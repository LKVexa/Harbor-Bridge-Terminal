# INV-25 - MicroVM devices

**Version:** 4.3.0 (see `CHANGELOG.md`)
**Group:** 01_Source_Inventory
**Series:** Post-Kubernetes Master Prompt & Workflow Series v4.0.0
**Checklist:** 100 requirements across ten dimensions, in `CHECKLIST.json`
**Audit source:** `CHECKLIST.json` contains the 100 auditable requirements. The historical `MASTER.md` corpus is not present in this standalone archive and is classified archival-only pending owner approval; see `docs/master-corpus.md`.

MicroVM devices is where the minimal device model is actually defined and defended. Each device is paravirtual, declares the exact guest-visible surface it exposes, and carries a rationale -- because a device without a reason to exist is attack surface with a justification attached after the fact.

## Responsibility

Own the paravirtual device catalogue: define every permitted device, its guest-visible surface and its rationale, and refuse to register a device that emulates legacy hardware or exposes host resources directly.

## Owns

- The paravirtual device catalogue and its schema
- Guest-visible surface per device
- Rationale and review status for each device
- Refusal of legacy emulation
- Device surface diffing between model versions

## Explicitly does not own

- Device backend implementations
- MicroVM lifecycle
- The I/O datapath
- Guest drivers
- Snapshot serialization

## Non-goals

- Implementing device backends
- Writing guest drivers
- Emulating legacy PCI or ISA hardware
- Deciding which devices a workload gets

## Interfaces

- `catalogue` - PK_DEVICE_CATALOGUE/1 - permitted devices with surface and rationale
- `diff` - PK_DEVICE_SURFACE_DIFF/1 - what changed between two device versions

## Service-level objectives

- **review coverage** - 100% of catalogue entries carry a rationale and reviewer (error budget: no budget)
- **legacy exclusion** - zero legacy-emulation devices in the catalogue (error budget: no budget)
- **surface visibility** - every version change produces a surface diff (error budget: no budget)

## Running it

```
python -m unittest discover -s inv25_microvm_devices/tests -v          # 87 tests, stdlib only
python -O -m unittest discover -s inv25_microvm_devices/tests          # optimised mode
python inv25_microvm_devices/tools/rtm.py check                        # traceability C001-C100
python inv25_microvm_devices/tools/gate.py run && python inv25_microvm_devices/tools/gate.py verify
python inv25_microvm_devices/tools/release.py build                    # reproducible archive + manifest + SBOM
python inv25_microvm_devices/conformance/performance/bench.py          # benchmarks vs thresholds
python -m inv25_microvm_devices.pk_bootstrap                           # pk_core availability (exit 3 if absent)
# Integration conformance additionally requires pk_core; set PK_CORE_PATH if it is elsewhere
python -m pk_core list
python -m pk_core run INV-25 --evidence evidence/pk_evidence.jsonl
python -m pk_core gate INV-25 --out conformance/PK_GATE_RESULTS.json
python -m pk_core verify evidence/pk_evidence.jsonl
```

W0 refuses to lock context on an incomplete contract; W4 refuses to integrate an
interface without a schema reference; W7 refuses to certify while any
requirement is blocked; W9 refuses to close out unless the evidence chain is
intact and all 100 requirements have been answered.

## Day-0 / day-1 / day-2

- **Day 0 (bootstrap):** import the package, run `pk_core run INV-25`, and archive the emitted evidence ledger as the baseline.
- **Day 1 (deployment):** run `pk_core gate INV-25`; a `NO_GO` verdict blocks the rollout, `CONDITIONAL_GO` requires the listed conditions to be accepted and recorded.
- **Day 2 (operation):** re-run the gate on every change to the contract or implementation and verify the ledger chains onto the previous head.

Rollback is the previous sealed evidence head; emergency disable is removal of
the component from the registry package, which the gate reports as a reduced
element count rather than a silent pass.


## Standalone hardening in 4.2.0

- Security-critical catalogue validation lives in dependency-free `model.py`, so it is testable even when `pk_core` is not installed.
- Unknown device classes fail closed; device names, versions, register identifiers, rationale, reviewer, and environment values are validated.
- Changed entries cannot silently overwrite an existing catalogue item; `replace()` requires an explicit version change and returns a surface diff.
- Machine-readable JSON Schemas are supplied for `PK_DEVICE_CATALOGUE/1` and `PK_DEVICE_SURFACE_DIFF/1`.
- `tests/test_model.py` provides standalone rejection, replacement, diff, export, and malformed-input coverage.

See `AUDIT_REPORT.md` for unresolved repository-level gaps and items that require the surrounding platform.


## Certification tooling added in 4.3.0

| Area | Where |
|---|---|
| Error contract `PK_DEVICE_ERROR/1` | `errors.py`, `docs/error-contract.md` |
| Resource ceilings | `model.py`, `docs/limits.md` |
| Authentication / capabilities | `authz.py`, `docs/authn-authz.md` |
| Transactional control plane (propose → approve → CAS activate, rollback, emergency disable, health, metrics, explain) | `store.py` |
| Tamper-evident audit `PK_DEVICE_AUDIT_EVENT/1` | `audit.py` |
| Activation records `PK_DEVICE_CONFIG_ACTIVATION/1` | `store.py`, schema |
| Artifact provenance verification | `provenance.py`, `docs/provenance.md` |
| Compatibility matrix / negotiation / pk_core startup check | `compat.py`, `pk_bootstrap.py`, `docs/compatibility.md` |
| ADR | `ADR/ADR-0001-virtio-net-block.md` (Proposed) |
| RTM | `governance/RTM.json` / `RTM.md` |
| Waivers, reviews, approvals registers | `governance/` |
| Evidence chain + gate | `evidence/pk_evidence.jsonl`, `conformance/PK_GATE_RESULTS.json` |
| Fuzz / fault / concurrency / integration-contract / performance suites | `tests/`, `conformance/` |
| CI / release | `.github/workflows/ci.yml`, `tools/release.py`, `pyproject.toml` |

**Current gate verdict: NO_GO** — 82 PASS, 11 BLOCKED, 4 EXTERNAL, 3 NOT_APPLICABLE. Every blocker needs
an input this repository cannot supply (named owners and approvals, pk_core, peer evidence, signing keys,
extra hardware); see `WORK_ORDER_STATUS.md`. Rollback/emergency disable are now `CatalogueStore.rollback()` /
`emergency_disable()` rather than registry removal.
