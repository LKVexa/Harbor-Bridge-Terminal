﻿param([string]$Root = $PSScriptRoot)
$ErrorActionPreference = "Stop"
$sumFile = Join-Path $Root "SHA256SUMS.txt"
if (-not (Test-Path -LiteralPath $sumFile)) { throw "Missing SHA256SUMS.txt" }
$listed = @{}
Get-Content -LiteralPath $sumFile -Encoding UTF8 | ForEach-Object {
  if ([string]::IsNullOrWhiteSpace($_)) { return }
  if ($_ -notmatch '^([0-9a-f]{64})  (.+)$') { throw "Malformed checksum line: $_" }
  $expected=$Matches[1]; $rel=$Matches[2]
  if ($listed.ContainsKey($rel)) { throw "Duplicate checksum path: $rel" }
  $listed[$rel]=$expected
  $target=Join-Path $Root ($rel.Replace('/', [IO.Path]::DirectorySeparatorChar))
  if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing file: $rel" }
  $actual=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw "Checksum mismatch: $rel" }
}
$actualFiles = Get-ChildItem -LiteralPath $Root -File -Recurse | Where-Object { $_.Name -ne 'SHA256SUMS.txt' }
foreach ($file in $actualFiles) {
  $rel=[IO.Path]::GetRelativePath($Root,$file.FullName).Replace('\','/')
  if (-not $listed.ContainsKey($rel)) { throw "Unlisted file: $rel" }
}
$components = @(Get-ChildItem -LiteralPath $Root -File -Recurse -Filter '*.md' | Where-Object { $_.Name -match '^\d{3}_' })
if ($components.Count -ne 325) { throw "Component count mismatch: $($components.Count)" }
$ledgerRows=0
Get-ChildItem -LiteralPath (Join-Path $Root 'LEDGERS') -File -Filter 'P??.csv' | ForEach-Object { $ledgerRows += @((Import-Csv -LiteralPath $_.FullName)).Count }
if ($ledgerRows -ne 325000) { throw "Ledger row mismatch: $ledgerRows" }
Write-Host "TIFF 9-Phase v1.6.0 verification PASS - $($listed.Count) files; 325 components; 325000 tasks."
