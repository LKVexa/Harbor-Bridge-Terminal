@echo off
setlocal
powershell.exe -NoLogo -NoProfile -File "%~dp0VERIFY.ps1" -Root "%~dp0"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Verification FAILED with exit code %RC%.
exit /b %RC%
