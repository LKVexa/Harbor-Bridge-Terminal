#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, json, re, sys
root=Path(__file__).resolve().parent; errors=[]
listed={}
for line in (root/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    try: expected,rel=line.split('  ',1)
    except ValueError: errors.append('Malformed checksum line'); continue
    if rel in listed: errors.append(f'Duplicate checksum path: {rel}')
    listed[rel]=expected
actual={str(p.relative_to(root)).replace('\\','/') for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'}
for rel,expected in listed.items():
    p=root/rel
    if not p.is_file(): errors.append(f'Missing: {rel}')
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=expected: errors.append(f'Checksum mismatch: {rel}')
for rel in sorted(actual-set(listed)): errors.append(f'Unlisted file: {rel}')
for rel in sorted(set(listed)-actual): errors.append(f'Listed file absent: {rel}')
components=list(root.glob('P??/S??/[0-9][0-9][0-9]_*.md'))
ids=sorted(int(p.name[:3]) for p in components)
if ids!=list(range(1,326)): errors.append('Component IDs are incomplete or duplicated')
prompt_ids=set()
for p in components:
    t=p.read_text(encoding='utf-8'); cid=int(p.name[:3])
    prompt_ids.update(re.findall(r'^    \*\*Prompt (C\d{3}-T\d{3}\.\d{2})\*\*$',t,re.M))
    if re.search(r'^    \*\*Required output:\*\* Canonical task ID `C\d{3}-Tnnn\.nn`',t,re.M): errors.append(f'Placeholder output task ID remains: {p}')
ledger_ids=[]
for ledger in sorted((root/'LEDGERS').glob('P??.csv')):
    with ledger.open(newline='',encoding='utf-8') as f: ledger_ids.extend(r['task_id'] for r in csv.DictReader(f))
if len(ledger_ids)!=325000 or len(set(ledger_ids))!=325000: errors.append('Ledger ID count/uniqueness failure')
if set(ledger_ids)!=prompt_ids: errors.append('Ledger IDs do not match prompt IDs')
paths=[str(p.relative_to(root)).replace('\\','/') for p in root.rglob('*') if p.is_file()]
if max(map(len,paths))>120: errors.append('Relative path exceeds 120 characters')
if len(paths)!=len({p.lower() for p in paths}): errors.append('Case-insensitive path collision detected')
example=json.loads((root/'EVIDENCE_RECORD.example.json').read_text(encoding='utf-8'))
if example.get('task_id') not in prompt_ids or example.get('schema_version')!='1.6.0': errors.append('Evidence example linkage/version failure')
if errors:
    print('VERIFICATION FAIL'); [print('-',e) for e in errors]; sys.exit(1)
print('TIFF 9-Phase v1.6.0 verification PASS')
print(f'325 components; 325000 canonical tasks; {len(actual)+1} files; max path {max(map(len,paths))}')
