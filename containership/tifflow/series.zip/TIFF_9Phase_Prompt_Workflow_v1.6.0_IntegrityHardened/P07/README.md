# Phase 07 - Geo/OME Metadata and Multiresolution Pyramids

## Dependency Contract

- Required predecessors: Phases 01-06
- Required entry evidence: P06 exit decision and evidence bundle
- Downstream consumer: P08

## Components

- [222 - GeoTIFF Extension Parser](S17/222_GeoTIFF_Extension_Parser.md)
- [223 - GeoKeyDirectoryTag Parser](S17/223_GeoKeyDirectoryTag_Parser.md)
- [224 - GeoDoubleParamsTag Parser](S17/224_GeoDoubleParamsTag_Parser.md)
- [225 - GeoAsciiParamsTag Parser](S17/225_GeoAsciiParamsTag_Parser.md)
- [226 - GeoKey Header Parser](S17/226_GeoKey_Header_Parser.md)
- [227 - GeoKey Entry Resolver](S17/227_GeoKey_Entry_Resolver.md)
- [228 - KeyID Registry](S17/228_KeyID_Registry.md)
- [229 - TIFFTagLocation Resolver](S17/229_TIFFTagLocation_Resolver.md)
- [230 - GeoKey Count Decoder](S17/230_GeoKey_Count_Decoder.md)
- [231 - GeoKey ValueOffset Resolver](S17/231_GeoKey_ValueOffset_Resolver.md)
- [232 - Coordinate Reference System Engine](S17/232_Coordinate_Reference_System_Engine.md)
- [233 - Projection Metadata Engine](S17/233_Projection_Metadata_Engine.md)
- [234 - Ellipsoid Metadata Engine](S17/234_Ellipsoid_Metadata_Engine.md)
- [235 - Datum Metadata Engine](S17/235_Datum_Metadata_Engine.md)
- [236 - UTM Support](S17/236_UTM_Support.md)
- [237 - WGS84 Support](S17/237_WGS84_Support.md)
- [238 - Affine Transformation Engine](S17/238_Affine_Transformation_Engine.md)
- [239 - Pixel-to-World Coordinate Mapper](S17/239_Pixel_to_World_Coordinate_Mapper.md)
- [240 - OME-TIFF Parser](S18/240_OME_TIFF_Parser.md)
- [241 - OME-XML Parser](S18/241_OME_XML_Parser.md)
- [242 - ImageDescription XML Extractor](S18/242_ImageDescription_XML_Extractor.md)
- [243 - UTF-8 Metadata Engine](S18/243_UTF_8_Metadata_Engine.md)
- [244 - <Pixels> Element Parser](S18/244_Pixels_Element_Parser.md)
- [245 - <TiffData> Mapping Engine](S18/245_TiffData_Mapping_Engine.md)
- [246 - DimensionOrder Parser](S18/246_DimensionOrder_Parser.md)
- [247 - X-Dimension Manager](S18/247_X_Dimension_Manager.md)
- [248 - Y-Dimension Manager](S18/248_Y_Dimension_Manager.md)
- [249 - Z-Plane Manager](S18/249_Z_Plane_Manager.md)
- [250 - Time-Frame Manager](S18/250_Time_Frame_Manager.md)
- [251 - Spectral Channel Manager](S18/251_Spectral_Channel_Manager.md)
- [252 - 5D Hyperstack Indexer](S18/252_5D_Hyperstack_Indexer.md)
- [253 - IFD-to-ZTC Mapping Engine](S18/253_IFD_to_ZTC_Mapping_Engine.md)
- [254 - Hyperstack Scroll Resolver](S18/254_Hyperstack_Scroll_Resolver.md)
- [255 - Multi-file OME-TIFF Manager](S18/255_Multi_file_OME_TIFF_Manager.md)
- [256 - Bio-Formats Compatibility Layer](S18/256_Bio_Formats_Compatibility_Layer.md)
- [257 - Pyramid Builder](S19/257_Pyramid_Builder.md)
- [258 - Downsampling Engine](S19/258_Downsampling_Engine.md)
- [259 - 2x Resolution-Level Generator](S19/259_2x_Resolution_Level_Generator.md)
- [260 - SubIFD Tag Parser](S19/260_SubIFD_Tag_Parser.md)
- [261 - SubIFD Offset Tree](S19/261_SubIFD_Offset_Tree.md)
- [262 - Parent/Child IFD Mapper](S19/262_Parent_Child_IFD_Mapper.md)
- [263 - NewSubfileType Parser](S19/263_NewSubfileType_Parser.md)
- [264 - Reduced-Resolution Classifier](S19/264_Reduced_Resolution_Classifier.md)
- [265 - Zoom-Level Resolver](S19/265_Zoom_Level_Resolver.md)
- [266 - Viewport-to-Pyramid-Level Mapper](S19/266_Viewport_to_Pyramid_Level_Mapper.md)
- [267 - Pyramidal Tile Server Interface](S19/267_Pyramidal_Tile_Server_Interface.md)
- [268 - Whole-Slide Image Viewer Backend](S19/268_Whole_Slide_Image_Viewer_Backend.md)

## Exit Gate

- All component evidence is complete and hash-addressed.
- No `FAIL` or `BLOCKED` task may be treated as closed; critical blockers prohibit advancement.
- Every `BLOCKED` result has an owner, dependency, target date, and approved disposition.
- Security, malformed-input, resource-limit, compatibility, and regression checks pass where applicable.
- Independent reviewer records `GO`, `CONDITIONAL_GO`, or `NO_GO`.
