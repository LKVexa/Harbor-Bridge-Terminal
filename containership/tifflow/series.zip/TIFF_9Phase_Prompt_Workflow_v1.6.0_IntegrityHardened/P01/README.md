# Phase 01 - Binary Foundations and Large-File Addressing

## Dependency Contract

- Required predecessors: None
- Required entry evidence: None
- Downstream consumer: P02

## Components

- [001 - TIFF File Signature Detector](S01/001_TIFF_File_Signature_Detector.md)
- [002 - Byte-Order Detector](S01/002_Byte_Order_Detector.md)
- [003 - Endian Conversion Engine](S01/003_Endian_Conversion_Engine.md)
- [004 - Classic TIFF Header Parser](S01/004_Classic_TIFF_Header_Parser.md)
- [005 - Magic Number Validator](S01/005_Magic_Number_Validator.md)
- [006 - Initial IFD Offset Resolver](S01/006_Initial_IFD_Offset_Resolver.md)
- [007 - Image File Directory Parser](S01/007_Image_File_Directory_Parser.md)
- [008 - IFD Chain Navigator](S01/008_IFD_Chain_Navigator.md)
- [009 - Tag Entry Decoder](S01/009_Tag_Entry_Decoder.md)
- [010 - TIFF Datatype Engine](S01/010_TIFF_Datatype_Engine.md)
- [011 - Inline-Value Decoder](S01/011_Inline_Value_Decoder.md)
- [012 - External-Value Offset Resolver](S01/012_External_Value_Offset_Resolver.md)
- [013 - Baseline Tag Registry](S01/013_Baseline_Tag_Registry.md)
- [014 - Extended Tag Registry](S01/014_Extended_Tag_Registry.md)
- [015 - Private Tag Registry](S01/015_Private_Tag_Registry.md)
- [016 - Private IFD Support](S01/016_Private_IFD_Support.md)
- [017 - Nested IFD Support](S01/017_Nested_IFD_Support.md)
- [018 - Multi-page TIFF Manager](S01/018_Multi_page_TIFF_Manager.md)
- [019 - Multidimensional TIFF Directory Manager](S01/019_Multidimensional_TIFF_Directory_Manager.md)
- [020 - IFD Ordering Validator](S01/020_IFD_Ordering_Validator.md)
- [021 - BigTIFF Format Detector](S02/021_BigTIFF_Format_Detector.md)
- [022 - BigTIFF 16-Byte Header Parser](S02/022_BigTIFF_16_Byte_Header_Parser.md)
- [023 - BigTIFF Magic-Number-43 Validator](S02/023_BigTIFF_Magic_Number_43_Validator.md)
- [024 - 64-Bit Offset Engine](S02/024_64_Bit_Offset_Engine.md)
- [025 - 64-Bit Dimension Engine](S02/025_64_Bit_Dimension_Engine.md)
- [026 - 64-Bit IFD Entry Counter](S02/026_64_Bit_IFD_Entry_Counter.md)
- [027 - 20-Byte BigTIFF Entry Parser](S02/027_20_Byte_BigTIFF_Entry_Parser.md)
- [028 - 8-Byte Inline Value Handler](S02/028_8_Byte_Inline_Value_Handler.md)
- [029 - Large-File Addressing Layer](S02/029_Large_File_Addressing_Layer.md)
- [030 - Classic-TIFF/BigTIFF Compatibility Abstraction](S02/030_Classic_TIFF_BigTIFF_Compatibility_Abstraction.md)
- [031 - Legacy 32-Bit Parser Rejection Guard](S02/031_Legacy_32_Bit_Parser_Rejection_Guard.md)

## Exit Gate

- All component evidence is complete and hash-addressed.
- No `FAIL` or `BLOCKED` task may be treated as closed; critical blockers prohibit advancement.
- Every `BLOCKED` result has an owner, dependency, target date, and approved disposition.
- Security, malformed-input, resource-limit, compatibility, and regression checks pass where applicable.
- Independent reviewer records `GO`, `CONDITIONAL_GO`, or `NO_GO`.
