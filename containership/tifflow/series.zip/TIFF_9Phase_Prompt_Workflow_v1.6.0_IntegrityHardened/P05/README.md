# Phase 05 - Native Integration, Concurrency, and Streaming

## Dependency Contract

- Required predecessors: Phases 01-04
- Required entry evidence: P04 exit decision and evidence bundle
- Downstream consumer: P06

## Components

- [151 - libtiff Core Adapter](S11/151_libtiff_Core_Adapter.md)
- [152 - TIFFOpen Wrapper](S11/152_TIFFOpen_Wrapper.md)
- [153 - TIFFClientOpen Wrapper](S11/153_TIFFClientOpen_Wrapper.md)
- [154 - TIFFReadEncodedTile Adapter](S11/154_TIFFReadEncodedTile_Adapter.md)
- [155 - TIFFReadEncodedStrip Adapter](S11/155_TIFFReadEncodedStrip_Adapter.md)
- [156 - TIFFReadScanline Adapter](S11/156_TIFFReadScanline_Adapter.md)
- [157 - TIFF Directory Traversal Wrapper](S11/157_TIFF_Directory_Traversal_Wrapper.md)
- [158 - TIFF Memory Allocation Adapter](S11/158_TIFF_Memory_Allocation_Adapter.md)
- [159 - libtiff Error Translation Layer](S11/159_libtiff_Error_Translation_Layer.md)
- [160 - Strip-Chopping Controller](S11/160_Strip_Chopping_Controller.md)
- [161 - Sequential Scanline Manager](S11/161_Sequential_Scanline_Manager.md)
- [162 - Compressed-State Coordinator](S11/162_Compressed_State_Coordinator.md)
- [163 - Independent TIFF Handle Pool](S12/163_Independent_TIFF_Handle_Pool.md)
- [164 - Reader Thread](S12/164_Reader_Thread.md)
- [165 - Writer Thread](S12/165_Writer_Thread.md)
- [166 - Compressed Tile Dispatch Queue](S12/166_Compressed_Tile_Dispatch_Queue.md)
- [167 - Decode Worker Pool](S12/167_Decode_Worker_Pool.md)
- [168 - Encode Worker Pool](S12/168_Encode_Worker_Pool.md)
- [169 - Per-Thread File Handle Manager](S12/169_Per_Thread_File_Handle_Manager.md)
- [170 - I/O-to-Codec Decoupling Layer](S12/170_I_O_to_Codec_Decoupling_Layer.md)
- [171 - Offset Synchronization Layer](S12/171_Offset_Synchronization_Layer.md)
- [172 - Prefetch Queue](S12/172_Prefetch_Queue.md)
- [173 - Asynchronous Tile Scheduler](S12/173_Asynchronous_Tile_Scheduler.md)
- [174 - Backpressure Controller](S12/174_Backpressure_Controller.md)
- [175 - libvips Integration](S13/175_libvips_Integration.md)
- [176 - Lazy Image Operation Graph](S13/176_Lazy_Image_Operation_Graph.md)
- [177 - Execution Dependency Graph](S13/177_Execution_Dependency_Graph.md)
- [178 - Sink-to-Source Evaluator](S13/178_Sink_to_Source_Evaluator.md)
- [179 - Region Demand Scheduler](S13/179_Region_Demand_Scheduler.md)
- [180 - 128x128 Working Region Engine](S13/180_128x128_Working_Region_Engine.md)
- [181 - Streaming Pixel Processor](S13/181_Streaming_Pixel_Processor.md)
- [182 - Temporary Region Buffer](S13/182_Temporary_Region_Buffer.md)
- [183 - Buffer Recycling Pool](S13/183_Buffer_Recycling_Pool.md)
- [184 - Pipeline Fusion Layer](S13/184_Pipeline_Fusion_Layer.md)
- [185 - Streaming Color Conversion](S13/185_Streaming_Color_Conversion.md)
- [186 - Streaming Convolution](S13/186_Streaming_Convolution.md)
- [187 - Streaming Compression](S13/187_Streaming_Compression.md)
- [188 - Out-of-Core TIFF Writer](S13/188_Out_of_Core_TIFF_Writer.md)

## Exit Gate

- All component evidence is complete and hash-addressed.
- No `FAIL` or `BLOCKED` task may be treated as closed; critical blockers prohibit advancement.
- Every `BLOCKED` result has an owner, dependency, target date, and approved disposition.
- Security, malformed-input, resource-limit, compatibility, and regression checks pass where applicable.
- Independent reviewer records `GO`, `CONDITIONAL_GO`, or `NO_GO`.
