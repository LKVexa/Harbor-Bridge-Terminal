# Phase 03 - Compression, Prediction, and LERC

## Dependency Contract

- Required predecessors: Phases 01-02
- Required entry evidence: P02 exit decision and evidence bundle
- Downstream consumer: P04

## Components

- [076 - Compression Tag Dispatcher](S06/076_Compression_Tag_Dispatcher.md)
- [077 - Codec Plugin Interface](S06/077_Codec_Plugin_Interface.md)
- [078 - CCITT Group 3 Decoder](S06/078_CCITT_Group_3_Decoder.md)
- [079 - CCITT Group 4 Decoder](S06/079_CCITT_Group_4_Decoder.md)
- [080 - LZW Codec](S06/080_LZW_Codec.md)
- [081 - Deflate/zlib Codec](S06/081_Deflate_zlib_Codec.md)
- [082 - Zstandard Codec](S06/082_Zstandard_Codec.md)
- [083 - JPEG Codec](S06/083_JPEG_Codec.md)
- [084 - JPEG2000 Codec](S06/084_JPEG2000_Codec.md)
- [085 - WebP Codec](S06/085_WebP_Codec.md)
- [086 - JPEG XL Codec](S06/086_JPEG_XL_Codec.md)
- [087 - Lossless Compression Pipeline](S06/087_Lossless_Compression_Pipeline.md)
- [088 - Lossy Compression Pipeline](S06/088_Lossy_Compression_Pipeline.md)
- [089 - Per-Tile Compression Manager](S06/089_Per_Tile_Compression_Manager.md)
- [090 - Per-Strip Compression Manager](S06/090_Per_Strip_Compression_Manager.md)
- [091 - Predictor Tag Parser](S07/091_Predictor_Tag_Parser.md)
- [092 - Predictor 2 Horizontal Differencing Encoder](S07/092_Predictor_2_Horizontal_Differencing_Encoder.md)
- [093 - Predictor 2 Decoder](S07/093_Predictor_2_Decoder.md)
- [094 - Integer Residual Generator](S07/094_Integer_Residual_Generator.md)
- [095 - Cumulative Reconstruction Engine](S07/095_Cumulative_Reconstruction_Engine.md)
- [096 - Predictor 3 Floating-Point Processor](S07/096_Predictor_3_Floating_Point_Processor.md)
- [097 - IEEE-754 Float Analyzer](S07/097_IEEE_754_Float_Analyzer.md)
- [098 - Floating-Point Byte Shuffler](S07/098_Floating_Point_Byte_Shuffler.md)
- [099 - AoS-to-SoA Byte Transposer](S07/099_AoS_to_SoA_Byte_Transposer.md)
- [100 - Floating-Point Horizontal Differencing Engine](S07/100_Floating_Point_Horizontal_Differencing_Engine.md)
- [101 - Predictor Endianness Guard](S07/101_Predictor_Endianness_Guard.md)
- [102 - Predictor/Codec Pipeline Coordinator](S07/102_Predictor_Codec_Pipeline_Coordinator.md)
- [103 - LERC Codec Integration](S08/103_LERC_Codec_Integration.md)
- [104 - MaxZError Controller](S08/104_MaxZError_Controller.md)
- [105 - Lossless LERC Mode](S08/105_Lossless_LERC_Mode.md)
- [106 - Bounded-Loss Compression Mode](S08/106_Bounded_Loss_Compression_Mode.md)
- [107 - Micro-Block Partitioner](S08/107_Micro_Block_Partitioner.md)
- [108 - Block Minimum Calculator](S08/108_Block_Minimum_Calculator.md)
- [109 - Block Maximum Calculator](S08/109_Block_Maximum_Calculator.md)
- [110 - Block Range Analyzer](S08/110_Block_Range_Analyzer.md)
- [111 - Constant-Block Collapser](S08/111_Constant_Block_Collapser.md)
- [112 - Residual Quantizer](S08/112_Residual_Quantizer.md)
- [113 - Variable Bit-Width Calculator](S08/113_Variable_Bit_Width_Calculator.md)
- [114 - Bit-Stuffing Engine](S08/114_Bit_Stuffing_Engine.md)
- [115 - Delta Histogram Generator](S08/115_Delta_Histogram_Generator.md)
- [116 - 8-Bit Huffman Encoder](S08/116_8_Bit_Huffman_Encoder.md)
- [117 - Valid/Invalid Pixel Mask](S08/117_Valid_Invalid_Pixel_Mask.md)
- [118 - NaN Handler](S08/118_NaN_Handler.md)
- [119 - NoData Boundary Handler](S08/119_NoData_Boundary_Handler.md)
- [120 - LERC + Zstd Pipeline](S08/120_LERC_Zstd_Pipeline.md)
- [121 - LERC + Deflate Pipeline](S08/121_LERC_Deflate_Pipeline.md)

## Exit Gate

- All component evidence is complete and hash-addressed.
- No `FAIL` or `BLOCKED` task may be treated as closed; critical blockers prohibit advancement.
- Every `BLOCKED` result has an owner, dependency, target date, and approved disposition.
- Security, malformed-input, resource-limit, compatibility, and regression checks pass where applicable.
- Independent reviewer records `GO`, `CONDITIONAL_GO`, or `NO_GO`.
