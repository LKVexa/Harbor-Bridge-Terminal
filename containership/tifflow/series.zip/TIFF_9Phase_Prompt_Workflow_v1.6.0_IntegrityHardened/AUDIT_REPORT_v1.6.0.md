# Audit and Hardening Report - v1.6.0

## New findings corrected

1. **Placeholder evidence IDs (HIGH):** each workflow required `Cxxx-Tnnn.nn` rather than its exact task ID. All 325,000 required-output clauses now carry the exact canonical ID.
2. **Overbroad specification routing (HIGH):** every prompt named the entire TIFF/cloud stack. Prompts now reference only the specifications and contracts relevant to their delivery phase.
3. **Unlisted-file blind spot (HIGH):** checksum verification detected missing/modified listed files but permitted extra files. Python and PowerShell verifiers now enforce a complete file allowlist.
4. **Embedded-instruction risk (HIGH):** execution contracts now treat instructions inside tags, XML, JSON, profiles, filenames, URLs, and other inputs as inert untrusted data.
5. **XML/resource-expansion risk (HIGH):** contracts now require disabled external entities/resource resolution and bounded recursion, expansion, decompression, dimensions, offsets, allocation, and work factors.
6. **Evidence-schema gaps (MEDIUM):** nonzero SHA-256 values are required; `FAIL`/`BLOCKED` require rationale and next action; `NOT_APPLICABLE` requires rationale.
7. **Windows verifier depth (MEDIUM):** native PowerShell verification now checks complete allowlisting, component count, and all phase-ledger rows.
8. **No evidence example (LOW):** added a schema-aligned example linked to a real canonical task.

All v1.4.0 and v1.5.0 controls remain in force.
