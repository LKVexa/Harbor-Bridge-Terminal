# Phase 02 - Pixel Storage, Channel Layout, and Color

## Dependency Contract

- Required predecessors: Phase 01
- Required entry evidence: P01 exit decision and evidence bundle
- Downstream consumer: P03

## Components

- [032 - Raster Geometry Descriptor](S03/032_Raster_Geometry_Descriptor.md)
- [033 - Image Width/Height Manager](S03/033_Image_Width_Height_Manager.md)
- [034 - Strip-Based Storage Engine](S03/034_Strip_Based_Storage_Engine.md)
- [035 - StripOffsets Parser](S03/035_StripOffsets_Parser.md)
- [036 - RowsPerStrip Parser](S03/036_RowsPerStrip_Parser.md)
- [037 - StripByteCounts Parser](S03/037_StripByteCounts_Parser.md)
- [038 - Sequential Strip Reader](S03/038_Sequential_Strip_Reader.md)
- [039 - Strip Decompression Buffer](S03/039_Strip_Decompression_Buffer.md)
- [040 - Tiled Storage Engine](S03/040_Tiled_Storage_Engine.md)
- [041 - TileWidth Parser](S03/041_TileWidth_Parser.md)
- [042 - TileLength Parser](S03/042_TileLength_Parser.md)
- [043 - TileOffsets Parser](S03/043_TileOffsets_Parser.md)
- [044 - TileByteCounts Parser](S03/044_TileByteCounts_Parser.md)
- [045 - Tile Coordinate Mapper](S03/045_Tile_Coordinate_Mapper.md)
- [046 - Spatial Region-to-Tile Resolver](S03/046_Spatial_Region_to_Tile_Resolver.md)
- [047 - Partial Tile Reader](S03/047_Partial_Tile_Reader.md)
- [048 - Tile Cache](S03/048_Tile_Cache.md)
- [049 - Random-Access Pixel Window Engine](S03/049_Random_Access_Pixel_Window_Engine.md)
- [050 - Power-of-Two Tile Geometry Optimizer](S03/050_Power_of_Two_Tile_Geometry_Optimizer.md)
- [051 - PlanarConfiguration Parser](S04/051_PlanarConfiguration_Parser.md)
- [052 - Interleaved/Chunky Pixel Handler](S04/052_Interleaved_Chunky_Pixel_Handler.md)
- [053 - Planar/Separate Channel Handler](S04/053_Planar_Separate_Channel_Handler.md)
- [054 - Array-of-Structures Pixel Interface](S04/054_Array_of_Structures_Pixel_Interface.md)
- [055 - Structure-of-Arrays Pixel Interface](S04/055_Structure_of_Arrays_Pixel_Interface.md)
- [056 - RGB Channel Extractor](S04/056_RGB_Channel_Extractor.md)
- [057 - CMYK Channel Extractor](S04/057_CMYK_Channel_Extractor.md)
- [058 - Multispectral Channel Extractor](S04/058_Multispectral_Channel_Extractor.md)
- [059 - Channel Repacking Engine](S04/059_Channel_Repacking_Engine.md)
- [060 - Interleaved-to-Planar Converter](S04/060_Interleaved_to_Planar_Converter.md)
- [061 - Planar-to-Interleaved Converter](S04/061_Planar_to_Interleaved_Converter.md)
- [062 - Independent Channel Processor](S04/062_Independent_Channel_Processor.md)
- [063 - PhotometricInterpretation Parser](S05/063_PhotometricInterpretation_Parser.md)
- [064 - MINISWHITE Decoder](S05/064_MINISWHITE_Decoder.md)
- [065 - MINISBLACK Decoder](S05/065_MINISBLACK_Decoder.md)
- [066 - RGB Interpreter](S05/066_RGB_Interpreter.md)
- [067 - Palette/Indexed Color Interpreter](S05/067_Palette_Indexed_Color_Interpreter.md)
- [068 - CMYK/Separation Interpreter](S05/068_CMYK_Separation_Interpreter.md)
- [069 - YCbCr Interpreter](S05/069_YCbCr_Interpreter.md)
- [070 - Palette Lookup Table Engine](S05/070_Palette_Lookup_Table_Engine.md)
- [071 - ICC Profile Extractor](S05/071_ICC_Profile_Extractor.md)
- [072 - ICC Color-Space Processor](S05/072_ICC_Color_Space_Processor.md)
- [073 - Color-Space Conversion Engine](S05/073_Color_Space_Conversion_Engine.md)
- [074 - Display-Space Calibration Layer](S05/074_Display_Space_Calibration_Layer.md)
- [075 - Radiometric Fidelity Pipeline](S05/075_Radiometric_Fidelity_Pipeline.md)

## Exit Gate

- All component evidence is complete and hash-addressed.
- No `FAIL` or `BLOCKED` task may be treated as closed; critical blockers prohibit advancement.
- Every `BLOCKED` result has an owner, dependency, target date, and approved disposition.
- Security, malformed-input, resource-limit, compatibility, and regression checks pass where applicable.
- Independent reviewer records `GO`, `CONDITIONAL_GO`, or `NO_GO`.
