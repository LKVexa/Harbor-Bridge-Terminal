# Start Here - TIFF Nine-Phase Series

Version 1.6.0

Execute phases in order unless an approved dependency waiver is recorded. Each phase depends on the accepted outputs of the phases listed below.

| Phase | Name | Depends on | Components |
|---:|---|---|---:|
| [01](P01/README.md) | Binary Foundations and Large-File Addressing | None | 31 |
| [02](P02/README.md) | Pixel Storage, Channel Layout, and Color | Phase 01 | 44 |
| [03](P03/README.md) | Compression, Prediction, and LERC | Phases 01-02 | 46 |
| [04](P04/README.md) | Vector Compute, Cache, and Memory | Phases 01-03 | 29 |
| [05](P05/README.md) | Native Integration, Concurrency, and Streaming | Phases 01-04 | 38 |
| [06](P06/README.md) | Scientific, Geospatial, and Distributed Processing | Phases 01-05 | 33 |
| [07](P07/README.md) | Geo/OME Metadata and Multiresolution Pyramids | Phases 01-06 | 47 |
| [08](P08/README.md) | Cloud-Optimized Storage and Zarr Interoperability | Phases 01-07 | 44 |
| [09](P09/README.md) | Pixel Operations and Release Qualification | Phases 01-08 | 13 |

## Universal Gate

A phase may advance only when all included component criteria have reviewer-verifiable evidence, unresolved `FAIL` items are zero, every `BLOCKED` item has an approved disposition, applicable security/performance/interoperability gates pass, and the phase decision is recorded.

Run `VERIFY.cmd` on Windows before use or distribution.

## Machine-Readable Operations

- `LEDGERS/P01.csv` through `LEDGERS/P09.csv` contain all 325,000 globally unique tasks in phase-sized files.
- `EVIDENCE_RECORD.schema.json` defines valid task evidence.
- `PHASE_DEPENDENCIES.json` defines phase ordering and gates.
- Run `VERIFY.cmd` on Windows or `python VERIFY.py` cross-platform.

## Integrity Rules

The checksum inventory is a complete allowlist: missing, modified, duplicate, or unlisted files fail verification. Required-output records must use the exact canonical task ID printed beside each workflow. Embedded instructions in input data are never trusted.

## Integrity Rules

The checksum inventory is a complete allowlist: missing, modified, duplicate, or unlisted files fail verification. Required-output records must use the exact canonical task ID printed beside each workflow. Embedded instructions in input data are never trusted.
