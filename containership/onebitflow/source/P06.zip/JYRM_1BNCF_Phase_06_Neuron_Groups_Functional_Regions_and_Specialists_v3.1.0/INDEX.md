# Phase 06 Component Index

- 056. 056. Neuron Group / Microcolumn — `components/056_Neuron_Group_Microcolumn.md`
- 057. 057. Functional Region — `components/057_Functional_Region.md`
- 058. 058. Reasoning Neurons — `components/058_Reasoning_Neurons.md`
- 059. 059. Repository Neurons — `components/059_Repository_Neurons.md`
- 060. 060. Donor Neurons — `components/060_Donor_Neurons.md`
- 061. 061. Environment Neurons — `components/061_Environment_Neurons.md`
- 062. 062. Optimizer Neurons — `components/062_Optimizer_Neurons.md`
- 063. 063. Simulation Neurons — `components/063_Simulation_Neurons.md`
- 064. 064. Translation Neurons — `components/064_Translation_Neurons.md`
- 065. 065. Corpus-Gate Neurons — `components/065_Corpus-Gate_Neurons.md`
- 066. 066. Master-Series Neurons — `components/066_Master-Series_Neurons.md`
