# Phase 03 Component Index

- 023. 023. Neuron/Layer Address Map — `components/023_Neuron_Layer_Address_Map.md`
- 024. 024. Communication Routing Table — `components/024_Communication_Routing_Table.md`
- 025. 025. Sparse Recipient Map — `components/025_Sparse_Recipient_Map.md`
- 026. 026. Compressed Collective Engine — `components/026_Compressed_Collective_Engine.md`
- 027. 027. Gather Phase — `components/027_Gather_Phase.md`
- 028. 028. Average/Reduce Phase — `components/028_Average_Reduce_Phase.md`
- 029. 029. Scatter/Broadcast Phase — `components/029_Scatter_Broadcast_Phase.md`
- 030. 030. Backend Abstraction Layer — `components/030_Backend_Abstraction_Layer.md`
- 031. 031. NCCL Backend — `components/031_NCCL_Backend.md`
- 032. 032. Shared-Memory Backend — `components/032_Shared-Memory_Backend.md`
- 033. 033. Memory-Mapped Backend — `components/033_Memory-Mapped_Backend.md`
