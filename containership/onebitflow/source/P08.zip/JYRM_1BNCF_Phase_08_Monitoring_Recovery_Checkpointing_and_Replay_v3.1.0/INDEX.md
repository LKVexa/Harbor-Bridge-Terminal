# Phase 08 Component Index

- 078. 078. Bit-Balance Monitor — `components/078_Bit-Balance_Monitor.md`
- 079. 079. Signal Saturation Monitor — `components/079_Signal_Saturation_Monitor.md`
- 080. 080. Compression-Error Monitor — `components/080_Compression-Error_Monitor.md`
- 081. 081. Layer Divergence Monitor — `components/081_Layer_Divergence_Monitor.md`
- 082. 082. Fallback-to-Full-Precision Switch — `components/082_Fallback-to-Full-Precision_Switch.md`
- 083. 083. Automatic Recovery Window — `components/083_Automatic_Recovery_Window.md`
- 084. 084. Re-entry-to-1-bit Gate — `components/084_Re-entry-to-1-bit_Gate.md`
- 085. 085. Checkpointing of Residual States — `components/085_Checkpointing_of_Residual_States.md`
- 086. 086. Checkpointing of Momentum States — `components/086_Checkpointing_of_Momentum_States.md`
- 087. 087. Checkpointing of Scales — `components/087_Checkpointing_of_Scales.md`
- 088. 088. Deterministic Replay Support — `components/088_Deterministic_Replay_Support.md`
