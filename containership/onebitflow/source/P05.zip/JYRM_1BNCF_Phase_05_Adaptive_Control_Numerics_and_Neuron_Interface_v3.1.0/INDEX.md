# Phase 05 Component Index

- 045. 045. Reference/Fresh Ratio Calculator — `components/045_Reference_Fresh_Ratio_Calculator.md`
- 046. 046. Adaptive Communication Gain — `components/046_Adaptive_Communication_Gain.md`
- 047. 047. Per-Layer Gain — `components/047_Per-Layer_Gain.md`
- 048. 048. Per-Tensor Gain — `components/048_Per-Tensor_Gain.md`
- 049. 049. Lower Scaling Bound — `components/049_Lower_Scaling_Bound.md`
- 050. 050. Upper Scaling Bound — `components/050_Upper_Scaling_Bound.md`
- 051. 051. Maximum Per-Step Scale-Change Limit — `components/051_Maximum_Per-Step_Scale-Change_Limit.md`
- 052. 052. Soft Threshold Controller — `components/052_Soft_Threshold_Controller.md`
- 053. 053. Outlier Clamp — `components/053_Outlier_Clamp.md`
- 054. 054. Numerical Stability Guard — `components/054_Numerical_Stability_Guard.md`
- 055. 055. JYRM Neuron Interface — `components/055_JYRM_Neuron_Interface.md`
