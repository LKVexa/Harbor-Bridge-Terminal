# Phase 05 — Adaptive Control Numerics and Neuron Interface

Components: 045–055
Components in phase: 11
Nested tasks / prompts / workflows: 27,500

Apply this phase cumulatively after all earlier phases.

Global rule: **1-bit communication, not 1-bit cognition.**
Local computation/state may remain at the precision required for correctness; the communication scalar/sign stream is what is compressed.

Every item is fail-closed and must emit evidence before it can be considered complete.
