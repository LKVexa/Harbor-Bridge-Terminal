# Phase 01 Component Index

- 001. 001. 1-Bit Communication Mode Controller — `components/001_1-Bit_Communication_Mode_Controller.md`
- 002. 002. Full-Precision Warmup Engine — `components/002_Full-Precision_Warmup_Engine.md`
- 003. 003. Automatic Warmup Convergence Detector — `components/003_Automatic_Warmup_Convergence_Detector.md`
- 004. 004. Neuron Communication State Vector — `components/004_Neuron_Communication_State_Vector.md`
- 005. 005. Neuron Momentum State — `components/005_Neuron_Momentum_State.md`
- 006. 006. Momentum Fusion Engine — `components/006_Momentum_Fusion_Engine.md`
- 007. 007. Binary Sign Quantizer — `components/007_Binary_Sign_Quantizer.md`
- 008. 008. Binary Encoding Convention — `components/008_Binary_Encoding_Convention.md`
- 009. 009. Per-Block Magnitude Scale — `components/009_Per-Block_Magnitude_Scale.md`
- 010. 010. Scale Estimator — `components/010_Scale_Estimator.md`
- 011. 011. Scale Granularity Controller — `components/011_Scale_Granularity_Controller.md`
