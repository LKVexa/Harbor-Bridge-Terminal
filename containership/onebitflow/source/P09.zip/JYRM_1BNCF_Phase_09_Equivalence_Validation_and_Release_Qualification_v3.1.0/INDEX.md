# Phase 09 Component Index

- 089. 089. Full-Precision JYRM Reference Run — `components/089_Full-Precision_JYRM_Reference_Run.md`
- 090. 090. 1-Bit JYRM Comparison Run — `components/090_1-Bit_JYRM_Comparison_Run.md`
- 091. 091. Repository-Refinement Quality Comparison — `components/091_Repository-Refinement_Quality_Comparison.md`
- 092. 092. Donor-Selection Equivalence Test — `components/092_Donor-Selection_Equivalence_Test.md`
- 093. 093. QAM Decision-Equivalence Test — `components/093_QAM_Decision-Equivalence_Test.md`
- 094. 094. Test-Environment Generation Equivalence — `components/094_Test-Environment_Generation_Equivalence.md`
- 095. 095. Candidate Convergence Comparison — `components/095_Candidate_Convergence_Comparison.md`
- 096. 096. JA21 Translation Equivalence — `components/096_JA21_Translation_Equivalence.md`
- 097. 097. Corpus-Gate Equivalence — `components/097_Corpus-Gate_Equivalence.md`
- 098. 098. Finalized-Repository Equivalence — `components/098_Finalized-Repository_Equivalence.md`
- 099. 099. Translated-Repository Equivalence — `components/099_Translated-Repository_Equivalence.md`
