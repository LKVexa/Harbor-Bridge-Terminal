# Phase 02 Component Index

- 012. 012. Residual Error Buffer — `components/012_Residual_Error_Buffer.md`
- 013. 013. Error-Feedback Injector — `components/013_Error-Feedback_Injector.md`
- 014. 014. Sender Error Compensator — `components/014_Sender_Error_Compensator.md`
- 015. 015. Aggregator Error Compensator — `components/015_Aggregator_Error_Compensator.md`
- 016. 016. 1-Bit Packet Packer — `components/016_1-Bit_Packet_Packer.md`
- 017. 017. SIMD Bit-Packing Engine — `components/017_SIMD_Bit-Packing_Engine.md`
- 018. 018. Communication Block Builder — `components/018_Communication_Block_Builder.md`
- 019. 019. Block Header — `components/019_Block_Header.md`
- 020. 020. Scale Sideband Channel — `components/020_Scale_Sideband_Channel.md`
- 021. 021. Sequence Counter — `components/021_Sequence_Counter.md`
- 022. 022. Block Integrity Check — `components/022_Block_Integrity_Check.md`
