# Phase 04 Component Index

- 034. 034. TCP Backend — `components/034_TCP_Backend.md`
- 035. 035. Named-Pipe Backend — `components/035_Named-Pipe_Backend.md`
- 036. 036. C# Communication Harness — `components/036_C_Communication_Harness.md`
- 037. 037. JA21 1-Bit Transport Interface — `components/037_JA21_1-Bit_Transport_Interface.md`
- 038. 038. QAM Communication Adapter — `components/038_QAM_Communication_Adapter.md`
- 039. 039. FXSpot Optimizer Adapter — `components/039_FXSpot_Optimizer_Adapter.md`
- 040. 040. Junkyard Chop Shop Adapter — `components/040_Junkyard_Chop_Shop_Adapter.md`
- 041. 041. Historical Scaling Average — `components/041_Historical_Scaling_Average.md`
- 042. 042. Frozen Reference Statistics — `components/042_Frozen_Reference_Statistics.md`
- 043. 043. Fresh Runtime Statistics — `components/043_Fresh_Runtime_Statistics.md`
- 044. 044. Reconstructed Signal Engine — `components/044_Reconstructed_Signal_Engine.md`
