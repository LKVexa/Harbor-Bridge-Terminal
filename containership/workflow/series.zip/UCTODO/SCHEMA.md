# Machine-readable records

**Schema: `UC/NESTED_TODO_PACK/2` · Pack 2.0.0**

All data files are UTF-8. JSONL means one independent JSON object per line, without a surrounding array. Files are plain data; no executable prompt, runtime call or external service is embedded.

## Child tasks — data/subtasks.jsonl

Exactly 96,000 records are ordered by original component, parent and child number.

| Field | Meaning |
|---|---|
| `id` | Stable child ID, such as `UC-M07.01-C006-T01` |
| `parent_id` | Original checklist ID, such as `UC-M07.01-C006` |
| `component_id` | Original component ID, such as `UC-M07.01` |
| `workstream` | Integer 1–12 inherited from the parent |
| `focus_number` | Integer 1–10 inherited from the parent |
| `kind` | Original check type; see the enumeration below |
| `number` | Child position 1–10 within this parent |
| `deliverable` | Short label describing this child's output or activity |
| `text` | Full proposed actionable to-do statement |
| `status` | Initial `TODO`; editable planning state |
| `owner` | Initially `null`; may be assigned a string |
| `evidence` | Initially `[]`; add nonsecret references and outcome records |
| `notes` | Initially an empty string; add blockers, scope rationale or decisions |

Allowed tracking states are `TODO`, `IN_PROGRESS`, `BLOCKED`, `DONE` and `NOT_APPLICABLE`. These are planning states, not automatically verified implementation claims. A `DONE` record should reference actual required outputs and evidence. `NOT_APPLICABLE` needs a profile rationale and cannot waive a selected mandatory requirement. The validator checks field shape and counts; it does not certify that those judgments are justified.

`kind` is one of `contract`, `delivery`, `invariant`, `integration`, `valid_case`, `negative_case`, `change_or_failure`, `bounds`, `diagnostics_or_review` or `evidence`.

## Original parents — data/parents.jsonl

The 9,600 source JSONL records are retained **byte-for-byte**. They carry the exact original parent text, ID, component ID, source focus title, kind, source assessment, priority, milestone and scope. Join a child to its parent by `parent_id = id`. Do not reinterpret source `PARTIAL`/`MISSING` as a new observation. Original parent status fields are source snapshots and should not be edited; child tracking does not synchronize them.

## Component manifest — data/manifest.json

The manifest records the pack version, unchanged runtime baseline, source hashes, expansion policy, counts and complete original component metadata. The original component array is unchanged, including all 960 focus definitions and 212 dependency edges. Join using `component_id` to `components[].id`. `components[].path` points to the new component Markdown file under the same short relative naming pattern; the original archive is separately retained.

`counts.subtasks` is 96,000; `counts.parent_checklist_items` is 9,600. Do not add repeated Markdown views to these logical counts. Initial status counts describe the shipped snapshot and do not automatically update after edits.

`expansion_policy.new_hard_dependencies` is false. Only the source component dependency graph is authoritative here. The child order is not a generated scheduler.

## Trace records — data/trace.jsonl

Exactly 9,600 records map each original parent to its ten children. Each record includes `parent_id`, `component_id`, `kind`, `focus_number`, the SHA-256 of the exact source parent text, `child_count`, first/last child IDs and the component Markdown path. The hash is over UTF-8 text without a newline. It provides content identity, not authority or a completion claim.

## Parallel views and editing

Component Markdown, [ALL.md](ALL.md) and child JSONL contain the same logical task IDs. [INDEX.md](INDEX.md) and workstream documents are navigation. [EXAMPLES.md](EXAMPLES.md) intentionally repeats selected parent expansions and is not an additional task set. Source snapshots contain the previous level of the hierarchy, not additional generated children.

No status synchronization is performed. `tools/show.py` reads JSONL only. Full release validation requires all original shipped bytes. Structure-only validation permits progress edits but still requires the parent text and child text/labels to agree across the working views. Source snapshots are immutable even in structure-only mode.
