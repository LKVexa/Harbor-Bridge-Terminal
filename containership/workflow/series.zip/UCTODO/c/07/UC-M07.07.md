# UC-M07.07 — Portable snapshots and state migrations

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/07.md)

| Field | Preserved source value |
|---|---|
| Workstream | 07. Persistence, transactions and recovery |
| Milestone | A |
| Priority | P1 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.08](../02/UC-M02.08.md), [UC-M06.07](../06/UC-M06.07.md), [UC-M07.02](../07/UC-M07.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S8]. |

## Original requirement

Define snapshot format, engine/ABI compatibility, encrypted secret handling and schema migration with validation before restore.

**Original acceptance criterion:** A snapshot restored on a supported clean host resumes with equivalent application state; incompatible ABI is refused.

**Source trace:** Original checklist `UC100/c/07/UC-M07.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 685–695 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Snapshot format

**Source delivery:** Define a versioned portable snapshot envelope and required contents.

**Source invariant:** A snapshot has explicit format and identity semantics.

**Source negative case:** A snapshot omits the format version and is guessed compatible.

**Source bounded quantities:** Envelope bytes and object count.

### UC-M07.07-C001 · Contract

**Original checklist item:** Specify snapshot format inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C001-T01 · Scope statement:** Draft the operation boundary for “Snapshot format” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Snapshot format”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C001-T03 · Output inventory:** List the outputs of “Snapshot format” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Snapshot format”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C001-T05 · Prerequisite contract:** Map “Snapshot format” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Snapshot format”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C001-T07 · Invariant clause:** Add a normative clause for “Snapshot format” that preserves “A snapshot has explicit format and identity semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Snapshot format”; include the source counterexample “A snapshot omits the format version and is guessed compatible” and the intended safe disposition.
- [ ] **UC-M07.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Envelope bytes and object count” in the “Snapshot format” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C001-T10 · Contract review:** Review the “Snapshot format” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C002 · Delivery

**Original checklist item:** Define a versioned portable snapshot envelope and required contents.

- [ ] **UC-M07.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Snapshot format”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C002-T02 · Change plan:** Break the source delivery for “Snapshot format” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C002-T03 · Core artifact:** Create the “Snapshot format” model, schema or inventory that realizes this source instruction: Define a versioned portable snapshot envelope and required contents.
- [ ] **UC-M07.07-C002-T04 · Concrete realization:** Populate “Snapshot format” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Snapshot format” needed to preserve “A snapshot has explicit format and identity semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C002-T06 · Dependency connection:** Connect the “Snapshot format” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C002-T07 · Resource behavior:** Account for “Envelope bytes and object count” in “Snapshot format”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C002-T08 · Delivery check:** Run the smallest real “Snapshot format” path and its adverse fixture “A snapshot omits the format version and is guessed compatible”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C002-T09 · Patch review:** Review the “Snapshot format” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C002-T10 · Delivery handoff:** Publish the “Snapshot format” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A snapshot has explicit format and identity semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Snapshot format”; copy its required invariant exactly: “A snapshot has explicit format and identity semantics”.
- [ ] **UC-M07.07-C003-T02 · Observable terms:** Define each term in the “Snapshot format” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C003-T03 · Precondition set:** List the preconditions under which “A snapshot has explicit format and identity semantics” must hold for “Snapshot format”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C003-T04 · Transition coverage:** Map the “Snapshot format” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Snapshot format”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C003-T06 · Satisfying fixture:** Create a concrete “Snapshot format” case that satisfies “A snapshot has explicit format and identity semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C003-T07 · Violating fixture:** Create the source counterexample “A snapshot omits the format version and is guessed compatible” for “Snapshot format”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C003-T08 · Enforcement evidence:** Exercise the “Snapshot format” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C003-T09 · Regression linkage:** Link the “Snapshot format” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Snapshot format” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C004 · Integration

**Original checklist item:** Integrate snapshot format with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Snapshot format” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C004-T02 · Field mapping:** Map every “Snapshot format” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Snapshot format” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C004-T04 · Ownership agreement:** Specify who owns “Snapshot format” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C004-T05 · Handoff implementation:** Connect “Snapshot format” through the mapped seam using the real adapter or explicit specification reference; preserve “A snapshot has explicit format and identity semantics” across the handoff.
- [ ] **UC-M07.07-C004-T06 · Absent-input case:** Omit one required “Snapshot format” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C004-T07 · Stale-input case:** Supply an outdated “Snapshot format” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Snapshot format” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C004-T09 · Valid integration trace:** Run a valid “Snapshot format” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C004-T10 · Seam review:** Reconcile the “Snapshot format” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for snapshot format; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Snapshot format” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C005-T02 · Expected-result oracle:** Specify the “Snapshot format” expected result independently of the implementation output; include the property “A snapshot has explicit format and identity semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C005-T03 · Fixture material:** Create the concrete “Snapshot format” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C005-T04 · Target preparation:** Prepare the “Snapshot format” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C005-T05 · Initial-state record:** Record the initial “Snapshot format” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C005-T06 · Valid-path execution:** Execute the “Snapshot format” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C005-T07 · Outcome comparison:** Compare every declared “Snapshot format” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C005-T08 · State and bounds check:** Inspect the “Snapshot format” ownership/state effects and actual use of “Envelope bytes and object count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C005-T09 · Repeatability check:** Repeat the same “Snapshot format” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C005-T10 · Positive evidence:** Attach the “Snapshot format” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C006 · Negative test

**Original checklist item:** Negative case: A snapshot omits the format version and is guessed compatible. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Snapshot format” source counterexample: “A snapshot omits the format version and is guessed compatible”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Snapshot format”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C006-T03 · Valid control:** Construct a valid “Snapshot format” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C006-T04 · Minimal adverse input:** Derive the “Snapshot format” adverse fixture from the control with the smallest documented change needed to reproduce “A snapshot omits the format version and is guessed compatible”; retain that change as reproducible data.
- [ ] **UC-M07.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Snapshot format”; require “A snapshot has explicit format and identity semantics” and forbid a false-success verdict.
- [ ] **UC-M07.07-C006-T06 · Adverse execution:** Exercise the “Snapshot format” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C006-T07 · Effect inspection:** Inspect “Snapshot format” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C006-T08 · Refusal versus failure:** Confirm the “Snapshot format” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C006-T09 · Reset and retention:** Restore only the disposable “Snapshot format” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C006-T10 · Negative regression:** Register the “Snapshot format” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C007 · Change / failure test

**Original checklist item:** Exercise snapshot format when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C007-T01 · Scenario record:** Write the “Snapshot format” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “A snapshot has explicit format and identity semantics”.
- [ ] **UC-M07.07-C007-T02 · Baseline capture:** Create a known-valid “Snapshot format” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C007-T03 · Injection map:** Locate the “Snapshot format” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Snapshot format” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C007-T05 · Controlled trigger:** Introduce the controlled “Snapshot format” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C007-T06 · Intermediate inspection:** Inspect the “Snapshot format” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Snapshot format”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Snapshot format” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C007-T09 · Repeat and compare:** Repeat the selected “Snapshot format” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C007-T10 · Failure evidence:** Publish the “Snapshot format” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for envelope bytes and object count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Snapshot format”: “Envelope bytes and object count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C008-T02 · Measurement method:** Choose how to observe each “Snapshot format” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Snapshot format”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Snapshot format” cases for “Envelope bytes and object count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Snapshot format” limit; preserve “A snapshot has explicit format and identity semantics”.
- [ ] **UC-M07.07-C008-T06 · Normal measurement:** Run or review the normal “Snapshot format” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C008-T07 · At-limit measurement:** Exercise the “Snapshot format” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C008-T08 · Over-limit measurement:** Exercise the “Snapshot format” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C008-T09 · Uncovered-scope report:** List the “Snapshot format” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C008-T10 · Limit evidence:** Publish the selected “Snapshot format” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for snapshot format with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C009-T01 · Event inventory:** List the “Snapshot format” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Snapshot format” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C009-T03 · Failure mapping:** Map each documented “Snapshot format” refusal or error to a diagnostic outcome; include “A snapshot omits the format version and is guessed compatible” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C009-T04 · Emission path:** Add the “Snapshot format” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C009-T05 · Redaction check:** Test “Snapshot format” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C009-T06 · Output budget:** Set and exercise bounded “Snapshot format” message size, rate and retention compatible with “Envelope bytes and object count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C009-T07 · Success/refusal fixtures:** Capture “Snapshot format” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Snapshot format” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C009-T09 · Operator review:** Read the “Snapshot format” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C009-T10 · Diagnostic evidence:** Publish redacted “Snapshot format” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for snapshot format; label unexecuted checks as untested.

- [ ] **UC-M07.07-C010-T01 · Evidence inventory:** List the “Snapshot format” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C010-T02 · Artifact references:** Record the exact “Snapshot format” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C010-T03 · Fixture references:** Attach the “Snapshot format” fixture IDs, input identities and oracle definition; preserve the source counterexample “A snapshot omits the format version and is guessed compatible” as a distinct evidence case.
- [ ] **UC-M07.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Snapshot format”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C010-T05 · Environment record:** Record the actual “Snapshot format” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C010-T06 · Expected versus observed:** Pair every “Snapshot format” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C010-T07 · Failure and limit records:** Attach “Snapshot format” change/failure and bounds evidence where required; include uncovered “Envelope bytes and object count” and unresolved violations of “A snapshot has explicit format and identity semantics”.
- [ ] **UC-M07.07-C010-T08 · Evidence hygiene:** Check the “Snapshot format” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C010-T09 · Reproduction review:** Have the “Snapshot format” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C010-T10 · Acceptance linkage:** Link the “Snapshot format” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Engine and ABI compatibility

**Source delivery:** Record and validate engine, image and ABI compatibility requirements.

**Source invariant:** An incompatible ABI is refused before guest execution.

**Source negative case:** A snapshot from an incompatible runtime is restored by name alone.

**Source bounded quantities:** Compatibility matrix and version span.

### UC-M07.07-C011 · Contract

**Original checklist item:** Specify engine and ABI compatibility inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C011-T01 · Scope statement:** Draft the operation boundary for “Engine and ABI compatibility” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Engine and ABI compatibility”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C011-T03 · Output inventory:** List the outputs of “Engine and ABI compatibility” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Engine and ABI compatibility”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C011-T05 · Prerequisite contract:** Map “Engine and ABI compatibility” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Engine and ABI compatibility”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C011-T07 · Invariant clause:** Add a normative clause for “Engine and ABI compatibility” that preserves “An incompatible ABI is refused before guest execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Engine and ABI compatibility”; include the source counterexample “A snapshot from an incompatible runtime is restored by name alone” and the intended safe disposition.
- [ ] **UC-M07.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Compatibility matrix and version span” in the “Engine and ABI compatibility” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C011-T10 · Contract review:** Review the “Engine and ABI compatibility” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C012 · Delivery

**Original checklist item:** Record and validate engine, image and ABI compatibility requirements.

- [ ] **UC-M07.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Engine and ABI compatibility”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C012-T02 · Change plan:** Break the source delivery for “Engine and ABI compatibility” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C012-T03 · Core artifact:** Create the “Engine and ABI compatibility” model, schema or inventory that realizes this source instruction: Record and validate engine, image and ABI compatibility requirements.
- [ ] **UC-M07.07-C012-T04 · Concrete realization:** Populate “Engine and ABI compatibility” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Engine and ABI compatibility” needed to preserve “An incompatible ABI is refused before guest execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C012-T06 · Dependency connection:** Connect the “Engine and ABI compatibility” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C012-T07 · Resource behavior:** Account for “Compatibility matrix and version span” in “Engine and ABI compatibility”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C012-T08 · Delivery check:** Run the smallest real “Engine and ABI compatibility” path and its adverse fixture “A snapshot from an incompatible runtime is restored by name alone”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C012-T09 · Patch review:** Review the “Engine and ABI compatibility” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C012-T10 · Delivery handoff:** Publish the “Engine and ABI compatibility” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An incompatible ABI is refused before guest execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Engine and ABI compatibility”; copy its required invariant exactly: “An incompatible ABI is refused before guest execution”.
- [ ] **UC-M07.07-C013-T02 · Observable terms:** Define each term in the “Engine and ABI compatibility” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C013-T03 · Precondition set:** List the preconditions under which “An incompatible ABI is refused before guest execution” must hold for “Engine and ABI compatibility”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C013-T04 · Transition coverage:** Map the “Engine and ABI compatibility” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Engine and ABI compatibility”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C013-T06 · Satisfying fixture:** Create a concrete “Engine and ABI compatibility” case that satisfies “An incompatible ABI is refused before guest execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C013-T07 · Violating fixture:** Create the source counterexample “A snapshot from an incompatible runtime is restored by name alone” for “Engine and ABI compatibility”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C013-T08 · Enforcement evidence:** Exercise the “Engine and ABI compatibility” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C013-T09 · Regression linkage:** Link the “Engine and ABI compatibility” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Engine and ABI compatibility” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C014 · Integration

**Original checklist item:** Integrate engine and ABI compatibility with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Engine and ABI compatibility” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C014-T02 · Field mapping:** Map every “Engine and ABI compatibility” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Engine and ABI compatibility” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C014-T04 · Ownership agreement:** Specify who owns “Engine and ABI compatibility” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C014-T05 · Handoff implementation:** Connect “Engine and ABI compatibility” through the mapped seam using the real adapter or explicit specification reference; preserve “An incompatible ABI is refused before guest execution” across the handoff.
- [ ] **UC-M07.07-C014-T06 · Absent-input case:** Omit one required “Engine and ABI compatibility” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C014-T07 · Stale-input case:** Supply an outdated “Engine and ABI compatibility” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Engine and ABI compatibility” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C014-T09 · Valid integration trace:** Run a valid “Engine and ABI compatibility” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C014-T10 · Seam review:** Reconcile the “Engine and ABI compatibility” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for engine and ABI compatibility; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Engine and ABI compatibility” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C015-T02 · Expected-result oracle:** Specify the “Engine and ABI compatibility” expected result independently of the implementation output; include the property “An incompatible ABI is refused before guest execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C015-T03 · Fixture material:** Create the concrete “Engine and ABI compatibility” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C015-T04 · Target preparation:** Prepare the “Engine and ABI compatibility” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C015-T05 · Initial-state record:** Record the initial “Engine and ABI compatibility” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C015-T06 · Valid-path execution:** Execute the “Engine and ABI compatibility” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C015-T07 · Outcome comparison:** Compare every declared “Engine and ABI compatibility” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C015-T08 · State and bounds check:** Inspect the “Engine and ABI compatibility” ownership/state effects and actual use of “Compatibility matrix and version span”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C015-T09 · Repeatability check:** Repeat the same “Engine and ABI compatibility” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C015-T10 · Positive evidence:** Attach the “Engine and ABI compatibility” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C016 · Negative test

**Original checklist item:** Negative case: A snapshot from an incompatible runtime is restored by name alone. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Engine and ABI compatibility” source counterexample: “A snapshot from an incompatible runtime is restored by name alone”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Engine and ABI compatibility”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C016-T03 · Valid control:** Construct a valid “Engine and ABI compatibility” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C016-T04 · Minimal adverse input:** Derive the “Engine and ABI compatibility” adverse fixture from the control with the smallest documented change needed to reproduce “A snapshot from an incompatible runtime is restored by name alone”; retain that change as reproducible data.
- [ ] **UC-M07.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Engine and ABI compatibility”; require “An incompatible ABI is refused before guest execution” and forbid a false-success verdict.
- [ ] **UC-M07.07-C016-T06 · Adverse execution:** Exercise the “Engine and ABI compatibility” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C016-T07 · Effect inspection:** Inspect “Engine and ABI compatibility” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C016-T08 · Refusal versus failure:** Confirm the “Engine and ABI compatibility” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C016-T09 · Reset and retention:** Restore only the disposable “Engine and ABI compatibility” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C016-T10 · Negative regression:** Register the “Engine and ABI compatibility” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C017 · Change / failure test

**Original checklist item:** Exercise engine and ABI compatibility when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C017-T01 · Scenario record:** Write the “Engine and ABI compatibility” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “An incompatible ABI is refused before guest execution”.
- [ ] **UC-M07.07-C017-T02 · Baseline capture:** Create a known-valid “Engine and ABI compatibility” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C017-T03 · Injection map:** Locate the “Engine and ABI compatibility” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Engine and ABI compatibility” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C017-T05 · Controlled trigger:** Introduce the controlled “Engine and ABI compatibility” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C017-T06 · Intermediate inspection:** Inspect the “Engine and ABI compatibility” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Engine and ABI compatibility”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Engine and ABI compatibility” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C017-T09 · Repeat and compare:** Repeat the selected “Engine and ABI compatibility” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C017-T10 · Failure evidence:** Publish the “Engine and ABI compatibility” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for compatibility matrix and version span; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Engine and ABI compatibility”: “Compatibility matrix and version span”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C018-T02 · Measurement method:** Choose how to observe each “Engine and ABI compatibility” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Engine and ABI compatibility”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Engine and ABI compatibility” cases for “Compatibility matrix and version span”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Engine and ABI compatibility” limit; preserve “An incompatible ABI is refused before guest execution”.
- [ ] **UC-M07.07-C018-T06 · Normal measurement:** Run or review the normal “Engine and ABI compatibility” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C018-T07 · At-limit measurement:** Exercise the “Engine and ABI compatibility” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C018-T08 · Over-limit measurement:** Exercise the “Engine and ABI compatibility” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C018-T09 · Uncovered-scope report:** List the “Engine and ABI compatibility” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C018-T10 · Limit evidence:** Publish the selected “Engine and ABI compatibility” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for engine and ABI compatibility with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C019-T01 · Event inventory:** List the “Engine and ABI compatibility” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Engine and ABI compatibility” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C019-T03 · Failure mapping:** Map each documented “Engine and ABI compatibility” refusal or error to a diagnostic outcome; include “A snapshot from an incompatible runtime is restored by name alone” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C019-T04 · Emission path:** Add the “Engine and ABI compatibility” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C019-T05 · Redaction check:** Test “Engine and ABI compatibility” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C019-T06 · Output budget:** Set and exercise bounded “Engine and ABI compatibility” message size, rate and retention compatible with “Compatibility matrix and version span”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C019-T07 · Success/refusal fixtures:** Capture “Engine and ABI compatibility” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Engine and ABI compatibility” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C019-T09 · Operator review:** Read the “Engine and ABI compatibility” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C019-T10 · Diagnostic evidence:** Publish redacted “Engine and ABI compatibility” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for engine and ABI compatibility; label unexecuted checks as untested.

- [ ] **UC-M07.07-C020-T01 · Evidence inventory:** List the “Engine and ABI compatibility” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C020-T02 · Artifact references:** Record the exact “Engine and ABI compatibility” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C020-T03 · Fixture references:** Attach the “Engine and ABI compatibility” fixture IDs, input identities and oracle definition; preserve the source counterexample “A snapshot from an incompatible runtime is restored by name alone” as a distinct evidence case.
- [ ] **UC-M07.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Engine and ABI compatibility”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C020-T05 · Environment record:** Record the actual “Engine and ABI compatibility” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C020-T06 · Expected versus observed:** Pair every “Engine and ABI compatibility” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C020-T07 · Failure and limit records:** Attach “Engine and ABI compatibility” change/failure and bounds evidence where required; include uncovered “Compatibility matrix and version span” and unresolved violations of “An incompatible ABI is refused before guest execution”.
- [ ] **UC-M07.07-C020-T08 · Evidence hygiene:** Check the “Engine and ABI compatibility” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C020-T09 · Reproduction review:** Have the “Engine and ABI compatibility” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C020-T10 · Acceptance linkage:** Link the “Engine and ABI compatibility” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Application-state completeness

**Source delivery:** Capture all state required by the declared application restore semantics.

**Source invariant:** Portable restore does not depend on undeclared local workspace files.

**Source negative case:** A clean host lacks a hidden file required to resume the snapshot.

**Source bounded quantities:** State bytes and dependency count.

### UC-M07.07-C021 · Contract

**Original checklist item:** Specify application-state completeness inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C021-T01 · Scope statement:** Draft the operation boundary for “Application-state completeness” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Application-state completeness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C021-T03 · Output inventory:** List the outputs of “Application-state completeness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Application-state completeness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C021-T05 · Prerequisite contract:** Map “Application-state completeness” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Application-state completeness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C021-T07 · Invariant clause:** Add a normative clause for “Application-state completeness” that preserves “Portable restore does not depend on undeclared local workspace files”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Application-state completeness”; include the source counterexample “A clean host lacks a hidden file required to resume the snapshot” and the intended safe disposition.
- [ ] **UC-M07.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “State bytes and dependency count” in the “Application-state completeness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C021-T10 · Contract review:** Review the “Application-state completeness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C022 · Delivery

**Original checklist item:** Capture all state required by the declared application restore semantics.

- [ ] **UC-M07.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Application-state completeness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C022-T02 · Change plan:** Break the source delivery for “Application-state completeness” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C022-T03 · Core artifact:** Create the “Application-state completeness” output artifact for this source instruction: Capture all state required by the declared application restore semantics.
- [ ] **UC-M07.07-C022-T04 · Concrete realization:** Populate the “Application-state completeness” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M07.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Application-state completeness” needed to preserve “Portable restore does not depend on undeclared local workspace files”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C022-T06 · Dependency connection:** Connect the “Application-state completeness” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C022-T07 · Resource behavior:** Account for “State bytes and dependency count” in “Application-state completeness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C022-T08 · Delivery check:** Run the smallest real “Application-state completeness” path and its adverse fixture “A clean host lacks a hidden file required to resume the snapshot”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C022-T09 · Patch review:** Review the “Application-state completeness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C022-T10 · Delivery handoff:** Publish the “Application-state completeness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Portable restore does not depend on undeclared local workspace files. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Application-state completeness”; copy its required invariant exactly: “Portable restore does not depend on undeclared local workspace files”.
- [ ] **UC-M07.07-C023-T02 · Observable terms:** Define each term in the “Application-state completeness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C023-T03 · Precondition set:** List the preconditions under which “Portable restore does not depend on undeclared local workspace files” must hold for “Application-state completeness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C023-T04 · Transition coverage:** Map the “Application-state completeness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Application-state completeness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C023-T06 · Satisfying fixture:** Create a concrete “Application-state completeness” case that satisfies “Portable restore does not depend on undeclared local workspace files”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C023-T07 · Violating fixture:** Create the source counterexample “A clean host lacks a hidden file required to resume the snapshot” for “Application-state completeness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C023-T08 · Enforcement evidence:** Exercise the “Application-state completeness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C023-T09 · Regression linkage:** Link the “Application-state completeness” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Application-state completeness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C024 · Integration

**Original checklist item:** Integrate application-state completeness with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Application-state completeness” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C024-T02 · Field mapping:** Map every “Application-state completeness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Application-state completeness” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C024-T04 · Ownership agreement:** Specify who owns “Application-state completeness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C024-T05 · Handoff implementation:** Connect “Application-state completeness” through the mapped seam using the real adapter or explicit specification reference; preserve “Portable restore does not depend on undeclared local workspace files” across the handoff.
- [ ] **UC-M07.07-C024-T06 · Absent-input case:** Omit one required “Application-state completeness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C024-T07 · Stale-input case:** Supply an outdated “Application-state completeness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Application-state completeness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C024-T09 · Valid integration trace:** Run a valid “Application-state completeness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C024-T10 · Seam review:** Reconcile the “Application-state completeness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for application-state completeness; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Application-state completeness” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C025-T02 · Expected-result oracle:** Specify the “Application-state completeness” expected result independently of the implementation output; include the property “Portable restore does not depend on undeclared local workspace files” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C025-T03 · Fixture material:** Create the concrete “Application-state completeness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C025-T04 · Target preparation:** Prepare the “Application-state completeness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C025-T05 · Initial-state record:** Record the initial “Application-state completeness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C025-T06 · Valid-path execution:** Execute the “Application-state completeness” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C025-T07 · Outcome comparison:** Compare every declared “Application-state completeness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C025-T08 · State and bounds check:** Inspect the “Application-state completeness” ownership/state effects and actual use of “State bytes and dependency count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C025-T09 · Repeatability check:** Repeat the same “Application-state completeness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C025-T10 · Positive evidence:** Attach the “Application-state completeness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C026 · Negative test

**Original checklist item:** Negative case: A clean host lacks a hidden file required to resume the snapshot. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Application-state completeness” source counterexample: “A clean host lacks a hidden file required to resume the snapshot”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Application-state completeness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C026-T03 · Valid control:** Construct a valid “Application-state completeness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C026-T04 · Minimal adverse input:** Derive the “Application-state completeness” adverse fixture from the control with the smallest documented change needed to reproduce “A clean host lacks a hidden file required to resume the snapshot”; retain that change as reproducible data.
- [ ] **UC-M07.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Application-state completeness”; require “Portable restore does not depend on undeclared local workspace files” and forbid a false-success verdict.
- [ ] **UC-M07.07-C026-T06 · Adverse execution:** Exercise the “Application-state completeness” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C026-T07 · Effect inspection:** Inspect “Application-state completeness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C026-T08 · Refusal versus failure:** Confirm the “Application-state completeness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C026-T09 · Reset and retention:** Restore only the disposable “Application-state completeness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C026-T10 · Negative regression:** Register the “Application-state completeness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C027 · Change / failure test

**Original checklist item:** Exercise application-state completeness when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C027-T01 · Scenario record:** Write the “Application-state completeness” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “Portable restore does not depend on undeclared local workspace files”.
- [ ] **UC-M07.07-C027-T02 · Baseline capture:** Create a known-valid “Application-state completeness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C027-T03 · Injection map:** Locate the “Application-state completeness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Application-state completeness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C027-T05 · Controlled trigger:** Introduce the controlled “Application-state completeness” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C027-T06 · Intermediate inspection:** Inspect the “Application-state completeness” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Application-state completeness”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Application-state completeness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C027-T09 · Repeat and compare:** Repeat the selected “Application-state completeness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C027-T10 · Failure evidence:** Publish the “Application-state completeness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for state bytes and dependency count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Application-state completeness”: “State bytes and dependency count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C028-T02 · Measurement method:** Choose how to observe each “Application-state completeness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Application-state completeness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Application-state completeness” cases for “State bytes and dependency count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Application-state completeness” limit; preserve “Portable restore does not depend on undeclared local workspace files”.
- [ ] **UC-M07.07-C028-T06 · Normal measurement:** Run or review the normal “Application-state completeness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C028-T07 · At-limit measurement:** Exercise the “Application-state completeness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C028-T08 · Over-limit measurement:** Exercise the “Application-state completeness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C028-T09 · Uncovered-scope report:** List the “Application-state completeness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C028-T10 · Limit evidence:** Publish the selected “Application-state completeness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for application-state completeness with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C029-T01 · Event inventory:** List the “Application-state completeness” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Application-state completeness” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C029-T03 · Failure mapping:** Map each documented “Application-state completeness” refusal or error to a diagnostic outcome; include “A clean host lacks a hidden file required to resume the snapshot” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C029-T04 · Emission path:** Add the “Application-state completeness” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C029-T05 · Redaction check:** Test “Application-state completeness” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C029-T06 · Output budget:** Set and exercise bounded “Application-state completeness” message size, rate and retention compatible with “State bytes and dependency count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C029-T07 · Success/refusal fixtures:** Capture “Application-state completeness” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Application-state completeness” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C029-T09 · Operator review:** Read the “Application-state completeness” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C029-T10 · Diagnostic evidence:** Publish redacted “Application-state completeness” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for application-state completeness; label unexecuted checks as untested.

- [ ] **UC-M07.07-C030-T01 · Evidence inventory:** List the “Application-state completeness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C030-T02 · Artifact references:** Record the exact “Application-state completeness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C030-T03 · Fixture references:** Attach the “Application-state completeness” fixture IDs, input identities and oracle definition; preserve the source counterexample “A clean host lacks a hidden file required to resume the snapshot” as a distinct evidence case.
- [ ] **UC-M07.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Application-state completeness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C030-T05 · Environment record:** Record the actual “Application-state completeness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C030-T06 · Expected versus observed:** Pair every “Application-state completeness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C030-T07 · Failure and limit records:** Attach “Application-state completeness” change/failure and bounds evidence where required; include uncovered “State bytes and dependency count” and unresolved violations of “Portable restore does not depend on undeclared local workspace files”.
- [ ] **UC-M07.07-C030-T08 · Evidence hygiene:** Check the “Application-state completeness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C030-T09 · Reproduction review:** Have the “Application-state completeness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C030-T10 · Acceptance linkage:** Link the “Application-state completeness” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Secret handling policy

**Source delivery:** Specify encrypted or externally referenced secret treatment compatible with the secret boundary.

**Source invariant:** Portable snapshots do not export live secrets as ordinary plaintext.

**Source negative case:** A snapshot packages a runtime credential in its metadata.

**Source bounded quantities:** Sensitive fields and protected payload bytes.

### UC-M07.07-C031 · Contract

**Original checklist item:** Specify secret handling policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C031-T01 · Scope statement:** Draft the operation boundary for “Secret handling policy” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Secret handling policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C031-T03 · Output inventory:** List the outputs of “Secret handling policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Secret handling policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C031-T05 · Prerequisite contract:** Map “Secret handling policy” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Secret handling policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C031-T07 · Invariant clause:** Add a normative clause for “Secret handling policy” that preserves “Portable snapshots do not export live secrets as ordinary plaintext”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Secret handling policy”; include the source counterexample “A snapshot packages a runtime credential in its metadata” and the intended safe disposition.
- [ ] **UC-M07.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Sensitive fields and protected payload bytes” in the “Secret handling policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C031-T10 · Contract review:** Review the “Secret handling policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C032 · Delivery

**Original checklist item:** Specify encrypted or externally referenced secret treatment compatible with the secret boundary.

- [ ] **UC-M07.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Secret handling policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C032-T02 · Change plan:** Break the source delivery for “Secret handling policy” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C032-T03 · Core artifact:** Create the “Secret handling policy” model, schema or inventory that realizes this source instruction: Specify encrypted or externally referenced secret treatment compatible with the secret boundary.
- [ ] **UC-M07.07-C032-T04 · Concrete realization:** Populate “Secret handling policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Secret handling policy” needed to preserve “Portable snapshots do not export live secrets as ordinary plaintext”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C032-T06 · Dependency connection:** Connect the “Secret handling policy” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C032-T07 · Resource behavior:** Account for “Sensitive fields and protected payload bytes” in “Secret handling policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C032-T08 · Delivery check:** Run the smallest real “Secret handling policy” path and its adverse fixture “A snapshot packages a runtime credential in its metadata”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C032-T09 · Patch review:** Review the “Secret handling policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C032-T10 · Delivery handoff:** Publish the “Secret handling policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Portable snapshots do not export live secrets as ordinary plaintext. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Secret handling policy”; copy its required invariant exactly: “Portable snapshots do not export live secrets as ordinary plaintext”.
- [ ] **UC-M07.07-C033-T02 · Observable terms:** Define each term in the “Secret handling policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C033-T03 · Precondition set:** List the preconditions under which “Portable snapshots do not export live secrets as ordinary plaintext” must hold for “Secret handling policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C033-T04 · Transition coverage:** Map the “Secret handling policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Secret handling policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C033-T06 · Satisfying fixture:** Create a concrete “Secret handling policy” case that satisfies “Portable snapshots do not export live secrets as ordinary plaintext”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C033-T07 · Violating fixture:** Create the source counterexample “A snapshot packages a runtime credential in its metadata” for “Secret handling policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C033-T08 · Enforcement evidence:** Exercise the “Secret handling policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C033-T09 · Regression linkage:** Link the “Secret handling policy” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Secret handling policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C034 · Integration

**Original checklist item:** Integrate secret handling policy with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Secret handling policy” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C034-T02 · Field mapping:** Map every “Secret handling policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Secret handling policy” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C034-T04 · Ownership agreement:** Specify who owns “Secret handling policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C034-T05 · Handoff implementation:** Connect “Secret handling policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Portable snapshots do not export live secrets as ordinary plaintext” across the handoff.
- [ ] **UC-M07.07-C034-T06 · Absent-input case:** Omit one required “Secret handling policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C034-T07 · Stale-input case:** Supply an outdated “Secret handling policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Secret handling policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C034-T09 · Valid integration trace:** Run a valid “Secret handling policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C034-T10 · Seam review:** Reconcile the “Secret handling policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for secret handling policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Secret handling policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C035-T02 · Expected-result oracle:** Specify the “Secret handling policy” expected result independently of the implementation output; include the property “Portable snapshots do not export live secrets as ordinary plaintext” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C035-T03 · Fixture material:** Create the concrete “Secret handling policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C035-T04 · Target preparation:** Prepare the “Secret handling policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C035-T05 · Initial-state record:** Record the initial “Secret handling policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C035-T06 · Valid-path execution:** Execute the “Secret handling policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C035-T07 · Outcome comparison:** Compare every declared “Secret handling policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C035-T08 · State and bounds check:** Inspect the “Secret handling policy” ownership/state effects and actual use of “Sensitive fields and protected payload bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C035-T09 · Repeatability check:** Repeat the same “Secret handling policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C035-T10 · Positive evidence:** Attach the “Secret handling policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C036 · Negative test

**Original checklist item:** Negative case: A snapshot packages a runtime credential in its metadata. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Secret handling policy” source counterexample: “A snapshot packages a runtime credential in its metadata”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Secret handling policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C036-T03 · Valid control:** Construct a valid “Secret handling policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C036-T04 · Minimal adverse input:** Derive the “Secret handling policy” adverse fixture from the control with the smallest documented change needed to reproduce “A snapshot packages a runtime credential in its metadata”; retain that change as reproducible data.
- [ ] **UC-M07.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Secret handling policy”; require “Portable snapshots do not export live secrets as ordinary plaintext” and forbid a false-success verdict.
- [ ] **UC-M07.07-C036-T06 · Adverse execution:** Exercise the “Secret handling policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C036-T07 · Effect inspection:** Inspect “Secret handling policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C036-T08 · Refusal versus failure:** Confirm the “Secret handling policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C036-T09 · Reset and retention:** Restore only the disposable “Secret handling policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C036-T10 · Negative regression:** Register the “Secret handling policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C037 · Change / failure test

**Original checklist item:** Exercise secret handling policy when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C037-T01 · Scenario record:** Write the “Secret handling policy” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “Portable snapshots do not export live secrets as ordinary plaintext”.
- [ ] **UC-M07.07-C037-T02 · Baseline capture:** Create a known-valid “Secret handling policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C037-T03 · Injection map:** Locate the “Secret handling policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Secret handling policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C037-T05 · Controlled trigger:** Introduce the controlled “Secret handling policy” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C037-T06 · Intermediate inspection:** Inspect the “Secret handling policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Secret handling policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Secret handling policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C037-T09 · Repeat and compare:** Repeat the selected “Secret handling policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C037-T10 · Failure evidence:** Publish the “Secret handling policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for sensitive fields and protected payload bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Secret handling policy”: “Sensitive fields and protected payload bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C038-T02 · Measurement method:** Choose how to observe each “Secret handling policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Secret handling policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Secret handling policy” cases for “Sensitive fields and protected payload bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Secret handling policy” limit; preserve “Portable snapshots do not export live secrets as ordinary plaintext”.
- [ ] **UC-M07.07-C038-T06 · Normal measurement:** Run or review the normal “Secret handling policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C038-T07 · At-limit measurement:** Exercise the “Secret handling policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C038-T08 · Over-limit measurement:** Exercise the “Secret handling policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C038-T09 · Uncovered-scope report:** List the “Secret handling policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C038-T10 · Limit evidence:** Publish the selected “Secret handling policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for secret handling policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C039-T01 · Event inventory:** List the “Secret handling policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Secret handling policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C039-T03 · Failure mapping:** Map each documented “Secret handling policy” refusal or error to a diagnostic outcome; include “A snapshot packages a runtime credential in its metadata” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C039-T04 · Emission path:** Add the “Secret handling policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C039-T05 · Redaction check:** Test “Secret handling policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C039-T06 · Output budget:** Set and exercise bounded “Secret handling policy” message size, rate and retention compatible with “Sensitive fields and protected payload bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C039-T07 · Success/refusal fixtures:** Capture “Secret handling policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Secret handling policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C039-T09 · Operator review:** Read the “Secret handling policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C039-T10 · Diagnostic evidence:** Publish redacted “Secret handling policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for secret handling policy; label unexecuted checks as untested.

- [ ] **UC-M07.07-C040-T01 · Evidence inventory:** List the “Secret handling policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C040-T02 · Artifact references:** Record the exact “Secret handling policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C040-T03 · Fixture references:** Attach the “Secret handling policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A snapshot packages a runtime credential in its metadata” as a distinct evidence case.
- [ ] **UC-M07.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Secret handling policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C040-T05 · Environment record:** Record the actual “Secret handling policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C040-T06 · Expected versus observed:** Pair every “Secret handling policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C040-T07 · Failure and limit records:** Attach “Secret handling policy” change/failure and bounds evidence where required; include uncovered “Sensitive fields and protected payload bytes” and unresolved violations of “Portable snapshots do not export live secrets as ordinary plaintext”.
- [ ] **UC-M07.07-C040-T08 · Evidence hygiene:** Check the “Secret handling policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C040-T09 · Reproduction review:** Have the “Secret handling policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C040-T10 · Acceptance linkage:** Link the “Secret handling policy” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Snapshot integrity

**Source delivery:** Verify object digests and structural relationships before restore.

**Source invariant:** Corrupt snapshot members cannot be accepted from matching filenames.

**Source negative case:** A history segment is altered inside a snapshot package.

**Source bounded quantities:** Package bytes and verification time.

### UC-M07.07-C041 · Contract

**Original checklist item:** Specify snapshot integrity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C041-T01 · Scope statement:** Draft the operation boundary for “Snapshot integrity” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Snapshot integrity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C041-T03 · Output inventory:** List the outputs of “Snapshot integrity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Snapshot integrity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C041-T05 · Prerequisite contract:** Map “Snapshot integrity” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Snapshot integrity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C041-T07 · Invariant clause:** Add a normative clause for “Snapshot integrity” that preserves “Corrupt snapshot members cannot be accepted from matching filenames”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Snapshot integrity”; include the source counterexample “A history segment is altered inside a snapshot package” and the intended safe disposition.
- [ ] **UC-M07.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Package bytes and verification time” in the “Snapshot integrity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C041-T10 · Contract review:** Review the “Snapshot integrity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C042 · Delivery

**Original checklist item:** Verify object digests and structural relationships before restore.

- [ ] **UC-M07.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Snapshot integrity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C042-T02 · Change plan:** Break the source delivery for “Snapshot integrity” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C042-T03 · Core artifact:** Create the “Snapshot integrity” fixture or harness for this source instruction: Verify object digests and structural relationships before restore.
- [ ] **UC-M07.07-C042-T04 · Concrete realization:** Connect the “Snapshot integrity” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Snapshot integrity” needed to preserve “Corrupt snapshot members cannot be accepted from matching filenames”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C042-T06 · Dependency connection:** Connect the “Snapshot integrity” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C042-T07 · Resource behavior:** Account for “Package bytes and verification time” in “Snapshot integrity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C042-T08 · Delivery check:** Run the smallest real “Snapshot integrity” path and its adverse fixture “A history segment is altered inside a snapshot package”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C042-T09 · Patch review:** Review the “Snapshot integrity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C042-T10 · Delivery handoff:** Publish the “Snapshot integrity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Corrupt snapshot members cannot be accepted from matching filenames. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Snapshot integrity”; copy its required invariant exactly: “Corrupt snapshot members cannot be accepted from matching filenames”.
- [ ] **UC-M07.07-C043-T02 · Observable terms:** Define each term in the “Snapshot integrity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C043-T03 · Precondition set:** List the preconditions under which “Corrupt snapshot members cannot be accepted from matching filenames” must hold for “Snapshot integrity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C043-T04 · Transition coverage:** Map the “Snapshot integrity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Snapshot integrity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C043-T06 · Satisfying fixture:** Create a concrete “Snapshot integrity” case that satisfies “Corrupt snapshot members cannot be accepted from matching filenames”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C043-T07 · Violating fixture:** Create the source counterexample “A history segment is altered inside a snapshot package” for “Snapshot integrity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C043-T08 · Enforcement evidence:** Exercise the “Snapshot integrity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C043-T09 · Regression linkage:** Link the “Snapshot integrity” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Snapshot integrity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C044 · Integration

**Original checklist item:** Integrate snapshot integrity with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Snapshot integrity” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C044-T02 · Field mapping:** Map every “Snapshot integrity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Snapshot integrity” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C044-T04 · Ownership agreement:** Specify who owns “Snapshot integrity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C044-T05 · Handoff implementation:** Connect “Snapshot integrity” through the mapped seam using the real adapter or explicit specification reference; preserve “Corrupt snapshot members cannot be accepted from matching filenames” across the handoff.
- [ ] **UC-M07.07-C044-T06 · Absent-input case:** Omit one required “Snapshot integrity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C044-T07 · Stale-input case:** Supply an outdated “Snapshot integrity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Snapshot integrity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C044-T09 · Valid integration trace:** Run a valid “Snapshot integrity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C044-T10 · Seam review:** Reconcile the “Snapshot integrity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for snapshot integrity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Snapshot integrity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C045-T02 · Expected-result oracle:** Specify the “Snapshot integrity” expected result independently of the implementation output; include the property “Corrupt snapshot members cannot be accepted from matching filenames” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C045-T03 · Fixture material:** Create the concrete “Snapshot integrity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C045-T04 · Target preparation:** Prepare the “Snapshot integrity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C045-T05 · Initial-state record:** Record the initial “Snapshot integrity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C045-T06 · Valid-path execution:** Execute the “Snapshot integrity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C045-T07 · Outcome comparison:** Compare every declared “Snapshot integrity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C045-T08 · State and bounds check:** Inspect the “Snapshot integrity” ownership/state effects and actual use of “Package bytes and verification time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C045-T09 · Repeatability check:** Repeat the same “Snapshot integrity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C045-T10 · Positive evidence:** Attach the “Snapshot integrity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C046 · Negative test

**Original checklist item:** Negative case: A history segment is altered inside a snapshot package. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Snapshot integrity” source counterexample: “A history segment is altered inside a snapshot package”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Snapshot integrity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C046-T03 · Valid control:** Construct a valid “Snapshot integrity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C046-T04 · Minimal adverse input:** Derive the “Snapshot integrity” adverse fixture from the control with the smallest documented change needed to reproduce “A history segment is altered inside a snapshot package”; retain that change as reproducible data.
- [ ] **UC-M07.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Snapshot integrity”; require “Corrupt snapshot members cannot be accepted from matching filenames” and forbid a false-success verdict.
- [ ] **UC-M07.07-C046-T06 · Adverse execution:** Exercise the “Snapshot integrity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C046-T07 · Effect inspection:** Inspect “Snapshot integrity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C046-T08 · Refusal versus failure:** Confirm the “Snapshot integrity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C046-T09 · Reset and retention:** Restore only the disposable “Snapshot integrity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C046-T10 · Negative regression:** Register the “Snapshot integrity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C047 · Change / failure test

**Original checklist item:** Exercise snapshot integrity when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C047-T01 · Scenario record:** Write the “Snapshot integrity” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “Corrupt snapshot members cannot be accepted from matching filenames”.
- [ ] **UC-M07.07-C047-T02 · Baseline capture:** Create a known-valid “Snapshot integrity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C047-T03 · Injection map:** Locate the “Snapshot integrity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Snapshot integrity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C047-T05 · Controlled trigger:** Introduce the controlled “Snapshot integrity” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C047-T06 · Intermediate inspection:** Inspect the “Snapshot integrity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Snapshot integrity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Snapshot integrity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C047-T09 · Repeat and compare:** Repeat the selected “Snapshot integrity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C047-T10 · Failure evidence:** Publish the “Snapshot integrity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for package bytes and verification time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Snapshot integrity”: “Package bytes and verification time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C048-T02 · Measurement method:** Choose how to observe each “Snapshot integrity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Snapshot integrity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Snapshot integrity” cases for “Package bytes and verification time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Snapshot integrity” limit; preserve “Corrupt snapshot members cannot be accepted from matching filenames”.
- [ ] **UC-M07.07-C048-T06 · Normal measurement:** Run or review the normal “Snapshot integrity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C048-T07 · At-limit measurement:** Exercise the “Snapshot integrity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C048-T08 · Over-limit measurement:** Exercise the “Snapshot integrity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C048-T09 · Uncovered-scope report:** List the “Snapshot integrity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C048-T10 · Limit evidence:** Publish the selected “Snapshot integrity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for snapshot integrity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C049-T01 · Event inventory:** List the “Snapshot integrity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Snapshot integrity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C049-T03 · Failure mapping:** Map each documented “Snapshot integrity” refusal or error to a diagnostic outcome; include “A history segment is altered inside a snapshot package” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C049-T04 · Emission path:** Add the “Snapshot integrity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C049-T05 · Redaction check:** Test “Snapshot integrity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C049-T06 · Output budget:** Set and exercise bounded “Snapshot integrity” message size, rate and retention compatible with “Package bytes and verification time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C049-T07 · Success/refusal fixtures:** Capture “Snapshot integrity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Snapshot integrity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C049-T09 · Operator review:** Read the “Snapshot integrity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C049-T10 · Diagnostic evidence:** Publish redacted “Snapshot integrity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for snapshot integrity; label unexecuted checks as untested.

- [ ] **UC-M07.07-C050-T01 · Evidence inventory:** List the “Snapshot integrity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C050-T02 · Artifact references:** Record the exact “Snapshot integrity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C050-T03 · Fixture references:** Attach the “Snapshot integrity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A history segment is altered inside a snapshot package” as a distinct evidence case.
- [ ] **UC-M07.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Snapshot integrity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C050-T05 · Environment record:** Record the actual “Snapshot integrity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C050-T06 · Expected versus observed:** Pair every “Snapshot integrity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C050-T07 · Failure and limit records:** Attach “Snapshot integrity” change/failure and bounds evidence where required; include uncovered “Package bytes and verification time” and unresolved violations of “Corrupt snapshot members cannot be accepted from matching filenames”.
- [ ] **UC-M07.07-C050-T08 · Evidence hygiene:** Check the “Snapshot integrity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C050-T09 · Reproduction review:** Have the “Snapshot integrity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C050-T10 · Acceptance linkage:** Link the “Snapshot integrity” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Schema migration

**Source delivery:** Apply supported explicit state migrations before publishing a restored generation.

**Source invariant:** Migration preserves declared state semantics or fails safely.

**Source negative case:** A migration silently drops a field required by the application.

**Source bounded quantities:** Migration steps and temporary storage.

### UC-M07.07-C051 · Contract

**Original checklist item:** Specify schema migration inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C051-T01 · Scope statement:** Draft the operation boundary for “Schema migration” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Schema migration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C051-T03 · Output inventory:** List the outputs of “Schema migration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Schema migration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C051-T05 · Prerequisite contract:** Map “Schema migration” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Schema migration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C051-T07 · Invariant clause:** Add a normative clause for “Schema migration” that preserves “Migration preserves declared state semantics or fails safely”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Schema migration”; include the source counterexample “A migration silently drops a field required by the application” and the intended safe disposition.
- [ ] **UC-M07.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Migration steps and temporary storage” in the “Schema migration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C051-T10 · Contract review:** Review the “Schema migration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C052 · Delivery

**Original checklist item:** Apply supported explicit state migrations before publishing a restored generation.

- [ ] **UC-M07.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Schema migration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C052-T02 · Change plan:** Break the source delivery for “Schema migration” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Schema migration” that realizes this source instruction: Apply supported explicit state migrations before publishing a restored generation.
- [ ] **UC-M07.07-C052-T04 · Concrete realization:** Trace “Schema migration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Schema migration” needed to preserve “Migration preserves declared state semantics or fails safely”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C052-T06 · Dependency connection:** Connect the “Schema migration” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C052-T07 · Resource behavior:** Account for “Migration steps and temporary storage” in “Schema migration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C052-T08 · Delivery check:** Run the smallest real “Schema migration” path and its adverse fixture “A migration silently drops a field required by the application”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C052-T09 · Patch review:** Review the “Schema migration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C052-T10 · Delivery handoff:** Publish the “Schema migration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Migration preserves declared state semantics or fails safely. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Schema migration”; copy its required invariant exactly: “Migration preserves declared state semantics or fails safely”.
- [ ] **UC-M07.07-C053-T02 · Observable terms:** Define each term in the “Schema migration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C053-T03 · Precondition set:** List the preconditions under which “Migration preserves declared state semantics or fails safely” must hold for “Schema migration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C053-T04 · Transition coverage:** Map the “Schema migration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Schema migration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C053-T06 · Satisfying fixture:** Create a concrete “Schema migration” case that satisfies “Migration preserves declared state semantics or fails safely”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C053-T07 · Violating fixture:** Create the source counterexample “A migration silently drops a field required by the application” for “Schema migration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C053-T08 · Enforcement evidence:** Exercise the “Schema migration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C053-T09 · Regression linkage:** Link the “Schema migration” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Schema migration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C054 · Integration

**Original checklist item:** Integrate schema migration with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Schema migration” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C054-T02 · Field mapping:** Map every “Schema migration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Schema migration” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C054-T04 · Ownership agreement:** Specify who owns “Schema migration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C054-T05 · Handoff implementation:** Connect “Schema migration” through the mapped seam using the real adapter or explicit specification reference; preserve “Migration preserves declared state semantics or fails safely” across the handoff.
- [ ] **UC-M07.07-C054-T06 · Absent-input case:** Omit one required “Schema migration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C054-T07 · Stale-input case:** Supply an outdated “Schema migration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Schema migration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C054-T09 · Valid integration trace:** Run a valid “Schema migration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C054-T10 · Seam review:** Reconcile the “Schema migration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for schema migration; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Schema migration” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C055-T02 · Expected-result oracle:** Specify the “Schema migration” expected result independently of the implementation output; include the property “Migration preserves declared state semantics or fails safely” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C055-T03 · Fixture material:** Create the concrete “Schema migration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C055-T04 · Target preparation:** Prepare the “Schema migration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C055-T05 · Initial-state record:** Record the initial “Schema migration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C055-T06 · Valid-path execution:** Execute the “Schema migration” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C055-T07 · Outcome comparison:** Compare every declared “Schema migration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C055-T08 · State and bounds check:** Inspect the “Schema migration” ownership/state effects and actual use of “Migration steps and temporary storage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C055-T09 · Repeatability check:** Repeat the same “Schema migration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C055-T10 · Positive evidence:** Attach the “Schema migration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C056 · Negative test

**Original checklist item:** Negative case: A migration silently drops a field required by the application. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Schema migration” source counterexample: “A migration silently drops a field required by the application”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Schema migration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C056-T03 · Valid control:** Construct a valid “Schema migration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C056-T04 · Minimal adverse input:** Derive the “Schema migration” adverse fixture from the control with the smallest documented change needed to reproduce “A migration silently drops a field required by the application”; retain that change as reproducible data.
- [ ] **UC-M07.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Schema migration”; require “Migration preserves declared state semantics or fails safely” and forbid a false-success verdict.
- [ ] **UC-M07.07-C056-T06 · Adverse execution:** Exercise the “Schema migration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C056-T07 · Effect inspection:** Inspect “Schema migration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C056-T08 · Refusal versus failure:** Confirm the “Schema migration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C056-T09 · Reset and retention:** Restore only the disposable “Schema migration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C056-T10 · Negative regression:** Register the “Schema migration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C057 · Change / failure test

**Original checklist item:** Exercise schema migration when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C057-T01 · Scenario record:** Write the “Schema migration” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “Migration preserves declared state semantics or fails safely”.
- [ ] **UC-M07.07-C057-T02 · Baseline capture:** Create a known-valid “Schema migration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C057-T03 · Injection map:** Locate the “Schema migration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Schema migration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C057-T05 · Controlled trigger:** Introduce the controlled “Schema migration” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C057-T06 · Intermediate inspection:** Inspect the “Schema migration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Schema migration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Schema migration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C057-T09 · Repeat and compare:** Repeat the selected “Schema migration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C057-T10 · Failure evidence:** Publish the “Schema migration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for migration steps and temporary storage; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Schema migration”: “Migration steps and temporary storage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C058-T02 · Measurement method:** Choose how to observe each “Schema migration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C058-T03 · Budget decision:** Select justified resource and input limits for “Schema migration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Schema migration” cases for “Migration steps and temporary storage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Schema migration” limit; preserve “Migration preserves declared state semantics or fails safely”.
- [ ] **UC-M07.07-C058-T06 · Normal measurement:** Run or review the normal “Schema migration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C058-T07 · At-limit measurement:** Exercise the “Schema migration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C058-T08 · Over-limit measurement:** Exercise the “Schema migration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C058-T09 · Uncovered-scope report:** List the “Schema migration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C058-T10 · Limit evidence:** Publish the selected “Schema migration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for schema migration with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C059-T01 · Event inventory:** List the “Schema migration” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Schema migration” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C059-T03 · Failure mapping:** Map each documented “Schema migration” refusal or error to a diagnostic outcome; include “A migration silently drops a field required by the application” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C059-T04 · Emission path:** Add the “Schema migration” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C059-T05 · Redaction check:** Test “Schema migration” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C059-T06 · Output budget:** Set and exercise bounded “Schema migration” message size, rate and retention compatible with “Migration steps and temporary storage”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C059-T07 · Success/refusal fixtures:** Capture “Schema migration” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Schema migration” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C059-T09 · Operator review:** Read the “Schema migration” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C059-T10 · Diagnostic evidence:** Publish redacted “Schema migration” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for schema migration; label unexecuted checks as untested.

- [ ] **UC-M07.07-C060-T01 · Evidence inventory:** List the “Schema migration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C060-T02 · Artifact references:** Record the exact “Schema migration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C060-T03 · Fixture references:** Attach the “Schema migration” fixture IDs, input identities and oracle definition; preserve the source counterexample “A migration silently drops a field required by the application” as a distinct evidence case.
- [ ] **UC-M07.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Schema migration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C060-T05 · Environment record:** Record the actual “Schema migration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C060-T06 · Expected versus observed:** Pair every “Schema migration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C060-T07 · Failure and limit records:** Attach “Schema migration” change/failure and bounds evidence where required; include uncovered “Migration steps and temporary storage” and unresolved violations of “Migration preserves declared state semantics or fails safely”.
- [ ] **UC-M07.07-C060-T08 · Evidence hygiene:** Check the “Schema migration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C060-T09 · Reproduction review:** Have the “Schema migration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C060-T10 · Acceptance linkage:** Link the “Schema migration” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Restore staging

**Source delivery:** Stage a complete validated restore before changing current authority.

**Source invariant:** Failed restore preserves the previous coherent generation.

**Source negative case:** An incompatible snapshot replaces current state before validation.

**Source bounded quantities:** Staging bytes and restore deadline.

### UC-M07.07-C061 · Contract

**Original checklist item:** Specify restore staging inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C061-T01 · Scope statement:** Draft the operation boundary for “Restore staging” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restore staging”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C061-T03 · Output inventory:** List the outputs of “Restore staging” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Restore staging”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C061-T05 · Prerequisite contract:** Map “Restore staging” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Restore staging”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C061-T07 · Invariant clause:** Add a normative clause for “Restore staging” that preserves “Failed restore preserves the previous coherent generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restore staging”; include the source counterexample “An incompatible snapshot replaces current state before validation” and the intended safe disposition.
- [ ] **UC-M07.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Staging bytes and restore deadline” in the “Restore staging” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C061-T10 · Contract review:** Review the “Restore staging” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C062 · Delivery

**Original checklist item:** Stage a complete validated restore before changing current authority.

- [ ] **UC-M07.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restore staging”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C062-T02 · Change plan:** Break the source delivery for “Restore staging” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Restore staging” that realizes this source instruction: Stage a complete validated restore before changing current authority.
- [ ] **UC-M07.07-C062-T04 · Concrete realization:** Trace “Restore staging” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restore staging” needed to preserve “Failed restore preserves the previous coherent generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C062-T06 · Dependency connection:** Connect the “Restore staging” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C062-T07 · Resource behavior:** Account for “Staging bytes and restore deadline” in “Restore staging”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C062-T08 · Delivery check:** Run the smallest real “Restore staging” path and its adverse fixture “An incompatible snapshot replaces current state before validation”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C062-T09 · Patch review:** Review the “Restore staging” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C062-T10 · Delivery handoff:** Publish the “Restore staging” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Failed restore preserves the previous coherent generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Restore staging”; copy its required invariant exactly: “Failed restore preserves the previous coherent generation”.
- [ ] **UC-M07.07-C063-T02 · Observable terms:** Define each term in the “Restore staging” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C063-T03 · Precondition set:** List the preconditions under which “Failed restore preserves the previous coherent generation” must hold for “Restore staging”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C063-T04 · Transition coverage:** Map the “Restore staging” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restore staging”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C063-T06 · Satisfying fixture:** Create a concrete “Restore staging” case that satisfies “Failed restore preserves the previous coherent generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C063-T07 · Violating fixture:** Create the source counterexample “An incompatible snapshot replaces current state before validation” for “Restore staging”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C063-T08 · Enforcement evidence:** Exercise the “Restore staging” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C063-T09 · Regression linkage:** Link the “Restore staging” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Restore staging” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C064 · Integration

**Original checklist item:** Integrate restore staging with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restore staging” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C064-T02 · Field mapping:** Map every “Restore staging” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Restore staging” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C064-T04 · Ownership agreement:** Specify who owns “Restore staging” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C064-T05 · Handoff implementation:** Connect “Restore staging” through the mapped seam using the real adapter or explicit specification reference; preserve “Failed restore preserves the previous coherent generation” across the handoff.
- [ ] **UC-M07.07-C064-T06 · Absent-input case:** Omit one required “Restore staging” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C064-T07 · Stale-input case:** Supply an outdated “Restore staging” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Restore staging” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C064-T09 · Valid integration trace:** Run a valid “Restore staging” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C064-T10 · Seam review:** Reconcile the “Restore staging” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restore staging; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restore staging” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C065-T02 · Expected-result oracle:** Specify the “Restore staging” expected result independently of the implementation output; include the property “Failed restore preserves the previous coherent generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C065-T03 · Fixture material:** Create the concrete “Restore staging” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C065-T04 · Target preparation:** Prepare the “Restore staging” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C065-T05 · Initial-state record:** Record the initial “Restore staging” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C065-T06 · Valid-path execution:** Execute the “Restore staging” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C065-T07 · Outcome comparison:** Compare every declared “Restore staging” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C065-T08 · State and bounds check:** Inspect the “Restore staging” ownership/state effects and actual use of “Staging bytes and restore deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C065-T09 · Repeatability check:** Repeat the same “Restore staging” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C065-T10 · Positive evidence:** Attach the “Restore staging” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C066 · Negative test

**Original checklist item:** Negative case: An incompatible snapshot replaces current state before validation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Restore staging” source counterexample: “An incompatible snapshot replaces current state before validation”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Restore staging”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C066-T03 · Valid control:** Construct a valid “Restore staging” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C066-T04 · Minimal adverse input:** Derive the “Restore staging” adverse fixture from the control with the smallest documented change needed to reproduce “An incompatible snapshot replaces current state before validation”; retain that change as reproducible data.
- [ ] **UC-M07.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restore staging”; require “Failed restore preserves the previous coherent generation” and forbid a false-success verdict.
- [ ] **UC-M07.07-C066-T06 · Adverse execution:** Exercise the “Restore staging” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C066-T07 · Effect inspection:** Inspect “Restore staging” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C066-T08 · Refusal versus failure:** Confirm the “Restore staging” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C066-T09 · Reset and retention:** Restore only the disposable “Restore staging” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C066-T10 · Negative regression:** Register the “Restore staging” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C067 · Change / failure test

**Original checklist item:** Exercise restore staging when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C067-T01 · Scenario record:** Write the “Restore staging” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “Failed restore preserves the previous coherent generation”.
- [ ] **UC-M07.07-C067-T02 · Baseline capture:** Create a known-valid “Restore staging” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C067-T03 · Injection map:** Locate the “Restore staging” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Restore staging” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C067-T05 · Controlled trigger:** Introduce the controlled “Restore staging” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C067-T06 · Intermediate inspection:** Inspect the “Restore staging” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restore staging”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Restore staging” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C067-T09 · Repeat and compare:** Repeat the selected “Restore staging” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C067-T10 · Failure evidence:** Publish the “Restore staging” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for staging bytes and restore deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Restore staging”: “Staging bytes and restore deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C068-T02 · Measurement method:** Choose how to observe each “Restore staging” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Restore staging”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restore staging” cases for “Staging bytes and restore deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restore staging” limit; preserve “Failed restore preserves the previous coherent generation”.
- [ ] **UC-M07.07-C068-T06 · Normal measurement:** Run or review the normal “Restore staging” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C068-T07 · At-limit measurement:** Exercise the “Restore staging” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C068-T08 · Over-limit measurement:** Exercise the “Restore staging” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C068-T09 · Uncovered-scope report:** List the “Restore staging” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C068-T10 · Limit evidence:** Publish the selected “Restore staging” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restore staging with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C069-T01 · Event inventory:** List the “Restore staging” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Restore staging” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C069-T03 · Failure mapping:** Map each documented “Restore staging” refusal or error to a diagnostic outcome; include “An incompatible snapshot replaces current state before validation” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C069-T04 · Emission path:** Add the “Restore staging” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C069-T05 · Redaction check:** Test “Restore staging” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C069-T06 · Output budget:** Set and exercise bounded “Restore staging” message size, rate and retention compatible with “Staging bytes and restore deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C069-T07 · Success/refusal fixtures:** Capture “Restore staging” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restore staging” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C069-T09 · Operator review:** Read the “Restore staging” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C069-T10 · Diagnostic evidence:** Publish redacted “Restore staging” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restore staging; label unexecuted checks as untested.

- [ ] **UC-M07.07-C070-T01 · Evidence inventory:** List the “Restore staging” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C070-T02 · Artifact references:** Record the exact “Restore staging” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C070-T03 · Fixture references:** Attach the “Restore staging” fixture IDs, input identities and oracle definition; preserve the source counterexample “An incompatible snapshot replaces current state before validation” as a distinct evidence case.
- [ ] **UC-M07.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restore staging”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C070-T05 · Environment record:** Record the actual “Restore staging” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C070-T06 · Expected versus observed:** Pair every “Restore staging” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C070-T07 · Failure and limit records:** Attach “Restore staging” change/failure and bounds evidence where required; include uncovered “Staging bytes and restore deadline” and unresolved violations of “Failed restore preserves the previous coherent generation”.
- [ ] **UC-M07.07-C070-T08 · Evidence hygiene:** Check the “Restore staging” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C070-T09 · Reproduction review:** Have the “Restore staging” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C070-T10 · Acceptance linkage:** Link the “Restore staging” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Clean-host restore

**Source delivery:** Restore on a supported clean host with only declared dependencies.

**Source invariant:** Portability evidence does not rely on the original host's mutable cache.

**Source negative case:** A restore passes only on the machine that created the snapshot.

**Source bounded quantities:** Host profiles and bootstrap prerequisites.

### UC-M07.07-C071 · Contract

**Original checklist item:** Specify clean-host restore inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C071-T01 · Scope statement:** Draft the operation boundary for “Clean-host restore” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clean-host restore”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C071-T03 · Output inventory:** List the outputs of “Clean-host restore” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Clean-host restore”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C071-T05 · Prerequisite contract:** Map “Clean-host restore” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Clean-host restore”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C071-T07 · Invariant clause:** Add a normative clause for “Clean-host restore” that preserves “Portability evidence does not rely on the original host's mutable cache”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clean-host restore”; include the source counterexample “A restore passes only on the machine that created the snapshot” and the intended safe disposition.
- [ ] **UC-M07.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Host profiles and bootstrap prerequisites” in the “Clean-host restore” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C071-T10 · Contract review:** Review the “Clean-host restore” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C072 · Delivery

**Original checklist item:** Restore on a supported clean host with only declared dependencies.

- [ ] **UC-M07.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clean-host restore”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C072-T02 · Change plan:** Break the source delivery for “Clean-host restore” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Clean-host restore” that realizes this source instruction: Restore on a supported clean host with only declared dependencies.
- [ ] **UC-M07.07-C072-T04 · Concrete realization:** Trace “Clean-host restore” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clean-host restore” needed to preserve “Portability evidence does not rely on the original host's mutable cache”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C072-T06 · Dependency connection:** Connect the “Clean-host restore” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C072-T07 · Resource behavior:** Account for “Host profiles and bootstrap prerequisites” in “Clean-host restore”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C072-T08 · Delivery check:** Run the smallest real “Clean-host restore” path and its adverse fixture “A restore passes only on the machine that created the snapshot”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C072-T09 · Patch review:** Review the “Clean-host restore” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C072-T10 · Delivery handoff:** Publish the “Clean-host restore” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Portability evidence does not rely on the original host's mutable cache. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Clean-host restore”; copy its required invariant exactly: “Portability evidence does not rely on the original host's mutable cache”.
- [ ] **UC-M07.07-C073-T02 · Observable terms:** Define each term in the “Clean-host restore” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C073-T03 · Precondition set:** List the preconditions under which “Portability evidence does not rely on the original host's mutable cache” must hold for “Clean-host restore”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C073-T04 · Transition coverage:** Map the “Clean-host restore” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clean-host restore”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C073-T06 · Satisfying fixture:** Create a concrete “Clean-host restore” case that satisfies “Portability evidence does not rely on the original host's mutable cache”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C073-T07 · Violating fixture:** Create the source counterexample “A restore passes only on the machine that created the snapshot” for “Clean-host restore”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C073-T08 · Enforcement evidence:** Exercise the “Clean-host restore” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C073-T09 · Regression linkage:** Link the “Clean-host restore” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Clean-host restore” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C074 · Integration

**Original checklist item:** Integrate clean-host restore with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clean-host restore” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C074-T02 · Field mapping:** Map every “Clean-host restore” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Clean-host restore” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C074-T04 · Ownership agreement:** Specify who owns “Clean-host restore” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C074-T05 · Handoff implementation:** Connect “Clean-host restore” through the mapped seam using the real adapter or explicit specification reference; preserve “Portability evidence does not rely on the original host's mutable cache” across the handoff.
- [ ] **UC-M07.07-C074-T06 · Absent-input case:** Omit one required “Clean-host restore” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C074-T07 · Stale-input case:** Supply an outdated “Clean-host restore” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Clean-host restore” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C074-T09 · Valid integration trace:** Run a valid “Clean-host restore” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C074-T10 · Seam review:** Reconcile the “Clean-host restore” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clean-host restore; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clean-host restore” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C075-T02 · Expected-result oracle:** Specify the “Clean-host restore” expected result independently of the implementation output; include the property “Portability evidence does not rely on the original host's mutable cache” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C075-T03 · Fixture material:** Create the concrete “Clean-host restore” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C075-T04 · Target preparation:** Prepare the “Clean-host restore” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C075-T05 · Initial-state record:** Record the initial “Clean-host restore” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C075-T06 · Valid-path execution:** Execute the “Clean-host restore” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C075-T07 · Outcome comparison:** Compare every declared “Clean-host restore” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C075-T08 · State and bounds check:** Inspect the “Clean-host restore” ownership/state effects and actual use of “Host profiles and bootstrap prerequisites”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C075-T09 · Repeatability check:** Repeat the same “Clean-host restore” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C075-T10 · Positive evidence:** Attach the “Clean-host restore” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C076 · Negative test

**Original checklist item:** Negative case: A restore passes only on the machine that created the snapshot. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Clean-host restore” source counterexample: “A restore passes only on the machine that created the snapshot”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Clean-host restore”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C076-T03 · Valid control:** Construct a valid “Clean-host restore” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C076-T04 · Minimal adverse input:** Derive the “Clean-host restore” adverse fixture from the control with the smallest documented change needed to reproduce “A restore passes only on the machine that created the snapshot”; retain that change as reproducible data.
- [ ] **UC-M07.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clean-host restore”; require “Portability evidence does not rely on the original host's mutable cache” and forbid a false-success verdict.
- [ ] **UC-M07.07-C076-T06 · Adverse execution:** Exercise the “Clean-host restore” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C076-T07 · Effect inspection:** Inspect “Clean-host restore” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C076-T08 · Refusal versus failure:** Confirm the “Clean-host restore” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C076-T09 · Reset and retention:** Restore only the disposable “Clean-host restore” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C076-T10 · Negative regression:** Register the “Clean-host restore” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C077 · Change / failure test

**Original checklist item:** Exercise clean-host restore when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C077-T01 · Scenario record:** Write the “Clean-host restore” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “Portability evidence does not rely on the original host's mutable cache”.
- [ ] **UC-M07.07-C077-T02 · Baseline capture:** Create a known-valid “Clean-host restore” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C077-T03 · Injection map:** Locate the “Clean-host restore” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Clean-host restore” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C077-T05 · Controlled trigger:** Introduce the controlled “Clean-host restore” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C077-T06 · Intermediate inspection:** Inspect the “Clean-host restore” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clean-host restore”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Clean-host restore” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C077-T09 · Repeat and compare:** Repeat the selected “Clean-host restore” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C077-T10 · Failure evidence:** Publish the “Clean-host restore” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for host profiles and bootstrap prerequisites; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Clean-host restore”: “Host profiles and bootstrap prerequisites”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C078-T02 · Measurement method:** Choose how to observe each “Clean-host restore” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Clean-host restore”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clean-host restore” cases for “Host profiles and bootstrap prerequisites”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clean-host restore” limit; preserve “Portability evidence does not rely on the original host's mutable cache”.
- [ ] **UC-M07.07-C078-T06 · Normal measurement:** Run or review the normal “Clean-host restore” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C078-T07 · At-limit measurement:** Exercise the “Clean-host restore” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C078-T08 · Over-limit measurement:** Exercise the “Clean-host restore” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C078-T09 · Uncovered-scope report:** List the “Clean-host restore” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C078-T10 · Limit evidence:** Publish the selected “Clean-host restore” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clean-host restore with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C079-T01 · Event inventory:** List the “Clean-host restore” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Clean-host restore” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C079-T03 · Failure mapping:** Map each documented “Clean-host restore” refusal or error to a diagnostic outcome; include “A restore passes only on the machine that created the snapshot” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C079-T04 · Emission path:** Add the “Clean-host restore” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C079-T05 · Redaction check:** Test “Clean-host restore” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C079-T06 · Output budget:** Set and exercise bounded “Clean-host restore” message size, rate and retention compatible with “Host profiles and bootstrap prerequisites”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C079-T07 · Success/refusal fixtures:** Capture “Clean-host restore” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clean-host restore” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C079-T09 · Operator review:** Read the “Clean-host restore” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C079-T10 · Diagnostic evidence:** Publish redacted “Clean-host restore” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clean-host restore; label unexecuted checks as untested.

- [ ] **UC-M07.07-C080-T01 · Evidence inventory:** List the “Clean-host restore” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C080-T02 · Artifact references:** Record the exact “Clean-host restore” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C080-T03 · Fixture references:** Attach the “Clean-host restore” fixture IDs, input identities and oracle definition; preserve the source counterexample “A restore passes only on the machine that created the snapshot” as a distinct evidence case.
- [ ] **UC-M07.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clean-host restore”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C080-T05 · Environment record:** Record the actual “Clean-host restore” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C080-T06 · Expected versus observed:** Pair every “Clean-host restore” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C080-T07 · Failure and limit records:** Attach “Clean-host restore” change/failure and bounds evidence where required; include uncovered “Host profiles and bootstrap prerequisites” and unresolved violations of “Portability evidence does not rely on the original host's mutable cache”.
- [ ] **UC-M07.07-C080-T08 · Evidence hygiene:** Check the “Clean-host restore” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C080-T09 · Reproduction review:** Have the “Clean-host restore” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C080-T10 · Acceptance linkage:** Link the “Clean-host restore” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. State equivalence oracle

**Source delivery:** Compare restored application state and next observable behavior with a reference.

**Source invariant:** A successful file copy alone does not prove equivalent restored state.

**Source negative case:** Restored bytes decode but produce a different next result.

**Source bounded quantities:** Compared state bytes and semantic fixture count.

### UC-M07.07-C081 · Contract

**Original checklist item:** Specify state equivalence oracle inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C081-T01 · Scope statement:** Draft the operation boundary for “State equivalence oracle” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State equivalence oracle”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C081-T03 · Output inventory:** List the outputs of “State equivalence oracle” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “State equivalence oracle”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C081-T05 · Prerequisite contract:** Map “State equivalence oracle” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C081-T06 · Authority map:** Identify who may produce, change and consume “State equivalence oracle”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C081-T07 · Invariant clause:** Add a normative clause for “State equivalence oracle” that preserves “A successful file copy alone does not prove equivalent restored state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State equivalence oracle”; include the source counterexample “Restored bytes decode but produce a different next result” and the intended safe disposition.
- [ ] **UC-M07.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Compared state bytes and semantic fixture count” in the “State equivalence oracle” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C081-T10 · Contract review:** Review the “State equivalence oracle” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C082 · Delivery

**Original checklist item:** Compare restored application state and next observable behavior with a reference.

- [ ] **UC-M07.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State equivalence oracle”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C082-T02 · Change plan:** Break the source delivery for “State equivalence oracle” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C082-T03 · Core artifact:** Create the “State equivalence oracle” fixture or harness for this source instruction: Compare restored application state and next observable behavior with a reference.
- [ ] **UC-M07.07-C082-T04 · Concrete realization:** Connect the “State equivalence oracle” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State equivalence oracle” needed to preserve “A successful file copy alone does not prove equivalent restored state”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C082-T06 · Dependency connection:** Connect the “State equivalence oracle” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C082-T07 · Resource behavior:** Account for “Compared state bytes and semantic fixture count” in “State equivalence oracle”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C082-T08 · Delivery check:** Run the smallest real “State equivalence oracle” path and its adverse fixture “Restored bytes decode but produce a different next result”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C082-T09 · Patch review:** Review the “State equivalence oracle” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C082-T10 · Delivery handoff:** Publish the “State equivalence oracle” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A successful file copy alone does not prove equivalent restored state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “State equivalence oracle”; copy its required invariant exactly: “A successful file copy alone does not prove equivalent restored state”.
- [ ] **UC-M07.07-C083-T02 · Observable terms:** Define each term in the “State equivalence oracle” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C083-T03 · Precondition set:** List the preconditions under which “A successful file copy alone does not prove equivalent restored state” must hold for “State equivalence oracle”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C083-T04 · Transition coverage:** Map the “State equivalence oracle” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State equivalence oracle”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C083-T06 · Satisfying fixture:** Create a concrete “State equivalence oracle” case that satisfies “A successful file copy alone does not prove equivalent restored state”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C083-T07 · Violating fixture:** Create the source counterexample “Restored bytes decode but produce a different next result” for “State equivalence oracle”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C083-T08 · Enforcement evidence:** Exercise the “State equivalence oracle” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C083-T09 · Regression linkage:** Link the “State equivalence oracle” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C083-T10 · Property disposition:** Compare the satisfying and violating “State equivalence oracle” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C084 · Integration

**Original checklist item:** Integrate state equivalence oracle with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State equivalence oracle” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C084-T02 · Field mapping:** Map every “State equivalence oracle” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “State equivalence oracle” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C084-T04 · Ownership agreement:** Specify who owns “State equivalence oracle” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C084-T05 · Handoff implementation:** Connect “State equivalence oracle” through the mapped seam using the real adapter or explicit specification reference; preserve “A successful file copy alone does not prove equivalent restored state” across the handoff.
- [ ] **UC-M07.07-C084-T06 · Absent-input case:** Omit one required “State equivalence oracle” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C084-T07 · Stale-input case:** Supply an outdated “State equivalence oracle” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C084-T08 · Incompatible-input case:** Supply an incompatible “State equivalence oracle” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C084-T09 · Valid integration trace:** Run a valid “State equivalence oracle” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C084-T10 · Seam review:** Reconcile the “State equivalence oracle” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for state equivalence oracle; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “State equivalence oracle” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C085-T02 · Expected-result oracle:** Specify the “State equivalence oracle” expected result independently of the implementation output; include the property “A successful file copy alone does not prove equivalent restored state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C085-T03 · Fixture material:** Create the concrete “State equivalence oracle” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C085-T04 · Target preparation:** Prepare the “State equivalence oracle” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C085-T05 · Initial-state record:** Record the initial “State equivalence oracle” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C085-T06 · Valid-path execution:** Execute the “State equivalence oracle” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C085-T07 · Outcome comparison:** Compare every declared “State equivalence oracle” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C085-T08 · State and bounds check:** Inspect the “State equivalence oracle” ownership/state effects and actual use of “Compared state bytes and semantic fixture count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C085-T09 · Repeatability check:** Repeat the same “State equivalence oracle” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C085-T10 · Positive evidence:** Attach the “State equivalence oracle” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C086 · Negative test

**Original checklist item:** Negative case: Restored bytes decode but produce a different next result. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “State equivalence oracle” source counterexample: “Restored bytes decode but produce a different next result”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “State equivalence oracle”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C086-T03 · Valid control:** Construct a valid “State equivalence oracle” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C086-T04 · Minimal adverse input:** Derive the “State equivalence oracle” adverse fixture from the control with the smallest documented change needed to reproduce “Restored bytes decode but produce a different next result”; retain that change as reproducible data.
- [ ] **UC-M07.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State equivalence oracle”; require “A successful file copy alone does not prove equivalent restored state” and forbid a false-success verdict.
- [ ] **UC-M07.07-C086-T06 · Adverse execution:** Exercise the “State equivalence oracle” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C086-T07 · Effect inspection:** Inspect “State equivalence oracle” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C086-T08 · Refusal versus failure:** Confirm the “State equivalence oracle” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C086-T09 · Reset and retention:** Restore only the disposable “State equivalence oracle” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C086-T10 · Negative regression:** Register the “State equivalence oracle” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C087 · Change / failure test

**Original checklist item:** Exercise state equivalence oracle when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C087-T01 · Scenario record:** Write the “State equivalence oracle” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “A successful file copy alone does not prove equivalent restored state”.
- [ ] **UC-M07.07-C087-T02 · Baseline capture:** Create a known-valid “State equivalence oracle” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C087-T03 · Injection map:** Locate the “State equivalence oracle” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “State equivalence oracle” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C087-T05 · Controlled trigger:** Introduce the controlled “State equivalence oracle” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C087-T06 · Intermediate inspection:** Inspect the “State equivalence oracle” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “State equivalence oracle”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “State equivalence oracle” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C087-T09 · Repeat and compare:** Repeat the selected “State equivalence oracle” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C087-T10 · Failure evidence:** Publish the “State equivalence oracle” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for compared state bytes and semantic fixture count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “State equivalence oracle”: “Compared state bytes and semantic fixture count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C088-T02 · Measurement method:** Choose how to observe each “State equivalence oracle” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C088-T03 · Budget decision:** Select justified resource and input limits for “State equivalence oracle”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State equivalence oracle” cases for “Compared state bytes and semantic fixture count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State equivalence oracle” limit; preserve “A successful file copy alone does not prove equivalent restored state”.
- [ ] **UC-M07.07-C088-T06 · Normal measurement:** Run or review the normal “State equivalence oracle” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C088-T07 · At-limit measurement:** Exercise the “State equivalence oracle” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C088-T08 · Over-limit measurement:** Exercise the “State equivalence oracle” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C088-T09 · Uncovered-scope report:** List the “State equivalence oracle” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C088-T10 · Limit evidence:** Publish the selected “State equivalence oracle” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for state equivalence oracle with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C089-T01 · Event inventory:** List the “State equivalence oracle” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “State equivalence oracle” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C089-T03 · Failure mapping:** Map each documented “State equivalence oracle” refusal or error to a diagnostic outcome; include “Restored bytes decode but produce a different next result” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C089-T04 · Emission path:** Add the “State equivalence oracle” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C089-T05 · Redaction check:** Test “State equivalence oracle” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C089-T06 · Output budget:** Set and exercise bounded “State equivalence oracle” message size, rate and retention compatible with “Compared state bytes and semantic fixture count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C089-T07 · Success/refusal fixtures:** Capture “State equivalence oracle” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “State equivalence oracle” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C089-T09 · Operator review:** Read the “State equivalence oracle” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C089-T10 · Diagnostic evidence:** Publish redacted “State equivalence oracle” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state equivalence oracle; label unexecuted checks as untested.

- [ ] **UC-M07.07-C090-T01 · Evidence inventory:** List the “State equivalence oracle” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C090-T02 · Artifact references:** Record the exact “State equivalence oracle” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C090-T03 · Fixture references:** Attach the “State equivalence oracle” fixture IDs, input identities and oracle definition; preserve the source counterexample “Restored bytes decode but produce a different next result” as a distinct evidence case.
- [ ] **UC-M07.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State equivalence oracle”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C090-T05 · Environment record:** Record the actual “State equivalence oracle” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C090-T06 · Expected versus observed:** Pair every “State equivalence oracle” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C090-T07 · Failure and limit records:** Attach “State equivalence oracle” change/failure and bounds evidence where required; include uncovered “Compared state bytes and semantic fixture count” and unresolved violations of “A successful file copy alone does not prove equivalent restored state”.
- [ ] **UC-M07.07-C090-T08 · Evidence hygiene:** Check the “State equivalence oracle” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C090-T09 · Reproduction review:** Have the “State equivalence oracle” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C090-T10 · Acceptance linkage:** Link the “State equivalence oracle” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Portable snapshot qualification

**Source delivery:** Exercise valid, corrupt, incompatible and migrated snapshots end to end.

**Source invariant:** The selected supported snapshot profiles have measured restore evidence.

**Source negative case:** An unsupported ABI is accepted because basic parsing succeeds.

**Source bounded quantities:** Profile matrix and restoration repetitions.

### UC-M07.07-C091 · Contract

**Original checklist item:** Specify portable snapshot qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.07-C091-T01 · Scope statement:** Draft the operation boundary for “Portable snapshot qualification” within Portable snapshots and state migrations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Portable snapshot qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.07-C091-T03 · Output inventory:** List the outputs of “Portable snapshot qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Portable snapshot qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.07-C091-T05 · Prerequisite contract:** Map “Portable snapshot qualification” to the source component prerequisites (UC-M02.08, UC-M06.07, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Portable snapshot qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.07-C091-T07 · Invariant clause:** Add a normative clause for “Portable snapshot qualification” that preserves “The selected supported snapshot profiles have measured restore evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Portable snapshot qualification”; include the source counterexample “An unsupported ABI is accepted because basic parsing succeeds” and the intended safe disposition.
- [ ] **UC-M07.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Profile matrix and restoration repetitions” in the “Portable snapshot qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.07-C091-T10 · Contract review:** Review the “Portable snapshot qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.07-C092 · Delivery

**Original checklist item:** Exercise valid, corrupt, incompatible and migrated snapshots end to end.

- [ ] **UC-M07.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Portable snapshot qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.07-C092-T02 · Change plan:** Break the source delivery for “Portable snapshot qualification” into concrete edit targets and reviewable outputs; keep the UC-M07.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.07-C092-T03 · Core artifact:** Create the “Portable snapshot qualification” fixture or harness for this source instruction: Exercise valid, corrupt, incompatible and migrated snapshots end to end.
- [ ] **UC-M07.07-C092-T04 · Concrete realization:** Connect the “Portable snapshot qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Portable snapshot qualification” needed to preserve “The selected supported snapshot profiles have measured restore evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.07-C092-T06 · Dependency connection:** Connect the “Portable snapshot qualification” implementation to snapshot envelopes, image/ABI compatibility and generation-safe restoration; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.07-C092-T07 · Resource behavior:** Account for “Profile matrix and restoration repetitions” in “Portable snapshot qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.07-C092-T08 · Delivery check:** Run the smallest real “Portable snapshot qualification” path and its adverse fixture “An unsupported ABI is accepted because basic parsing succeeds”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.07-C092-T09 · Patch review:** Review the “Portable snapshot qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.07-C092-T10 · Delivery handoff:** Publish the “Portable snapshot qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The selected supported snapshot profiles have measured restore evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Portable snapshot qualification”; copy its required invariant exactly: “The selected supported snapshot profiles have measured restore evidence”.
- [ ] **UC-M07.07-C093-T02 · Observable terms:** Define each term in the “Portable snapshot qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.07-C093-T03 · Precondition set:** List the preconditions under which “The selected supported snapshot profiles have measured restore evidence” must hold for “Portable snapshot qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.07-C093-T04 · Transition coverage:** Map the “Portable snapshot qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Portable snapshot qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.07-C093-T06 · Satisfying fixture:** Create a concrete “Portable snapshot qualification” case that satisfies “The selected supported snapshot profiles have measured restore evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.07-C093-T07 · Violating fixture:** Create the source counterexample “An unsupported ABI is accepted because basic parsing succeeds” for “Portable snapshot qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.07-C093-T08 · Enforcement evidence:** Exercise the “Portable snapshot qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.07-C093-T09 · Regression linkage:** Link the “Portable snapshot qualification” property to changes in snapshot envelopes, image/ABI compatibility and generation-safe restoration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Portable snapshot qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.07-C094 · Integration

**Original checklist item:** Integrate portable snapshot qualification with snapshot envelopes, image/ABI compatibility and generation-safe restoration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Portable snapshot qualification” across snapshot envelopes, image/ABI compatibility and generation-safe restoration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.07-C094-T02 · Field mapping:** Map every “Portable snapshot qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Portable snapshot qualification” (source dependency list: UC-M02.08, UC-M06.07, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.07-C094-T04 · Ownership agreement:** Specify who owns “Portable snapshot qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.07-C094-T05 · Handoff implementation:** Connect “Portable snapshot qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “The selected supported snapshot profiles have measured restore evidence” across the handoff.
- [ ] **UC-M07.07-C094-T06 · Absent-input case:** Omit one required “Portable snapshot qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.07-C094-T07 · Stale-input case:** Supply an outdated “Portable snapshot qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Portable snapshot qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.07-C094-T09 · Valid integration trace:** Run a valid “Portable snapshot qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.07-C094-T10 · Seam review:** Reconcile the “Portable snapshot qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for portable snapshot qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Portable snapshot qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.07-C095-T02 · Expected-result oracle:** Specify the “Portable snapshot qualification” expected result independently of the implementation output; include the property “The selected supported snapshot profiles have measured restore evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.07-C095-T03 · Fixture material:** Create the concrete “Portable snapshot qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.07-C095-T04 · Target preparation:** Prepare the “Portable snapshot qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.07-C095-T05 · Initial-state record:** Record the initial “Portable snapshot qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.07-C095-T06 · Valid-path execution:** Execute the “Portable snapshot qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.07-C095-T07 · Outcome comparison:** Compare every declared “Portable snapshot qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.07-C095-T08 · State and bounds check:** Inspect the “Portable snapshot qualification” ownership/state effects and actual use of “Profile matrix and restoration repetitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.07-C095-T09 · Repeatability check:** Repeat the same “Portable snapshot qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.07-C095-T10 · Positive evidence:** Attach the “Portable snapshot qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.07-C096 · Negative test

**Original checklist item:** Negative case: An unsupported ABI is accepted because basic parsing succeeds. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Portable snapshot qualification” source counterexample: “An unsupported ABI is accepted because basic parsing succeeds”; state which precondition or invariant it challenges.
- [ ] **UC-M07.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Portable snapshot qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.07-C096-T03 · Valid control:** Construct a valid “Portable snapshot qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.07-C096-T04 · Minimal adverse input:** Derive the “Portable snapshot qualification” adverse fixture from the control with the smallest documented change needed to reproduce “An unsupported ABI is accepted because basic parsing succeeds”; retain that change as reproducible data.
- [ ] **UC-M07.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Portable snapshot qualification”; require “The selected supported snapshot profiles have measured restore evidence” and forbid a false-success verdict.
- [ ] **UC-M07.07-C096-T06 · Adverse execution:** Exercise the “Portable snapshot qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.07-C096-T07 · Effect inspection:** Inspect “Portable snapshot qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.07-C096-T08 · Refusal versus failure:** Confirm the “Portable snapshot qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.07-C096-T09 · Reset and retention:** Restore only the disposable “Portable snapshot qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.07-C096-T10 · Negative regression:** Register the “Portable snapshot qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.07-C097 · Change / failure test

**Original checklist item:** Exercise portable snapshot qualification when restore is attempted on a clean supported host without the original workspace; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.07-C097-T01 · Scenario record:** Write the “Portable snapshot qualification” change/failure scenario exactly as supplied: restore is attempted on a clean supported host without the original workspace; identify the property that must remain true: “The selected supported snapshot profiles have measured restore evidence”.
- [ ] **UC-M07.07-C097-T02 · Baseline capture:** Create a known-valid “Portable snapshot qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.07-C097-T03 · Injection map:** Locate the “Portable snapshot qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Portable snapshot qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.07-C097-T05 · Controlled trigger:** Introduce the controlled “Portable snapshot qualification” scenario in the disposable fixture: restore is attempted on a clean supported host without the original workspace; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.07-C097-T06 · Intermediate inspection:** Inspect the “Portable snapshot qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Portable snapshot qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Portable snapshot qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.07-C097-T09 · Repeat and compare:** Repeat the selected “Portable snapshot qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.07-C097-T10 · Failure evidence:** Publish the “Portable snapshot qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for profile matrix and restoration repetitions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Portable snapshot qualification”: “Profile matrix and restoration repetitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.07-C098-T02 · Measurement method:** Choose how to observe each “Portable snapshot qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Portable snapshot qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Portable snapshot qualification” cases for “Profile matrix and restoration repetitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Portable snapshot qualification” limit; preserve “The selected supported snapshot profiles have measured restore evidence”.
- [ ] **UC-M07.07-C098-T06 · Normal measurement:** Run or review the normal “Portable snapshot qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.07-C098-T07 · At-limit measurement:** Exercise the “Portable snapshot qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.07-C098-T08 · Over-limit measurement:** Exercise the “Portable snapshot qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.07-C098-T09 · Uncovered-scope report:** List the “Portable snapshot qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.07-C098-T10 · Limit evidence:** Publish the selected “Portable snapshot qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for portable snapshot qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.07-C099-T01 · Event inventory:** List the “Portable snapshot qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Portable snapshot qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.07-C099-T03 · Failure mapping:** Map each documented “Portable snapshot qualification” refusal or error to a diagnostic outcome; include “An unsupported ABI is accepted because basic parsing succeeds” and prohibit conversion into a success message.
- [ ] **UC-M07.07-C099-T04 · Emission path:** Add the “Portable snapshot qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.07-C099-T05 · Redaction check:** Test “Portable snapshot qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.07-C099-T06 · Output budget:** Set and exercise bounded “Portable snapshot qualification” message size, rate and retention compatible with “Profile matrix and restoration repetitions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.07-C099-T07 · Success/refusal fixtures:** Capture “Portable snapshot qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Portable snapshot qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.07-C099-T09 · Operator review:** Read the “Portable snapshot qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.07-C099-T10 · Diagnostic evidence:** Publish redacted “Portable snapshot qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for portable snapshot qualification; label unexecuted checks as untested.

- [ ] **UC-M07.07-C100-T01 · Evidence inventory:** List the “Portable snapshot qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.07-C100-T02 · Artifact references:** Record the exact “Portable snapshot qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.07-C100-T03 · Fixture references:** Attach the “Portable snapshot qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unsupported ABI is accepted because basic parsing succeeds” as a distinct evidence case.
- [ ] **UC-M07.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Portable snapshot qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.07-C100-T05 · Environment record:** Record the actual “Portable snapshot qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.07-C100-T06 · Expected versus observed:** Pair every “Portable snapshot qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.07-C100-T07 · Failure and limit records:** Attach “Portable snapshot qualification” change/failure and bounds evidence where required; include uncovered “Profile matrix and restoration repetitions” and unresolved violations of “The selected supported snapshot profiles have measured restore evidence”.
- [ ] **UC-M07.07-C100-T08 · Evidence hygiene:** Check the “Portable snapshot qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.07-C100-T09 · Reproduction review:** Have the “Portable snapshot qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.07-C100-T10 · Acceptance linkage:** Link the “Portable snapshot qualification” evidence to its parent and UC-M07.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

