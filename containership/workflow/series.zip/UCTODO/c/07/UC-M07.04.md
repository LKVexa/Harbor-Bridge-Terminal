# UC-M07.04 — Strict state schema and decoder boundary

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/07.md)

| Field | Preserved source value |
|---|---|
| Workstream | 07. Persistence, transactions and recovery |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M03.05](../03/UC-M03.05.md), [UC-M07.02](../07/UC-M07.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S8]. |

## Original requirement

Apply bounded schema validation to every TIFF/JSON/blob entry point, including embedded hull decoders, previews and import paths.

**Original acceptance criterion:** Malformed metadata, dimensions, integer fields and nested structures are rejected inside a bounded decoder worker.

**Source trace:** Original checklist `UC100/c/07/UC-M07.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 652–662 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Decoder entry-point inventory

**Source delivery:** Inventory TIFF, JSON, blob, preview, import and embedded hull decoding paths.

**Source invariant:** No decoding entry point bypasses the selected validation boundary.

**Source negative case:** A preview opens unvalidated TIFF metadata directly.

**Source bounded quantities:** Entry points and parser variants.

### UC-M07.04-C001 · Contract

**Original checklist item:** Specify decoder entry-point inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C001-T01 · Scope statement:** Draft the operation boundary for “Decoder entry-point inventory” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Decoder entry-point inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C001-T03 · Output inventory:** List the outputs of “Decoder entry-point inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Decoder entry-point inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C001-T05 · Prerequisite contract:** Map “Decoder entry-point inventory” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Decoder entry-point inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C001-T07 · Invariant clause:** Add a normative clause for “Decoder entry-point inventory” that preserves “No decoding entry point bypasses the selected validation boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Decoder entry-point inventory”; include the source counterexample “A preview opens unvalidated TIFF metadata directly” and the intended safe disposition.
- [ ] **UC-M07.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Entry points and parser variants” in the “Decoder entry-point inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C001-T10 · Contract review:** Review the “Decoder entry-point inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C002 · Delivery

**Original checklist item:** Inventory TIFF, JSON, blob, preview, import and embedded hull decoding paths.

- [ ] **UC-M07.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Decoder entry-point inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C002-T02 · Change plan:** Break the source delivery for “Decoder entry-point inventory” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C002-T03 · Core artifact:** Create the “Decoder entry-point inventory” model, schema or inventory that realizes this source instruction: Inventory TIFF, JSON, blob, preview, import and embedded hull decoding paths.
- [ ] **UC-M07.04-C002-T04 · Concrete realization:** Populate “Decoder entry-point inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Decoder entry-point inventory” needed to preserve “No decoding entry point bypasses the selected validation boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C002-T06 · Dependency connection:** Connect the “Decoder entry-point inventory” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C002-T07 · Resource behavior:** Account for “Entry points and parser variants” in “Decoder entry-point inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C002-T08 · Delivery check:** Run the smallest real “Decoder entry-point inventory” path and its adverse fixture “A preview opens unvalidated TIFF metadata directly”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C002-T09 · Patch review:** Review the “Decoder entry-point inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C002-T10 · Delivery handoff:** Publish the “Decoder entry-point inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No decoding entry point bypasses the selected validation boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Decoder entry-point inventory”; copy its required invariant exactly: “No decoding entry point bypasses the selected validation boundary”.
- [ ] **UC-M07.04-C003-T02 · Observable terms:** Define each term in the “Decoder entry-point inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C003-T03 · Precondition set:** List the preconditions under which “No decoding entry point bypasses the selected validation boundary” must hold for “Decoder entry-point inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C003-T04 · Transition coverage:** Map the “Decoder entry-point inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Decoder entry-point inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C003-T06 · Satisfying fixture:** Create a concrete “Decoder entry-point inventory” case that satisfies “No decoding entry point bypasses the selected validation boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C003-T07 · Violating fixture:** Create the source counterexample “A preview opens unvalidated TIFF metadata directly” for “Decoder entry-point inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C003-T08 · Enforcement evidence:** Exercise the “Decoder entry-point inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C003-T09 · Regression linkage:** Link the “Decoder entry-point inventory” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Decoder entry-point inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C004 · Integration

**Original checklist item:** Integrate decoder entry-point inventory with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Decoder entry-point inventory” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C004-T02 · Field mapping:** Map every “Decoder entry-point inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Decoder entry-point inventory” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C004-T04 · Ownership agreement:** Specify who owns “Decoder entry-point inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C004-T05 · Handoff implementation:** Connect “Decoder entry-point inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “No decoding entry point bypasses the selected validation boundary” across the handoff.
- [ ] **UC-M07.04-C004-T06 · Absent-input case:** Omit one required “Decoder entry-point inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C004-T07 · Stale-input case:** Supply an outdated “Decoder entry-point inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Decoder entry-point inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C004-T09 · Valid integration trace:** Run a valid “Decoder entry-point inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C004-T10 · Seam review:** Reconcile the “Decoder entry-point inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for decoder entry-point inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Decoder entry-point inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C005-T02 · Expected-result oracle:** Specify the “Decoder entry-point inventory” expected result independently of the implementation output; include the property “No decoding entry point bypasses the selected validation boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C005-T03 · Fixture material:** Create the concrete “Decoder entry-point inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C005-T04 · Target preparation:** Prepare the “Decoder entry-point inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C005-T05 · Initial-state record:** Record the initial “Decoder entry-point inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C005-T06 · Valid-path execution:** Execute the “Decoder entry-point inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C005-T07 · Outcome comparison:** Compare every declared “Decoder entry-point inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C005-T08 · State and bounds check:** Inspect the “Decoder entry-point inventory” ownership/state effects and actual use of “Entry points and parser variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C005-T09 · Repeatability check:** Repeat the same “Decoder entry-point inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C005-T10 · Positive evidence:** Attach the “Decoder entry-point inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C006 · Negative test

**Original checklist item:** Negative case: A preview opens unvalidated TIFF metadata directly. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Decoder entry-point inventory” source counterexample: “A preview opens unvalidated TIFF metadata directly”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Decoder entry-point inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C006-T03 · Valid control:** Construct a valid “Decoder entry-point inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C006-T04 · Minimal adverse input:** Derive the “Decoder entry-point inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A preview opens unvalidated TIFF metadata directly”; retain that change as reproducible data.
- [ ] **UC-M07.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Decoder entry-point inventory”; require “No decoding entry point bypasses the selected validation boundary” and forbid a false-success verdict.
- [ ] **UC-M07.04-C006-T06 · Adverse execution:** Exercise the “Decoder entry-point inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C006-T07 · Effect inspection:** Inspect “Decoder entry-point inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C006-T08 · Refusal versus failure:** Confirm the “Decoder entry-point inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C006-T09 · Reset and retention:** Restore only the disposable “Decoder entry-point inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C006-T10 · Negative regression:** Register the “Decoder entry-point inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C007 · Change / failure test

**Original checklist item:** Exercise decoder entry-point inventory when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C007-T01 · Scenario record:** Write the “Decoder entry-point inventory” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “No decoding entry point bypasses the selected validation boundary”.
- [ ] **UC-M07.04-C007-T02 · Baseline capture:** Create a known-valid “Decoder entry-point inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C007-T03 · Injection map:** Locate the “Decoder entry-point inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Decoder entry-point inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C007-T05 · Controlled trigger:** Introduce the controlled “Decoder entry-point inventory” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C007-T06 · Intermediate inspection:** Inspect the “Decoder entry-point inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Decoder entry-point inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Decoder entry-point inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C007-T09 · Repeat and compare:** Repeat the selected “Decoder entry-point inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C007-T10 · Failure evidence:** Publish the “Decoder entry-point inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C008 · Bounds

**Original checklist item:** Choose, document and test limits for entry points and parser variants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Decoder entry-point inventory”: “Entry points and parser variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C008-T02 · Measurement method:** Choose how to observe each “Decoder entry-point inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C008-T03 · Budget decision:** Select justified resource and input limits for “Decoder entry-point inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Decoder entry-point inventory” cases for “Entry points and parser variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Decoder entry-point inventory” limit; preserve “No decoding entry point bypasses the selected validation boundary”.
- [ ] **UC-M07.04-C008-T06 · Normal measurement:** Run or review the normal “Decoder entry-point inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C008-T07 · At-limit measurement:** Exercise the “Decoder entry-point inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C008-T08 · Over-limit measurement:** Exercise the “Decoder entry-point inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C008-T09 · Uncovered-scope report:** List the “Decoder entry-point inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C008-T10 · Limit evidence:** Publish the selected “Decoder entry-point inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for decoder entry-point inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C009-T01 · Event inventory:** List the “Decoder entry-point inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Decoder entry-point inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C009-T03 · Failure mapping:** Map each documented “Decoder entry-point inventory” refusal or error to a diagnostic outcome; include “A preview opens unvalidated TIFF metadata directly” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C009-T04 · Emission path:** Add the “Decoder entry-point inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C009-T05 · Redaction check:** Test “Decoder entry-point inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C009-T06 · Output budget:** Set and exercise bounded “Decoder entry-point inventory” message size, rate and retention compatible with “Entry points and parser variants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C009-T07 · Success/refusal fixtures:** Capture “Decoder entry-point inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Decoder entry-point inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C009-T09 · Operator review:** Read the “Decoder entry-point inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C009-T10 · Diagnostic evidence:** Publish redacted “Decoder entry-point inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for decoder entry-point inventory; label unexecuted checks as untested.

- [ ] **UC-M07.04-C010-T01 · Evidence inventory:** List the “Decoder entry-point inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C010-T02 · Artifact references:** Record the exact “Decoder entry-point inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C010-T03 · Fixture references:** Attach the “Decoder entry-point inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A preview opens unvalidated TIFF metadata directly” as a distinct evidence case.
- [ ] **UC-M07.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Decoder entry-point inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C010-T05 · Environment record:** Record the actual “Decoder entry-point inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C010-T06 · Expected versus observed:** Pair every “Decoder entry-point inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C010-T07 · Failure and limit records:** Attach “Decoder entry-point inventory” change/failure and bounds evidence where required; include uncovered “Entry points and parser variants” and unresolved violations of “No decoding entry point bypasses the selected validation boundary”.
- [ ] **UC-M07.04-C010-T08 · Evidence hygiene:** Check the “Decoder entry-point inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C010-T09 · Reproduction review:** Have the “Decoder entry-point inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C010-T10 · Acceptance linkage:** Link the “Decoder entry-point inventory” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Schema validation

**Source delivery:** Define strict required fields and accepted types for each state format.

**Source invariant:** Decoded state cannot rely on ambiguous or coerced field values.

**Source negative case:** A numeric state field is accepted as an arbitrary string.

**Source bounded quantities:** Field count and schema versions.

### UC-M07.04-C011 · Contract

**Original checklist item:** Specify schema validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C011-T01 · Scope statement:** Draft the operation boundary for “Schema validation” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Schema validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C011-T03 · Output inventory:** List the outputs of “Schema validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Schema validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C011-T05 · Prerequisite contract:** Map “Schema validation” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Schema validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C011-T07 · Invariant clause:** Add a normative clause for “Schema validation” that preserves “Decoded state cannot rely on ambiguous or coerced field values”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Schema validation”; include the source counterexample “A numeric state field is accepted as an arbitrary string” and the intended safe disposition.
- [ ] **UC-M07.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Field count and schema versions” in the “Schema validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C011-T10 · Contract review:** Review the “Schema validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C012 · Delivery

**Original checklist item:** Define strict required fields and accepted types for each state format.

- [ ] **UC-M07.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Schema validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C012-T02 · Change plan:** Break the source delivery for “Schema validation” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C012-T03 · Core artifact:** Create the “Schema validation” model, schema or inventory that realizes this source instruction: Define strict required fields and accepted types for each state format.
- [ ] **UC-M07.04-C012-T04 · Concrete realization:** Populate “Schema validation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Schema validation” needed to preserve “Decoded state cannot rely on ambiguous or coerced field values”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C012-T06 · Dependency connection:** Connect the “Schema validation” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C012-T07 · Resource behavior:** Account for “Field count and schema versions” in “Schema validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C012-T08 · Delivery check:** Run the smallest real “Schema validation” path and its adverse fixture “A numeric state field is accepted as an arbitrary string”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C012-T09 · Patch review:** Review the “Schema validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C012-T10 · Delivery handoff:** Publish the “Schema validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Decoded state cannot rely on ambiguous or coerced field values. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Schema validation”; copy its required invariant exactly: “Decoded state cannot rely on ambiguous or coerced field values”.
- [ ] **UC-M07.04-C013-T02 · Observable terms:** Define each term in the “Schema validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C013-T03 · Precondition set:** List the preconditions under which “Decoded state cannot rely on ambiguous or coerced field values” must hold for “Schema validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C013-T04 · Transition coverage:** Map the “Schema validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Schema validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C013-T06 · Satisfying fixture:** Create a concrete “Schema validation” case that satisfies “Decoded state cannot rely on ambiguous or coerced field values”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C013-T07 · Violating fixture:** Create the source counterexample “A numeric state field is accepted as an arbitrary string” for “Schema validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C013-T08 · Enforcement evidence:** Exercise the “Schema validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C013-T09 · Regression linkage:** Link the “Schema validation” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Schema validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C014 · Integration

**Original checklist item:** Integrate schema validation with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Schema validation” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C014-T02 · Field mapping:** Map every “Schema validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Schema validation” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C014-T04 · Ownership agreement:** Specify who owns “Schema validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C014-T05 · Handoff implementation:** Connect “Schema validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Decoded state cannot rely on ambiguous or coerced field values” across the handoff.
- [ ] **UC-M07.04-C014-T06 · Absent-input case:** Omit one required “Schema validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C014-T07 · Stale-input case:** Supply an outdated “Schema validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Schema validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C014-T09 · Valid integration trace:** Run a valid “Schema validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C014-T10 · Seam review:** Reconcile the “Schema validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for schema validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Schema validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C015-T02 · Expected-result oracle:** Specify the “Schema validation” expected result independently of the implementation output; include the property “Decoded state cannot rely on ambiguous or coerced field values” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C015-T03 · Fixture material:** Create the concrete “Schema validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C015-T04 · Target preparation:** Prepare the “Schema validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C015-T05 · Initial-state record:** Record the initial “Schema validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C015-T06 · Valid-path execution:** Execute the “Schema validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C015-T07 · Outcome comparison:** Compare every declared “Schema validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C015-T08 · State and bounds check:** Inspect the “Schema validation” ownership/state effects and actual use of “Field count and schema versions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C015-T09 · Repeatability check:** Repeat the same “Schema validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C015-T10 · Positive evidence:** Attach the “Schema validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C016 · Negative test

**Original checklist item:** Negative case: A numeric state field is accepted as an arbitrary string. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Schema validation” source counterexample: “A numeric state field is accepted as an arbitrary string”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Schema validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C016-T03 · Valid control:** Construct a valid “Schema validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C016-T04 · Minimal adverse input:** Derive the “Schema validation” adverse fixture from the control with the smallest documented change needed to reproduce “A numeric state field is accepted as an arbitrary string”; retain that change as reproducible data.
- [ ] **UC-M07.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Schema validation”; require “Decoded state cannot rely on ambiguous or coerced field values” and forbid a false-success verdict.
- [ ] **UC-M07.04-C016-T06 · Adverse execution:** Exercise the “Schema validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C016-T07 · Effect inspection:** Inspect “Schema validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C016-T08 · Refusal versus failure:** Confirm the “Schema validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C016-T09 · Reset and retention:** Restore only the disposable “Schema validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C016-T10 · Negative regression:** Register the “Schema validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C017 · Change / failure test

**Original checklist item:** Exercise schema validation when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C017-T01 · Scenario record:** Write the “Schema validation” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “Decoded state cannot rely on ambiguous or coerced field values”.
- [ ] **UC-M07.04-C017-T02 · Baseline capture:** Create a known-valid “Schema validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C017-T03 · Injection map:** Locate the “Schema validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Schema validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C017-T05 · Controlled trigger:** Introduce the controlled “Schema validation” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C017-T06 · Intermediate inspection:** Inspect the “Schema validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Schema validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Schema validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C017-T09 · Repeat and compare:** Repeat the selected “Schema validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C017-T10 · Failure evidence:** Publish the “Schema validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C018 · Bounds

**Original checklist item:** Choose, document and test limits for field count and schema versions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Schema validation”: “Field count and schema versions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C018-T02 · Measurement method:** Choose how to observe each “Schema validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C018-T03 · Budget decision:** Select justified resource and input limits for “Schema validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Schema validation” cases for “Field count and schema versions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Schema validation” limit; preserve “Decoded state cannot rely on ambiguous or coerced field values”.
- [ ] **UC-M07.04-C018-T06 · Normal measurement:** Run or review the normal “Schema validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C018-T07 · At-limit measurement:** Exercise the “Schema validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C018-T08 · Over-limit measurement:** Exercise the “Schema validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C018-T09 · Uncovered-scope report:** List the “Schema validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C018-T10 · Limit evidence:** Publish the selected “Schema validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for schema validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C019-T01 · Event inventory:** List the “Schema validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Schema validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C019-T03 · Failure mapping:** Map each documented “Schema validation” refusal or error to a diagnostic outcome; include “A numeric state field is accepted as an arbitrary string” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C019-T04 · Emission path:** Add the “Schema validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C019-T05 · Redaction check:** Test “Schema validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C019-T06 · Output budget:** Set and exercise bounded “Schema validation” message size, rate and retention compatible with “Field count and schema versions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C019-T07 · Success/refusal fixtures:** Capture “Schema validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Schema validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C019-T09 · Operator review:** Read the “Schema validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C019-T10 · Diagnostic evidence:** Publish redacted “Schema validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for schema validation; label unexecuted checks as untested.

- [ ] **UC-M07.04-C020-T01 · Evidence inventory:** List the “Schema validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C020-T02 · Artifact references:** Record the exact “Schema validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C020-T03 · Fixture references:** Attach the “Schema validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A numeric state field is accepted as an arbitrary string” as a distinct evidence case.
- [ ] **UC-M07.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Schema validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C020-T05 · Environment record:** Record the actual “Schema validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C020-T06 · Expected versus observed:** Pair every “Schema validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C020-T07 · Failure and limit records:** Attach “Schema validation” change/failure and bounds evidence where required; include uncovered “Field count and schema versions” and unresolved violations of “Decoded state cannot rely on ambiguous or coerced field values”.
- [ ] **UC-M07.04-C020-T08 · Evidence hygiene:** Check the “Schema validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C020-T09 · Reproduction review:** Have the “Schema validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C020-T10 · Acceptance linkage:** Link the “Schema validation” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Dimension and size bounds

**Source delivery:** Validate dimensions, page counts and declared decoded sizes before allocation.

**Source invariant:** Compact input cannot request unbounded decoded memory.

**Source negative case:** A small TIFF declares enormous dimensions.

**Source bounded quantities:** Pixels, pages and expanded bytes.

### UC-M07.04-C021 · Contract

**Original checklist item:** Specify dimension and size bounds inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C021-T01 · Scope statement:** Draft the operation boundary for “Dimension and size bounds” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Dimension and size bounds”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C021-T03 · Output inventory:** List the outputs of “Dimension and size bounds” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Dimension and size bounds”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C021-T05 · Prerequisite contract:** Map “Dimension and size bounds” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Dimension and size bounds”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C021-T07 · Invariant clause:** Add a normative clause for “Dimension and size bounds” that preserves “Compact input cannot request unbounded decoded memory”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Dimension and size bounds”; include the source counterexample “A small TIFF declares enormous dimensions” and the intended safe disposition.
- [ ] **UC-M07.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pixels, pages and expanded bytes” in the “Dimension and size bounds” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C021-T10 · Contract review:** Review the “Dimension and size bounds” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C022 · Delivery

**Original checklist item:** Validate dimensions, page counts and declared decoded sizes before allocation.

- [ ] **UC-M07.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Dimension and size bounds”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C022-T02 · Change plan:** Break the source delivery for “Dimension and size bounds” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Dimension and size bounds” that realizes this source instruction: Validate dimensions, page counts and declared decoded sizes before allocation.
- [ ] **UC-M07.04-C022-T04 · Concrete realization:** Trace “Dimension and size bounds” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Dimension and size bounds” needed to preserve “Compact input cannot request unbounded decoded memory”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C022-T06 · Dependency connection:** Connect the “Dimension and size bounds” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C022-T07 · Resource behavior:** Account for “Pixels, pages and expanded bytes” in “Dimension and size bounds”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C022-T08 · Delivery check:** Run the smallest real “Dimension and size bounds” path and its adverse fixture “A small TIFF declares enormous dimensions”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C022-T09 · Patch review:** Review the “Dimension and size bounds” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C022-T10 · Delivery handoff:** Publish the “Dimension and size bounds” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Compact input cannot request unbounded decoded memory. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Dimension and size bounds”; copy its required invariant exactly: “Compact input cannot request unbounded decoded memory”.
- [ ] **UC-M07.04-C023-T02 · Observable terms:** Define each term in the “Dimension and size bounds” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C023-T03 · Precondition set:** List the preconditions under which “Compact input cannot request unbounded decoded memory” must hold for “Dimension and size bounds”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C023-T04 · Transition coverage:** Map the “Dimension and size bounds” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Dimension and size bounds”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C023-T06 · Satisfying fixture:** Create a concrete “Dimension and size bounds” case that satisfies “Compact input cannot request unbounded decoded memory”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C023-T07 · Violating fixture:** Create the source counterexample “A small TIFF declares enormous dimensions” for “Dimension and size bounds”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C023-T08 · Enforcement evidence:** Exercise the “Dimension and size bounds” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C023-T09 · Regression linkage:** Link the “Dimension and size bounds” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Dimension and size bounds” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C024 · Integration

**Original checklist item:** Integrate dimension and size bounds with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Dimension and size bounds” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C024-T02 · Field mapping:** Map every “Dimension and size bounds” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Dimension and size bounds” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C024-T04 · Ownership agreement:** Specify who owns “Dimension and size bounds” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C024-T05 · Handoff implementation:** Connect “Dimension and size bounds” through the mapped seam using the real adapter or explicit specification reference; preserve “Compact input cannot request unbounded decoded memory” across the handoff.
- [ ] **UC-M07.04-C024-T06 · Absent-input case:** Omit one required “Dimension and size bounds” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C024-T07 · Stale-input case:** Supply an outdated “Dimension and size bounds” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Dimension and size bounds” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C024-T09 · Valid integration trace:** Run a valid “Dimension and size bounds” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C024-T10 · Seam review:** Reconcile the “Dimension and size bounds” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for dimension and size bounds; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Dimension and size bounds” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C025-T02 · Expected-result oracle:** Specify the “Dimension and size bounds” expected result independently of the implementation output; include the property “Compact input cannot request unbounded decoded memory” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C025-T03 · Fixture material:** Create the concrete “Dimension and size bounds” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C025-T04 · Target preparation:** Prepare the “Dimension and size bounds” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C025-T05 · Initial-state record:** Record the initial “Dimension and size bounds” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C025-T06 · Valid-path execution:** Execute the “Dimension and size bounds” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C025-T07 · Outcome comparison:** Compare every declared “Dimension and size bounds” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C025-T08 · State and bounds check:** Inspect the “Dimension and size bounds” ownership/state effects and actual use of “Pixels, pages and expanded bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C025-T09 · Repeatability check:** Repeat the same “Dimension and size bounds” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C025-T10 · Positive evidence:** Attach the “Dimension and size bounds” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C026 · Negative test

**Original checklist item:** Negative case: A small TIFF declares enormous dimensions. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Dimension and size bounds” source counterexample: “A small TIFF declares enormous dimensions”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Dimension and size bounds”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C026-T03 · Valid control:** Construct a valid “Dimension and size bounds” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C026-T04 · Minimal adverse input:** Derive the “Dimension and size bounds” adverse fixture from the control with the smallest documented change needed to reproduce “A small TIFF declares enormous dimensions”; retain that change as reproducible data.
- [ ] **UC-M07.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Dimension and size bounds”; require “Compact input cannot request unbounded decoded memory” and forbid a false-success verdict.
- [ ] **UC-M07.04-C026-T06 · Adverse execution:** Exercise the “Dimension and size bounds” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C026-T07 · Effect inspection:** Inspect “Dimension and size bounds” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C026-T08 · Refusal versus failure:** Confirm the “Dimension and size bounds” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C026-T09 · Reset and retention:** Restore only the disposable “Dimension and size bounds” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C026-T10 · Negative regression:** Register the “Dimension and size bounds” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C027 · Change / failure test

**Original checklist item:** Exercise dimension and size bounds when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C027-T01 · Scenario record:** Write the “Dimension and size bounds” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “Compact input cannot request unbounded decoded memory”.
- [ ] **UC-M07.04-C027-T02 · Baseline capture:** Create a known-valid “Dimension and size bounds” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C027-T03 · Injection map:** Locate the “Dimension and size bounds” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Dimension and size bounds” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C027-T05 · Controlled trigger:** Introduce the controlled “Dimension and size bounds” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C027-T06 · Intermediate inspection:** Inspect the “Dimension and size bounds” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Dimension and size bounds”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Dimension and size bounds” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C027-T09 · Repeat and compare:** Repeat the selected “Dimension and size bounds” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C027-T10 · Failure evidence:** Publish the “Dimension and size bounds” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C028 · Bounds

**Original checklist item:** Choose, document and test limits for pixels, pages and expanded bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Dimension and size bounds”: “Pixels, pages and expanded bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C028-T02 · Measurement method:** Choose how to observe each “Dimension and size bounds” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C028-T03 · Budget decision:** Select justified resource and input limits for “Dimension and size bounds”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Dimension and size bounds” cases for “Pixels, pages and expanded bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Dimension and size bounds” limit; preserve “Compact input cannot request unbounded decoded memory”.
- [ ] **UC-M07.04-C028-T06 · Normal measurement:** Run or review the normal “Dimension and size bounds” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C028-T07 · At-limit measurement:** Exercise the “Dimension and size bounds” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C028-T08 · Over-limit measurement:** Exercise the “Dimension and size bounds” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C028-T09 · Uncovered-scope report:** List the “Dimension and size bounds” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C028-T10 · Limit evidence:** Publish the selected “Dimension and size bounds” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for dimension and size bounds with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C029-T01 · Event inventory:** List the “Dimension and size bounds” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Dimension and size bounds” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C029-T03 · Failure mapping:** Map each documented “Dimension and size bounds” refusal or error to a diagnostic outcome; include “A small TIFF declares enormous dimensions” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C029-T04 · Emission path:** Add the “Dimension and size bounds” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C029-T05 · Redaction check:** Test “Dimension and size bounds” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C029-T06 · Output budget:** Set and exercise bounded “Dimension and size bounds” message size, rate and retention compatible with “Pixels, pages and expanded bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C029-T07 · Success/refusal fixtures:** Capture “Dimension and size bounds” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Dimension and size bounds” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C029-T09 · Operator review:** Read the “Dimension and size bounds” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C029-T10 · Diagnostic evidence:** Publish redacted “Dimension and size bounds” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for dimension and size bounds; label unexecuted checks as untested.

- [ ] **UC-M07.04-C030-T01 · Evidence inventory:** List the “Dimension and size bounds” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C030-T02 · Artifact references:** Record the exact “Dimension and size bounds” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C030-T03 · Fixture references:** Attach the “Dimension and size bounds” fixture IDs, input identities and oracle definition; preserve the source counterexample “A small TIFF declares enormous dimensions” as a distinct evidence case.
- [ ] **UC-M07.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Dimension and size bounds”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C030-T05 · Environment record:** Record the actual “Dimension and size bounds” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C030-T06 · Expected versus observed:** Pair every “Dimension and size bounds” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C030-T07 · Failure and limit records:** Attach “Dimension and size bounds” change/failure and bounds evidence where required; include uncovered “Pixels, pages and expanded bytes” and unresolved violations of “Compact input cannot request unbounded decoded memory”.
- [ ] **UC-M07.04-C030-T08 · Evidence hygiene:** Check the “Dimension and size bounds” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C030-T09 · Reproduction review:** Have the “Dimension and size bounds” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C030-T10 · Acceptance linkage:** Link the “Dimension and size bounds” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Integer validation

**Source delivery:** Check widths, signs and arithmetic used by state metadata.

**Source invariant:** Integer overflow cannot bypass allocation or index limits.

**Source negative case:** A dimension multiplication wraps into a small accepted size.

**Source bounded quantities:** Integer widths and boundary cases.

### UC-M07.04-C031 · Contract

**Original checklist item:** Specify integer validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C031-T01 · Scope statement:** Draft the operation boundary for “Integer validation” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Integer validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C031-T03 · Output inventory:** List the outputs of “Integer validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Integer validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C031-T05 · Prerequisite contract:** Map “Integer validation” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Integer validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C031-T07 · Invariant clause:** Add a normative clause for “Integer validation” that preserves “Integer overflow cannot bypass allocation or index limits”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Integer validation”; include the source counterexample “A dimension multiplication wraps into a small accepted size” and the intended safe disposition.
- [ ] **UC-M07.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Integer widths and boundary cases” in the “Integer validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C031-T10 · Contract review:** Review the “Integer validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C032 · Delivery

**Original checklist item:** Check widths, signs and arithmetic used by state metadata.

- [ ] **UC-M07.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Integer validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C032-T02 · Change plan:** Break the source delivery for “Integer validation” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C032-T03 · Core artifact:** Create the “Integer validation” fixture or harness for this source instruction: Check widths, signs and arithmetic used by state metadata.
- [ ] **UC-M07.04-C032-T04 · Concrete realization:** Connect the “Integer validation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Integer validation” needed to preserve “Integer overflow cannot bypass allocation or index limits”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C032-T06 · Dependency connection:** Connect the “Integer validation” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C032-T07 · Resource behavior:** Account for “Integer widths and boundary cases” in “Integer validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C032-T08 · Delivery check:** Run the smallest real “Integer validation” path and its adverse fixture “A dimension multiplication wraps into a small accepted size”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C032-T09 · Patch review:** Review the “Integer validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C032-T10 · Delivery handoff:** Publish the “Integer validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Integer overflow cannot bypass allocation or index limits. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Integer validation”; copy its required invariant exactly: “Integer overflow cannot bypass allocation or index limits”.
- [ ] **UC-M07.04-C033-T02 · Observable terms:** Define each term in the “Integer validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C033-T03 · Precondition set:** List the preconditions under which “Integer overflow cannot bypass allocation or index limits” must hold for “Integer validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C033-T04 · Transition coverage:** Map the “Integer validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Integer validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C033-T06 · Satisfying fixture:** Create a concrete “Integer validation” case that satisfies “Integer overflow cannot bypass allocation or index limits”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C033-T07 · Violating fixture:** Create the source counterexample “A dimension multiplication wraps into a small accepted size” for “Integer validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C033-T08 · Enforcement evidence:** Exercise the “Integer validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C033-T09 · Regression linkage:** Link the “Integer validation” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Integer validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C034 · Integration

**Original checklist item:** Integrate integer validation with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Integer validation” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C034-T02 · Field mapping:** Map every “Integer validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Integer validation” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C034-T04 · Ownership agreement:** Specify who owns “Integer validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C034-T05 · Handoff implementation:** Connect “Integer validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Integer overflow cannot bypass allocation or index limits” across the handoff.
- [ ] **UC-M07.04-C034-T06 · Absent-input case:** Omit one required “Integer validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C034-T07 · Stale-input case:** Supply an outdated “Integer validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Integer validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C034-T09 · Valid integration trace:** Run a valid “Integer validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C034-T10 · Seam review:** Reconcile the “Integer validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for integer validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Integer validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C035-T02 · Expected-result oracle:** Specify the “Integer validation” expected result independently of the implementation output; include the property “Integer overflow cannot bypass allocation or index limits” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C035-T03 · Fixture material:** Create the concrete “Integer validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C035-T04 · Target preparation:** Prepare the “Integer validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C035-T05 · Initial-state record:** Record the initial “Integer validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C035-T06 · Valid-path execution:** Execute the “Integer validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C035-T07 · Outcome comparison:** Compare every declared “Integer validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C035-T08 · State and bounds check:** Inspect the “Integer validation” ownership/state effects and actual use of “Integer widths and boundary cases”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C035-T09 · Repeatability check:** Repeat the same “Integer validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C035-T10 · Positive evidence:** Attach the “Integer validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C036 · Negative test

**Original checklist item:** Negative case: A dimension multiplication wraps into a small accepted size. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Integer validation” source counterexample: “A dimension multiplication wraps into a small accepted size”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Integer validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C036-T03 · Valid control:** Construct a valid “Integer validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C036-T04 · Minimal adverse input:** Derive the “Integer validation” adverse fixture from the control with the smallest documented change needed to reproduce “A dimension multiplication wraps into a small accepted size”; retain that change as reproducible data.
- [ ] **UC-M07.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Integer validation”; require “Integer overflow cannot bypass allocation or index limits” and forbid a false-success verdict.
- [ ] **UC-M07.04-C036-T06 · Adverse execution:** Exercise the “Integer validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C036-T07 · Effect inspection:** Inspect “Integer validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C036-T08 · Refusal versus failure:** Confirm the “Integer validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C036-T09 · Reset and retention:** Restore only the disposable “Integer validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C036-T10 · Negative regression:** Register the “Integer validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C037 · Change / failure test

**Original checklist item:** Exercise integer validation when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C037-T01 · Scenario record:** Write the “Integer validation” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “Integer overflow cannot bypass allocation or index limits”.
- [ ] **UC-M07.04-C037-T02 · Baseline capture:** Create a known-valid “Integer validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C037-T03 · Injection map:** Locate the “Integer validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Integer validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C037-T05 · Controlled trigger:** Introduce the controlled “Integer validation” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C037-T06 · Intermediate inspection:** Inspect the “Integer validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Integer validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Integer validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C037-T09 · Repeat and compare:** Repeat the selected “Integer validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C037-T10 · Failure evidence:** Publish the “Integer validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C038 · Bounds

**Original checklist item:** Choose, document and test limits for integer widths and boundary cases; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Integer validation”: “Integer widths and boundary cases”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C038-T02 · Measurement method:** Choose how to observe each “Integer validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C038-T03 · Budget decision:** Select justified resource and input limits for “Integer validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Integer validation” cases for “Integer widths and boundary cases”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Integer validation” limit; preserve “Integer overflow cannot bypass allocation or index limits”.
- [ ] **UC-M07.04-C038-T06 · Normal measurement:** Run or review the normal “Integer validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C038-T07 · At-limit measurement:** Exercise the “Integer validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C038-T08 · Over-limit measurement:** Exercise the “Integer validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C038-T09 · Uncovered-scope report:** List the “Integer validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C038-T10 · Limit evidence:** Publish the selected “Integer validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for integer validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C039-T01 · Event inventory:** List the “Integer validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Integer validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C039-T03 · Failure mapping:** Map each documented “Integer validation” refusal or error to a diagnostic outcome; include “A dimension multiplication wraps into a small accepted size” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C039-T04 · Emission path:** Add the “Integer validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C039-T05 · Redaction check:** Test “Integer validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C039-T06 · Output budget:** Set and exercise bounded “Integer validation” message size, rate and retention compatible with “Integer widths and boundary cases”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C039-T07 · Success/refusal fixtures:** Capture “Integer validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Integer validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C039-T09 · Operator review:** Read the “Integer validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C039-T10 · Diagnostic evidence:** Publish redacted “Integer validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for integer validation; label unexecuted checks as untested.

- [ ] **UC-M07.04-C040-T01 · Evidence inventory:** List the “Integer validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C040-T02 · Artifact references:** Record the exact “Integer validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C040-T03 · Fixture references:** Attach the “Integer validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A dimension multiplication wraps into a small accepted size” as a distinct evidence case.
- [ ] **UC-M07.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Integer validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C040-T05 · Environment record:** Record the actual “Integer validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C040-T06 · Expected versus observed:** Pair every “Integer validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C040-T07 · Failure and limit records:** Attach “Integer validation” change/failure and bounds evidence where required; include uncovered “Integer widths and boundary cases” and unresolved violations of “Integer overflow cannot bypass allocation or index limits”.
- [ ] **UC-M07.04-C040-T08 · Evidence hygiene:** Check the “Integer validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C040-T09 · Reproduction review:** Have the “Integer validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C040-T10 · Acceptance linkage:** Link the “Integer validation” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Nested structure limits

**Source delivery:** Bound arrays, objects, nesting and reference expansion in state formats.

**Source invariant:** Deep or recursive structures cannot exhaust the worker.

**Source negative case:** Nested JSON exceeds the supported depth.

**Source bounded quantities:** Nesting depth and aggregate element count.

### UC-M07.04-C041 · Contract

**Original checklist item:** Specify nested structure limits inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C041-T01 · Scope statement:** Draft the operation boundary for “Nested structure limits” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Nested structure limits”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C041-T03 · Output inventory:** List the outputs of “Nested structure limits” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Nested structure limits”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C041-T05 · Prerequisite contract:** Map “Nested structure limits” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Nested structure limits”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C041-T07 · Invariant clause:** Add a normative clause for “Nested structure limits” that preserves “Deep or recursive structures cannot exhaust the worker”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Nested structure limits”; include the source counterexample “Nested JSON exceeds the supported depth” and the intended safe disposition.
- [ ] **UC-M07.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Nesting depth and aggregate element count” in the “Nested structure limits” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C041-T10 · Contract review:** Review the “Nested structure limits” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C042 · Delivery

**Original checklist item:** Bound arrays, objects, nesting and reference expansion in state formats.

- [ ] **UC-M07.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Nested structure limits”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C042-T02 · Change plan:** Break the source delivery for “Nested structure limits” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Nested structure limits” that realizes this source instruction: Bound arrays, objects, nesting and reference expansion in state formats.
- [ ] **UC-M07.04-C042-T04 · Concrete realization:** Trace “Nested structure limits” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Nested structure limits” needed to preserve “Deep or recursive structures cannot exhaust the worker”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C042-T06 · Dependency connection:** Connect the “Nested structure limits” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C042-T07 · Resource behavior:** Account for “Nesting depth and aggregate element count” in “Nested structure limits”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C042-T08 · Delivery check:** Run the smallest real “Nested structure limits” path and its adverse fixture “Nested JSON exceeds the supported depth”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C042-T09 · Patch review:** Review the “Nested structure limits” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C042-T10 · Delivery handoff:** Publish the “Nested structure limits” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Deep or recursive structures cannot exhaust the worker. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Nested structure limits”; copy its required invariant exactly: “Deep or recursive structures cannot exhaust the worker”.
- [ ] **UC-M07.04-C043-T02 · Observable terms:** Define each term in the “Nested structure limits” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C043-T03 · Precondition set:** List the preconditions under which “Deep or recursive structures cannot exhaust the worker” must hold for “Nested structure limits”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C043-T04 · Transition coverage:** Map the “Nested structure limits” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Nested structure limits”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C043-T06 · Satisfying fixture:** Create a concrete “Nested structure limits” case that satisfies “Deep or recursive structures cannot exhaust the worker”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C043-T07 · Violating fixture:** Create the source counterexample “Nested JSON exceeds the supported depth” for “Nested structure limits”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C043-T08 · Enforcement evidence:** Exercise the “Nested structure limits” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C043-T09 · Regression linkage:** Link the “Nested structure limits” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Nested structure limits” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C044 · Integration

**Original checklist item:** Integrate nested structure limits with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Nested structure limits” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C044-T02 · Field mapping:** Map every “Nested structure limits” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Nested structure limits” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C044-T04 · Ownership agreement:** Specify who owns “Nested structure limits” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C044-T05 · Handoff implementation:** Connect “Nested structure limits” through the mapped seam using the real adapter or explicit specification reference; preserve “Deep or recursive structures cannot exhaust the worker” across the handoff.
- [ ] **UC-M07.04-C044-T06 · Absent-input case:** Omit one required “Nested structure limits” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C044-T07 · Stale-input case:** Supply an outdated “Nested structure limits” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Nested structure limits” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C044-T09 · Valid integration trace:** Run a valid “Nested structure limits” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C044-T10 · Seam review:** Reconcile the “Nested structure limits” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for nested structure limits; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Nested structure limits” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C045-T02 · Expected-result oracle:** Specify the “Nested structure limits” expected result independently of the implementation output; include the property “Deep or recursive structures cannot exhaust the worker” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C045-T03 · Fixture material:** Create the concrete “Nested structure limits” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C045-T04 · Target preparation:** Prepare the “Nested structure limits” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C045-T05 · Initial-state record:** Record the initial “Nested structure limits” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C045-T06 · Valid-path execution:** Execute the “Nested structure limits” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C045-T07 · Outcome comparison:** Compare every declared “Nested structure limits” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C045-T08 · State and bounds check:** Inspect the “Nested structure limits” ownership/state effects and actual use of “Nesting depth and aggregate element count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C045-T09 · Repeatability check:** Repeat the same “Nested structure limits” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C045-T10 · Positive evidence:** Attach the “Nested structure limits” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C046 · Negative test

**Original checklist item:** Negative case: Nested JSON exceeds the supported depth. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Nested structure limits” source counterexample: “Nested JSON exceeds the supported depth”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Nested structure limits”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C046-T03 · Valid control:** Construct a valid “Nested structure limits” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C046-T04 · Minimal adverse input:** Derive the “Nested structure limits” adverse fixture from the control with the smallest documented change needed to reproduce “Nested JSON exceeds the supported depth”; retain that change as reproducible data.
- [ ] **UC-M07.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Nested structure limits”; require “Deep or recursive structures cannot exhaust the worker” and forbid a false-success verdict.
- [ ] **UC-M07.04-C046-T06 · Adverse execution:** Exercise the “Nested structure limits” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C046-T07 · Effect inspection:** Inspect “Nested structure limits” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C046-T08 · Refusal versus failure:** Confirm the “Nested structure limits” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C046-T09 · Reset and retention:** Restore only the disposable “Nested structure limits” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C046-T10 · Negative regression:** Register the “Nested structure limits” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C047 · Change / failure test

**Original checklist item:** Exercise nested structure limits when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C047-T01 · Scenario record:** Write the “Nested structure limits” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “Deep or recursive structures cannot exhaust the worker”.
- [ ] **UC-M07.04-C047-T02 · Baseline capture:** Create a known-valid “Nested structure limits” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C047-T03 · Injection map:** Locate the “Nested structure limits” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Nested structure limits” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C047-T05 · Controlled trigger:** Introduce the controlled “Nested structure limits” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C047-T06 · Intermediate inspection:** Inspect the “Nested structure limits” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Nested structure limits”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Nested structure limits” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C047-T09 · Repeat and compare:** Repeat the selected “Nested structure limits” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C047-T10 · Failure evidence:** Publish the “Nested structure limits” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C048 · Bounds

**Original checklist item:** Choose, document and test limits for nesting depth and aggregate element count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Nested structure limits”: “Nesting depth and aggregate element count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C048-T02 · Measurement method:** Choose how to observe each “Nested structure limits” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C048-T03 · Budget decision:** Select justified resource and input limits for “Nested structure limits”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Nested structure limits” cases for “Nesting depth and aggregate element count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Nested structure limits” limit; preserve “Deep or recursive structures cannot exhaust the worker”.
- [ ] **UC-M07.04-C048-T06 · Normal measurement:** Run or review the normal “Nested structure limits” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C048-T07 · At-limit measurement:** Exercise the “Nested structure limits” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C048-T08 · Over-limit measurement:** Exercise the “Nested structure limits” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C048-T09 · Uncovered-scope report:** List the “Nested structure limits” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C048-T10 · Limit evidence:** Publish the selected “Nested structure limits” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for nested structure limits with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C049-T01 · Event inventory:** List the “Nested structure limits” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Nested structure limits” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C049-T03 · Failure mapping:** Map each documented “Nested structure limits” refusal or error to a diagnostic outcome; include “Nested JSON exceeds the supported depth” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C049-T04 · Emission path:** Add the “Nested structure limits” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C049-T05 · Redaction check:** Test “Nested structure limits” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C049-T06 · Output budget:** Set and exercise bounded “Nested structure limits” message size, rate and retention compatible with “Nesting depth and aggregate element count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C049-T07 · Success/refusal fixtures:** Capture “Nested structure limits” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Nested structure limits” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C049-T09 · Operator review:** Read the “Nested structure limits” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C049-T10 · Diagnostic evidence:** Publish redacted “Nested structure limits” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for nested structure limits; label unexecuted checks as untested.

- [ ] **UC-M07.04-C050-T01 · Evidence inventory:** List the “Nested structure limits” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C050-T02 · Artifact references:** Record the exact “Nested structure limits” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C050-T03 · Fixture references:** Attach the “Nested structure limits” fixture IDs, input identities and oracle definition; preserve the source counterexample “Nested JSON exceeds the supported depth” as a distinct evidence case.
- [ ] **UC-M07.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Nested structure limits”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C050-T05 · Environment record:** Record the actual “Nested structure limits” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C050-T06 · Expected versus observed:** Pair every “Nested structure limits” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C050-T07 · Failure and limit records:** Attach “Nested structure limits” change/failure and bounds evidence where required; include uncovered “Nesting depth and aggregate element count” and unresolved violations of “Deep or recursive structures cannot exhaust the worker”.
- [ ] **UC-M07.04-C050-T08 · Evidence hygiene:** Check the “Nested structure limits” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C050-T09 · Reproduction review:** Have the “Nested structure limits” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C050-T10 · Acceptance linkage:** Link the “Nested structure limits” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Decoder worker isolation

**Source delivery:** Run untrusted decode work in resource-limited workers for the selected host.

**Source invariant:** A malformed state file cannot monopolize the management process.

**Source negative case:** A decoder hangs while the ship's main loop remains blocked.

**Source bounded quantities:** Worker memory, CPU and wall deadline.

### UC-M07.04-C051 · Contract

**Original checklist item:** Specify decoder worker isolation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C051-T01 · Scope statement:** Draft the operation boundary for “Decoder worker isolation” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Decoder worker isolation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C051-T03 · Output inventory:** List the outputs of “Decoder worker isolation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Decoder worker isolation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C051-T05 · Prerequisite contract:** Map “Decoder worker isolation” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Decoder worker isolation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C051-T07 · Invariant clause:** Add a normative clause for “Decoder worker isolation” that preserves “A malformed state file cannot monopolize the management process”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Decoder worker isolation”; include the source counterexample “A decoder hangs while the ship's main loop remains blocked” and the intended safe disposition.
- [ ] **UC-M07.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Worker memory, CPU and wall deadline” in the “Decoder worker isolation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C051-T10 · Contract review:** Review the “Decoder worker isolation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C052 · Delivery

**Original checklist item:** Run untrusted decode work in resource-limited workers for the selected host.

- [ ] **UC-M07.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Decoder worker isolation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C052-T02 · Change plan:** Break the source delivery for “Decoder worker isolation” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C052-T03 · Core artifact:** Create the “Decoder worker isolation” fixture or harness for this source instruction: Run untrusted decode work in resource-limited workers for the selected host.
- [ ] **UC-M07.04-C052-T04 · Concrete realization:** Connect the “Decoder worker isolation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Decoder worker isolation” needed to preserve “A malformed state file cannot monopolize the management process”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C052-T06 · Dependency connection:** Connect the “Decoder worker isolation” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C052-T07 · Resource behavior:** Account for “Worker memory, CPU and wall deadline” in “Decoder worker isolation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C052-T08 · Delivery check:** Run the smallest real “Decoder worker isolation” path and its adverse fixture “A decoder hangs while the ship's main loop remains blocked”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C052-T09 · Patch review:** Review the “Decoder worker isolation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C052-T10 · Delivery handoff:** Publish the “Decoder worker isolation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A malformed state file cannot monopolize the management process. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Decoder worker isolation”; copy its required invariant exactly: “A malformed state file cannot monopolize the management process”.
- [ ] **UC-M07.04-C053-T02 · Observable terms:** Define each term in the “Decoder worker isolation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C053-T03 · Precondition set:** List the preconditions under which “A malformed state file cannot monopolize the management process” must hold for “Decoder worker isolation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C053-T04 · Transition coverage:** Map the “Decoder worker isolation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Decoder worker isolation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C053-T06 · Satisfying fixture:** Create a concrete “Decoder worker isolation” case that satisfies “A malformed state file cannot monopolize the management process”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C053-T07 · Violating fixture:** Create the source counterexample “A decoder hangs while the ship's main loop remains blocked” for “Decoder worker isolation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C053-T08 · Enforcement evidence:** Exercise the “Decoder worker isolation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C053-T09 · Regression linkage:** Link the “Decoder worker isolation” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Decoder worker isolation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C054 · Integration

**Original checklist item:** Integrate decoder worker isolation with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Decoder worker isolation” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C054-T02 · Field mapping:** Map every “Decoder worker isolation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Decoder worker isolation” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C054-T04 · Ownership agreement:** Specify who owns “Decoder worker isolation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C054-T05 · Handoff implementation:** Connect “Decoder worker isolation” through the mapped seam using the real adapter or explicit specification reference; preserve “A malformed state file cannot monopolize the management process” across the handoff.
- [ ] **UC-M07.04-C054-T06 · Absent-input case:** Omit one required “Decoder worker isolation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C054-T07 · Stale-input case:** Supply an outdated “Decoder worker isolation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Decoder worker isolation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C054-T09 · Valid integration trace:** Run a valid “Decoder worker isolation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C054-T10 · Seam review:** Reconcile the “Decoder worker isolation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for decoder worker isolation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Decoder worker isolation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C055-T02 · Expected-result oracle:** Specify the “Decoder worker isolation” expected result independently of the implementation output; include the property “A malformed state file cannot monopolize the management process” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C055-T03 · Fixture material:** Create the concrete “Decoder worker isolation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C055-T04 · Target preparation:** Prepare the “Decoder worker isolation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C055-T05 · Initial-state record:** Record the initial “Decoder worker isolation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C055-T06 · Valid-path execution:** Execute the “Decoder worker isolation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C055-T07 · Outcome comparison:** Compare every declared “Decoder worker isolation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C055-T08 · State and bounds check:** Inspect the “Decoder worker isolation” ownership/state effects and actual use of “Worker memory, CPU and wall deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C055-T09 · Repeatability check:** Repeat the same “Decoder worker isolation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C055-T10 · Positive evidence:** Attach the “Decoder worker isolation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C056 · Negative test

**Original checklist item:** Negative case: A decoder hangs while the ship's main loop remains blocked. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Decoder worker isolation” source counterexample: “A decoder hangs while the ship's main loop remains blocked”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Decoder worker isolation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C056-T03 · Valid control:** Construct a valid “Decoder worker isolation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C056-T04 · Minimal adverse input:** Derive the “Decoder worker isolation” adverse fixture from the control with the smallest documented change needed to reproduce “A decoder hangs while the ship's main loop remains blocked”; retain that change as reproducible data.
- [ ] **UC-M07.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Decoder worker isolation”; require “A malformed state file cannot monopolize the management process” and forbid a false-success verdict.
- [ ] **UC-M07.04-C056-T06 · Adverse execution:** Exercise the “Decoder worker isolation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C056-T07 · Effect inspection:** Inspect “Decoder worker isolation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C056-T08 · Refusal versus failure:** Confirm the “Decoder worker isolation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C056-T09 · Reset and retention:** Restore only the disposable “Decoder worker isolation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C056-T10 · Negative regression:** Register the “Decoder worker isolation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C057 · Change / failure test

**Original checklist item:** Exercise decoder worker isolation when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C057-T01 · Scenario record:** Write the “Decoder worker isolation” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “A malformed state file cannot monopolize the management process”.
- [ ] **UC-M07.04-C057-T02 · Baseline capture:** Create a known-valid “Decoder worker isolation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C057-T03 · Injection map:** Locate the “Decoder worker isolation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Decoder worker isolation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C057-T05 · Controlled trigger:** Introduce the controlled “Decoder worker isolation” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C057-T06 · Intermediate inspection:** Inspect the “Decoder worker isolation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Decoder worker isolation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Decoder worker isolation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C057-T09 · Repeat and compare:** Repeat the selected “Decoder worker isolation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C057-T10 · Failure evidence:** Publish the “Decoder worker isolation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C058 · Bounds

**Original checklist item:** Choose, document and test limits for worker memory, CPU and wall deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Decoder worker isolation”: “Worker memory, CPU and wall deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C058-T02 · Measurement method:** Choose how to observe each “Decoder worker isolation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C058-T03 · Budget decision:** Select justified resource and input limits for “Decoder worker isolation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Decoder worker isolation” cases for “Worker memory, CPU and wall deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Decoder worker isolation” limit; preserve “A malformed state file cannot monopolize the management process”.
- [ ] **UC-M07.04-C058-T06 · Normal measurement:** Run or review the normal “Decoder worker isolation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C058-T07 · At-limit measurement:** Exercise the “Decoder worker isolation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C058-T08 · Over-limit measurement:** Exercise the “Decoder worker isolation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C058-T09 · Uncovered-scope report:** List the “Decoder worker isolation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C058-T10 · Limit evidence:** Publish the selected “Decoder worker isolation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for decoder worker isolation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C059-T01 · Event inventory:** List the “Decoder worker isolation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Decoder worker isolation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C059-T03 · Failure mapping:** Map each documented “Decoder worker isolation” refusal or error to a diagnostic outcome; include “A decoder hangs while the ship's main loop remains blocked” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C059-T04 · Emission path:** Add the “Decoder worker isolation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C059-T05 · Redaction check:** Test “Decoder worker isolation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C059-T06 · Output budget:** Set and exercise bounded “Decoder worker isolation” message size, rate and retention compatible with “Worker memory, CPU and wall deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C059-T07 · Success/refusal fixtures:** Capture “Decoder worker isolation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Decoder worker isolation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C059-T09 · Operator review:** Read the “Decoder worker isolation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C059-T10 · Diagnostic evidence:** Publish redacted “Decoder worker isolation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for decoder worker isolation; label unexecuted checks as untested.

- [ ] **UC-M07.04-C060-T01 · Evidence inventory:** List the “Decoder worker isolation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C060-T02 · Artifact references:** Record the exact “Decoder worker isolation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C060-T03 · Fixture references:** Attach the “Decoder worker isolation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A decoder hangs while the ship's main loop remains blocked” as a distinct evidence case.
- [ ] **UC-M07.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Decoder worker isolation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C060-T05 · Environment record:** Record the actual “Decoder worker isolation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C060-T06 · Expected versus observed:** Pair every “Decoder worker isolation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C060-T07 · Failure and limit records:** Attach “Decoder worker isolation” change/failure and bounds evidence where required; include uncovered “Worker memory, CPU and wall deadline” and unresolved violations of “A malformed state file cannot monopolize the management process”.
- [ ] **UC-M07.04-C060-T08 · Evidence hygiene:** Check the “Decoder worker isolation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C060-T09 · Reproduction review:** Have the “Decoder worker isolation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C060-T10 · Acceptance linkage:** Link the “Decoder worker isolation” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Error disposition

**Source delivery:** Return typed bounded validation errors without publishing partial state.

**Source invariant:** Decoder refusal does not create a valid-looking restored object.

**Source negative case:** Parsing fails after a partially constructed state is registered.

**Source bounded quantities:** Error bytes and cleanup deadline.

### UC-M07.04-C061 · Contract

**Original checklist item:** Specify error disposition inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C061-T01 · Scope statement:** Draft the operation boundary for “Error disposition” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Error disposition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C061-T03 · Output inventory:** List the outputs of “Error disposition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Error disposition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C061-T05 · Prerequisite contract:** Map “Error disposition” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Error disposition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C061-T07 · Invariant clause:** Add a normative clause for “Error disposition” that preserves “Decoder refusal does not create a valid-looking restored object”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Error disposition”; include the source counterexample “Parsing fails after a partially constructed state is registered” and the intended safe disposition.
- [ ] **UC-M07.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Error bytes and cleanup deadline” in the “Error disposition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C061-T10 · Contract review:** Review the “Error disposition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C062 · Delivery

**Original checklist item:** Return typed bounded validation errors without publishing partial state.

- [ ] **UC-M07.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Error disposition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C062-T02 · Change plan:** Break the source delivery for “Error disposition” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Error disposition” that realizes this source instruction: Return typed bounded validation errors without publishing partial state.
- [ ] **UC-M07.04-C062-T04 · Concrete realization:** Trace “Error disposition” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Error disposition” needed to preserve “Decoder refusal does not create a valid-looking restored object”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C062-T06 · Dependency connection:** Connect the “Error disposition” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C062-T07 · Resource behavior:** Account for “Error bytes and cleanup deadline” in “Error disposition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C062-T08 · Delivery check:** Run the smallest real “Error disposition” path and its adverse fixture “Parsing fails after a partially constructed state is registered”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C062-T09 · Patch review:** Review the “Error disposition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C062-T10 · Delivery handoff:** Publish the “Error disposition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Decoder refusal does not create a valid-looking restored object. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Error disposition”; copy its required invariant exactly: “Decoder refusal does not create a valid-looking restored object”.
- [ ] **UC-M07.04-C063-T02 · Observable terms:** Define each term in the “Error disposition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C063-T03 · Precondition set:** List the preconditions under which “Decoder refusal does not create a valid-looking restored object” must hold for “Error disposition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C063-T04 · Transition coverage:** Map the “Error disposition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Error disposition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C063-T06 · Satisfying fixture:** Create a concrete “Error disposition” case that satisfies “Decoder refusal does not create a valid-looking restored object”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C063-T07 · Violating fixture:** Create the source counterexample “Parsing fails after a partially constructed state is registered” for “Error disposition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C063-T08 · Enforcement evidence:** Exercise the “Error disposition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C063-T09 · Regression linkage:** Link the “Error disposition” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Error disposition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C064 · Integration

**Original checklist item:** Integrate error disposition with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Error disposition” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C064-T02 · Field mapping:** Map every “Error disposition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Error disposition” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C064-T04 · Ownership agreement:** Specify who owns “Error disposition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C064-T05 · Handoff implementation:** Connect “Error disposition” through the mapped seam using the real adapter or explicit specification reference; preserve “Decoder refusal does not create a valid-looking restored object” across the handoff.
- [ ] **UC-M07.04-C064-T06 · Absent-input case:** Omit one required “Error disposition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C064-T07 · Stale-input case:** Supply an outdated “Error disposition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Error disposition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C064-T09 · Valid integration trace:** Run a valid “Error disposition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C064-T10 · Seam review:** Reconcile the “Error disposition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for error disposition; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Error disposition” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C065-T02 · Expected-result oracle:** Specify the “Error disposition” expected result independently of the implementation output; include the property “Decoder refusal does not create a valid-looking restored object” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C065-T03 · Fixture material:** Create the concrete “Error disposition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C065-T04 · Target preparation:** Prepare the “Error disposition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C065-T05 · Initial-state record:** Record the initial “Error disposition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C065-T06 · Valid-path execution:** Execute the “Error disposition” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C065-T07 · Outcome comparison:** Compare every declared “Error disposition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C065-T08 · State and bounds check:** Inspect the “Error disposition” ownership/state effects and actual use of “Error bytes and cleanup deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C065-T09 · Repeatability check:** Repeat the same “Error disposition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C065-T10 · Positive evidence:** Attach the “Error disposition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C066 · Negative test

**Original checklist item:** Negative case: Parsing fails after a partially constructed state is registered. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Error disposition” source counterexample: “Parsing fails after a partially constructed state is registered”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Error disposition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C066-T03 · Valid control:** Construct a valid “Error disposition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C066-T04 · Minimal adverse input:** Derive the “Error disposition” adverse fixture from the control with the smallest documented change needed to reproduce “Parsing fails after a partially constructed state is registered”; retain that change as reproducible data.
- [ ] **UC-M07.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Error disposition”; require “Decoder refusal does not create a valid-looking restored object” and forbid a false-success verdict.
- [ ] **UC-M07.04-C066-T06 · Adverse execution:** Exercise the “Error disposition” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C066-T07 · Effect inspection:** Inspect “Error disposition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C066-T08 · Refusal versus failure:** Confirm the “Error disposition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C066-T09 · Reset and retention:** Restore only the disposable “Error disposition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C066-T10 · Negative regression:** Register the “Error disposition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C067 · Change / failure test

**Original checklist item:** Exercise error disposition when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C067-T01 · Scenario record:** Write the “Error disposition” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “Decoder refusal does not create a valid-looking restored object”.
- [ ] **UC-M07.04-C067-T02 · Baseline capture:** Create a known-valid “Error disposition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C067-T03 · Injection map:** Locate the “Error disposition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Error disposition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C067-T05 · Controlled trigger:** Introduce the controlled “Error disposition” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C067-T06 · Intermediate inspection:** Inspect the “Error disposition” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Error disposition”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Error disposition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C067-T09 · Repeat and compare:** Repeat the selected “Error disposition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C067-T10 · Failure evidence:** Publish the “Error disposition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C068 · Bounds

**Original checklist item:** Choose, document and test limits for error bytes and cleanup deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Error disposition”: “Error bytes and cleanup deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C068-T02 · Measurement method:** Choose how to observe each “Error disposition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C068-T03 · Budget decision:** Select justified resource and input limits for “Error disposition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Error disposition” cases for “Error bytes and cleanup deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Error disposition” limit; preserve “Decoder refusal does not create a valid-looking restored object”.
- [ ] **UC-M07.04-C068-T06 · Normal measurement:** Run or review the normal “Error disposition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C068-T07 · At-limit measurement:** Exercise the “Error disposition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C068-T08 · Over-limit measurement:** Exercise the “Error disposition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C068-T09 · Uncovered-scope report:** List the “Error disposition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C068-T10 · Limit evidence:** Publish the selected “Error disposition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for error disposition with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C069-T01 · Event inventory:** List the “Error disposition” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Error disposition” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C069-T03 · Failure mapping:** Map each documented “Error disposition” refusal or error to a diagnostic outcome; include “Parsing fails after a partially constructed state is registered” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C069-T04 · Emission path:** Add the “Error disposition” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C069-T05 · Redaction check:** Test “Error disposition” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C069-T06 · Output budget:** Set and exercise bounded “Error disposition” message size, rate and retention compatible with “Error bytes and cleanup deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C069-T07 · Success/refusal fixtures:** Capture “Error disposition” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Error disposition” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C069-T09 · Operator review:** Read the “Error disposition” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C069-T10 · Diagnostic evidence:** Publish redacted “Error disposition” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for error disposition; label unexecuted checks as untested.

- [ ] **UC-M07.04-C070-T01 · Evidence inventory:** List the “Error disposition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C070-T02 · Artifact references:** Record the exact “Error disposition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C070-T03 · Fixture references:** Attach the “Error disposition” fixture IDs, input identities and oracle definition; preserve the source counterexample “Parsing fails after a partially constructed state is registered” as a distinct evidence case.
- [ ] **UC-M07.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Error disposition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C070-T05 · Environment record:** Record the actual “Error disposition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C070-T06 · Expected versus observed:** Pair every “Error disposition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C070-T07 · Failure and limit records:** Attach “Error disposition” change/failure and bounds evidence where required; include uncovered “Error bytes and cleanup deadline” and unresolved violations of “Decoder refusal does not create a valid-looking restored object”.
- [ ] **UC-M07.04-C070-T08 · Evidence hygiene:** Check the “Error disposition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C070-T09 · Reproduction review:** Have the “Error disposition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C070-T10 · Acceptance linkage:** Link the “Error disposition” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Embedded decoder parity

**Source delivery:** Apply the same required bounds to bundled hull and helper decoding paths.

**Source invariant:** An alternate embedded path cannot bypass ship-level restrictions.

**Source negative case:** An import uses an older unrestricted hull decoder.

**Source bounded quantities:** Embedded paths and conformance fixtures.

### UC-M07.04-C071 · Contract

**Original checklist item:** Specify embedded decoder parity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C071-T01 · Scope statement:** Draft the operation boundary for “Embedded decoder parity” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Embedded decoder parity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C071-T03 · Output inventory:** List the outputs of “Embedded decoder parity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Embedded decoder parity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C071-T05 · Prerequisite contract:** Map “Embedded decoder parity” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Embedded decoder parity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C071-T07 · Invariant clause:** Add a normative clause for “Embedded decoder parity” that preserves “An alternate embedded path cannot bypass ship-level restrictions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Embedded decoder parity”; include the source counterexample “An import uses an older unrestricted hull decoder” and the intended safe disposition.
- [ ] **UC-M07.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Embedded paths and conformance fixtures” in the “Embedded decoder parity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C071-T10 · Contract review:** Review the “Embedded decoder parity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C072 · Delivery

**Original checklist item:** Apply the same required bounds to bundled hull and helper decoding paths.

- [ ] **UC-M07.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Embedded decoder parity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C072-T02 · Change plan:** Break the source delivery for “Embedded decoder parity” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Embedded decoder parity” that realizes this source instruction: Apply the same required bounds to bundled hull and helper decoding paths.
- [ ] **UC-M07.04-C072-T04 · Concrete realization:** Trace “Embedded decoder parity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Embedded decoder parity” needed to preserve “An alternate embedded path cannot bypass ship-level restrictions”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C072-T06 · Dependency connection:** Connect the “Embedded decoder parity” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C072-T07 · Resource behavior:** Account for “Embedded paths and conformance fixtures” in “Embedded decoder parity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C072-T08 · Delivery check:** Run the smallest real “Embedded decoder parity” path and its adverse fixture “An import uses an older unrestricted hull decoder”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C072-T09 · Patch review:** Review the “Embedded decoder parity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C072-T10 · Delivery handoff:** Publish the “Embedded decoder parity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An alternate embedded path cannot bypass ship-level restrictions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Embedded decoder parity”; copy its required invariant exactly: “An alternate embedded path cannot bypass ship-level restrictions”.
- [ ] **UC-M07.04-C073-T02 · Observable terms:** Define each term in the “Embedded decoder parity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C073-T03 · Precondition set:** List the preconditions under which “An alternate embedded path cannot bypass ship-level restrictions” must hold for “Embedded decoder parity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C073-T04 · Transition coverage:** Map the “Embedded decoder parity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Embedded decoder parity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C073-T06 · Satisfying fixture:** Create a concrete “Embedded decoder parity” case that satisfies “An alternate embedded path cannot bypass ship-level restrictions”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C073-T07 · Violating fixture:** Create the source counterexample “An import uses an older unrestricted hull decoder” for “Embedded decoder parity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C073-T08 · Enforcement evidence:** Exercise the “Embedded decoder parity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C073-T09 · Regression linkage:** Link the “Embedded decoder parity” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Embedded decoder parity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C074 · Integration

**Original checklist item:** Integrate embedded decoder parity with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Embedded decoder parity” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C074-T02 · Field mapping:** Map every “Embedded decoder parity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Embedded decoder parity” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C074-T04 · Ownership agreement:** Specify who owns “Embedded decoder parity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C074-T05 · Handoff implementation:** Connect “Embedded decoder parity” through the mapped seam using the real adapter or explicit specification reference; preserve “An alternate embedded path cannot bypass ship-level restrictions” across the handoff.
- [ ] **UC-M07.04-C074-T06 · Absent-input case:** Omit one required “Embedded decoder parity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C074-T07 · Stale-input case:** Supply an outdated “Embedded decoder parity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Embedded decoder parity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C074-T09 · Valid integration trace:** Run a valid “Embedded decoder parity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C074-T10 · Seam review:** Reconcile the “Embedded decoder parity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for embedded decoder parity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Embedded decoder parity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C075-T02 · Expected-result oracle:** Specify the “Embedded decoder parity” expected result independently of the implementation output; include the property “An alternate embedded path cannot bypass ship-level restrictions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C075-T03 · Fixture material:** Create the concrete “Embedded decoder parity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C075-T04 · Target preparation:** Prepare the “Embedded decoder parity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C075-T05 · Initial-state record:** Record the initial “Embedded decoder parity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C075-T06 · Valid-path execution:** Execute the “Embedded decoder parity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C075-T07 · Outcome comparison:** Compare every declared “Embedded decoder parity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C075-T08 · State and bounds check:** Inspect the “Embedded decoder parity” ownership/state effects and actual use of “Embedded paths and conformance fixtures”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C075-T09 · Repeatability check:** Repeat the same “Embedded decoder parity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C075-T10 · Positive evidence:** Attach the “Embedded decoder parity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C076 · Negative test

**Original checklist item:** Negative case: An import uses an older unrestricted hull decoder. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Embedded decoder parity” source counterexample: “An import uses an older unrestricted hull decoder”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Embedded decoder parity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C076-T03 · Valid control:** Construct a valid “Embedded decoder parity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C076-T04 · Minimal adverse input:** Derive the “Embedded decoder parity” adverse fixture from the control with the smallest documented change needed to reproduce “An import uses an older unrestricted hull decoder”; retain that change as reproducible data.
- [ ] **UC-M07.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Embedded decoder parity”; require “An alternate embedded path cannot bypass ship-level restrictions” and forbid a false-success verdict.
- [ ] **UC-M07.04-C076-T06 · Adverse execution:** Exercise the “Embedded decoder parity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C076-T07 · Effect inspection:** Inspect “Embedded decoder parity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C076-T08 · Refusal versus failure:** Confirm the “Embedded decoder parity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C076-T09 · Reset and retention:** Restore only the disposable “Embedded decoder parity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C076-T10 · Negative regression:** Register the “Embedded decoder parity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C077 · Change / failure test

**Original checklist item:** Exercise embedded decoder parity when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C077-T01 · Scenario record:** Write the “Embedded decoder parity” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “An alternate embedded path cannot bypass ship-level restrictions”.
- [ ] **UC-M07.04-C077-T02 · Baseline capture:** Create a known-valid “Embedded decoder parity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C077-T03 · Injection map:** Locate the “Embedded decoder parity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Embedded decoder parity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C077-T05 · Controlled trigger:** Introduce the controlled “Embedded decoder parity” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C077-T06 · Intermediate inspection:** Inspect the “Embedded decoder parity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Embedded decoder parity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Embedded decoder parity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C077-T09 · Repeat and compare:** Repeat the selected “Embedded decoder parity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C077-T10 · Failure evidence:** Publish the “Embedded decoder parity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C078 · Bounds

**Original checklist item:** Choose, document and test limits for embedded paths and conformance fixtures; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Embedded decoder parity”: “Embedded paths and conformance fixtures”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C078-T02 · Measurement method:** Choose how to observe each “Embedded decoder parity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C078-T03 · Budget decision:** Select justified resource and input limits for “Embedded decoder parity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Embedded decoder parity” cases for “Embedded paths and conformance fixtures”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Embedded decoder parity” limit; preserve “An alternate embedded path cannot bypass ship-level restrictions”.
- [ ] **UC-M07.04-C078-T06 · Normal measurement:** Run or review the normal “Embedded decoder parity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C078-T07 · At-limit measurement:** Exercise the “Embedded decoder parity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C078-T08 · Over-limit measurement:** Exercise the “Embedded decoder parity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C078-T09 · Uncovered-scope report:** List the “Embedded decoder parity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C078-T10 · Limit evidence:** Publish the selected “Embedded decoder parity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for embedded decoder parity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C079-T01 · Event inventory:** List the “Embedded decoder parity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Embedded decoder parity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C079-T03 · Failure mapping:** Map each documented “Embedded decoder parity” refusal or error to a diagnostic outcome; include “An import uses an older unrestricted hull decoder” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C079-T04 · Emission path:** Add the “Embedded decoder parity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C079-T05 · Redaction check:** Test “Embedded decoder parity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C079-T06 · Output budget:** Set and exercise bounded “Embedded decoder parity” message size, rate and retention compatible with “Embedded paths and conformance fixtures”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C079-T07 · Success/refusal fixtures:** Capture “Embedded decoder parity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Embedded decoder parity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C079-T09 · Operator review:** Read the “Embedded decoder parity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C079-T10 · Diagnostic evidence:** Publish redacted “Embedded decoder parity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for embedded decoder parity; label unexecuted checks as untested.

- [ ] **UC-M07.04-C080-T01 · Evidence inventory:** List the “Embedded decoder parity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C080-T02 · Artifact references:** Record the exact “Embedded decoder parity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C080-T03 · Fixture references:** Attach the “Embedded decoder parity” fixture IDs, input identities and oracle definition; preserve the source counterexample “An import uses an older unrestricted hull decoder” as a distinct evidence case.
- [ ] **UC-M07.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Embedded decoder parity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C080-T05 · Environment record:** Record the actual “Embedded decoder parity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C080-T06 · Expected versus observed:** Pair every “Embedded decoder parity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C080-T07 · Failure and limit records:** Attach “Embedded decoder parity” change/failure and bounds evidence where required; include uncovered “Embedded paths and conformance fixtures” and unresolved violations of “An alternate embedded path cannot bypass ship-level restrictions”.
- [ ] **UC-M07.04-C080-T08 · Evidence hygiene:** Check the “Embedded decoder parity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C080-T09 · Reproduction review:** Have the “Embedded decoder parity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C080-T10 · Acceptance linkage:** Link the “Embedded decoder parity” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Malformed-state corpus

**Source delivery:** Retain reproducible malformed dimensions, metadata and nested-structure fixtures.

**Source invariant:** Every known decoder failure has a bounded reproducible regression.

**Source negative case:** An oversized image fixture causes an unbounded allocation.

**Source bounded quantities:** Corpus bytes and per-case timeout.

### UC-M07.04-C081 · Contract

**Original checklist item:** Specify malformed-state corpus inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C081-T01 · Scope statement:** Draft the operation boundary for “Malformed-state corpus” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Malformed-state corpus”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C081-T03 · Output inventory:** List the outputs of “Malformed-state corpus” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Malformed-state corpus”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C081-T05 · Prerequisite contract:** Map “Malformed-state corpus” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Malformed-state corpus”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C081-T07 · Invariant clause:** Add a normative clause for “Malformed-state corpus” that preserves “Every known decoder failure has a bounded reproducible regression”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Malformed-state corpus”; include the source counterexample “An oversized image fixture causes an unbounded allocation” and the intended safe disposition.
- [ ] **UC-M07.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Corpus bytes and per-case timeout” in the “Malformed-state corpus” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C081-T10 · Contract review:** Review the “Malformed-state corpus” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C082 · Delivery

**Original checklist item:** Retain reproducible malformed dimensions, metadata and nested-structure fixtures.

- [ ] **UC-M07.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Malformed-state corpus”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C082-T02 · Change plan:** Break the source delivery for “Malformed-state corpus” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Malformed-state corpus” that realizes this source instruction: Retain reproducible malformed dimensions, metadata and nested-structure fixtures.
- [ ] **UC-M07.04-C082-T04 · Concrete realization:** Trace “Malformed-state corpus” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Malformed-state corpus” needed to preserve “Every known decoder failure has a bounded reproducible regression”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C082-T06 · Dependency connection:** Connect the “Malformed-state corpus” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C082-T07 · Resource behavior:** Account for “Corpus bytes and per-case timeout” in “Malformed-state corpus”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C082-T08 · Delivery check:** Run the smallest real “Malformed-state corpus” path and its adverse fixture “An oversized image fixture causes an unbounded allocation”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C082-T09 · Patch review:** Review the “Malformed-state corpus” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C082-T10 · Delivery handoff:** Publish the “Malformed-state corpus” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every known decoder failure has a bounded reproducible regression. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Malformed-state corpus”; copy its required invariant exactly: “Every known decoder failure has a bounded reproducible regression”.
- [ ] **UC-M07.04-C083-T02 · Observable terms:** Define each term in the “Malformed-state corpus” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C083-T03 · Precondition set:** List the preconditions under which “Every known decoder failure has a bounded reproducible regression” must hold for “Malformed-state corpus”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C083-T04 · Transition coverage:** Map the “Malformed-state corpus” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Malformed-state corpus”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C083-T06 · Satisfying fixture:** Create a concrete “Malformed-state corpus” case that satisfies “Every known decoder failure has a bounded reproducible regression”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C083-T07 · Violating fixture:** Create the source counterexample “An oversized image fixture causes an unbounded allocation” for “Malformed-state corpus”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C083-T08 · Enforcement evidence:** Exercise the “Malformed-state corpus” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C083-T09 · Regression linkage:** Link the “Malformed-state corpus” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Malformed-state corpus” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C084 · Integration

**Original checklist item:** Integrate malformed-state corpus with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Malformed-state corpus” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C084-T02 · Field mapping:** Map every “Malformed-state corpus” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Malformed-state corpus” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C084-T04 · Ownership agreement:** Specify who owns “Malformed-state corpus” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C084-T05 · Handoff implementation:** Connect “Malformed-state corpus” through the mapped seam using the real adapter or explicit specification reference; preserve “Every known decoder failure has a bounded reproducible regression” across the handoff.
- [ ] **UC-M07.04-C084-T06 · Absent-input case:** Omit one required “Malformed-state corpus” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C084-T07 · Stale-input case:** Supply an outdated “Malformed-state corpus” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Malformed-state corpus” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C084-T09 · Valid integration trace:** Run a valid “Malformed-state corpus” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C084-T10 · Seam review:** Reconcile the “Malformed-state corpus” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for malformed-state corpus; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Malformed-state corpus” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C085-T02 · Expected-result oracle:** Specify the “Malformed-state corpus” expected result independently of the implementation output; include the property “Every known decoder failure has a bounded reproducible regression” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C085-T03 · Fixture material:** Create the concrete “Malformed-state corpus” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C085-T04 · Target preparation:** Prepare the “Malformed-state corpus” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C085-T05 · Initial-state record:** Record the initial “Malformed-state corpus” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C085-T06 · Valid-path execution:** Execute the “Malformed-state corpus” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C085-T07 · Outcome comparison:** Compare every declared “Malformed-state corpus” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C085-T08 · State and bounds check:** Inspect the “Malformed-state corpus” ownership/state effects and actual use of “Corpus bytes and per-case timeout”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C085-T09 · Repeatability check:** Repeat the same “Malformed-state corpus” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C085-T10 · Positive evidence:** Attach the “Malformed-state corpus” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C086 · Negative test

**Original checklist item:** Negative case: An oversized image fixture causes an unbounded allocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Malformed-state corpus” source counterexample: “An oversized image fixture causes an unbounded allocation”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Malformed-state corpus”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C086-T03 · Valid control:** Construct a valid “Malformed-state corpus” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C086-T04 · Minimal adverse input:** Derive the “Malformed-state corpus” adverse fixture from the control with the smallest documented change needed to reproduce “An oversized image fixture causes an unbounded allocation”; retain that change as reproducible data.
- [ ] **UC-M07.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Malformed-state corpus”; require “Every known decoder failure has a bounded reproducible regression” and forbid a false-success verdict.
- [ ] **UC-M07.04-C086-T06 · Adverse execution:** Exercise the “Malformed-state corpus” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C086-T07 · Effect inspection:** Inspect “Malformed-state corpus” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C086-T08 · Refusal versus failure:** Confirm the “Malformed-state corpus” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C086-T09 · Reset and retention:** Restore only the disposable “Malformed-state corpus” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C086-T10 · Negative regression:** Register the “Malformed-state corpus” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C087 · Change / failure test

**Original checklist item:** Exercise malformed-state corpus when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C087-T01 · Scenario record:** Write the “Malformed-state corpus” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “Every known decoder failure has a bounded reproducible regression”.
- [ ] **UC-M07.04-C087-T02 · Baseline capture:** Create a known-valid “Malformed-state corpus” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C087-T03 · Injection map:** Locate the “Malformed-state corpus” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Malformed-state corpus” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C087-T05 · Controlled trigger:** Introduce the controlled “Malformed-state corpus” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C087-T06 · Intermediate inspection:** Inspect the “Malformed-state corpus” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Malformed-state corpus”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Malformed-state corpus” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C087-T09 · Repeat and compare:** Repeat the selected “Malformed-state corpus” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C087-T10 · Failure evidence:** Publish the “Malformed-state corpus” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C088 · Bounds

**Original checklist item:** Choose, document and test limits for corpus bytes and per-case timeout; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Malformed-state corpus”: “Corpus bytes and per-case timeout”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C088-T02 · Measurement method:** Choose how to observe each “Malformed-state corpus” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C088-T03 · Budget decision:** Select justified resource and input limits for “Malformed-state corpus”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Malformed-state corpus” cases for “Corpus bytes and per-case timeout”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Malformed-state corpus” limit; preserve “Every known decoder failure has a bounded reproducible regression”.
- [ ] **UC-M07.04-C088-T06 · Normal measurement:** Run or review the normal “Malformed-state corpus” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C088-T07 · At-limit measurement:** Exercise the “Malformed-state corpus” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C088-T08 · Over-limit measurement:** Exercise the “Malformed-state corpus” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C088-T09 · Uncovered-scope report:** List the “Malformed-state corpus” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C088-T10 · Limit evidence:** Publish the selected “Malformed-state corpus” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for malformed-state corpus with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C089-T01 · Event inventory:** List the “Malformed-state corpus” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Malformed-state corpus” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C089-T03 · Failure mapping:** Map each documented “Malformed-state corpus” refusal or error to a diagnostic outcome; include “An oversized image fixture causes an unbounded allocation” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C089-T04 · Emission path:** Add the “Malformed-state corpus” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C089-T05 · Redaction check:** Test “Malformed-state corpus” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C089-T06 · Output budget:** Set and exercise bounded “Malformed-state corpus” message size, rate and retention compatible with “Corpus bytes and per-case timeout”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C089-T07 · Success/refusal fixtures:** Capture “Malformed-state corpus” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Malformed-state corpus” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C089-T09 · Operator review:** Read the “Malformed-state corpus” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C089-T10 · Diagnostic evidence:** Publish redacted “Malformed-state corpus” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for malformed-state corpus; label unexecuted checks as untested.

- [ ] **UC-M07.04-C090-T01 · Evidence inventory:** List the “Malformed-state corpus” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C090-T02 · Artifact references:** Record the exact “Malformed-state corpus” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C090-T03 · Fixture references:** Attach the “Malformed-state corpus” fixture IDs, input identities and oracle definition; preserve the source counterexample “An oversized image fixture causes an unbounded allocation” as a distinct evidence case.
- [ ] **UC-M07.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Malformed-state corpus”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C090-T05 · Environment record:** Record the actual “Malformed-state corpus” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C090-T06 · Expected versus observed:** Pair every “Malformed-state corpus” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C090-T07 · Failure and limit records:** Attach “Malformed-state corpus” change/failure and bounds evidence where required; include uncovered “Corpus bytes and per-case timeout” and unresolved violations of “Every known decoder failure has a bounded reproducible regression”.
- [ ] **UC-M07.04-C090-T08 · Evidence hygiene:** Check the “Malformed-state corpus” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C090-T09 · Reproduction review:** Have the “Malformed-state corpus” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C090-T10 · Acceptance linkage:** Link the “Malformed-state corpus” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Decoder acceptance gate

**Source delivery:** Verify valid state and malformed input under actual worker limits.

**Source invariant:** Passing schema checks alone does not establish bounded decoding.

**Source negative case:** A valid header triggers an excessive allocation later in decoding.

**Source bounded quantities:** Formats, worker profiles and measurement duration.

### UC-M07.04-C091 · Contract

**Original checklist item:** Specify decoder acceptance gate inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.04-C091-T01 · Scope statement:** Draft the operation boundary for “Decoder acceptance gate” within Strict state schema and decoder boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Decoder acceptance gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.04-C091-T03 · Output inventory:** List the outputs of “Decoder acceptance gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Decoder acceptance gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.04-C091-T05 · Prerequisite contract:** Map “Decoder acceptance gate” to the source component prerequisites (UC-M03.05, UC-M07.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Decoder acceptance gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.04-C091-T07 · Invariant clause:** Add a normative clause for “Decoder acceptance gate” that preserves “Passing schema checks alone does not establish bounded decoding”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Decoder acceptance gate”; include the source counterexample “A valid header triggers an excessive allocation later in decoding” and the intended safe disposition.
- [ ] **UC-M07.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Formats, worker profiles and measurement duration” in the “Decoder acceptance gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.04-C091-T10 · Contract review:** Review the “Decoder acceptance gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.04-C092 · Delivery

**Original checklist item:** Verify valid state and malformed input under actual worker limits.

- [ ] **UC-M07.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Decoder acceptance gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.04-C092-T02 · Change plan:** Break the source delivery for “Decoder acceptance gate” into concrete edit targets and reviewable outputs; keep the UC-M07.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.04-C092-T03 · Core artifact:** Create the “Decoder acceptance gate” fixture or harness for this source instruction: Verify valid state and malformed input under actual worker limits.
- [ ] **UC-M07.04-C092-T04 · Concrete realization:** Connect the “Decoder acceptance gate” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Decoder acceptance gate” needed to preserve “Passing schema checks alone does not establish bounded decoding”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.04-C092-T06 · Dependency connection:** Connect the “Decoder acceptance gate” implementation to state import, previews, embedded hull decoders and bounded worker execution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.04-C092-T07 · Resource behavior:** Account for “Formats, worker profiles and measurement duration” in “Decoder acceptance gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.04-C092-T08 · Delivery check:** Run the smallest real “Decoder acceptance gate” path and its adverse fixture “A valid header triggers an excessive allocation later in decoding”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.04-C092-T09 · Patch review:** Review the “Decoder acceptance gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.04-C092-T10 · Delivery handoff:** Publish the “Decoder acceptance gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Passing schema checks alone does not establish bounded decoding. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Decoder acceptance gate”; copy its required invariant exactly: “Passing schema checks alone does not establish bounded decoding”.
- [ ] **UC-M07.04-C093-T02 · Observable terms:** Define each term in the “Decoder acceptance gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.04-C093-T03 · Precondition set:** List the preconditions under which “Passing schema checks alone does not establish bounded decoding” must hold for “Decoder acceptance gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.04-C093-T04 · Transition coverage:** Map the “Decoder acceptance gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Decoder acceptance gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.04-C093-T06 · Satisfying fixture:** Create a concrete “Decoder acceptance gate” case that satisfies “Passing schema checks alone does not establish bounded decoding”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.04-C093-T07 · Violating fixture:** Create the source counterexample “A valid header triggers an excessive allocation later in decoding” for “Decoder acceptance gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.04-C093-T08 · Enforcement evidence:** Exercise the “Decoder acceptance gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.04-C093-T09 · Regression linkage:** Link the “Decoder acceptance gate” property to changes in state import, previews, embedded hull decoders and bounded worker execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Decoder acceptance gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.04-C094 · Integration

**Original checklist item:** Integrate decoder acceptance gate with state import, previews, embedded hull decoders and bounded worker execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Decoder acceptance gate” across state import, previews, embedded hull decoders and bounded worker execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.04-C094-T02 · Field mapping:** Map every “Decoder acceptance gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Decoder acceptance gate” (source dependency list: UC-M03.05, UC-M07.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.04-C094-T04 · Ownership agreement:** Specify who owns “Decoder acceptance gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.04-C094-T05 · Handoff implementation:** Connect “Decoder acceptance gate” through the mapped seam using the real adapter or explicit specification reference; preserve “Passing schema checks alone does not establish bounded decoding” across the handoff.
- [ ] **UC-M07.04-C094-T06 · Absent-input case:** Omit one required “Decoder acceptance gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.04-C094-T07 · Stale-input case:** Supply an outdated “Decoder acceptance gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Decoder acceptance gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.04-C094-T09 · Valid integration trace:** Run a valid “Decoder acceptance gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.04-C094-T10 · Seam review:** Reconcile the “Decoder acceptance gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.04-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for decoder acceptance gate; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.04-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Decoder acceptance gate” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.04-C095-T02 · Expected-result oracle:** Specify the “Decoder acceptance gate” expected result independently of the implementation output; include the property “Passing schema checks alone does not establish bounded decoding” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.04-C095-T03 · Fixture material:** Create the concrete “Decoder acceptance gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.04-C095-T04 · Target preparation:** Prepare the “Decoder acceptance gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.04-C095-T05 · Initial-state record:** Record the initial “Decoder acceptance gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.04-C095-T06 · Valid-path execution:** Execute the “Decoder acceptance gate” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.04-C095-T07 · Outcome comparison:** Compare every declared “Decoder acceptance gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.04-C095-T08 · State and bounds check:** Inspect the “Decoder acceptance gate” ownership/state effects and actual use of “Formats, worker profiles and measurement duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.04-C095-T09 · Repeatability check:** Repeat the same “Decoder acceptance gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.04-C095-T10 · Positive evidence:** Attach the “Decoder acceptance gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.04-C096 · Negative test

**Original checklist item:** Negative case: A valid header triggers an excessive allocation later in decoding. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Decoder acceptance gate” source counterexample: “A valid header triggers an excessive allocation later in decoding”; state which precondition or invariant it challenges.
- [ ] **UC-M07.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Decoder acceptance gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.04-C096-T03 · Valid control:** Construct a valid “Decoder acceptance gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.04-C096-T04 · Minimal adverse input:** Derive the “Decoder acceptance gate” adverse fixture from the control with the smallest documented change needed to reproduce “A valid header triggers an excessive allocation later in decoding”; retain that change as reproducible data.
- [ ] **UC-M07.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Decoder acceptance gate”; require “Passing schema checks alone does not establish bounded decoding” and forbid a false-success verdict.
- [ ] **UC-M07.04-C096-T06 · Adverse execution:** Exercise the “Decoder acceptance gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.04-C096-T07 · Effect inspection:** Inspect “Decoder acceptance gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.04-C096-T08 · Refusal versus failure:** Confirm the “Decoder acceptance gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.04-C096-T09 · Reset and retention:** Restore only the disposable “Decoder acceptance gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.04-C096-T10 · Negative regression:** Register the “Decoder acceptance gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.04-C097 · Change / failure test

**Original checklist item:** Exercise decoder acceptance gate when a decoder times out after reading only part of an untrusted state object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.04-C097-T01 · Scenario record:** Write the “Decoder acceptance gate” change/failure scenario exactly as supplied: a decoder times out after reading only part of an untrusted state object; identify the property that must remain true: “Passing schema checks alone does not establish bounded decoding”.
- [ ] **UC-M07.04-C097-T02 · Baseline capture:** Create a known-valid “Decoder acceptance gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.04-C097-T03 · Injection map:** Locate the “Decoder acceptance gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Decoder acceptance gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.04-C097-T05 · Controlled trigger:** Introduce the controlled “Decoder acceptance gate” scenario in the disposable fixture: a decoder times out after reading only part of an untrusted state object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.04-C097-T06 · Intermediate inspection:** Inspect the “Decoder acceptance gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Decoder acceptance gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Decoder acceptance gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.04-C097-T09 · Repeat and compare:** Repeat the selected “Decoder acceptance gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.04-C097-T10 · Failure evidence:** Publish the “Decoder acceptance gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.04-C098 · Bounds

**Original checklist item:** Choose, document and test limits for formats, worker profiles and measurement duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Decoder acceptance gate”: “Formats, worker profiles and measurement duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.04-C098-T02 · Measurement method:** Choose how to observe each “Decoder acceptance gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.04-C098-T03 · Budget decision:** Select justified resource and input limits for “Decoder acceptance gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Decoder acceptance gate” cases for “Formats, worker profiles and measurement duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Decoder acceptance gate” limit; preserve “Passing schema checks alone does not establish bounded decoding”.
- [ ] **UC-M07.04-C098-T06 · Normal measurement:** Run or review the normal “Decoder acceptance gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.04-C098-T07 · At-limit measurement:** Exercise the “Decoder acceptance gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.04-C098-T08 · Over-limit measurement:** Exercise the “Decoder acceptance gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.04-C098-T09 · Uncovered-scope report:** List the “Decoder acceptance gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.04-C098-T10 · Limit evidence:** Publish the selected “Decoder acceptance gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.04-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for decoder acceptance gate with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.04-C099-T01 · Event inventory:** List the “Decoder acceptance gate” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.04-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Decoder acceptance gate” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.04-C099-T03 · Failure mapping:** Map each documented “Decoder acceptance gate” refusal or error to a diagnostic outcome; include “A valid header triggers an excessive allocation later in decoding” and prohibit conversion into a success message.
- [ ] **UC-M07.04-C099-T04 · Emission path:** Add the “Decoder acceptance gate” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.04-C099-T05 · Redaction check:** Test “Decoder acceptance gate” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.04-C099-T06 · Output budget:** Set and exercise bounded “Decoder acceptance gate” message size, rate and retention compatible with “Formats, worker profiles and measurement duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.04-C099-T07 · Success/refusal fixtures:** Capture “Decoder acceptance gate” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.04-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Decoder acceptance gate” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.04-C099-T09 · Operator review:** Read the “Decoder acceptance gate” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.04-C099-T10 · Diagnostic evidence:** Publish redacted “Decoder acceptance gate” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for decoder acceptance gate; label unexecuted checks as untested.

- [ ] **UC-M07.04-C100-T01 · Evidence inventory:** List the “Decoder acceptance gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.04-C100-T02 · Artifact references:** Record the exact “Decoder acceptance gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.04-C100-T03 · Fixture references:** Attach the “Decoder acceptance gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A valid header triggers an excessive allocation later in decoding” as a distinct evidence case.
- [ ] **UC-M07.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Decoder acceptance gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.04-C100-T05 · Environment record:** Record the actual “Decoder acceptance gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.04-C100-T06 · Expected versus observed:** Pair every “Decoder acceptance gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.04-C100-T07 · Failure and limit records:** Attach “Decoder acceptance gate” change/failure and bounds evidence where required; include uncovered “Formats, worker profiles and measurement duration” and unresolved violations of “Passing schema checks alone does not establish bounded decoding”.
- [ ] **UC-M07.04-C100-T08 · Evidence hygiene:** Check the “Decoder acceptance gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.04-C100-T09 · Reproduction review:** Have the “Decoder acceptance gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.04-C100-T10 · Acceptance linkage:** Link the “Decoder acceptance gate” evidence to its parent and UC-M07.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

