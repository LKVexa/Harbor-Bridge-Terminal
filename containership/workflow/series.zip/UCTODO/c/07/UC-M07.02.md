# UC-M07.02 — Checkpoint and history rollover

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/07.md)

| Field | Preserved source value |
|---|---|
| Workstream | 07. Persistence, transactions and recovery |
| Milestone | A |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M07.01](../07/UC-M07.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S8]. |

## Original requirement

Turn the 512-page stop guard into validated immutable checkpoints, bounded history segments and an explicit restore index.

**Original acceptance criterion:** Long-running TIFF state continues after rollover and restores the same state as uninterrupted execution.

**Source trace:** Original checklist `UC100/c/07/UC-M07.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 630–640 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. History limit transition

**Source delivery:** Replace the existing 512-page stop-only behavior with an explicit rollover policy.

**Source invariant:** History growth stays bounded without silently discarding required state.

**Source negative case:** Page 513 is appended without rollover or produces an unexplained stop.

**Source bounded quantities:** Pages per segment and rollover threshold.

### UC-M07.02-C001 · Contract

**Original checklist item:** Specify history limit transition inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C001-T01 · Scope statement:** Draft the operation boundary for “History limit transition” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “History limit transition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C001-T03 · Output inventory:** List the outputs of “History limit transition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “History limit transition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C001-T05 · Prerequisite contract:** Map “History limit transition” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C001-T06 · Authority map:** Identify who may produce, change and consume “History limit transition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C001-T07 · Invariant clause:** Add a normative clause for “History limit transition” that preserves “History growth stays bounded without silently discarding required state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “History limit transition”; include the source counterexample “Page 513 is appended without rollover or produces an unexplained stop” and the intended safe disposition.
- [ ] **UC-M07.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pages per segment and rollover threshold” in the “History limit transition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C001-T10 · Contract review:** Review the “History limit transition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C002 · Delivery

**Original checklist item:** Replace the existing 512-page stop-only behavior with an explicit rollover policy.

- [ ] **UC-M07.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “History limit transition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C002-T02 · Change plan:** Break the source delivery for “History limit transition” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “History limit transition” that realizes this source instruction: Replace the existing 512-page stop-only behavior with an explicit rollover policy.
- [ ] **UC-M07.02-C002-T04 · Concrete realization:** Trace “History limit transition” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “History limit transition” needed to preserve “History growth stays bounded without silently discarding required state”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C002-T06 · Dependency connection:** Connect the “History limit transition” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C002-T07 · Resource behavior:** Account for “Pages per segment and rollover threshold” in “History limit transition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C002-T08 · Delivery check:** Run the smallest real “History limit transition” path and its adverse fixture “Page 513 is appended without rollover or produces an unexplained stop”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C002-T09 · Patch review:** Review the “History limit transition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C002-T10 · Delivery handoff:** Publish the “History limit transition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: History growth stays bounded without silently discarding required state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “History limit transition”; copy its required invariant exactly: “History growth stays bounded without silently discarding required state”.
- [ ] **UC-M07.02-C003-T02 · Observable terms:** Define each term in the “History limit transition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C003-T03 · Precondition set:** List the preconditions under which “History growth stays bounded without silently discarding required state” must hold for “History limit transition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C003-T04 · Transition coverage:** Map the “History limit transition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “History limit transition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C003-T06 · Satisfying fixture:** Create a concrete “History limit transition” case that satisfies “History growth stays bounded without silently discarding required state”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C003-T07 · Violating fixture:** Create the source counterexample “Page 513 is appended without rollover or produces an unexplained stop” for “History limit transition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C003-T08 · Enforcement evidence:** Exercise the “History limit transition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C003-T09 · Regression linkage:** Link the “History limit transition” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C003-T10 · Property disposition:** Compare the satisfying and violating “History limit transition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C004 · Integration

**Original checklist item:** Integrate history limit transition with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “History limit transition” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C004-T02 · Field mapping:** Map every “History limit transition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “History limit transition” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C004-T04 · Ownership agreement:** Specify who owns “History limit transition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C004-T05 · Handoff implementation:** Connect “History limit transition” through the mapped seam using the real adapter or explicit specification reference; preserve “History growth stays bounded without silently discarding required state” across the handoff.
- [ ] **UC-M07.02-C004-T06 · Absent-input case:** Omit one required “History limit transition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C004-T07 · Stale-input case:** Supply an outdated “History limit transition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C004-T08 · Incompatible-input case:** Supply an incompatible “History limit transition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C004-T09 · Valid integration trace:** Run a valid “History limit transition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C004-T10 · Seam review:** Reconcile the “History limit transition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for history limit transition; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “History limit transition” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C005-T02 · Expected-result oracle:** Specify the “History limit transition” expected result independently of the implementation output; include the property “History growth stays bounded without silently discarding required state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C005-T03 · Fixture material:** Create the concrete “History limit transition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C005-T04 · Target preparation:** Prepare the “History limit transition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C005-T05 · Initial-state record:** Record the initial “History limit transition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C005-T06 · Valid-path execution:** Execute the “History limit transition” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C005-T07 · Outcome comparison:** Compare every declared “History limit transition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C005-T08 · State and bounds check:** Inspect the “History limit transition” ownership/state effects and actual use of “Pages per segment and rollover threshold”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C005-T09 · Repeatability check:** Repeat the same “History limit transition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C005-T10 · Positive evidence:** Attach the “History limit transition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C006 · Negative test

**Original checklist item:** Negative case: Page 513 is appended without rollover or produces an unexplained stop. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “History limit transition” source counterexample: “Page 513 is appended without rollover or produces an unexplained stop”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “History limit transition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C006-T03 · Valid control:** Construct a valid “History limit transition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C006-T04 · Minimal adverse input:** Derive the “History limit transition” adverse fixture from the control with the smallest documented change needed to reproduce “Page 513 is appended without rollover or produces an unexplained stop”; retain that change as reproducible data.
- [ ] **UC-M07.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “History limit transition”; require “History growth stays bounded without silently discarding required state” and forbid a false-success verdict.
- [ ] **UC-M07.02-C006-T06 · Adverse execution:** Exercise the “History limit transition” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C006-T07 · Effect inspection:** Inspect “History limit transition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C006-T08 · Refusal versus failure:** Confirm the “History limit transition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C006-T09 · Reset and retention:** Restore only the disposable “History limit transition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C006-T10 · Negative regression:** Register the “History limit transition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C007 · Change / failure test

**Original checklist item:** Exercise history limit transition when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C007-T01 · Scenario record:** Write the “History limit transition” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “History growth stays bounded without silently discarding required state”.
- [ ] **UC-M07.02-C007-T02 · Baseline capture:** Create a known-valid “History limit transition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C007-T03 · Injection map:** Locate the “History limit transition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “History limit transition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C007-T05 · Controlled trigger:** Introduce the controlled “History limit transition” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C007-T06 · Intermediate inspection:** Inspect the “History limit transition” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “History limit transition”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “History limit transition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C007-T09 · Repeat and compare:** Repeat the selected “History limit transition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C007-T10 · Failure evidence:** Publish the “History limit transition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for pages per segment and rollover threshold; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “History limit transition”: “Pages per segment and rollover threshold”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C008-T02 · Measurement method:** Choose how to observe each “History limit transition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C008-T03 · Budget decision:** Select justified resource and input limits for “History limit transition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “History limit transition” cases for “Pages per segment and rollover threshold”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “History limit transition” limit; preserve “History growth stays bounded without silently discarding required state”.
- [ ] **UC-M07.02-C008-T06 · Normal measurement:** Run or review the normal “History limit transition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C008-T07 · At-limit measurement:** Exercise the “History limit transition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C008-T08 · Over-limit measurement:** Exercise the “History limit transition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C008-T09 · Uncovered-scope report:** List the “History limit transition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C008-T10 · Limit evidence:** Publish the selected “History limit transition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for history limit transition with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C009-T01 · Event inventory:** List the “History limit transition” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “History limit transition” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C009-T03 · Failure mapping:** Map each documented “History limit transition” refusal or error to a diagnostic outcome; include “Page 513 is appended without rollover or produces an unexplained stop” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C009-T04 · Emission path:** Add the “History limit transition” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C009-T05 · Redaction check:** Test “History limit transition” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C009-T06 · Output budget:** Set and exercise bounded “History limit transition” message size, rate and retention compatible with “Pages per segment and rollover threshold”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C009-T07 · Success/refusal fixtures:** Capture “History limit transition” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “History limit transition” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C009-T09 · Operator review:** Read the “History limit transition” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C009-T10 · Diagnostic evidence:** Publish redacted “History limit transition” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for history limit transition; label unexecuted checks as untested.

- [ ] **UC-M07.02-C010-T01 · Evidence inventory:** List the “History limit transition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C010-T02 · Artifact references:** Record the exact “History limit transition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C010-T03 · Fixture references:** Attach the “History limit transition” fixture IDs, input identities and oracle definition; preserve the source counterexample “Page 513 is appended without rollover or produces an unexplained stop” as a distinct evidence case.
- [ ] **UC-M07.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “History limit transition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C010-T05 · Environment record:** Record the actual “History limit transition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C010-T06 · Expected versus observed:** Pair every “History limit transition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C010-T07 · Failure and limit records:** Attach “History limit transition” change/failure and bounds evidence where required; include uncovered “Pages per segment and rollover threshold” and unresolved violations of “History growth stays bounded without silently discarding required state”.
- [ ] **UC-M07.02-C010-T08 · Evidence hygiene:** Check the “History limit transition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C010-T09 · Reproduction review:** Have the “History limit transition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C010-T10 · Acceptance linkage:** Link the “History limit transition” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Checkpoint contents

**Source delivery:** Define the complete state, image, ABI and generation data required by a checkpoint.

**Source invariant:** A checkpoint contains enough validated information for its declared restore scope.

**Source negative case:** A checkpoint omits state needed to resume the workload.

**Source bounded quantities:** Checkpoint bytes and field count.

### UC-M07.02-C011 · Contract

**Original checklist item:** Specify checkpoint contents inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C011-T01 · Scope statement:** Draft the operation boundary for “Checkpoint contents” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Checkpoint contents”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C011-T03 · Output inventory:** List the outputs of “Checkpoint contents” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Checkpoint contents”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C011-T05 · Prerequisite contract:** Map “Checkpoint contents” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Checkpoint contents”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C011-T07 · Invariant clause:** Add a normative clause for “Checkpoint contents” that preserves “A checkpoint contains enough validated information for its declared restore scope”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Checkpoint contents”; include the source counterexample “A checkpoint omits state needed to resume the workload” and the intended safe disposition.
- [ ] **UC-M07.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Checkpoint bytes and field count” in the “Checkpoint contents” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C011-T10 · Contract review:** Review the “Checkpoint contents” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C012 · Delivery

**Original checklist item:** Define the complete state, image, ABI and generation data required by a checkpoint.

- [ ] **UC-M07.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Checkpoint contents”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C012-T02 · Change plan:** Break the source delivery for “Checkpoint contents” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C012-T03 · Core artifact:** Create the “Checkpoint contents” model, schema or inventory that realizes this source instruction: Define the complete state, image, ABI and generation data required by a checkpoint.
- [ ] **UC-M07.02-C012-T04 · Concrete realization:** Populate “Checkpoint contents” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Checkpoint contents” needed to preserve “A checkpoint contains enough validated information for its declared restore scope”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C012-T06 · Dependency connection:** Connect the “Checkpoint contents” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C012-T07 · Resource behavior:** Account for “Checkpoint bytes and field count” in “Checkpoint contents”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C012-T08 · Delivery check:** Run the smallest real “Checkpoint contents” path and its adverse fixture “A checkpoint omits state needed to resume the workload”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C012-T09 · Patch review:** Review the “Checkpoint contents” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C012-T10 · Delivery handoff:** Publish the “Checkpoint contents” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A checkpoint contains enough validated information for its declared restore scope. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Checkpoint contents”; copy its required invariant exactly: “A checkpoint contains enough validated information for its declared restore scope”.
- [ ] **UC-M07.02-C013-T02 · Observable terms:** Define each term in the “Checkpoint contents” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C013-T03 · Precondition set:** List the preconditions under which “A checkpoint contains enough validated information for its declared restore scope” must hold for “Checkpoint contents”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C013-T04 · Transition coverage:** Map the “Checkpoint contents” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Checkpoint contents”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C013-T06 · Satisfying fixture:** Create a concrete “Checkpoint contents” case that satisfies “A checkpoint contains enough validated information for its declared restore scope”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C013-T07 · Violating fixture:** Create the source counterexample “A checkpoint omits state needed to resume the workload” for “Checkpoint contents”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C013-T08 · Enforcement evidence:** Exercise the “Checkpoint contents” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C013-T09 · Regression linkage:** Link the “Checkpoint contents” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Checkpoint contents” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C014 · Integration

**Original checklist item:** Integrate checkpoint contents with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Checkpoint contents” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C014-T02 · Field mapping:** Map every “Checkpoint contents” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Checkpoint contents” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C014-T04 · Ownership agreement:** Specify who owns “Checkpoint contents” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C014-T05 · Handoff implementation:** Connect “Checkpoint contents” through the mapped seam using the real adapter or explicit specification reference; preserve “A checkpoint contains enough validated information for its declared restore scope” across the handoff.
- [ ] **UC-M07.02-C014-T06 · Absent-input case:** Omit one required “Checkpoint contents” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C014-T07 · Stale-input case:** Supply an outdated “Checkpoint contents” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Checkpoint contents” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C014-T09 · Valid integration trace:** Run a valid “Checkpoint contents” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C014-T10 · Seam review:** Reconcile the “Checkpoint contents” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for checkpoint contents; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Checkpoint contents” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C015-T02 · Expected-result oracle:** Specify the “Checkpoint contents” expected result independently of the implementation output; include the property “A checkpoint contains enough validated information for its declared restore scope” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C015-T03 · Fixture material:** Create the concrete “Checkpoint contents” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C015-T04 · Target preparation:** Prepare the “Checkpoint contents” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C015-T05 · Initial-state record:** Record the initial “Checkpoint contents” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C015-T06 · Valid-path execution:** Execute the “Checkpoint contents” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C015-T07 · Outcome comparison:** Compare every declared “Checkpoint contents” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C015-T08 · State and bounds check:** Inspect the “Checkpoint contents” ownership/state effects and actual use of “Checkpoint bytes and field count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C015-T09 · Repeatability check:** Repeat the same “Checkpoint contents” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C015-T10 · Positive evidence:** Attach the “Checkpoint contents” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C016 · Negative test

**Original checklist item:** Negative case: A checkpoint omits state needed to resume the workload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Checkpoint contents” source counterexample: “A checkpoint omits state needed to resume the workload”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Checkpoint contents”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C016-T03 · Valid control:** Construct a valid “Checkpoint contents” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C016-T04 · Minimal adverse input:** Derive the “Checkpoint contents” adverse fixture from the control with the smallest documented change needed to reproduce “A checkpoint omits state needed to resume the workload”; retain that change as reproducible data.
- [ ] **UC-M07.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Checkpoint contents”; require “A checkpoint contains enough validated information for its declared restore scope” and forbid a false-success verdict.
- [ ] **UC-M07.02-C016-T06 · Adverse execution:** Exercise the “Checkpoint contents” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C016-T07 · Effect inspection:** Inspect “Checkpoint contents” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C016-T08 · Refusal versus failure:** Confirm the “Checkpoint contents” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C016-T09 · Reset and retention:** Restore only the disposable “Checkpoint contents” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C016-T10 · Negative regression:** Register the “Checkpoint contents” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C017 · Change / failure test

**Original checklist item:** Exercise checkpoint contents when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C017-T01 · Scenario record:** Write the “Checkpoint contents” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “A checkpoint contains enough validated information for its declared restore scope”.
- [ ] **UC-M07.02-C017-T02 · Baseline capture:** Create a known-valid “Checkpoint contents” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C017-T03 · Injection map:** Locate the “Checkpoint contents” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Checkpoint contents” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C017-T05 · Controlled trigger:** Introduce the controlled “Checkpoint contents” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C017-T06 · Intermediate inspection:** Inspect the “Checkpoint contents” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Checkpoint contents”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Checkpoint contents” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C017-T09 · Repeat and compare:** Repeat the selected “Checkpoint contents” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C017-T10 · Failure evidence:** Publish the “Checkpoint contents” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for checkpoint bytes and field count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Checkpoint contents”: “Checkpoint bytes and field count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C018-T02 · Measurement method:** Choose how to observe each “Checkpoint contents” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C018-T03 · Budget decision:** Select justified resource and input limits for “Checkpoint contents”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Checkpoint contents” cases for “Checkpoint bytes and field count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Checkpoint contents” limit; preserve “A checkpoint contains enough validated information for its declared restore scope”.
- [ ] **UC-M07.02-C018-T06 · Normal measurement:** Run or review the normal “Checkpoint contents” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C018-T07 · At-limit measurement:** Exercise the “Checkpoint contents” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C018-T08 · Over-limit measurement:** Exercise the “Checkpoint contents” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C018-T09 · Uncovered-scope report:** List the “Checkpoint contents” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C018-T10 · Limit evidence:** Publish the selected “Checkpoint contents” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for checkpoint contents with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C019-T01 · Event inventory:** List the “Checkpoint contents” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Checkpoint contents” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C019-T03 · Failure mapping:** Map each documented “Checkpoint contents” refusal or error to a diagnostic outcome; include “A checkpoint omits state needed to resume the workload” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C019-T04 · Emission path:** Add the “Checkpoint contents” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C019-T05 · Redaction check:** Test “Checkpoint contents” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C019-T06 · Output budget:** Set and exercise bounded “Checkpoint contents” message size, rate and retention compatible with “Checkpoint bytes and field count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C019-T07 · Success/refusal fixtures:** Capture “Checkpoint contents” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Checkpoint contents” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C019-T09 · Operator review:** Read the “Checkpoint contents” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C019-T10 · Diagnostic evidence:** Publish redacted “Checkpoint contents” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for checkpoint contents; label unexecuted checks as untested.

- [ ] **UC-M07.02-C020-T01 · Evidence inventory:** List the “Checkpoint contents” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C020-T02 · Artifact references:** Record the exact “Checkpoint contents” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C020-T03 · Fixture references:** Attach the “Checkpoint contents” fixture IDs, input identities and oracle definition; preserve the source counterexample “A checkpoint omits state needed to resume the workload” as a distinct evidence case.
- [ ] **UC-M07.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Checkpoint contents”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C020-T05 · Environment record:** Record the actual “Checkpoint contents” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C020-T06 · Expected versus observed:** Pair every “Checkpoint contents” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C020-T07 · Failure and limit records:** Attach “Checkpoint contents” change/failure and bounds evidence where required; include uncovered “Checkpoint bytes and field count” and unresolved violations of “A checkpoint contains enough validated information for its declared restore scope”.
- [ ] **UC-M07.02-C020-T08 · Evidence hygiene:** Check the “Checkpoint contents” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C020-T09 · Reproduction review:** Have the “Checkpoint contents” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C020-T10 · Acceptance linkage:** Link the “Checkpoint contents” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Immutable checkpoint publication

**Source delivery:** Stage, validate and publish checkpoints as immutable identified objects.

**Source invariant:** Interrupted creation cannot expose a valid-looking partial checkpoint.

**Source negative case:** The process stops halfway through checkpoint writing.

**Source bounded quantities:** Temporary bytes and publication time.

### UC-M07.02-C021 · Contract

**Original checklist item:** Specify immutable checkpoint publication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C021-T01 · Scope statement:** Draft the operation boundary for “Immutable checkpoint publication” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Immutable checkpoint publication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C021-T03 · Output inventory:** List the outputs of “Immutable checkpoint publication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Immutable checkpoint publication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C021-T05 · Prerequisite contract:** Map “Immutable checkpoint publication” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Immutable checkpoint publication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C021-T07 · Invariant clause:** Add a normative clause for “Immutable checkpoint publication” that preserves “Interrupted creation cannot expose a valid-looking partial checkpoint”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Immutable checkpoint publication”; include the source counterexample “The process stops halfway through checkpoint writing” and the intended safe disposition.
- [ ] **UC-M07.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Temporary bytes and publication time” in the “Immutable checkpoint publication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C021-T10 · Contract review:** Review the “Immutable checkpoint publication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C022 · Delivery

**Original checklist item:** Stage, validate and publish checkpoints as immutable identified objects.

- [ ] **UC-M07.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Immutable checkpoint publication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C022-T02 · Change plan:** Break the source delivery for “Immutable checkpoint publication” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Immutable checkpoint publication” that realizes this source instruction: Stage, validate and publish checkpoints as immutable identified objects.
- [ ] **UC-M07.02-C022-T04 · Concrete realization:** Trace “Immutable checkpoint publication” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Immutable checkpoint publication” needed to preserve “Interrupted creation cannot expose a valid-looking partial checkpoint”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C022-T06 · Dependency connection:** Connect the “Immutable checkpoint publication” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C022-T07 · Resource behavior:** Account for “Temporary bytes and publication time” in “Immutable checkpoint publication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C022-T08 · Delivery check:** Run the smallest real “Immutable checkpoint publication” path and its adverse fixture “The process stops halfway through checkpoint writing”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C022-T09 · Patch review:** Review the “Immutable checkpoint publication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C022-T10 · Delivery handoff:** Publish the “Immutable checkpoint publication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Interrupted creation cannot expose a valid-looking partial checkpoint. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Immutable checkpoint publication”; copy its required invariant exactly: “Interrupted creation cannot expose a valid-looking partial checkpoint”.
- [ ] **UC-M07.02-C023-T02 · Observable terms:** Define each term in the “Immutable checkpoint publication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C023-T03 · Precondition set:** List the preconditions under which “Interrupted creation cannot expose a valid-looking partial checkpoint” must hold for “Immutable checkpoint publication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C023-T04 · Transition coverage:** Map the “Immutable checkpoint publication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Immutable checkpoint publication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C023-T06 · Satisfying fixture:** Create a concrete “Immutable checkpoint publication” case that satisfies “Interrupted creation cannot expose a valid-looking partial checkpoint”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C023-T07 · Violating fixture:** Create the source counterexample “The process stops halfway through checkpoint writing” for “Immutable checkpoint publication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C023-T08 · Enforcement evidence:** Exercise the “Immutable checkpoint publication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C023-T09 · Regression linkage:** Link the “Immutable checkpoint publication” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Immutable checkpoint publication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C024 · Integration

**Original checklist item:** Integrate immutable checkpoint publication with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Immutable checkpoint publication” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C024-T02 · Field mapping:** Map every “Immutable checkpoint publication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Immutable checkpoint publication” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C024-T04 · Ownership agreement:** Specify who owns “Immutable checkpoint publication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C024-T05 · Handoff implementation:** Connect “Immutable checkpoint publication” through the mapped seam using the real adapter or explicit specification reference; preserve “Interrupted creation cannot expose a valid-looking partial checkpoint” across the handoff.
- [ ] **UC-M07.02-C024-T06 · Absent-input case:** Omit one required “Immutable checkpoint publication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C024-T07 · Stale-input case:** Supply an outdated “Immutable checkpoint publication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Immutable checkpoint publication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C024-T09 · Valid integration trace:** Run a valid “Immutable checkpoint publication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C024-T10 · Seam review:** Reconcile the “Immutable checkpoint publication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for immutable checkpoint publication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Immutable checkpoint publication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C025-T02 · Expected-result oracle:** Specify the “Immutable checkpoint publication” expected result independently of the implementation output; include the property “Interrupted creation cannot expose a valid-looking partial checkpoint” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C025-T03 · Fixture material:** Create the concrete “Immutable checkpoint publication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C025-T04 · Target preparation:** Prepare the “Immutable checkpoint publication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C025-T05 · Initial-state record:** Record the initial “Immutable checkpoint publication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C025-T06 · Valid-path execution:** Execute the “Immutable checkpoint publication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C025-T07 · Outcome comparison:** Compare every declared “Immutable checkpoint publication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C025-T08 · State and bounds check:** Inspect the “Immutable checkpoint publication” ownership/state effects and actual use of “Temporary bytes and publication time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C025-T09 · Repeatability check:** Repeat the same “Immutable checkpoint publication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C025-T10 · Positive evidence:** Attach the “Immutable checkpoint publication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C026 · Negative test

**Original checklist item:** Negative case: The process stops halfway through checkpoint writing. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Immutable checkpoint publication” source counterexample: “The process stops halfway through checkpoint writing”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Immutable checkpoint publication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C026-T03 · Valid control:** Construct a valid “Immutable checkpoint publication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C026-T04 · Minimal adverse input:** Derive the “Immutable checkpoint publication” adverse fixture from the control with the smallest documented change needed to reproduce “The process stops halfway through checkpoint writing”; retain that change as reproducible data.
- [ ] **UC-M07.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Immutable checkpoint publication”; require “Interrupted creation cannot expose a valid-looking partial checkpoint” and forbid a false-success verdict.
- [ ] **UC-M07.02-C026-T06 · Adverse execution:** Exercise the “Immutable checkpoint publication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C026-T07 · Effect inspection:** Inspect “Immutable checkpoint publication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C026-T08 · Refusal versus failure:** Confirm the “Immutable checkpoint publication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C026-T09 · Reset and retention:** Restore only the disposable “Immutable checkpoint publication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C026-T10 · Negative regression:** Register the “Immutable checkpoint publication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C027 · Change / failure test

**Original checklist item:** Exercise immutable checkpoint publication when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C027-T01 · Scenario record:** Write the “Immutable checkpoint publication” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “Interrupted creation cannot expose a valid-looking partial checkpoint”.
- [ ] **UC-M07.02-C027-T02 · Baseline capture:** Create a known-valid “Immutable checkpoint publication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C027-T03 · Injection map:** Locate the “Immutable checkpoint publication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Immutable checkpoint publication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C027-T05 · Controlled trigger:** Introduce the controlled “Immutable checkpoint publication” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C027-T06 · Intermediate inspection:** Inspect the “Immutable checkpoint publication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Immutable checkpoint publication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Immutable checkpoint publication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C027-T09 · Repeat and compare:** Repeat the selected “Immutable checkpoint publication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C027-T10 · Failure evidence:** Publish the “Immutable checkpoint publication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for temporary bytes and publication time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Immutable checkpoint publication”: “Temporary bytes and publication time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C028-T02 · Measurement method:** Choose how to observe each “Immutable checkpoint publication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Immutable checkpoint publication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Immutable checkpoint publication” cases for “Temporary bytes and publication time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Immutable checkpoint publication” limit; preserve “Interrupted creation cannot expose a valid-looking partial checkpoint”.
- [ ] **UC-M07.02-C028-T06 · Normal measurement:** Run or review the normal “Immutable checkpoint publication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C028-T07 · At-limit measurement:** Exercise the “Immutable checkpoint publication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C028-T08 · Over-limit measurement:** Exercise the “Immutable checkpoint publication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C028-T09 · Uncovered-scope report:** List the “Immutable checkpoint publication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C028-T10 · Limit evidence:** Publish the selected “Immutable checkpoint publication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for immutable checkpoint publication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C029-T01 · Event inventory:** List the “Immutable checkpoint publication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Immutable checkpoint publication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C029-T03 · Failure mapping:** Map each documented “Immutable checkpoint publication” refusal or error to a diagnostic outcome; include “The process stops halfway through checkpoint writing” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C029-T04 · Emission path:** Add the “Immutable checkpoint publication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C029-T05 · Redaction check:** Test “Immutable checkpoint publication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C029-T06 · Output budget:** Set and exercise bounded “Immutable checkpoint publication” message size, rate and retention compatible with “Temporary bytes and publication time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C029-T07 · Success/refusal fixtures:** Capture “Immutable checkpoint publication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Immutable checkpoint publication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C029-T09 · Operator review:** Read the “Immutable checkpoint publication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C029-T10 · Diagnostic evidence:** Publish redacted “Immutable checkpoint publication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for immutable checkpoint publication; label unexecuted checks as untested.

- [ ] **UC-M07.02-C030-T01 · Evidence inventory:** List the “Immutable checkpoint publication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C030-T02 · Artifact references:** Record the exact “Immutable checkpoint publication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C030-T03 · Fixture references:** Attach the “Immutable checkpoint publication” fixture IDs, input identities and oracle definition; preserve the source counterexample “The process stops halfway through checkpoint writing” as a distinct evidence case.
- [ ] **UC-M07.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Immutable checkpoint publication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C030-T05 · Environment record:** Record the actual “Immutable checkpoint publication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C030-T06 · Expected versus observed:** Pair every “Immutable checkpoint publication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C030-T07 · Failure and limit records:** Attach “Immutable checkpoint publication” change/failure and bounds evidence where required; include uncovered “Temporary bytes and publication time” and unresolved violations of “Interrupted creation cannot expose a valid-looking partial checkpoint”.
- [ ] **UC-M07.02-C030-T08 · Evidence hygiene:** Check the “Immutable checkpoint publication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C030-T09 · Reproduction review:** Have the “Immutable checkpoint publication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C030-T10 · Acceptance linkage:** Link the “Immutable checkpoint publication” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. History segmentation

**Source delivery:** Partition history into bounded segments with explicit sequence boundaries.

**Source invariant:** Adjacent segments do not overlap or omit committed progression.

**Source negative case:** Rollover skips a committed tick between segments.

**Source bounded quantities:** Segment bytes and segment count.

### UC-M07.02-C031 · Contract

**Original checklist item:** Specify history segmentation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C031-T01 · Scope statement:** Draft the operation boundary for “History segmentation” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “History segmentation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C031-T03 · Output inventory:** List the outputs of “History segmentation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “History segmentation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C031-T05 · Prerequisite contract:** Map “History segmentation” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C031-T06 · Authority map:** Identify who may produce, change and consume “History segmentation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C031-T07 · Invariant clause:** Add a normative clause for “History segmentation” that preserves “Adjacent segments do not overlap or omit committed progression”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “History segmentation”; include the source counterexample “Rollover skips a committed tick between segments” and the intended safe disposition.
- [ ] **UC-M07.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Segment bytes and segment count” in the “History segmentation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C031-T10 · Contract review:** Review the “History segmentation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C032 · Delivery

**Original checklist item:** Partition history into bounded segments with explicit sequence boundaries.

- [ ] **UC-M07.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “History segmentation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C032-T02 · Change plan:** Break the source delivery for “History segmentation” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “History segmentation” that realizes this source instruction: Partition history into bounded segments with explicit sequence boundaries.
- [ ] **UC-M07.02-C032-T04 · Concrete realization:** Trace “History segmentation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “History segmentation” needed to preserve “Adjacent segments do not overlap or omit committed progression”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C032-T06 · Dependency connection:** Connect the “History segmentation” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C032-T07 · Resource behavior:** Account for “Segment bytes and segment count” in “History segmentation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C032-T08 · Delivery check:** Run the smallest real “History segmentation” path and its adverse fixture “Rollover skips a committed tick between segments”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C032-T09 · Patch review:** Review the “History segmentation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C032-T10 · Delivery handoff:** Publish the “History segmentation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Adjacent segments do not overlap or omit committed progression. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “History segmentation”; copy its required invariant exactly: “Adjacent segments do not overlap or omit committed progression”.
- [ ] **UC-M07.02-C033-T02 · Observable terms:** Define each term in the “History segmentation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C033-T03 · Precondition set:** List the preconditions under which “Adjacent segments do not overlap or omit committed progression” must hold for “History segmentation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C033-T04 · Transition coverage:** Map the “History segmentation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “History segmentation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C033-T06 · Satisfying fixture:** Create a concrete “History segmentation” case that satisfies “Adjacent segments do not overlap or omit committed progression”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C033-T07 · Violating fixture:** Create the source counterexample “Rollover skips a committed tick between segments” for “History segmentation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C033-T08 · Enforcement evidence:** Exercise the “History segmentation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C033-T09 · Regression linkage:** Link the “History segmentation” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C033-T10 · Property disposition:** Compare the satisfying and violating “History segmentation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C034 · Integration

**Original checklist item:** Integrate history segmentation with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “History segmentation” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C034-T02 · Field mapping:** Map every “History segmentation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “History segmentation” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C034-T04 · Ownership agreement:** Specify who owns “History segmentation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C034-T05 · Handoff implementation:** Connect “History segmentation” through the mapped seam using the real adapter or explicit specification reference; preserve “Adjacent segments do not overlap or omit committed progression” across the handoff.
- [ ] **UC-M07.02-C034-T06 · Absent-input case:** Omit one required “History segmentation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C034-T07 · Stale-input case:** Supply an outdated “History segmentation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C034-T08 · Incompatible-input case:** Supply an incompatible “History segmentation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C034-T09 · Valid integration trace:** Run a valid “History segmentation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C034-T10 · Seam review:** Reconcile the “History segmentation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for history segmentation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “History segmentation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C035-T02 · Expected-result oracle:** Specify the “History segmentation” expected result independently of the implementation output; include the property “Adjacent segments do not overlap or omit committed progression” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C035-T03 · Fixture material:** Create the concrete “History segmentation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C035-T04 · Target preparation:** Prepare the “History segmentation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C035-T05 · Initial-state record:** Record the initial “History segmentation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C035-T06 · Valid-path execution:** Execute the “History segmentation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C035-T07 · Outcome comparison:** Compare every declared “History segmentation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C035-T08 · State and bounds check:** Inspect the “History segmentation” ownership/state effects and actual use of “Segment bytes and segment count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C035-T09 · Repeatability check:** Repeat the same “History segmentation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C035-T10 · Positive evidence:** Attach the “History segmentation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C036 · Negative test

**Original checklist item:** Negative case: Rollover skips a committed tick between segments. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “History segmentation” source counterexample: “Rollover skips a committed tick between segments”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “History segmentation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C036-T03 · Valid control:** Construct a valid “History segmentation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C036-T04 · Minimal adverse input:** Derive the “History segmentation” adverse fixture from the control with the smallest documented change needed to reproduce “Rollover skips a committed tick between segments”; retain that change as reproducible data.
- [ ] **UC-M07.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “History segmentation”; require “Adjacent segments do not overlap or omit committed progression” and forbid a false-success verdict.
- [ ] **UC-M07.02-C036-T06 · Adverse execution:** Exercise the “History segmentation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C036-T07 · Effect inspection:** Inspect “History segmentation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C036-T08 · Refusal versus failure:** Confirm the “History segmentation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C036-T09 · Reset and retention:** Restore only the disposable “History segmentation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C036-T10 · Negative regression:** Register the “History segmentation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C037 · Change / failure test

**Original checklist item:** Exercise history segmentation when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C037-T01 · Scenario record:** Write the “History segmentation” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “Adjacent segments do not overlap or omit committed progression”.
- [ ] **UC-M07.02-C037-T02 · Baseline capture:** Create a known-valid “History segmentation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C037-T03 · Injection map:** Locate the “History segmentation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “History segmentation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C037-T05 · Controlled trigger:** Introduce the controlled “History segmentation” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C037-T06 · Intermediate inspection:** Inspect the “History segmentation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “History segmentation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “History segmentation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C037-T09 · Repeat and compare:** Repeat the selected “History segmentation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C037-T10 · Failure evidence:** Publish the “History segmentation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for segment bytes and segment count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “History segmentation”: “Segment bytes and segment count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C038-T02 · Measurement method:** Choose how to observe each “History segmentation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C038-T03 · Budget decision:** Select justified resource and input limits for “History segmentation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “History segmentation” cases for “Segment bytes and segment count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “History segmentation” limit; preserve “Adjacent segments do not overlap or omit committed progression”.
- [ ] **UC-M07.02-C038-T06 · Normal measurement:** Run or review the normal “History segmentation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C038-T07 · At-limit measurement:** Exercise the “History segmentation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C038-T08 · Over-limit measurement:** Exercise the “History segmentation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C038-T09 · Uncovered-scope report:** List the “History segmentation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C038-T10 · Limit evidence:** Publish the selected “History segmentation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for history segmentation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C039-T01 · Event inventory:** List the “History segmentation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “History segmentation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C039-T03 · Failure mapping:** Map each documented “History segmentation” refusal or error to a diagnostic outcome; include “Rollover skips a committed tick between segments” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C039-T04 · Emission path:** Add the “History segmentation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C039-T05 · Redaction check:** Test “History segmentation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C039-T06 · Output budget:** Set and exercise bounded “History segmentation” message size, rate and retention compatible with “Segment bytes and segment count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C039-T07 · Success/refusal fixtures:** Capture “History segmentation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “History segmentation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C039-T09 · Operator review:** Read the “History segmentation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C039-T10 · Diagnostic evidence:** Publish redacted “History segmentation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for history segmentation; label unexecuted checks as untested.

- [ ] **UC-M07.02-C040-T01 · Evidence inventory:** List the “History segmentation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C040-T02 · Artifact references:** Record the exact “History segmentation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C040-T03 · Fixture references:** Attach the “History segmentation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Rollover skips a committed tick between segments” as a distinct evidence case.
- [ ] **UC-M07.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “History segmentation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C040-T05 · Environment record:** Record the actual “History segmentation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C040-T06 · Expected versus observed:** Pair every “History segmentation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C040-T07 · Failure and limit records:** Attach “History segmentation” change/failure and bounds evidence where required; include uncovered “Segment bytes and segment count” and unresolved violations of “Adjacent segments do not overlap or omit committed progression”.
- [ ] **UC-M07.02-C040-T08 · Evidence hygiene:** Check the “History segmentation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C040-T09 · Reproduction review:** Have the “History segmentation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C040-T10 · Acceptance linkage:** Link the “History segmentation” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Restore index

**Source delivery:** Maintain a validated index relating checkpoints to subsequent history segments.

**Source invariant:** Restore selects a coherent checkpoint/history chain.

**Source negative case:** An index references a missing or different-generation segment.

**Source bounded quantities:** Index entries and lookup time.

### UC-M07.02-C041 · Contract

**Original checklist item:** Specify restore index inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C041-T01 · Scope statement:** Draft the operation boundary for “Restore index” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restore index”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C041-T03 · Output inventory:** List the outputs of “Restore index” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Restore index”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C041-T05 · Prerequisite contract:** Map “Restore index” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Restore index”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C041-T07 · Invariant clause:** Add a normative clause for “Restore index” that preserves “Restore selects a coherent checkpoint/history chain”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restore index”; include the source counterexample “An index references a missing or different-generation segment” and the intended safe disposition.
- [ ] **UC-M07.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Index entries and lookup time” in the “Restore index” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C041-T10 · Contract review:** Review the “Restore index” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C042 · Delivery

**Original checklist item:** Maintain a validated index relating checkpoints to subsequent history segments.

- [ ] **UC-M07.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restore index”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C042-T02 · Change plan:** Break the source delivery for “Restore index” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Restore index” that realizes this source instruction: Maintain a validated index relating checkpoints to subsequent history segments.
- [ ] **UC-M07.02-C042-T04 · Concrete realization:** Trace “Restore index” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restore index” needed to preserve “Restore selects a coherent checkpoint/history chain”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C042-T06 · Dependency connection:** Connect the “Restore index” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C042-T07 · Resource behavior:** Account for “Index entries and lookup time” in “Restore index”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C042-T08 · Delivery check:** Run the smallest real “Restore index” path and its adverse fixture “An index references a missing or different-generation segment”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C042-T09 · Patch review:** Review the “Restore index” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C042-T10 · Delivery handoff:** Publish the “Restore index” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restore selects a coherent checkpoint/history chain. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Restore index”; copy its required invariant exactly: “Restore selects a coherent checkpoint/history chain”.
- [ ] **UC-M07.02-C043-T02 · Observable terms:** Define each term in the “Restore index” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C043-T03 · Precondition set:** List the preconditions under which “Restore selects a coherent checkpoint/history chain” must hold for “Restore index”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C043-T04 · Transition coverage:** Map the “Restore index” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restore index”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C043-T06 · Satisfying fixture:** Create a concrete “Restore index” case that satisfies “Restore selects a coherent checkpoint/history chain”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C043-T07 · Violating fixture:** Create the source counterexample “An index references a missing or different-generation segment” for “Restore index”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C043-T08 · Enforcement evidence:** Exercise the “Restore index” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C043-T09 · Regression linkage:** Link the “Restore index” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Restore index” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C044 · Integration

**Original checklist item:** Integrate restore index with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restore index” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C044-T02 · Field mapping:** Map every “Restore index” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Restore index” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C044-T04 · Ownership agreement:** Specify who owns “Restore index” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C044-T05 · Handoff implementation:** Connect “Restore index” through the mapped seam using the real adapter or explicit specification reference; preserve “Restore selects a coherent checkpoint/history chain” across the handoff.
- [ ] **UC-M07.02-C044-T06 · Absent-input case:** Omit one required “Restore index” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C044-T07 · Stale-input case:** Supply an outdated “Restore index” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Restore index” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C044-T09 · Valid integration trace:** Run a valid “Restore index” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C044-T10 · Seam review:** Reconcile the “Restore index” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restore index; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restore index” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C045-T02 · Expected-result oracle:** Specify the “Restore index” expected result independently of the implementation output; include the property “Restore selects a coherent checkpoint/history chain” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C045-T03 · Fixture material:** Create the concrete “Restore index” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C045-T04 · Target preparation:** Prepare the “Restore index” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C045-T05 · Initial-state record:** Record the initial “Restore index” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C045-T06 · Valid-path execution:** Execute the “Restore index” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C045-T07 · Outcome comparison:** Compare every declared “Restore index” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C045-T08 · State and bounds check:** Inspect the “Restore index” ownership/state effects and actual use of “Index entries and lookup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C045-T09 · Repeatability check:** Repeat the same “Restore index” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C045-T10 · Positive evidence:** Attach the “Restore index” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C046 · Negative test

**Original checklist item:** Negative case: An index references a missing or different-generation segment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Restore index” source counterexample: “An index references a missing or different-generation segment”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Restore index”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C046-T03 · Valid control:** Construct a valid “Restore index” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C046-T04 · Minimal adverse input:** Derive the “Restore index” adverse fixture from the control with the smallest documented change needed to reproduce “An index references a missing or different-generation segment”; retain that change as reproducible data.
- [ ] **UC-M07.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restore index”; require “Restore selects a coherent checkpoint/history chain” and forbid a false-success verdict.
- [ ] **UC-M07.02-C046-T06 · Adverse execution:** Exercise the “Restore index” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C046-T07 · Effect inspection:** Inspect “Restore index” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C046-T08 · Refusal versus failure:** Confirm the “Restore index” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C046-T09 · Reset and retention:** Restore only the disposable “Restore index” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C046-T10 · Negative regression:** Register the “Restore index” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C047 · Change / failure test

**Original checklist item:** Exercise restore index when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C047-T01 · Scenario record:** Write the “Restore index” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “Restore selects a coherent checkpoint/history chain”.
- [ ] **UC-M07.02-C047-T02 · Baseline capture:** Create a known-valid “Restore index” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C047-T03 · Injection map:** Locate the “Restore index” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Restore index” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C047-T05 · Controlled trigger:** Introduce the controlled “Restore index” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C047-T06 · Intermediate inspection:** Inspect the “Restore index” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restore index”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Restore index” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C047-T09 · Repeat and compare:** Repeat the selected “Restore index” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C047-T10 · Failure evidence:** Publish the “Restore index” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for index entries and lookup time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Restore index”: “Index entries and lookup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C048-T02 · Measurement method:** Choose how to observe each “Restore index” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C048-T03 · Budget decision:** Select justified resource and input limits for “Restore index”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restore index” cases for “Index entries and lookup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restore index” limit; preserve “Restore selects a coherent checkpoint/history chain”.
- [ ] **UC-M07.02-C048-T06 · Normal measurement:** Run or review the normal “Restore index” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C048-T07 · At-limit measurement:** Exercise the “Restore index” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C048-T08 · Over-limit measurement:** Exercise the “Restore index” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C048-T09 · Uncovered-scope report:** List the “Restore index” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C048-T10 · Limit evidence:** Publish the selected “Restore index” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restore index with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C049-T01 · Event inventory:** List the “Restore index” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Restore index” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C049-T03 · Failure mapping:** Map each documented “Restore index” refusal or error to a diagnostic outcome; include “An index references a missing or different-generation segment” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C049-T04 · Emission path:** Add the “Restore index” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C049-T05 · Redaction check:** Test “Restore index” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C049-T06 · Output budget:** Set and exercise bounded “Restore index” message size, rate and retention compatible with “Index entries and lookup time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C049-T07 · Success/refusal fixtures:** Capture “Restore index” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restore index” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C049-T09 · Operator review:** Read the “Restore index” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C049-T10 · Diagnostic evidence:** Publish redacted “Restore index” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restore index; label unexecuted checks as untested.

- [ ] **UC-M07.02-C050-T01 · Evidence inventory:** List the “Restore index” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C050-T02 · Artifact references:** Record the exact “Restore index” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C050-T03 · Fixture references:** Attach the “Restore index” fixture IDs, input identities and oracle definition; preserve the source counterexample “An index references a missing or different-generation segment” as a distinct evidence case.
- [ ] **UC-M07.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restore index”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C050-T05 · Environment record:** Record the actual “Restore index” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C050-T06 · Expected versus observed:** Pair every “Restore index” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C050-T07 · Failure and limit records:** Attach “Restore index” change/failure and bounds evidence where required; include uncovered “Index entries and lookup time” and unresolved violations of “Restore selects a coherent checkpoint/history chain”.
- [ ] **UC-M07.02-C050-T08 · Evidence hygiene:** Check the “Restore index” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C050-T09 · Reproduction review:** Have the “Restore index” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C050-T10 · Acceptance linkage:** Link the “Restore index” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Checkpoint verification

**Source delivery:** Verify digests, schema and generation relationships before using checkpoints.

**Source invariant:** A named checkpoint is not trusted solely because its file exists.

**Source negative case:** A checkpoint is modified without changing its filename.

**Source bounded quantities:** Verification bytes and decoder memory.

### UC-M07.02-C051 · Contract

**Original checklist item:** Specify checkpoint verification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C051-T01 · Scope statement:** Draft the operation boundary for “Checkpoint verification” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Checkpoint verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C051-T03 · Output inventory:** List the outputs of “Checkpoint verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Checkpoint verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C051-T05 · Prerequisite contract:** Map “Checkpoint verification” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Checkpoint verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C051-T07 · Invariant clause:** Add a normative clause for “Checkpoint verification” that preserves “A named checkpoint is not trusted solely because its file exists”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Checkpoint verification”; include the source counterexample “A checkpoint is modified without changing its filename” and the intended safe disposition.
- [ ] **UC-M07.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Verification bytes and decoder memory” in the “Checkpoint verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C051-T10 · Contract review:** Review the “Checkpoint verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C052 · Delivery

**Original checklist item:** Verify digests, schema and generation relationships before using checkpoints.

- [ ] **UC-M07.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Checkpoint verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C052-T02 · Change plan:** Break the source delivery for “Checkpoint verification” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C052-T03 · Core artifact:** Create the “Checkpoint verification” fixture or harness for this source instruction: Verify digests, schema and generation relationships before using checkpoints.
- [ ] **UC-M07.02-C052-T04 · Concrete realization:** Connect the “Checkpoint verification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Checkpoint verification” needed to preserve “A named checkpoint is not trusted solely because its file exists”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C052-T06 · Dependency connection:** Connect the “Checkpoint verification” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C052-T07 · Resource behavior:** Account for “Verification bytes and decoder memory” in “Checkpoint verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C052-T08 · Delivery check:** Run the smallest real “Checkpoint verification” path and its adverse fixture “A checkpoint is modified without changing its filename”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C052-T09 · Patch review:** Review the “Checkpoint verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C052-T10 · Delivery handoff:** Publish the “Checkpoint verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A named checkpoint is not trusted solely because its file exists. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Checkpoint verification”; copy its required invariant exactly: “A named checkpoint is not trusted solely because its file exists”.
- [ ] **UC-M07.02-C053-T02 · Observable terms:** Define each term in the “Checkpoint verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C053-T03 · Precondition set:** List the preconditions under which “A named checkpoint is not trusted solely because its file exists” must hold for “Checkpoint verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C053-T04 · Transition coverage:** Map the “Checkpoint verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Checkpoint verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C053-T06 · Satisfying fixture:** Create a concrete “Checkpoint verification” case that satisfies “A named checkpoint is not trusted solely because its file exists”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C053-T07 · Violating fixture:** Create the source counterexample “A checkpoint is modified without changing its filename” for “Checkpoint verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C053-T08 · Enforcement evidence:** Exercise the “Checkpoint verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C053-T09 · Regression linkage:** Link the “Checkpoint verification” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Checkpoint verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C054 · Integration

**Original checklist item:** Integrate checkpoint verification with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Checkpoint verification” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C054-T02 · Field mapping:** Map every “Checkpoint verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Checkpoint verification” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C054-T04 · Ownership agreement:** Specify who owns “Checkpoint verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C054-T05 · Handoff implementation:** Connect “Checkpoint verification” through the mapped seam using the real adapter or explicit specification reference; preserve “A named checkpoint is not trusted solely because its file exists” across the handoff.
- [ ] **UC-M07.02-C054-T06 · Absent-input case:** Omit one required “Checkpoint verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C054-T07 · Stale-input case:** Supply an outdated “Checkpoint verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Checkpoint verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C054-T09 · Valid integration trace:** Run a valid “Checkpoint verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C054-T10 · Seam review:** Reconcile the “Checkpoint verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for checkpoint verification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Checkpoint verification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C055-T02 · Expected-result oracle:** Specify the “Checkpoint verification” expected result independently of the implementation output; include the property “A named checkpoint is not trusted solely because its file exists” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C055-T03 · Fixture material:** Create the concrete “Checkpoint verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C055-T04 · Target preparation:** Prepare the “Checkpoint verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C055-T05 · Initial-state record:** Record the initial “Checkpoint verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C055-T06 · Valid-path execution:** Execute the “Checkpoint verification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C055-T07 · Outcome comparison:** Compare every declared “Checkpoint verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C055-T08 · State and bounds check:** Inspect the “Checkpoint verification” ownership/state effects and actual use of “Verification bytes and decoder memory”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C055-T09 · Repeatability check:** Repeat the same “Checkpoint verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C055-T10 · Positive evidence:** Attach the “Checkpoint verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C056 · Negative test

**Original checklist item:** Negative case: A checkpoint is modified without changing its filename. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Checkpoint verification” source counterexample: “A checkpoint is modified without changing its filename”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Checkpoint verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C056-T03 · Valid control:** Construct a valid “Checkpoint verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C056-T04 · Minimal adverse input:** Derive the “Checkpoint verification” adverse fixture from the control with the smallest documented change needed to reproduce “A checkpoint is modified without changing its filename”; retain that change as reproducible data.
- [ ] **UC-M07.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Checkpoint verification”; require “A named checkpoint is not trusted solely because its file exists” and forbid a false-success verdict.
- [ ] **UC-M07.02-C056-T06 · Adverse execution:** Exercise the “Checkpoint verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C056-T07 · Effect inspection:** Inspect “Checkpoint verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C056-T08 · Refusal versus failure:** Confirm the “Checkpoint verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C056-T09 · Reset and retention:** Restore only the disposable “Checkpoint verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C056-T10 · Negative regression:** Register the “Checkpoint verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C057 · Change / failure test

**Original checklist item:** Exercise checkpoint verification when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C057-T01 · Scenario record:** Write the “Checkpoint verification” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “A named checkpoint is not trusted solely because its file exists”.
- [ ] **UC-M07.02-C057-T02 · Baseline capture:** Create a known-valid “Checkpoint verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C057-T03 · Injection map:** Locate the “Checkpoint verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Checkpoint verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C057-T05 · Controlled trigger:** Introduce the controlled “Checkpoint verification” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C057-T06 · Intermediate inspection:** Inspect the “Checkpoint verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Checkpoint verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Checkpoint verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C057-T09 · Repeat and compare:** Repeat the selected “Checkpoint verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C057-T10 · Failure evidence:** Publish the “Checkpoint verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for verification bytes and decoder memory; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Checkpoint verification”: “Verification bytes and decoder memory”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C058-T02 · Measurement method:** Choose how to observe each “Checkpoint verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Checkpoint verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Checkpoint verification” cases for “Verification bytes and decoder memory”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Checkpoint verification” limit; preserve “A named checkpoint is not trusted solely because its file exists”.
- [ ] **UC-M07.02-C058-T06 · Normal measurement:** Run or review the normal “Checkpoint verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C058-T07 · At-limit measurement:** Exercise the “Checkpoint verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C058-T08 · Over-limit measurement:** Exercise the “Checkpoint verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C058-T09 · Uncovered-scope report:** List the “Checkpoint verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C058-T10 · Limit evidence:** Publish the selected “Checkpoint verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for checkpoint verification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C059-T01 · Event inventory:** List the “Checkpoint verification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Checkpoint verification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C059-T03 · Failure mapping:** Map each documented “Checkpoint verification” refusal or error to a diagnostic outcome; include “A checkpoint is modified without changing its filename” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C059-T04 · Emission path:** Add the “Checkpoint verification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C059-T05 · Redaction check:** Test “Checkpoint verification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C059-T06 · Output budget:** Set and exercise bounded “Checkpoint verification” message size, rate and retention compatible with “Verification bytes and decoder memory”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C059-T07 · Success/refusal fixtures:** Capture “Checkpoint verification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Checkpoint verification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C059-T09 · Operator review:** Read the “Checkpoint verification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C059-T10 · Diagnostic evidence:** Publish redacted “Checkpoint verification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for checkpoint verification; label unexecuted checks as untested.

- [ ] **UC-M07.02-C060-T01 · Evidence inventory:** List the “Checkpoint verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C060-T02 · Artifact references:** Record the exact “Checkpoint verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C060-T03 · Fixture references:** Attach the “Checkpoint verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A checkpoint is modified without changing its filename” as a distinct evidence case.
- [ ] **UC-M07.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Checkpoint verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C060-T05 · Environment record:** Record the actual “Checkpoint verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C060-T06 · Expected versus observed:** Pair every “Checkpoint verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C060-T07 · Failure and limit records:** Attach “Checkpoint verification” change/failure and bounds evidence where required; include uncovered “Verification bytes and decoder memory” and unresolved violations of “A named checkpoint is not trusted solely because its file exists”.
- [ ] **UC-M07.02-C060-T08 · Evidence hygiene:** Check the “Checkpoint verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C060-T09 · Reproduction review:** Have the “Checkpoint verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C060-T10 · Acceptance linkage:** Link the “Checkpoint verification” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Rollover crash recovery

**Source delivery:** Recover safely from interruption before or after checkpoint/index publication.

**Source invariant:** Rollover does not destroy the last complete recoverable chain.

**Source negative case:** A crash occurs after pruning history but before publishing the index.

**Source bounded quantities:** Recovery steps and retained safety margin.

### UC-M07.02-C061 · Contract

**Original checklist item:** Specify rollover crash recovery inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C061-T01 · Scope statement:** Draft the operation boundary for “Rollover crash recovery” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rollover crash recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C061-T03 · Output inventory:** List the outputs of “Rollover crash recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Rollover crash recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C061-T05 · Prerequisite contract:** Map “Rollover crash recovery” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Rollover crash recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C061-T07 · Invariant clause:** Add a normative clause for “Rollover crash recovery” that preserves “Rollover does not destroy the last complete recoverable chain”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rollover crash recovery”; include the source counterexample “A crash occurs after pruning history but before publishing the index” and the intended safe disposition.
- [ ] **UC-M07.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recovery steps and retained safety margin” in the “Rollover crash recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C061-T10 · Contract review:** Review the “Rollover crash recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C062 · Delivery

**Original checklist item:** Recover safely from interruption before or after checkpoint/index publication.

- [ ] **UC-M07.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rollover crash recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C062-T02 · Change plan:** Break the source delivery for “Rollover crash recovery” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Rollover crash recovery” that realizes this source instruction: Recover safely from interruption before or after checkpoint/index publication.
- [ ] **UC-M07.02-C062-T04 · Concrete realization:** Trace “Rollover crash recovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rollover crash recovery” needed to preserve “Rollover does not destroy the last complete recoverable chain”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C062-T06 · Dependency connection:** Connect the “Rollover crash recovery” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C062-T07 · Resource behavior:** Account for “Recovery steps and retained safety margin” in “Rollover crash recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C062-T08 · Delivery check:** Run the smallest real “Rollover crash recovery” path and its adverse fixture “A crash occurs after pruning history but before publishing the index”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C062-T09 · Patch review:** Review the “Rollover crash recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C062-T10 · Delivery handoff:** Publish the “Rollover crash recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rollover does not destroy the last complete recoverable chain. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Rollover crash recovery”; copy its required invariant exactly: “Rollover does not destroy the last complete recoverable chain”.
- [ ] **UC-M07.02-C063-T02 · Observable terms:** Define each term in the “Rollover crash recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C063-T03 · Precondition set:** List the preconditions under which “Rollover does not destroy the last complete recoverable chain” must hold for “Rollover crash recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C063-T04 · Transition coverage:** Map the “Rollover crash recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rollover crash recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C063-T06 · Satisfying fixture:** Create a concrete “Rollover crash recovery” case that satisfies “Rollover does not destroy the last complete recoverable chain”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C063-T07 · Violating fixture:** Create the source counterexample “A crash occurs after pruning history but before publishing the index” for “Rollover crash recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C063-T08 · Enforcement evidence:** Exercise the “Rollover crash recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C063-T09 · Regression linkage:** Link the “Rollover crash recovery” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Rollover crash recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C064 · Integration

**Original checklist item:** Integrate rollover crash recovery with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rollover crash recovery” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C064-T02 · Field mapping:** Map every “Rollover crash recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Rollover crash recovery” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C064-T04 · Ownership agreement:** Specify who owns “Rollover crash recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C064-T05 · Handoff implementation:** Connect “Rollover crash recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Rollover does not destroy the last complete recoverable chain” across the handoff.
- [ ] **UC-M07.02-C064-T06 · Absent-input case:** Omit one required “Rollover crash recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C064-T07 · Stale-input case:** Supply an outdated “Rollover crash recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Rollover crash recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C064-T09 · Valid integration trace:** Run a valid “Rollover crash recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C064-T10 · Seam review:** Reconcile the “Rollover crash recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for rollover crash recovery; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Rollover crash recovery” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C065-T02 · Expected-result oracle:** Specify the “Rollover crash recovery” expected result independently of the implementation output; include the property “Rollover does not destroy the last complete recoverable chain” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C065-T03 · Fixture material:** Create the concrete “Rollover crash recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C065-T04 · Target preparation:** Prepare the “Rollover crash recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C065-T05 · Initial-state record:** Record the initial “Rollover crash recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C065-T06 · Valid-path execution:** Execute the “Rollover crash recovery” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C065-T07 · Outcome comparison:** Compare every declared “Rollover crash recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C065-T08 · State and bounds check:** Inspect the “Rollover crash recovery” ownership/state effects and actual use of “Recovery steps and retained safety margin”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C065-T09 · Repeatability check:** Repeat the same “Rollover crash recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C065-T10 · Positive evidence:** Attach the “Rollover crash recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C066 · Negative test

**Original checklist item:** Negative case: A crash occurs after pruning history but before publishing the index. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Rollover crash recovery” source counterexample: “A crash occurs after pruning history but before publishing the index”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Rollover crash recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C066-T03 · Valid control:** Construct a valid “Rollover crash recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C066-T04 · Minimal adverse input:** Derive the “Rollover crash recovery” adverse fixture from the control with the smallest documented change needed to reproduce “A crash occurs after pruning history but before publishing the index”; retain that change as reproducible data.
- [ ] **UC-M07.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rollover crash recovery”; require “Rollover does not destroy the last complete recoverable chain” and forbid a false-success verdict.
- [ ] **UC-M07.02-C066-T06 · Adverse execution:** Exercise the “Rollover crash recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C066-T07 · Effect inspection:** Inspect “Rollover crash recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C066-T08 · Refusal versus failure:** Confirm the “Rollover crash recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C066-T09 · Reset and retention:** Restore only the disposable “Rollover crash recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C066-T10 · Negative regression:** Register the “Rollover crash recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C067 · Change / failure test

**Original checklist item:** Exercise rollover crash recovery when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C067-T01 · Scenario record:** Write the “Rollover crash recovery” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “Rollover does not destroy the last complete recoverable chain”.
- [ ] **UC-M07.02-C067-T02 · Baseline capture:** Create a known-valid “Rollover crash recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C067-T03 · Injection map:** Locate the “Rollover crash recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Rollover crash recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C067-T05 · Controlled trigger:** Introduce the controlled “Rollover crash recovery” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C067-T06 · Intermediate inspection:** Inspect the “Rollover crash recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rollover crash recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Rollover crash recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C067-T09 · Repeat and compare:** Repeat the selected “Rollover crash recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C067-T10 · Failure evidence:** Publish the “Rollover crash recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for recovery steps and retained safety margin; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Rollover crash recovery”: “Recovery steps and retained safety margin”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C068-T02 · Measurement method:** Choose how to observe each “Rollover crash recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Rollover crash recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rollover crash recovery” cases for “Recovery steps and retained safety margin”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rollover crash recovery” limit; preserve “Rollover does not destroy the last complete recoverable chain”.
- [ ] **UC-M07.02-C068-T06 · Normal measurement:** Run or review the normal “Rollover crash recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C068-T07 · At-limit measurement:** Exercise the “Rollover crash recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C068-T08 · Over-limit measurement:** Exercise the “Rollover crash recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C068-T09 · Uncovered-scope report:** List the “Rollover crash recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C068-T10 · Limit evidence:** Publish the selected “Rollover crash recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for rollover crash recovery with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C069-T01 · Event inventory:** List the “Rollover crash recovery” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Rollover crash recovery” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C069-T03 · Failure mapping:** Map each documented “Rollover crash recovery” refusal or error to a diagnostic outcome; include “A crash occurs after pruning history but before publishing the index” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C069-T04 · Emission path:** Add the “Rollover crash recovery” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C069-T05 · Redaction check:** Test “Rollover crash recovery” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C069-T06 · Output budget:** Set and exercise bounded “Rollover crash recovery” message size, rate and retention compatible with “Recovery steps and retained safety margin”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C069-T07 · Success/refusal fixtures:** Capture “Rollover crash recovery” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Rollover crash recovery” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C069-T09 · Operator review:** Read the “Rollover crash recovery” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C069-T10 · Diagnostic evidence:** Publish redacted “Rollover crash recovery” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rollover crash recovery; label unexecuted checks as untested.

- [ ] **UC-M07.02-C070-T01 · Evidence inventory:** List the “Rollover crash recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C070-T02 · Artifact references:** Record the exact “Rollover crash recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C070-T03 · Fixture references:** Attach the “Rollover crash recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “A crash occurs after pruning history but before publishing the index” as a distinct evidence case.
- [ ] **UC-M07.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rollover crash recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C070-T05 · Environment record:** Record the actual “Rollover crash recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C070-T06 · Expected versus observed:** Pair every “Rollover crash recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C070-T07 · Failure and limit records:** Attach “Rollover crash recovery” change/failure and bounds evidence where required; include uncovered “Recovery steps and retained safety margin” and unresolved violations of “Rollover does not destroy the last complete recoverable chain”.
- [ ] **UC-M07.02-C070-T08 · Evidence hygiene:** Check the “Rollover crash recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C070-T09 · Reproduction review:** Have the “Rollover crash recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C070-T10 · Acceptance linkage:** Link the “Rollover crash recovery” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Retention policy

**Source delivery:** Retain required checkpoints and dependent history according to explicit policy.

**Source invariant:** Pruning cannot remove the only state needed by a retained restore point.

**Source negative case:** A retained checkpoint depends on a deleted segment.

**Source bounded quantities:** Retained checkpoints and total history bytes.

### UC-M07.02-C071 · Contract

**Original checklist item:** Specify retention policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C071-T01 · Scope statement:** Draft the operation boundary for “Retention policy” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Retention policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C071-T03 · Output inventory:** List the outputs of “Retention policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Retention policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C071-T05 · Prerequisite contract:** Map “Retention policy” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Retention policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C071-T07 · Invariant clause:** Add a normative clause for “Retention policy” that preserves “Pruning cannot remove the only state needed by a retained restore point”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Retention policy”; include the source counterexample “A retained checkpoint depends on a deleted segment” and the intended safe disposition.
- [ ] **UC-M07.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained checkpoints and total history bytes” in the “Retention policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C071-T10 · Contract review:** Review the “Retention policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C072 · Delivery

**Original checklist item:** Retain required checkpoints and dependent history according to explicit policy.

- [ ] **UC-M07.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Retention policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C072-T02 · Change plan:** Break the source delivery for “Retention policy” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Retention policy” that realizes this source instruction: Retain required checkpoints and dependent history according to explicit policy.
- [ ] **UC-M07.02-C072-T04 · Concrete realization:** Trace “Retention policy” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Retention policy” needed to preserve “Pruning cannot remove the only state needed by a retained restore point”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C072-T06 · Dependency connection:** Connect the “Retention policy” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C072-T07 · Resource behavior:** Account for “Retained checkpoints and total history bytes” in “Retention policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C072-T08 · Delivery check:** Run the smallest real “Retention policy” path and its adverse fixture “A retained checkpoint depends on a deleted segment”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C072-T09 · Patch review:** Review the “Retention policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C072-T10 · Delivery handoff:** Publish the “Retention policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Pruning cannot remove the only state needed by a retained restore point. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Retention policy”; copy its required invariant exactly: “Pruning cannot remove the only state needed by a retained restore point”.
- [ ] **UC-M07.02-C073-T02 · Observable terms:** Define each term in the “Retention policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C073-T03 · Precondition set:** List the preconditions under which “Pruning cannot remove the only state needed by a retained restore point” must hold for “Retention policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C073-T04 · Transition coverage:** Map the “Retention policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Retention policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C073-T06 · Satisfying fixture:** Create a concrete “Retention policy” case that satisfies “Pruning cannot remove the only state needed by a retained restore point”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C073-T07 · Violating fixture:** Create the source counterexample “A retained checkpoint depends on a deleted segment” for “Retention policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C073-T08 · Enforcement evidence:** Exercise the “Retention policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C073-T09 · Regression linkage:** Link the “Retention policy” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Retention policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C074 · Integration

**Original checklist item:** Integrate retention policy with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Retention policy” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C074-T02 · Field mapping:** Map every “Retention policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Retention policy” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C074-T04 · Ownership agreement:** Specify who owns “Retention policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C074-T05 · Handoff implementation:** Connect “Retention policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Pruning cannot remove the only state needed by a retained restore point” across the handoff.
- [ ] **UC-M07.02-C074-T06 · Absent-input case:** Omit one required “Retention policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C074-T07 · Stale-input case:** Supply an outdated “Retention policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Retention policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C074-T09 · Valid integration trace:** Run a valid “Retention policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C074-T10 · Seam review:** Reconcile the “Retention policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for retention policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Retention policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C075-T02 · Expected-result oracle:** Specify the “Retention policy” expected result independently of the implementation output; include the property “Pruning cannot remove the only state needed by a retained restore point” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C075-T03 · Fixture material:** Create the concrete “Retention policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C075-T04 · Target preparation:** Prepare the “Retention policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C075-T05 · Initial-state record:** Record the initial “Retention policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C075-T06 · Valid-path execution:** Execute the “Retention policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C075-T07 · Outcome comparison:** Compare every declared “Retention policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C075-T08 · State and bounds check:** Inspect the “Retention policy” ownership/state effects and actual use of “Retained checkpoints and total history bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C075-T09 · Repeatability check:** Repeat the same “Retention policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C075-T10 · Positive evidence:** Attach the “Retention policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C076 · Negative test

**Original checklist item:** Negative case: A retained checkpoint depends on a deleted segment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Retention policy” source counterexample: “A retained checkpoint depends on a deleted segment”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Retention policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C076-T03 · Valid control:** Construct a valid “Retention policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C076-T04 · Minimal adverse input:** Derive the “Retention policy” adverse fixture from the control with the smallest documented change needed to reproduce “A retained checkpoint depends on a deleted segment”; retain that change as reproducible data.
- [ ] **UC-M07.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Retention policy”; require “Pruning cannot remove the only state needed by a retained restore point” and forbid a false-success verdict.
- [ ] **UC-M07.02-C076-T06 · Adverse execution:** Exercise the “Retention policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C076-T07 · Effect inspection:** Inspect “Retention policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C076-T08 · Refusal versus failure:** Confirm the “Retention policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C076-T09 · Reset and retention:** Restore only the disposable “Retention policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C076-T10 · Negative regression:** Register the “Retention policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C077 · Change / failure test

**Original checklist item:** Exercise retention policy when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C077-T01 · Scenario record:** Write the “Retention policy” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “Pruning cannot remove the only state needed by a retained restore point”.
- [ ] **UC-M07.02-C077-T02 · Baseline capture:** Create a known-valid “Retention policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C077-T03 · Injection map:** Locate the “Retention policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Retention policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C077-T05 · Controlled trigger:** Introduce the controlled “Retention policy” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C077-T06 · Intermediate inspection:** Inspect the “Retention policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Retention policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Retention policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C077-T09 · Repeat and compare:** Repeat the selected “Retention policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C077-T10 · Failure evidence:** Publish the “Retention policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for retained checkpoints and total history bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Retention policy”: “Retained checkpoints and total history bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C078-T02 · Measurement method:** Choose how to observe each “Retention policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Retention policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Retention policy” cases for “Retained checkpoints and total history bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Retention policy” limit; preserve “Pruning cannot remove the only state needed by a retained restore point”.
- [ ] **UC-M07.02-C078-T06 · Normal measurement:** Run or review the normal “Retention policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C078-T07 · At-limit measurement:** Exercise the “Retention policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C078-T08 · Over-limit measurement:** Exercise the “Retention policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C078-T09 · Uncovered-scope report:** List the “Retention policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C078-T10 · Limit evidence:** Publish the selected “Retention policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for retention policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C079-T01 · Event inventory:** List the “Retention policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Retention policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C079-T03 · Failure mapping:** Map each documented “Retention policy” refusal or error to a diagnostic outcome; include “A retained checkpoint depends on a deleted segment” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C079-T04 · Emission path:** Add the “Retention policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C079-T05 · Redaction check:** Test “Retention policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C079-T06 · Output budget:** Set and exercise bounded “Retention policy” message size, rate and retention compatible with “Retained checkpoints and total history bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C079-T07 · Success/refusal fixtures:** Capture “Retention policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Retention policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C079-T09 · Operator review:** Read the “Retention policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C079-T10 · Diagnostic evidence:** Publish redacted “Retention policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for retention policy; label unexecuted checks as untested.

- [ ] **UC-M07.02-C080-T01 · Evidence inventory:** List the “Retention policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C080-T02 · Artifact references:** Record the exact “Retention policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C080-T03 · Fixture references:** Attach the “Retention policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A retained checkpoint depends on a deleted segment” as a distinct evidence case.
- [ ] **UC-M07.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Retention policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C080-T05 · Environment record:** Record the actual “Retention policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C080-T06 · Expected versus observed:** Pair every “Retention policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C080-T07 · Failure and limit records:** Attach “Retention policy” change/failure and bounds evidence where required; include uncovered “Retained checkpoints and total history bytes” and unresolved violations of “Pruning cannot remove the only state needed by a retained restore point”.
- [ ] **UC-M07.02-C080-T08 · Evidence hygiene:** Check the “Retention policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C080-T09 · Reproduction review:** Have the “Retention policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C080-T10 · Acceptance linkage:** Link the “Retention policy” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Uninterrupted equivalence

**Source delivery:** Compare long-running rolled-over state with uninterrupted reference execution.

**Source invariant:** Rollover preserves the declared application state semantics.

**Source negative case:** The restored state differs after crossing a segment boundary.

**Source bounded quantities:** Run length and comparison state size.

### UC-M07.02-C081 · Contract

**Original checklist item:** Specify uninterrupted equivalence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C081-T01 · Scope statement:** Draft the operation boundary for “Uninterrupted equivalence” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Uninterrupted equivalence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C081-T03 · Output inventory:** List the outputs of “Uninterrupted equivalence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Uninterrupted equivalence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C081-T05 · Prerequisite contract:** Map “Uninterrupted equivalence” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Uninterrupted equivalence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C081-T07 · Invariant clause:** Add a normative clause for “Uninterrupted equivalence” that preserves “Rollover preserves the declared application state semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Uninterrupted equivalence”; include the source counterexample “The restored state differs after crossing a segment boundary” and the intended safe disposition.
- [ ] **UC-M07.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Run length and comparison state size” in the “Uninterrupted equivalence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C081-T10 · Contract review:** Review the “Uninterrupted equivalence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C082 · Delivery

**Original checklist item:** Compare long-running rolled-over state with uninterrupted reference execution.

- [ ] **UC-M07.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Uninterrupted equivalence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C082-T02 · Change plan:** Break the source delivery for “Uninterrupted equivalence” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C082-T03 · Core artifact:** Create the “Uninterrupted equivalence” fixture or harness for this source instruction: Compare long-running rolled-over state with uninterrupted reference execution.
- [ ] **UC-M07.02-C082-T04 · Concrete realization:** Connect the “Uninterrupted equivalence” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Uninterrupted equivalence” needed to preserve “Rollover preserves the declared application state semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C082-T06 · Dependency connection:** Connect the “Uninterrupted equivalence” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C082-T07 · Resource behavior:** Account for “Run length and comparison state size” in “Uninterrupted equivalence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C082-T08 · Delivery check:** Run the smallest real “Uninterrupted equivalence” path and its adverse fixture “The restored state differs after crossing a segment boundary”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C082-T09 · Patch review:** Review the “Uninterrupted equivalence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C082-T10 · Delivery handoff:** Publish the “Uninterrupted equivalence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rollover preserves the declared application state semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Uninterrupted equivalence”; copy its required invariant exactly: “Rollover preserves the declared application state semantics”.
- [ ] **UC-M07.02-C083-T02 · Observable terms:** Define each term in the “Uninterrupted equivalence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C083-T03 · Precondition set:** List the preconditions under which “Rollover preserves the declared application state semantics” must hold for “Uninterrupted equivalence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C083-T04 · Transition coverage:** Map the “Uninterrupted equivalence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Uninterrupted equivalence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C083-T06 · Satisfying fixture:** Create a concrete “Uninterrupted equivalence” case that satisfies “Rollover preserves the declared application state semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C083-T07 · Violating fixture:** Create the source counterexample “The restored state differs after crossing a segment boundary” for “Uninterrupted equivalence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C083-T08 · Enforcement evidence:** Exercise the “Uninterrupted equivalence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C083-T09 · Regression linkage:** Link the “Uninterrupted equivalence” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Uninterrupted equivalence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C084 · Integration

**Original checklist item:** Integrate uninterrupted equivalence with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Uninterrupted equivalence” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C084-T02 · Field mapping:** Map every “Uninterrupted equivalence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Uninterrupted equivalence” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C084-T04 · Ownership agreement:** Specify who owns “Uninterrupted equivalence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C084-T05 · Handoff implementation:** Connect “Uninterrupted equivalence” through the mapped seam using the real adapter or explicit specification reference; preserve “Rollover preserves the declared application state semantics” across the handoff.
- [ ] **UC-M07.02-C084-T06 · Absent-input case:** Omit one required “Uninterrupted equivalence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C084-T07 · Stale-input case:** Supply an outdated “Uninterrupted equivalence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Uninterrupted equivalence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C084-T09 · Valid integration trace:** Run a valid “Uninterrupted equivalence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C084-T10 · Seam review:** Reconcile the “Uninterrupted equivalence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for uninterrupted equivalence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Uninterrupted equivalence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C085-T02 · Expected-result oracle:** Specify the “Uninterrupted equivalence” expected result independently of the implementation output; include the property “Rollover preserves the declared application state semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C085-T03 · Fixture material:** Create the concrete “Uninterrupted equivalence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C085-T04 · Target preparation:** Prepare the “Uninterrupted equivalence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C085-T05 · Initial-state record:** Record the initial “Uninterrupted equivalence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C085-T06 · Valid-path execution:** Execute the “Uninterrupted equivalence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C085-T07 · Outcome comparison:** Compare every declared “Uninterrupted equivalence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C085-T08 · State and bounds check:** Inspect the “Uninterrupted equivalence” ownership/state effects and actual use of “Run length and comparison state size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C085-T09 · Repeatability check:** Repeat the same “Uninterrupted equivalence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C085-T10 · Positive evidence:** Attach the “Uninterrupted equivalence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C086 · Negative test

**Original checklist item:** Negative case: The restored state differs after crossing a segment boundary. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Uninterrupted equivalence” source counterexample: “The restored state differs after crossing a segment boundary”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Uninterrupted equivalence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C086-T03 · Valid control:** Construct a valid “Uninterrupted equivalence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C086-T04 · Minimal adverse input:** Derive the “Uninterrupted equivalence” adverse fixture from the control with the smallest documented change needed to reproduce “The restored state differs after crossing a segment boundary”; retain that change as reproducible data.
- [ ] **UC-M07.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Uninterrupted equivalence”; require “Rollover preserves the declared application state semantics” and forbid a false-success verdict.
- [ ] **UC-M07.02-C086-T06 · Adverse execution:** Exercise the “Uninterrupted equivalence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C086-T07 · Effect inspection:** Inspect “Uninterrupted equivalence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C086-T08 · Refusal versus failure:** Confirm the “Uninterrupted equivalence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C086-T09 · Reset and retention:** Restore only the disposable “Uninterrupted equivalence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C086-T10 · Negative regression:** Register the “Uninterrupted equivalence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C087 · Change / failure test

**Original checklist item:** Exercise uninterrupted equivalence when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C087-T01 · Scenario record:** Write the “Uninterrupted equivalence” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “Rollover preserves the declared application state semantics”.
- [ ] **UC-M07.02-C087-T02 · Baseline capture:** Create a known-valid “Uninterrupted equivalence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C087-T03 · Injection map:** Locate the “Uninterrupted equivalence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Uninterrupted equivalence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C087-T05 · Controlled trigger:** Introduce the controlled “Uninterrupted equivalence” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C087-T06 · Intermediate inspection:** Inspect the “Uninterrupted equivalence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Uninterrupted equivalence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Uninterrupted equivalence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C087-T09 · Repeat and compare:** Repeat the selected “Uninterrupted equivalence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C087-T10 · Failure evidence:** Publish the “Uninterrupted equivalence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for run length and comparison state size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Uninterrupted equivalence”: “Run length and comparison state size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C088-T02 · Measurement method:** Choose how to observe each “Uninterrupted equivalence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Uninterrupted equivalence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Uninterrupted equivalence” cases for “Run length and comparison state size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Uninterrupted equivalence” limit; preserve “Rollover preserves the declared application state semantics”.
- [ ] **UC-M07.02-C088-T06 · Normal measurement:** Run or review the normal “Uninterrupted equivalence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C088-T07 · At-limit measurement:** Exercise the “Uninterrupted equivalence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C088-T08 · Over-limit measurement:** Exercise the “Uninterrupted equivalence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C088-T09 · Uncovered-scope report:** List the “Uninterrupted equivalence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C088-T10 · Limit evidence:** Publish the selected “Uninterrupted equivalence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for uninterrupted equivalence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C089-T01 · Event inventory:** List the “Uninterrupted equivalence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Uninterrupted equivalence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C089-T03 · Failure mapping:** Map each documented “Uninterrupted equivalence” refusal or error to a diagnostic outcome; include “The restored state differs after crossing a segment boundary” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C089-T04 · Emission path:** Add the “Uninterrupted equivalence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C089-T05 · Redaction check:** Test “Uninterrupted equivalence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C089-T06 · Output budget:** Set and exercise bounded “Uninterrupted equivalence” message size, rate and retention compatible with “Run length and comparison state size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C089-T07 · Success/refusal fixtures:** Capture “Uninterrupted equivalence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Uninterrupted equivalence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C089-T09 · Operator review:** Read the “Uninterrupted equivalence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C089-T10 · Diagnostic evidence:** Publish redacted “Uninterrupted equivalence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for uninterrupted equivalence; label unexecuted checks as untested.

- [ ] **UC-M07.02-C090-T01 · Evidence inventory:** List the “Uninterrupted equivalence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C090-T02 · Artifact references:** Record the exact “Uninterrupted equivalence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C090-T03 · Fixture references:** Attach the “Uninterrupted equivalence” fixture IDs, input identities and oracle definition; preserve the source counterexample “The restored state differs after crossing a segment boundary” as a distinct evidence case.
- [ ] **UC-M07.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Uninterrupted equivalence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C090-T05 · Environment record:** Record the actual “Uninterrupted equivalence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C090-T06 · Expected versus observed:** Pair every “Uninterrupted equivalence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C090-T07 · Failure and limit records:** Attach “Uninterrupted equivalence” change/failure and bounds evidence where required; include uncovered “Run length and comparison state size” and unresolved violations of “Rollover preserves the declared application state semantics”.
- [ ] **UC-M07.02-C090-T08 · Evidence hygiene:** Check the “Uninterrupted equivalence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C090-T09 · Reproduction review:** Have the “Uninterrupted equivalence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C090-T10 · Acceptance linkage:** Link the “Uninterrupted equivalence” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Rollover observability

**Source delivery:** Expose checkpoint progress, segment use and refusal reasons.

**Source invariant:** Operators can distinguish safe rollover from a history-limit failure.

**Source negative case:** A stalled rollover is displayed as healthy ongoing execution.

**Source bounded quantities:** Status bytes and last-progress age.

### UC-M07.02-C091 · Contract

**Original checklist item:** Specify rollover observability inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.02-C091-T01 · Scope statement:** Draft the operation boundary for “Rollover observability” within Checkpoint and history rollover; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rollover observability”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.02-C091-T03 · Output inventory:** List the outputs of “Rollover observability” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Rollover observability”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.02-C091-T05 · Prerequisite contract:** Map “Rollover observability” to the source component prerequisites (UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Rollover observability”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.02-C091-T07 · Invariant clause:** Add a normative clause for “Rollover observability” that preserves “Operators can distinguish safe rollover from a history-limit failure”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rollover observability”; include the source counterexample “A stalled rollover is displayed as healthy ongoing execution” and the intended safe disposition.
- [ ] **UC-M07.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Status bytes and last-progress age” in the “Rollover observability” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.02-C091-T10 · Contract review:** Review the “Rollover observability” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.02-C092 · Delivery

**Original checklist item:** Expose checkpoint progress, segment use and refusal reasons.

- [ ] **UC-M07.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rollover observability”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.02-C092-T02 · Change plan:** Break the source delivery for “Rollover observability” into concrete edit targets and reviewable outputs; keep the UC-M07.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.02-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Rollover observability” that realizes this source instruction: Expose checkpoint progress, segment use and refusal reasons.
- [ ] **UC-M07.02-C092-T04 · Concrete realization:** Trace “Rollover observability” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rollover observability” needed to preserve “Operators can distinguish safe rollover from a history-limit failure”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.02-C092-T06 · Dependency connection:** Connect the “Rollover observability” implementation to TIFF history segments, immutable checkpoints and the restore index; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.02-C092-T07 · Resource behavior:** Account for “Status bytes and last-progress age” in “Rollover observability”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.02-C092-T08 · Delivery check:** Run the smallest real “Rollover observability” path and its adverse fixture “A stalled rollover is displayed as healthy ongoing execution”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.02-C092-T09 · Patch review:** Review the “Rollover observability” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.02-C092-T10 · Delivery handoff:** Publish the “Rollover observability” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Operators can distinguish safe rollover from a history-limit failure. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Rollover observability”; copy its required invariant exactly: “Operators can distinguish safe rollover from a history-limit failure”.
- [ ] **UC-M07.02-C093-T02 · Observable terms:** Define each term in the “Rollover observability” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.02-C093-T03 · Precondition set:** List the preconditions under which “Operators can distinguish safe rollover from a history-limit failure” must hold for “Rollover observability”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.02-C093-T04 · Transition coverage:** Map the “Rollover observability” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rollover observability”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.02-C093-T06 · Satisfying fixture:** Create a concrete “Rollover observability” case that satisfies “Operators can distinguish safe rollover from a history-limit failure”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.02-C093-T07 · Violating fixture:** Create the source counterexample “A stalled rollover is displayed as healthy ongoing execution” for “Rollover observability”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.02-C093-T08 · Enforcement evidence:** Exercise the “Rollover observability” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.02-C093-T09 · Regression linkage:** Link the “Rollover observability” property to changes in TIFF history segments, immutable checkpoints and the restore index; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Rollover observability” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.02-C094 · Integration

**Original checklist item:** Integrate rollover observability with TIFF history segments, immutable checkpoints and the restore index; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rollover observability” across TIFF history segments, immutable checkpoints and the restore index; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.02-C094-T02 · Field mapping:** Map every “Rollover observability” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Rollover observability” (source dependency list: UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.02-C094-T04 · Ownership agreement:** Specify who owns “Rollover observability” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.02-C094-T05 · Handoff implementation:** Connect “Rollover observability” through the mapped seam using the real adapter or explicit specification reference; preserve “Operators can distinguish safe rollover from a history-limit failure” across the handoff.
- [ ] **UC-M07.02-C094-T06 · Absent-input case:** Omit one required “Rollover observability” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.02-C094-T07 · Stale-input case:** Supply an outdated “Rollover observability” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Rollover observability” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.02-C094-T09 · Valid integration trace:** Run a valid “Rollover observability” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.02-C094-T10 · Seam review:** Reconcile the “Rollover observability” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for rollover observability; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Rollover observability” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.02-C095-T02 · Expected-result oracle:** Specify the “Rollover observability” expected result independently of the implementation output; include the property “Operators can distinguish safe rollover from a history-limit failure” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.02-C095-T03 · Fixture material:** Create the concrete “Rollover observability” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.02-C095-T04 · Target preparation:** Prepare the “Rollover observability” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.02-C095-T05 · Initial-state record:** Record the initial “Rollover observability” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.02-C095-T06 · Valid-path execution:** Execute the “Rollover observability” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.02-C095-T07 · Outcome comparison:** Compare every declared “Rollover observability” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.02-C095-T08 · State and bounds check:** Inspect the “Rollover observability” ownership/state effects and actual use of “Status bytes and last-progress age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.02-C095-T09 · Repeatability check:** Repeat the same “Rollover observability” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.02-C095-T10 · Positive evidence:** Attach the “Rollover observability” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.02-C096 · Negative test

**Original checklist item:** Negative case: A stalled rollover is displayed as healthy ongoing execution. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Rollover observability” source counterexample: “A stalled rollover is displayed as healthy ongoing execution”; state which precondition or invariant it challenges.
- [ ] **UC-M07.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Rollover observability”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.02-C096-T03 · Valid control:** Construct a valid “Rollover observability” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.02-C096-T04 · Minimal adverse input:** Derive the “Rollover observability” adverse fixture from the control with the smallest documented change needed to reproduce “A stalled rollover is displayed as healthy ongoing execution”; retain that change as reproducible data.
- [ ] **UC-M07.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rollover observability”; require “Operators can distinguish safe rollover from a history-limit failure” and forbid a false-success verdict.
- [ ] **UC-M07.02-C096-T06 · Adverse execution:** Exercise the “Rollover observability” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.02-C096-T07 · Effect inspection:** Inspect “Rollover observability” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.02-C096-T08 · Refusal versus failure:** Confirm the “Rollover observability” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.02-C096-T09 · Reset and retention:** Restore only the disposable “Rollover observability” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.02-C096-T10 · Negative regression:** Register the “Rollover observability” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.02-C097 · Change / failure test

**Original checklist item:** Exercise rollover observability when history rollover is interrupted between checkpoint publication and index update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.02-C097-T01 · Scenario record:** Write the “Rollover observability” change/failure scenario exactly as supplied: history rollover is interrupted between checkpoint publication and index update; identify the property that must remain true: “Operators can distinguish safe rollover from a history-limit failure”.
- [ ] **UC-M07.02-C097-T02 · Baseline capture:** Create a known-valid “Rollover observability” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.02-C097-T03 · Injection map:** Locate the “Rollover observability” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Rollover observability” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.02-C097-T05 · Controlled trigger:** Introduce the controlled “Rollover observability” scenario in the disposable fixture: history rollover is interrupted between checkpoint publication and index update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.02-C097-T06 · Intermediate inspection:** Inspect the “Rollover observability” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rollover observability”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Rollover observability” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.02-C097-T09 · Repeat and compare:** Repeat the selected “Rollover observability” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.02-C097-T10 · Failure evidence:** Publish the “Rollover observability” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for status bytes and last-progress age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Rollover observability”: “Status bytes and last-progress age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.02-C098-T02 · Measurement method:** Choose how to observe each “Rollover observability” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Rollover observability”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rollover observability” cases for “Status bytes and last-progress age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rollover observability” limit; preserve “Operators can distinguish safe rollover from a history-limit failure”.
- [ ] **UC-M07.02-C098-T06 · Normal measurement:** Run or review the normal “Rollover observability” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.02-C098-T07 · At-limit measurement:** Exercise the “Rollover observability” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.02-C098-T08 · Over-limit measurement:** Exercise the “Rollover observability” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.02-C098-T09 · Uncovered-scope report:** List the “Rollover observability” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.02-C098-T10 · Limit evidence:** Publish the selected “Rollover observability” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for rollover observability with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.02-C099-T01 · Event inventory:** List the “Rollover observability” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Rollover observability” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.02-C099-T03 · Failure mapping:** Map each documented “Rollover observability” refusal or error to a diagnostic outcome; include “A stalled rollover is displayed as healthy ongoing execution” and prohibit conversion into a success message.
- [ ] **UC-M07.02-C099-T04 · Emission path:** Add the “Rollover observability” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.02-C099-T05 · Redaction check:** Test “Rollover observability” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.02-C099-T06 · Output budget:** Set and exercise bounded “Rollover observability” message size, rate and retention compatible with “Status bytes and last-progress age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.02-C099-T07 · Success/refusal fixtures:** Capture “Rollover observability” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Rollover observability” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.02-C099-T09 · Operator review:** Read the “Rollover observability” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.02-C099-T10 · Diagnostic evidence:** Publish redacted “Rollover observability” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rollover observability; label unexecuted checks as untested.

- [ ] **UC-M07.02-C100-T01 · Evidence inventory:** List the “Rollover observability” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.02-C100-T02 · Artifact references:** Record the exact “Rollover observability” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.02-C100-T03 · Fixture references:** Attach the “Rollover observability” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stalled rollover is displayed as healthy ongoing execution” as a distinct evidence case.
- [ ] **UC-M07.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rollover observability”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.02-C100-T05 · Environment record:** Record the actual “Rollover observability” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.02-C100-T06 · Expected versus observed:** Pair every “Rollover observability” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.02-C100-T07 · Failure and limit records:** Attach “Rollover observability” change/failure and bounds evidence where required; include uncovered “Status bytes and last-progress age” and unresolved violations of “Operators can distinguish safe rollover from a history-limit failure”.
- [ ] **UC-M07.02-C100-T08 · Evidence hygiene:** Check the “Rollover observability” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.02-C100-T09 · Reproduction review:** Have the “Rollover observability” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.02-C100-T10 · Acceptance linkage:** Link the “Rollover observability” evidence to its parent and UC-M07.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

