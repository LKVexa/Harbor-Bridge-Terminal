# UC-M07.08 — Verified rollback and recovery commands

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/07.md)

| Field | Preserved source value |
|---|---|
| Workstream | 07. Persistence, transactions and recovery |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M07.01](../07/UC-M07.01.md), [UC-M07.03](../07/UC-M07.03.md), [UC-M07.07](../07/UC-M07.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S8]. |

## Original requirement

Provide operator-facing inspect, restore and abandon commands for retained backups and transaction journals, with generation checks.

**Original acceptance criterion:** Automated restore returns registry, seals and mount state to a verified generation rather than only moving a directory.

**Source trace:** Original checklist `UC100/c/07/UC-M07.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 696–707 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Recovery inventory

**Source delivery:** Inspect retained backups and journals with identities, generations and integrity status.

**Source invariant:** Recovery choices are based on validated metadata rather than folder names.

**Source negative case:** The newest-looking directory is selected without verification.

**Source bounded quantities:** Backups, journals and inspection bytes.

### UC-M07.08-C001 · Contract

**Original checklist item:** Specify recovery inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C001-T01 · Scope statement:** Draft the operation boundary for “Recovery inventory” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recovery inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C001-T03 · Output inventory:** List the outputs of “Recovery inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Recovery inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C001-T05 · Prerequisite contract:** Map “Recovery inventory” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C001-T06 · Authority map:** Identify who may produce, change and consume “Recovery inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C001-T07 · Invariant clause:** Add a normative clause for “Recovery inventory” that preserves “Recovery choices are based on validated metadata rather than folder names”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recovery inventory”; include the source counterexample “The newest-looking directory is selected without verification” and the intended safe disposition.
- [ ] **UC-M07.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Backups, journals and inspection bytes” in the “Recovery inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C001-T10 · Contract review:** Review the “Recovery inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C002 · Delivery

**Original checklist item:** Inspect retained backups and journals with identities, generations and integrity status.

- [ ] **UC-M07.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recovery inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C002-T02 · Change plan:** Break the source delivery for “Recovery inventory” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Recovery inventory” that realizes this source instruction: Inspect retained backups and journals with identities, generations and integrity status.
- [ ] **UC-M07.08-C002-T04 · Concrete realization:** Trace “Recovery inventory” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recovery inventory” needed to preserve “Recovery choices are based on validated metadata rather than folder names”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C002-T06 · Dependency connection:** Connect the “Recovery inventory” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C002-T07 · Resource behavior:** Account for “Backups, journals and inspection bytes” in “Recovery inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C002-T08 · Delivery check:** Run the smallest real “Recovery inventory” path and its adverse fixture “The newest-looking directory is selected without verification”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C002-T09 · Patch review:** Review the “Recovery inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C002-T10 · Delivery handoff:** Publish the “Recovery inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery choices are based on validated metadata rather than folder names. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “Recovery inventory”; copy its required invariant exactly: “Recovery choices are based on validated metadata rather than folder names”.
- [ ] **UC-M07.08-C003-T02 · Observable terms:** Define each term in the “Recovery inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C003-T03 · Precondition set:** List the preconditions under which “Recovery choices are based on validated metadata rather than folder names” must hold for “Recovery inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C003-T04 · Transition coverage:** Map the “Recovery inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recovery inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C003-T06 · Satisfying fixture:** Create a concrete “Recovery inventory” case that satisfies “Recovery choices are based on validated metadata rather than folder names”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C003-T07 · Violating fixture:** Create the source counterexample “The newest-looking directory is selected without verification” for “Recovery inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C003-T08 · Enforcement evidence:** Exercise the “Recovery inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C003-T09 · Regression linkage:** Link the “Recovery inventory” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C003-T10 · Property disposition:** Compare the satisfying and violating “Recovery inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C004 · Integration

**Original checklist item:** Integrate recovery inventory with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recovery inventory” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C004-T02 · Field mapping:** Map every “Recovery inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Recovery inventory” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C004-T04 · Ownership agreement:** Specify who owns “Recovery inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C004-T05 · Handoff implementation:** Connect “Recovery inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery choices are based on validated metadata rather than folder names” across the handoff.
- [ ] **UC-M07.08-C004-T06 · Absent-input case:** Omit one required “Recovery inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C004-T07 · Stale-input case:** Supply an outdated “Recovery inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C004-T08 · Incompatible-input case:** Supply an incompatible “Recovery inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C004-T09 · Valid integration trace:** Run a valid “Recovery inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C004-T10 · Seam review:** Reconcile the “Recovery inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for recovery inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Recovery inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C005-T02 · Expected-result oracle:** Specify the “Recovery inventory” expected result independently of the implementation output; include the property “Recovery choices are based on validated metadata rather than folder names” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C005-T03 · Fixture material:** Create the concrete “Recovery inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C005-T04 · Target preparation:** Prepare the “Recovery inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C005-T05 · Initial-state record:** Record the initial “Recovery inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C005-T06 · Valid-path execution:** Execute the “Recovery inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C005-T07 · Outcome comparison:** Compare every declared “Recovery inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C005-T08 · State and bounds check:** Inspect the “Recovery inventory” ownership/state effects and actual use of “Backups, journals and inspection bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C005-T09 · Repeatability check:** Repeat the same “Recovery inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C005-T10 · Positive evidence:** Attach the “Recovery inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C006 · Negative test

**Original checklist item:** Negative case: The newest-looking directory is selected without verification. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “Recovery inventory” source counterexample: “The newest-looking directory is selected without verification”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Recovery inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C006-T03 · Valid control:** Construct a valid “Recovery inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C006-T04 · Minimal adverse input:** Derive the “Recovery inventory” adverse fixture from the control with the smallest documented change needed to reproduce “The newest-looking directory is selected without verification”; retain that change as reproducible data.
- [ ] **UC-M07.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recovery inventory”; require “Recovery choices are based on validated metadata rather than folder names” and forbid a false-success verdict.
- [ ] **UC-M07.08-C006-T06 · Adverse execution:** Exercise the “Recovery inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C006-T07 · Effect inspection:** Inspect “Recovery inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C006-T08 · Refusal versus failure:** Confirm the “Recovery inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C006-T09 · Reset and retention:** Restore only the disposable “Recovery inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C006-T10 · Negative regression:** Register the “Recovery inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C007 · Change / failure test

**Original checklist item:** Exercise recovery inventory when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C007-T01 · Scenario record:** Write the “Recovery inventory” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “Recovery choices are based on validated metadata rather than folder names”.
- [ ] **UC-M07.08-C007-T02 · Baseline capture:** Create a known-valid “Recovery inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C007-T03 · Injection map:** Locate the “Recovery inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Recovery inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C007-T05 · Controlled trigger:** Introduce the controlled “Recovery inventory” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C007-T06 · Intermediate inspection:** Inspect the “Recovery inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recovery inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Recovery inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C007-T09 · Repeat and compare:** Repeat the selected “Recovery inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C007-T10 · Failure evidence:** Publish the “Recovery inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C008 · Bounds

**Original checklist item:** Choose, document and test limits for backups, journals and inspection bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “Recovery inventory”: “Backups, journals and inspection bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C008-T02 · Measurement method:** Choose how to observe each “Recovery inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C008-T03 · Budget decision:** Select justified resource and input limits for “Recovery inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recovery inventory” cases for “Backups, journals and inspection bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recovery inventory” limit; preserve “Recovery choices are based on validated metadata rather than folder names”.
- [ ] **UC-M07.08-C008-T06 · Normal measurement:** Run or review the normal “Recovery inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C008-T07 · At-limit measurement:** Exercise the “Recovery inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C008-T08 · Over-limit measurement:** Exercise the “Recovery inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C008-T09 · Uncovered-scope report:** List the “Recovery inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C008-T10 · Limit evidence:** Publish the selected “Recovery inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for recovery inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C009-T01 · Event inventory:** List the “Recovery inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Recovery inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C009-T03 · Failure mapping:** Map each documented “Recovery inventory” refusal or error to a diagnostic outcome; include “The newest-looking directory is selected without verification” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C009-T04 · Emission path:** Add the “Recovery inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C009-T05 · Redaction check:** Test “Recovery inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C009-T06 · Output budget:** Set and exercise bounded “Recovery inventory” message size, rate and retention compatible with “Backups, journals and inspection bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C009-T07 · Success/refusal fixtures:** Capture “Recovery inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Recovery inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C009-T09 · Operator review:** Read the “Recovery inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C009-T10 · Diagnostic evidence:** Publish redacted “Recovery inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recovery inventory; label unexecuted checks as untested.

- [ ] **UC-M07.08-C010-T01 · Evidence inventory:** List the “Recovery inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C010-T02 · Artifact references:** Record the exact “Recovery inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C010-T03 · Fixture references:** Attach the “Recovery inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “The newest-looking directory is selected without verification” as a distinct evidence case.
- [ ] **UC-M07.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recovery inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C010-T05 · Environment record:** Record the actual “Recovery inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C010-T06 · Expected versus observed:** Pair every “Recovery inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C010-T07 · Failure and limit records:** Attach “Recovery inventory” change/failure and bounds evidence where required; include uncovered “Backups, journals and inspection bytes” and unresolved violations of “Recovery choices are based on validated metadata rather than folder names”.
- [ ] **UC-M07.08-C010-T08 · Evidence hygiene:** Check the “Recovery inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C010-T09 · Reproduction review:** Have the “Recovery inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C010-T10 · Acceptance linkage:** Link the “Recovery inventory” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Recovery command contracts

**Source delivery:** Define machine-stable inspect, restore and abandon operations.

**Source invariant:** Recovery actions have explicit scope and outcome semantics.

**Source negative case:** A restore command implicitly deletes unrelated backups.

**Source bounded quantities:** Operation count and request bytes.

### UC-M07.08-C011 · Contract

**Original checklist item:** Specify recovery command contracts inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C011-T01 · Scope statement:** Draft the operation boundary for “Recovery command contracts” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recovery command contracts”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C011-T03 · Output inventory:** List the outputs of “Recovery command contracts” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Recovery command contracts”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C011-T05 · Prerequisite contract:** Map “Recovery command contracts” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Recovery command contracts”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C011-T07 · Invariant clause:** Add a normative clause for “Recovery command contracts” that preserves “Recovery actions have explicit scope and outcome semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recovery command contracts”; include the source counterexample “A restore command implicitly deletes unrelated backups” and the intended safe disposition.
- [ ] **UC-M07.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Operation count and request bytes” in the “Recovery command contracts” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C011-T10 · Contract review:** Review the “Recovery command contracts” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C012 · Delivery

**Original checklist item:** Define machine-stable inspect, restore and abandon operations.

- [ ] **UC-M07.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recovery command contracts”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C012-T02 · Change plan:** Break the source delivery for “Recovery command contracts” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C012-T03 · Core artifact:** Create the “Recovery command contracts” model, schema or inventory that realizes this source instruction: Define machine-stable inspect, restore and abandon operations.
- [ ] **UC-M07.08-C012-T04 · Concrete realization:** Populate “Recovery command contracts” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recovery command contracts” needed to preserve “Recovery actions have explicit scope and outcome semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C012-T06 · Dependency connection:** Connect the “Recovery command contracts” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C012-T07 · Resource behavior:** Account for “Operation count and request bytes” in “Recovery command contracts”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C012-T08 · Delivery check:** Run the smallest real “Recovery command contracts” path and its adverse fixture “A restore command implicitly deletes unrelated backups”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C012-T09 · Patch review:** Review the “Recovery command contracts” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C012-T10 · Delivery handoff:** Publish the “Recovery command contracts” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery actions have explicit scope and outcome semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Recovery command contracts”; copy its required invariant exactly: “Recovery actions have explicit scope and outcome semantics”.
- [ ] **UC-M07.08-C013-T02 · Observable terms:** Define each term in the “Recovery command contracts” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C013-T03 · Precondition set:** List the preconditions under which “Recovery actions have explicit scope and outcome semantics” must hold for “Recovery command contracts”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C013-T04 · Transition coverage:** Map the “Recovery command contracts” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recovery command contracts”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C013-T06 · Satisfying fixture:** Create a concrete “Recovery command contracts” case that satisfies “Recovery actions have explicit scope and outcome semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C013-T07 · Violating fixture:** Create the source counterexample “A restore command implicitly deletes unrelated backups” for “Recovery command contracts”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C013-T08 · Enforcement evidence:** Exercise the “Recovery command contracts” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C013-T09 · Regression linkage:** Link the “Recovery command contracts” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Recovery command contracts” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C014 · Integration

**Original checklist item:** Integrate recovery command contracts with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recovery command contracts” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C014-T02 · Field mapping:** Map every “Recovery command contracts” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Recovery command contracts” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C014-T04 · Ownership agreement:** Specify who owns “Recovery command contracts” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C014-T05 · Handoff implementation:** Connect “Recovery command contracts” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery actions have explicit scope and outcome semantics” across the handoff.
- [ ] **UC-M07.08-C014-T06 · Absent-input case:** Omit one required “Recovery command contracts” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C014-T07 · Stale-input case:** Supply an outdated “Recovery command contracts” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Recovery command contracts” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C014-T09 · Valid integration trace:** Run a valid “Recovery command contracts” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C014-T10 · Seam review:** Reconcile the “Recovery command contracts” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for recovery command contracts; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Recovery command contracts” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C015-T02 · Expected-result oracle:** Specify the “Recovery command contracts” expected result independently of the implementation output; include the property “Recovery actions have explicit scope and outcome semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C015-T03 · Fixture material:** Create the concrete “Recovery command contracts” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C015-T04 · Target preparation:** Prepare the “Recovery command contracts” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C015-T05 · Initial-state record:** Record the initial “Recovery command contracts” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C015-T06 · Valid-path execution:** Execute the “Recovery command contracts” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C015-T07 · Outcome comparison:** Compare every declared “Recovery command contracts” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C015-T08 · State and bounds check:** Inspect the “Recovery command contracts” ownership/state effects and actual use of “Operation count and request bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C015-T09 · Repeatability check:** Repeat the same “Recovery command contracts” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C015-T10 · Positive evidence:** Attach the “Recovery command contracts” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C016 · Negative test

**Original checklist item:** Negative case: A restore command implicitly deletes unrelated backups. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Recovery command contracts” source counterexample: “A restore command implicitly deletes unrelated backups”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Recovery command contracts”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C016-T03 · Valid control:** Construct a valid “Recovery command contracts” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C016-T04 · Minimal adverse input:** Derive the “Recovery command contracts” adverse fixture from the control with the smallest documented change needed to reproduce “A restore command implicitly deletes unrelated backups”; retain that change as reproducible data.
- [ ] **UC-M07.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recovery command contracts”; require “Recovery actions have explicit scope and outcome semantics” and forbid a false-success verdict.
- [ ] **UC-M07.08-C016-T06 · Adverse execution:** Exercise the “Recovery command contracts” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C016-T07 · Effect inspection:** Inspect “Recovery command contracts” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C016-T08 · Refusal versus failure:** Confirm the “Recovery command contracts” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C016-T09 · Reset and retention:** Restore only the disposable “Recovery command contracts” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C016-T10 · Negative regression:** Register the “Recovery command contracts” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C017 · Change / failure test

**Original checklist item:** Exercise recovery command contracts when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C017-T01 · Scenario record:** Write the “Recovery command contracts” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “Recovery actions have explicit scope and outcome semantics”.
- [ ] **UC-M07.08-C017-T02 · Baseline capture:** Create a known-valid “Recovery command contracts” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C017-T03 · Injection map:** Locate the “Recovery command contracts” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Recovery command contracts” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C017-T05 · Controlled trigger:** Introduce the controlled “Recovery command contracts” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C017-T06 · Intermediate inspection:** Inspect the “Recovery command contracts” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recovery command contracts”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Recovery command contracts” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C017-T09 · Repeat and compare:** Repeat the selected “Recovery command contracts” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C017-T10 · Failure evidence:** Publish the “Recovery command contracts” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C018 · Bounds

**Original checklist item:** Choose, document and test limits for operation count and request bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Recovery command contracts”: “Operation count and request bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C018-T02 · Measurement method:** Choose how to observe each “Recovery command contracts” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C018-T03 · Budget decision:** Select justified resource and input limits for “Recovery command contracts”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recovery command contracts” cases for “Operation count and request bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recovery command contracts” limit; preserve “Recovery actions have explicit scope and outcome semantics”.
- [ ] **UC-M07.08-C018-T06 · Normal measurement:** Run or review the normal “Recovery command contracts” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C018-T07 · At-limit measurement:** Exercise the “Recovery command contracts” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C018-T08 · Over-limit measurement:** Exercise the “Recovery command contracts” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C018-T09 · Uncovered-scope report:** List the “Recovery command contracts” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C018-T10 · Limit evidence:** Publish the selected “Recovery command contracts” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for recovery command contracts with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C019-T01 · Event inventory:** List the “Recovery command contracts” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Recovery command contracts” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C019-T03 · Failure mapping:** Map each documented “Recovery command contracts” refusal or error to a diagnostic outcome; include “A restore command implicitly deletes unrelated backups” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C019-T04 · Emission path:** Add the “Recovery command contracts” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C019-T05 · Redaction check:** Test “Recovery command contracts” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C019-T06 · Output budget:** Set and exercise bounded “Recovery command contracts” message size, rate and retention compatible with “Operation count and request bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C019-T07 · Success/refusal fixtures:** Capture “Recovery command contracts” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Recovery command contracts” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C019-T09 · Operator review:** Read the “Recovery command contracts” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C019-T10 · Diagnostic evidence:** Publish redacted “Recovery command contracts” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recovery command contracts; label unexecuted checks as untested.

- [ ] **UC-M07.08-C020-T01 · Evidence inventory:** List the “Recovery command contracts” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C020-T02 · Artifact references:** Record the exact “Recovery command contracts” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C020-T03 · Fixture references:** Attach the “Recovery command contracts” fixture IDs, input identities and oracle definition; preserve the source counterexample “A restore command implicitly deletes unrelated backups” as a distinct evidence case.
- [ ] **UC-M07.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recovery command contracts”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C020-T05 · Environment record:** Record the actual “Recovery command contracts” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C020-T06 · Expected versus observed:** Pair every “Recovery command contracts” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C020-T07 · Failure and limit records:** Attach “Recovery command contracts” change/failure and bounds evidence where required; include uncovered “Operation count and request bytes” and unresolved violations of “Recovery actions have explicit scope and outcome semantics”.
- [ ] **UC-M07.08-C020-T08 · Evidence hygiene:** Check the “Recovery command contracts” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C020-T09 · Reproduction review:** Have the “Recovery command contracts” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C020-T10 · Acceptance linkage:** Link the “Recovery command contracts” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Generation authorization

**Source delivery:** Require current target identity and allowed source generation for recovery.

**Source invariant:** A stale operator request cannot overwrite a newer generation.

**Source negative case:** An old restore request arrives after a successful replacement.

**Source bounded quantities:** Generation checks and concurrent requests.

### UC-M07.08-C021 · Contract

**Original checklist item:** Specify generation authorization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C021-T01 · Scope statement:** Draft the operation boundary for “Generation authorization” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Generation authorization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C021-T03 · Output inventory:** List the outputs of “Generation authorization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Generation authorization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C021-T05 · Prerequisite contract:** Map “Generation authorization” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Generation authorization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C021-T07 · Invariant clause:** Add a normative clause for “Generation authorization” that preserves “A stale operator request cannot overwrite a newer generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Generation authorization”; include the source counterexample “An old restore request arrives after a successful replacement” and the intended safe disposition.
- [ ] **UC-M07.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Generation checks and concurrent requests” in the “Generation authorization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C021-T10 · Contract review:** Review the “Generation authorization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C022 · Delivery

**Original checklist item:** Require current target identity and allowed source generation for recovery.

- [ ] **UC-M07.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Generation authorization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C022-T02 · Change plan:** Break the source delivery for “Generation authorization” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Generation authorization” that realizes this source instruction: Require current target identity and allowed source generation for recovery.
- [ ] **UC-M07.08-C022-T04 · Concrete realization:** Trace “Generation authorization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Generation authorization” needed to preserve “A stale operator request cannot overwrite a newer generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C022-T06 · Dependency connection:** Connect the “Generation authorization” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C022-T07 · Resource behavior:** Account for “Generation checks and concurrent requests” in “Generation authorization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C022-T08 · Delivery check:** Run the smallest real “Generation authorization” path and its adverse fixture “An old restore request arrives after a successful replacement”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C022-T09 · Patch review:** Review the “Generation authorization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C022-T10 · Delivery handoff:** Publish the “Generation authorization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stale operator request cannot overwrite a newer generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Generation authorization”; copy its required invariant exactly: “A stale operator request cannot overwrite a newer generation”.
- [ ] **UC-M07.08-C023-T02 · Observable terms:** Define each term in the “Generation authorization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C023-T03 · Precondition set:** List the preconditions under which “A stale operator request cannot overwrite a newer generation” must hold for “Generation authorization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C023-T04 · Transition coverage:** Map the “Generation authorization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Generation authorization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C023-T06 · Satisfying fixture:** Create a concrete “Generation authorization” case that satisfies “A stale operator request cannot overwrite a newer generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C023-T07 · Violating fixture:** Create the source counterexample “An old restore request arrives after a successful replacement” for “Generation authorization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C023-T08 · Enforcement evidence:** Exercise the “Generation authorization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C023-T09 · Regression linkage:** Link the “Generation authorization” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Generation authorization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C024 · Integration

**Original checklist item:** Integrate generation authorization with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Generation authorization” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C024-T02 · Field mapping:** Map every “Generation authorization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Generation authorization” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C024-T04 · Ownership agreement:** Specify who owns “Generation authorization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C024-T05 · Handoff implementation:** Connect “Generation authorization” through the mapped seam using the real adapter or explicit specification reference; preserve “A stale operator request cannot overwrite a newer generation” across the handoff.
- [ ] **UC-M07.08-C024-T06 · Absent-input case:** Omit one required “Generation authorization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C024-T07 · Stale-input case:** Supply an outdated “Generation authorization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Generation authorization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C024-T09 · Valid integration trace:** Run a valid “Generation authorization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C024-T10 · Seam review:** Reconcile the “Generation authorization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for generation authorization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Generation authorization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C025-T02 · Expected-result oracle:** Specify the “Generation authorization” expected result independently of the implementation output; include the property “A stale operator request cannot overwrite a newer generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C025-T03 · Fixture material:** Create the concrete “Generation authorization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C025-T04 · Target preparation:** Prepare the “Generation authorization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C025-T05 · Initial-state record:** Record the initial “Generation authorization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C025-T06 · Valid-path execution:** Execute the “Generation authorization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C025-T07 · Outcome comparison:** Compare every declared “Generation authorization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C025-T08 · State and bounds check:** Inspect the “Generation authorization” ownership/state effects and actual use of “Generation checks and concurrent requests”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C025-T09 · Repeatability check:** Repeat the same “Generation authorization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C025-T10 · Positive evidence:** Attach the “Generation authorization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C026 · Negative test

**Original checklist item:** Negative case: An old restore request arrives after a successful replacement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Generation authorization” source counterexample: “An old restore request arrives after a successful replacement”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Generation authorization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C026-T03 · Valid control:** Construct a valid “Generation authorization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C026-T04 · Minimal adverse input:** Derive the “Generation authorization” adverse fixture from the control with the smallest documented change needed to reproduce “An old restore request arrives after a successful replacement”; retain that change as reproducible data.
- [ ] **UC-M07.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Generation authorization”; require “A stale operator request cannot overwrite a newer generation” and forbid a false-success verdict.
- [ ] **UC-M07.08-C026-T06 · Adverse execution:** Exercise the “Generation authorization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C026-T07 · Effect inspection:** Inspect “Generation authorization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C026-T08 · Refusal versus failure:** Confirm the “Generation authorization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C026-T09 · Reset and retention:** Restore only the disposable “Generation authorization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C026-T10 · Negative regression:** Register the “Generation authorization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C027 · Change / failure test

**Original checklist item:** Exercise generation authorization when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C027-T01 · Scenario record:** Write the “Generation authorization” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “A stale operator request cannot overwrite a newer generation”.
- [ ] **UC-M07.08-C027-T02 · Baseline capture:** Create a known-valid “Generation authorization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C027-T03 · Injection map:** Locate the “Generation authorization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Generation authorization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C027-T05 · Controlled trigger:** Introduce the controlled “Generation authorization” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C027-T06 · Intermediate inspection:** Inspect the “Generation authorization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Generation authorization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Generation authorization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C027-T09 · Repeat and compare:** Repeat the selected “Generation authorization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C027-T10 · Failure evidence:** Publish the “Generation authorization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C028 · Bounds

**Original checklist item:** Choose, document and test limits for generation checks and concurrent requests; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Generation authorization”: “Generation checks and concurrent requests”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C028-T02 · Measurement method:** Choose how to observe each “Generation authorization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C028-T03 · Budget decision:** Select justified resource and input limits for “Generation authorization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Generation authorization” cases for “Generation checks and concurrent requests”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Generation authorization” limit; preserve “A stale operator request cannot overwrite a newer generation”.
- [ ] **UC-M07.08-C028-T06 · Normal measurement:** Run or review the normal “Generation authorization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C028-T07 · At-limit measurement:** Exercise the “Generation authorization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C028-T08 · Over-limit measurement:** Exercise the “Generation authorization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C028-T09 · Uncovered-scope report:** List the “Generation authorization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C028-T10 · Limit evidence:** Publish the selected “Generation authorization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for generation authorization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C029-T01 · Event inventory:** List the “Generation authorization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Generation authorization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C029-T03 · Failure mapping:** Map each documented “Generation authorization” refusal or error to a diagnostic outcome; include “An old restore request arrives after a successful replacement” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C029-T04 · Emission path:** Add the “Generation authorization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C029-T05 · Redaction check:** Test “Generation authorization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C029-T06 · Output budget:** Set and exercise bounded “Generation authorization” message size, rate and retention compatible with “Generation checks and concurrent requests”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C029-T07 · Success/refusal fixtures:** Capture “Generation authorization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Generation authorization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C029-T09 · Operator review:** Read the “Generation authorization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C029-T10 · Diagnostic evidence:** Publish redacted “Generation authorization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for generation authorization; label unexecuted checks as untested.

- [ ] **UC-M07.08-C030-T01 · Evidence inventory:** List the “Generation authorization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C030-T02 · Artifact references:** Record the exact “Generation authorization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C030-T03 · Fixture references:** Attach the “Generation authorization” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old restore request arrives after a successful replacement” as a distinct evidence case.
- [ ] **UC-M07.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Generation authorization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C030-T05 · Environment record:** Record the actual “Generation authorization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C030-T06 · Expected versus observed:** Pair every “Generation authorization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C030-T07 · Failure and limit records:** Attach “Generation authorization” change/failure and bounds evidence where required; include uncovered “Generation checks and concurrent requests” and unresolved violations of “A stale operator request cannot overwrite a newer generation”.
- [ ] **UC-M07.08-C030-T08 · Evidence hygiene:** Check the “Generation authorization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C030-T09 · Reproduction review:** Have the “Generation authorization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C030-T10 · Acceptance linkage:** Link the “Generation authorization” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Pre-restore validation

**Source delivery:** Validate backup, snapshot, seals and participant relationships before mutation.

**Source invariant:** An invalid recovery source cannot displace a working current generation.

**Source negative case:** A damaged backup is moved into place before validation.

**Source bounded quantities:** Verified bytes and validation deadline.

### UC-M07.08-C031 · Contract

**Original checklist item:** Specify pre-restore validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C031-T01 · Scope statement:** Draft the operation boundary for “Pre-restore validation” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Pre-restore validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C031-T03 · Output inventory:** List the outputs of “Pre-restore validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Pre-restore validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C031-T05 · Prerequisite contract:** Map “Pre-restore validation” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Pre-restore validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C031-T07 · Invariant clause:** Add a normative clause for “Pre-restore validation” that preserves “An invalid recovery source cannot displace a working current generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Pre-restore validation”; include the source counterexample “A damaged backup is moved into place before validation” and the intended safe disposition.
- [ ] **UC-M07.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Verified bytes and validation deadline” in the “Pre-restore validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C031-T10 · Contract review:** Review the “Pre-restore validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C032 · Delivery

**Original checklist item:** Validate backup, snapshot, seals and participant relationships before mutation.

- [ ] **UC-M07.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Pre-restore validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C032-T02 · Change plan:** Break the source delivery for “Pre-restore validation” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Pre-restore validation” that realizes this source instruction: Validate backup, snapshot, seals and participant relationships before mutation.
- [ ] **UC-M07.08-C032-T04 · Concrete realization:** Trace “Pre-restore validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Pre-restore validation” needed to preserve “An invalid recovery source cannot displace a working current generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C032-T06 · Dependency connection:** Connect the “Pre-restore validation” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C032-T07 · Resource behavior:** Account for “Verified bytes and validation deadline” in “Pre-restore validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C032-T08 · Delivery check:** Run the smallest real “Pre-restore validation” path and its adverse fixture “A damaged backup is moved into place before validation”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C032-T09 · Patch review:** Review the “Pre-restore validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C032-T10 · Delivery handoff:** Publish the “Pre-restore validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An invalid recovery source cannot displace a working current generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Pre-restore validation”; copy its required invariant exactly: “An invalid recovery source cannot displace a working current generation”.
- [ ] **UC-M07.08-C033-T02 · Observable terms:** Define each term in the “Pre-restore validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C033-T03 · Precondition set:** List the preconditions under which “An invalid recovery source cannot displace a working current generation” must hold for “Pre-restore validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C033-T04 · Transition coverage:** Map the “Pre-restore validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Pre-restore validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C033-T06 · Satisfying fixture:** Create a concrete “Pre-restore validation” case that satisfies “An invalid recovery source cannot displace a working current generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C033-T07 · Violating fixture:** Create the source counterexample “A damaged backup is moved into place before validation” for “Pre-restore validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C033-T08 · Enforcement evidence:** Exercise the “Pre-restore validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C033-T09 · Regression linkage:** Link the “Pre-restore validation” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Pre-restore validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C034 · Integration

**Original checklist item:** Integrate pre-restore validation with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Pre-restore validation” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C034-T02 · Field mapping:** Map every “Pre-restore validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Pre-restore validation” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C034-T04 · Ownership agreement:** Specify who owns “Pre-restore validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C034-T05 · Handoff implementation:** Connect “Pre-restore validation” through the mapped seam using the real adapter or explicit specification reference; preserve “An invalid recovery source cannot displace a working current generation” across the handoff.
- [ ] **UC-M07.08-C034-T06 · Absent-input case:** Omit one required “Pre-restore validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C034-T07 · Stale-input case:** Supply an outdated “Pre-restore validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Pre-restore validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C034-T09 · Valid integration trace:** Run a valid “Pre-restore validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C034-T10 · Seam review:** Reconcile the “Pre-restore validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for pre-restore validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Pre-restore validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C035-T02 · Expected-result oracle:** Specify the “Pre-restore validation” expected result independently of the implementation output; include the property “An invalid recovery source cannot displace a working current generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C035-T03 · Fixture material:** Create the concrete “Pre-restore validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C035-T04 · Target preparation:** Prepare the “Pre-restore validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C035-T05 · Initial-state record:** Record the initial “Pre-restore validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C035-T06 · Valid-path execution:** Execute the “Pre-restore validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C035-T07 · Outcome comparison:** Compare every declared “Pre-restore validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C035-T08 · State and bounds check:** Inspect the “Pre-restore validation” ownership/state effects and actual use of “Verified bytes and validation deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C035-T09 · Repeatability check:** Repeat the same “Pre-restore validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C035-T10 · Positive evidence:** Attach the “Pre-restore validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C036 · Negative test

**Original checklist item:** Negative case: A damaged backup is moved into place before validation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Pre-restore validation” source counterexample: “A damaged backup is moved into place before validation”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Pre-restore validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C036-T03 · Valid control:** Construct a valid “Pre-restore validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C036-T04 · Minimal adverse input:** Derive the “Pre-restore validation” adverse fixture from the control with the smallest documented change needed to reproduce “A damaged backup is moved into place before validation”; retain that change as reproducible data.
- [ ] **UC-M07.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Pre-restore validation”; require “An invalid recovery source cannot displace a working current generation” and forbid a false-success verdict.
- [ ] **UC-M07.08-C036-T06 · Adverse execution:** Exercise the “Pre-restore validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C036-T07 · Effect inspection:** Inspect “Pre-restore validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C036-T08 · Refusal versus failure:** Confirm the “Pre-restore validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C036-T09 · Reset and retention:** Restore only the disposable “Pre-restore validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C036-T10 · Negative regression:** Register the “Pre-restore validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C037 · Change / failure test

**Original checklist item:** Exercise pre-restore validation when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C037-T01 · Scenario record:** Write the “Pre-restore validation” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “An invalid recovery source cannot displace a working current generation”.
- [ ] **UC-M07.08-C037-T02 · Baseline capture:** Create a known-valid “Pre-restore validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C037-T03 · Injection map:** Locate the “Pre-restore validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Pre-restore validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C037-T05 · Controlled trigger:** Introduce the controlled “Pre-restore validation” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C037-T06 · Intermediate inspection:** Inspect the “Pre-restore validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Pre-restore validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Pre-restore validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C037-T09 · Repeat and compare:** Repeat the selected “Pre-restore validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C037-T10 · Failure evidence:** Publish the “Pre-restore validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C038 · Bounds

**Original checklist item:** Choose, document and test limits for verified bytes and validation deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Pre-restore validation”: “Verified bytes and validation deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C038-T02 · Measurement method:** Choose how to observe each “Pre-restore validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C038-T03 · Budget decision:** Select justified resource and input limits for “Pre-restore validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Pre-restore validation” cases for “Verified bytes and validation deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Pre-restore validation” limit; preserve “An invalid recovery source cannot displace a working current generation”.
- [ ] **UC-M07.08-C038-T06 · Normal measurement:** Run or review the normal “Pre-restore validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C038-T07 · At-limit measurement:** Exercise the “Pre-restore validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C038-T08 · Over-limit measurement:** Exercise the “Pre-restore validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C038-T09 · Uncovered-scope report:** List the “Pre-restore validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C038-T10 · Limit evidence:** Publish the selected “Pre-restore validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for pre-restore validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C039-T01 · Event inventory:** List the “Pre-restore validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Pre-restore validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C039-T03 · Failure mapping:** Map each documented “Pre-restore validation” refusal or error to a diagnostic outcome; include “A damaged backup is moved into place before validation” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C039-T04 · Emission path:** Add the “Pre-restore validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C039-T05 · Redaction check:** Test “Pre-restore validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C039-T06 · Output budget:** Set and exercise bounded “Pre-restore validation” message size, rate and retention compatible with “Verified bytes and validation deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C039-T07 · Success/refusal fixtures:** Capture “Pre-restore validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Pre-restore validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C039-T09 · Operator review:** Read the “Pre-restore validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C039-T10 · Diagnostic evidence:** Publish redacted “Pre-restore validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for pre-restore validation; label unexecuted checks as untested.

- [ ] **UC-M07.08-C040-T01 · Evidence inventory:** List the “Pre-restore validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C040-T02 · Artifact references:** Record the exact “Pre-restore validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C040-T03 · Fixture references:** Attach the “Pre-restore validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A damaged backup is moved into place before validation” as a distinct evidence case.
- [ ] **UC-M07.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Pre-restore validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C040-T05 · Environment record:** Record the actual “Pre-restore validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C040-T06 · Expected versus observed:** Pair every “Pre-restore validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C040-T07 · Failure and limit records:** Attach “Pre-restore validation” change/failure and bounds evidence where required; include uncovered “Verified bytes and validation deadline” and unresolved violations of “An invalid recovery source cannot displace a working current generation”.
- [ ] **UC-M07.08-C040-T08 · Evidence hygiene:** Check the “Pre-restore validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C040-T09 · Reproduction review:** Have the “Pre-restore validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C040-T10 · Acceptance linkage:** Link the “Pre-restore validation” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Cross-resource restore plan

**Source delivery:** Restore registry, ship seals, berth data, hull mounts and runtime relationships together.

**Source invariant:** Recovery is more than moving one directory.

**Source negative case:** The berth is restored but registry and mounts still point elsewhere.

**Source bounded quantities:** Participants and restoration steps.

### UC-M07.08-C041 · Contract

**Original checklist item:** Specify cross-resource restore plan inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C041-T01 · Scope statement:** Draft the operation boundary for “Cross-resource restore plan” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cross-resource restore plan”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C041-T03 · Output inventory:** List the outputs of “Cross-resource restore plan” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Cross-resource restore plan”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C041-T05 · Prerequisite contract:** Map “Cross-resource restore plan” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Cross-resource restore plan”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C041-T07 · Invariant clause:** Add a normative clause for “Cross-resource restore plan” that preserves “Recovery is more than moving one directory”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cross-resource restore plan”; include the source counterexample “The berth is restored but registry and mounts still point elsewhere” and the intended safe disposition.
- [ ] **UC-M07.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Participants and restoration steps” in the “Cross-resource restore plan” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C041-T10 · Contract review:** Review the “Cross-resource restore plan” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C042 · Delivery

**Original checklist item:** Restore registry, ship seals, berth data, hull mounts and runtime relationships together.

- [ ] **UC-M07.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cross-resource restore plan”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C042-T02 · Change plan:** Break the source delivery for “Cross-resource restore plan” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Cross-resource restore plan” that realizes this source instruction: Restore registry, ship seals, berth data, hull mounts and runtime relationships together.
- [ ] **UC-M07.08-C042-T04 · Concrete realization:** Trace “Cross-resource restore plan” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cross-resource restore plan” needed to preserve “Recovery is more than moving one directory”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C042-T06 · Dependency connection:** Connect the “Cross-resource restore plan” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C042-T07 · Resource behavior:** Account for “Participants and restoration steps” in “Cross-resource restore plan”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C042-T08 · Delivery check:** Run the smallest real “Cross-resource restore plan” path and its adverse fixture “The berth is restored but registry and mounts still point elsewhere”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C042-T09 · Patch review:** Review the “Cross-resource restore plan” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C042-T10 · Delivery handoff:** Publish the “Cross-resource restore plan” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery is more than moving one directory. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Cross-resource restore plan”; copy its required invariant exactly: “Recovery is more than moving one directory”.
- [ ] **UC-M07.08-C043-T02 · Observable terms:** Define each term in the “Cross-resource restore plan” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C043-T03 · Precondition set:** List the preconditions under which “Recovery is more than moving one directory” must hold for “Cross-resource restore plan”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C043-T04 · Transition coverage:** Map the “Cross-resource restore plan” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cross-resource restore plan”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C043-T06 · Satisfying fixture:** Create a concrete “Cross-resource restore plan” case that satisfies “Recovery is more than moving one directory”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C043-T07 · Violating fixture:** Create the source counterexample “The berth is restored but registry and mounts still point elsewhere” for “Cross-resource restore plan”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C043-T08 · Enforcement evidence:** Exercise the “Cross-resource restore plan” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C043-T09 · Regression linkage:** Link the “Cross-resource restore plan” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Cross-resource restore plan” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C044 · Integration

**Original checklist item:** Integrate cross-resource restore plan with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cross-resource restore plan” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C044-T02 · Field mapping:** Map every “Cross-resource restore plan” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Cross-resource restore plan” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C044-T04 · Ownership agreement:** Specify who owns “Cross-resource restore plan” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C044-T05 · Handoff implementation:** Connect “Cross-resource restore plan” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery is more than moving one directory” across the handoff.
- [ ] **UC-M07.08-C044-T06 · Absent-input case:** Omit one required “Cross-resource restore plan” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C044-T07 · Stale-input case:** Supply an outdated “Cross-resource restore plan” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Cross-resource restore plan” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C044-T09 · Valid integration trace:** Run a valid “Cross-resource restore plan” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C044-T10 · Seam review:** Reconcile the “Cross-resource restore plan” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cross-resource restore plan; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cross-resource restore plan” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C045-T02 · Expected-result oracle:** Specify the “Cross-resource restore plan” expected result independently of the implementation output; include the property “Recovery is more than moving one directory” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C045-T03 · Fixture material:** Create the concrete “Cross-resource restore plan” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C045-T04 · Target preparation:** Prepare the “Cross-resource restore plan” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C045-T05 · Initial-state record:** Record the initial “Cross-resource restore plan” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C045-T06 · Valid-path execution:** Execute the “Cross-resource restore plan” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C045-T07 · Outcome comparison:** Compare every declared “Cross-resource restore plan” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C045-T08 · State and bounds check:** Inspect the “Cross-resource restore plan” ownership/state effects and actual use of “Participants and restoration steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C045-T09 · Repeatability check:** Repeat the same “Cross-resource restore plan” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C045-T10 · Positive evidence:** Attach the “Cross-resource restore plan” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C046 · Negative test

**Original checklist item:** Negative case: The berth is restored but registry and mounts still point elsewhere. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Cross-resource restore plan” source counterexample: “The berth is restored but registry and mounts still point elsewhere”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Cross-resource restore plan”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C046-T03 · Valid control:** Construct a valid “Cross-resource restore plan” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C046-T04 · Minimal adverse input:** Derive the “Cross-resource restore plan” adverse fixture from the control with the smallest documented change needed to reproduce “The berth is restored but registry and mounts still point elsewhere”; retain that change as reproducible data.
- [ ] **UC-M07.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cross-resource restore plan”; require “Recovery is more than moving one directory” and forbid a false-success verdict.
- [ ] **UC-M07.08-C046-T06 · Adverse execution:** Exercise the “Cross-resource restore plan” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C046-T07 · Effect inspection:** Inspect “Cross-resource restore plan” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C046-T08 · Refusal versus failure:** Confirm the “Cross-resource restore plan” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C046-T09 · Reset and retention:** Restore only the disposable “Cross-resource restore plan” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C046-T10 · Negative regression:** Register the “Cross-resource restore plan” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C047 · Change / failure test

**Original checklist item:** Exercise cross-resource restore plan when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C047-T01 · Scenario record:** Write the “Cross-resource restore plan” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “Recovery is more than moving one directory”.
- [ ] **UC-M07.08-C047-T02 · Baseline capture:** Create a known-valid “Cross-resource restore plan” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C047-T03 · Injection map:** Locate the “Cross-resource restore plan” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Cross-resource restore plan” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C047-T05 · Controlled trigger:** Introduce the controlled “Cross-resource restore plan” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C047-T06 · Intermediate inspection:** Inspect the “Cross-resource restore plan” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cross-resource restore plan”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Cross-resource restore plan” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C047-T09 · Repeat and compare:** Repeat the selected “Cross-resource restore plan” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C047-T10 · Failure evidence:** Publish the “Cross-resource restore plan” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C048 · Bounds

**Original checklist item:** Choose, document and test limits for participants and restoration steps; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Cross-resource restore plan”: “Participants and restoration steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C048-T02 · Measurement method:** Choose how to observe each “Cross-resource restore plan” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C048-T03 · Budget decision:** Select justified resource and input limits for “Cross-resource restore plan”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cross-resource restore plan” cases for “Participants and restoration steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cross-resource restore plan” limit; preserve “Recovery is more than moving one directory”.
- [ ] **UC-M07.08-C048-T06 · Normal measurement:** Run or review the normal “Cross-resource restore plan” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C048-T07 · At-limit measurement:** Exercise the “Cross-resource restore plan” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C048-T08 · Over-limit measurement:** Exercise the “Cross-resource restore plan” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C048-T09 · Uncovered-scope report:** List the “Cross-resource restore plan” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C048-T10 · Limit evidence:** Publish the selected “Cross-resource restore plan” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cross-resource restore plan with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C049-T01 · Event inventory:** List the “Cross-resource restore plan” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Cross-resource restore plan” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C049-T03 · Failure mapping:** Map each documented “Cross-resource restore plan” refusal or error to a diagnostic outcome; include “The berth is restored but registry and mounts still point elsewhere” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C049-T04 · Emission path:** Add the “Cross-resource restore plan” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C049-T05 · Redaction check:** Test “Cross-resource restore plan” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C049-T06 · Output budget:** Set and exercise bounded “Cross-resource restore plan” message size, rate and retention compatible with “Participants and restoration steps”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C049-T07 · Success/refusal fixtures:** Capture “Cross-resource restore plan” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cross-resource restore plan” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C049-T09 · Operator review:** Read the “Cross-resource restore plan” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C049-T10 · Diagnostic evidence:** Publish redacted “Cross-resource restore plan” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cross-resource restore plan; label unexecuted checks as untested.

- [ ] **UC-M07.08-C050-T01 · Evidence inventory:** List the “Cross-resource restore plan” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C050-T02 · Artifact references:** Record the exact “Cross-resource restore plan” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C050-T03 · Fixture references:** Attach the “Cross-resource restore plan” fixture IDs, input identities and oracle definition; preserve the source counterexample “The berth is restored but registry and mounts still point elsewhere” as a distinct evidence case.
- [ ] **UC-M07.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cross-resource restore plan”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C050-T05 · Environment record:** Record the actual “Cross-resource restore plan” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C050-T06 · Expected versus observed:** Pair every “Cross-resource restore plan” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C050-T07 · Failure and limit records:** Attach “Cross-resource restore plan” change/failure and bounds evidence where required; include uncovered “Participants and restoration steps” and unresolved violations of “Recovery is more than moving one directory”.
- [ ] **UC-M07.08-C050-T08 · Evidence hygiene:** Check the “Cross-resource restore plan” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C050-T09 · Reproduction review:** Have the “Cross-resource restore plan” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C050-T10 · Acceptance linkage:** Link the “Cross-resource restore plan” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Restore transaction

**Source delivery:** Execute recovery through durable staged transaction semantics.

**Source invariant:** A crash during restore leaves a documented recoverable generation.

**Source negative case:** The process terminates after replacing only half the participants.

**Source bounded quantities:** Restore staging bytes and commit points.

### UC-M07.08-C051 · Contract

**Original checklist item:** Specify restore transaction inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C051-T01 · Scope statement:** Draft the operation boundary for “Restore transaction” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restore transaction”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C051-T03 · Output inventory:** List the outputs of “Restore transaction” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Restore transaction”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C051-T05 · Prerequisite contract:** Map “Restore transaction” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Restore transaction”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C051-T07 · Invariant clause:** Add a normative clause for “Restore transaction” that preserves “A crash during restore leaves a documented recoverable generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restore transaction”; include the source counterexample “The process terminates after replacing only half the participants” and the intended safe disposition.
- [ ] **UC-M07.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Restore staging bytes and commit points” in the “Restore transaction” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C051-T10 · Contract review:** Review the “Restore transaction” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C052 · Delivery

**Original checklist item:** Execute recovery through durable staged transaction semantics.

- [ ] **UC-M07.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restore transaction”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C052-T02 · Change plan:** Break the source delivery for “Restore transaction” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Restore transaction” that realizes this source instruction: Execute recovery through durable staged transaction semantics.
- [ ] **UC-M07.08-C052-T04 · Concrete realization:** Trace “Restore transaction” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restore transaction” needed to preserve “A crash during restore leaves a documented recoverable generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C052-T06 · Dependency connection:** Connect the “Restore transaction” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C052-T07 · Resource behavior:** Account for “Restore staging bytes and commit points” in “Restore transaction”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C052-T08 · Delivery check:** Run the smallest real “Restore transaction” path and its adverse fixture “The process terminates after replacing only half the participants”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C052-T09 · Patch review:** Review the “Restore transaction” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C052-T10 · Delivery handoff:** Publish the “Restore transaction” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A crash during restore leaves a documented recoverable generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Restore transaction”; copy its required invariant exactly: “A crash during restore leaves a documented recoverable generation”.
- [ ] **UC-M07.08-C053-T02 · Observable terms:** Define each term in the “Restore transaction” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C053-T03 · Precondition set:** List the preconditions under which “A crash during restore leaves a documented recoverable generation” must hold for “Restore transaction”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C053-T04 · Transition coverage:** Map the “Restore transaction” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restore transaction”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C053-T06 · Satisfying fixture:** Create a concrete “Restore transaction” case that satisfies “A crash during restore leaves a documented recoverable generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C053-T07 · Violating fixture:** Create the source counterexample “The process terminates after replacing only half the participants” for “Restore transaction”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C053-T08 · Enforcement evidence:** Exercise the “Restore transaction” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C053-T09 · Regression linkage:** Link the “Restore transaction” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Restore transaction” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C054 · Integration

**Original checklist item:** Integrate restore transaction with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restore transaction” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C054-T02 · Field mapping:** Map every “Restore transaction” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Restore transaction” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C054-T04 · Ownership agreement:** Specify who owns “Restore transaction” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C054-T05 · Handoff implementation:** Connect “Restore transaction” through the mapped seam using the real adapter or explicit specification reference; preserve “A crash during restore leaves a documented recoverable generation” across the handoff.
- [ ] **UC-M07.08-C054-T06 · Absent-input case:** Omit one required “Restore transaction” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C054-T07 · Stale-input case:** Supply an outdated “Restore transaction” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Restore transaction” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C054-T09 · Valid integration trace:** Run a valid “Restore transaction” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C054-T10 · Seam review:** Reconcile the “Restore transaction” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restore transaction; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restore transaction” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C055-T02 · Expected-result oracle:** Specify the “Restore transaction” expected result independently of the implementation output; include the property “A crash during restore leaves a documented recoverable generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C055-T03 · Fixture material:** Create the concrete “Restore transaction” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C055-T04 · Target preparation:** Prepare the “Restore transaction” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C055-T05 · Initial-state record:** Record the initial “Restore transaction” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C055-T06 · Valid-path execution:** Execute the “Restore transaction” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C055-T07 · Outcome comparison:** Compare every declared “Restore transaction” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C055-T08 · State and bounds check:** Inspect the “Restore transaction” ownership/state effects and actual use of “Restore staging bytes and commit points”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C055-T09 · Repeatability check:** Repeat the same “Restore transaction” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C055-T10 · Positive evidence:** Attach the “Restore transaction” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C056 · Negative test

**Original checklist item:** Negative case: The process terminates after replacing only half the participants. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Restore transaction” source counterexample: “The process terminates after replacing only half the participants”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Restore transaction”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C056-T03 · Valid control:** Construct a valid “Restore transaction” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C056-T04 · Minimal adverse input:** Derive the “Restore transaction” adverse fixture from the control with the smallest documented change needed to reproduce “The process terminates after replacing only half the participants”; retain that change as reproducible data.
- [ ] **UC-M07.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restore transaction”; require “A crash during restore leaves a documented recoverable generation” and forbid a false-success verdict.
- [ ] **UC-M07.08-C056-T06 · Adverse execution:** Exercise the “Restore transaction” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C056-T07 · Effect inspection:** Inspect “Restore transaction” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C056-T08 · Refusal versus failure:** Confirm the “Restore transaction” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C056-T09 · Reset and retention:** Restore only the disposable “Restore transaction” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C056-T10 · Negative regression:** Register the “Restore transaction” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C057 · Change / failure test

**Original checklist item:** Exercise restore transaction when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C057-T01 · Scenario record:** Write the “Restore transaction” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “A crash during restore leaves a documented recoverable generation”.
- [ ] **UC-M07.08-C057-T02 · Baseline capture:** Create a known-valid “Restore transaction” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C057-T03 · Injection map:** Locate the “Restore transaction” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Restore transaction” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C057-T05 · Controlled trigger:** Introduce the controlled “Restore transaction” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C057-T06 · Intermediate inspection:** Inspect the “Restore transaction” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restore transaction”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Restore transaction” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C057-T09 · Repeat and compare:** Repeat the selected “Restore transaction” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C057-T10 · Failure evidence:** Publish the “Restore transaction” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C058 · Bounds

**Original checklist item:** Choose, document and test limits for restore staging bytes and commit points; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Restore transaction”: “Restore staging bytes and commit points”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C058-T02 · Measurement method:** Choose how to observe each “Restore transaction” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C058-T03 · Budget decision:** Select justified resource and input limits for “Restore transaction”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restore transaction” cases for “Restore staging bytes and commit points”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restore transaction” limit; preserve “A crash during restore leaves a documented recoverable generation”.
- [ ] **UC-M07.08-C058-T06 · Normal measurement:** Run or review the normal “Restore transaction” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C058-T07 · At-limit measurement:** Exercise the “Restore transaction” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C058-T08 · Over-limit measurement:** Exercise the “Restore transaction” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C058-T09 · Uncovered-scope report:** List the “Restore transaction” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C058-T10 · Limit evidence:** Publish the selected “Restore transaction” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restore transaction with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C059-T01 · Event inventory:** List the “Restore transaction” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Restore transaction” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C059-T03 · Failure mapping:** Map each documented “Restore transaction” refusal or error to a diagnostic outcome; include “The process terminates after replacing only half the participants” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C059-T04 · Emission path:** Add the “Restore transaction” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C059-T05 · Redaction check:** Test “Restore transaction” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C059-T06 · Output budget:** Set and exercise bounded “Restore transaction” message size, rate and retention compatible with “Restore staging bytes and commit points”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C059-T07 · Success/refusal fixtures:** Capture “Restore transaction” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restore transaction” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C059-T09 · Operator review:** Read the “Restore transaction” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C059-T10 · Diagnostic evidence:** Publish redacted “Restore transaction” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restore transaction; label unexecuted checks as untested.

- [ ] **UC-M07.08-C060-T01 · Evidence inventory:** List the “Restore transaction” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C060-T02 · Artifact references:** Record the exact “Restore transaction” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C060-T03 · Fixture references:** Attach the “Restore transaction” fixture IDs, input identities and oracle definition; preserve the source counterexample “The process terminates after replacing only half the participants” as a distinct evidence case.
- [ ] **UC-M07.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restore transaction”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C060-T05 · Environment record:** Record the actual “Restore transaction” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C060-T06 · Expected versus observed:** Pair every “Restore transaction” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C060-T07 · Failure and limit records:** Attach “Restore transaction” change/failure and bounds evidence where required; include uncovered “Restore staging bytes and commit points” and unresolved violations of “A crash during restore leaves a documented recoverable generation”.
- [ ] **UC-M07.08-C060-T08 · Evidence hygiene:** Check the “Restore transaction” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C060-T09 · Reproduction review:** Have the “Restore transaction” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C060-T10 · Acceptance linkage:** Link the “Restore transaction” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Post-restore verification

**Source delivery:** Verify registry, seals, mounts and application state after recovery.

**Source invariant:** A successful command requires evidence of coherent restored state.

**Source negative case:** The command returns success while a seal still references old content.

**Source bounded quantities:** Verification bytes and required gates.

### UC-M07.08-C061 · Contract

**Original checklist item:** Specify post-restore verification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C061-T01 · Scope statement:** Draft the operation boundary for “Post-restore verification” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Post-restore verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C061-T03 · Output inventory:** List the outputs of “Post-restore verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Post-restore verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C061-T05 · Prerequisite contract:** Map “Post-restore verification” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C061-T06 · Authority map:** Identify who may produce, change and consume “Post-restore verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C061-T07 · Invariant clause:** Add a normative clause for “Post-restore verification” that preserves “A successful command requires evidence of coherent restored state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Post-restore verification”; include the source counterexample “The command returns success while a seal still references old content” and the intended safe disposition.
- [ ] **UC-M07.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Verification bytes and required gates” in the “Post-restore verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C061-T10 · Contract review:** Review the “Post-restore verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C062 · Delivery

**Original checklist item:** Verify registry, seals, mounts and application state after recovery.

- [ ] **UC-M07.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Post-restore verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C062-T02 · Change plan:** Break the source delivery for “Post-restore verification” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C062-T03 · Core artifact:** Create the “Post-restore verification” fixture or harness for this source instruction: Verify registry, seals, mounts and application state after recovery.
- [ ] **UC-M07.08-C062-T04 · Concrete realization:** Connect the “Post-restore verification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Post-restore verification” needed to preserve “A successful command requires evidence of coherent restored state”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C062-T06 · Dependency connection:** Connect the “Post-restore verification” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C062-T07 · Resource behavior:** Account for “Verification bytes and required gates” in “Post-restore verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C062-T08 · Delivery check:** Run the smallest real “Post-restore verification” path and its adverse fixture “The command returns success while a seal still references old content”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C062-T09 · Patch review:** Review the “Post-restore verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C062-T10 · Delivery handoff:** Publish the “Post-restore verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A successful command requires evidence of coherent restored state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “Post-restore verification”; copy its required invariant exactly: “A successful command requires evidence of coherent restored state”.
- [ ] **UC-M07.08-C063-T02 · Observable terms:** Define each term in the “Post-restore verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C063-T03 · Precondition set:** List the preconditions under which “A successful command requires evidence of coherent restored state” must hold for “Post-restore verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C063-T04 · Transition coverage:** Map the “Post-restore verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Post-restore verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C063-T06 · Satisfying fixture:** Create a concrete “Post-restore verification” case that satisfies “A successful command requires evidence of coherent restored state”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C063-T07 · Violating fixture:** Create the source counterexample “The command returns success while a seal still references old content” for “Post-restore verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C063-T08 · Enforcement evidence:** Exercise the “Post-restore verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C063-T09 · Regression linkage:** Link the “Post-restore verification” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C063-T10 · Property disposition:** Compare the satisfying and violating “Post-restore verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C064 · Integration

**Original checklist item:** Integrate post-restore verification with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Post-restore verification” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C064-T02 · Field mapping:** Map every “Post-restore verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Post-restore verification” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C064-T04 · Ownership agreement:** Specify who owns “Post-restore verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C064-T05 · Handoff implementation:** Connect “Post-restore verification” through the mapped seam using the real adapter or explicit specification reference; preserve “A successful command requires evidence of coherent restored state” across the handoff.
- [ ] **UC-M07.08-C064-T06 · Absent-input case:** Omit one required “Post-restore verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C064-T07 · Stale-input case:** Supply an outdated “Post-restore verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C064-T08 · Incompatible-input case:** Supply an incompatible “Post-restore verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C064-T09 · Valid integration trace:** Run a valid “Post-restore verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C064-T10 · Seam review:** Reconcile the “Post-restore verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for post-restore verification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Post-restore verification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C065-T02 · Expected-result oracle:** Specify the “Post-restore verification” expected result independently of the implementation output; include the property “A successful command requires evidence of coherent restored state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C065-T03 · Fixture material:** Create the concrete “Post-restore verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C065-T04 · Target preparation:** Prepare the “Post-restore verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C065-T05 · Initial-state record:** Record the initial “Post-restore verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C065-T06 · Valid-path execution:** Execute the “Post-restore verification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C065-T07 · Outcome comparison:** Compare every declared “Post-restore verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C065-T08 · State and bounds check:** Inspect the “Post-restore verification” ownership/state effects and actual use of “Verification bytes and required gates”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C065-T09 · Repeatability check:** Repeat the same “Post-restore verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C065-T10 · Positive evidence:** Attach the “Post-restore verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C066 · Negative test

**Original checklist item:** Negative case: The command returns success while a seal still references old content. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “Post-restore verification” source counterexample: “The command returns success while a seal still references old content”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Post-restore verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C066-T03 · Valid control:** Construct a valid “Post-restore verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C066-T04 · Minimal adverse input:** Derive the “Post-restore verification” adverse fixture from the control with the smallest documented change needed to reproduce “The command returns success while a seal still references old content”; retain that change as reproducible data.
- [ ] **UC-M07.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Post-restore verification”; require “A successful command requires evidence of coherent restored state” and forbid a false-success verdict.
- [ ] **UC-M07.08-C066-T06 · Adverse execution:** Exercise the “Post-restore verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C066-T07 · Effect inspection:** Inspect “Post-restore verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C066-T08 · Refusal versus failure:** Confirm the “Post-restore verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C066-T09 · Reset and retention:** Restore only the disposable “Post-restore verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C066-T10 · Negative regression:** Register the “Post-restore verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C067 · Change / failure test

**Original checklist item:** Exercise post-restore verification when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C067-T01 · Scenario record:** Write the “Post-restore verification” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “A successful command requires evidence of coherent restored state”.
- [ ] **UC-M07.08-C067-T02 · Baseline capture:** Create a known-valid “Post-restore verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C067-T03 · Injection map:** Locate the “Post-restore verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Post-restore verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C067-T05 · Controlled trigger:** Introduce the controlled “Post-restore verification” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C067-T06 · Intermediate inspection:** Inspect the “Post-restore verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Post-restore verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Post-restore verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C067-T09 · Repeat and compare:** Repeat the selected “Post-restore verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C067-T10 · Failure evidence:** Publish the “Post-restore verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C068 · Bounds

**Original checklist item:** Choose, document and test limits for verification bytes and required gates; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “Post-restore verification”: “Verification bytes and required gates”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C068-T02 · Measurement method:** Choose how to observe each “Post-restore verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C068-T03 · Budget decision:** Select justified resource and input limits for “Post-restore verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Post-restore verification” cases for “Verification bytes and required gates”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Post-restore verification” limit; preserve “A successful command requires evidence of coherent restored state”.
- [ ] **UC-M07.08-C068-T06 · Normal measurement:** Run or review the normal “Post-restore verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C068-T07 · At-limit measurement:** Exercise the “Post-restore verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C068-T08 · Over-limit measurement:** Exercise the “Post-restore verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C068-T09 · Uncovered-scope report:** List the “Post-restore verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C068-T10 · Limit evidence:** Publish the selected “Post-restore verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for post-restore verification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C069-T01 · Event inventory:** List the “Post-restore verification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Post-restore verification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C069-T03 · Failure mapping:** Map each documented “Post-restore verification” refusal or error to a diagnostic outcome; include “The command returns success while a seal still references old content” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C069-T04 · Emission path:** Add the “Post-restore verification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C069-T05 · Redaction check:** Test “Post-restore verification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C069-T06 · Output budget:** Set and exercise bounded “Post-restore verification” message size, rate and retention compatible with “Verification bytes and required gates”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C069-T07 · Success/refusal fixtures:** Capture “Post-restore verification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Post-restore verification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C069-T09 · Operator review:** Read the “Post-restore verification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C069-T10 · Diagnostic evidence:** Publish redacted “Post-restore verification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for post-restore verification; label unexecuted checks as untested.

- [ ] **UC-M07.08-C070-T01 · Evidence inventory:** List the “Post-restore verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C070-T02 · Artifact references:** Record the exact “Post-restore verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C070-T03 · Fixture references:** Attach the “Post-restore verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “The command returns success while a seal still references old content” as a distinct evidence case.
- [ ] **UC-M07.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Post-restore verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C070-T05 · Environment record:** Record the actual “Post-restore verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C070-T06 · Expected versus observed:** Pair every “Post-restore verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C070-T07 · Failure and limit records:** Attach “Post-restore verification” change/failure and bounds evidence where required; include uncovered “Verification bytes and required gates” and unresolved violations of “A successful command requires evidence of coherent restored state”.
- [ ] **UC-M07.08-C070-T08 · Evidence hygiene:** Check the “Post-restore verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C070-T09 · Reproduction review:** Have the “Post-restore verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C070-T10 · Acceptance linkage:** Link the “Post-restore verification” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Abandon semantics

**Source delivery:** Define authorized abandonment of irrecoverable transactions with retained evidence.

**Source invariant:** Abandon does not hide missing cargo or erase unexplained failure.

**Source negative case:** A user abandons a journal to silence a required integrity failure.

**Source bounded quantities:** Retained records and destructive scope.

### UC-M07.08-C071 · Contract

**Original checklist item:** Specify abandon semantics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C071-T01 · Scope statement:** Draft the operation boundary for “Abandon semantics” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Abandon semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C071-T03 · Output inventory:** List the outputs of “Abandon semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Abandon semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C071-T05 · Prerequisite contract:** Map “Abandon semantics” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Abandon semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C071-T07 · Invariant clause:** Add a normative clause for “Abandon semantics” that preserves “Abandon does not hide missing cargo or erase unexplained failure”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Abandon semantics”; include the source counterexample “A user abandons a journal to silence a required integrity failure” and the intended safe disposition.
- [ ] **UC-M07.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained records and destructive scope” in the “Abandon semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C071-T10 · Contract review:** Review the “Abandon semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C072 · Delivery

**Original checklist item:** Define authorized abandonment of irrecoverable transactions with retained evidence.

- [ ] **UC-M07.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Abandon semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C072-T02 · Change plan:** Break the source delivery for “Abandon semantics” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C072-T03 · Core artifact:** Create the “Abandon semantics” model, schema or inventory that realizes this source instruction: Define authorized abandonment of irrecoverable transactions with retained evidence.
- [ ] **UC-M07.08-C072-T04 · Concrete realization:** Populate “Abandon semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Abandon semantics” needed to preserve “Abandon does not hide missing cargo or erase unexplained failure”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C072-T06 · Dependency connection:** Connect the “Abandon semantics” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C072-T07 · Resource behavior:** Account for “Retained records and destructive scope” in “Abandon semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C072-T08 · Delivery check:** Run the smallest real “Abandon semantics” path and its adverse fixture “A user abandons a journal to silence a required integrity failure”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C072-T09 · Patch review:** Review the “Abandon semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C072-T10 · Delivery handoff:** Publish the “Abandon semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Abandon does not hide missing cargo or erase unexplained failure. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Abandon semantics”; copy its required invariant exactly: “Abandon does not hide missing cargo or erase unexplained failure”.
- [ ] **UC-M07.08-C073-T02 · Observable terms:** Define each term in the “Abandon semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C073-T03 · Precondition set:** List the preconditions under which “Abandon does not hide missing cargo or erase unexplained failure” must hold for “Abandon semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C073-T04 · Transition coverage:** Map the “Abandon semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Abandon semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C073-T06 · Satisfying fixture:** Create a concrete “Abandon semantics” case that satisfies “Abandon does not hide missing cargo or erase unexplained failure”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C073-T07 · Violating fixture:** Create the source counterexample “A user abandons a journal to silence a required integrity failure” for “Abandon semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C073-T08 · Enforcement evidence:** Exercise the “Abandon semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C073-T09 · Regression linkage:** Link the “Abandon semantics” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Abandon semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C074 · Integration

**Original checklist item:** Integrate abandon semantics with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Abandon semantics” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C074-T02 · Field mapping:** Map every “Abandon semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Abandon semantics” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C074-T04 · Ownership agreement:** Specify who owns “Abandon semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C074-T05 · Handoff implementation:** Connect “Abandon semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Abandon does not hide missing cargo or erase unexplained failure” across the handoff.
- [ ] **UC-M07.08-C074-T06 · Absent-input case:** Omit one required “Abandon semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C074-T07 · Stale-input case:** Supply an outdated “Abandon semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Abandon semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C074-T09 · Valid integration trace:** Run a valid “Abandon semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C074-T10 · Seam review:** Reconcile the “Abandon semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for abandon semantics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Abandon semantics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C075-T02 · Expected-result oracle:** Specify the “Abandon semantics” expected result independently of the implementation output; include the property “Abandon does not hide missing cargo or erase unexplained failure” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C075-T03 · Fixture material:** Create the concrete “Abandon semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C075-T04 · Target preparation:** Prepare the “Abandon semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C075-T05 · Initial-state record:** Record the initial “Abandon semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C075-T06 · Valid-path execution:** Execute the “Abandon semantics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C075-T07 · Outcome comparison:** Compare every declared “Abandon semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C075-T08 · State and bounds check:** Inspect the “Abandon semantics” ownership/state effects and actual use of “Retained records and destructive scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C075-T09 · Repeatability check:** Repeat the same “Abandon semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C075-T10 · Positive evidence:** Attach the “Abandon semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C076 · Negative test

**Original checklist item:** Negative case: A user abandons a journal to silence a required integrity failure. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Abandon semantics” source counterexample: “A user abandons a journal to silence a required integrity failure”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Abandon semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C076-T03 · Valid control:** Construct a valid “Abandon semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C076-T04 · Minimal adverse input:** Derive the “Abandon semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A user abandons a journal to silence a required integrity failure”; retain that change as reproducible data.
- [ ] **UC-M07.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Abandon semantics”; require “Abandon does not hide missing cargo or erase unexplained failure” and forbid a false-success verdict.
- [ ] **UC-M07.08-C076-T06 · Adverse execution:** Exercise the “Abandon semantics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C076-T07 · Effect inspection:** Inspect “Abandon semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C076-T08 · Refusal versus failure:** Confirm the “Abandon semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C076-T09 · Reset and retention:** Restore only the disposable “Abandon semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C076-T10 · Negative regression:** Register the “Abandon semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C077 · Change / failure test

**Original checklist item:** Exercise abandon semantics when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C077-T01 · Scenario record:** Write the “Abandon semantics” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “Abandon does not hide missing cargo or erase unexplained failure”.
- [ ] **UC-M07.08-C077-T02 · Baseline capture:** Create a known-valid “Abandon semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C077-T03 · Injection map:** Locate the “Abandon semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Abandon semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C077-T05 · Controlled trigger:** Introduce the controlled “Abandon semantics” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C077-T06 · Intermediate inspection:** Inspect the “Abandon semantics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Abandon semantics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Abandon semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C077-T09 · Repeat and compare:** Repeat the selected “Abandon semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C077-T10 · Failure evidence:** Publish the “Abandon semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C078 · Bounds

**Original checklist item:** Choose, document and test limits for retained records and destructive scope; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Abandon semantics”: “Retained records and destructive scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C078-T02 · Measurement method:** Choose how to observe each “Abandon semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C078-T03 · Budget decision:** Select justified resource and input limits for “Abandon semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Abandon semantics” cases for “Retained records and destructive scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Abandon semantics” limit; preserve “Abandon does not hide missing cargo or erase unexplained failure”.
- [ ] **UC-M07.08-C078-T06 · Normal measurement:** Run or review the normal “Abandon semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C078-T07 · At-limit measurement:** Exercise the “Abandon semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C078-T08 · Over-limit measurement:** Exercise the “Abandon semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C078-T09 · Uncovered-scope report:** List the “Abandon semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C078-T10 · Limit evidence:** Publish the selected “Abandon semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for abandon semantics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C079-T01 · Event inventory:** List the “Abandon semantics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Abandon semantics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C079-T03 · Failure mapping:** Map each documented “Abandon semantics” refusal or error to a diagnostic outcome; include “A user abandons a journal to silence a required integrity failure” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C079-T04 · Emission path:** Add the “Abandon semantics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C079-T05 · Redaction check:** Test “Abandon semantics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C079-T06 · Output budget:** Set and exercise bounded “Abandon semantics” message size, rate and retention compatible with “Retained records and destructive scope”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C079-T07 · Success/refusal fixtures:** Capture “Abandon semantics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Abandon semantics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C079-T09 · Operator review:** Read the “Abandon semantics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C079-T10 · Diagnostic evidence:** Publish redacted “Abandon semantics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for abandon semantics; label unexecuted checks as untested.

- [ ] **UC-M07.08-C080-T01 · Evidence inventory:** List the “Abandon semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C080-T02 · Artifact references:** Record the exact “Abandon semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C080-T03 · Fixture references:** Attach the “Abandon semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A user abandons a journal to silence a required integrity failure” as a distinct evidence case.
- [ ] **UC-M07.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Abandon semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C080-T05 · Environment record:** Record the actual “Abandon semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C080-T06 · Expected versus observed:** Pair every “Abandon semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C080-T07 · Failure and limit records:** Attach “Abandon semantics” change/failure and bounds evidence where required; include uncovered “Retained records and destructive scope” and unresolved violations of “Abandon does not hide missing cargo or erase unexplained failure”.
- [ ] **UC-M07.08-C080-T08 · Evidence hygiene:** Check the “Abandon semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C080-T09 · Reproduction review:** Have the “Abandon semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C080-T10 · Acceptance linkage:** Link the “Abandon semantics” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Recovery diagnostics

**Source delivery:** Show planned changes, remaining blockers and recovery-copy disposition.

**Source invariant:** Operators can see exactly what a recovery action affects.

**Source negative case:** A restore prompt shows only a display name without generation.

**Source bounded quantities:** Report size and inspection latency.

### UC-M07.08-C081 · Contract

**Original checklist item:** Specify recovery diagnostics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C081-T01 · Scope statement:** Draft the operation boundary for “Recovery diagnostics” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recovery diagnostics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C081-T03 · Output inventory:** List the outputs of “Recovery diagnostics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Recovery diagnostics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C081-T05 · Prerequisite contract:** Map “Recovery diagnostics” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Recovery diagnostics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C081-T07 · Invariant clause:** Add a normative clause for “Recovery diagnostics” that preserves “Operators can see exactly what a recovery action affects”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recovery diagnostics”; include the source counterexample “A restore prompt shows only a display name without generation” and the intended safe disposition.
- [ ] **UC-M07.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Report size and inspection latency” in the “Recovery diagnostics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C081-T10 · Contract review:** Review the “Recovery diagnostics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C082 · Delivery

**Original checklist item:** Show planned changes, remaining blockers and recovery-copy disposition.

- [ ] **UC-M07.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recovery diagnostics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C082-T02 · Change plan:** Break the source delivery for “Recovery diagnostics” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C082-T03 · Core artifact:** Create the “Recovery diagnostics” output artifact for this source instruction: Show planned changes, remaining blockers and recovery-copy disposition.
- [ ] **UC-M07.08-C082-T04 · Concrete realization:** Populate the “Recovery diagnostics” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M07.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recovery diagnostics” needed to preserve “Operators can see exactly what a recovery action affects”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C082-T06 · Dependency connection:** Connect the “Recovery diagnostics” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C082-T07 · Resource behavior:** Account for “Report size and inspection latency” in “Recovery diagnostics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C082-T08 · Delivery check:** Run the smallest real “Recovery diagnostics” path and its adverse fixture “A restore prompt shows only a display name without generation”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C082-T09 · Patch review:** Review the “Recovery diagnostics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C082-T10 · Delivery handoff:** Publish the “Recovery diagnostics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Operators can see exactly what a recovery action affects. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Recovery diagnostics”; copy its required invariant exactly: “Operators can see exactly what a recovery action affects”.
- [ ] **UC-M07.08-C083-T02 · Observable terms:** Define each term in the “Recovery diagnostics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C083-T03 · Precondition set:** List the preconditions under which “Operators can see exactly what a recovery action affects” must hold for “Recovery diagnostics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C083-T04 · Transition coverage:** Map the “Recovery diagnostics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recovery diagnostics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C083-T06 · Satisfying fixture:** Create a concrete “Recovery diagnostics” case that satisfies “Operators can see exactly what a recovery action affects”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C083-T07 · Violating fixture:** Create the source counterexample “A restore prompt shows only a display name without generation” for “Recovery diagnostics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C083-T08 · Enforcement evidence:** Exercise the “Recovery diagnostics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C083-T09 · Regression linkage:** Link the “Recovery diagnostics” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Recovery diagnostics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C084 · Integration

**Original checklist item:** Integrate recovery diagnostics with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recovery diagnostics” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C084-T02 · Field mapping:** Map every “Recovery diagnostics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Recovery diagnostics” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C084-T04 · Ownership agreement:** Specify who owns “Recovery diagnostics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C084-T05 · Handoff implementation:** Connect “Recovery diagnostics” through the mapped seam using the real adapter or explicit specification reference; preserve “Operators can see exactly what a recovery action affects” across the handoff.
- [ ] **UC-M07.08-C084-T06 · Absent-input case:** Omit one required “Recovery diagnostics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C084-T07 · Stale-input case:** Supply an outdated “Recovery diagnostics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Recovery diagnostics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C084-T09 · Valid integration trace:** Run a valid “Recovery diagnostics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C084-T10 · Seam review:** Reconcile the “Recovery diagnostics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for recovery diagnostics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Recovery diagnostics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C085-T02 · Expected-result oracle:** Specify the “Recovery diagnostics” expected result independently of the implementation output; include the property “Operators can see exactly what a recovery action affects” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C085-T03 · Fixture material:** Create the concrete “Recovery diagnostics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C085-T04 · Target preparation:** Prepare the “Recovery diagnostics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C085-T05 · Initial-state record:** Record the initial “Recovery diagnostics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C085-T06 · Valid-path execution:** Execute the “Recovery diagnostics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C085-T07 · Outcome comparison:** Compare every declared “Recovery diagnostics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C085-T08 · State and bounds check:** Inspect the “Recovery diagnostics” ownership/state effects and actual use of “Report size and inspection latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C085-T09 · Repeatability check:** Repeat the same “Recovery diagnostics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C085-T10 · Positive evidence:** Attach the “Recovery diagnostics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C086 · Negative test

**Original checklist item:** Negative case: A restore prompt shows only a display name without generation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Recovery diagnostics” source counterexample: “A restore prompt shows only a display name without generation”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Recovery diagnostics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C086-T03 · Valid control:** Construct a valid “Recovery diagnostics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C086-T04 · Minimal adverse input:** Derive the “Recovery diagnostics” adverse fixture from the control with the smallest documented change needed to reproduce “A restore prompt shows only a display name without generation”; retain that change as reproducible data.
- [ ] **UC-M07.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recovery diagnostics”; require “Operators can see exactly what a recovery action affects” and forbid a false-success verdict.
- [ ] **UC-M07.08-C086-T06 · Adverse execution:** Exercise the “Recovery diagnostics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C086-T07 · Effect inspection:** Inspect “Recovery diagnostics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C086-T08 · Refusal versus failure:** Confirm the “Recovery diagnostics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C086-T09 · Reset and retention:** Restore only the disposable “Recovery diagnostics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C086-T10 · Negative regression:** Register the “Recovery diagnostics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C087 · Change / failure test

**Original checklist item:** Exercise recovery diagnostics when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C087-T01 · Scenario record:** Write the “Recovery diagnostics” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “Operators can see exactly what a recovery action affects”.
- [ ] **UC-M07.08-C087-T02 · Baseline capture:** Create a known-valid “Recovery diagnostics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C087-T03 · Injection map:** Locate the “Recovery diagnostics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Recovery diagnostics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C087-T05 · Controlled trigger:** Introduce the controlled “Recovery diagnostics” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C087-T06 · Intermediate inspection:** Inspect the “Recovery diagnostics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recovery diagnostics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Recovery diagnostics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C087-T09 · Repeat and compare:** Repeat the selected “Recovery diagnostics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C087-T10 · Failure evidence:** Publish the “Recovery diagnostics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C088 · Bounds

**Original checklist item:** Choose, document and test limits for report size and inspection latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Recovery diagnostics”: “Report size and inspection latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C088-T02 · Measurement method:** Choose how to observe each “Recovery diagnostics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C088-T03 · Budget decision:** Select justified resource and input limits for “Recovery diagnostics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recovery diagnostics” cases for “Report size and inspection latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recovery diagnostics” limit; preserve “Operators can see exactly what a recovery action affects”.
- [ ] **UC-M07.08-C088-T06 · Normal measurement:** Run or review the normal “Recovery diagnostics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C088-T07 · At-limit measurement:** Exercise the “Recovery diagnostics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C088-T08 · Over-limit measurement:** Exercise the “Recovery diagnostics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C088-T09 · Uncovered-scope report:** List the “Recovery diagnostics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C088-T10 · Limit evidence:** Publish the selected “Recovery diagnostics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for recovery diagnostics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C089-T01 · Event inventory:** List the “Recovery diagnostics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Recovery diagnostics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C089-T03 · Failure mapping:** Map each documented “Recovery diagnostics” refusal or error to a diagnostic outcome; include “A restore prompt shows only a display name without generation” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C089-T04 · Emission path:** Add the “Recovery diagnostics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C089-T05 · Redaction check:** Test “Recovery diagnostics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C089-T06 · Output budget:** Set and exercise bounded “Recovery diagnostics” message size, rate and retention compatible with “Report size and inspection latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C089-T07 · Success/refusal fixtures:** Capture “Recovery diagnostics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Recovery diagnostics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C089-T09 · Operator review:** Read the “Recovery diagnostics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C089-T10 · Diagnostic evidence:** Publish redacted “Recovery diagnostics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recovery diagnostics; label unexecuted checks as untested.

- [ ] **UC-M07.08-C090-T01 · Evidence inventory:** List the “Recovery diagnostics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C090-T02 · Artifact references:** Record the exact “Recovery diagnostics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C090-T03 · Fixture references:** Attach the “Recovery diagnostics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A restore prompt shows only a display name without generation” as a distinct evidence case.
- [ ] **UC-M07.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recovery diagnostics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C090-T05 · Environment record:** Record the actual “Recovery diagnostics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C090-T06 · Expected versus observed:** Pair every “Recovery diagnostics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C090-T07 · Failure and limit records:** Attach “Recovery diagnostics” change/failure and bounds evidence where required; include uncovered “Report size and inspection latency” and unresolved violations of “Operators can see exactly what a recovery action affects”.
- [ ] **UC-M07.08-C090-T08 · Evidence hygiene:** Check the “Recovery diagnostics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C090-T09 · Reproduction review:** Have the “Recovery diagnostics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C090-T10 · Acceptance linkage:** Link the “Recovery diagnostics” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Recovery drill

**Source delivery:** Automate interrupted replacement and restore scenarios on a clean test workspace.

**Source invariant:** The drill returns all participants to a verified generation.

**Source negative case:** A test passes after checking only that a backup directory moved.

**Source bounded quantities:** Fault scenarios and recovery duration.

### UC-M07.08-C091 · Contract

**Original checklist item:** Specify recovery drill inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.08-C091-T01 · Scope statement:** Draft the operation boundary for “Recovery drill” within Verified rollback and recovery commands; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recovery drill”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.08-C091-T03 · Output inventory:** List the outputs of “Recovery drill” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Recovery drill”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.08-C091-T05 · Prerequisite contract:** Map “Recovery drill” to the source component prerequisites (UC-M07.01, UC-M07.03, UC-M07.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.08-C091-T06 · Authority map:** Identify who may produce, change and consume “Recovery drill”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.08-C091-T07 · Invariant clause:** Add a normative clause for “Recovery drill” that preserves “The drill returns all participants to a verified generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recovery drill”; include the source counterexample “A test passes after checking only that a backup directory moved” and the intended safe disposition.
- [ ] **UC-M07.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fault scenarios and recovery duration” in the “Recovery drill” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.08-C091-T10 · Contract review:** Review the “Recovery drill” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.08-C092 · Delivery

**Original checklist item:** Automate interrupted replacement and restore scenarios on a clean test workspace.

- [ ] **UC-M07.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recovery drill”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.08-C092-T02 · Change plan:** Break the source delivery for “Recovery drill” into concrete edit targets and reviewable outputs; keep the UC-M07.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.08-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Recovery drill” that realizes this source instruction: Automate interrupted replacement and restore scenarios on a clean test workspace.
- [ ] **UC-M07.08-C092-T04 · Concrete realization:** Trace “Recovery drill” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recovery drill” needed to preserve “The drill returns all participants to a verified generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.08-C092-T06 · Dependency connection:** Connect the “Recovery drill” implementation to retained backups, transaction journals and registry/seal/mount verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.08-C092-T07 · Resource behavior:** Account for “Fault scenarios and recovery duration” in “Recovery drill”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.08-C092-T08 · Delivery check:** Run the smallest real “Recovery drill” path and its adverse fixture “A test passes after checking only that a backup directory moved”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.08-C092-T09 · Patch review:** Review the “Recovery drill” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.08-C092-T10 · Delivery handoff:** Publish the “Recovery drill” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The drill returns all participants to a verified generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “Recovery drill”; copy its required invariant exactly: “The drill returns all participants to a verified generation”.
- [ ] **UC-M07.08-C093-T02 · Observable terms:** Define each term in the “Recovery drill” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.08-C093-T03 · Precondition set:** List the preconditions under which “The drill returns all participants to a verified generation” must hold for “Recovery drill”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.08-C093-T04 · Transition coverage:** Map the “Recovery drill” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recovery drill”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.08-C093-T06 · Satisfying fixture:** Create a concrete “Recovery drill” case that satisfies “The drill returns all participants to a verified generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.08-C093-T07 · Violating fixture:** Create the source counterexample “A test passes after checking only that a backup directory moved” for “Recovery drill”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.08-C093-T08 · Enforcement evidence:** Exercise the “Recovery drill” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.08-C093-T09 · Regression linkage:** Link the “Recovery drill” property to changes in retained backups, transaction journals and registry/seal/mount verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.08-C093-T10 · Property disposition:** Compare the satisfying and violating “Recovery drill” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.08-C094 · Integration

**Original checklist item:** Integrate recovery drill with retained backups, transaction journals and registry/seal/mount verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recovery drill” across retained backups, transaction journals and registry/seal/mount verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.08-C094-T02 · Field mapping:** Map every “Recovery drill” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Recovery drill” (source dependency list: UC-M07.01, UC-M07.03, UC-M07.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.08-C094-T04 · Ownership agreement:** Specify who owns “Recovery drill” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.08-C094-T05 · Handoff implementation:** Connect “Recovery drill” through the mapped seam using the real adapter or explicit specification reference; preserve “The drill returns all participants to a verified generation” across the handoff.
- [ ] **UC-M07.08-C094-T06 · Absent-input case:** Omit one required “Recovery drill” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.08-C094-T07 · Stale-input case:** Supply an outdated “Recovery drill” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.08-C094-T08 · Incompatible-input case:** Supply an incompatible “Recovery drill” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.08-C094-T09 · Valid integration trace:** Run a valid “Recovery drill” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.08-C094-T10 · Seam review:** Reconcile the “Recovery drill” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.08-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for recovery drill; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.08-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Recovery drill” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.08-C095-T02 · Expected-result oracle:** Specify the “Recovery drill” expected result independently of the implementation output; include the property “The drill returns all participants to a verified generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.08-C095-T03 · Fixture material:** Create the concrete “Recovery drill” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.08-C095-T04 · Target preparation:** Prepare the “Recovery drill” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.08-C095-T05 · Initial-state record:** Record the initial “Recovery drill” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.08-C095-T06 · Valid-path execution:** Execute the “Recovery drill” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.08-C095-T07 · Outcome comparison:** Compare every declared “Recovery drill” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.08-C095-T08 · State and bounds check:** Inspect the “Recovery drill” ownership/state effects and actual use of “Fault scenarios and recovery duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.08-C095-T09 · Repeatability check:** Repeat the same “Recovery drill” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.08-C095-T10 · Positive evidence:** Attach the “Recovery drill” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.08-C096 · Negative test

**Original checklist item:** Negative case: A test passes after checking only that a backup directory moved. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “Recovery drill” source counterexample: “A test passes after checking only that a backup directory moved”; state which precondition or invariant it challenges.
- [ ] **UC-M07.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Recovery drill”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.08-C096-T03 · Valid control:** Construct a valid “Recovery drill” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.08-C096-T04 · Minimal adverse input:** Derive the “Recovery drill” adverse fixture from the control with the smallest documented change needed to reproduce “A test passes after checking only that a backup directory moved”; retain that change as reproducible data.
- [ ] **UC-M07.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recovery drill”; require “The drill returns all participants to a verified generation” and forbid a false-success verdict.
- [ ] **UC-M07.08-C096-T06 · Adverse execution:** Exercise the “Recovery drill” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.08-C096-T07 · Effect inspection:** Inspect “Recovery drill” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.08-C096-T08 · Refusal versus failure:** Confirm the “Recovery drill” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.08-C096-T09 · Reset and retention:** Restore only the disposable “Recovery drill” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.08-C096-T10 · Negative regression:** Register the “Recovery drill” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.08-C097 · Change / failure test

**Original checklist item:** Exercise recovery drill when a recovery command is interrupted after only some participants have been restored; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.08-C097-T01 · Scenario record:** Write the “Recovery drill” change/failure scenario exactly as supplied: a recovery command is interrupted after only some participants have been restored; identify the property that must remain true: “The drill returns all participants to a verified generation”.
- [ ] **UC-M07.08-C097-T02 · Baseline capture:** Create a known-valid “Recovery drill” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.08-C097-T03 · Injection map:** Locate the “Recovery drill” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Recovery drill” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.08-C097-T05 · Controlled trigger:** Introduce the controlled “Recovery drill” scenario in the disposable fixture: a recovery command is interrupted after only some participants have been restored; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.08-C097-T06 · Intermediate inspection:** Inspect the “Recovery drill” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recovery drill”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Recovery drill” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.08-C097-T09 · Repeat and compare:** Repeat the selected “Recovery drill” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.08-C097-T10 · Failure evidence:** Publish the “Recovery drill” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.08-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fault scenarios and recovery duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “Recovery drill”: “Fault scenarios and recovery duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.08-C098-T02 · Measurement method:** Choose how to observe each “Recovery drill” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.08-C098-T03 · Budget decision:** Select justified resource and input limits for “Recovery drill”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recovery drill” cases for “Fault scenarios and recovery duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recovery drill” limit; preserve “The drill returns all participants to a verified generation”.
- [ ] **UC-M07.08-C098-T06 · Normal measurement:** Run or review the normal “Recovery drill” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.08-C098-T07 · At-limit measurement:** Exercise the “Recovery drill” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.08-C098-T08 · Over-limit measurement:** Exercise the “Recovery drill” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.08-C098-T09 · Uncovered-scope report:** List the “Recovery drill” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.08-C098-T10 · Limit evidence:** Publish the selected “Recovery drill” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.08-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for recovery drill with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.08-C099-T01 · Event inventory:** List the “Recovery drill” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.08-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Recovery drill” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.08-C099-T03 · Failure mapping:** Map each documented “Recovery drill” refusal or error to a diagnostic outcome; include “A test passes after checking only that a backup directory moved” and prohibit conversion into a success message.
- [ ] **UC-M07.08-C099-T04 · Emission path:** Add the “Recovery drill” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.08-C099-T05 · Redaction check:** Test “Recovery drill” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.08-C099-T06 · Output budget:** Set and exercise bounded “Recovery drill” message size, rate and retention compatible with “Fault scenarios and recovery duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.08-C099-T07 · Success/refusal fixtures:** Capture “Recovery drill” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.08-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Recovery drill” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.08-C099-T09 · Operator review:** Read the “Recovery drill” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.08-C099-T10 · Diagnostic evidence:** Publish redacted “Recovery drill” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recovery drill; label unexecuted checks as untested.

- [ ] **UC-M07.08-C100-T01 · Evidence inventory:** List the “Recovery drill” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.08-C100-T02 · Artifact references:** Record the exact “Recovery drill” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.08-C100-T03 · Fixture references:** Attach the “Recovery drill” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test passes after checking only that a backup directory moved” as a distinct evidence case.
- [ ] **UC-M07.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recovery drill”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.08-C100-T05 · Environment record:** Record the actual “Recovery drill” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.08-C100-T06 · Expected versus observed:** Pair every “Recovery drill” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.08-C100-T07 · Failure and limit records:** Attach “Recovery drill” change/failure and bounds evidence where required; include uncovered “Fault scenarios and recovery duration” and unresolved violations of “The drill returns all participants to a verified generation”.
- [ ] **UC-M07.08-C100-T08 · Evidence hygiene:** Check the “Recovery drill” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.08-C100-T09 · Reproduction review:** Have the “Recovery drill” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.08-C100-T10 · Acceptance linkage:** Link the “Recovery drill” evidence to its parent and UC-M07.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

