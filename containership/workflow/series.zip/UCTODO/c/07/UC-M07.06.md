# UC-M07.06 — Reachability-based garbage collection

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/07.md)

| Field | Preserved source value |
|---|---|
| Workstream | 07. Persistence, transactions and recovery |
| Milestone | A |
| Priority | P1 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M04.05](../04/UC-M04.05.md), [UC-M07.01](../07/UC-M07.01.md), [UC-M07.05](../07/UC-M07.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S8]. |

## Original requirement

Track references from active generations, snapshots and retained backups; quarantine then remove only unreferenced artifacts.

**Original acceptance criterion:** A concurrent deployment/restore cannot lose a referenced object; dry-run lists exactly the reclaimable bytes.

**Source trace:** Original checklist `UC100/c/07/UC-M07.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 674–684 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Reachability roots

**Source delivery:** Define roots from active generations, snapshots, retained backups and in-flight publications.

**Source invariant:** Every object still needed by a valid root is protected.

**Source negative case:** A retained snapshot is omitted from the root inventory.

**Source bounded quantities:** Root count and metadata bytes.

### UC-M07.06-C001 · Contract

**Original checklist item:** Specify reachability roots inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C001-T01 · Scope statement:** Draft the operation boundary for “Reachability roots” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reachability roots”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C001-T03 · Output inventory:** List the outputs of “Reachability roots” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Reachability roots”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C001-T05 · Prerequisite contract:** Map “Reachability roots” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Reachability roots”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C001-T07 · Invariant clause:** Add a normative clause for “Reachability roots” that preserves “Every object still needed by a valid root is protected”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reachability roots”; include the source counterexample “A retained snapshot is omitted from the root inventory” and the intended safe disposition.
- [ ] **UC-M07.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Root count and metadata bytes” in the “Reachability roots” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C001-T10 · Contract review:** Review the “Reachability roots” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C002 · Delivery

**Original checklist item:** Define roots from active generations, snapshots, retained backups and in-flight publications.

- [ ] **UC-M07.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reachability roots”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C002-T02 · Change plan:** Break the source delivery for “Reachability roots” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C002-T03 · Core artifact:** Create the “Reachability roots” model, schema or inventory that realizes this source instruction: Define roots from active generations, snapshots, retained backups and in-flight publications.
- [ ] **UC-M07.06-C002-T04 · Concrete realization:** Populate “Reachability roots” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reachability roots” needed to preserve “Every object still needed by a valid root is protected”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C002-T06 · Dependency connection:** Connect the “Reachability roots” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C002-T07 · Resource behavior:** Account for “Root count and metadata bytes” in “Reachability roots”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C002-T08 · Delivery check:** Run the smallest real “Reachability roots” path and its adverse fixture “A retained snapshot is omitted from the root inventory”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C002-T09 · Patch review:** Review the “Reachability roots” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C002-T10 · Delivery handoff:** Publish the “Reachability roots” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every object still needed by a valid root is protected. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Reachability roots”; copy its required invariant exactly: “Every object still needed by a valid root is protected”.
- [ ] **UC-M07.06-C003-T02 · Observable terms:** Define each term in the “Reachability roots” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C003-T03 · Precondition set:** List the preconditions under which “Every object still needed by a valid root is protected” must hold for “Reachability roots”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C003-T04 · Transition coverage:** Map the “Reachability roots” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reachability roots”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C003-T06 · Satisfying fixture:** Create a concrete “Reachability roots” case that satisfies “Every object still needed by a valid root is protected”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C003-T07 · Violating fixture:** Create the source counterexample “A retained snapshot is omitted from the root inventory” for “Reachability roots”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C003-T08 · Enforcement evidence:** Exercise the “Reachability roots” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C003-T09 · Regression linkage:** Link the “Reachability roots” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Reachability roots” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C004 · Integration

**Original checklist item:** Integrate reachability roots with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reachability roots” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C004-T02 · Field mapping:** Map every “Reachability roots” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Reachability roots” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C004-T04 · Ownership agreement:** Specify who owns “Reachability roots” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C004-T05 · Handoff implementation:** Connect “Reachability roots” through the mapped seam using the real adapter or explicit specification reference; preserve “Every object still needed by a valid root is protected” across the handoff.
- [ ] **UC-M07.06-C004-T06 · Absent-input case:** Omit one required “Reachability roots” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C004-T07 · Stale-input case:** Supply an outdated “Reachability roots” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Reachability roots” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C004-T09 · Valid integration trace:** Run a valid “Reachability roots” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C004-T10 · Seam review:** Reconcile the “Reachability roots” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reachability roots; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reachability roots” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C005-T02 · Expected-result oracle:** Specify the “Reachability roots” expected result independently of the implementation output; include the property “Every object still needed by a valid root is protected” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C005-T03 · Fixture material:** Create the concrete “Reachability roots” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C005-T04 · Target preparation:** Prepare the “Reachability roots” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C005-T05 · Initial-state record:** Record the initial “Reachability roots” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C005-T06 · Valid-path execution:** Execute the “Reachability roots” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C005-T07 · Outcome comparison:** Compare every declared “Reachability roots” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C005-T08 · State and bounds check:** Inspect the “Reachability roots” ownership/state effects and actual use of “Root count and metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C005-T09 · Repeatability check:** Repeat the same “Reachability roots” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C005-T10 · Positive evidence:** Attach the “Reachability roots” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C006 · Negative test

**Original checklist item:** Negative case: A retained snapshot is omitted from the root inventory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Reachability roots” source counterexample: “A retained snapshot is omitted from the root inventory”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Reachability roots”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C006-T03 · Valid control:** Construct a valid “Reachability roots” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C006-T04 · Minimal adverse input:** Derive the “Reachability roots” adverse fixture from the control with the smallest documented change needed to reproduce “A retained snapshot is omitted from the root inventory”; retain that change as reproducible data.
- [ ] **UC-M07.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reachability roots”; require “Every object still needed by a valid root is protected” and forbid a false-success verdict.
- [ ] **UC-M07.06-C006-T06 · Adverse execution:** Exercise the “Reachability roots” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C006-T07 · Effect inspection:** Inspect “Reachability roots” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C006-T08 · Refusal versus failure:** Confirm the “Reachability roots” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C006-T09 · Reset and retention:** Restore only the disposable “Reachability roots” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C006-T10 · Negative regression:** Register the “Reachability roots” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C007 · Change / failure test

**Original checklist item:** Exercise reachability roots when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C007-T01 · Scenario record:** Write the “Reachability roots” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Every object still needed by a valid root is protected”.
- [ ] **UC-M07.06-C007-T02 · Baseline capture:** Create a known-valid “Reachability roots” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C007-T03 · Injection map:** Locate the “Reachability roots” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Reachability roots” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C007-T05 · Controlled trigger:** Introduce the controlled “Reachability roots” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C007-T06 · Intermediate inspection:** Inspect the “Reachability roots” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reachability roots”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Reachability roots” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C007-T09 · Repeat and compare:** Repeat the selected “Reachability roots” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C007-T10 · Failure evidence:** Publish the “Reachability roots” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for root count and metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Reachability roots”: “Root count and metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C008-T02 · Measurement method:** Choose how to observe each “Reachability roots” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Reachability roots”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reachability roots” cases for “Root count and metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reachability roots” limit; preserve “Every object still needed by a valid root is protected”.
- [ ] **UC-M07.06-C008-T06 · Normal measurement:** Run or review the normal “Reachability roots” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C008-T07 · At-limit measurement:** Exercise the “Reachability roots” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C008-T08 · Over-limit measurement:** Exercise the “Reachability roots” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C008-T09 · Uncovered-scope report:** List the “Reachability roots” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C008-T10 · Limit evidence:** Publish the selected “Reachability roots” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reachability roots with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C009-T01 · Event inventory:** List the “Reachability roots” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Reachability roots” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C009-T03 · Failure mapping:** Map each documented “Reachability roots” refusal or error to a diagnostic outcome; include “A retained snapshot is omitted from the root inventory” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C009-T04 · Emission path:** Add the “Reachability roots” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C009-T05 · Redaction check:** Test “Reachability roots” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C009-T06 · Output budget:** Set and exercise bounded “Reachability roots” message size, rate and retention compatible with “Root count and metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C009-T07 · Success/refusal fixtures:** Capture “Reachability roots” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reachability roots” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C009-T09 · Operator review:** Read the “Reachability roots” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C009-T10 · Diagnostic evidence:** Publish redacted “Reachability roots” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reachability roots; label unexecuted checks as untested.

- [ ] **UC-M07.06-C010-T01 · Evidence inventory:** List the “Reachability roots” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C010-T02 · Artifact references:** Record the exact “Reachability roots” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C010-T03 · Fixture references:** Attach the “Reachability roots” fixture IDs, input identities and oracle definition; preserve the source counterexample “A retained snapshot is omitted from the root inventory” as a distinct evidence case.
- [ ] **UC-M07.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reachability roots”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C010-T05 · Environment record:** Record the actual “Reachability roots” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C010-T06 · Expected versus observed:** Pair every “Reachability roots” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C010-T07 · Failure and limit records:** Attach “Reachability roots” change/failure and bounds evidence where required; include uncovered “Root count and metadata bytes” and unresolved violations of “Every object still needed by a valid root is protected”.
- [ ] **UC-M07.06-C010-T08 · Evidence hygiene:** Check the “Reachability roots” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C010-T09 · Reproduction review:** Have the “Reachability roots” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C010-T10 · Acceptance linkage:** Link the “Reachability roots” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Reference graph traversal

**Source delivery:** Traverse immutable artifact and state dependencies from protected roots.

**Source invariant:** Transitive dependencies remain live even without direct user references.

**Source negative case:** A checkpoint's dependent history segment is collected.

**Source bounded quantities:** Graph edges and traversal memory.

### UC-M07.06-C011 · Contract

**Original checklist item:** Specify reference graph traversal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C011-T01 · Scope statement:** Draft the operation boundary for “Reference graph traversal” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reference graph traversal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C011-T03 · Output inventory:** List the outputs of “Reference graph traversal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Reference graph traversal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C011-T05 · Prerequisite contract:** Map “Reference graph traversal” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Reference graph traversal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C011-T07 · Invariant clause:** Add a normative clause for “Reference graph traversal” that preserves “Transitive dependencies remain live even without direct user references”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reference graph traversal”; include the source counterexample “A checkpoint's dependent history segment is collected” and the intended safe disposition.
- [ ] **UC-M07.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Graph edges and traversal memory” in the “Reference graph traversal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C011-T10 · Contract review:** Review the “Reference graph traversal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C012 · Delivery

**Original checklist item:** Traverse immutable artifact and state dependencies from protected roots.

- [ ] **UC-M07.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reference graph traversal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C012-T02 · Change plan:** Break the source delivery for “Reference graph traversal” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Reference graph traversal” that realizes this source instruction: Traverse immutable artifact and state dependencies from protected roots.
- [ ] **UC-M07.06-C012-T04 · Concrete realization:** Trace “Reference graph traversal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reference graph traversal” needed to preserve “Transitive dependencies remain live even without direct user references”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C012-T06 · Dependency connection:** Connect the “Reference graph traversal” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C012-T07 · Resource behavior:** Account for “Graph edges and traversal memory” in “Reference graph traversal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C012-T08 · Delivery check:** Run the smallest real “Reference graph traversal” path and its adverse fixture “A checkpoint's dependent history segment is collected”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C012-T09 · Patch review:** Review the “Reference graph traversal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C012-T10 · Delivery handoff:** Publish the “Reference graph traversal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Transitive dependencies remain live even without direct user references. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Reference graph traversal”; copy its required invariant exactly: “Transitive dependencies remain live even without direct user references”.
- [ ] **UC-M07.06-C013-T02 · Observable terms:** Define each term in the “Reference graph traversal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C013-T03 · Precondition set:** List the preconditions under which “Transitive dependencies remain live even without direct user references” must hold for “Reference graph traversal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C013-T04 · Transition coverage:** Map the “Reference graph traversal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reference graph traversal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C013-T06 · Satisfying fixture:** Create a concrete “Reference graph traversal” case that satisfies “Transitive dependencies remain live even without direct user references”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C013-T07 · Violating fixture:** Create the source counterexample “A checkpoint's dependent history segment is collected” for “Reference graph traversal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C013-T08 · Enforcement evidence:** Exercise the “Reference graph traversal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C013-T09 · Regression linkage:** Link the “Reference graph traversal” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Reference graph traversal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C014 · Integration

**Original checklist item:** Integrate reference graph traversal with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reference graph traversal” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C014-T02 · Field mapping:** Map every “Reference graph traversal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Reference graph traversal” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C014-T04 · Ownership agreement:** Specify who owns “Reference graph traversal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C014-T05 · Handoff implementation:** Connect “Reference graph traversal” through the mapped seam using the real adapter or explicit specification reference; preserve “Transitive dependencies remain live even without direct user references” across the handoff.
- [ ] **UC-M07.06-C014-T06 · Absent-input case:** Omit one required “Reference graph traversal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C014-T07 · Stale-input case:** Supply an outdated “Reference graph traversal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Reference graph traversal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C014-T09 · Valid integration trace:** Run a valid “Reference graph traversal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C014-T10 · Seam review:** Reconcile the “Reference graph traversal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reference graph traversal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reference graph traversal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C015-T02 · Expected-result oracle:** Specify the “Reference graph traversal” expected result independently of the implementation output; include the property “Transitive dependencies remain live even without direct user references” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C015-T03 · Fixture material:** Create the concrete “Reference graph traversal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C015-T04 · Target preparation:** Prepare the “Reference graph traversal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C015-T05 · Initial-state record:** Record the initial “Reference graph traversal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C015-T06 · Valid-path execution:** Execute the “Reference graph traversal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C015-T07 · Outcome comparison:** Compare every declared “Reference graph traversal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C015-T08 · State and bounds check:** Inspect the “Reference graph traversal” ownership/state effects and actual use of “Graph edges and traversal memory”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C015-T09 · Repeatability check:** Repeat the same “Reference graph traversal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C015-T10 · Positive evidence:** Attach the “Reference graph traversal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C016 · Negative test

**Original checklist item:** Negative case: A checkpoint's dependent history segment is collected. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Reference graph traversal” source counterexample: “A checkpoint's dependent history segment is collected”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Reference graph traversal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C016-T03 · Valid control:** Construct a valid “Reference graph traversal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C016-T04 · Minimal adverse input:** Derive the “Reference graph traversal” adverse fixture from the control with the smallest documented change needed to reproduce “A checkpoint's dependent history segment is collected”; retain that change as reproducible data.
- [ ] **UC-M07.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reference graph traversal”; require “Transitive dependencies remain live even without direct user references” and forbid a false-success verdict.
- [ ] **UC-M07.06-C016-T06 · Adverse execution:** Exercise the “Reference graph traversal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C016-T07 · Effect inspection:** Inspect “Reference graph traversal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C016-T08 · Refusal versus failure:** Confirm the “Reference graph traversal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C016-T09 · Reset and retention:** Restore only the disposable “Reference graph traversal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C016-T10 · Negative regression:** Register the “Reference graph traversal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C017 · Change / failure test

**Original checklist item:** Exercise reference graph traversal when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C017-T01 · Scenario record:** Write the “Reference graph traversal” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Transitive dependencies remain live even without direct user references”.
- [ ] **UC-M07.06-C017-T02 · Baseline capture:** Create a known-valid “Reference graph traversal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C017-T03 · Injection map:** Locate the “Reference graph traversal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Reference graph traversal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C017-T05 · Controlled trigger:** Introduce the controlled “Reference graph traversal” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C017-T06 · Intermediate inspection:** Inspect the “Reference graph traversal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reference graph traversal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Reference graph traversal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C017-T09 · Repeat and compare:** Repeat the selected “Reference graph traversal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C017-T10 · Failure evidence:** Publish the “Reference graph traversal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for graph edges and traversal memory; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Reference graph traversal”: “Graph edges and traversal memory”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C018-T02 · Measurement method:** Choose how to observe each “Reference graph traversal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Reference graph traversal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reference graph traversal” cases for “Graph edges and traversal memory”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reference graph traversal” limit; preserve “Transitive dependencies remain live even without direct user references”.
- [ ] **UC-M07.06-C018-T06 · Normal measurement:** Run or review the normal “Reference graph traversal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C018-T07 · At-limit measurement:** Exercise the “Reference graph traversal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C018-T08 · Over-limit measurement:** Exercise the “Reference graph traversal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C018-T09 · Uncovered-scope report:** List the “Reference graph traversal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C018-T10 · Limit evidence:** Publish the selected “Reference graph traversal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reference graph traversal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C019-T01 · Event inventory:** List the “Reference graph traversal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Reference graph traversal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C019-T03 · Failure mapping:** Map each documented “Reference graph traversal” refusal or error to a diagnostic outcome; include “A checkpoint's dependent history segment is collected” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C019-T04 · Emission path:** Add the “Reference graph traversal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C019-T05 · Redaction check:** Test “Reference graph traversal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C019-T06 · Output budget:** Set and exercise bounded “Reference graph traversal” message size, rate and retention compatible with “Graph edges and traversal memory”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C019-T07 · Success/refusal fixtures:** Capture “Reference graph traversal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reference graph traversal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C019-T09 · Operator review:** Read the “Reference graph traversal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C019-T10 · Diagnostic evidence:** Publish redacted “Reference graph traversal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reference graph traversal; label unexecuted checks as untested.

- [ ] **UC-M07.06-C020-T01 · Evidence inventory:** List the “Reference graph traversal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C020-T02 · Artifact references:** Record the exact “Reference graph traversal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C020-T03 · Fixture references:** Attach the “Reference graph traversal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A checkpoint's dependent history segment is collected” as a distinct evidence case.
- [ ] **UC-M07.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reference graph traversal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C020-T05 · Environment record:** Record the actual “Reference graph traversal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C020-T06 · Expected versus observed:** Pair every “Reference graph traversal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C020-T07 · Failure and limit records:** Attach “Reference graph traversal” change/failure and bounds evidence where required; include uncovered “Graph edges and traversal memory” and unresolved violations of “Transitive dependencies remain live even without direct user references”.
- [ ] **UC-M07.06-C020-T08 · Evidence hygiene:** Check the “Reference graph traversal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C020-T09 · Reproduction review:** Have the “Reference graph traversal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C020-T10 · Acceptance linkage:** Link the “Reference graph traversal” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Concurrent mutation protocol

**Source delivery:** Coordinate collection with deployment, publication and restore.

**Source invariant:** Newly referenced objects cannot be deleted by a stale collection view.

**Source negative case:** A restore claims an object after the collector's initial scan.

**Source bounded quantities:** Concurrent publishers and synchronization time.

### UC-M07.06-C021 · Contract

**Original checklist item:** Specify concurrent mutation protocol inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C021-T01 · Scope statement:** Draft the operation boundary for “Concurrent mutation protocol” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Concurrent mutation protocol”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C021-T03 · Output inventory:** List the outputs of “Concurrent mutation protocol” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Concurrent mutation protocol”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C021-T05 · Prerequisite contract:** Map “Concurrent mutation protocol” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Concurrent mutation protocol”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C021-T07 · Invariant clause:** Add a normative clause for “Concurrent mutation protocol” that preserves “Newly referenced objects cannot be deleted by a stale collection view”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Concurrent mutation protocol”; include the source counterexample “A restore claims an object after the collector's initial scan” and the intended safe disposition.
- [ ] **UC-M07.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent publishers and synchronization time” in the “Concurrent mutation protocol” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C021-T10 · Contract review:** Review the “Concurrent mutation protocol” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C022 · Delivery

**Original checklist item:** Coordinate collection with deployment, publication and restore.

- [ ] **UC-M07.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Concurrent mutation protocol”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C022-T02 · Change plan:** Break the source delivery for “Concurrent mutation protocol” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Concurrent mutation protocol” that realizes this source instruction: Coordinate collection with deployment, publication and restore.
- [ ] **UC-M07.06-C022-T04 · Concrete realization:** Trace “Concurrent mutation protocol” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Concurrent mutation protocol” needed to preserve “Newly referenced objects cannot be deleted by a stale collection view”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C022-T06 · Dependency connection:** Connect the “Concurrent mutation protocol” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C022-T07 · Resource behavior:** Account for “Concurrent publishers and synchronization time” in “Concurrent mutation protocol”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C022-T08 · Delivery check:** Run the smallest real “Concurrent mutation protocol” path and its adverse fixture “A restore claims an object after the collector's initial scan”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C022-T09 · Patch review:** Review the “Concurrent mutation protocol” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C022-T10 · Delivery handoff:** Publish the “Concurrent mutation protocol” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Newly referenced objects cannot be deleted by a stale collection view. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Concurrent mutation protocol”; copy its required invariant exactly: “Newly referenced objects cannot be deleted by a stale collection view”.
- [ ] **UC-M07.06-C023-T02 · Observable terms:** Define each term in the “Concurrent mutation protocol” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C023-T03 · Precondition set:** List the preconditions under which “Newly referenced objects cannot be deleted by a stale collection view” must hold for “Concurrent mutation protocol”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C023-T04 · Transition coverage:** Map the “Concurrent mutation protocol” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Concurrent mutation protocol”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C023-T06 · Satisfying fixture:** Create a concrete “Concurrent mutation protocol” case that satisfies “Newly referenced objects cannot be deleted by a stale collection view”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C023-T07 · Violating fixture:** Create the source counterexample “A restore claims an object after the collector's initial scan” for “Concurrent mutation protocol”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C023-T08 · Enforcement evidence:** Exercise the “Concurrent mutation protocol” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C023-T09 · Regression linkage:** Link the “Concurrent mutation protocol” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Concurrent mutation protocol” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C024 · Integration

**Original checklist item:** Integrate concurrent mutation protocol with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Concurrent mutation protocol” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C024-T02 · Field mapping:** Map every “Concurrent mutation protocol” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Concurrent mutation protocol” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C024-T04 · Ownership agreement:** Specify who owns “Concurrent mutation protocol” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C024-T05 · Handoff implementation:** Connect “Concurrent mutation protocol” through the mapped seam using the real adapter or explicit specification reference; preserve “Newly referenced objects cannot be deleted by a stale collection view” across the handoff.
- [ ] **UC-M07.06-C024-T06 · Absent-input case:** Omit one required “Concurrent mutation protocol” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C024-T07 · Stale-input case:** Supply an outdated “Concurrent mutation protocol” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Concurrent mutation protocol” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C024-T09 · Valid integration trace:** Run a valid “Concurrent mutation protocol” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C024-T10 · Seam review:** Reconcile the “Concurrent mutation protocol” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for concurrent mutation protocol; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Concurrent mutation protocol” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C025-T02 · Expected-result oracle:** Specify the “Concurrent mutation protocol” expected result independently of the implementation output; include the property “Newly referenced objects cannot be deleted by a stale collection view” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C025-T03 · Fixture material:** Create the concrete “Concurrent mutation protocol” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C025-T04 · Target preparation:** Prepare the “Concurrent mutation protocol” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C025-T05 · Initial-state record:** Record the initial “Concurrent mutation protocol” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C025-T06 · Valid-path execution:** Execute the “Concurrent mutation protocol” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C025-T07 · Outcome comparison:** Compare every declared “Concurrent mutation protocol” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C025-T08 · State and bounds check:** Inspect the “Concurrent mutation protocol” ownership/state effects and actual use of “Concurrent publishers and synchronization time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C025-T09 · Repeatability check:** Repeat the same “Concurrent mutation protocol” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C025-T10 · Positive evidence:** Attach the “Concurrent mutation protocol” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C026 · Negative test

**Original checklist item:** Negative case: A restore claims an object after the collector's initial scan. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Concurrent mutation protocol” source counterexample: “A restore claims an object after the collector's initial scan”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Concurrent mutation protocol”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C026-T03 · Valid control:** Construct a valid “Concurrent mutation protocol” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C026-T04 · Minimal adverse input:** Derive the “Concurrent mutation protocol” adverse fixture from the control with the smallest documented change needed to reproduce “A restore claims an object after the collector's initial scan”; retain that change as reproducible data.
- [ ] **UC-M07.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Concurrent mutation protocol”; require “Newly referenced objects cannot be deleted by a stale collection view” and forbid a false-success verdict.
- [ ] **UC-M07.06-C026-T06 · Adverse execution:** Exercise the “Concurrent mutation protocol” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C026-T07 · Effect inspection:** Inspect “Concurrent mutation protocol” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C026-T08 · Refusal versus failure:** Confirm the “Concurrent mutation protocol” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C026-T09 · Reset and retention:** Restore only the disposable “Concurrent mutation protocol” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C026-T10 · Negative regression:** Register the “Concurrent mutation protocol” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C027 · Change / failure test

**Original checklist item:** Exercise concurrent mutation protocol when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C027-T01 · Scenario record:** Write the “Concurrent mutation protocol” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Newly referenced objects cannot be deleted by a stale collection view”.
- [ ] **UC-M07.06-C027-T02 · Baseline capture:** Create a known-valid “Concurrent mutation protocol” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C027-T03 · Injection map:** Locate the “Concurrent mutation protocol” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Concurrent mutation protocol” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C027-T05 · Controlled trigger:** Introduce the controlled “Concurrent mutation protocol” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C027-T06 · Intermediate inspection:** Inspect the “Concurrent mutation protocol” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Concurrent mutation protocol”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Concurrent mutation protocol” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C027-T09 · Repeat and compare:** Repeat the selected “Concurrent mutation protocol” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C027-T10 · Failure evidence:** Publish the “Concurrent mutation protocol” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for concurrent publishers and synchronization time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Concurrent mutation protocol”: “Concurrent publishers and synchronization time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C028-T02 · Measurement method:** Choose how to observe each “Concurrent mutation protocol” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Concurrent mutation protocol”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Concurrent mutation protocol” cases for “Concurrent publishers and synchronization time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Concurrent mutation protocol” limit; preserve “Newly referenced objects cannot be deleted by a stale collection view”.
- [ ] **UC-M07.06-C028-T06 · Normal measurement:** Run or review the normal “Concurrent mutation protocol” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C028-T07 · At-limit measurement:** Exercise the “Concurrent mutation protocol” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C028-T08 · Over-limit measurement:** Exercise the “Concurrent mutation protocol” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C028-T09 · Uncovered-scope report:** List the “Concurrent mutation protocol” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C028-T10 · Limit evidence:** Publish the selected “Concurrent mutation protocol” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for concurrent mutation protocol with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C029-T01 · Event inventory:** List the “Concurrent mutation protocol” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Concurrent mutation protocol” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C029-T03 · Failure mapping:** Map each documented “Concurrent mutation protocol” refusal or error to a diagnostic outcome; include “A restore claims an object after the collector's initial scan” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C029-T04 · Emission path:** Add the “Concurrent mutation protocol” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C029-T05 · Redaction check:** Test “Concurrent mutation protocol” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C029-T06 · Output budget:** Set and exercise bounded “Concurrent mutation protocol” message size, rate and retention compatible with “Concurrent publishers and synchronization time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C029-T07 · Success/refusal fixtures:** Capture “Concurrent mutation protocol” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Concurrent mutation protocol” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C029-T09 · Operator review:** Read the “Concurrent mutation protocol” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C029-T10 · Diagnostic evidence:** Publish redacted “Concurrent mutation protocol” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for concurrent mutation protocol; label unexecuted checks as untested.

- [ ] **UC-M07.06-C030-T01 · Evidence inventory:** List the “Concurrent mutation protocol” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C030-T02 · Artifact references:** Record the exact “Concurrent mutation protocol” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C030-T03 · Fixture references:** Attach the “Concurrent mutation protocol” fixture IDs, input identities and oracle definition; preserve the source counterexample “A restore claims an object after the collector's initial scan” as a distinct evidence case.
- [ ] **UC-M07.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Concurrent mutation protocol”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C030-T05 · Environment record:** Record the actual “Concurrent mutation protocol” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C030-T06 · Expected versus observed:** Pair every “Concurrent mutation protocol” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C030-T07 · Failure and limit records:** Attach “Concurrent mutation protocol” change/failure and bounds evidence where required; include uncovered “Concurrent publishers and synchronization time” and unresolved violations of “Newly referenced objects cannot be deleted by a stale collection view”.
- [ ] **UC-M07.06-C030-T08 · Evidence hygiene:** Check the “Concurrent mutation protocol” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C030-T09 · Reproduction review:** Have the “Concurrent mutation protocol” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C030-T10 · Acceptance linkage:** Link the “Concurrent mutation protocol” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Unreferenced candidate set

**Source delivery:** Identify only objects unreachable under the selected consistency boundary.

**Source invariant:** Candidate selection does not rely solely on file age.

**Source negative case:** An old but active image is marked reclaimable.

**Source bounded quantities:** Candidate objects and scan duration.

### UC-M07.06-C031 · Contract

**Original checklist item:** Specify unreferenced candidate set inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C031-T01 · Scope statement:** Draft the operation boundary for “Unreferenced candidate set” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Unreferenced candidate set”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C031-T03 · Output inventory:** List the outputs of “Unreferenced candidate set” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Unreferenced candidate set”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C031-T05 · Prerequisite contract:** Map “Unreferenced candidate set” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Unreferenced candidate set”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C031-T07 · Invariant clause:** Add a normative clause for “Unreferenced candidate set” that preserves “Candidate selection does not rely solely on file age”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Unreferenced candidate set”; include the source counterexample “An old but active image is marked reclaimable” and the intended safe disposition.
- [ ] **UC-M07.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Candidate objects and scan duration” in the “Unreferenced candidate set” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C031-T10 · Contract review:** Review the “Unreferenced candidate set” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C032 · Delivery

**Original checklist item:** Identify only objects unreachable under the selected consistency boundary.

- [ ] **UC-M07.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Unreferenced candidate set”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C032-T02 · Change plan:** Break the source delivery for “Unreferenced candidate set” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C032-T03 · Core artifact:** Create the “Unreferenced candidate set” model, schema or inventory that realizes this source instruction: Identify only objects unreachable under the selected consistency boundary.
- [ ] **UC-M07.06-C032-T04 · Concrete realization:** Populate “Unreferenced candidate set” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Unreferenced candidate set” needed to preserve “Candidate selection does not rely solely on file age”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C032-T06 · Dependency connection:** Connect the “Unreferenced candidate set” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C032-T07 · Resource behavior:** Account for “Candidate objects and scan duration” in “Unreferenced candidate set”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C032-T08 · Delivery check:** Run the smallest real “Unreferenced candidate set” path and its adverse fixture “An old but active image is marked reclaimable”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C032-T09 · Patch review:** Review the “Unreferenced candidate set” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C032-T10 · Delivery handoff:** Publish the “Unreferenced candidate set” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Candidate selection does not rely solely on file age. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Unreferenced candidate set”; copy its required invariant exactly: “Candidate selection does not rely solely on file age”.
- [ ] **UC-M07.06-C033-T02 · Observable terms:** Define each term in the “Unreferenced candidate set” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C033-T03 · Precondition set:** List the preconditions under which “Candidate selection does not rely solely on file age” must hold for “Unreferenced candidate set”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C033-T04 · Transition coverage:** Map the “Unreferenced candidate set” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Unreferenced candidate set”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C033-T06 · Satisfying fixture:** Create a concrete “Unreferenced candidate set” case that satisfies “Candidate selection does not rely solely on file age”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C033-T07 · Violating fixture:** Create the source counterexample “An old but active image is marked reclaimable” for “Unreferenced candidate set”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C033-T08 · Enforcement evidence:** Exercise the “Unreferenced candidate set” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C033-T09 · Regression linkage:** Link the “Unreferenced candidate set” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Unreferenced candidate set” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C034 · Integration

**Original checklist item:** Integrate unreferenced candidate set with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Unreferenced candidate set” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C034-T02 · Field mapping:** Map every “Unreferenced candidate set” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Unreferenced candidate set” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C034-T04 · Ownership agreement:** Specify who owns “Unreferenced candidate set” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C034-T05 · Handoff implementation:** Connect “Unreferenced candidate set” through the mapped seam using the real adapter or explicit specification reference; preserve “Candidate selection does not rely solely on file age” across the handoff.
- [ ] **UC-M07.06-C034-T06 · Absent-input case:** Omit one required “Unreferenced candidate set” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C034-T07 · Stale-input case:** Supply an outdated “Unreferenced candidate set” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Unreferenced candidate set” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C034-T09 · Valid integration trace:** Run a valid “Unreferenced candidate set” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C034-T10 · Seam review:** Reconcile the “Unreferenced candidate set” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for unreferenced candidate set; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Unreferenced candidate set” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C035-T02 · Expected-result oracle:** Specify the “Unreferenced candidate set” expected result independently of the implementation output; include the property “Candidate selection does not rely solely on file age” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C035-T03 · Fixture material:** Create the concrete “Unreferenced candidate set” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C035-T04 · Target preparation:** Prepare the “Unreferenced candidate set” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C035-T05 · Initial-state record:** Record the initial “Unreferenced candidate set” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C035-T06 · Valid-path execution:** Execute the “Unreferenced candidate set” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C035-T07 · Outcome comparison:** Compare every declared “Unreferenced candidate set” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C035-T08 · State and bounds check:** Inspect the “Unreferenced candidate set” ownership/state effects and actual use of “Candidate objects and scan duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C035-T09 · Repeatability check:** Repeat the same “Unreferenced candidate set” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C035-T10 · Positive evidence:** Attach the “Unreferenced candidate set” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C036 · Negative test

**Original checklist item:** Negative case: An old but active image is marked reclaimable. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Unreferenced candidate set” source counterexample: “An old but active image is marked reclaimable”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Unreferenced candidate set”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C036-T03 · Valid control:** Construct a valid “Unreferenced candidate set” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C036-T04 · Minimal adverse input:** Derive the “Unreferenced candidate set” adverse fixture from the control with the smallest documented change needed to reproduce “An old but active image is marked reclaimable”; retain that change as reproducible data.
- [ ] **UC-M07.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Unreferenced candidate set”; require “Candidate selection does not rely solely on file age” and forbid a false-success verdict.
- [ ] **UC-M07.06-C036-T06 · Adverse execution:** Exercise the “Unreferenced candidate set” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C036-T07 · Effect inspection:** Inspect “Unreferenced candidate set” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C036-T08 · Refusal versus failure:** Confirm the “Unreferenced candidate set” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C036-T09 · Reset and retention:** Restore only the disposable “Unreferenced candidate set” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C036-T10 · Negative regression:** Register the “Unreferenced candidate set” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C037 · Change / failure test

**Original checklist item:** Exercise unreferenced candidate set when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C037-T01 · Scenario record:** Write the “Unreferenced candidate set” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Candidate selection does not rely solely on file age”.
- [ ] **UC-M07.06-C037-T02 · Baseline capture:** Create a known-valid “Unreferenced candidate set” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C037-T03 · Injection map:** Locate the “Unreferenced candidate set” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Unreferenced candidate set” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C037-T05 · Controlled trigger:** Introduce the controlled “Unreferenced candidate set” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C037-T06 · Intermediate inspection:** Inspect the “Unreferenced candidate set” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Unreferenced candidate set”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Unreferenced candidate set” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C037-T09 · Repeat and compare:** Repeat the selected “Unreferenced candidate set” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C037-T10 · Failure evidence:** Publish the “Unreferenced candidate set” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for candidate objects and scan duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Unreferenced candidate set”: “Candidate objects and scan duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C038-T02 · Measurement method:** Choose how to observe each “Unreferenced candidate set” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Unreferenced candidate set”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Unreferenced candidate set” cases for “Candidate objects and scan duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Unreferenced candidate set” limit; preserve “Candidate selection does not rely solely on file age”.
- [ ] **UC-M07.06-C038-T06 · Normal measurement:** Run or review the normal “Unreferenced candidate set” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C038-T07 · At-limit measurement:** Exercise the “Unreferenced candidate set” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C038-T08 · Over-limit measurement:** Exercise the “Unreferenced candidate set” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C038-T09 · Uncovered-scope report:** List the “Unreferenced candidate set” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C038-T10 · Limit evidence:** Publish the selected “Unreferenced candidate set” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for unreferenced candidate set with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C039-T01 · Event inventory:** List the “Unreferenced candidate set” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Unreferenced candidate set” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C039-T03 · Failure mapping:** Map each documented “Unreferenced candidate set” refusal or error to a diagnostic outcome; include “An old but active image is marked reclaimable” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C039-T04 · Emission path:** Add the “Unreferenced candidate set” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C039-T05 · Redaction check:** Test “Unreferenced candidate set” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C039-T06 · Output budget:** Set and exercise bounded “Unreferenced candidate set” message size, rate and retention compatible with “Candidate objects and scan duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C039-T07 · Success/refusal fixtures:** Capture “Unreferenced candidate set” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Unreferenced candidate set” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C039-T09 · Operator review:** Read the “Unreferenced candidate set” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C039-T10 · Diagnostic evidence:** Publish redacted “Unreferenced candidate set” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for unreferenced candidate set; label unexecuted checks as untested.

- [ ] **UC-M07.06-C040-T01 · Evidence inventory:** List the “Unreferenced candidate set” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C040-T02 · Artifact references:** Record the exact “Unreferenced candidate set” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C040-T03 · Fixture references:** Attach the “Unreferenced candidate set” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old but active image is marked reclaimable” as a distinct evidence case.
- [ ] **UC-M07.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Unreferenced candidate set”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C040-T05 · Environment record:** Record the actual “Unreferenced candidate set” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C040-T06 · Expected versus observed:** Pair every “Unreferenced candidate set” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C040-T07 · Failure and limit records:** Attach “Unreferenced candidate set” change/failure and bounds evidence where required; include uncovered “Candidate objects and scan duration” and unresolved violations of “Candidate selection does not rely solely on file age”.
- [ ] **UC-M07.06-C040-T08 · Evidence hygiene:** Check the “Unreferenced candidate set” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C040-T09 · Reproduction review:** Have the “Unreferenced candidate set” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C040-T10 · Acceptance linkage:** Link the “Unreferenced candidate set” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Quarantine phase

**Source delivery:** Move or mark candidates for reversible quarantine before final removal.

**Source invariant:** Collection allows recovery from a mistaken candidate classification.

**Source negative case:** A newly needed object is removed immediately without quarantine.

**Source bounded quantities:** Quarantine bytes and retention interval.

### UC-M07.06-C041 · Contract

**Original checklist item:** Specify quarantine phase inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C041-T01 · Scope statement:** Draft the operation boundary for “Quarantine phase” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Quarantine phase”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C041-T03 · Output inventory:** List the outputs of “Quarantine phase” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Quarantine phase”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C041-T05 · Prerequisite contract:** Map “Quarantine phase” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Quarantine phase”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C041-T07 · Invariant clause:** Add a normative clause for “Quarantine phase” that preserves “Collection allows recovery from a mistaken candidate classification”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Quarantine phase”; include the source counterexample “A newly needed object is removed immediately without quarantine” and the intended safe disposition.
- [ ] **UC-M07.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Quarantine bytes and retention interval” in the “Quarantine phase” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C041-T10 · Contract review:** Review the “Quarantine phase” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C042 · Delivery

**Original checklist item:** Move or mark candidates for reversible quarantine before final removal.

- [ ] **UC-M07.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Quarantine phase”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C042-T02 · Change plan:** Break the source delivery for “Quarantine phase” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Quarantine phase” that realizes this source instruction: Move or mark candidates for reversible quarantine before final removal.
- [ ] **UC-M07.06-C042-T04 · Concrete realization:** Trace “Quarantine phase” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Quarantine phase” needed to preserve “Collection allows recovery from a mistaken candidate classification”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C042-T06 · Dependency connection:** Connect the “Quarantine phase” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C042-T07 · Resource behavior:** Account for “Quarantine bytes and retention interval” in “Quarantine phase”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C042-T08 · Delivery check:** Run the smallest real “Quarantine phase” path and its adverse fixture “A newly needed object is removed immediately without quarantine”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C042-T09 · Patch review:** Review the “Quarantine phase” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C042-T10 · Delivery handoff:** Publish the “Quarantine phase” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Collection allows recovery from a mistaken candidate classification. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Quarantine phase”; copy its required invariant exactly: “Collection allows recovery from a mistaken candidate classification”.
- [ ] **UC-M07.06-C043-T02 · Observable terms:** Define each term in the “Quarantine phase” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C043-T03 · Precondition set:** List the preconditions under which “Collection allows recovery from a mistaken candidate classification” must hold for “Quarantine phase”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C043-T04 · Transition coverage:** Map the “Quarantine phase” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Quarantine phase”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C043-T06 · Satisfying fixture:** Create a concrete “Quarantine phase” case that satisfies “Collection allows recovery from a mistaken candidate classification”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C043-T07 · Violating fixture:** Create the source counterexample “A newly needed object is removed immediately without quarantine” for “Quarantine phase”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C043-T08 · Enforcement evidence:** Exercise the “Quarantine phase” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C043-T09 · Regression linkage:** Link the “Quarantine phase” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Quarantine phase” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C044 · Integration

**Original checklist item:** Integrate quarantine phase with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Quarantine phase” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C044-T02 · Field mapping:** Map every “Quarantine phase” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Quarantine phase” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C044-T04 · Ownership agreement:** Specify who owns “Quarantine phase” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C044-T05 · Handoff implementation:** Connect “Quarantine phase” through the mapped seam using the real adapter or explicit specification reference; preserve “Collection allows recovery from a mistaken candidate classification” across the handoff.
- [ ] **UC-M07.06-C044-T06 · Absent-input case:** Omit one required “Quarantine phase” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C044-T07 · Stale-input case:** Supply an outdated “Quarantine phase” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Quarantine phase” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C044-T09 · Valid integration trace:** Run a valid “Quarantine phase” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C044-T10 · Seam review:** Reconcile the “Quarantine phase” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for quarantine phase; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Quarantine phase” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C045-T02 · Expected-result oracle:** Specify the “Quarantine phase” expected result independently of the implementation output; include the property “Collection allows recovery from a mistaken candidate classification” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C045-T03 · Fixture material:** Create the concrete “Quarantine phase” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C045-T04 · Target preparation:** Prepare the “Quarantine phase” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C045-T05 · Initial-state record:** Record the initial “Quarantine phase” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C045-T06 · Valid-path execution:** Execute the “Quarantine phase” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C045-T07 · Outcome comparison:** Compare every declared “Quarantine phase” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C045-T08 · State and bounds check:** Inspect the “Quarantine phase” ownership/state effects and actual use of “Quarantine bytes and retention interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C045-T09 · Repeatability check:** Repeat the same “Quarantine phase” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C045-T10 · Positive evidence:** Attach the “Quarantine phase” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C046 · Negative test

**Original checklist item:** Negative case: A newly needed object is removed immediately without quarantine. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Quarantine phase” source counterexample: “A newly needed object is removed immediately without quarantine”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Quarantine phase”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C046-T03 · Valid control:** Construct a valid “Quarantine phase” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C046-T04 · Minimal adverse input:** Derive the “Quarantine phase” adverse fixture from the control with the smallest documented change needed to reproduce “A newly needed object is removed immediately without quarantine”; retain that change as reproducible data.
- [ ] **UC-M07.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Quarantine phase”; require “Collection allows recovery from a mistaken candidate classification” and forbid a false-success verdict.
- [ ] **UC-M07.06-C046-T06 · Adverse execution:** Exercise the “Quarantine phase” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C046-T07 · Effect inspection:** Inspect “Quarantine phase” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C046-T08 · Refusal versus failure:** Confirm the “Quarantine phase” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C046-T09 · Reset and retention:** Restore only the disposable “Quarantine phase” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C046-T10 · Negative regression:** Register the “Quarantine phase” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C047 · Change / failure test

**Original checklist item:** Exercise quarantine phase when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C047-T01 · Scenario record:** Write the “Quarantine phase” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Collection allows recovery from a mistaken candidate classification”.
- [ ] **UC-M07.06-C047-T02 · Baseline capture:** Create a known-valid “Quarantine phase” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C047-T03 · Injection map:** Locate the “Quarantine phase” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Quarantine phase” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C047-T05 · Controlled trigger:** Introduce the controlled “Quarantine phase” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C047-T06 · Intermediate inspection:** Inspect the “Quarantine phase” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Quarantine phase”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Quarantine phase” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C047-T09 · Repeat and compare:** Repeat the selected “Quarantine phase” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C047-T10 · Failure evidence:** Publish the “Quarantine phase” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for quarantine bytes and retention interval; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Quarantine phase”: “Quarantine bytes and retention interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C048-T02 · Measurement method:** Choose how to observe each “Quarantine phase” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C048-T03 · Budget decision:** Select justified resource and input limits for “Quarantine phase”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Quarantine phase” cases for “Quarantine bytes and retention interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Quarantine phase” limit; preserve “Collection allows recovery from a mistaken candidate classification”.
- [ ] **UC-M07.06-C048-T06 · Normal measurement:** Run or review the normal “Quarantine phase” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C048-T07 · At-limit measurement:** Exercise the “Quarantine phase” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C048-T08 · Over-limit measurement:** Exercise the “Quarantine phase” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C048-T09 · Uncovered-scope report:** List the “Quarantine phase” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C048-T10 · Limit evidence:** Publish the selected “Quarantine phase” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for quarantine phase with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C049-T01 · Event inventory:** List the “Quarantine phase” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Quarantine phase” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C049-T03 · Failure mapping:** Map each documented “Quarantine phase” refusal or error to a diagnostic outcome; include “A newly needed object is removed immediately without quarantine” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C049-T04 · Emission path:** Add the “Quarantine phase” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C049-T05 · Redaction check:** Test “Quarantine phase” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C049-T06 · Output budget:** Set and exercise bounded “Quarantine phase” message size, rate and retention compatible with “Quarantine bytes and retention interval”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C049-T07 · Success/refusal fixtures:** Capture “Quarantine phase” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Quarantine phase” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C049-T09 · Operator review:** Read the “Quarantine phase” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C049-T10 · Diagnostic evidence:** Publish redacted “Quarantine phase” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for quarantine phase; label unexecuted checks as untested.

- [ ] **UC-M07.06-C050-T01 · Evidence inventory:** List the “Quarantine phase” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C050-T02 · Artifact references:** Record the exact “Quarantine phase” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C050-T03 · Fixture references:** Attach the “Quarantine phase” fixture IDs, input identities and oracle definition; preserve the source counterexample “A newly needed object is removed immediately without quarantine” as a distinct evidence case.
- [ ] **UC-M07.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Quarantine phase”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C050-T05 · Environment record:** Record the actual “Quarantine phase” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C050-T06 · Expected versus observed:** Pair every “Quarantine phase” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C050-T07 · Failure and limit records:** Attach “Quarantine phase” change/failure and bounds evidence where required; include uncovered “Quarantine bytes and retention interval” and unresolved violations of “Collection allows recovery from a mistaken candidate classification”.
- [ ] **UC-M07.06-C050-T08 · Evidence hygiene:** Check the “Quarantine phase” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C050-T09 · Reproduction review:** Have the “Quarantine phase” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C050-T10 · Acceptance linkage:** Link the “Quarantine phase” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Revalidation before deletion

**Source delivery:** Recheck candidate reachability and ownership before irreversible deletion.

**Source invariant:** A newly referenced quarantined object is not deleted.

**Source negative case:** Deployment references an object between scan and deletion.

**Source bounded quantities:** Recheck cost and batch size.

### UC-M07.06-C051 · Contract

**Original checklist item:** Specify revalidation before deletion inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C051-T01 · Scope statement:** Draft the operation boundary for “Revalidation before deletion” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Revalidation before deletion”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C051-T03 · Output inventory:** List the outputs of “Revalidation before deletion” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Revalidation before deletion”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C051-T05 · Prerequisite contract:** Map “Revalidation before deletion” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Revalidation before deletion”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C051-T07 · Invariant clause:** Add a normative clause for “Revalidation before deletion” that preserves “A newly referenced quarantined object is not deleted”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Revalidation before deletion”; include the source counterexample “Deployment references an object between scan and deletion” and the intended safe disposition.
- [ ] **UC-M07.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recheck cost and batch size” in the “Revalidation before deletion” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C051-T10 · Contract review:** Review the “Revalidation before deletion” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C052 · Delivery

**Original checklist item:** Recheck candidate reachability and ownership before irreversible deletion.

- [ ] **UC-M07.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Revalidation before deletion”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C052-T02 · Change plan:** Break the source delivery for “Revalidation before deletion” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Revalidation before deletion” that realizes this source instruction: Recheck candidate reachability and ownership before irreversible deletion.
- [ ] **UC-M07.06-C052-T04 · Concrete realization:** Trace “Revalidation before deletion” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Revalidation before deletion” needed to preserve “A newly referenced quarantined object is not deleted”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C052-T06 · Dependency connection:** Connect the “Revalidation before deletion” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C052-T07 · Resource behavior:** Account for “Recheck cost and batch size” in “Revalidation before deletion”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C052-T08 · Delivery check:** Run the smallest real “Revalidation before deletion” path and its adverse fixture “Deployment references an object between scan and deletion”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C052-T09 · Patch review:** Review the “Revalidation before deletion” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C052-T10 · Delivery handoff:** Publish the “Revalidation before deletion” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A newly referenced quarantined object is not deleted. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Revalidation before deletion”; copy its required invariant exactly: “A newly referenced quarantined object is not deleted”.
- [ ] **UC-M07.06-C053-T02 · Observable terms:** Define each term in the “Revalidation before deletion” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C053-T03 · Precondition set:** List the preconditions under which “A newly referenced quarantined object is not deleted” must hold for “Revalidation before deletion”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C053-T04 · Transition coverage:** Map the “Revalidation before deletion” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Revalidation before deletion”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C053-T06 · Satisfying fixture:** Create a concrete “Revalidation before deletion” case that satisfies “A newly referenced quarantined object is not deleted”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C053-T07 · Violating fixture:** Create the source counterexample “Deployment references an object between scan and deletion” for “Revalidation before deletion”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C053-T08 · Enforcement evidence:** Exercise the “Revalidation before deletion” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C053-T09 · Regression linkage:** Link the “Revalidation before deletion” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Revalidation before deletion” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C054 · Integration

**Original checklist item:** Integrate revalidation before deletion with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Revalidation before deletion” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C054-T02 · Field mapping:** Map every “Revalidation before deletion” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Revalidation before deletion” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C054-T04 · Ownership agreement:** Specify who owns “Revalidation before deletion” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C054-T05 · Handoff implementation:** Connect “Revalidation before deletion” through the mapped seam using the real adapter or explicit specification reference; preserve “A newly referenced quarantined object is not deleted” across the handoff.
- [ ] **UC-M07.06-C054-T06 · Absent-input case:** Omit one required “Revalidation before deletion” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C054-T07 · Stale-input case:** Supply an outdated “Revalidation before deletion” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Revalidation before deletion” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C054-T09 · Valid integration trace:** Run a valid “Revalidation before deletion” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C054-T10 · Seam review:** Reconcile the “Revalidation before deletion” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for revalidation before deletion; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Revalidation before deletion” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C055-T02 · Expected-result oracle:** Specify the “Revalidation before deletion” expected result independently of the implementation output; include the property “A newly referenced quarantined object is not deleted” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C055-T03 · Fixture material:** Create the concrete “Revalidation before deletion” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C055-T04 · Target preparation:** Prepare the “Revalidation before deletion” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C055-T05 · Initial-state record:** Record the initial “Revalidation before deletion” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C055-T06 · Valid-path execution:** Execute the “Revalidation before deletion” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C055-T07 · Outcome comparison:** Compare every declared “Revalidation before deletion” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C055-T08 · State and bounds check:** Inspect the “Revalidation before deletion” ownership/state effects and actual use of “Recheck cost and batch size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C055-T09 · Repeatability check:** Repeat the same “Revalidation before deletion” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C055-T10 · Positive evidence:** Attach the “Revalidation before deletion” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C056 · Negative test

**Original checklist item:** Negative case: Deployment references an object between scan and deletion. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Revalidation before deletion” source counterexample: “Deployment references an object between scan and deletion”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Revalidation before deletion”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C056-T03 · Valid control:** Construct a valid “Revalidation before deletion” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C056-T04 · Minimal adverse input:** Derive the “Revalidation before deletion” adverse fixture from the control with the smallest documented change needed to reproduce “Deployment references an object between scan and deletion”; retain that change as reproducible data.
- [ ] **UC-M07.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Revalidation before deletion”; require “A newly referenced quarantined object is not deleted” and forbid a false-success verdict.
- [ ] **UC-M07.06-C056-T06 · Adverse execution:** Exercise the “Revalidation before deletion” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C056-T07 · Effect inspection:** Inspect “Revalidation before deletion” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C056-T08 · Refusal versus failure:** Confirm the “Revalidation before deletion” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C056-T09 · Reset and retention:** Restore only the disposable “Revalidation before deletion” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C056-T10 · Negative regression:** Register the “Revalidation before deletion” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C057 · Change / failure test

**Original checklist item:** Exercise revalidation before deletion when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C057-T01 · Scenario record:** Write the “Revalidation before deletion” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “A newly referenced quarantined object is not deleted”.
- [ ] **UC-M07.06-C057-T02 · Baseline capture:** Create a known-valid “Revalidation before deletion” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C057-T03 · Injection map:** Locate the “Revalidation before deletion” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Revalidation before deletion” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C057-T05 · Controlled trigger:** Introduce the controlled “Revalidation before deletion” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C057-T06 · Intermediate inspection:** Inspect the “Revalidation before deletion” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Revalidation before deletion”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Revalidation before deletion” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C057-T09 · Repeat and compare:** Repeat the selected “Revalidation before deletion” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C057-T10 · Failure evidence:** Publish the “Revalidation before deletion” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for recheck cost and batch size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Revalidation before deletion”: “Recheck cost and batch size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C058-T02 · Measurement method:** Choose how to observe each “Revalidation before deletion” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C058-T03 · Budget decision:** Select justified resource and input limits for “Revalidation before deletion”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Revalidation before deletion” cases for “Recheck cost and batch size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Revalidation before deletion” limit; preserve “A newly referenced quarantined object is not deleted”.
- [ ] **UC-M07.06-C058-T06 · Normal measurement:** Run or review the normal “Revalidation before deletion” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C058-T07 · At-limit measurement:** Exercise the “Revalidation before deletion” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C058-T08 · Over-limit measurement:** Exercise the “Revalidation before deletion” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C058-T09 · Uncovered-scope report:** List the “Revalidation before deletion” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C058-T10 · Limit evidence:** Publish the selected “Revalidation before deletion” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for revalidation before deletion with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C059-T01 · Event inventory:** List the “Revalidation before deletion” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Revalidation before deletion” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C059-T03 · Failure mapping:** Map each documented “Revalidation before deletion” refusal or error to a diagnostic outcome; include “Deployment references an object between scan and deletion” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C059-T04 · Emission path:** Add the “Revalidation before deletion” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C059-T05 · Redaction check:** Test “Revalidation before deletion” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C059-T06 · Output budget:** Set and exercise bounded “Revalidation before deletion” message size, rate and retention compatible with “Recheck cost and batch size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C059-T07 · Success/refusal fixtures:** Capture “Revalidation before deletion” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Revalidation before deletion” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C059-T09 · Operator review:** Read the “Revalidation before deletion” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C059-T10 · Diagnostic evidence:** Publish redacted “Revalidation before deletion” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for revalidation before deletion; label unexecuted checks as untested.

- [ ] **UC-M07.06-C060-T01 · Evidence inventory:** List the “Revalidation before deletion” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C060-T02 · Artifact references:** Record the exact “Revalidation before deletion” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C060-T03 · Fixture references:** Attach the “Revalidation before deletion” fixture IDs, input identities and oracle definition; preserve the source counterexample “Deployment references an object between scan and deletion” as a distinct evidence case.
- [ ] **UC-M07.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Revalidation before deletion”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C060-T05 · Environment record:** Record the actual “Revalidation before deletion” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C060-T06 · Expected versus observed:** Pair every “Revalidation before deletion” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C060-T07 · Failure and limit records:** Attach “Revalidation before deletion” change/failure and bounds evidence where required; include uncovered “Recheck cost and batch size” and unresolved violations of “A newly referenced quarantined object is not deleted”.
- [ ] **UC-M07.06-C060-T08 · Evidence hygiene:** Check the “Revalidation before deletion” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C060-T09 · Reproduction review:** Have the “Revalidation before deletion” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C060-T10 · Acceptance linkage:** Link the “Revalidation before deletion” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Dry-run report

**Source delivery:** Report exact candidate identities and reclaimable bytes without mutation.

**Source invariant:** Dry-run results correspond to the actual selected collection policy.

**Source negative case:** A dry run understates dependencies and overstates reclaimable bytes.

**Source bounded quantities:** Report rows and total diagnostic bytes.

### UC-M07.06-C061 · Contract

**Original checklist item:** Specify dry-run report inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C061-T01 · Scope statement:** Draft the operation boundary for “Dry-run report” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Dry-run report”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C061-T03 · Output inventory:** List the outputs of “Dry-run report” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Dry-run report”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C061-T05 · Prerequisite contract:** Map “Dry-run report” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Dry-run report”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C061-T07 · Invariant clause:** Add a normative clause for “Dry-run report” that preserves “Dry-run results correspond to the actual selected collection policy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Dry-run report”; include the source counterexample “A dry run understates dependencies and overstates reclaimable bytes” and the intended safe disposition.
- [ ] **UC-M07.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Report rows and total diagnostic bytes” in the “Dry-run report” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C061-T10 · Contract review:** Review the “Dry-run report” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C062 · Delivery

**Original checklist item:** Report exact candidate identities and reclaimable bytes without mutation.

- [ ] **UC-M07.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Dry-run report”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C062-T02 · Change plan:** Break the source delivery for “Dry-run report” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C062-T03 · Core artifact:** Create the “Dry-run report” output artifact for this source instruction: Report exact candidate identities and reclaimable bytes without mutation.
- [ ] **UC-M07.06-C062-T04 · Concrete realization:** Populate the “Dry-run report” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M07.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Dry-run report” needed to preserve “Dry-run results correspond to the actual selected collection policy”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C062-T06 · Dependency connection:** Connect the “Dry-run report” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C062-T07 · Resource behavior:** Account for “Report rows and total diagnostic bytes” in “Dry-run report”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C062-T08 · Delivery check:** Run the smallest real “Dry-run report” path and its adverse fixture “A dry run understates dependencies and overstates reclaimable bytes”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C062-T09 · Patch review:** Review the “Dry-run report” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C062-T10 · Delivery handoff:** Publish the “Dry-run report” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Dry-run results correspond to the actual selected collection policy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Dry-run report”; copy its required invariant exactly: “Dry-run results correspond to the actual selected collection policy”.
- [ ] **UC-M07.06-C063-T02 · Observable terms:** Define each term in the “Dry-run report” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C063-T03 · Precondition set:** List the preconditions under which “Dry-run results correspond to the actual selected collection policy” must hold for “Dry-run report”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C063-T04 · Transition coverage:** Map the “Dry-run report” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Dry-run report”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C063-T06 · Satisfying fixture:** Create a concrete “Dry-run report” case that satisfies “Dry-run results correspond to the actual selected collection policy”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C063-T07 · Violating fixture:** Create the source counterexample “A dry run understates dependencies and overstates reclaimable bytes” for “Dry-run report”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C063-T08 · Enforcement evidence:** Exercise the “Dry-run report” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C063-T09 · Regression linkage:** Link the “Dry-run report” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Dry-run report” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C064 · Integration

**Original checklist item:** Integrate dry-run report with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Dry-run report” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C064-T02 · Field mapping:** Map every “Dry-run report” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Dry-run report” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C064-T04 · Ownership agreement:** Specify who owns “Dry-run report” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C064-T05 · Handoff implementation:** Connect “Dry-run report” through the mapped seam using the real adapter or explicit specification reference; preserve “Dry-run results correspond to the actual selected collection policy” across the handoff.
- [ ] **UC-M07.06-C064-T06 · Absent-input case:** Omit one required “Dry-run report” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C064-T07 · Stale-input case:** Supply an outdated “Dry-run report” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Dry-run report” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C064-T09 · Valid integration trace:** Run a valid “Dry-run report” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C064-T10 · Seam review:** Reconcile the “Dry-run report” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for dry-run report; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Dry-run report” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C065-T02 · Expected-result oracle:** Specify the “Dry-run report” expected result independently of the implementation output; include the property “Dry-run results correspond to the actual selected collection policy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C065-T03 · Fixture material:** Create the concrete “Dry-run report” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C065-T04 · Target preparation:** Prepare the “Dry-run report” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C065-T05 · Initial-state record:** Record the initial “Dry-run report” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C065-T06 · Valid-path execution:** Execute the “Dry-run report” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C065-T07 · Outcome comparison:** Compare every declared “Dry-run report” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C065-T08 · State and bounds check:** Inspect the “Dry-run report” ownership/state effects and actual use of “Report rows and total diagnostic bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C065-T09 · Repeatability check:** Repeat the same “Dry-run report” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C065-T10 · Positive evidence:** Attach the “Dry-run report” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C066 · Negative test

**Original checklist item:** Negative case: A dry run understates dependencies and overstates reclaimable bytes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Dry-run report” source counterexample: “A dry run understates dependencies and overstates reclaimable bytes”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Dry-run report”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C066-T03 · Valid control:** Construct a valid “Dry-run report” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C066-T04 · Minimal adverse input:** Derive the “Dry-run report” adverse fixture from the control with the smallest documented change needed to reproduce “A dry run understates dependencies and overstates reclaimable bytes”; retain that change as reproducible data.
- [ ] **UC-M07.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Dry-run report”; require “Dry-run results correspond to the actual selected collection policy” and forbid a false-success verdict.
- [ ] **UC-M07.06-C066-T06 · Adverse execution:** Exercise the “Dry-run report” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C066-T07 · Effect inspection:** Inspect “Dry-run report” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C066-T08 · Refusal versus failure:** Confirm the “Dry-run report” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C066-T09 · Reset and retention:** Restore only the disposable “Dry-run report” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C066-T10 · Negative regression:** Register the “Dry-run report” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C067 · Change / failure test

**Original checklist item:** Exercise dry-run report when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C067-T01 · Scenario record:** Write the “Dry-run report” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Dry-run results correspond to the actual selected collection policy”.
- [ ] **UC-M07.06-C067-T02 · Baseline capture:** Create a known-valid “Dry-run report” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C067-T03 · Injection map:** Locate the “Dry-run report” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Dry-run report” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C067-T05 · Controlled trigger:** Introduce the controlled “Dry-run report” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C067-T06 · Intermediate inspection:** Inspect the “Dry-run report” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Dry-run report”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Dry-run report” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C067-T09 · Repeat and compare:** Repeat the selected “Dry-run report” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C067-T10 · Failure evidence:** Publish the “Dry-run report” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for report rows and total diagnostic bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Dry-run report”: “Report rows and total diagnostic bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C068-T02 · Measurement method:** Choose how to observe each “Dry-run report” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Dry-run report”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Dry-run report” cases for “Report rows and total diagnostic bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Dry-run report” limit; preserve “Dry-run results correspond to the actual selected collection policy”.
- [ ] **UC-M07.06-C068-T06 · Normal measurement:** Run or review the normal “Dry-run report” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C068-T07 · At-limit measurement:** Exercise the “Dry-run report” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C068-T08 · Over-limit measurement:** Exercise the “Dry-run report” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C068-T09 · Uncovered-scope report:** List the “Dry-run report” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C068-T10 · Limit evidence:** Publish the selected “Dry-run report” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for dry-run report with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C069-T01 · Event inventory:** List the “Dry-run report” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Dry-run report” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C069-T03 · Failure mapping:** Map each documented “Dry-run report” refusal or error to a diagnostic outcome; include “A dry run understates dependencies and overstates reclaimable bytes” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C069-T04 · Emission path:** Add the “Dry-run report” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C069-T05 · Redaction check:** Test “Dry-run report” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C069-T06 · Output budget:** Set and exercise bounded “Dry-run report” message size, rate and retention compatible with “Report rows and total diagnostic bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C069-T07 · Success/refusal fixtures:** Capture “Dry-run report” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Dry-run report” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C069-T09 · Operator review:** Read the “Dry-run report” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C069-T10 · Diagnostic evidence:** Publish redacted “Dry-run report” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for dry-run report; label unexecuted checks as untested.

- [ ] **UC-M07.06-C070-T01 · Evidence inventory:** List the “Dry-run report” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C070-T02 · Artifact references:** Record the exact “Dry-run report” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C070-T03 · Fixture references:** Attach the “Dry-run report” fixture IDs, input identities and oracle definition; preserve the source counterexample “A dry run understates dependencies and overstates reclaimable bytes” as a distinct evidence case.
- [ ] **UC-M07.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Dry-run report”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C070-T05 · Environment record:** Record the actual “Dry-run report” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C070-T06 · Expected versus observed:** Pair every “Dry-run report” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C070-T07 · Failure and limit records:** Attach “Dry-run report” change/failure and bounds evidence where required; include uncovered “Report rows and total diagnostic bytes” and unresolved violations of “Dry-run results correspond to the actual selected collection policy”.
- [ ] **UC-M07.06-C070-T08 · Evidence hygiene:** Check the “Dry-run report” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C070-T09 · Reproduction review:** Have the “Dry-run report” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C070-T10 · Acceptance linkage:** Link the “Dry-run report” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Storage accounting reconciliation

**Source delivery:** Update quota and store accounting after verified deletion.

**Source invariant:** Reclaimed-byte totals reflect actual removal rather than planned deletion.

**Source negative case:** A failed deletion is counted as freed disk space.

**Source bounded quantities:** Accounting records and reconciliation time.

### UC-M07.06-C071 · Contract

**Original checklist item:** Specify storage accounting reconciliation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C071-T01 · Scope statement:** Draft the operation boundary for “Storage accounting reconciliation” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Storage accounting reconciliation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C071-T03 · Output inventory:** List the outputs of “Storage accounting reconciliation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Storage accounting reconciliation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C071-T05 · Prerequisite contract:** Map “Storage accounting reconciliation” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Storage accounting reconciliation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C071-T07 · Invariant clause:** Add a normative clause for “Storage accounting reconciliation” that preserves “Reclaimed-byte totals reflect actual removal rather than planned deletion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Storage accounting reconciliation”; include the source counterexample “A failed deletion is counted as freed disk space” and the intended safe disposition.
- [ ] **UC-M07.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Accounting records and reconciliation time” in the “Storage accounting reconciliation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C071-T10 · Contract review:** Review the “Storage accounting reconciliation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C072 · Delivery

**Original checklist item:** Update quota and store accounting after verified deletion.

- [ ] **UC-M07.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Storage accounting reconciliation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C072-T02 · Change plan:** Break the source delivery for “Storage accounting reconciliation” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Storage accounting reconciliation” that realizes this source instruction: Update quota and store accounting after verified deletion.
- [ ] **UC-M07.06-C072-T04 · Concrete realization:** Trace “Storage accounting reconciliation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Storage accounting reconciliation” needed to preserve “Reclaimed-byte totals reflect actual removal rather than planned deletion”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C072-T06 · Dependency connection:** Connect the “Storage accounting reconciliation” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C072-T07 · Resource behavior:** Account for “Accounting records and reconciliation time” in “Storage accounting reconciliation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C072-T08 · Delivery check:** Run the smallest real “Storage accounting reconciliation” path and its adverse fixture “A failed deletion is counted as freed disk space”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C072-T09 · Patch review:** Review the “Storage accounting reconciliation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C072-T10 · Delivery handoff:** Publish the “Storage accounting reconciliation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Reclaimed-byte totals reflect actual removal rather than planned deletion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Storage accounting reconciliation”; copy its required invariant exactly: “Reclaimed-byte totals reflect actual removal rather than planned deletion”.
- [ ] **UC-M07.06-C073-T02 · Observable terms:** Define each term in the “Storage accounting reconciliation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C073-T03 · Precondition set:** List the preconditions under which “Reclaimed-byte totals reflect actual removal rather than planned deletion” must hold for “Storage accounting reconciliation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C073-T04 · Transition coverage:** Map the “Storage accounting reconciliation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Storage accounting reconciliation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C073-T06 · Satisfying fixture:** Create a concrete “Storage accounting reconciliation” case that satisfies “Reclaimed-byte totals reflect actual removal rather than planned deletion”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C073-T07 · Violating fixture:** Create the source counterexample “A failed deletion is counted as freed disk space” for “Storage accounting reconciliation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C073-T08 · Enforcement evidence:** Exercise the “Storage accounting reconciliation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C073-T09 · Regression linkage:** Link the “Storage accounting reconciliation” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Storage accounting reconciliation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C074 · Integration

**Original checklist item:** Integrate storage accounting reconciliation with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Storage accounting reconciliation” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C074-T02 · Field mapping:** Map every “Storage accounting reconciliation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Storage accounting reconciliation” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C074-T04 · Ownership agreement:** Specify who owns “Storage accounting reconciliation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C074-T05 · Handoff implementation:** Connect “Storage accounting reconciliation” through the mapped seam using the real adapter or explicit specification reference; preserve “Reclaimed-byte totals reflect actual removal rather than planned deletion” across the handoff.
- [ ] **UC-M07.06-C074-T06 · Absent-input case:** Omit one required “Storage accounting reconciliation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C074-T07 · Stale-input case:** Supply an outdated “Storage accounting reconciliation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Storage accounting reconciliation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C074-T09 · Valid integration trace:** Run a valid “Storage accounting reconciliation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C074-T10 · Seam review:** Reconcile the “Storage accounting reconciliation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for storage accounting reconciliation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Storage accounting reconciliation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C075-T02 · Expected-result oracle:** Specify the “Storage accounting reconciliation” expected result independently of the implementation output; include the property “Reclaimed-byte totals reflect actual removal rather than planned deletion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C075-T03 · Fixture material:** Create the concrete “Storage accounting reconciliation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C075-T04 · Target preparation:** Prepare the “Storage accounting reconciliation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C075-T05 · Initial-state record:** Record the initial “Storage accounting reconciliation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C075-T06 · Valid-path execution:** Execute the “Storage accounting reconciliation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C075-T07 · Outcome comparison:** Compare every declared “Storage accounting reconciliation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C075-T08 · State and bounds check:** Inspect the “Storage accounting reconciliation” ownership/state effects and actual use of “Accounting records and reconciliation time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C075-T09 · Repeatability check:** Repeat the same “Storage accounting reconciliation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C075-T10 · Positive evidence:** Attach the “Storage accounting reconciliation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C076 · Negative test

**Original checklist item:** Negative case: A failed deletion is counted as freed disk space. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Storage accounting reconciliation” source counterexample: “A failed deletion is counted as freed disk space”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Storage accounting reconciliation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C076-T03 · Valid control:** Construct a valid “Storage accounting reconciliation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C076-T04 · Minimal adverse input:** Derive the “Storage accounting reconciliation” adverse fixture from the control with the smallest documented change needed to reproduce “A failed deletion is counted as freed disk space”; retain that change as reproducible data.
- [ ] **UC-M07.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Storage accounting reconciliation”; require “Reclaimed-byte totals reflect actual removal rather than planned deletion” and forbid a false-success verdict.
- [ ] **UC-M07.06-C076-T06 · Adverse execution:** Exercise the “Storage accounting reconciliation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C076-T07 · Effect inspection:** Inspect “Storage accounting reconciliation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C076-T08 · Refusal versus failure:** Confirm the “Storage accounting reconciliation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C076-T09 · Reset and retention:** Restore only the disposable “Storage accounting reconciliation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C076-T10 · Negative regression:** Register the “Storage accounting reconciliation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C077 · Change / failure test

**Original checklist item:** Exercise storage accounting reconciliation when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C077-T01 · Scenario record:** Write the “Storage accounting reconciliation” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Reclaimed-byte totals reflect actual removal rather than planned deletion”.
- [ ] **UC-M07.06-C077-T02 · Baseline capture:** Create a known-valid “Storage accounting reconciliation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C077-T03 · Injection map:** Locate the “Storage accounting reconciliation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Storage accounting reconciliation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C077-T05 · Controlled trigger:** Introduce the controlled “Storage accounting reconciliation” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C077-T06 · Intermediate inspection:** Inspect the “Storage accounting reconciliation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Storage accounting reconciliation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Storage accounting reconciliation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C077-T09 · Repeat and compare:** Repeat the selected “Storage accounting reconciliation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C077-T10 · Failure evidence:** Publish the “Storage accounting reconciliation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for accounting records and reconciliation time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Storage accounting reconciliation”: “Accounting records and reconciliation time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C078-T02 · Measurement method:** Choose how to observe each “Storage accounting reconciliation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C078-T03 · Budget decision:** Select justified resource and input limits for “Storage accounting reconciliation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Storage accounting reconciliation” cases for “Accounting records and reconciliation time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Storage accounting reconciliation” limit; preserve “Reclaimed-byte totals reflect actual removal rather than planned deletion”.
- [ ] **UC-M07.06-C078-T06 · Normal measurement:** Run or review the normal “Storage accounting reconciliation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C078-T07 · At-limit measurement:** Exercise the “Storage accounting reconciliation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C078-T08 · Over-limit measurement:** Exercise the “Storage accounting reconciliation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C078-T09 · Uncovered-scope report:** List the “Storage accounting reconciliation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C078-T10 · Limit evidence:** Publish the selected “Storage accounting reconciliation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for storage accounting reconciliation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C079-T01 · Event inventory:** List the “Storage accounting reconciliation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Storage accounting reconciliation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C079-T03 · Failure mapping:** Map each documented “Storage accounting reconciliation” refusal or error to a diagnostic outcome; include “A failed deletion is counted as freed disk space” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C079-T04 · Emission path:** Add the “Storage accounting reconciliation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C079-T05 · Redaction check:** Test “Storage accounting reconciliation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C079-T06 · Output budget:** Set and exercise bounded “Storage accounting reconciliation” message size, rate and retention compatible with “Accounting records and reconciliation time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C079-T07 · Success/refusal fixtures:** Capture “Storage accounting reconciliation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Storage accounting reconciliation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C079-T09 · Operator review:** Read the “Storage accounting reconciliation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C079-T10 · Diagnostic evidence:** Publish redacted “Storage accounting reconciliation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for storage accounting reconciliation; label unexecuted checks as untested.

- [ ] **UC-M07.06-C080-T01 · Evidence inventory:** List the “Storage accounting reconciliation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C080-T02 · Artifact references:** Record the exact “Storage accounting reconciliation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C080-T03 · Fixture references:** Attach the “Storage accounting reconciliation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed deletion is counted as freed disk space” as a distinct evidence case.
- [ ] **UC-M07.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Storage accounting reconciliation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C080-T05 · Environment record:** Record the actual “Storage accounting reconciliation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C080-T06 · Expected versus observed:** Pair every “Storage accounting reconciliation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C080-T07 · Failure and limit records:** Attach “Storage accounting reconciliation” change/failure and bounds evidence where required; include uncovered “Accounting records and reconciliation time” and unresolved violations of “Reclaimed-byte totals reflect actual removal rather than planned deletion”.
- [ ] **UC-M07.06-C080-T08 · Evidence hygiene:** Check the “Storage accounting reconciliation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C080-T09 · Reproduction review:** Have the “Storage accounting reconciliation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C080-T10 · Acceptance linkage:** Link the “Storage accounting reconciliation” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Failed deletion handling

**Source delivery:** Retain clear retryable dispositions for locked, missing or denied objects.

**Source invariant:** Deletion failures do not invalidate still-referenced objects.

**Source negative case:** A permission error causes the collector to skip its ownership checks.

**Source bounded quantities:** Retry count and failure backlog.

### UC-M07.06-C081 · Contract

**Original checklist item:** Specify failed deletion handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C081-T01 · Scope statement:** Draft the operation boundary for “Failed deletion handling” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failed deletion handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C081-T03 · Output inventory:** List the outputs of “Failed deletion handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Failed deletion handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C081-T05 · Prerequisite contract:** Map “Failed deletion handling” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Failed deletion handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C081-T07 · Invariant clause:** Add a normative clause for “Failed deletion handling” that preserves “Deletion failures do not invalidate still-referenced objects”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failed deletion handling”; include the source counterexample “A permission error causes the collector to skip its ownership checks” and the intended safe disposition.
- [ ] **UC-M07.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retry count and failure backlog” in the “Failed deletion handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C081-T10 · Contract review:** Review the “Failed deletion handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C082 · Delivery

**Original checklist item:** Retain clear retryable dispositions for locked, missing or denied objects.

- [ ] **UC-M07.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failed deletion handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C082-T02 · Change plan:** Break the source delivery for “Failed deletion handling” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Failed deletion handling” that realizes this source instruction: Retain clear retryable dispositions for locked, missing or denied objects.
- [ ] **UC-M07.06-C082-T04 · Concrete realization:** Trace “Failed deletion handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failed deletion handling” needed to preserve “Deletion failures do not invalidate still-referenced objects”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C082-T06 · Dependency connection:** Connect the “Failed deletion handling” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C082-T07 · Resource behavior:** Account for “Retry count and failure backlog” in “Failed deletion handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C082-T08 · Delivery check:** Run the smallest real “Failed deletion handling” path and its adverse fixture “A permission error causes the collector to skip its ownership checks”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C082-T09 · Patch review:** Review the “Failed deletion handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C082-T10 · Delivery handoff:** Publish the “Failed deletion handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Deletion failures do not invalidate still-referenced objects. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Failed deletion handling”; copy its required invariant exactly: “Deletion failures do not invalidate still-referenced objects”.
- [ ] **UC-M07.06-C083-T02 · Observable terms:** Define each term in the “Failed deletion handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C083-T03 · Precondition set:** List the preconditions under which “Deletion failures do not invalidate still-referenced objects” must hold for “Failed deletion handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C083-T04 · Transition coverage:** Map the “Failed deletion handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failed deletion handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C083-T06 · Satisfying fixture:** Create a concrete “Failed deletion handling” case that satisfies “Deletion failures do not invalidate still-referenced objects”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C083-T07 · Violating fixture:** Create the source counterexample “A permission error causes the collector to skip its ownership checks” for “Failed deletion handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C083-T08 · Enforcement evidence:** Exercise the “Failed deletion handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C083-T09 · Regression linkage:** Link the “Failed deletion handling” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Failed deletion handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C084 · Integration

**Original checklist item:** Integrate failed deletion handling with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failed deletion handling” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C084-T02 · Field mapping:** Map every “Failed deletion handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Failed deletion handling” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C084-T04 · Ownership agreement:** Specify who owns “Failed deletion handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C084-T05 · Handoff implementation:** Connect “Failed deletion handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Deletion failures do not invalidate still-referenced objects” across the handoff.
- [ ] **UC-M07.06-C084-T06 · Absent-input case:** Omit one required “Failed deletion handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C084-T07 · Stale-input case:** Supply an outdated “Failed deletion handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Failed deletion handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C084-T09 · Valid integration trace:** Run a valid “Failed deletion handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C084-T10 · Seam review:** Reconcile the “Failed deletion handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failed deletion handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failed deletion handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C085-T02 · Expected-result oracle:** Specify the “Failed deletion handling” expected result independently of the implementation output; include the property “Deletion failures do not invalidate still-referenced objects” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C085-T03 · Fixture material:** Create the concrete “Failed deletion handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C085-T04 · Target preparation:** Prepare the “Failed deletion handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C085-T05 · Initial-state record:** Record the initial “Failed deletion handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C085-T06 · Valid-path execution:** Execute the “Failed deletion handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C085-T07 · Outcome comparison:** Compare every declared “Failed deletion handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C085-T08 · State and bounds check:** Inspect the “Failed deletion handling” ownership/state effects and actual use of “Retry count and failure backlog”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C085-T09 · Repeatability check:** Repeat the same “Failed deletion handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C085-T10 · Positive evidence:** Attach the “Failed deletion handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C086 · Negative test

**Original checklist item:** Negative case: A permission error causes the collector to skip its ownership checks. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Failed deletion handling” source counterexample: “A permission error causes the collector to skip its ownership checks”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Failed deletion handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C086-T03 · Valid control:** Construct a valid “Failed deletion handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C086-T04 · Minimal adverse input:** Derive the “Failed deletion handling” adverse fixture from the control with the smallest documented change needed to reproduce “A permission error causes the collector to skip its ownership checks”; retain that change as reproducible data.
- [ ] **UC-M07.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failed deletion handling”; require “Deletion failures do not invalidate still-referenced objects” and forbid a false-success verdict.
- [ ] **UC-M07.06-C086-T06 · Adverse execution:** Exercise the “Failed deletion handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C086-T07 · Effect inspection:** Inspect “Failed deletion handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C086-T08 · Refusal versus failure:** Confirm the “Failed deletion handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C086-T09 · Reset and retention:** Restore only the disposable “Failed deletion handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C086-T10 · Negative regression:** Register the “Failed deletion handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C087 · Change / failure test

**Original checklist item:** Exercise failed deletion handling when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C087-T01 · Scenario record:** Write the “Failed deletion handling” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “Deletion failures do not invalidate still-referenced objects”.
- [ ] **UC-M07.06-C087-T02 · Baseline capture:** Create a known-valid “Failed deletion handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C087-T03 · Injection map:** Locate the “Failed deletion handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Failed deletion handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C087-T05 · Controlled trigger:** Introduce the controlled “Failed deletion handling” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C087-T06 · Intermediate inspection:** Inspect the “Failed deletion handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failed deletion handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Failed deletion handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C087-T09 · Repeat and compare:** Repeat the selected “Failed deletion handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C087-T10 · Failure evidence:** Publish the “Failed deletion handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for retry count and failure backlog; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Failed deletion handling”: “Retry count and failure backlog”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C088-T02 · Measurement method:** Choose how to observe each “Failed deletion handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Failed deletion handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failed deletion handling” cases for “Retry count and failure backlog”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failed deletion handling” limit; preserve “Deletion failures do not invalidate still-referenced objects”.
- [ ] **UC-M07.06-C088-T06 · Normal measurement:** Run or review the normal “Failed deletion handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C088-T07 · At-limit measurement:** Exercise the “Failed deletion handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C088-T08 · Over-limit measurement:** Exercise the “Failed deletion handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C088-T09 · Uncovered-scope report:** List the “Failed deletion handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C088-T10 · Limit evidence:** Publish the selected “Failed deletion handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failed deletion handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C089-T01 · Event inventory:** List the “Failed deletion handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Failed deletion handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C089-T03 · Failure mapping:** Map each documented “Failed deletion handling” refusal or error to a diagnostic outcome; include “A permission error causes the collector to skip its ownership checks” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C089-T04 · Emission path:** Add the “Failed deletion handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C089-T05 · Redaction check:** Test “Failed deletion handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C089-T06 · Output budget:** Set and exercise bounded “Failed deletion handling” message size, rate and retention compatible with “Retry count and failure backlog”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C089-T07 · Success/refusal fixtures:** Capture “Failed deletion handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failed deletion handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C089-T09 · Operator review:** Read the “Failed deletion handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C089-T10 · Diagnostic evidence:** Publish redacted “Failed deletion handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failed deletion handling; label unexecuted checks as untested.

- [ ] **UC-M07.06-C090-T01 · Evidence inventory:** List the “Failed deletion handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C090-T02 · Artifact references:** Record the exact “Failed deletion handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C090-T03 · Fixture references:** Attach the “Failed deletion handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A permission error causes the collector to skip its ownership checks” as a distinct evidence case.
- [ ] **UC-M07.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failed deletion handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C090-T05 · Environment record:** Record the actual “Failed deletion handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C090-T06 · Expected versus observed:** Pair every “Failed deletion handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C090-T07 · Failure and limit records:** Attach “Failed deletion handling” change/failure and bounds evidence where required; include uncovered “Retry count and failure backlog” and unresolved violations of “Deletion failures do not invalidate still-referenced objects”.
- [ ] **UC-M07.06-C090-T08 · Evidence hygiene:** Check the “Failed deletion handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C090-T09 · Reproduction review:** Have the “Failed deletion handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C090-T10 · Acceptance linkage:** Link the “Failed deletion handling” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Concurrent GC qualification

**Source delivery:** Test collection while deploying and restoring retained snapshots.

**Source invariant:** No referenced object is lost and dry-run totals are reproducible.

**Source negative case:** A concurrent restore fails because GC removed its image.

**Source bounded quantities:** Object population and concurrent operation count.

### UC-M07.06-C091 · Contract

**Original checklist item:** Specify concurrent GC qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.06-C091-T01 · Scope statement:** Draft the operation boundary for “Concurrent GC qualification” within Reachability-based garbage collection; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Concurrent GC qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.06-C091-T03 · Output inventory:** List the outputs of “Concurrent GC qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Concurrent GC qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.06-C091-T05 · Prerequisite contract:** Map “Concurrent GC qualification” to the source component prerequisites (UC-M04.05, UC-M07.01, UC-M07.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Concurrent GC qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.06-C091-T07 · Invariant clause:** Add a normative clause for “Concurrent GC qualification” that preserves “No referenced object is lost and dry-run totals are reproducible”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Concurrent GC qualification”; include the source counterexample “A concurrent restore fails because GC removed its image” and the intended safe disposition.
- [ ] **UC-M07.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Object population and concurrent operation count” in the “Concurrent GC qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.06-C091-T10 · Contract review:** Review the “Concurrent GC qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.06-C092 · Delivery

**Original checklist item:** Test collection while deploying and restoring retained snapshots.

- [ ] **UC-M07.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Concurrent GC qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.06-C092-T02 · Change plan:** Break the source delivery for “Concurrent GC qualification” into concrete edit targets and reviewable outputs; keep the UC-M07.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.06-C092-T03 · Core artifact:** Create the “Concurrent GC qualification” fixture or harness for this source instruction: Test collection while deploying and restoring retained snapshots.
- [ ] **UC-M07.06-C092-T04 · Concrete realization:** Connect the “Concurrent GC qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Concurrent GC qualification” needed to preserve “No referenced object is lost and dry-run totals are reproducible”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.06-C092-T06 · Dependency connection:** Connect the “Concurrent GC qualification” implementation to active-generation roots, snapshot references and concurrent object publication; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.06-C092-T07 · Resource behavior:** Account for “Object population and concurrent operation count” in “Concurrent GC qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.06-C092-T08 · Delivery check:** Run the smallest real “Concurrent GC qualification” path and its adverse fixture “A concurrent restore fails because GC removed its image”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.06-C092-T09 · Patch review:** Review the “Concurrent GC qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.06-C092-T10 · Delivery handoff:** Publish the “Concurrent GC qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No referenced object is lost and dry-run totals are reproducible. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Concurrent GC qualification”; copy its required invariant exactly: “No referenced object is lost and dry-run totals are reproducible”.
- [ ] **UC-M07.06-C093-T02 · Observable terms:** Define each term in the “Concurrent GC qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.06-C093-T03 · Precondition set:** List the preconditions under which “No referenced object is lost and dry-run totals are reproducible” must hold for “Concurrent GC qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.06-C093-T04 · Transition coverage:** Map the “Concurrent GC qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Concurrent GC qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.06-C093-T06 · Satisfying fixture:** Create a concrete “Concurrent GC qualification” case that satisfies “No referenced object is lost and dry-run totals are reproducible”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.06-C093-T07 · Violating fixture:** Create the source counterexample “A concurrent restore fails because GC removed its image” for “Concurrent GC qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.06-C093-T08 · Enforcement evidence:** Exercise the “Concurrent GC qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.06-C093-T09 · Regression linkage:** Link the “Concurrent GC qualification” property to changes in active-generation roots, snapshot references and concurrent object publication; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Concurrent GC qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.06-C094 · Integration

**Original checklist item:** Integrate concurrent GC qualification with active-generation roots, snapshot references and concurrent object publication; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Concurrent GC qualification” across active-generation roots, snapshot references and concurrent object publication; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.06-C094-T02 · Field mapping:** Map every “Concurrent GC qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Concurrent GC qualification” (source dependency list: UC-M04.05, UC-M07.01, UC-M07.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.06-C094-T04 · Ownership agreement:** Specify who owns “Concurrent GC qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.06-C094-T05 · Handoff implementation:** Connect “Concurrent GC qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “No referenced object is lost and dry-run totals are reproducible” across the handoff.
- [ ] **UC-M07.06-C094-T06 · Absent-input case:** Omit one required “Concurrent GC qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.06-C094-T07 · Stale-input case:** Supply an outdated “Concurrent GC qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Concurrent GC qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.06-C094-T09 · Valid integration trace:** Run a valid “Concurrent GC qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.06-C094-T10 · Seam review:** Reconcile the “Concurrent GC qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for concurrent GC qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Concurrent GC qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.06-C095-T02 · Expected-result oracle:** Specify the “Concurrent GC qualification” expected result independently of the implementation output; include the property “No referenced object is lost and dry-run totals are reproducible” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.06-C095-T03 · Fixture material:** Create the concrete “Concurrent GC qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.06-C095-T04 · Target preparation:** Prepare the “Concurrent GC qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.06-C095-T05 · Initial-state record:** Record the initial “Concurrent GC qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.06-C095-T06 · Valid-path execution:** Execute the “Concurrent GC qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.06-C095-T07 · Outcome comparison:** Compare every declared “Concurrent GC qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.06-C095-T08 · State and bounds check:** Inspect the “Concurrent GC qualification” ownership/state effects and actual use of “Object population and concurrent operation count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.06-C095-T09 · Repeatability check:** Repeat the same “Concurrent GC qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.06-C095-T10 · Positive evidence:** Attach the “Concurrent GC qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.06-C096 · Negative test

**Original checklist item:** Negative case: A concurrent restore fails because GC removed its image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Concurrent GC qualification” source counterexample: “A concurrent restore fails because GC removed its image”; state which precondition or invariant it challenges.
- [ ] **UC-M07.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Concurrent GC qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.06-C096-T03 · Valid control:** Construct a valid “Concurrent GC qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.06-C096-T04 · Minimal adverse input:** Derive the “Concurrent GC qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A concurrent restore fails because GC removed its image”; retain that change as reproducible data.
- [ ] **UC-M07.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Concurrent GC qualification”; require “No referenced object is lost and dry-run totals are reproducible” and forbid a false-success verdict.
- [ ] **UC-M07.06-C096-T06 · Adverse execution:** Exercise the “Concurrent GC qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.06-C096-T07 · Effect inspection:** Inspect “Concurrent GC qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.06-C096-T08 · Refusal versus failure:** Confirm the “Concurrent GC qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.06-C096-T09 · Reset and retention:** Restore only the disposable “Concurrent GC qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.06-C096-T10 · Negative regression:** Register the “Concurrent GC qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.06-C097 · Change / failure test

**Original checklist item:** Exercise concurrent GC qualification when a deployment or restore references an object during collection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.06-C097-T01 · Scenario record:** Write the “Concurrent GC qualification” change/failure scenario exactly as supplied: a deployment or restore references an object during collection; identify the property that must remain true: “No referenced object is lost and dry-run totals are reproducible”.
- [ ] **UC-M07.06-C097-T02 · Baseline capture:** Create a known-valid “Concurrent GC qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.06-C097-T03 · Injection map:** Locate the “Concurrent GC qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Concurrent GC qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.06-C097-T05 · Controlled trigger:** Introduce the controlled “Concurrent GC qualification” scenario in the disposable fixture: a deployment or restore references an object during collection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.06-C097-T06 · Intermediate inspection:** Inspect the “Concurrent GC qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Concurrent GC qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Concurrent GC qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.06-C097-T09 · Repeat and compare:** Repeat the selected “Concurrent GC qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.06-C097-T10 · Failure evidence:** Publish the “Concurrent GC qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for object population and concurrent operation count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Concurrent GC qualification”: “Object population and concurrent operation count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.06-C098-T02 · Measurement method:** Choose how to observe each “Concurrent GC qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Concurrent GC qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Concurrent GC qualification” cases for “Object population and concurrent operation count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Concurrent GC qualification” limit; preserve “No referenced object is lost and dry-run totals are reproducible”.
- [ ] **UC-M07.06-C098-T06 · Normal measurement:** Run or review the normal “Concurrent GC qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.06-C098-T07 · At-limit measurement:** Exercise the “Concurrent GC qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.06-C098-T08 · Over-limit measurement:** Exercise the “Concurrent GC qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.06-C098-T09 · Uncovered-scope report:** List the “Concurrent GC qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.06-C098-T10 · Limit evidence:** Publish the selected “Concurrent GC qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for concurrent GC qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.06-C099-T01 · Event inventory:** List the “Concurrent GC qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Concurrent GC qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.06-C099-T03 · Failure mapping:** Map each documented “Concurrent GC qualification” refusal or error to a diagnostic outcome; include “A concurrent restore fails because GC removed its image” and prohibit conversion into a success message.
- [ ] **UC-M07.06-C099-T04 · Emission path:** Add the “Concurrent GC qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.06-C099-T05 · Redaction check:** Test “Concurrent GC qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.06-C099-T06 · Output budget:** Set and exercise bounded “Concurrent GC qualification” message size, rate and retention compatible with “Object population and concurrent operation count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.06-C099-T07 · Success/refusal fixtures:** Capture “Concurrent GC qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Concurrent GC qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.06-C099-T09 · Operator review:** Read the “Concurrent GC qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.06-C099-T10 · Diagnostic evidence:** Publish redacted “Concurrent GC qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for concurrent GC qualification; label unexecuted checks as untested.

- [ ] **UC-M07.06-C100-T01 · Evidence inventory:** List the “Concurrent GC qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.06-C100-T02 · Artifact references:** Record the exact “Concurrent GC qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.06-C100-T03 · Fixture references:** Attach the “Concurrent GC qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A concurrent restore fails because GC removed its image” as a distinct evidence case.
- [ ] **UC-M07.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Concurrent GC qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.06-C100-T05 · Environment record:** Record the actual “Concurrent GC qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.06-C100-T06 · Expected versus observed:** Pair every “Concurrent GC qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.06-C100-T07 · Failure and limit records:** Attach “Concurrent GC qualification” change/failure and bounds evidence where required; include uncovered “Object population and concurrent operation count” and unresolved violations of “No referenced object is lost and dry-run totals are reproducible”.
- [ ] **UC-M07.06-C100-T08 · Evidence hygiene:** Check the “Concurrent GC qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.06-C100-T09 · Reproduction review:** Have the “Concurrent GC qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.06-C100-T10 · Acceptance linkage:** Link the “Concurrent GC qualification” evidence to its parent and UC-M07.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

