# UC-M07.01 — Cross-resource durable transaction coordinator

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/07.md)

| Field | Preserved source value |
|---|---|
| Workstream | 07. Persistence, transactions and recovery |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.03](../01/UC-M01.03.md), [UC-M01.05](../01/UC-M01.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S8]. |

## Original requirement

Extend staging/journals to berth, bill of lading, ship seals, hull mounts and runtime state with explicit commit/recovery semantics.

**Original acceptance criterion:** Crash injection at every mutation step recovers a coherent old or new generation with no missing cargo.

**Source trace:** Original checklist `UC100/c/07/UC-M07.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 619–629 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Transaction participant inventory

**Source delivery:** Include berth contents, bill of lading, ship seals, hull mounts and runtime state as explicit participants.

**Source invariant:** A successful transaction accounts for every affected resource.

**Source negative case:** Berth replacement commits while the hull still references the old state.

**Source bounded quantities:** Participant count and transaction metadata bytes.

### UC-M07.01-C001 · Contract

**Original checklist item:** Specify transaction participant inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C001-T01 · Scope statement:** Draft the operation boundary for “Transaction participant inventory” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Transaction participant inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C001-T03 · Output inventory:** List the outputs of “Transaction participant inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Transaction participant inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C001-T05 · Prerequisite contract:** Map “Transaction participant inventory” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Transaction participant inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C001-T07 · Invariant clause:** Add a normative clause for “Transaction participant inventory” that preserves “A successful transaction accounts for every affected resource”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Transaction participant inventory”; include the source counterexample “Berth replacement commits while the hull still references the old state” and the intended safe disposition.
- [ ] **UC-M07.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Participant count and transaction metadata bytes” in the “Transaction participant inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C001-T10 · Contract review:** Review the “Transaction participant inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C002 · Delivery

**Original checklist item:** Include berth contents, bill of lading, ship seals, hull mounts and runtime state as explicit participants.

- [ ] **UC-M07.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Transaction participant inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C002-T02 · Change plan:** Break the source delivery for “Transaction participant inventory” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Transaction participant inventory” that realizes this source instruction: Include berth contents, bill of lading, ship seals, hull mounts and runtime state as explicit participants.
- [ ] **UC-M07.01-C002-T04 · Concrete realization:** Trace “Transaction participant inventory” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Transaction participant inventory” needed to preserve “A successful transaction accounts for every affected resource”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C002-T06 · Dependency connection:** Connect the “Transaction participant inventory” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C002-T07 · Resource behavior:** Account for “Participant count and transaction metadata bytes” in “Transaction participant inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C002-T08 · Delivery check:** Run the smallest real “Transaction participant inventory” path and its adverse fixture “Berth replacement commits while the hull still references the old state”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C002-T09 · Patch review:** Review the “Transaction participant inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C002-T10 · Delivery handoff:** Publish the “Transaction participant inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A successful transaction accounts for every affected resource. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Transaction participant inventory”; copy its required invariant exactly: “A successful transaction accounts for every affected resource”.
- [ ] **UC-M07.01-C003-T02 · Observable terms:** Define each term in the “Transaction participant inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C003-T03 · Precondition set:** List the preconditions under which “A successful transaction accounts for every affected resource” must hold for “Transaction participant inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C003-T04 · Transition coverage:** Map the “Transaction participant inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Transaction participant inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C003-T06 · Satisfying fixture:** Create a concrete “Transaction participant inventory” case that satisfies “A successful transaction accounts for every affected resource”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C003-T07 · Violating fixture:** Create the source counterexample “Berth replacement commits while the hull still references the old state” for “Transaction participant inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C003-T08 · Enforcement evidence:** Exercise the “Transaction participant inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C003-T09 · Regression linkage:** Link the “Transaction participant inventory” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Transaction participant inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C004 · Integration

**Original checklist item:** Integrate transaction participant inventory with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Transaction participant inventory” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C004-T02 · Field mapping:** Map every “Transaction participant inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Transaction participant inventory” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C004-T04 · Ownership agreement:** Specify who owns “Transaction participant inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C004-T05 · Handoff implementation:** Connect “Transaction participant inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “A successful transaction accounts for every affected resource” across the handoff.
- [ ] **UC-M07.01-C004-T06 · Absent-input case:** Omit one required “Transaction participant inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C004-T07 · Stale-input case:** Supply an outdated “Transaction participant inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Transaction participant inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C004-T09 · Valid integration trace:** Run a valid “Transaction participant inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C004-T10 · Seam review:** Reconcile the “Transaction participant inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for transaction participant inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Transaction participant inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C005-T02 · Expected-result oracle:** Specify the “Transaction participant inventory” expected result independently of the implementation output; include the property “A successful transaction accounts for every affected resource” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C005-T03 · Fixture material:** Create the concrete “Transaction participant inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C005-T04 · Target preparation:** Prepare the “Transaction participant inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C005-T05 · Initial-state record:** Record the initial “Transaction participant inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C005-T06 · Valid-path execution:** Execute the “Transaction participant inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C005-T07 · Outcome comparison:** Compare every declared “Transaction participant inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C005-T08 · State and bounds check:** Inspect the “Transaction participant inventory” ownership/state effects and actual use of “Participant count and transaction metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C005-T09 · Repeatability check:** Repeat the same “Transaction participant inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C005-T10 · Positive evidence:** Attach the “Transaction participant inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C006 · Negative test

**Original checklist item:** Negative case: Berth replacement commits while the hull still references the old state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Transaction participant inventory” source counterexample: “Berth replacement commits while the hull still references the old state”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Transaction participant inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C006-T03 · Valid control:** Construct a valid “Transaction participant inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C006-T04 · Minimal adverse input:** Derive the “Transaction participant inventory” adverse fixture from the control with the smallest documented change needed to reproduce “Berth replacement commits while the hull still references the old state”; retain that change as reproducible data.
- [ ] **UC-M07.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Transaction participant inventory”; require “A successful transaction accounts for every affected resource” and forbid a false-success verdict.
- [ ] **UC-M07.01-C006-T06 · Adverse execution:** Exercise the “Transaction participant inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C006-T07 · Effect inspection:** Inspect “Transaction participant inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C006-T08 · Refusal versus failure:** Confirm the “Transaction participant inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C006-T09 · Reset and retention:** Restore only the disposable “Transaction participant inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C006-T10 · Negative regression:** Register the “Transaction participant inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C007 · Change / failure test

**Original checklist item:** Exercise transaction participant inventory when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C007-T01 · Scenario record:** Write the “Transaction participant inventory” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “A successful transaction accounts for every affected resource”.
- [ ] **UC-M07.01-C007-T02 · Baseline capture:** Create a known-valid “Transaction participant inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C007-T03 · Injection map:** Locate the “Transaction participant inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Transaction participant inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C007-T05 · Controlled trigger:** Introduce the controlled “Transaction participant inventory” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C007-T06 · Intermediate inspection:** Inspect the “Transaction participant inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Transaction participant inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Transaction participant inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C007-T09 · Repeat and compare:** Repeat the selected “Transaction participant inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C007-T10 · Failure evidence:** Publish the “Transaction participant inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for participant count and transaction metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Transaction participant inventory”: “Participant count and transaction metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C008-T02 · Measurement method:** Choose how to observe each “Transaction participant inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Transaction participant inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Transaction participant inventory” cases for “Participant count and transaction metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Transaction participant inventory” limit; preserve “A successful transaction accounts for every affected resource”.
- [ ] **UC-M07.01-C008-T06 · Normal measurement:** Run or review the normal “Transaction participant inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C008-T07 · At-limit measurement:** Exercise the “Transaction participant inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C008-T08 · Over-limit measurement:** Exercise the “Transaction participant inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C008-T09 · Uncovered-scope report:** List the “Transaction participant inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C008-T10 · Limit evidence:** Publish the selected “Transaction participant inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for transaction participant inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C009-T01 · Event inventory:** List the “Transaction participant inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Transaction participant inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C009-T03 · Failure mapping:** Map each documented “Transaction participant inventory” refusal or error to a diagnostic outcome; include “Berth replacement commits while the hull still references the old state” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C009-T04 · Emission path:** Add the “Transaction participant inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C009-T05 · Redaction check:** Test “Transaction participant inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C009-T06 · Output budget:** Set and exercise bounded “Transaction participant inventory” message size, rate and retention compatible with “Participant count and transaction metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C009-T07 · Success/refusal fixtures:** Capture “Transaction participant inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Transaction participant inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C009-T09 · Operator review:** Read the “Transaction participant inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C009-T10 · Diagnostic evidence:** Publish redacted “Transaction participant inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for transaction participant inventory; label unexecuted checks as untested.

- [ ] **UC-M07.01-C010-T01 · Evidence inventory:** List the “Transaction participant inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C010-T02 · Artifact references:** Record the exact “Transaction participant inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C010-T03 · Fixture references:** Attach the “Transaction participant inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “Berth replacement commits while the hull still references the old state” as a distinct evidence case.
- [ ] **UC-M07.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Transaction participant inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C010-T05 · Environment record:** Record the actual “Transaction participant inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C010-T06 · Expected versus observed:** Pair every “Transaction participant inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C010-T07 · Failure and limit records:** Attach “Transaction participant inventory” change/failure and bounds evidence where required; include uncovered “Participant count and transaction metadata bytes” and unresolved violations of “A successful transaction accounts for every affected resource”.
- [ ] **UC-M07.01-C010-T08 · Evidence hygiene:** Check the “Transaction participant inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C010-T09 · Reproduction review:** Have the “Transaction participant inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C010-T10 · Acceptance linkage:** Link the “Transaction participant inventory” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Transaction identity

**Source delivery:** Assign durable transaction IDs bound to workload identity and old/new generations.

**Source invariant:** A journal cannot be applied to a different generation silently.

**Source negative case:** A stale journal is replayed after a later replacement.

**Source bounded quantities:** Journal identities and retained generations.

### UC-M07.01-C011 · Contract

**Original checklist item:** Specify transaction identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C011-T01 · Scope statement:** Draft the operation boundary for “Transaction identity” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Transaction identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C011-T03 · Output inventory:** List the outputs of “Transaction identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Transaction identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C011-T05 · Prerequisite contract:** Map “Transaction identity” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Transaction identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C011-T07 · Invariant clause:** Add a normative clause for “Transaction identity” that preserves “A journal cannot be applied to a different generation silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Transaction identity”; include the source counterexample “A stale journal is replayed after a later replacement” and the intended safe disposition.
- [ ] **UC-M07.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Journal identities and retained generations” in the “Transaction identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C011-T10 · Contract review:** Review the “Transaction identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C012 · Delivery

**Original checklist item:** Assign durable transaction IDs bound to workload identity and old/new generations.

- [ ] **UC-M07.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Transaction identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C012-T02 · Change plan:** Break the source delivery for “Transaction identity” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Transaction identity” that realizes this source instruction: Assign durable transaction IDs bound to workload identity and old/new generations.
- [ ] **UC-M07.01-C012-T04 · Concrete realization:** Trace “Transaction identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Transaction identity” needed to preserve “A journal cannot be applied to a different generation silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C012-T06 · Dependency connection:** Connect the “Transaction identity” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C012-T07 · Resource behavior:** Account for “Journal identities and retained generations” in “Transaction identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C012-T08 · Delivery check:** Run the smallest real “Transaction identity” path and its adverse fixture “A stale journal is replayed after a later replacement”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C012-T09 · Patch review:** Review the “Transaction identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C012-T10 · Delivery handoff:** Publish the “Transaction identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A journal cannot be applied to a different generation silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Transaction identity”; copy its required invariant exactly: “A journal cannot be applied to a different generation silently”.
- [ ] **UC-M07.01-C013-T02 · Observable terms:** Define each term in the “Transaction identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C013-T03 · Precondition set:** List the preconditions under which “A journal cannot be applied to a different generation silently” must hold for “Transaction identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C013-T04 · Transition coverage:** Map the “Transaction identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Transaction identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C013-T06 · Satisfying fixture:** Create a concrete “Transaction identity” case that satisfies “A journal cannot be applied to a different generation silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C013-T07 · Violating fixture:** Create the source counterexample “A stale journal is replayed after a later replacement” for “Transaction identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C013-T08 · Enforcement evidence:** Exercise the “Transaction identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C013-T09 · Regression linkage:** Link the “Transaction identity” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Transaction identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C014 · Integration

**Original checklist item:** Integrate transaction identity with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Transaction identity” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C014-T02 · Field mapping:** Map every “Transaction identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Transaction identity” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C014-T04 · Ownership agreement:** Specify who owns “Transaction identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C014-T05 · Handoff implementation:** Connect “Transaction identity” through the mapped seam using the real adapter or explicit specification reference; preserve “A journal cannot be applied to a different generation silently” across the handoff.
- [ ] **UC-M07.01-C014-T06 · Absent-input case:** Omit one required “Transaction identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C014-T07 · Stale-input case:** Supply an outdated “Transaction identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Transaction identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C014-T09 · Valid integration trace:** Run a valid “Transaction identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C014-T10 · Seam review:** Reconcile the “Transaction identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for transaction identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Transaction identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C015-T02 · Expected-result oracle:** Specify the “Transaction identity” expected result independently of the implementation output; include the property “A journal cannot be applied to a different generation silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C015-T03 · Fixture material:** Create the concrete “Transaction identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C015-T04 · Target preparation:** Prepare the “Transaction identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C015-T05 · Initial-state record:** Record the initial “Transaction identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C015-T06 · Valid-path execution:** Execute the “Transaction identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C015-T07 · Outcome comparison:** Compare every declared “Transaction identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C015-T08 · State and bounds check:** Inspect the “Transaction identity” ownership/state effects and actual use of “Journal identities and retained generations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C015-T09 · Repeatability check:** Repeat the same “Transaction identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C015-T10 · Positive evidence:** Attach the “Transaction identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C016 · Negative test

**Original checklist item:** Negative case: A stale journal is replayed after a later replacement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Transaction identity” source counterexample: “A stale journal is replayed after a later replacement”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Transaction identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C016-T03 · Valid control:** Construct a valid “Transaction identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C016-T04 · Minimal adverse input:** Derive the “Transaction identity” adverse fixture from the control with the smallest documented change needed to reproduce “A stale journal is replayed after a later replacement”; retain that change as reproducible data.
- [ ] **UC-M07.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Transaction identity”; require “A journal cannot be applied to a different generation silently” and forbid a false-success verdict.
- [ ] **UC-M07.01-C016-T06 · Adverse execution:** Exercise the “Transaction identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C016-T07 · Effect inspection:** Inspect “Transaction identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C016-T08 · Refusal versus failure:** Confirm the “Transaction identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C016-T09 · Reset and retention:** Restore only the disposable “Transaction identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C016-T10 · Negative regression:** Register the “Transaction identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C017 · Change / failure test

**Original checklist item:** Exercise transaction identity when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C017-T01 · Scenario record:** Write the “Transaction identity” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “A journal cannot be applied to a different generation silently”.
- [ ] **UC-M07.01-C017-T02 · Baseline capture:** Create a known-valid “Transaction identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C017-T03 · Injection map:** Locate the “Transaction identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Transaction identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C017-T05 · Controlled trigger:** Introduce the controlled “Transaction identity” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C017-T06 · Intermediate inspection:** Inspect the “Transaction identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Transaction identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Transaction identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C017-T09 · Repeat and compare:** Repeat the selected “Transaction identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C017-T10 · Failure evidence:** Publish the “Transaction identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for journal identities and retained generations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Transaction identity”: “Journal identities and retained generations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C018-T02 · Measurement method:** Choose how to observe each “Transaction identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Transaction identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Transaction identity” cases for “Journal identities and retained generations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Transaction identity” limit; preserve “A journal cannot be applied to a different generation silently”.
- [ ] **UC-M07.01-C018-T06 · Normal measurement:** Run or review the normal “Transaction identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C018-T07 · At-limit measurement:** Exercise the “Transaction identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C018-T08 · Over-limit measurement:** Exercise the “Transaction identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C018-T09 · Uncovered-scope report:** List the “Transaction identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C018-T10 · Limit evidence:** Publish the selected “Transaction identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for transaction identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C019-T01 · Event inventory:** List the “Transaction identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Transaction identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C019-T03 · Failure mapping:** Map each documented “Transaction identity” refusal or error to a diagnostic outcome; include “A stale journal is replayed after a later replacement” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C019-T04 · Emission path:** Add the “Transaction identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C019-T05 · Redaction check:** Test “Transaction identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C019-T06 · Output budget:** Set and exercise bounded “Transaction identity” message size, rate and retention compatible with “Journal identities and retained generations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C019-T07 · Success/refusal fixtures:** Capture “Transaction identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Transaction identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C019-T09 · Operator review:** Read the “Transaction identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C019-T10 · Diagnostic evidence:** Publish redacted “Transaction identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for transaction identity; label unexecuted checks as untested.

- [ ] **UC-M07.01-C020-T01 · Evidence inventory:** List the “Transaction identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C020-T02 · Artifact references:** Record the exact “Transaction identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C020-T03 · Fixture references:** Attach the “Transaction identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale journal is replayed after a later replacement” as a distinct evidence case.
- [ ] **UC-M07.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Transaction identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C020-T05 · Environment record:** Record the actual “Transaction identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C020-T06 · Expected versus observed:** Pair every “Transaction identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C020-T07 · Failure and limit records:** Attach “Transaction identity” change/failure and bounds evidence where required; include uncovered “Journal identities and retained generations” and unresolved violations of “A journal cannot be applied to a different generation silently”.
- [ ] **UC-M07.01-C020-T08 · Evidence hygiene:** Check the “Transaction identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C020-T09 · Reproduction review:** Have the “Transaction identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C020-T10 · Acceptance linkage:** Link the “Transaction identity” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Prepare phase

**Source delivery:** Stage and validate all required candidate resources before publishing new authority.

**Source invariant:** Preparation does not destroy the coherent previous generation.

**Source negative case:** A candidate fails validation after the old berth is removed.

**Source bounded quantities:** Staging bytes and prepare deadline.

### UC-M07.01-C021 · Contract

**Original checklist item:** Specify prepare phase inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C021-T01 · Scope statement:** Draft the operation boundary for “Prepare phase” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Prepare phase”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C021-T03 · Output inventory:** List the outputs of “Prepare phase” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Prepare phase”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C021-T05 · Prerequisite contract:** Map “Prepare phase” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Prepare phase”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C021-T07 · Invariant clause:** Add a normative clause for “Prepare phase” that preserves “Preparation does not destroy the coherent previous generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Prepare phase”; include the source counterexample “A candidate fails validation after the old berth is removed” and the intended safe disposition.
- [ ] **UC-M07.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Staging bytes and prepare deadline” in the “Prepare phase” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C021-T10 · Contract review:** Review the “Prepare phase” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C022 · Delivery

**Original checklist item:** Stage and validate all required candidate resources before publishing new authority.

- [ ] **UC-M07.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Prepare phase”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C022-T02 · Change plan:** Break the source delivery for “Prepare phase” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Prepare phase” that realizes this source instruction: Stage and validate all required candidate resources before publishing new authority.
- [ ] **UC-M07.01-C022-T04 · Concrete realization:** Trace “Prepare phase” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Prepare phase” needed to preserve “Preparation does not destroy the coherent previous generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C022-T06 · Dependency connection:** Connect the “Prepare phase” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C022-T07 · Resource behavior:** Account for “Staging bytes and prepare deadline” in “Prepare phase”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C022-T08 · Delivery check:** Run the smallest real “Prepare phase” path and its adverse fixture “A candidate fails validation after the old berth is removed”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C022-T09 · Patch review:** Review the “Prepare phase” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C022-T10 · Delivery handoff:** Publish the “Prepare phase” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Preparation does not destroy the coherent previous generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Prepare phase”; copy its required invariant exactly: “Preparation does not destroy the coherent previous generation”.
- [ ] **UC-M07.01-C023-T02 · Observable terms:** Define each term in the “Prepare phase” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C023-T03 · Precondition set:** List the preconditions under which “Preparation does not destroy the coherent previous generation” must hold for “Prepare phase”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C023-T04 · Transition coverage:** Map the “Prepare phase” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Prepare phase”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C023-T06 · Satisfying fixture:** Create a concrete “Prepare phase” case that satisfies “Preparation does not destroy the coherent previous generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C023-T07 · Violating fixture:** Create the source counterexample “A candidate fails validation after the old berth is removed” for “Prepare phase”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C023-T08 · Enforcement evidence:** Exercise the “Prepare phase” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C023-T09 · Regression linkage:** Link the “Prepare phase” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Prepare phase” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C024 · Integration

**Original checklist item:** Integrate prepare phase with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Prepare phase” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C024-T02 · Field mapping:** Map every “Prepare phase” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Prepare phase” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C024-T04 · Ownership agreement:** Specify who owns “Prepare phase” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C024-T05 · Handoff implementation:** Connect “Prepare phase” through the mapped seam using the real adapter or explicit specification reference; preserve “Preparation does not destroy the coherent previous generation” across the handoff.
- [ ] **UC-M07.01-C024-T06 · Absent-input case:** Omit one required “Prepare phase” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C024-T07 · Stale-input case:** Supply an outdated “Prepare phase” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Prepare phase” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C024-T09 · Valid integration trace:** Run a valid “Prepare phase” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C024-T10 · Seam review:** Reconcile the “Prepare phase” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for prepare phase; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Prepare phase” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C025-T02 · Expected-result oracle:** Specify the “Prepare phase” expected result independently of the implementation output; include the property “Preparation does not destroy the coherent previous generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C025-T03 · Fixture material:** Create the concrete “Prepare phase” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C025-T04 · Target preparation:** Prepare the “Prepare phase” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C025-T05 · Initial-state record:** Record the initial “Prepare phase” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C025-T06 · Valid-path execution:** Execute the “Prepare phase” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C025-T07 · Outcome comparison:** Compare every declared “Prepare phase” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C025-T08 · State and bounds check:** Inspect the “Prepare phase” ownership/state effects and actual use of “Staging bytes and prepare deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C025-T09 · Repeatability check:** Repeat the same “Prepare phase” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C025-T10 · Positive evidence:** Attach the “Prepare phase” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C026 · Negative test

**Original checklist item:** Negative case: A candidate fails validation after the old berth is removed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Prepare phase” source counterexample: “A candidate fails validation after the old berth is removed”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Prepare phase”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C026-T03 · Valid control:** Construct a valid “Prepare phase” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C026-T04 · Minimal adverse input:** Derive the “Prepare phase” adverse fixture from the control with the smallest documented change needed to reproduce “A candidate fails validation after the old berth is removed”; retain that change as reproducible data.
- [ ] **UC-M07.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Prepare phase”; require “Preparation does not destroy the coherent previous generation” and forbid a false-success verdict.
- [ ] **UC-M07.01-C026-T06 · Adverse execution:** Exercise the “Prepare phase” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C026-T07 · Effect inspection:** Inspect “Prepare phase” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C026-T08 · Refusal versus failure:** Confirm the “Prepare phase” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C026-T09 · Reset and retention:** Restore only the disposable “Prepare phase” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C026-T10 · Negative regression:** Register the “Prepare phase” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C027 · Change / failure test

**Original checklist item:** Exercise prepare phase when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C027-T01 · Scenario record:** Write the “Prepare phase” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “Preparation does not destroy the coherent previous generation”.
- [ ] **UC-M07.01-C027-T02 · Baseline capture:** Create a known-valid “Prepare phase” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C027-T03 · Injection map:** Locate the “Prepare phase” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Prepare phase” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C027-T05 · Controlled trigger:** Introduce the controlled “Prepare phase” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C027-T06 · Intermediate inspection:** Inspect the “Prepare phase” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Prepare phase”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Prepare phase” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C027-T09 · Repeat and compare:** Repeat the selected “Prepare phase” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C027-T10 · Failure evidence:** Publish the “Prepare phase” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for staging bytes and prepare deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Prepare phase”: “Staging bytes and prepare deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C028-T02 · Measurement method:** Choose how to observe each “Prepare phase” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Prepare phase”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Prepare phase” cases for “Staging bytes and prepare deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Prepare phase” limit; preserve “Preparation does not destroy the coherent previous generation”.
- [ ] **UC-M07.01-C028-T06 · Normal measurement:** Run or review the normal “Prepare phase” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C028-T07 · At-limit measurement:** Exercise the “Prepare phase” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C028-T08 · Over-limit measurement:** Exercise the “Prepare phase” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C028-T09 · Uncovered-scope report:** List the “Prepare phase” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C028-T10 · Limit evidence:** Publish the selected “Prepare phase” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for prepare phase with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C029-T01 · Event inventory:** List the “Prepare phase” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Prepare phase” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C029-T03 · Failure mapping:** Map each documented “Prepare phase” refusal or error to a diagnostic outcome; include “A candidate fails validation after the old berth is removed” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C029-T04 · Emission path:** Add the “Prepare phase” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C029-T05 · Redaction check:** Test “Prepare phase” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C029-T06 · Output budget:** Set and exercise bounded “Prepare phase” message size, rate and retention compatible with “Staging bytes and prepare deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C029-T07 · Success/refusal fixtures:** Capture “Prepare phase” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Prepare phase” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C029-T09 · Operator review:** Read the “Prepare phase” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C029-T10 · Diagnostic evidence:** Publish redacted “Prepare phase” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for prepare phase; label unexecuted checks as untested.

- [ ] **UC-M07.01-C030-T01 · Evidence inventory:** List the “Prepare phase” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C030-T02 · Artifact references:** Record the exact “Prepare phase” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C030-T03 · Fixture references:** Attach the “Prepare phase” fixture IDs, input identities and oracle definition; preserve the source counterexample “A candidate fails validation after the old berth is removed” as a distinct evidence case.
- [ ] **UC-M07.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Prepare phase”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C030-T05 · Environment record:** Record the actual “Prepare phase” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C030-T06 · Expected versus observed:** Pair every “Prepare phase” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C030-T07 · Failure and limit records:** Attach “Prepare phase” change/failure and bounds evidence where required; include uncovered “Staging bytes and prepare deadline” and unresolved violations of “Preparation does not destroy the coherent previous generation”.
- [ ] **UC-M07.01-C030-T08 · Evidence hygiene:** Check the “Prepare phase” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C030-T09 · Reproduction review:** Have the “Prepare phase” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C030-T10 · Acceptance linkage:** Link the “Prepare phase” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Durable intent journal

**Source delivery:** Record recoverable intent and participant progress before irreversible mutation.

**Source invariant:** Recovery can determine the intended transaction and completed steps.

**Source negative case:** A process dies after a mutation with no corresponding durable intent.

**Source bounded quantities:** Journal record size and flush frequency.

### UC-M07.01-C031 · Contract

**Original checklist item:** Specify durable intent journal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C031-T01 · Scope statement:** Draft the operation boundary for “Durable intent journal” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Durable intent journal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C031-T03 · Output inventory:** List the outputs of “Durable intent journal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Durable intent journal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C031-T05 · Prerequisite contract:** Map “Durable intent journal” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Durable intent journal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C031-T07 · Invariant clause:** Add a normative clause for “Durable intent journal” that preserves “Recovery can determine the intended transaction and completed steps”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Durable intent journal”; include the source counterexample “A process dies after a mutation with no corresponding durable intent” and the intended safe disposition.
- [ ] **UC-M07.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Journal record size and flush frequency” in the “Durable intent journal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C031-T10 · Contract review:** Review the “Durable intent journal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C032 · Delivery

**Original checklist item:** Record recoverable intent and participant progress before irreversible mutation.

- [ ] **UC-M07.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Durable intent journal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C032-T02 · Change plan:** Break the source delivery for “Durable intent journal” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C032-T03 · Core artifact:** Create the “Durable intent journal” model, schema or inventory that realizes this source instruction: Record recoverable intent and participant progress before irreversible mutation.
- [ ] **UC-M07.01-C032-T04 · Concrete realization:** Populate “Durable intent journal” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Durable intent journal” needed to preserve “Recovery can determine the intended transaction and completed steps”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C032-T06 · Dependency connection:** Connect the “Durable intent journal” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C032-T07 · Resource behavior:** Account for “Journal record size and flush frequency” in “Durable intent journal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C032-T08 · Delivery check:** Run the smallest real “Durable intent journal” path and its adverse fixture “A process dies after a mutation with no corresponding durable intent”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C032-T09 · Patch review:** Review the “Durable intent journal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C032-T10 · Delivery handoff:** Publish the “Durable intent journal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery can determine the intended transaction and completed steps. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Durable intent journal”; copy its required invariant exactly: “Recovery can determine the intended transaction and completed steps”.
- [ ] **UC-M07.01-C033-T02 · Observable terms:** Define each term in the “Durable intent journal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C033-T03 · Precondition set:** List the preconditions under which “Recovery can determine the intended transaction and completed steps” must hold for “Durable intent journal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C033-T04 · Transition coverage:** Map the “Durable intent journal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Durable intent journal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C033-T06 · Satisfying fixture:** Create a concrete “Durable intent journal” case that satisfies “Recovery can determine the intended transaction and completed steps”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C033-T07 · Violating fixture:** Create the source counterexample “A process dies after a mutation with no corresponding durable intent” for “Durable intent journal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C033-T08 · Enforcement evidence:** Exercise the “Durable intent journal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C033-T09 · Regression linkage:** Link the “Durable intent journal” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Durable intent journal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C034 · Integration

**Original checklist item:** Integrate durable intent journal with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Durable intent journal” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C034-T02 · Field mapping:** Map every “Durable intent journal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Durable intent journal” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C034-T04 · Ownership agreement:** Specify who owns “Durable intent journal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C034-T05 · Handoff implementation:** Connect “Durable intent journal” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery can determine the intended transaction and completed steps” across the handoff.
- [ ] **UC-M07.01-C034-T06 · Absent-input case:** Omit one required “Durable intent journal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C034-T07 · Stale-input case:** Supply an outdated “Durable intent journal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Durable intent journal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C034-T09 · Valid integration trace:** Run a valid “Durable intent journal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C034-T10 · Seam review:** Reconcile the “Durable intent journal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for durable intent journal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Durable intent journal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C035-T02 · Expected-result oracle:** Specify the “Durable intent journal” expected result independently of the implementation output; include the property “Recovery can determine the intended transaction and completed steps” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C035-T03 · Fixture material:** Create the concrete “Durable intent journal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C035-T04 · Target preparation:** Prepare the “Durable intent journal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C035-T05 · Initial-state record:** Record the initial “Durable intent journal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C035-T06 · Valid-path execution:** Execute the “Durable intent journal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C035-T07 · Outcome comparison:** Compare every declared “Durable intent journal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C035-T08 · State and bounds check:** Inspect the “Durable intent journal” ownership/state effects and actual use of “Journal record size and flush frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C035-T09 · Repeatability check:** Repeat the same “Durable intent journal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C035-T10 · Positive evidence:** Attach the “Durable intent journal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C036 · Negative test

**Original checklist item:** Negative case: A process dies after a mutation with no corresponding durable intent. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Durable intent journal” source counterexample: “A process dies after a mutation with no corresponding durable intent”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Durable intent journal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C036-T03 · Valid control:** Construct a valid “Durable intent journal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C036-T04 · Minimal adverse input:** Derive the “Durable intent journal” adverse fixture from the control with the smallest documented change needed to reproduce “A process dies after a mutation with no corresponding durable intent”; retain that change as reproducible data.
- [ ] **UC-M07.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Durable intent journal”; require “Recovery can determine the intended transaction and completed steps” and forbid a false-success verdict.
- [ ] **UC-M07.01-C036-T06 · Adverse execution:** Exercise the “Durable intent journal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C036-T07 · Effect inspection:** Inspect “Durable intent journal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C036-T08 · Refusal versus failure:** Confirm the “Durable intent journal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C036-T09 · Reset and retention:** Restore only the disposable “Durable intent journal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C036-T10 · Negative regression:** Register the “Durable intent journal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C037 · Change / failure test

**Original checklist item:** Exercise durable intent journal when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C037-T01 · Scenario record:** Write the “Durable intent journal” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “Recovery can determine the intended transaction and completed steps”.
- [ ] **UC-M07.01-C037-T02 · Baseline capture:** Create a known-valid “Durable intent journal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C037-T03 · Injection map:** Locate the “Durable intent journal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Durable intent journal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C037-T05 · Controlled trigger:** Introduce the controlled “Durable intent journal” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C037-T06 · Intermediate inspection:** Inspect the “Durable intent journal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Durable intent journal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Durable intent journal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C037-T09 · Repeat and compare:** Repeat the selected “Durable intent journal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C037-T10 · Failure evidence:** Publish the “Durable intent journal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for journal record size and flush frequency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Durable intent journal”: “Journal record size and flush frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C038-T02 · Measurement method:** Choose how to observe each “Durable intent journal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Durable intent journal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Durable intent journal” cases for “Journal record size and flush frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Durable intent journal” limit; preserve “Recovery can determine the intended transaction and completed steps”.
- [ ] **UC-M07.01-C038-T06 · Normal measurement:** Run or review the normal “Durable intent journal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C038-T07 · At-limit measurement:** Exercise the “Durable intent journal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C038-T08 · Over-limit measurement:** Exercise the “Durable intent journal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C038-T09 · Uncovered-scope report:** List the “Durable intent journal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C038-T10 · Limit evidence:** Publish the selected “Durable intent journal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for durable intent journal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C039-T01 · Event inventory:** List the “Durable intent journal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Durable intent journal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C039-T03 · Failure mapping:** Map each documented “Durable intent journal” refusal or error to a diagnostic outcome; include “A process dies after a mutation with no corresponding durable intent” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C039-T04 · Emission path:** Add the “Durable intent journal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C039-T05 · Redaction check:** Test “Durable intent journal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C039-T06 · Output budget:** Set and exercise bounded “Durable intent journal” message size, rate and retention compatible with “Journal record size and flush frequency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C039-T07 · Success/refusal fixtures:** Capture “Durable intent journal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Durable intent journal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C039-T09 · Operator review:** Read the “Durable intent journal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C039-T10 · Diagnostic evidence:** Publish redacted “Durable intent journal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for durable intent journal; label unexecuted checks as untested.

- [ ] **UC-M07.01-C040-T01 · Evidence inventory:** List the “Durable intent journal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C040-T02 · Artifact references:** Record the exact “Durable intent journal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C040-T03 · Fixture references:** Attach the “Durable intent journal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A process dies after a mutation with no corresponding durable intent” as a distinct evidence case.
- [ ] **UC-M07.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Durable intent journal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C040-T05 · Environment record:** Record the actual “Durable intent journal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C040-T06 · Expected versus observed:** Pair every “Durable intent journal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C040-T07 · Failure and limit records:** Attach “Durable intent journal” change/failure and bounds evidence where required; include uncovered “Journal record size and flush frequency” and unresolved violations of “Recovery can determine the intended transaction and completed steps”.
- [ ] **UC-M07.01-C040-T08 · Evidence hygiene:** Check the “Durable intent journal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C040-T09 · Reproduction review:** Have the “Durable intent journal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C040-T10 · Acceptance linkage:** Link the “Durable intent journal” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Commit point

**Source delivery:** Define the exact durable event that makes the new generation authoritative.

**Source invariant:** A transaction has one unambiguous commit decision.

**Source negative case:** Two participants independently declare conflicting commit states.

**Source bounded quantities:** Commit latency and coordination steps.

### UC-M07.01-C041 · Contract

**Original checklist item:** Specify commit point inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C041-T01 · Scope statement:** Draft the operation boundary for “Commit point” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Commit point”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C041-T03 · Output inventory:** List the outputs of “Commit point” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Commit point”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C041-T05 · Prerequisite contract:** Map “Commit point” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Commit point”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C041-T07 · Invariant clause:** Add a normative clause for “Commit point” that preserves “A transaction has one unambiguous commit decision”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Commit point”; include the source counterexample “Two participants independently declare conflicting commit states” and the intended safe disposition.
- [ ] **UC-M07.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Commit latency and coordination steps” in the “Commit point” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C041-T10 · Contract review:** Review the “Commit point” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C042 · Delivery

**Original checklist item:** Define the exact durable event that makes the new generation authoritative.

- [ ] **UC-M07.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Commit point”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C042-T02 · Change plan:** Break the source delivery for “Commit point” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C042-T03 · Core artifact:** Create the “Commit point” model, schema or inventory that realizes this source instruction: Define the exact durable event that makes the new generation authoritative.
- [ ] **UC-M07.01-C042-T04 · Concrete realization:** Populate “Commit point” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Commit point” needed to preserve “A transaction has one unambiguous commit decision”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C042-T06 · Dependency connection:** Connect the “Commit point” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C042-T07 · Resource behavior:** Account for “Commit latency and coordination steps” in “Commit point”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C042-T08 · Delivery check:** Run the smallest real “Commit point” path and its adverse fixture “Two participants independently declare conflicting commit states”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C042-T09 · Patch review:** Review the “Commit point” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C042-T10 · Delivery handoff:** Publish the “Commit point” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A transaction has one unambiguous commit decision. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Commit point”; copy its required invariant exactly: “A transaction has one unambiguous commit decision”.
- [ ] **UC-M07.01-C043-T02 · Observable terms:** Define each term in the “Commit point” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C043-T03 · Precondition set:** List the preconditions under which “A transaction has one unambiguous commit decision” must hold for “Commit point”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C043-T04 · Transition coverage:** Map the “Commit point” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Commit point”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C043-T06 · Satisfying fixture:** Create a concrete “Commit point” case that satisfies “A transaction has one unambiguous commit decision”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C043-T07 · Violating fixture:** Create the source counterexample “Two participants independently declare conflicting commit states” for “Commit point”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C043-T08 · Enforcement evidence:** Exercise the “Commit point” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C043-T09 · Regression linkage:** Link the “Commit point” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Commit point” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C044 · Integration

**Original checklist item:** Integrate commit point with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Commit point” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C044-T02 · Field mapping:** Map every “Commit point” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Commit point” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C044-T04 · Ownership agreement:** Specify who owns “Commit point” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C044-T05 · Handoff implementation:** Connect “Commit point” through the mapped seam using the real adapter or explicit specification reference; preserve “A transaction has one unambiguous commit decision” across the handoff.
- [ ] **UC-M07.01-C044-T06 · Absent-input case:** Omit one required “Commit point” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C044-T07 · Stale-input case:** Supply an outdated “Commit point” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Commit point” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C044-T09 · Valid integration trace:** Run a valid “Commit point” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C044-T10 · Seam review:** Reconcile the “Commit point” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for commit point; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Commit point” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C045-T02 · Expected-result oracle:** Specify the “Commit point” expected result independently of the implementation output; include the property “A transaction has one unambiguous commit decision” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C045-T03 · Fixture material:** Create the concrete “Commit point” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C045-T04 · Target preparation:** Prepare the “Commit point” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C045-T05 · Initial-state record:** Record the initial “Commit point” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C045-T06 · Valid-path execution:** Execute the “Commit point” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C045-T07 · Outcome comparison:** Compare every declared “Commit point” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C045-T08 · State and bounds check:** Inspect the “Commit point” ownership/state effects and actual use of “Commit latency and coordination steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C045-T09 · Repeatability check:** Repeat the same “Commit point” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C045-T10 · Positive evidence:** Attach the “Commit point” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C046 · Negative test

**Original checklist item:** Negative case: Two participants independently declare conflicting commit states. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Commit point” source counterexample: “Two participants independently declare conflicting commit states”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Commit point”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C046-T03 · Valid control:** Construct a valid “Commit point” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C046-T04 · Minimal adverse input:** Derive the “Commit point” adverse fixture from the control with the smallest documented change needed to reproduce “Two participants independently declare conflicting commit states”; retain that change as reproducible data.
- [ ] **UC-M07.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Commit point”; require “A transaction has one unambiguous commit decision” and forbid a false-success verdict.
- [ ] **UC-M07.01-C046-T06 · Adverse execution:** Exercise the “Commit point” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C046-T07 · Effect inspection:** Inspect “Commit point” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C046-T08 · Refusal versus failure:** Confirm the “Commit point” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C046-T09 · Reset and retention:** Restore only the disposable “Commit point” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C046-T10 · Negative regression:** Register the “Commit point” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C047 · Change / failure test

**Original checklist item:** Exercise commit point when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C047-T01 · Scenario record:** Write the “Commit point” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “A transaction has one unambiguous commit decision”.
- [ ] **UC-M07.01-C047-T02 · Baseline capture:** Create a known-valid “Commit point” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C047-T03 · Injection map:** Locate the “Commit point” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Commit point” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C047-T05 · Controlled trigger:** Introduce the controlled “Commit point” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C047-T06 · Intermediate inspection:** Inspect the “Commit point” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Commit point”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Commit point” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C047-T09 · Repeat and compare:** Repeat the selected “Commit point” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C047-T10 · Failure evidence:** Publish the “Commit point” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for commit latency and coordination steps; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Commit point”: “Commit latency and coordination steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C048-T02 · Measurement method:** Choose how to observe each “Commit point” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Commit point”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Commit point” cases for “Commit latency and coordination steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Commit point” limit; preserve “A transaction has one unambiguous commit decision”.
- [ ] **UC-M07.01-C048-T06 · Normal measurement:** Run or review the normal “Commit point” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C048-T07 · At-limit measurement:** Exercise the “Commit point” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C048-T08 · Over-limit measurement:** Exercise the “Commit point” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C048-T09 · Uncovered-scope report:** List the “Commit point” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C048-T10 · Limit evidence:** Publish the selected “Commit point” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for commit point with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C049-T01 · Event inventory:** List the “Commit point” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Commit point” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C049-T03 · Failure mapping:** Map each documented “Commit point” refusal or error to a diagnostic outcome; include “Two participants independently declare conflicting commit states” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C049-T04 · Emission path:** Add the “Commit point” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C049-T05 · Redaction check:** Test “Commit point” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C049-T06 · Output budget:** Set and exercise bounded “Commit point” message size, rate and retention compatible with “Commit latency and coordination steps”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C049-T07 · Success/refusal fixtures:** Capture “Commit point” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Commit point” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C049-T09 · Operator review:** Read the “Commit point” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C049-T10 · Diagnostic evidence:** Publish redacted “Commit point” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for commit point; label unexecuted checks as untested.

- [ ] **UC-M07.01-C050-T01 · Evidence inventory:** List the “Commit point” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C050-T02 · Artifact references:** Record the exact “Commit point” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C050-T03 · Fixture references:** Attach the “Commit point” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two participants independently declare conflicting commit states” as a distinct evidence case.
- [ ] **UC-M07.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Commit point”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C050-T05 · Environment record:** Record the actual “Commit point” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C050-T06 · Expected versus observed:** Pair every “Commit point” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C050-T07 · Failure and limit records:** Attach “Commit point” change/failure and bounds evidence where required; include uncovered “Commit latency and coordination steps” and unresolved violations of “A transaction has one unambiguous commit decision”.
- [ ] **UC-M07.01-C050-T08 · Evidence hygiene:** Check the “Commit point” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C050-T09 · Reproduction review:** Have the “Commit point” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C050-T10 · Acceptance linkage:** Link the “Commit point” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Participant publication

**Source delivery:** Publish participant changes according to the documented commit protocol.

**Source invariant:** A partially published generation is never presented as fully coherent.

**Source negative case:** Seals update but the bill of lading remains from the old generation.

**Source bounded quantities:** Participant writes and publication duration.

### UC-M07.01-C051 · Contract

**Original checklist item:** Specify participant publication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C051-T01 · Scope statement:** Draft the operation boundary for “Participant publication” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Participant publication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C051-T03 · Output inventory:** List the outputs of “Participant publication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Participant publication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C051-T05 · Prerequisite contract:** Map “Participant publication” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Participant publication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C051-T07 · Invariant clause:** Add a normative clause for “Participant publication” that preserves “A partially published generation is never presented as fully coherent”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Participant publication”; include the source counterexample “Seals update but the bill of lading remains from the old generation” and the intended safe disposition.
- [ ] **UC-M07.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Participant writes and publication duration” in the “Participant publication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C051-T10 · Contract review:** Review the “Participant publication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C052 · Delivery

**Original checklist item:** Publish participant changes according to the documented commit protocol.

- [ ] **UC-M07.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Participant publication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C052-T02 · Change plan:** Break the source delivery for “Participant publication” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C052-T03 · Core artifact:** Create the “Participant publication” output artifact for this source instruction: Publish participant changes according to the documented commit protocol.
- [ ] **UC-M07.01-C052-T04 · Concrete realization:** Populate the “Participant publication” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M07.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Participant publication” needed to preserve “A partially published generation is never presented as fully coherent”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C052-T06 · Dependency connection:** Connect the “Participant publication” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C052-T07 · Resource behavior:** Account for “Participant writes and publication duration” in “Participant publication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C052-T08 · Delivery check:** Run the smallest real “Participant publication” path and its adverse fixture “Seals update but the bill of lading remains from the old generation”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C052-T09 · Patch review:** Review the “Participant publication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C052-T10 · Delivery handoff:** Publish the “Participant publication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A partially published generation is never presented as fully coherent. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Participant publication”; copy its required invariant exactly: “A partially published generation is never presented as fully coherent”.
- [ ] **UC-M07.01-C053-T02 · Observable terms:** Define each term in the “Participant publication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C053-T03 · Precondition set:** List the preconditions under which “A partially published generation is never presented as fully coherent” must hold for “Participant publication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C053-T04 · Transition coverage:** Map the “Participant publication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Participant publication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C053-T06 · Satisfying fixture:** Create a concrete “Participant publication” case that satisfies “A partially published generation is never presented as fully coherent”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C053-T07 · Violating fixture:** Create the source counterexample “Seals update but the bill of lading remains from the old generation” for “Participant publication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C053-T08 · Enforcement evidence:** Exercise the “Participant publication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C053-T09 · Regression linkage:** Link the “Participant publication” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Participant publication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C054 · Integration

**Original checklist item:** Integrate participant publication with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Participant publication” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C054-T02 · Field mapping:** Map every “Participant publication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Participant publication” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C054-T04 · Ownership agreement:** Specify who owns “Participant publication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C054-T05 · Handoff implementation:** Connect “Participant publication” through the mapped seam using the real adapter or explicit specification reference; preserve “A partially published generation is never presented as fully coherent” across the handoff.
- [ ] **UC-M07.01-C054-T06 · Absent-input case:** Omit one required “Participant publication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C054-T07 · Stale-input case:** Supply an outdated “Participant publication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Participant publication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C054-T09 · Valid integration trace:** Run a valid “Participant publication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C054-T10 · Seam review:** Reconcile the “Participant publication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for participant publication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Participant publication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C055-T02 · Expected-result oracle:** Specify the “Participant publication” expected result independently of the implementation output; include the property “A partially published generation is never presented as fully coherent” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C055-T03 · Fixture material:** Create the concrete “Participant publication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C055-T04 · Target preparation:** Prepare the “Participant publication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C055-T05 · Initial-state record:** Record the initial “Participant publication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C055-T06 · Valid-path execution:** Execute the “Participant publication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C055-T07 · Outcome comparison:** Compare every declared “Participant publication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C055-T08 · State and bounds check:** Inspect the “Participant publication” ownership/state effects and actual use of “Participant writes and publication duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C055-T09 · Repeatability check:** Repeat the same “Participant publication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C055-T10 · Positive evidence:** Attach the “Participant publication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C056 · Negative test

**Original checklist item:** Negative case: Seals update but the bill of lading remains from the old generation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Participant publication” source counterexample: “Seals update but the bill of lading remains from the old generation”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Participant publication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C056-T03 · Valid control:** Construct a valid “Participant publication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C056-T04 · Minimal adverse input:** Derive the “Participant publication” adverse fixture from the control with the smallest documented change needed to reproduce “Seals update but the bill of lading remains from the old generation”; retain that change as reproducible data.
- [ ] **UC-M07.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Participant publication”; require “A partially published generation is never presented as fully coherent” and forbid a false-success verdict.
- [ ] **UC-M07.01-C056-T06 · Adverse execution:** Exercise the “Participant publication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C056-T07 · Effect inspection:** Inspect “Participant publication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C056-T08 · Refusal versus failure:** Confirm the “Participant publication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C056-T09 · Reset and retention:** Restore only the disposable “Participant publication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C056-T10 · Negative regression:** Register the “Participant publication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C057 · Change / failure test

**Original checklist item:** Exercise participant publication when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C057-T01 · Scenario record:** Write the “Participant publication” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “A partially published generation is never presented as fully coherent”.
- [ ] **UC-M07.01-C057-T02 · Baseline capture:** Create a known-valid “Participant publication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C057-T03 · Injection map:** Locate the “Participant publication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Participant publication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C057-T05 · Controlled trigger:** Introduce the controlled “Participant publication” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C057-T06 · Intermediate inspection:** Inspect the “Participant publication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Participant publication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Participant publication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C057-T09 · Repeat and compare:** Repeat the selected “Participant publication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C057-T10 · Failure evidence:** Publish the “Participant publication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for participant writes and publication duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Participant publication”: “Participant writes and publication duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C058-T02 · Measurement method:** Choose how to observe each “Participant publication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Participant publication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Participant publication” cases for “Participant writes and publication duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Participant publication” limit; preserve “A partially published generation is never presented as fully coherent”.
- [ ] **UC-M07.01-C058-T06 · Normal measurement:** Run or review the normal “Participant publication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C058-T07 · At-limit measurement:** Exercise the “Participant publication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C058-T08 · Over-limit measurement:** Exercise the “Participant publication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C058-T09 · Uncovered-scope report:** List the “Participant publication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C058-T10 · Limit evidence:** Publish the selected “Participant publication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for participant publication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C059-T01 · Event inventory:** List the “Participant publication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Participant publication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C059-T03 · Failure mapping:** Map each documented “Participant publication” refusal or error to a diagnostic outcome; include “Seals update but the bill of lading remains from the old generation” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C059-T04 · Emission path:** Add the “Participant publication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C059-T05 · Redaction check:** Test “Participant publication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C059-T06 · Output budget:** Set and exercise bounded “Participant publication” message size, rate and retention compatible with “Participant writes and publication duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C059-T07 · Success/refusal fixtures:** Capture “Participant publication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Participant publication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C059-T09 · Operator review:** Read the “Participant publication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C059-T10 · Diagnostic evidence:** Publish redacted “Participant publication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for participant publication; label unexecuted checks as untested.

- [ ] **UC-M07.01-C060-T01 · Evidence inventory:** List the “Participant publication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C060-T02 · Artifact references:** Record the exact “Participant publication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C060-T03 · Fixture references:** Attach the “Participant publication” fixture IDs, input identities and oracle definition; preserve the source counterexample “Seals update but the bill of lading remains from the old generation” as a distinct evidence case.
- [ ] **UC-M07.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Participant publication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C060-T05 · Environment record:** Record the actual “Participant publication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C060-T06 · Expected versus observed:** Pair every “Participant publication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C060-T07 · Failure and limit records:** Attach “Participant publication” change/failure and bounds evidence where required; include uncovered “Participant writes and publication duration” and unresolved violations of “A partially published generation is never presented as fully coherent”.
- [ ] **UC-M07.01-C060-T08 · Evidence hygiene:** Check the “Participant publication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C060-T09 · Reproduction review:** Have the “Participant publication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C060-T10 · Acceptance linkage:** Link the “Participant publication” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Abort and rollback

**Source delivery:** Restore or retain a coherent old generation when pre-commit work fails.

**Source invariant:** Abort preserves original cargo and a usable recovery path.

**Source negative case:** Cleanup deletes the only complete pre-transaction copy.

**Source bounded quantities:** Retained bytes and rollback deadline.

### UC-M07.01-C061 · Contract

**Original checklist item:** Specify abort and rollback inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C061-T01 · Scope statement:** Draft the operation boundary for “Abort and rollback” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Abort and rollback”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C061-T03 · Output inventory:** List the outputs of “Abort and rollback” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Abort and rollback”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C061-T05 · Prerequisite contract:** Map “Abort and rollback” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Abort and rollback”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C061-T07 · Invariant clause:** Add a normative clause for “Abort and rollback” that preserves “Abort preserves original cargo and a usable recovery path”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Abort and rollback”; include the source counterexample “Cleanup deletes the only complete pre-transaction copy” and the intended safe disposition.
- [ ] **UC-M07.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained bytes and rollback deadline” in the “Abort and rollback” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C061-T10 · Contract review:** Review the “Abort and rollback” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C062 · Delivery

**Original checklist item:** Restore or retain a coherent old generation when pre-commit work fails.

- [ ] **UC-M07.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Abort and rollback”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C062-T02 · Change plan:** Break the source delivery for “Abort and rollback” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Abort and rollback” that realizes this source instruction: Restore or retain a coherent old generation when pre-commit work fails.
- [ ] **UC-M07.01-C062-T04 · Concrete realization:** Trace “Abort and rollback” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Abort and rollback” needed to preserve “Abort preserves original cargo and a usable recovery path”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C062-T06 · Dependency connection:** Connect the “Abort and rollback” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C062-T07 · Resource behavior:** Account for “Retained bytes and rollback deadline” in “Abort and rollback”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C062-T08 · Delivery check:** Run the smallest real “Abort and rollback” path and its adverse fixture “Cleanup deletes the only complete pre-transaction copy”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C062-T09 · Patch review:** Review the “Abort and rollback” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C062-T10 · Delivery handoff:** Publish the “Abort and rollback” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Abort preserves original cargo and a usable recovery path. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Abort and rollback”; copy its required invariant exactly: “Abort preserves original cargo and a usable recovery path”.
- [ ] **UC-M07.01-C063-T02 · Observable terms:** Define each term in the “Abort and rollback” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C063-T03 · Precondition set:** List the preconditions under which “Abort preserves original cargo and a usable recovery path” must hold for “Abort and rollback”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C063-T04 · Transition coverage:** Map the “Abort and rollback” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Abort and rollback”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C063-T06 · Satisfying fixture:** Create a concrete “Abort and rollback” case that satisfies “Abort preserves original cargo and a usable recovery path”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C063-T07 · Violating fixture:** Create the source counterexample “Cleanup deletes the only complete pre-transaction copy” for “Abort and rollback”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C063-T08 · Enforcement evidence:** Exercise the “Abort and rollback” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C063-T09 · Regression linkage:** Link the “Abort and rollback” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Abort and rollback” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C064 · Integration

**Original checklist item:** Integrate abort and rollback with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Abort and rollback” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C064-T02 · Field mapping:** Map every “Abort and rollback” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Abort and rollback” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C064-T04 · Ownership agreement:** Specify who owns “Abort and rollback” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C064-T05 · Handoff implementation:** Connect “Abort and rollback” through the mapped seam using the real adapter or explicit specification reference; preserve “Abort preserves original cargo and a usable recovery path” across the handoff.
- [ ] **UC-M07.01-C064-T06 · Absent-input case:** Omit one required “Abort and rollback” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C064-T07 · Stale-input case:** Supply an outdated “Abort and rollback” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Abort and rollback” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C064-T09 · Valid integration trace:** Run a valid “Abort and rollback” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C064-T10 · Seam review:** Reconcile the “Abort and rollback” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for abort and rollback; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Abort and rollback” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C065-T02 · Expected-result oracle:** Specify the “Abort and rollback” expected result independently of the implementation output; include the property “Abort preserves original cargo and a usable recovery path” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C065-T03 · Fixture material:** Create the concrete “Abort and rollback” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C065-T04 · Target preparation:** Prepare the “Abort and rollback” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C065-T05 · Initial-state record:** Record the initial “Abort and rollback” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C065-T06 · Valid-path execution:** Execute the “Abort and rollback” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C065-T07 · Outcome comparison:** Compare every declared “Abort and rollback” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C065-T08 · State and bounds check:** Inspect the “Abort and rollback” ownership/state effects and actual use of “Retained bytes and rollback deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C065-T09 · Repeatability check:** Repeat the same “Abort and rollback” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C065-T10 · Positive evidence:** Attach the “Abort and rollback” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C066 · Negative test

**Original checklist item:** Negative case: Cleanup deletes the only complete pre-transaction copy. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Abort and rollback” source counterexample: “Cleanup deletes the only complete pre-transaction copy”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Abort and rollback”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C066-T03 · Valid control:** Construct a valid “Abort and rollback” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C066-T04 · Minimal adverse input:** Derive the “Abort and rollback” adverse fixture from the control with the smallest documented change needed to reproduce “Cleanup deletes the only complete pre-transaction copy”; retain that change as reproducible data.
- [ ] **UC-M07.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Abort and rollback”; require “Abort preserves original cargo and a usable recovery path” and forbid a false-success verdict.
- [ ] **UC-M07.01-C066-T06 · Adverse execution:** Exercise the “Abort and rollback” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C066-T07 · Effect inspection:** Inspect “Abort and rollback” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C066-T08 · Refusal versus failure:** Confirm the “Abort and rollback” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C066-T09 · Reset and retention:** Restore only the disposable “Abort and rollback” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C066-T10 · Negative regression:** Register the “Abort and rollback” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C067 · Change / failure test

**Original checklist item:** Exercise abort and rollback when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C067-T01 · Scenario record:** Write the “Abort and rollback” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “Abort preserves original cargo and a usable recovery path”.
- [ ] **UC-M07.01-C067-T02 · Baseline capture:** Create a known-valid “Abort and rollback” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C067-T03 · Injection map:** Locate the “Abort and rollback” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Abort and rollback” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C067-T05 · Controlled trigger:** Introduce the controlled “Abort and rollback” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C067-T06 · Intermediate inspection:** Inspect the “Abort and rollback” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Abort and rollback”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Abort and rollback” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C067-T09 · Repeat and compare:** Repeat the selected “Abort and rollback” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C067-T10 · Failure evidence:** Publish the “Abort and rollback” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for retained bytes and rollback deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Abort and rollback”: “Retained bytes and rollback deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C068-T02 · Measurement method:** Choose how to observe each “Abort and rollback” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Abort and rollback”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Abort and rollback” cases for “Retained bytes and rollback deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Abort and rollback” limit; preserve “Abort preserves original cargo and a usable recovery path”.
- [ ] **UC-M07.01-C068-T06 · Normal measurement:** Run or review the normal “Abort and rollback” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C068-T07 · At-limit measurement:** Exercise the “Abort and rollback” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C068-T08 · Over-limit measurement:** Exercise the “Abort and rollback” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C068-T09 · Uncovered-scope report:** List the “Abort and rollback” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C068-T10 · Limit evidence:** Publish the selected “Abort and rollback” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for abort and rollback with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C069-T01 · Event inventory:** List the “Abort and rollback” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Abort and rollback” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C069-T03 · Failure mapping:** Map each documented “Abort and rollback” refusal or error to a diagnostic outcome; include “Cleanup deletes the only complete pre-transaction copy” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C069-T04 · Emission path:** Add the “Abort and rollback” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C069-T05 · Redaction check:** Test “Abort and rollback” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C069-T06 · Output budget:** Set and exercise bounded “Abort and rollback” message size, rate and retention compatible with “Retained bytes and rollback deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C069-T07 · Success/refusal fixtures:** Capture “Abort and rollback” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Abort and rollback” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C069-T09 · Operator review:** Read the “Abort and rollback” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C069-T10 · Diagnostic evidence:** Publish redacted “Abort and rollback” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for abort and rollback; label unexecuted checks as untested.

- [ ] **UC-M07.01-C070-T01 · Evidence inventory:** List the “Abort and rollback” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C070-T02 · Artifact references:** Record the exact “Abort and rollback” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C070-T03 · Fixture references:** Attach the “Abort and rollback” fixture IDs, input identities and oracle definition; preserve the source counterexample “Cleanup deletes the only complete pre-transaction copy” as a distinct evidence case.
- [ ] **UC-M07.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Abort and rollback”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C070-T05 · Environment record:** Record the actual “Abort and rollback” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C070-T06 · Expected versus observed:** Pair every “Abort and rollback” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C070-T07 · Failure and limit records:** Attach “Abort and rollback” change/failure and bounds evidence where required; include uncovered “Retained bytes and rollback deadline” and unresolved violations of “Abort preserves original cargo and a usable recovery path”.
- [ ] **UC-M07.01-C070-T08 · Evidence hygiene:** Check the “Abort and rollback” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C070-T09 · Reproduction review:** Have the “Abort and rollback” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C070-T10 · Acceptance linkage:** Link the “Abort and rollback” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Restart recovery

**Source delivery:** Inspect durable journal and participant state to finish or undo interrupted work.

**Source invariant:** Recovery converges to a documented old or new generation.

**Source negative case:** Restart guesses success from the newest directory timestamp.

**Source bounded quantities:** Journal scan size and recovery duration.

### UC-M07.01-C071 · Contract

**Original checklist item:** Specify restart recovery inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C071-T01 · Scope statement:** Draft the operation boundary for “Restart recovery” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restart recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C071-T03 · Output inventory:** List the outputs of “Restart recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Restart recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C071-T05 · Prerequisite contract:** Map “Restart recovery” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Restart recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C071-T07 · Invariant clause:** Add a normative clause for “Restart recovery” that preserves “Recovery converges to a documented old or new generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restart recovery”; include the source counterexample “Restart guesses success from the newest directory timestamp” and the intended safe disposition.
- [ ] **UC-M07.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Journal scan size and recovery duration” in the “Restart recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C071-T10 · Contract review:** Review the “Restart recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C072 · Delivery

**Original checklist item:** Inspect durable journal and participant state to finish or undo interrupted work.

- [ ] **UC-M07.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restart recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C072-T02 · Change plan:** Break the source delivery for “Restart recovery” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Restart recovery” that realizes this source instruction: Inspect durable journal and participant state to finish or undo interrupted work.
- [ ] **UC-M07.01-C072-T04 · Concrete realization:** Trace “Restart recovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restart recovery” needed to preserve “Recovery converges to a documented old or new generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C072-T06 · Dependency connection:** Connect the “Restart recovery” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C072-T07 · Resource behavior:** Account for “Journal scan size and recovery duration” in “Restart recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C072-T08 · Delivery check:** Run the smallest real “Restart recovery” path and its adverse fixture “Restart guesses success from the newest directory timestamp”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C072-T09 · Patch review:** Review the “Restart recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C072-T10 · Delivery handoff:** Publish the “Restart recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery converges to a documented old or new generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Restart recovery”; copy its required invariant exactly: “Recovery converges to a documented old or new generation”.
- [ ] **UC-M07.01-C073-T02 · Observable terms:** Define each term in the “Restart recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C073-T03 · Precondition set:** List the preconditions under which “Recovery converges to a documented old or new generation” must hold for “Restart recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C073-T04 · Transition coverage:** Map the “Restart recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restart recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C073-T06 · Satisfying fixture:** Create a concrete “Restart recovery” case that satisfies “Recovery converges to a documented old or new generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C073-T07 · Violating fixture:** Create the source counterexample “Restart guesses success from the newest directory timestamp” for “Restart recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C073-T08 · Enforcement evidence:** Exercise the “Restart recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C073-T09 · Regression linkage:** Link the “Restart recovery” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Restart recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C074 · Integration

**Original checklist item:** Integrate restart recovery with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restart recovery” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C074-T02 · Field mapping:** Map every “Restart recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Restart recovery” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C074-T04 · Ownership agreement:** Specify who owns “Restart recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C074-T05 · Handoff implementation:** Connect “Restart recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery converges to a documented old or new generation” across the handoff.
- [ ] **UC-M07.01-C074-T06 · Absent-input case:** Omit one required “Restart recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C074-T07 · Stale-input case:** Supply an outdated “Restart recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Restart recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C074-T09 · Valid integration trace:** Run a valid “Restart recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C074-T10 · Seam review:** Reconcile the “Restart recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restart recovery; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restart recovery” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C075-T02 · Expected-result oracle:** Specify the “Restart recovery” expected result independently of the implementation output; include the property “Recovery converges to a documented old or new generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C075-T03 · Fixture material:** Create the concrete “Restart recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C075-T04 · Target preparation:** Prepare the “Restart recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C075-T05 · Initial-state record:** Record the initial “Restart recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C075-T06 · Valid-path execution:** Execute the “Restart recovery” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C075-T07 · Outcome comparison:** Compare every declared “Restart recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C075-T08 · State and bounds check:** Inspect the “Restart recovery” ownership/state effects and actual use of “Journal scan size and recovery duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C075-T09 · Repeatability check:** Repeat the same “Restart recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C075-T10 · Positive evidence:** Attach the “Restart recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C076 · Negative test

**Original checklist item:** Negative case: Restart guesses success from the newest directory timestamp. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Restart recovery” source counterexample: “Restart guesses success from the newest directory timestamp”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Restart recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C076-T03 · Valid control:** Construct a valid “Restart recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C076-T04 · Minimal adverse input:** Derive the “Restart recovery” adverse fixture from the control with the smallest documented change needed to reproduce “Restart guesses success from the newest directory timestamp”; retain that change as reproducible data.
- [ ] **UC-M07.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restart recovery”; require “Recovery converges to a documented old or new generation” and forbid a false-success verdict.
- [ ] **UC-M07.01-C076-T06 · Adverse execution:** Exercise the “Restart recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C076-T07 · Effect inspection:** Inspect “Restart recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C076-T08 · Refusal versus failure:** Confirm the “Restart recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C076-T09 · Reset and retention:** Restore only the disposable “Restart recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C076-T10 · Negative regression:** Register the “Restart recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C077 · Change / failure test

**Original checklist item:** Exercise restart recovery when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C077-T01 · Scenario record:** Write the “Restart recovery” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “Recovery converges to a documented old or new generation”.
- [ ] **UC-M07.01-C077-T02 · Baseline capture:** Create a known-valid “Restart recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C077-T03 · Injection map:** Locate the “Restart recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Restart recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C077-T05 · Controlled trigger:** Introduce the controlled “Restart recovery” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C077-T06 · Intermediate inspection:** Inspect the “Restart recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restart recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Restart recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C077-T09 · Repeat and compare:** Repeat the selected “Restart recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C077-T10 · Failure evidence:** Publish the “Restart recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for journal scan size and recovery duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Restart recovery”: “Journal scan size and recovery duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C078-T02 · Measurement method:** Choose how to observe each “Restart recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Restart recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restart recovery” cases for “Journal scan size and recovery duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restart recovery” limit; preserve “Recovery converges to a documented old or new generation”.
- [ ] **UC-M07.01-C078-T06 · Normal measurement:** Run or review the normal “Restart recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C078-T07 · At-limit measurement:** Exercise the “Restart recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C078-T08 · Over-limit measurement:** Exercise the “Restart recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C078-T09 · Uncovered-scope report:** List the “Restart recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C078-T10 · Limit evidence:** Publish the selected “Restart recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restart recovery with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C079-T01 · Event inventory:** List the “Restart recovery” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Restart recovery” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C079-T03 · Failure mapping:** Map each documented “Restart recovery” refusal or error to a diagnostic outcome; include “Restart guesses success from the newest directory timestamp” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C079-T04 · Emission path:** Add the “Restart recovery” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C079-T05 · Redaction check:** Test “Restart recovery” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C079-T06 · Output budget:** Set and exercise bounded “Restart recovery” message size, rate and retention compatible with “Journal scan size and recovery duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C079-T07 · Success/refusal fixtures:** Capture “Restart recovery” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restart recovery” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C079-T09 · Operator review:** Read the “Restart recovery” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C079-T10 · Diagnostic evidence:** Publish redacted “Restart recovery” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restart recovery; label unexecuted checks as untested.

- [ ] **UC-M07.01-C080-T01 · Evidence inventory:** List the “Restart recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C080-T02 · Artifact references:** Record the exact “Restart recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C080-T03 · Fixture references:** Attach the “Restart recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “Restart guesses success from the newest directory timestamp” as a distinct evidence case.
- [ ] **UC-M07.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restart recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C080-T05 · Environment record:** Record the actual “Restart recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C080-T06 · Expected versus observed:** Pair every “Restart recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C080-T07 · Failure and limit records:** Attach “Restart recovery” change/failure and bounds evidence where required; include uncovered “Journal scan size and recovery duration” and unresolved violations of “Recovery converges to a documented old or new generation”.
- [ ] **UC-M07.01-C080-T08 · Evidence hygiene:** Check the “Restart recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C080-T09 · Reproduction review:** Have the “Restart recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C080-T10 · Acceptance linkage:** Link the “Restart recovery” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Concurrent transaction control

**Source delivery:** Coordinate overlapping operations on shared ship and hull resources.

**Source invariant:** Concurrent transactions cannot publish conflicting ownership.

**Source negative case:** Two replacements update the same ship seal concurrently.

**Source bounded quantities:** Concurrent transactions and lock wait.

### UC-M07.01-C081 · Contract

**Original checklist item:** Specify concurrent transaction control inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C081-T01 · Scope statement:** Draft the operation boundary for “Concurrent transaction control” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Concurrent transaction control”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C081-T03 · Output inventory:** List the outputs of “Concurrent transaction control” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Concurrent transaction control”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C081-T05 · Prerequisite contract:** Map “Concurrent transaction control” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Concurrent transaction control”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C081-T07 · Invariant clause:** Add a normative clause for “Concurrent transaction control” that preserves “Concurrent transactions cannot publish conflicting ownership”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Concurrent transaction control”; include the source counterexample “Two replacements update the same ship seal concurrently” and the intended safe disposition.
- [ ] **UC-M07.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent transactions and lock wait” in the “Concurrent transaction control” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C081-T10 · Contract review:** Review the “Concurrent transaction control” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C082 · Delivery

**Original checklist item:** Coordinate overlapping operations on shared ship and hull resources.

- [ ] **UC-M07.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Concurrent transaction control”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C082-T02 · Change plan:** Break the source delivery for “Concurrent transaction control” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Concurrent transaction control” that realizes this source instruction: Coordinate overlapping operations on shared ship and hull resources.
- [ ] **UC-M07.01-C082-T04 · Concrete realization:** Trace “Concurrent transaction control” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Concurrent transaction control” needed to preserve “Concurrent transactions cannot publish conflicting ownership”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C082-T06 · Dependency connection:** Connect the “Concurrent transaction control” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C082-T07 · Resource behavior:** Account for “Concurrent transactions and lock wait” in “Concurrent transaction control”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C082-T08 · Delivery check:** Run the smallest real “Concurrent transaction control” path and its adverse fixture “Two replacements update the same ship seal concurrently”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C082-T09 · Patch review:** Review the “Concurrent transaction control” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C082-T10 · Delivery handoff:** Publish the “Concurrent transaction control” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Concurrent transactions cannot publish conflicting ownership. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Concurrent transaction control”; copy its required invariant exactly: “Concurrent transactions cannot publish conflicting ownership”.
- [ ] **UC-M07.01-C083-T02 · Observable terms:** Define each term in the “Concurrent transaction control” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C083-T03 · Precondition set:** List the preconditions under which “Concurrent transactions cannot publish conflicting ownership” must hold for “Concurrent transaction control”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C083-T04 · Transition coverage:** Map the “Concurrent transaction control” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Concurrent transaction control”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C083-T06 · Satisfying fixture:** Create a concrete “Concurrent transaction control” case that satisfies “Concurrent transactions cannot publish conflicting ownership”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C083-T07 · Violating fixture:** Create the source counterexample “Two replacements update the same ship seal concurrently” for “Concurrent transaction control”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C083-T08 · Enforcement evidence:** Exercise the “Concurrent transaction control” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C083-T09 · Regression linkage:** Link the “Concurrent transaction control” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Concurrent transaction control” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C084 · Integration

**Original checklist item:** Integrate concurrent transaction control with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Concurrent transaction control” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C084-T02 · Field mapping:** Map every “Concurrent transaction control” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Concurrent transaction control” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C084-T04 · Ownership agreement:** Specify who owns “Concurrent transaction control” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C084-T05 · Handoff implementation:** Connect “Concurrent transaction control” through the mapped seam using the real adapter or explicit specification reference; preserve “Concurrent transactions cannot publish conflicting ownership” across the handoff.
- [ ] **UC-M07.01-C084-T06 · Absent-input case:** Omit one required “Concurrent transaction control” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C084-T07 · Stale-input case:** Supply an outdated “Concurrent transaction control” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Concurrent transaction control” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C084-T09 · Valid integration trace:** Run a valid “Concurrent transaction control” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C084-T10 · Seam review:** Reconcile the “Concurrent transaction control” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for concurrent transaction control; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Concurrent transaction control” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C085-T02 · Expected-result oracle:** Specify the “Concurrent transaction control” expected result independently of the implementation output; include the property “Concurrent transactions cannot publish conflicting ownership” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C085-T03 · Fixture material:** Create the concrete “Concurrent transaction control” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C085-T04 · Target preparation:** Prepare the “Concurrent transaction control” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C085-T05 · Initial-state record:** Record the initial “Concurrent transaction control” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C085-T06 · Valid-path execution:** Execute the “Concurrent transaction control” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C085-T07 · Outcome comparison:** Compare every declared “Concurrent transaction control” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C085-T08 · State and bounds check:** Inspect the “Concurrent transaction control” ownership/state effects and actual use of “Concurrent transactions and lock wait”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C085-T09 · Repeatability check:** Repeat the same “Concurrent transaction control” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C085-T10 · Positive evidence:** Attach the “Concurrent transaction control” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C086 · Negative test

**Original checklist item:** Negative case: Two replacements update the same ship seal concurrently. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Concurrent transaction control” source counterexample: “Two replacements update the same ship seal concurrently”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Concurrent transaction control”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C086-T03 · Valid control:** Construct a valid “Concurrent transaction control” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C086-T04 · Minimal adverse input:** Derive the “Concurrent transaction control” adverse fixture from the control with the smallest documented change needed to reproduce “Two replacements update the same ship seal concurrently”; retain that change as reproducible data.
- [ ] **UC-M07.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Concurrent transaction control”; require “Concurrent transactions cannot publish conflicting ownership” and forbid a false-success verdict.
- [ ] **UC-M07.01-C086-T06 · Adverse execution:** Exercise the “Concurrent transaction control” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C086-T07 · Effect inspection:** Inspect “Concurrent transaction control” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C086-T08 · Refusal versus failure:** Confirm the “Concurrent transaction control” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C086-T09 · Reset and retention:** Restore only the disposable “Concurrent transaction control” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C086-T10 · Negative regression:** Register the “Concurrent transaction control” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C087 · Change / failure test

**Original checklist item:** Exercise concurrent transaction control when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C087-T01 · Scenario record:** Write the “Concurrent transaction control” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “Concurrent transactions cannot publish conflicting ownership”.
- [ ] **UC-M07.01-C087-T02 · Baseline capture:** Create a known-valid “Concurrent transaction control” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C087-T03 · Injection map:** Locate the “Concurrent transaction control” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Concurrent transaction control” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C087-T05 · Controlled trigger:** Introduce the controlled “Concurrent transaction control” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C087-T06 · Intermediate inspection:** Inspect the “Concurrent transaction control” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Concurrent transaction control”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Concurrent transaction control” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C087-T09 · Repeat and compare:** Repeat the selected “Concurrent transaction control” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C087-T10 · Failure evidence:** Publish the “Concurrent transaction control” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for concurrent transactions and lock wait; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Concurrent transaction control”: “Concurrent transactions and lock wait”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C088-T02 · Measurement method:** Choose how to observe each “Concurrent transaction control” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Concurrent transaction control”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Concurrent transaction control” cases for “Concurrent transactions and lock wait”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Concurrent transaction control” limit; preserve “Concurrent transactions cannot publish conflicting ownership”.
- [ ] **UC-M07.01-C088-T06 · Normal measurement:** Run or review the normal “Concurrent transaction control” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C088-T07 · At-limit measurement:** Exercise the “Concurrent transaction control” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C088-T08 · Over-limit measurement:** Exercise the “Concurrent transaction control” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C088-T09 · Uncovered-scope report:** List the “Concurrent transaction control” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C088-T10 · Limit evidence:** Publish the selected “Concurrent transaction control” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for concurrent transaction control with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C089-T01 · Event inventory:** List the “Concurrent transaction control” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Concurrent transaction control” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C089-T03 · Failure mapping:** Map each documented “Concurrent transaction control” refusal or error to a diagnostic outcome; include “Two replacements update the same ship seal concurrently” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C089-T04 · Emission path:** Add the “Concurrent transaction control” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C089-T05 · Redaction check:** Test “Concurrent transaction control” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C089-T06 · Output budget:** Set and exercise bounded “Concurrent transaction control” message size, rate and retention compatible with “Concurrent transactions and lock wait”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C089-T07 · Success/refusal fixtures:** Capture “Concurrent transaction control” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Concurrent transaction control” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C089-T09 · Operator review:** Read the “Concurrent transaction control” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C089-T10 · Diagnostic evidence:** Publish redacted “Concurrent transaction control” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for concurrent transaction control; label unexecuted checks as untested.

- [ ] **UC-M07.01-C090-T01 · Evidence inventory:** List the “Concurrent transaction control” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C090-T02 · Artifact references:** Record the exact “Concurrent transaction control” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C090-T03 · Fixture references:** Attach the “Concurrent transaction control” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two replacements update the same ship seal concurrently” as a distinct evidence case.
- [ ] **UC-M07.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Concurrent transaction control”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C090-T05 · Environment record:** Record the actual “Concurrent transaction control” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C090-T06 · Expected versus observed:** Pair every “Concurrent transaction control” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C090-T07 · Failure and limit records:** Attach “Concurrent transaction control” change/failure and bounds evidence where required; include uncovered “Concurrent transactions and lock wait” and unresolved violations of “Concurrent transactions cannot publish conflicting ownership”.
- [ ] **UC-M07.01-C090-T08 · Evidence hygiene:** Check the “Concurrent transaction control” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C090-T09 · Reproduction review:** Have the “Concurrent transaction control” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C090-T10 · Acceptance linkage:** Link the “Concurrent transaction control” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Crash-point qualification

**Source delivery:** Inject termination at every mutation boundary and reconcile all participants.

**Source invariant:** Every observed recovery preserves coherent state and original cargo accounting.

**Source negative case:** A test validates only the berth directory after a cross-resource crash.

**Source bounded quantities:** Mutation points and repeated fault trials.

### UC-M07.01-C091 · Contract

**Original checklist item:** Specify crash-point qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.01-C091-T01 · Scope statement:** Draft the operation boundary for “Crash-point qualification” within Cross-resource durable transaction coordinator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Crash-point qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.01-C091-T03 · Output inventory:** List the outputs of “Crash-point qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Crash-point qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.01-C091-T05 · Prerequisite contract:** Map “Crash-point qualification” to the source component prerequisites (UC-M01.03, UC-M01.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Crash-point qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.01-C091-T07 · Invariant clause:** Add a normative clause for “Crash-point qualification” that preserves “Every observed recovery preserves coherent state and original cargo accounting”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Crash-point qualification”; include the source counterexample “A test validates only the berth directory after a cross-resource crash” and the intended safe disposition.
- [ ] **UC-M07.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Mutation points and repeated fault trials” in the “Crash-point qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.01-C091-T10 · Contract review:** Review the “Crash-point qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.01-C092 · Delivery

**Original checklist item:** Inject termination at every mutation boundary and reconcile all participants.

- [ ] **UC-M07.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Crash-point qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.01-C092-T02 · Change plan:** Break the source delivery for “Crash-point qualification” into concrete edit targets and reviewable outputs; keep the UC-M07.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.01-C092-T03 · Core artifact:** Create the “Crash-point qualification” fixture or harness for this source instruction: Inject termination at every mutation boundary and reconcile all participants.
- [ ] **UC-M07.01-C092-T04 · Concrete realization:** Connect the “Crash-point qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Crash-point qualification” needed to preserve “Every observed recovery preserves coherent state and original cargo accounting”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.01-C092-T06 · Dependency connection:** Connect the “Crash-point qualification” implementation to berth data, bill of lading, seals, hull mounts and runtime-state participants; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.01-C092-T07 · Resource behavior:** Account for “Mutation points and repeated fault trials” in “Crash-point qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.01-C092-T08 · Delivery check:** Run the smallest real “Crash-point qualification” path and its adverse fixture “A test validates only the berth directory after a cross-resource crash”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.01-C092-T09 · Patch review:** Review the “Crash-point qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.01-C092-T10 · Delivery handoff:** Publish the “Crash-point qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every observed recovery preserves coherent state and original cargo accounting. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Crash-point qualification”; copy its required invariant exactly: “Every observed recovery preserves coherent state and original cargo accounting”.
- [ ] **UC-M07.01-C093-T02 · Observable terms:** Define each term in the “Crash-point qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.01-C093-T03 · Precondition set:** List the preconditions under which “Every observed recovery preserves coherent state and original cargo accounting” must hold for “Crash-point qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.01-C093-T04 · Transition coverage:** Map the “Crash-point qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Crash-point qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.01-C093-T06 · Satisfying fixture:** Create a concrete “Crash-point qualification” case that satisfies “Every observed recovery preserves coherent state and original cargo accounting”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.01-C093-T07 · Violating fixture:** Create the source counterexample “A test validates only the berth directory after a cross-resource crash” for “Crash-point qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.01-C093-T08 · Enforcement evidence:** Exercise the “Crash-point qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.01-C093-T09 · Regression linkage:** Link the “Crash-point qualification” property to changes in berth data, bill of lading, seals, hull mounts and runtime-state participants; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Crash-point qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.01-C094 · Integration

**Original checklist item:** Integrate crash-point qualification with berth data, bill of lading, seals, hull mounts and runtime-state participants; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Crash-point qualification” across berth data, bill of lading, seals, hull mounts and runtime-state participants; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.01-C094-T02 · Field mapping:** Map every “Crash-point qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Crash-point qualification” (source dependency list: UC-M01.03, UC-M01.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.01-C094-T04 · Ownership agreement:** Specify who owns “Crash-point qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.01-C094-T05 · Handoff implementation:** Connect “Crash-point qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Every observed recovery preserves coherent state and original cargo accounting” across the handoff.
- [ ] **UC-M07.01-C094-T06 · Absent-input case:** Omit one required “Crash-point qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.01-C094-T07 · Stale-input case:** Supply an outdated “Crash-point qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Crash-point qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.01-C094-T09 · Valid integration trace:** Run a valid “Crash-point qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.01-C094-T10 · Seam review:** Reconcile the “Crash-point qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for crash-point qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Crash-point qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.01-C095-T02 · Expected-result oracle:** Specify the “Crash-point qualification” expected result independently of the implementation output; include the property “Every observed recovery preserves coherent state and original cargo accounting” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.01-C095-T03 · Fixture material:** Create the concrete “Crash-point qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.01-C095-T04 · Target preparation:** Prepare the “Crash-point qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.01-C095-T05 · Initial-state record:** Record the initial “Crash-point qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.01-C095-T06 · Valid-path execution:** Execute the “Crash-point qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.01-C095-T07 · Outcome comparison:** Compare every declared “Crash-point qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.01-C095-T08 · State and bounds check:** Inspect the “Crash-point qualification” ownership/state effects and actual use of “Mutation points and repeated fault trials”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.01-C095-T09 · Repeatability check:** Repeat the same “Crash-point qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.01-C095-T10 · Positive evidence:** Attach the “Crash-point qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.01-C096 · Negative test

**Original checklist item:** Negative case: A test validates only the berth directory after a cross-resource crash. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Crash-point qualification” source counterexample: “A test validates only the berth directory after a cross-resource crash”; state which precondition or invariant it challenges.
- [ ] **UC-M07.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Crash-point qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.01-C096-T03 · Valid control:** Construct a valid “Crash-point qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.01-C096-T04 · Minimal adverse input:** Derive the “Crash-point qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A test validates only the berth directory after a cross-resource crash”; retain that change as reproducible data.
- [ ] **UC-M07.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Crash-point qualification”; require “Every observed recovery preserves coherent state and original cargo accounting” and forbid a false-success verdict.
- [ ] **UC-M07.01-C096-T06 · Adverse execution:** Exercise the “Crash-point qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.01-C096-T07 · Effect inspection:** Inspect “Crash-point qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.01-C096-T08 · Refusal versus failure:** Confirm the “Crash-point qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.01-C096-T09 · Reset and retention:** Restore only the disposable “Crash-point qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.01-C096-T10 · Negative regression:** Register the “Crash-point qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.01-C097 · Change / failure test

**Original checklist item:** Exercise crash-point qualification when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C097-T01 · Scenario record:** Write the “Crash-point qualification” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “Every observed recovery preserves coherent state and original cargo accounting”.
- [ ] **UC-M07.01-C097-T02 · Baseline capture:** Create a known-valid “Crash-point qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C097-T03 · Injection map:** Locate the “Crash-point qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Crash-point qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C097-T05 · Controlled trigger:** Introduce the controlled “Crash-point qualification” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C097-T06 · Intermediate inspection:** Inspect the “Crash-point qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Crash-point qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Crash-point qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C097-T09 · Repeat and compare:** Repeat the selected “Crash-point qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C097-T10 · Failure evidence:** Publish the “Crash-point qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for mutation points and repeated fault trials; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Crash-point qualification”: “Mutation points and repeated fault trials”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.01-C098-T02 · Measurement method:** Choose how to observe each “Crash-point qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.01-C098-T03 · Budget decision:** Select justified resource and input limits for “Crash-point qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Crash-point qualification” cases for “Mutation points and repeated fault trials”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Crash-point qualification” limit; preserve “Every observed recovery preserves coherent state and original cargo accounting”.
- [ ] **UC-M07.01-C098-T06 · Normal measurement:** Run or review the normal “Crash-point qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.01-C098-T07 · At-limit measurement:** Exercise the “Crash-point qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.01-C098-T08 · Over-limit measurement:** Exercise the “Crash-point qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.01-C098-T09 · Uncovered-scope report:** List the “Crash-point qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.01-C098-T10 · Limit evidence:** Publish the selected “Crash-point qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for crash-point qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.01-C099-T01 · Event inventory:** List the “Crash-point qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Crash-point qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.01-C099-T03 · Failure mapping:** Map each documented “Crash-point qualification” refusal or error to a diagnostic outcome; include “A test validates only the berth directory after a cross-resource crash” and prohibit conversion into a success message.
- [ ] **UC-M07.01-C099-T04 · Emission path:** Add the “Crash-point qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.01-C099-T05 · Redaction check:** Test “Crash-point qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.01-C099-T06 · Output budget:** Set and exercise bounded “Crash-point qualification” message size, rate and retention compatible with “Mutation points and repeated fault trials”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.01-C099-T07 · Success/refusal fixtures:** Capture “Crash-point qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Crash-point qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.01-C099-T09 · Operator review:** Read the “Crash-point qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.01-C099-T10 · Diagnostic evidence:** Publish redacted “Crash-point qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for crash-point qualification; label unexecuted checks as untested.

- [ ] **UC-M07.01-C100-T01 · Evidence inventory:** List the “Crash-point qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.01-C100-T02 · Artifact references:** Record the exact “Crash-point qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.01-C100-T03 · Fixture references:** Attach the “Crash-point qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test validates only the berth directory after a cross-resource crash” as a distinct evidence case.
- [ ] **UC-M07.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Crash-point qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.01-C100-T05 · Environment record:** Record the actual “Crash-point qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.01-C100-T06 · Expected versus observed:** Pair every “Crash-point qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.01-C100-T07 · Failure and limit records:** Attach “Crash-point qualification” change/failure and bounds evidence where required; include uncovered “Mutation points and repeated fault trials” and unresolved violations of “Every observed recovery preserves coherent state and original cargo accounting”.
- [ ] **UC-M07.01-C100-T08 · Evidence hygiene:** Check the “Crash-point qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.01-C100-T09 · Reproduction review:** Have the “Crash-point qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.01-C100-T10 · Acceptance linkage:** Link the “Crash-point qualification” evidence to its parent and UC-M07.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

