# UC-M07.05 — Workspace capacity reservation

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/07.md)

| Field | Preserved source value |
|---|---|
| Workstream | 07. Persistence, transactions and recovery |
| Milestone | A |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.05](../03/UC-M03.05.md), [UC-M07.01](../07/UC-M07.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S8]. |

## Original requirement

Reserve space for staging, image growth and backups before mutation; enforce minimum free-space thresholds and aggregate quotas.

**Original acceptance criterion:** A low-disk fault stops before destructive commit and preserves a usable recovery copy and clear error record.

**Source trace:** Original checklist `UC100/c/07/UC-M07.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 663–673 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Capacity scope

**Source delivery:** Account for staging, images, histories, checkpoints and retained backups.

**Source invariant:** Capacity decisions include temporary and recovery copies.

**Source negative case:** Admission counts final image size but ignores staging duplication.

**Source bounded quantities:** Accounted roots and aggregate bytes.

### UC-M07.05-C001 · Contract

**Original checklist item:** Specify capacity scope inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C001-T01 · Scope statement:** Draft the operation boundary for “Capacity scope” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capacity scope”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C001-T03 · Output inventory:** List the outputs of “Capacity scope” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Capacity scope”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C001-T05 · Prerequisite contract:** Map “Capacity scope” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Capacity scope”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C001-T07 · Invariant clause:** Add a normative clause for “Capacity scope” that preserves “Capacity decisions include temporary and recovery copies”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capacity scope”; include the source counterexample “Admission counts final image size but ignores staging duplication” and the intended safe disposition.
- [ ] **UC-M07.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Accounted roots and aggregate bytes” in the “Capacity scope” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C001-T10 · Contract review:** Review the “Capacity scope” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C002 · Delivery

**Original checklist item:** Account for staging, images, histories, checkpoints and retained backups.

- [ ] **UC-M07.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capacity scope”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C002-T02 · Change plan:** Break the source delivery for “Capacity scope” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Capacity scope” that realizes this source instruction: Account for staging, images, histories, checkpoints and retained backups.
- [ ] **UC-M07.05-C002-T04 · Concrete realization:** Trace “Capacity scope” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capacity scope” needed to preserve “Capacity decisions include temporary and recovery copies”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C002-T06 · Dependency connection:** Connect the “Capacity scope” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C002-T07 · Resource behavior:** Account for “Accounted roots and aggregate bytes” in “Capacity scope”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C002-T08 · Delivery check:** Run the smallest real “Capacity scope” path and its adverse fixture “Admission counts final image size but ignores staging duplication”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C002-T09 · Patch review:** Review the “Capacity scope” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C002-T10 · Delivery handoff:** Publish the “Capacity scope” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Capacity decisions include temporary and recovery copies. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Capacity scope”; copy its required invariant exactly: “Capacity decisions include temporary and recovery copies”.
- [ ] **UC-M07.05-C003-T02 · Observable terms:** Define each term in the “Capacity scope” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C003-T03 · Precondition set:** List the preconditions under which “Capacity decisions include temporary and recovery copies” must hold for “Capacity scope”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C003-T04 · Transition coverage:** Map the “Capacity scope” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capacity scope”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C003-T06 · Satisfying fixture:** Create a concrete “Capacity scope” case that satisfies “Capacity decisions include temporary and recovery copies”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C003-T07 · Violating fixture:** Create the source counterexample “Admission counts final image size but ignores staging duplication” for “Capacity scope”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C003-T08 · Enforcement evidence:** Exercise the “Capacity scope” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C003-T09 · Regression linkage:** Link the “Capacity scope” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Capacity scope” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C004 · Integration

**Original checklist item:** Integrate capacity scope with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capacity scope” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C004-T02 · Field mapping:** Map every “Capacity scope” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Capacity scope” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C004-T04 · Ownership agreement:** Specify who owns “Capacity scope” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C004-T05 · Handoff implementation:** Connect “Capacity scope” through the mapped seam using the real adapter or explicit specification reference; preserve “Capacity decisions include temporary and recovery copies” across the handoff.
- [ ] **UC-M07.05-C004-T06 · Absent-input case:** Omit one required “Capacity scope” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C004-T07 · Stale-input case:** Supply an outdated “Capacity scope” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Capacity scope” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C004-T09 · Valid integration trace:** Run a valid “Capacity scope” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C004-T10 · Seam review:** Reconcile the “Capacity scope” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capacity scope; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capacity scope” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C005-T02 · Expected-result oracle:** Specify the “Capacity scope” expected result independently of the implementation output; include the property “Capacity decisions include temporary and recovery copies” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C005-T03 · Fixture material:** Create the concrete “Capacity scope” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C005-T04 · Target preparation:** Prepare the “Capacity scope” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C005-T05 · Initial-state record:** Record the initial “Capacity scope” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C005-T06 · Valid-path execution:** Execute the “Capacity scope” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C005-T07 · Outcome comparison:** Compare every declared “Capacity scope” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C005-T08 · State and bounds check:** Inspect the “Capacity scope” ownership/state effects and actual use of “Accounted roots and aggregate bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C005-T09 · Repeatability check:** Repeat the same “Capacity scope” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C005-T10 · Positive evidence:** Attach the “Capacity scope” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C006 · Negative test

**Original checklist item:** Negative case: Admission counts final image size but ignores staging duplication. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Capacity scope” source counterexample: “Admission counts final image size but ignores staging duplication”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Capacity scope”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C006-T03 · Valid control:** Construct a valid “Capacity scope” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C006-T04 · Minimal adverse input:** Derive the “Capacity scope” adverse fixture from the control with the smallest documented change needed to reproduce “Admission counts final image size but ignores staging duplication”; retain that change as reproducible data.
- [ ] **UC-M07.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capacity scope”; require “Capacity decisions include temporary and recovery copies” and forbid a false-success verdict.
- [ ] **UC-M07.05-C006-T06 · Adverse execution:** Exercise the “Capacity scope” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C006-T07 · Effect inspection:** Inspect “Capacity scope” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C006-T08 · Refusal versus failure:** Confirm the “Capacity scope” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C006-T09 · Reset and retention:** Restore only the disposable “Capacity scope” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C006-T10 · Negative regression:** Register the “Capacity scope” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C007 · Change / failure test

**Original checklist item:** Exercise capacity scope when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C007-T01 · Scenario record:** Write the “Capacity scope” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Capacity decisions include temporary and recovery copies”.
- [ ] **UC-M07.05-C007-T02 · Baseline capture:** Create a known-valid “Capacity scope” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C007-T03 · Injection map:** Locate the “Capacity scope” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Capacity scope” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C007-T05 · Controlled trigger:** Introduce the controlled “Capacity scope” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C007-T06 · Intermediate inspection:** Inspect the “Capacity scope” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capacity scope”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Capacity scope” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C007-T09 · Repeat and compare:** Repeat the selected “Capacity scope” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C007-T10 · Failure evidence:** Publish the “Capacity scope” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C008 · Bounds

**Original checklist item:** Choose, document and test limits for accounted roots and aggregate bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Capacity scope”: “Accounted roots and aggregate bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C008-T02 · Measurement method:** Choose how to observe each “Capacity scope” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C008-T03 · Budget decision:** Select justified resource and input limits for “Capacity scope”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capacity scope” cases for “Accounted roots and aggregate bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capacity scope” limit; preserve “Capacity decisions include temporary and recovery copies”.
- [ ] **UC-M07.05-C008-T06 · Normal measurement:** Run or review the normal “Capacity scope” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C008-T07 · At-limit measurement:** Exercise the “Capacity scope” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C008-T08 · Over-limit measurement:** Exercise the “Capacity scope” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C008-T09 · Uncovered-scope report:** List the “Capacity scope” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C008-T10 · Limit evidence:** Publish the selected “Capacity scope” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capacity scope with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C009-T01 · Event inventory:** List the “Capacity scope” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Capacity scope” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C009-T03 · Failure mapping:** Map each documented “Capacity scope” refusal or error to a diagnostic outcome; include “Admission counts final image size but ignores staging duplication” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C009-T04 · Emission path:** Add the “Capacity scope” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C009-T05 · Redaction check:** Test “Capacity scope” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C009-T06 · Output budget:** Set and exercise bounded “Capacity scope” message size, rate and retention compatible with “Accounted roots and aggregate bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C009-T07 · Success/refusal fixtures:** Capture “Capacity scope” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capacity scope” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C009-T09 · Operator review:** Read the “Capacity scope” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C009-T10 · Diagnostic evidence:** Publish redacted “Capacity scope” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capacity scope; label unexecuted checks as untested.

- [ ] **UC-M07.05-C010-T01 · Evidence inventory:** List the “Capacity scope” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C010-T02 · Artifact references:** Record the exact “Capacity scope” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C010-T03 · Fixture references:** Attach the “Capacity scope” fixture IDs, input identities and oracle definition; preserve the source counterexample “Admission counts final image size but ignores staging duplication” as a distinct evidence case.
- [ ] **UC-M07.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capacity scope”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C010-T05 · Environment record:** Record the actual “Capacity scope” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C010-T06 · Expected versus observed:** Pair every “Capacity scope” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C010-T07 · Failure and limit records:** Attach “Capacity scope” change/failure and bounds evidence where required; include uncovered “Accounted roots and aggregate bytes” and unresolved violations of “Capacity decisions include temporary and recovery copies”.
- [ ] **UC-M07.05-C010-T08 · Evidence hygiene:** Check the “Capacity scope” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C010-T09 · Reproduction review:** Have the “Capacity scope” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C010-T10 · Acceptance linkage:** Link the “Capacity scope” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Free-space threshold

**Source delivery:** Define an operator-approved minimum free-space policy for each relevant volume.

**Source invariant:** Mutation stops before consuming required recovery headroom.

**Source negative case:** A transaction begins with insufficient space for its backup.

**Source bounded quantities:** Minimum free bytes and measurement freshness.

### UC-M07.05-C011 · Contract

**Original checklist item:** Specify free-space threshold inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C011-T01 · Scope statement:** Draft the operation boundary for “Free-space threshold” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Free-space threshold”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C011-T03 · Output inventory:** List the outputs of “Free-space threshold” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Free-space threshold”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C011-T05 · Prerequisite contract:** Map “Free-space threshold” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Free-space threshold”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C011-T07 · Invariant clause:** Add a normative clause for “Free-space threshold” that preserves “Mutation stops before consuming required recovery headroom”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Free-space threshold”; include the source counterexample “A transaction begins with insufficient space for its backup” and the intended safe disposition.
- [ ] **UC-M07.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Minimum free bytes and measurement freshness” in the “Free-space threshold” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C011-T10 · Contract review:** Review the “Free-space threshold” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C012 · Delivery

**Original checklist item:** Define an operator-approved minimum free-space policy for each relevant volume.

- [ ] **UC-M07.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Free-space threshold”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C012-T02 · Change plan:** Break the source delivery for “Free-space threshold” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C012-T03 · Core artifact:** Create the “Free-space threshold” model, schema or inventory that realizes this source instruction: Define an operator-approved minimum free-space policy for each relevant volume.
- [ ] **UC-M07.05-C012-T04 · Concrete realization:** Populate “Free-space threshold” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M07.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Free-space threshold” needed to preserve “Mutation stops before consuming required recovery headroom”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C012-T06 · Dependency connection:** Connect the “Free-space threshold” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C012-T07 · Resource behavior:** Account for “Minimum free bytes and measurement freshness” in “Free-space threshold”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C012-T08 · Delivery check:** Run the smallest real “Free-space threshold” path and its adverse fixture “A transaction begins with insufficient space for its backup”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C012-T09 · Patch review:** Review the “Free-space threshold” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C012-T10 · Delivery handoff:** Publish the “Free-space threshold” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Mutation stops before consuming required recovery headroom. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Free-space threshold”; copy its required invariant exactly: “Mutation stops before consuming required recovery headroom”.
- [ ] **UC-M07.05-C013-T02 · Observable terms:** Define each term in the “Free-space threshold” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C013-T03 · Precondition set:** List the preconditions under which “Mutation stops before consuming required recovery headroom” must hold for “Free-space threshold”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C013-T04 · Transition coverage:** Map the “Free-space threshold” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Free-space threshold”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C013-T06 · Satisfying fixture:** Create a concrete “Free-space threshold” case that satisfies “Mutation stops before consuming required recovery headroom”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C013-T07 · Violating fixture:** Create the source counterexample “A transaction begins with insufficient space for its backup” for “Free-space threshold”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C013-T08 · Enforcement evidence:** Exercise the “Free-space threshold” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C013-T09 · Regression linkage:** Link the “Free-space threshold” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Free-space threshold” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C014 · Integration

**Original checklist item:** Integrate free-space threshold with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Free-space threshold” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C014-T02 · Field mapping:** Map every “Free-space threshold” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Free-space threshold” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C014-T04 · Ownership agreement:** Specify who owns “Free-space threshold” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C014-T05 · Handoff implementation:** Connect “Free-space threshold” through the mapped seam using the real adapter or explicit specification reference; preserve “Mutation stops before consuming required recovery headroom” across the handoff.
- [ ] **UC-M07.05-C014-T06 · Absent-input case:** Omit one required “Free-space threshold” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C014-T07 · Stale-input case:** Supply an outdated “Free-space threshold” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Free-space threshold” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C014-T09 · Valid integration trace:** Run a valid “Free-space threshold” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C014-T10 · Seam review:** Reconcile the “Free-space threshold” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for free-space threshold; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Free-space threshold” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C015-T02 · Expected-result oracle:** Specify the “Free-space threshold” expected result independently of the implementation output; include the property “Mutation stops before consuming required recovery headroom” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C015-T03 · Fixture material:** Create the concrete “Free-space threshold” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C015-T04 · Target preparation:** Prepare the “Free-space threshold” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C015-T05 · Initial-state record:** Record the initial “Free-space threshold” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C015-T06 · Valid-path execution:** Execute the “Free-space threshold” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C015-T07 · Outcome comparison:** Compare every declared “Free-space threshold” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C015-T08 · State and bounds check:** Inspect the “Free-space threshold” ownership/state effects and actual use of “Minimum free bytes and measurement freshness”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C015-T09 · Repeatability check:** Repeat the same “Free-space threshold” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C015-T10 · Positive evidence:** Attach the “Free-space threshold” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C016 · Negative test

**Original checklist item:** Negative case: A transaction begins with insufficient space for its backup. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Free-space threshold” source counterexample: “A transaction begins with insufficient space for its backup”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Free-space threshold”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C016-T03 · Valid control:** Construct a valid “Free-space threshold” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C016-T04 · Minimal adverse input:** Derive the “Free-space threshold” adverse fixture from the control with the smallest documented change needed to reproduce “A transaction begins with insufficient space for its backup”; retain that change as reproducible data.
- [ ] **UC-M07.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Free-space threshold”; require “Mutation stops before consuming required recovery headroom” and forbid a false-success verdict.
- [ ] **UC-M07.05-C016-T06 · Adverse execution:** Exercise the “Free-space threshold” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C016-T07 · Effect inspection:** Inspect “Free-space threshold” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C016-T08 · Refusal versus failure:** Confirm the “Free-space threshold” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C016-T09 · Reset and retention:** Restore only the disposable “Free-space threshold” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C016-T10 · Negative regression:** Register the “Free-space threshold” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C017 · Change / failure test

**Original checklist item:** Exercise free-space threshold when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C017-T01 · Scenario record:** Write the “Free-space threshold” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Mutation stops before consuming required recovery headroom”.
- [ ] **UC-M07.05-C017-T02 · Baseline capture:** Create a known-valid “Free-space threshold” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C017-T03 · Injection map:** Locate the “Free-space threshold” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Free-space threshold” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C017-T05 · Controlled trigger:** Introduce the controlled “Free-space threshold” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C017-T06 · Intermediate inspection:** Inspect the “Free-space threshold” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Free-space threshold”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Free-space threshold” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C017-T09 · Repeat and compare:** Repeat the selected “Free-space threshold” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C017-T10 · Failure evidence:** Publish the “Free-space threshold” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C018 · Bounds

**Original checklist item:** Choose, document and test limits for minimum free bytes and measurement freshness; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Free-space threshold”: “Minimum free bytes and measurement freshness”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C018-T02 · Measurement method:** Choose how to observe each “Free-space threshold” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C018-T03 · Budget decision:** Select justified resource and input limits for “Free-space threshold”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Free-space threshold” cases for “Minimum free bytes and measurement freshness”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Free-space threshold” limit; preserve “Mutation stops before consuming required recovery headroom”.
- [ ] **UC-M07.05-C018-T06 · Normal measurement:** Run or review the normal “Free-space threshold” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C018-T07 · At-limit measurement:** Exercise the “Free-space threshold” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C018-T08 · Over-limit measurement:** Exercise the “Free-space threshold” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C018-T09 · Uncovered-scope report:** List the “Free-space threshold” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C018-T10 · Limit evidence:** Publish the selected “Free-space threshold” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for free-space threshold with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C019-T01 · Event inventory:** List the “Free-space threshold” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Free-space threshold” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C019-T03 · Failure mapping:** Map each documented “Free-space threshold” refusal or error to a diagnostic outcome; include “A transaction begins with insufficient space for its backup” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C019-T04 · Emission path:** Add the “Free-space threshold” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C019-T05 · Redaction check:** Test “Free-space threshold” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C019-T06 · Output budget:** Set and exercise bounded “Free-space threshold” message size, rate and retention compatible with “Minimum free bytes and measurement freshness”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C019-T07 · Success/refusal fixtures:** Capture “Free-space threshold” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Free-space threshold” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C019-T09 · Operator review:** Read the “Free-space threshold” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C019-T10 · Diagnostic evidence:** Publish redacted “Free-space threshold” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for free-space threshold; label unexecuted checks as untested.

- [ ] **UC-M07.05-C020-T01 · Evidence inventory:** List the “Free-space threshold” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C020-T02 · Artifact references:** Record the exact “Free-space threshold” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C020-T03 · Fixture references:** Attach the “Free-space threshold” fixture IDs, input identities and oracle definition; preserve the source counterexample “A transaction begins with insufficient space for its backup” as a distinct evidence case.
- [ ] **UC-M07.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Free-space threshold”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C020-T05 · Environment record:** Record the actual “Free-space threshold” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C020-T06 · Expected versus observed:** Pair every “Free-space threshold” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C020-T07 · Failure and limit records:** Attach “Free-space threshold” change/failure and bounds evidence where required; include uncovered “Minimum free bytes and measurement freshness” and unresolved violations of “Mutation stops before consuming required recovery headroom”.
- [ ] **UC-M07.05-C020-T08 · Evidence hygiene:** Check the “Free-space threshold” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C020-T09 · Reproduction review:** Have the “Free-space threshold” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C020-T10 · Acceptance linkage:** Link the “Free-space threshold” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Reservation estimates

**Source delivery:** Estimate worst-case required bytes for each mutation using declared growth limits.

**Source invariant:** A reservation covers the operation's documented expansion boundary.

**Source negative case:** A compressed input expands beyond the reserved space.

**Source bounded quantities:** Expansion ratios and reservation bytes.

### UC-M07.05-C021 · Contract

**Original checklist item:** Specify reservation estimates inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C021-T01 · Scope statement:** Draft the operation boundary for “Reservation estimates” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reservation estimates”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C021-T03 · Output inventory:** List the outputs of “Reservation estimates” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Reservation estimates”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C021-T05 · Prerequisite contract:** Map “Reservation estimates” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Reservation estimates”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C021-T07 · Invariant clause:** Add a normative clause for “Reservation estimates” that preserves “A reservation covers the operation's documented expansion boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reservation estimates”; include the source counterexample “A compressed input expands beyond the reserved space” and the intended safe disposition.
- [ ] **UC-M07.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Expansion ratios and reservation bytes” in the “Reservation estimates” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C021-T10 · Contract review:** Review the “Reservation estimates” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C022 · Delivery

**Original checklist item:** Estimate worst-case required bytes for each mutation using declared growth limits.

- [ ] **UC-M07.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reservation estimates”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C022-T02 · Change plan:** Break the source delivery for “Reservation estimates” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Reservation estimates” that realizes this source instruction: Estimate worst-case required bytes for each mutation using declared growth limits.
- [ ] **UC-M07.05-C022-T04 · Concrete realization:** Trace “Reservation estimates” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reservation estimates” needed to preserve “A reservation covers the operation's documented expansion boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C022-T06 · Dependency connection:** Connect the “Reservation estimates” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C022-T07 · Resource behavior:** Account for “Expansion ratios and reservation bytes” in “Reservation estimates”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C022-T08 · Delivery check:** Run the smallest real “Reservation estimates” path and its adverse fixture “A compressed input expands beyond the reserved space”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C022-T09 · Patch review:** Review the “Reservation estimates” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C022-T10 · Delivery handoff:** Publish the “Reservation estimates” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A reservation covers the operation's documented expansion boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Reservation estimates”; copy its required invariant exactly: “A reservation covers the operation's documented expansion boundary”.
- [ ] **UC-M07.05-C023-T02 · Observable terms:** Define each term in the “Reservation estimates” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C023-T03 · Precondition set:** List the preconditions under which “A reservation covers the operation's documented expansion boundary” must hold for “Reservation estimates”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C023-T04 · Transition coverage:** Map the “Reservation estimates” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reservation estimates”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C023-T06 · Satisfying fixture:** Create a concrete “Reservation estimates” case that satisfies “A reservation covers the operation's documented expansion boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C023-T07 · Violating fixture:** Create the source counterexample “A compressed input expands beyond the reserved space” for “Reservation estimates”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C023-T08 · Enforcement evidence:** Exercise the “Reservation estimates” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C023-T09 · Regression linkage:** Link the “Reservation estimates” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Reservation estimates” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C024 · Integration

**Original checklist item:** Integrate reservation estimates with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reservation estimates” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C024-T02 · Field mapping:** Map every “Reservation estimates” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Reservation estimates” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C024-T04 · Ownership agreement:** Specify who owns “Reservation estimates” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C024-T05 · Handoff implementation:** Connect “Reservation estimates” through the mapped seam using the real adapter or explicit specification reference; preserve “A reservation covers the operation's documented expansion boundary” across the handoff.
- [ ] **UC-M07.05-C024-T06 · Absent-input case:** Omit one required “Reservation estimates” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C024-T07 · Stale-input case:** Supply an outdated “Reservation estimates” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Reservation estimates” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C024-T09 · Valid integration trace:** Run a valid “Reservation estimates” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C024-T10 · Seam review:** Reconcile the “Reservation estimates” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reservation estimates; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reservation estimates” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C025-T02 · Expected-result oracle:** Specify the “Reservation estimates” expected result independently of the implementation output; include the property “A reservation covers the operation's documented expansion boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C025-T03 · Fixture material:** Create the concrete “Reservation estimates” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C025-T04 · Target preparation:** Prepare the “Reservation estimates” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C025-T05 · Initial-state record:** Record the initial “Reservation estimates” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C025-T06 · Valid-path execution:** Execute the “Reservation estimates” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C025-T07 · Outcome comparison:** Compare every declared “Reservation estimates” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C025-T08 · State and bounds check:** Inspect the “Reservation estimates” ownership/state effects and actual use of “Expansion ratios and reservation bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C025-T09 · Repeatability check:** Repeat the same “Reservation estimates” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C025-T10 · Positive evidence:** Attach the “Reservation estimates” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C026 · Negative test

**Original checklist item:** Negative case: A compressed input expands beyond the reserved space. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Reservation estimates” source counterexample: “A compressed input expands beyond the reserved space”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Reservation estimates”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C026-T03 · Valid control:** Construct a valid “Reservation estimates” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C026-T04 · Minimal adverse input:** Derive the “Reservation estimates” adverse fixture from the control with the smallest documented change needed to reproduce “A compressed input expands beyond the reserved space”; retain that change as reproducible data.
- [ ] **UC-M07.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reservation estimates”; require “A reservation covers the operation's documented expansion boundary” and forbid a false-success verdict.
- [ ] **UC-M07.05-C026-T06 · Adverse execution:** Exercise the “Reservation estimates” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C026-T07 · Effect inspection:** Inspect “Reservation estimates” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C026-T08 · Refusal versus failure:** Confirm the “Reservation estimates” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C026-T09 · Reset and retention:** Restore only the disposable “Reservation estimates” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C026-T10 · Negative regression:** Register the “Reservation estimates” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C027 · Change / failure test

**Original checklist item:** Exercise reservation estimates when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C027-T01 · Scenario record:** Write the “Reservation estimates” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “A reservation covers the operation's documented expansion boundary”.
- [ ] **UC-M07.05-C027-T02 · Baseline capture:** Create a known-valid “Reservation estimates” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C027-T03 · Injection map:** Locate the “Reservation estimates” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Reservation estimates” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C027-T05 · Controlled trigger:** Introduce the controlled “Reservation estimates” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C027-T06 · Intermediate inspection:** Inspect the “Reservation estimates” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reservation estimates”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Reservation estimates” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C027-T09 · Repeat and compare:** Repeat the selected “Reservation estimates” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C027-T10 · Failure evidence:** Publish the “Reservation estimates” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C028 · Bounds

**Original checklist item:** Choose, document and test limits for expansion ratios and reservation bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Reservation estimates”: “Expansion ratios and reservation bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C028-T02 · Measurement method:** Choose how to observe each “Reservation estimates” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C028-T03 · Budget decision:** Select justified resource and input limits for “Reservation estimates”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reservation estimates” cases for “Expansion ratios and reservation bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reservation estimates” limit; preserve “A reservation covers the operation's documented expansion boundary”.
- [ ] **UC-M07.05-C028-T06 · Normal measurement:** Run or review the normal “Reservation estimates” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C028-T07 · At-limit measurement:** Exercise the “Reservation estimates” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C028-T08 · Over-limit measurement:** Exercise the “Reservation estimates” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C028-T09 · Uncovered-scope report:** List the “Reservation estimates” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C028-T10 · Limit evidence:** Publish the selected “Reservation estimates” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reservation estimates with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C029-T01 · Event inventory:** List the “Reservation estimates” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Reservation estimates” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C029-T03 · Failure mapping:** Map each documented “Reservation estimates” refusal or error to a diagnostic outcome; include “A compressed input expands beyond the reserved space” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C029-T04 · Emission path:** Add the “Reservation estimates” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C029-T05 · Redaction check:** Test “Reservation estimates” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C029-T06 · Output budget:** Set and exercise bounded “Reservation estimates” message size, rate and retention compatible with “Expansion ratios and reservation bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C029-T07 · Success/refusal fixtures:** Capture “Reservation estimates” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reservation estimates” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C029-T09 · Operator review:** Read the “Reservation estimates” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C029-T10 · Diagnostic evidence:** Publish redacted “Reservation estimates” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reservation estimates; label unexecuted checks as untested.

- [ ] **UC-M07.05-C030-T01 · Evidence inventory:** List the “Reservation estimates” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C030-T02 · Artifact references:** Record the exact “Reservation estimates” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C030-T03 · Fixture references:** Attach the “Reservation estimates” fixture IDs, input identities and oracle definition; preserve the source counterexample “A compressed input expands beyond the reserved space” as a distinct evidence case.
- [ ] **UC-M07.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reservation estimates”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C030-T05 · Environment record:** Record the actual “Reservation estimates” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C030-T06 · Expected versus observed:** Pair every “Reservation estimates” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C030-T07 · Failure and limit records:** Attach “Reservation estimates” change/failure and bounds evidence where required; include uncovered “Expansion ratios and reservation bytes” and unresolved violations of “A reservation covers the operation's documented expansion boundary”.
- [ ] **UC-M07.05-C030-T08 · Evidence hygiene:** Check the “Reservation estimates” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C030-T09 · Reproduction review:** Have the “Reservation estimates” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C030-T10 · Acceptance linkage:** Link the “Reservation estimates” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Atomic reservation ledger

**Source delivery:** Reserve capacity against concurrent operations before staging.

**Source invariant:** Concurrent operations cannot spend the same remaining capacity.

**Source negative case:** Two builders each reserve the last available free space.

**Source bounded quantities:** Reservations and contention time.

### UC-M07.05-C031 · Contract

**Original checklist item:** Specify atomic reservation ledger inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C031-T01 · Scope statement:** Draft the operation boundary for “Atomic reservation ledger” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Atomic reservation ledger”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C031-T03 · Output inventory:** List the outputs of “Atomic reservation ledger” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Atomic reservation ledger”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C031-T05 · Prerequisite contract:** Map “Atomic reservation ledger” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Atomic reservation ledger”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C031-T07 · Invariant clause:** Add a normative clause for “Atomic reservation ledger” that preserves “Concurrent operations cannot spend the same remaining capacity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Atomic reservation ledger”; include the source counterexample “Two builders each reserve the last available free space” and the intended safe disposition.
- [ ] **UC-M07.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reservations and contention time” in the “Atomic reservation ledger” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C031-T10 · Contract review:** Review the “Atomic reservation ledger” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C032 · Delivery

**Original checklist item:** Reserve capacity against concurrent operations before staging.

- [ ] **UC-M07.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Atomic reservation ledger”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C032-T02 · Change plan:** Break the source delivery for “Atomic reservation ledger” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Atomic reservation ledger” that realizes this source instruction: Reserve capacity against concurrent operations before staging.
- [ ] **UC-M07.05-C032-T04 · Concrete realization:** Trace “Atomic reservation ledger” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Atomic reservation ledger” needed to preserve “Concurrent operations cannot spend the same remaining capacity”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C032-T06 · Dependency connection:** Connect the “Atomic reservation ledger” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C032-T07 · Resource behavior:** Account for “Reservations and contention time” in “Atomic reservation ledger”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C032-T08 · Delivery check:** Run the smallest real “Atomic reservation ledger” path and its adverse fixture “Two builders each reserve the last available free space”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C032-T09 · Patch review:** Review the “Atomic reservation ledger” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C032-T10 · Delivery handoff:** Publish the “Atomic reservation ledger” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Concurrent operations cannot spend the same remaining capacity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Atomic reservation ledger”; copy its required invariant exactly: “Concurrent operations cannot spend the same remaining capacity”.
- [ ] **UC-M07.05-C033-T02 · Observable terms:** Define each term in the “Atomic reservation ledger” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C033-T03 · Precondition set:** List the preconditions under which “Concurrent operations cannot spend the same remaining capacity” must hold for “Atomic reservation ledger”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C033-T04 · Transition coverage:** Map the “Atomic reservation ledger” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Atomic reservation ledger”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C033-T06 · Satisfying fixture:** Create a concrete “Atomic reservation ledger” case that satisfies “Concurrent operations cannot spend the same remaining capacity”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C033-T07 · Violating fixture:** Create the source counterexample “Two builders each reserve the last available free space” for “Atomic reservation ledger”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C033-T08 · Enforcement evidence:** Exercise the “Atomic reservation ledger” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C033-T09 · Regression linkage:** Link the “Atomic reservation ledger” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Atomic reservation ledger” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C034 · Integration

**Original checklist item:** Integrate atomic reservation ledger with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Atomic reservation ledger” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C034-T02 · Field mapping:** Map every “Atomic reservation ledger” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Atomic reservation ledger” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C034-T04 · Ownership agreement:** Specify who owns “Atomic reservation ledger” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C034-T05 · Handoff implementation:** Connect “Atomic reservation ledger” through the mapped seam using the real adapter or explicit specification reference; preserve “Concurrent operations cannot spend the same remaining capacity” across the handoff.
- [ ] **UC-M07.05-C034-T06 · Absent-input case:** Omit one required “Atomic reservation ledger” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C034-T07 · Stale-input case:** Supply an outdated “Atomic reservation ledger” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Atomic reservation ledger” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C034-T09 · Valid integration trace:** Run a valid “Atomic reservation ledger” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C034-T10 · Seam review:** Reconcile the “Atomic reservation ledger” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for atomic reservation ledger; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Atomic reservation ledger” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C035-T02 · Expected-result oracle:** Specify the “Atomic reservation ledger” expected result independently of the implementation output; include the property “Concurrent operations cannot spend the same remaining capacity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C035-T03 · Fixture material:** Create the concrete “Atomic reservation ledger” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C035-T04 · Target preparation:** Prepare the “Atomic reservation ledger” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C035-T05 · Initial-state record:** Record the initial “Atomic reservation ledger” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C035-T06 · Valid-path execution:** Execute the “Atomic reservation ledger” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C035-T07 · Outcome comparison:** Compare every declared “Atomic reservation ledger” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C035-T08 · State and bounds check:** Inspect the “Atomic reservation ledger” ownership/state effects and actual use of “Reservations and contention time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C035-T09 · Repeatability check:** Repeat the same “Atomic reservation ledger” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C035-T10 · Positive evidence:** Attach the “Atomic reservation ledger” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C036 · Negative test

**Original checklist item:** Negative case: Two builders each reserve the last available free space. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Atomic reservation ledger” source counterexample: “Two builders each reserve the last available free space”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Atomic reservation ledger”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C036-T03 · Valid control:** Construct a valid “Atomic reservation ledger” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C036-T04 · Minimal adverse input:** Derive the “Atomic reservation ledger” adverse fixture from the control with the smallest documented change needed to reproduce “Two builders each reserve the last available free space”; retain that change as reproducible data.
- [ ] **UC-M07.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Atomic reservation ledger”; require “Concurrent operations cannot spend the same remaining capacity” and forbid a false-success verdict.
- [ ] **UC-M07.05-C036-T06 · Adverse execution:** Exercise the “Atomic reservation ledger” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C036-T07 · Effect inspection:** Inspect “Atomic reservation ledger” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C036-T08 · Refusal versus failure:** Confirm the “Atomic reservation ledger” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C036-T09 · Reset and retention:** Restore only the disposable “Atomic reservation ledger” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C036-T10 · Negative regression:** Register the “Atomic reservation ledger” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C037 · Change / failure test

**Original checklist item:** Exercise atomic reservation ledger when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C037-T01 · Scenario record:** Write the “Atomic reservation ledger” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Concurrent operations cannot spend the same remaining capacity”.
- [ ] **UC-M07.05-C037-T02 · Baseline capture:** Create a known-valid “Atomic reservation ledger” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C037-T03 · Injection map:** Locate the “Atomic reservation ledger” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Atomic reservation ledger” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C037-T05 · Controlled trigger:** Introduce the controlled “Atomic reservation ledger” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C037-T06 · Intermediate inspection:** Inspect the “Atomic reservation ledger” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Atomic reservation ledger”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Atomic reservation ledger” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C037-T09 · Repeat and compare:** Repeat the selected “Atomic reservation ledger” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C037-T10 · Failure evidence:** Publish the “Atomic reservation ledger” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C038 · Bounds

**Original checklist item:** Choose, document and test limits for reservations and contention time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Atomic reservation ledger”: “Reservations and contention time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C038-T02 · Measurement method:** Choose how to observe each “Atomic reservation ledger” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C038-T03 · Budget decision:** Select justified resource and input limits for “Atomic reservation ledger”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Atomic reservation ledger” cases for “Reservations and contention time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Atomic reservation ledger” limit; preserve “Concurrent operations cannot spend the same remaining capacity”.
- [ ] **UC-M07.05-C038-T06 · Normal measurement:** Run or review the normal “Atomic reservation ledger” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C038-T07 · At-limit measurement:** Exercise the “Atomic reservation ledger” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C038-T08 · Over-limit measurement:** Exercise the “Atomic reservation ledger” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C038-T09 · Uncovered-scope report:** List the “Atomic reservation ledger” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C038-T10 · Limit evidence:** Publish the selected “Atomic reservation ledger” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for atomic reservation ledger with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C039-T01 · Event inventory:** List the “Atomic reservation ledger” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Atomic reservation ledger” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C039-T03 · Failure mapping:** Map each documented “Atomic reservation ledger” refusal or error to a diagnostic outcome; include “Two builders each reserve the last available free space” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C039-T04 · Emission path:** Add the “Atomic reservation ledger” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C039-T05 · Redaction check:** Test “Atomic reservation ledger” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C039-T06 · Output budget:** Set and exercise bounded “Atomic reservation ledger” message size, rate and retention compatible with “Reservations and contention time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C039-T07 · Success/refusal fixtures:** Capture “Atomic reservation ledger” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Atomic reservation ledger” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C039-T09 · Operator review:** Read the “Atomic reservation ledger” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C039-T10 · Diagnostic evidence:** Publish redacted “Atomic reservation ledger” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for atomic reservation ledger; label unexecuted checks as untested.

- [ ] **UC-M07.05-C040-T01 · Evidence inventory:** List the “Atomic reservation ledger” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C040-T02 · Artifact references:** Record the exact “Atomic reservation ledger” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C040-T03 · Fixture references:** Attach the “Atomic reservation ledger” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two builders each reserve the last available free space” as a distinct evidence case.
- [ ] **UC-M07.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Atomic reservation ledger”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C040-T05 · Environment record:** Record the actual “Atomic reservation ledger” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C040-T06 · Expected versus observed:** Pair every “Atomic reservation ledger” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C040-T07 · Failure and limit records:** Attach “Atomic reservation ledger” change/failure and bounds evidence where required; include uncovered “Reservations and contention time” and unresolved violations of “Concurrent operations cannot spend the same remaining capacity”.
- [ ] **UC-M07.05-C040-T08 · Evidence hygiene:** Check the “Atomic reservation ledger” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C040-T09 · Reproduction review:** Have the “Atomic reservation ledger” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C040-T10 · Acceptance linkage:** Link the “Atomic reservation ledger” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Per-tenant storage quotas

**Source delivery:** Charge active state, staging and retained artifacts to the appropriate quota owner.

**Source invariant:** Creating many small workloads cannot bypass aggregate storage limits.

**Source negative case:** A tenant accumulates uncharged backups.

**Source bounded quantities:** Tenant bytes and retained object count.

### UC-M07.05-C041 · Contract

**Original checklist item:** Specify per-tenant storage quotas inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C041-T01 · Scope statement:** Draft the operation boundary for “Per-tenant storage quotas” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Per-tenant storage quotas”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C041-T03 · Output inventory:** List the outputs of “Per-tenant storage quotas” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Per-tenant storage quotas”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C041-T05 · Prerequisite contract:** Map “Per-tenant storage quotas” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Per-tenant storage quotas”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C041-T07 · Invariant clause:** Add a normative clause for “Per-tenant storage quotas” that preserves “Creating many small workloads cannot bypass aggregate storage limits”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Per-tenant storage quotas”; include the source counterexample “A tenant accumulates uncharged backups” and the intended safe disposition.
- [ ] **UC-M07.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Tenant bytes and retained object count” in the “Per-tenant storage quotas” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C041-T10 · Contract review:** Review the “Per-tenant storage quotas” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C042 · Delivery

**Original checklist item:** Charge active state, staging and retained artifacts to the appropriate quota owner.

- [ ] **UC-M07.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Per-tenant storage quotas”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C042-T02 · Change plan:** Break the source delivery for “Per-tenant storage quotas” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Per-tenant storage quotas” that realizes this source instruction: Charge active state, staging and retained artifacts to the appropriate quota owner.
- [ ] **UC-M07.05-C042-T04 · Concrete realization:** Trace “Per-tenant storage quotas” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Per-tenant storage quotas” needed to preserve “Creating many small workloads cannot bypass aggregate storage limits”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C042-T06 · Dependency connection:** Connect the “Per-tenant storage quotas” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C042-T07 · Resource behavior:** Account for “Tenant bytes and retained object count” in “Per-tenant storage quotas”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C042-T08 · Delivery check:** Run the smallest real “Per-tenant storage quotas” path and its adverse fixture “A tenant accumulates uncharged backups”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C042-T09 · Patch review:** Review the “Per-tenant storage quotas” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C042-T10 · Delivery handoff:** Publish the “Per-tenant storage quotas” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Creating many small workloads cannot bypass aggregate storage limits. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Per-tenant storage quotas”; copy its required invariant exactly: “Creating many small workloads cannot bypass aggregate storage limits”.
- [ ] **UC-M07.05-C043-T02 · Observable terms:** Define each term in the “Per-tenant storage quotas” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C043-T03 · Precondition set:** List the preconditions under which “Creating many small workloads cannot bypass aggregate storage limits” must hold for “Per-tenant storage quotas”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C043-T04 · Transition coverage:** Map the “Per-tenant storage quotas” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Per-tenant storage quotas”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C043-T06 · Satisfying fixture:** Create a concrete “Per-tenant storage quotas” case that satisfies “Creating many small workloads cannot bypass aggregate storage limits”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C043-T07 · Violating fixture:** Create the source counterexample “A tenant accumulates uncharged backups” for “Per-tenant storage quotas”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C043-T08 · Enforcement evidence:** Exercise the “Per-tenant storage quotas” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C043-T09 · Regression linkage:** Link the “Per-tenant storage quotas” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Per-tenant storage quotas” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C044 · Integration

**Original checklist item:** Integrate per-tenant storage quotas with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Per-tenant storage quotas” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C044-T02 · Field mapping:** Map every “Per-tenant storage quotas” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Per-tenant storage quotas” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C044-T04 · Ownership agreement:** Specify who owns “Per-tenant storage quotas” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C044-T05 · Handoff implementation:** Connect “Per-tenant storage quotas” through the mapped seam using the real adapter or explicit specification reference; preserve “Creating many small workloads cannot bypass aggregate storage limits” across the handoff.
- [ ] **UC-M07.05-C044-T06 · Absent-input case:** Omit one required “Per-tenant storage quotas” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C044-T07 · Stale-input case:** Supply an outdated “Per-tenant storage quotas” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Per-tenant storage quotas” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C044-T09 · Valid integration trace:** Run a valid “Per-tenant storage quotas” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C044-T10 · Seam review:** Reconcile the “Per-tenant storage quotas” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for per-tenant storage quotas; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Per-tenant storage quotas” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C045-T02 · Expected-result oracle:** Specify the “Per-tenant storage quotas” expected result independently of the implementation output; include the property “Creating many small workloads cannot bypass aggregate storage limits” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C045-T03 · Fixture material:** Create the concrete “Per-tenant storage quotas” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C045-T04 · Target preparation:** Prepare the “Per-tenant storage quotas” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C045-T05 · Initial-state record:** Record the initial “Per-tenant storage quotas” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C045-T06 · Valid-path execution:** Execute the “Per-tenant storage quotas” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C045-T07 · Outcome comparison:** Compare every declared “Per-tenant storage quotas” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C045-T08 · State and bounds check:** Inspect the “Per-tenant storage quotas” ownership/state effects and actual use of “Tenant bytes and retained object count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C045-T09 · Repeatability check:** Repeat the same “Per-tenant storage quotas” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C045-T10 · Positive evidence:** Attach the “Per-tenant storage quotas” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C046 · Negative test

**Original checklist item:** Negative case: A tenant accumulates uncharged backups. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Per-tenant storage quotas” source counterexample: “A tenant accumulates uncharged backups”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Per-tenant storage quotas”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C046-T03 · Valid control:** Construct a valid “Per-tenant storage quotas” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C046-T04 · Minimal adverse input:** Derive the “Per-tenant storage quotas” adverse fixture from the control with the smallest documented change needed to reproduce “A tenant accumulates uncharged backups”; retain that change as reproducible data.
- [ ] **UC-M07.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Per-tenant storage quotas”; require “Creating many small workloads cannot bypass aggregate storage limits” and forbid a false-success verdict.
- [ ] **UC-M07.05-C046-T06 · Adverse execution:** Exercise the “Per-tenant storage quotas” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C046-T07 · Effect inspection:** Inspect “Per-tenant storage quotas” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C046-T08 · Refusal versus failure:** Confirm the “Per-tenant storage quotas” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C046-T09 · Reset and retention:** Restore only the disposable “Per-tenant storage quotas” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C046-T10 · Negative regression:** Register the “Per-tenant storage quotas” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C047 · Change / failure test

**Original checklist item:** Exercise per-tenant storage quotas when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C047-T01 · Scenario record:** Write the “Per-tenant storage quotas” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Creating many small workloads cannot bypass aggregate storage limits”.
- [ ] **UC-M07.05-C047-T02 · Baseline capture:** Create a known-valid “Per-tenant storage quotas” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C047-T03 · Injection map:** Locate the “Per-tenant storage quotas” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Per-tenant storage quotas” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C047-T05 · Controlled trigger:** Introduce the controlled “Per-tenant storage quotas” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C047-T06 · Intermediate inspection:** Inspect the “Per-tenant storage quotas” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Per-tenant storage quotas”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Per-tenant storage quotas” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C047-T09 · Repeat and compare:** Repeat the selected “Per-tenant storage quotas” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C047-T10 · Failure evidence:** Publish the “Per-tenant storage quotas” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C048 · Bounds

**Original checklist item:** Choose, document and test limits for tenant bytes and retained object count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Per-tenant storage quotas”: “Tenant bytes and retained object count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C048-T02 · Measurement method:** Choose how to observe each “Per-tenant storage quotas” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C048-T03 · Budget decision:** Select justified resource and input limits for “Per-tenant storage quotas”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Per-tenant storage quotas” cases for “Tenant bytes and retained object count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Per-tenant storage quotas” limit; preserve “Creating many small workloads cannot bypass aggregate storage limits”.
- [ ] **UC-M07.05-C048-T06 · Normal measurement:** Run or review the normal “Per-tenant storage quotas” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C048-T07 · At-limit measurement:** Exercise the “Per-tenant storage quotas” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C048-T08 · Over-limit measurement:** Exercise the “Per-tenant storage quotas” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C048-T09 · Uncovered-scope report:** List the “Per-tenant storage quotas” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C048-T10 · Limit evidence:** Publish the selected “Per-tenant storage quotas” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for per-tenant storage quotas with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C049-T01 · Event inventory:** List the “Per-tenant storage quotas” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Per-tenant storage quotas” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C049-T03 · Failure mapping:** Map each documented “Per-tenant storage quotas” refusal or error to a diagnostic outcome; include “A tenant accumulates uncharged backups” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C049-T04 · Emission path:** Add the “Per-tenant storage quotas” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C049-T05 · Redaction check:** Test “Per-tenant storage quotas” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C049-T06 · Output budget:** Set and exercise bounded “Per-tenant storage quotas” message size, rate and retention compatible with “Tenant bytes and retained object count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C049-T07 · Success/refusal fixtures:** Capture “Per-tenant storage quotas” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Per-tenant storage quotas” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C049-T09 · Operator review:** Read the “Per-tenant storage quotas” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C049-T10 · Diagnostic evidence:** Publish redacted “Per-tenant storage quotas” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for per-tenant storage quotas; label unexecuted checks as untested.

- [ ] **UC-M07.05-C050-T01 · Evidence inventory:** List the “Per-tenant storage quotas” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C050-T02 · Artifact references:** Record the exact “Per-tenant storage quotas” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C050-T03 · Fixture references:** Attach the “Per-tenant storage quotas” fixture IDs, input identities and oracle definition; preserve the source counterexample “A tenant accumulates uncharged backups” as a distinct evidence case.
- [ ] **UC-M07.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Per-tenant storage quotas”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C050-T05 · Environment record:** Record the actual “Per-tenant storage quotas” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C050-T06 · Expected versus observed:** Pair every “Per-tenant storage quotas” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C050-T07 · Failure and limit records:** Attach “Per-tenant storage quotas” change/failure and bounds evidence where required; include uncovered “Tenant bytes and retained object count” and unresolved violations of “Creating many small workloads cannot bypass aggregate storage limits”.
- [ ] **UC-M07.05-C050-T08 · Evidence hygiene:** Check the “Per-tenant storage quotas” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C050-T09 · Reproduction review:** Have the “Per-tenant storage quotas” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C050-T10 · Acceptance linkage:** Link the “Per-tenant storage quotas” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Growth rechecks

**Source delivery:** Recheck actual usage before growth or commit when estimates can change.

**Source invariant:** Unexpected growth triggers a safe refusal before destructive publication.

**Source negative case:** A checkpoint grows beyond its original reservation.

**Source bounded quantities:** Recheck interval and overrun allowance.

### UC-M07.05-C051 · Contract

**Original checklist item:** Specify growth rechecks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C051-T01 · Scope statement:** Draft the operation boundary for “Growth rechecks” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Growth rechecks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C051-T03 · Output inventory:** List the outputs of “Growth rechecks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Growth rechecks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C051-T05 · Prerequisite contract:** Map “Growth rechecks” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Growth rechecks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C051-T07 · Invariant clause:** Add a normative clause for “Growth rechecks” that preserves “Unexpected growth triggers a safe refusal before destructive publication”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Growth rechecks”; include the source counterexample “A checkpoint grows beyond its original reservation” and the intended safe disposition.
- [ ] **UC-M07.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recheck interval and overrun allowance” in the “Growth rechecks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C051-T10 · Contract review:** Review the “Growth rechecks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C052 · Delivery

**Original checklist item:** Recheck actual usage before growth or commit when estimates can change.

- [ ] **UC-M07.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Growth rechecks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C052-T02 · Change plan:** Break the source delivery for “Growth rechecks” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Growth rechecks” that realizes this source instruction: Recheck actual usage before growth or commit when estimates can change.
- [ ] **UC-M07.05-C052-T04 · Concrete realization:** Trace “Growth rechecks” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Growth rechecks” needed to preserve “Unexpected growth triggers a safe refusal before destructive publication”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C052-T06 · Dependency connection:** Connect the “Growth rechecks” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C052-T07 · Resource behavior:** Account for “Recheck interval and overrun allowance” in “Growth rechecks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C052-T08 · Delivery check:** Run the smallest real “Growth rechecks” path and its adverse fixture “A checkpoint grows beyond its original reservation”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C052-T09 · Patch review:** Review the “Growth rechecks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C052-T10 · Delivery handoff:** Publish the “Growth rechecks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unexpected growth triggers a safe refusal before destructive publication. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Growth rechecks”; copy its required invariant exactly: “Unexpected growth triggers a safe refusal before destructive publication”.
- [ ] **UC-M07.05-C053-T02 · Observable terms:** Define each term in the “Growth rechecks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C053-T03 · Precondition set:** List the preconditions under which “Unexpected growth triggers a safe refusal before destructive publication” must hold for “Growth rechecks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C053-T04 · Transition coverage:** Map the “Growth rechecks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Growth rechecks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C053-T06 · Satisfying fixture:** Create a concrete “Growth rechecks” case that satisfies “Unexpected growth triggers a safe refusal before destructive publication”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C053-T07 · Violating fixture:** Create the source counterexample “A checkpoint grows beyond its original reservation” for “Growth rechecks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C053-T08 · Enforcement evidence:** Exercise the “Growth rechecks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C053-T09 · Regression linkage:** Link the “Growth rechecks” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Growth rechecks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C054 · Integration

**Original checklist item:** Integrate growth rechecks with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Growth rechecks” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C054-T02 · Field mapping:** Map every “Growth rechecks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Growth rechecks” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C054-T04 · Ownership agreement:** Specify who owns “Growth rechecks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C054-T05 · Handoff implementation:** Connect “Growth rechecks” through the mapped seam using the real adapter or explicit specification reference; preserve “Unexpected growth triggers a safe refusal before destructive publication” across the handoff.
- [ ] **UC-M07.05-C054-T06 · Absent-input case:** Omit one required “Growth rechecks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C054-T07 · Stale-input case:** Supply an outdated “Growth rechecks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Growth rechecks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C054-T09 · Valid integration trace:** Run a valid “Growth rechecks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C054-T10 · Seam review:** Reconcile the “Growth rechecks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for growth rechecks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Growth rechecks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C055-T02 · Expected-result oracle:** Specify the “Growth rechecks” expected result independently of the implementation output; include the property “Unexpected growth triggers a safe refusal before destructive publication” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C055-T03 · Fixture material:** Create the concrete “Growth rechecks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C055-T04 · Target preparation:** Prepare the “Growth rechecks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C055-T05 · Initial-state record:** Record the initial “Growth rechecks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C055-T06 · Valid-path execution:** Execute the “Growth rechecks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C055-T07 · Outcome comparison:** Compare every declared “Growth rechecks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C055-T08 · State and bounds check:** Inspect the “Growth rechecks” ownership/state effects and actual use of “Recheck interval and overrun allowance”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C055-T09 · Repeatability check:** Repeat the same “Growth rechecks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C055-T10 · Positive evidence:** Attach the “Growth rechecks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C056 · Negative test

**Original checklist item:** Negative case: A checkpoint grows beyond its original reservation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Growth rechecks” source counterexample: “A checkpoint grows beyond its original reservation”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Growth rechecks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C056-T03 · Valid control:** Construct a valid “Growth rechecks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C056-T04 · Minimal adverse input:** Derive the “Growth rechecks” adverse fixture from the control with the smallest documented change needed to reproduce “A checkpoint grows beyond its original reservation”; retain that change as reproducible data.
- [ ] **UC-M07.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Growth rechecks”; require “Unexpected growth triggers a safe refusal before destructive publication” and forbid a false-success verdict.
- [ ] **UC-M07.05-C056-T06 · Adverse execution:** Exercise the “Growth rechecks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C056-T07 · Effect inspection:** Inspect “Growth rechecks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C056-T08 · Refusal versus failure:** Confirm the “Growth rechecks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C056-T09 · Reset and retention:** Restore only the disposable “Growth rechecks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C056-T10 · Negative regression:** Register the “Growth rechecks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C057 · Change / failure test

**Original checklist item:** Exercise growth rechecks when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C057-T01 · Scenario record:** Write the “Growth rechecks” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Unexpected growth triggers a safe refusal before destructive publication”.
- [ ] **UC-M07.05-C057-T02 · Baseline capture:** Create a known-valid “Growth rechecks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C057-T03 · Injection map:** Locate the “Growth rechecks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Growth rechecks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C057-T05 · Controlled trigger:** Introduce the controlled “Growth rechecks” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C057-T06 · Intermediate inspection:** Inspect the “Growth rechecks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Growth rechecks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Growth rechecks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C057-T09 · Repeat and compare:** Repeat the selected “Growth rechecks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C057-T10 · Failure evidence:** Publish the “Growth rechecks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C058 · Bounds

**Original checklist item:** Choose, document and test limits for recheck interval and overrun allowance; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Growth rechecks”: “Recheck interval and overrun allowance”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C058-T02 · Measurement method:** Choose how to observe each “Growth rechecks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C058-T03 · Budget decision:** Select justified resource and input limits for “Growth rechecks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Growth rechecks” cases for “Recheck interval and overrun allowance”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Growth rechecks” limit; preserve “Unexpected growth triggers a safe refusal before destructive publication”.
- [ ] **UC-M07.05-C058-T06 · Normal measurement:** Run or review the normal “Growth rechecks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C058-T07 · At-limit measurement:** Exercise the “Growth rechecks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C058-T08 · Over-limit measurement:** Exercise the “Growth rechecks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C058-T09 · Uncovered-scope report:** List the “Growth rechecks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C058-T10 · Limit evidence:** Publish the selected “Growth rechecks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for growth rechecks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C059-T01 · Event inventory:** List the “Growth rechecks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Growth rechecks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C059-T03 · Failure mapping:** Map each documented “Growth rechecks” refusal or error to a diagnostic outcome; include “A checkpoint grows beyond its original reservation” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C059-T04 · Emission path:** Add the “Growth rechecks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C059-T05 · Redaction check:** Test “Growth rechecks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C059-T06 · Output budget:** Set and exercise bounded “Growth rechecks” message size, rate and retention compatible with “Recheck interval and overrun allowance”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C059-T07 · Success/refusal fixtures:** Capture “Growth rechecks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Growth rechecks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C059-T09 · Operator review:** Read the “Growth rechecks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C059-T10 · Diagnostic evidence:** Publish redacted “Growth rechecks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for growth rechecks; label unexecuted checks as untested.

- [ ] **UC-M07.05-C060-T01 · Evidence inventory:** List the “Growth rechecks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C060-T02 · Artifact references:** Record the exact “Growth rechecks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C060-T03 · Fixture references:** Attach the “Growth rechecks” fixture IDs, input identities and oracle definition; preserve the source counterexample “A checkpoint grows beyond its original reservation” as a distinct evidence case.
- [ ] **UC-M07.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Growth rechecks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C060-T05 · Environment record:** Record the actual “Growth rechecks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C060-T06 · Expected versus observed:** Pair every “Growth rechecks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C060-T07 · Failure and limit records:** Attach “Growth rechecks” change/failure and bounds evidence where required; include uncovered “Recheck interval and overrun allowance” and unresolved violations of “Unexpected growth triggers a safe refusal before destructive publication”.
- [ ] **UC-M07.05-C060-T08 · Evidence hygiene:** Check the “Growth rechecks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C060-T09 · Reproduction review:** Have the “Growth rechecks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C060-T10 · Acceptance linkage:** Link the “Growth rechecks” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Low-disk failure behavior

**Source delivery:** Return a clear capacity refusal while preserving the old valid generation.

**Source invariant:** Disk exhaustion cannot trigger deletion of the only recovery copy.

**Source negative case:** ENOSPC occurs during replacement publication.

**Source bounded quantities:** Reserved recovery bytes and failure handling time.

### UC-M07.05-C061 · Contract

**Original checklist item:** Specify low-disk failure behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C061-T01 · Scope statement:** Draft the operation boundary for “Low-disk failure behavior” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Low-disk failure behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C061-T03 · Output inventory:** List the outputs of “Low-disk failure behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Low-disk failure behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C061-T05 · Prerequisite contract:** Map “Low-disk failure behavior” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Low-disk failure behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C061-T07 · Invariant clause:** Add a normative clause for “Low-disk failure behavior” that preserves “Disk exhaustion cannot trigger deletion of the only recovery copy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Low-disk failure behavior”; include the source counterexample “ENOSPC occurs during replacement publication” and the intended safe disposition.
- [ ] **UC-M07.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reserved recovery bytes and failure handling time” in the “Low-disk failure behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C061-T10 · Contract review:** Review the “Low-disk failure behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C062 · Delivery

**Original checklist item:** Return a clear capacity refusal while preserving the old valid generation.

- [ ] **UC-M07.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Low-disk failure behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C062-T02 · Change plan:** Break the source delivery for “Low-disk failure behavior” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Low-disk failure behavior” that realizes this source instruction: Return a clear capacity refusal while preserving the old valid generation.
- [ ] **UC-M07.05-C062-T04 · Concrete realization:** Trace “Low-disk failure behavior” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Low-disk failure behavior” needed to preserve “Disk exhaustion cannot trigger deletion of the only recovery copy”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C062-T06 · Dependency connection:** Connect the “Low-disk failure behavior” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C062-T07 · Resource behavior:** Account for “Reserved recovery bytes and failure handling time” in “Low-disk failure behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C062-T08 · Delivery check:** Run the smallest real “Low-disk failure behavior” path and its adverse fixture “ENOSPC occurs during replacement publication”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C062-T09 · Patch review:** Review the “Low-disk failure behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C062-T10 · Delivery handoff:** Publish the “Low-disk failure behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Disk exhaustion cannot trigger deletion of the only recovery copy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Low-disk failure behavior”; copy its required invariant exactly: “Disk exhaustion cannot trigger deletion of the only recovery copy”.
- [ ] **UC-M07.05-C063-T02 · Observable terms:** Define each term in the “Low-disk failure behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C063-T03 · Precondition set:** List the preconditions under which “Disk exhaustion cannot trigger deletion of the only recovery copy” must hold for “Low-disk failure behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C063-T04 · Transition coverage:** Map the “Low-disk failure behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Low-disk failure behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C063-T06 · Satisfying fixture:** Create a concrete “Low-disk failure behavior” case that satisfies “Disk exhaustion cannot trigger deletion of the only recovery copy”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C063-T07 · Violating fixture:** Create the source counterexample “ENOSPC occurs during replacement publication” for “Low-disk failure behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C063-T08 · Enforcement evidence:** Exercise the “Low-disk failure behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C063-T09 · Regression linkage:** Link the “Low-disk failure behavior” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Low-disk failure behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C064 · Integration

**Original checklist item:** Integrate low-disk failure behavior with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Low-disk failure behavior” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C064-T02 · Field mapping:** Map every “Low-disk failure behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Low-disk failure behavior” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C064-T04 · Ownership agreement:** Specify who owns “Low-disk failure behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C064-T05 · Handoff implementation:** Connect “Low-disk failure behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Disk exhaustion cannot trigger deletion of the only recovery copy” across the handoff.
- [ ] **UC-M07.05-C064-T06 · Absent-input case:** Omit one required “Low-disk failure behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C064-T07 · Stale-input case:** Supply an outdated “Low-disk failure behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Low-disk failure behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C064-T09 · Valid integration trace:** Run a valid “Low-disk failure behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C064-T10 · Seam review:** Reconcile the “Low-disk failure behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for low-disk failure behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Low-disk failure behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C065-T02 · Expected-result oracle:** Specify the “Low-disk failure behavior” expected result independently of the implementation output; include the property “Disk exhaustion cannot trigger deletion of the only recovery copy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C065-T03 · Fixture material:** Create the concrete “Low-disk failure behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C065-T04 · Target preparation:** Prepare the “Low-disk failure behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C065-T05 · Initial-state record:** Record the initial “Low-disk failure behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C065-T06 · Valid-path execution:** Execute the “Low-disk failure behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C065-T07 · Outcome comparison:** Compare every declared “Low-disk failure behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C065-T08 · State and bounds check:** Inspect the “Low-disk failure behavior” ownership/state effects and actual use of “Reserved recovery bytes and failure handling time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C065-T09 · Repeatability check:** Repeat the same “Low-disk failure behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C065-T10 · Positive evidence:** Attach the “Low-disk failure behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C066 · Negative test

**Original checklist item:** Negative case: ENOSPC occurs during replacement publication. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Low-disk failure behavior” source counterexample: “ENOSPC occurs during replacement publication”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Low-disk failure behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C066-T03 · Valid control:** Construct a valid “Low-disk failure behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C066-T04 · Minimal adverse input:** Derive the “Low-disk failure behavior” adverse fixture from the control with the smallest documented change needed to reproduce “ENOSPC occurs during replacement publication”; retain that change as reproducible data.
- [ ] **UC-M07.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Low-disk failure behavior”; require “Disk exhaustion cannot trigger deletion of the only recovery copy” and forbid a false-success verdict.
- [ ] **UC-M07.05-C066-T06 · Adverse execution:** Exercise the “Low-disk failure behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C066-T07 · Effect inspection:** Inspect “Low-disk failure behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C066-T08 · Refusal versus failure:** Confirm the “Low-disk failure behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C066-T09 · Reset and retention:** Restore only the disposable “Low-disk failure behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C066-T10 · Negative regression:** Register the “Low-disk failure behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C067 · Change / failure test

**Original checklist item:** Exercise low-disk failure behavior when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C067-T01 · Scenario record:** Write the “Low-disk failure behavior” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Disk exhaustion cannot trigger deletion of the only recovery copy”.
- [ ] **UC-M07.05-C067-T02 · Baseline capture:** Create a known-valid “Low-disk failure behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C067-T03 · Injection map:** Locate the “Low-disk failure behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Low-disk failure behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C067-T05 · Controlled trigger:** Introduce the controlled “Low-disk failure behavior” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C067-T06 · Intermediate inspection:** Inspect the “Low-disk failure behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Low-disk failure behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Low-disk failure behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C067-T09 · Repeat and compare:** Repeat the selected “Low-disk failure behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C067-T10 · Failure evidence:** Publish the “Low-disk failure behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C068 · Bounds

**Original checklist item:** Choose, document and test limits for reserved recovery bytes and failure handling time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Low-disk failure behavior”: “Reserved recovery bytes and failure handling time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C068-T02 · Measurement method:** Choose how to observe each “Low-disk failure behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C068-T03 · Budget decision:** Select justified resource and input limits for “Low-disk failure behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Low-disk failure behavior” cases for “Reserved recovery bytes and failure handling time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Low-disk failure behavior” limit; preserve “Disk exhaustion cannot trigger deletion of the only recovery copy”.
- [ ] **UC-M07.05-C068-T06 · Normal measurement:** Run or review the normal “Low-disk failure behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C068-T07 · At-limit measurement:** Exercise the “Low-disk failure behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C068-T08 · Over-limit measurement:** Exercise the “Low-disk failure behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C068-T09 · Uncovered-scope report:** List the “Low-disk failure behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C068-T10 · Limit evidence:** Publish the selected “Low-disk failure behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for low-disk failure behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C069-T01 · Event inventory:** List the “Low-disk failure behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Low-disk failure behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C069-T03 · Failure mapping:** Map each documented “Low-disk failure behavior” refusal or error to a diagnostic outcome; include “ENOSPC occurs during replacement publication” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C069-T04 · Emission path:** Add the “Low-disk failure behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C069-T05 · Redaction check:** Test “Low-disk failure behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C069-T06 · Output budget:** Set and exercise bounded “Low-disk failure behavior” message size, rate and retention compatible with “Reserved recovery bytes and failure handling time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C069-T07 · Success/refusal fixtures:** Capture “Low-disk failure behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Low-disk failure behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C069-T09 · Operator review:** Read the “Low-disk failure behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C069-T10 · Diagnostic evidence:** Publish redacted “Low-disk failure behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for low-disk failure behavior; label unexecuted checks as untested.

- [ ] **UC-M07.05-C070-T01 · Evidence inventory:** List the “Low-disk failure behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C070-T02 · Artifact references:** Record the exact “Low-disk failure behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C070-T03 · Fixture references:** Attach the “Low-disk failure behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “ENOSPC occurs during replacement publication” as a distinct evidence case.
- [ ] **UC-M07.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Low-disk failure behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C070-T05 · Environment record:** Record the actual “Low-disk failure behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C070-T06 · Expected versus observed:** Pair every “Low-disk failure behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C070-T07 · Failure and limit records:** Attach “Low-disk failure behavior” change/failure and bounds evidence where required; include uncovered “Reserved recovery bytes and failure handling time” and unresolved violations of “Disk exhaustion cannot trigger deletion of the only recovery copy”.
- [ ] **UC-M07.05-C070-T08 · Evidence hygiene:** Check the “Low-disk failure behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C070-T09 · Reproduction review:** Have the “Low-disk failure behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C070-T10 · Acceptance linkage:** Link the “Low-disk failure behavior” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Reservation release

**Source delivery:** Release or reconcile reservations after commit, abort and process loss.

**Source invariant:** Stale reservations cannot permanently hide available capacity.

**Source negative case:** A crashed worker leaves an unrecoverable reservation entry.

**Source bounded quantities:** Reservation lifetime and recovery scan size.

### UC-M07.05-C071 · Contract

**Original checklist item:** Specify reservation release inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C071-T01 · Scope statement:** Draft the operation boundary for “Reservation release” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reservation release”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C071-T03 · Output inventory:** List the outputs of “Reservation release” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Reservation release”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C071-T05 · Prerequisite contract:** Map “Reservation release” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Reservation release”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C071-T07 · Invariant clause:** Add a normative clause for “Reservation release” that preserves “Stale reservations cannot permanently hide available capacity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reservation release”; include the source counterexample “A crashed worker leaves an unrecoverable reservation entry” and the intended safe disposition.
- [ ] **UC-M07.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reservation lifetime and recovery scan size” in the “Reservation release” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C071-T10 · Contract review:** Review the “Reservation release” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C072 · Delivery

**Original checklist item:** Release or reconcile reservations after commit, abort and process loss.

- [ ] **UC-M07.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reservation release”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C072-T02 · Change plan:** Break the source delivery for “Reservation release” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Reservation release” that realizes this source instruction: Release or reconcile reservations after commit, abort and process loss.
- [ ] **UC-M07.05-C072-T04 · Concrete realization:** Trace “Reservation release” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reservation release” needed to preserve “Stale reservations cannot permanently hide available capacity”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C072-T06 · Dependency connection:** Connect the “Reservation release” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C072-T07 · Resource behavior:** Account for “Reservation lifetime and recovery scan size” in “Reservation release”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C072-T08 · Delivery check:** Run the smallest real “Reservation release” path and its adverse fixture “A crashed worker leaves an unrecoverable reservation entry”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C072-T09 · Patch review:** Review the “Reservation release” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C072-T10 · Delivery handoff:** Publish the “Reservation release” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stale reservations cannot permanently hide available capacity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Reservation release”; copy its required invariant exactly: “Stale reservations cannot permanently hide available capacity”.
- [ ] **UC-M07.05-C073-T02 · Observable terms:** Define each term in the “Reservation release” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C073-T03 · Precondition set:** List the preconditions under which “Stale reservations cannot permanently hide available capacity” must hold for “Reservation release”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C073-T04 · Transition coverage:** Map the “Reservation release” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reservation release”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C073-T06 · Satisfying fixture:** Create a concrete “Reservation release” case that satisfies “Stale reservations cannot permanently hide available capacity”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C073-T07 · Violating fixture:** Create the source counterexample “A crashed worker leaves an unrecoverable reservation entry” for “Reservation release”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C073-T08 · Enforcement evidence:** Exercise the “Reservation release” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C073-T09 · Regression linkage:** Link the “Reservation release” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Reservation release” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C074 · Integration

**Original checklist item:** Integrate reservation release with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reservation release” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C074-T02 · Field mapping:** Map every “Reservation release” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Reservation release” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C074-T04 · Ownership agreement:** Specify who owns “Reservation release” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C074-T05 · Handoff implementation:** Connect “Reservation release” through the mapped seam using the real adapter or explicit specification reference; preserve “Stale reservations cannot permanently hide available capacity” across the handoff.
- [ ] **UC-M07.05-C074-T06 · Absent-input case:** Omit one required “Reservation release” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C074-T07 · Stale-input case:** Supply an outdated “Reservation release” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Reservation release” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C074-T09 · Valid integration trace:** Run a valid “Reservation release” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C074-T10 · Seam review:** Reconcile the “Reservation release” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reservation release; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reservation release” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C075-T02 · Expected-result oracle:** Specify the “Reservation release” expected result independently of the implementation output; include the property “Stale reservations cannot permanently hide available capacity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C075-T03 · Fixture material:** Create the concrete “Reservation release” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C075-T04 · Target preparation:** Prepare the “Reservation release” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C075-T05 · Initial-state record:** Record the initial “Reservation release” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C075-T06 · Valid-path execution:** Execute the “Reservation release” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C075-T07 · Outcome comparison:** Compare every declared “Reservation release” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C075-T08 · State and bounds check:** Inspect the “Reservation release” ownership/state effects and actual use of “Reservation lifetime and recovery scan size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C075-T09 · Repeatability check:** Repeat the same “Reservation release” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C075-T10 · Positive evidence:** Attach the “Reservation release” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C076 · Negative test

**Original checklist item:** Negative case: A crashed worker leaves an unrecoverable reservation entry. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Reservation release” source counterexample: “A crashed worker leaves an unrecoverable reservation entry”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Reservation release”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C076-T03 · Valid control:** Construct a valid “Reservation release” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C076-T04 · Minimal adverse input:** Derive the “Reservation release” adverse fixture from the control with the smallest documented change needed to reproduce “A crashed worker leaves an unrecoverable reservation entry”; retain that change as reproducible data.
- [ ] **UC-M07.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reservation release”; require “Stale reservations cannot permanently hide available capacity” and forbid a false-success verdict.
- [ ] **UC-M07.05-C076-T06 · Adverse execution:** Exercise the “Reservation release” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C076-T07 · Effect inspection:** Inspect “Reservation release” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C076-T08 · Refusal versus failure:** Confirm the “Reservation release” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C076-T09 · Reset and retention:** Restore only the disposable “Reservation release” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C076-T10 · Negative regression:** Register the “Reservation release” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C077 · Change / failure test

**Original checklist item:** Exercise reservation release when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C077-T01 · Scenario record:** Write the “Reservation release” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Stale reservations cannot permanently hide available capacity”.
- [ ] **UC-M07.05-C077-T02 · Baseline capture:** Create a known-valid “Reservation release” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C077-T03 · Injection map:** Locate the “Reservation release” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Reservation release” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C077-T05 · Controlled trigger:** Introduce the controlled “Reservation release” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C077-T06 · Intermediate inspection:** Inspect the “Reservation release” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reservation release”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Reservation release” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C077-T09 · Repeat and compare:** Repeat the selected “Reservation release” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C077-T10 · Failure evidence:** Publish the “Reservation release” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C078 · Bounds

**Original checklist item:** Choose, document and test limits for reservation lifetime and recovery scan size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Reservation release”: “Reservation lifetime and recovery scan size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C078-T02 · Measurement method:** Choose how to observe each “Reservation release” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C078-T03 · Budget decision:** Select justified resource and input limits for “Reservation release”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reservation release” cases for “Reservation lifetime and recovery scan size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reservation release” limit; preserve “Stale reservations cannot permanently hide available capacity”.
- [ ] **UC-M07.05-C078-T06 · Normal measurement:** Run or review the normal “Reservation release” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C078-T07 · At-limit measurement:** Exercise the “Reservation release” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C078-T08 · Over-limit measurement:** Exercise the “Reservation release” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C078-T09 · Uncovered-scope report:** List the “Reservation release” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C078-T10 · Limit evidence:** Publish the selected “Reservation release” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reservation release with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C079-T01 · Event inventory:** List the “Reservation release” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Reservation release” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C079-T03 · Failure mapping:** Map each documented “Reservation release” refusal or error to a diagnostic outcome; include “A crashed worker leaves an unrecoverable reservation entry” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C079-T04 · Emission path:** Add the “Reservation release” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C079-T05 · Redaction check:** Test “Reservation release” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C079-T06 · Output budget:** Set and exercise bounded “Reservation release” message size, rate and retention compatible with “Reservation lifetime and recovery scan size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C079-T07 · Success/refusal fixtures:** Capture “Reservation release” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reservation release” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C079-T09 · Operator review:** Read the “Reservation release” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C079-T10 · Diagnostic evidence:** Publish redacted “Reservation release” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reservation release; label unexecuted checks as untested.

- [ ] **UC-M07.05-C080-T01 · Evidence inventory:** List the “Reservation release” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C080-T02 · Artifact references:** Record the exact “Reservation release” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C080-T03 · Fixture references:** Attach the “Reservation release” fixture IDs, input identities and oracle definition; preserve the source counterexample “A crashed worker leaves an unrecoverable reservation entry” as a distinct evidence case.
- [ ] **UC-M07.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reservation release”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C080-T05 · Environment record:** Record the actual “Reservation release” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C080-T06 · Expected versus observed:** Pair every “Reservation release” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C080-T07 · Failure and limit records:** Attach “Reservation release” change/failure and bounds evidence where required; include uncovered “Reservation lifetime and recovery scan size” and unresolved violations of “Stale reservations cannot permanently hide available capacity”.
- [ ] **UC-M07.05-C080-T08 · Evidence hygiene:** Check the “Reservation release” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C080-T09 · Reproduction review:** Have the “Reservation release” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C080-T10 · Acceptance linkage:** Link the “Reservation release” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Capacity diagnostics

**Source delivery:** Expose free, reserved, used and required bytes with the affected volume.

**Source invariant:** Operators can identify why an operation cannot safely proceed.

**Source negative case:** A low-space error reports no required or available byte counts.

**Source bounded quantities:** Diagnostic bytes and refresh rate.

### UC-M07.05-C081 · Contract

**Original checklist item:** Specify capacity diagnostics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C081-T01 · Scope statement:** Draft the operation boundary for “Capacity diagnostics” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capacity diagnostics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C081-T03 · Output inventory:** List the outputs of “Capacity diagnostics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Capacity diagnostics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C081-T05 · Prerequisite contract:** Map “Capacity diagnostics” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Capacity diagnostics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C081-T07 · Invariant clause:** Add a normative clause for “Capacity diagnostics” that preserves “Operators can identify why an operation cannot safely proceed”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capacity diagnostics”; include the source counterexample “A low-space error reports no required or available byte counts” and the intended safe disposition.
- [ ] **UC-M07.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Diagnostic bytes and refresh rate” in the “Capacity diagnostics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C081-T10 · Contract review:** Review the “Capacity diagnostics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C082 · Delivery

**Original checklist item:** Expose free, reserved, used and required bytes with the affected volume.

- [ ] **UC-M07.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capacity diagnostics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C082-T02 · Change plan:** Break the source delivery for “Capacity diagnostics” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Capacity diagnostics” that realizes this source instruction: Expose free, reserved, used and required bytes with the affected volume.
- [ ] **UC-M07.05-C082-T04 · Concrete realization:** Trace “Capacity diagnostics” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M07.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capacity diagnostics” needed to preserve “Operators can identify why an operation cannot safely proceed”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C082-T06 · Dependency connection:** Connect the “Capacity diagnostics” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C082-T07 · Resource behavior:** Account for “Diagnostic bytes and refresh rate” in “Capacity diagnostics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C082-T08 · Delivery check:** Run the smallest real “Capacity diagnostics” path and its adverse fixture “A low-space error reports no required or available byte counts”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C082-T09 · Patch review:** Review the “Capacity diagnostics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C082-T10 · Delivery handoff:** Publish the “Capacity diagnostics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Operators can identify why an operation cannot safely proceed. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Capacity diagnostics”; copy its required invariant exactly: “Operators can identify why an operation cannot safely proceed”.
- [ ] **UC-M07.05-C083-T02 · Observable terms:** Define each term in the “Capacity diagnostics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C083-T03 · Precondition set:** List the preconditions under which “Operators can identify why an operation cannot safely proceed” must hold for “Capacity diagnostics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C083-T04 · Transition coverage:** Map the “Capacity diagnostics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capacity diagnostics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C083-T06 · Satisfying fixture:** Create a concrete “Capacity diagnostics” case that satisfies “Operators can identify why an operation cannot safely proceed”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C083-T07 · Violating fixture:** Create the source counterexample “A low-space error reports no required or available byte counts” for “Capacity diagnostics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C083-T08 · Enforcement evidence:** Exercise the “Capacity diagnostics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C083-T09 · Regression linkage:** Link the “Capacity diagnostics” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Capacity diagnostics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C084 · Integration

**Original checklist item:** Integrate capacity diagnostics with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capacity diagnostics” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C084-T02 · Field mapping:** Map every “Capacity diagnostics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Capacity diagnostics” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C084-T04 · Ownership agreement:** Specify who owns “Capacity diagnostics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C084-T05 · Handoff implementation:** Connect “Capacity diagnostics” through the mapped seam using the real adapter or explicit specification reference; preserve “Operators can identify why an operation cannot safely proceed” across the handoff.
- [ ] **UC-M07.05-C084-T06 · Absent-input case:** Omit one required “Capacity diagnostics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C084-T07 · Stale-input case:** Supply an outdated “Capacity diagnostics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Capacity diagnostics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C084-T09 · Valid integration trace:** Run a valid “Capacity diagnostics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C084-T10 · Seam review:** Reconcile the “Capacity diagnostics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capacity diagnostics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capacity diagnostics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C085-T02 · Expected-result oracle:** Specify the “Capacity diagnostics” expected result independently of the implementation output; include the property “Operators can identify why an operation cannot safely proceed” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C085-T03 · Fixture material:** Create the concrete “Capacity diagnostics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C085-T04 · Target preparation:** Prepare the “Capacity diagnostics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C085-T05 · Initial-state record:** Record the initial “Capacity diagnostics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C085-T06 · Valid-path execution:** Execute the “Capacity diagnostics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C085-T07 · Outcome comparison:** Compare every declared “Capacity diagnostics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C085-T08 · State and bounds check:** Inspect the “Capacity diagnostics” ownership/state effects and actual use of “Diagnostic bytes and refresh rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C085-T09 · Repeatability check:** Repeat the same “Capacity diagnostics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C085-T10 · Positive evidence:** Attach the “Capacity diagnostics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C086 · Negative test

**Original checklist item:** Negative case: A low-space error reports no required or available byte counts. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Capacity diagnostics” source counterexample: “A low-space error reports no required or available byte counts”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Capacity diagnostics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C086-T03 · Valid control:** Construct a valid “Capacity diagnostics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C086-T04 · Minimal adverse input:** Derive the “Capacity diagnostics” adverse fixture from the control with the smallest documented change needed to reproduce “A low-space error reports no required or available byte counts”; retain that change as reproducible data.
- [ ] **UC-M07.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capacity diagnostics”; require “Operators can identify why an operation cannot safely proceed” and forbid a false-success verdict.
- [ ] **UC-M07.05-C086-T06 · Adverse execution:** Exercise the “Capacity diagnostics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C086-T07 · Effect inspection:** Inspect “Capacity diagnostics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C086-T08 · Refusal versus failure:** Confirm the “Capacity diagnostics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C086-T09 · Reset and retention:** Restore only the disposable “Capacity diagnostics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C086-T10 · Negative regression:** Register the “Capacity diagnostics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C087 · Change / failure test

**Original checklist item:** Exercise capacity diagnostics when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C087-T01 · Scenario record:** Write the “Capacity diagnostics” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Operators can identify why an operation cannot safely proceed”.
- [ ] **UC-M07.05-C087-T02 · Baseline capture:** Create a known-valid “Capacity diagnostics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C087-T03 · Injection map:** Locate the “Capacity diagnostics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Capacity diagnostics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C087-T05 · Controlled trigger:** Introduce the controlled “Capacity diagnostics” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C087-T06 · Intermediate inspection:** Inspect the “Capacity diagnostics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capacity diagnostics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Capacity diagnostics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C087-T09 · Repeat and compare:** Repeat the selected “Capacity diagnostics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C087-T10 · Failure evidence:** Publish the “Capacity diagnostics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C088 · Bounds

**Original checklist item:** Choose, document and test limits for diagnostic bytes and refresh rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Capacity diagnostics”: “Diagnostic bytes and refresh rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C088-T02 · Measurement method:** Choose how to observe each “Capacity diagnostics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C088-T03 · Budget decision:** Select justified resource and input limits for “Capacity diagnostics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capacity diagnostics” cases for “Diagnostic bytes and refresh rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capacity diagnostics” limit; preserve “Operators can identify why an operation cannot safely proceed”.
- [ ] **UC-M07.05-C088-T06 · Normal measurement:** Run or review the normal “Capacity diagnostics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C088-T07 · At-limit measurement:** Exercise the “Capacity diagnostics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C088-T08 · Over-limit measurement:** Exercise the “Capacity diagnostics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C088-T09 · Uncovered-scope report:** List the “Capacity diagnostics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C088-T10 · Limit evidence:** Publish the selected “Capacity diagnostics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capacity diagnostics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C089-T01 · Event inventory:** List the “Capacity diagnostics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Capacity diagnostics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C089-T03 · Failure mapping:** Map each documented “Capacity diagnostics” refusal or error to a diagnostic outcome; include “A low-space error reports no required or available byte counts” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C089-T04 · Emission path:** Add the “Capacity diagnostics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C089-T05 · Redaction check:** Test “Capacity diagnostics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C089-T06 · Output budget:** Set and exercise bounded “Capacity diagnostics” message size, rate and retention compatible with “Diagnostic bytes and refresh rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C089-T07 · Success/refusal fixtures:** Capture “Capacity diagnostics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capacity diagnostics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C089-T09 · Operator review:** Read the “Capacity diagnostics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C089-T10 · Diagnostic evidence:** Publish redacted “Capacity diagnostics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capacity diagnostics; label unexecuted checks as untested.

- [ ] **UC-M07.05-C090-T01 · Evidence inventory:** List the “Capacity diagnostics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C090-T02 · Artifact references:** Record the exact “Capacity diagnostics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C090-T03 · Fixture references:** Attach the “Capacity diagnostics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A low-space error reports no required or available byte counts” as a distinct evidence case.
- [ ] **UC-M07.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capacity diagnostics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C090-T05 · Environment record:** Record the actual “Capacity diagnostics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C090-T06 · Expected versus observed:** Pair every “Capacity diagnostics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C090-T07 · Failure and limit records:** Attach “Capacity diagnostics” change/failure and bounds evidence where required; include uncovered “Diagnostic bytes and refresh rate” and unresolved violations of “Operators can identify why an operation cannot safely proceed”.
- [ ] **UC-M07.05-C090-T08 · Evidence hygiene:** Check the “Capacity diagnostics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C090-T09 · Reproduction review:** Have the “Capacity diagnostics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C090-T10 · Acceptance linkage:** Link the “Capacity diagnostics” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Capacity fault qualification

**Source delivery:** Inject low-space and full-disk conditions at each staged mutation boundary.

**Source invariant:** Recovery remains usable and no destructive commit precedes capacity checks.

**Source negative case:** A simulated full disk leaves no complete old or new generation.

**Source bounded quantities:** Fault points and repeated storage trials.

### UC-M07.05-C091 · Contract

**Original checklist item:** Specify capacity fault qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M07.05-C091-T01 · Scope statement:** Draft the operation boundary for “Capacity fault qualification” within Workspace capacity reservation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M07.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capacity fault qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M07.05-C091-T03 · Output inventory:** List the outputs of “Capacity fault qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M07.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Capacity fault qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M07.05-C091-T05 · Prerequisite contract:** Map “Capacity fault qualification” to the source component prerequisites (UC-M03.05, UC-M07.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M07.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Capacity fault qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M07.05-C091-T07 · Invariant clause:** Add a normative clause for “Capacity fault qualification” that preserves “Recovery remains usable and no destructive commit precedes capacity checks”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M07.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capacity fault qualification”; include the source counterexample “A simulated full disk leaves no complete old or new generation” and the intended safe disposition.
- [ ] **UC-M07.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fault points and repeated storage trials” in the “Capacity fault qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M07.05-C091-T10 · Contract review:** Review the “Capacity fault qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M07.05-C092 · Delivery

**Original checklist item:** Inject low-space and full-disk conditions at each staged mutation boundary.

- [ ] **UC-M07.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capacity fault qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M07.05-C092-T02 · Change plan:** Break the source delivery for “Capacity fault qualification” into concrete edit targets and reviewable outputs; keep the UC-M07.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M07.05-C092-T03 · Core artifact:** Create the “Capacity fault qualification” fixture or harness for this source instruction: Inject low-space and full-disk conditions at each staged mutation boundary.
- [ ] **UC-M07.05-C092-T04 · Concrete realization:** Connect the “Capacity fault qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M07.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capacity fault qualification” needed to preserve “Recovery remains usable and no destructive commit precedes capacity checks”; record an enforcement gap where only a model exists.
- [ ] **UC-M07.05-C092-T06 · Dependency connection:** Connect the “Capacity fault qualification” implementation to aggregate quotas, staging reservations and retained recovery generations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M07.05-C092-T07 · Resource behavior:** Account for “Fault points and repeated storage trials” in “Capacity fault qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M07.05-C092-T08 · Delivery check:** Run the smallest real “Capacity fault qualification” path and its adverse fixture “A simulated full disk leaves no complete old or new generation”; retain actual output, state effects and final disposition.
- [ ] **UC-M07.05-C092-T09 · Patch review:** Review the “Capacity fault qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M07.05-C092-T10 · Delivery handoff:** Publish the “Capacity fault qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M07.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery remains usable and no destructive commit precedes capacity checks. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M07.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Capacity fault qualification”; copy its required invariant exactly: “Recovery remains usable and no destructive commit precedes capacity checks”.
- [ ] **UC-M07.05-C093-T02 · Observable terms:** Define each term in the “Capacity fault qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M07.05-C093-T03 · Precondition set:** List the preconditions under which “Recovery remains usable and no destructive commit precedes capacity checks” must hold for “Capacity fault qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M07.05-C093-T04 · Transition coverage:** Map the “Capacity fault qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M07.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capacity fault qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M07.05-C093-T06 · Satisfying fixture:** Create a concrete “Capacity fault qualification” case that satisfies “Recovery remains usable and no destructive commit precedes capacity checks”; record its expected observation before running the assertion or review.
- [ ] **UC-M07.05-C093-T07 · Violating fixture:** Create the source counterexample “A simulated full disk leaves no complete old or new generation” for “Capacity fault qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M07.05-C093-T08 · Enforcement evidence:** Exercise the “Capacity fault qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M07.05-C093-T09 · Regression linkage:** Link the “Capacity fault qualification” property to changes in aggregate quotas, staging reservations and retained recovery generations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M07.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Capacity fault qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M07.05-C094 · Integration

**Original checklist item:** Integrate capacity fault qualification with aggregate quotas, staging reservations and retained recovery generations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M07.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capacity fault qualification” across aggregate quotas, staging reservations and retained recovery generations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M07.05-C094-T02 · Field mapping:** Map every “Capacity fault qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M07.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Capacity fault qualification” (source dependency list: UC-M03.05, UC-M07.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M07.05-C094-T04 · Ownership agreement:** Specify who owns “Capacity fault qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M07.05-C094-T05 · Handoff implementation:** Connect “Capacity fault qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery remains usable and no destructive commit precedes capacity checks” across the handoff.
- [ ] **UC-M07.05-C094-T06 · Absent-input case:** Omit one required “Capacity fault qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M07.05-C094-T07 · Stale-input case:** Supply an outdated “Capacity fault qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M07.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Capacity fault qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M07.05-C094-T09 · Valid integration trace:** Run a valid “Capacity fault qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M07.05-C094-T10 · Seam review:** Reconcile the “Capacity fault qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M07.05-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capacity fault qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M07.05-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capacity fault qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M07.05-C095-T02 · Expected-result oracle:** Specify the “Capacity fault qualification” expected result independently of the implementation output; include the property “Recovery remains usable and no destructive commit precedes capacity checks” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M07.05-C095-T03 · Fixture material:** Create the concrete “Capacity fault qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M07.05-C095-T04 · Target preparation:** Prepare the “Capacity fault qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M07.05-C095-T05 · Initial-state record:** Record the initial “Capacity fault qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M07.05-C095-T06 · Valid-path execution:** Execute the “Capacity fault qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M07.05-C095-T07 · Outcome comparison:** Compare every declared “Capacity fault qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M07.05-C095-T08 · State and bounds check:** Inspect the “Capacity fault qualification” ownership/state effects and actual use of “Fault points and repeated storage trials”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M07.05-C095-T09 · Repeatability check:** Repeat the same “Capacity fault qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M07.05-C095-T10 · Positive evidence:** Attach the “Capacity fault qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M07.05-C096 · Negative test

**Original checklist item:** Negative case: A simulated full disk leaves no complete old or new generation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M07.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Capacity fault qualification” source counterexample: “A simulated full disk leaves no complete old or new generation”; state which precondition or invariant it challenges.
- [ ] **UC-M07.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Capacity fault qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M07.05-C096-T03 · Valid control:** Construct a valid “Capacity fault qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M07.05-C096-T04 · Minimal adverse input:** Derive the “Capacity fault qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A simulated full disk leaves no complete old or new generation”; retain that change as reproducible data.
- [ ] **UC-M07.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capacity fault qualification”; require “Recovery remains usable and no destructive commit precedes capacity checks” and forbid a false-success verdict.
- [ ] **UC-M07.05-C096-T06 · Adverse execution:** Exercise the “Capacity fault qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M07.05-C096-T07 · Effect inspection:** Inspect “Capacity fault qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M07.05-C096-T08 · Refusal versus failure:** Confirm the “Capacity fault qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M07.05-C096-T09 · Reset and retention:** Restore only the disposable “Capacity fault qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M07.05-C096-T10 · Negative regression:** Register the “Capacity fault qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M07.05-C097 · Change / failure test

**Original checklist item:** Exercise capacity fault qualification when free disk space falls after reservation but before a destructive commit point; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.05-C097-T01 · Scenario record:** Write the “Capacity fault qualification” change/failure scenario exactly as supplied: free disk space falls after reservation but before a destructive commit point; identify the property that must remain true: “Recovery remains usable and no destructive commit precedes capacity checks”.
- [ ] **UC-M07.05-C097-T02 · Baseline capture:** Create a known-valid “Capacity fault qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.05-C097-T03 · Injection map:** Locate the “Capacity fault qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Capacity fault qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.05-C097-T05 · Controlled trigger:** Introduce the controlled “Capacity fault qualification” scenario in the disposable fixture: free disk space falls after reservation but before a destructive commit point; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.05-C097-T06 · Intermediate inspection:** Inspect the “Capacity fault qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.05-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capacity fault qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Capacity fault qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.05-C097-T09 · Repeat and compare:** Repeat the selected “Capacity fault qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.05-C097-T10 · Failure evidence:** Publish the “Capacity fault qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M07.05-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fault points and repeated storage trials; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M07.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Capacity fault qualification”: “Fault points and repeated storage trials”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M07.05-C098-T02 · Measurement method:** Choose how to observe each “Capacity fault qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M07.05-C098-T03 · Budget decision:** Select justified resource and input limits for “Capacity fault qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M07.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capacity fault qualification” cases for “Fault points and repeated storage trials”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M07.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capacity fault qualification” limit; preserve “Recovery remains usable and no destructive commit precedes capacity checks”.
- [ ] **UC-M07.05-C098-T06 · Normal measurement:** Run or review the normal “Capacity fault qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M07.05-C098-T07 · At-limit measurement:** Exercise the “Capacity fault qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M07.05-C098-T08 · Over-limit measurement:** Exercise the “Capacity fault qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M07.05-C098-T09 · Uncovered-scope report:** List the “Capacity fault qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M07.05-C098-T10 · Limit evidence:** Publish the selected “Capacity fault qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M07.05-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capacity fault qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M07.05-C099-T01 · Event inventory:** List the “Capacity fault qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M07.05-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Capacity fault qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M07.05-C099-T03 · Failure mapping:** Map each documented “Capacity fault qualification” refusal or error to a diagnostic outcome; include “A simulated full disk leaves no complete old or new generation” and prohibit conversion into a success message.
- [ ] **UC-M07.05-C099-T04 · Emission path:** Add the “Capacity fault qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M07.05-C099-T05 · Redaction check:** Test “Capacity fault qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M07.05-C099-T06 · Output budget:** Set and exercise bounded “Capacity fault qualification” message size, rate and retention compatible with “Fault points and repeated storage trials”; define truncation behavior that preserves the final reason.
- [ ] **UC-M07.05-C099-T07 · Success/refusal fixtures:** Capture “Capacity fault qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M07.05-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capacity fault qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M07.05-C099-T09 · Operator review:** Read the “Capacity fault qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M07.05-C099-T10 · Diagnostic evidence:** Publish redacted “Capacity fault qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M07.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capacity fault qualification; label unexecuted checks as untested.

- [ ] **UC-M07.05-C100-T01 · Evidence inventory:** List the “Capacity fault qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M07.05-C100-T02 · Artifact references:** Record the exact “Capacity fault qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M07.05-C100-T03 · Fixture references:** Attach the “Capacity fault qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A simulated full disk leaves no complete old or new generation” as a distinct evidence case.
- [ ] **UC-M07.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capacity fault qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M07.05-C100-T05 · Environment record:** Record the actual “Capacity fault qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M07.05-C100-T06 · Expected versus observed:** Pair every “Capacity fault qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M07.05-C100-T07 · Failure and limit records:** Attach “Capacity fault qualification” change/failure and bounds evidence where required; include uncovered “Fault points and repeated storage trials” and unresolved violations of “Recovery remains usable and no destructive commit precedes capacity checks”.
- [ ] **UC-M07.05-C100-T08 · Evidence hygiene:** Check the “Capacity fault qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M07.05-C100-T09 · Reproduction review:** Have the “Capacity fault qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M07.05-C100-T10 · Acceptance linkage:** Link the “Capacity fault qualification” evidence to its parent and UC-M07.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

