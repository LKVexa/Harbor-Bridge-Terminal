# UC-M10.04 — Unified live health view

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/10.md)

| Field | Preserved source value |
|---|---|
| Workstream | 10. Observability and operator experience |
| Milestone | C |
| Priority | P1 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M05.05](../05/UC-M05.05.md), [UC-M10.02](../10/UC-M10.02.md), [UC-M10.03](../10/UC-M10.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4]. |

## Original requirement

Present boot/readiness/liveness/evidence status separately with last-progress age, current phase and actual blocked reason.

**Original acceptance criterion:** A stale or stopped workload cannot continue showing healthy merely because its last witness passed.

**Source trace:** Original checklist `UC100/c/10/UC-M10.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 937–947 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Health data model

**Source delivery:** Represent boot, readiness, liveness, semantic and evidence status as separate fields.

**Source invariant:** One green status cannot stand in for all health dimensions.

**Source negative case:** A passing witness forces every health indicator to healthy.

**Source bounded quantities:** Status fields and payload bytes.

### UC-M10.04-C001 · Contract

**Original checklist item:** Specify the operator workflow for health data model, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C001-T01 · Scope statement:** Describe the operator journey for “Health data model”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Health data model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C001-T03 · Output inventory:** List the outputs of “Health data model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Health data model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C001-T05 · Prerequisite contract:** Map “Health data model” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Health data model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C001-T07 · Invariant clause:** Add a normative clause for “Health data model” that preserves “One green status cannot stand in for all health dimensions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Health data model”; include the source counterexample “A passing witness forces every health indicator to healthy” and the intended safe disposition.
- [ ] **UC-M10.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Status fields and payload bytes” in the “Health data model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C001-T10 · Contract review:** Review the “Health data model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C002 · Delivery

**Original checklist item:** Represent boot, readiness, liveness, semantic and evidence status as separate fields.

- [ ] **UC-M10.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Health data model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C002-T02 · Change plan:** Break the source delivery for “Health data model” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C002-T03 · Core artifact:** Create the “Health data model” model, schema or inventory that realizes this source instruction: Represent boot, readiness, liveness, semantic and evidence status as separate fields.
- [ ] **UC-M10.04-C002-T04 · Concrete realization:** Populate “Health data model” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M10.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Health data model” needed to preserve “One green status cannot stand in for all health dimensions”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C002-T06 · Dependency connection:** Connect the “Health data model” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C002-T07 · Resource behavior:** Account for “Status fields and payload bytes” in “Health data model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C002-T08 · Delivery check:** Exercise the “Health data model” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C002-T09 · Patch review:** Review the “Health data model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C002-T10 · Delivery handoff:** Publish the “Health data model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One green status cannot stand in for all health dimensions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Health data model”; copy its required invariant exactly: “One green status cannot stand in for all health dimensions”.
- [ ] **UC-M10.04-C003-T02 · Observable terms:** Define each term in the “Health data model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C003-T03 · Precondition set:** List the preconditions under which “One green status cannot stand in for all health dimensions” must hold for “Health data model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C003-T04 · Transition coverage:** Map the “Health data model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Health data model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C003-T06 · Satisfying fixture:** Create a concrete “Health data model” case that satisfies “One green status cannot stand in for all health dimensions”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C003-T07 · Violating fixture:** Create the source counterexample “A passing witness forces every health indicator to healthy” for “Health data model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C003-T08 · Enforcement evidence:** Exercise the “Health data model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C003-T09 · Regression linkage:** Link the “Health data model” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Health data model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C004 · Integration

**Original checklist item:** Integrate health data model with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Health data model” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C004-T02 · Field mapping:** Map every “Health data model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Health data model” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C004-T04 · Ownership agreement:** Specify who owns “Health data model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C004-T05 · Handoff implementation:** Connect “Health data model” through the mapped seam using the real adapter or explicit specification reference; preserve “One green status cannot stand in for all health dimensions” across the handoff.
- [ ] **UC-M10.04-C004-T06 · Absent-input case:** Omit one required “Health data model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C004-T07 · Stale-input case:** Supply an outdated “Health data model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Health data model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C004-T09 · Valid integration trace:** Run a valid “Health data model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C004-T10 · Seam review:** Reconcile the “Health data model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C005 · Valid-case test

**Original checklist item:** Test health data model with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C005-T01 · Valid fixture choice:** Select an authorized-operator example for “Health data model” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C005-T02 · Expected-result oracle:** Specify the “Health data model” expected result independently of the implementation output; include the property “One green status cannot stand in for all health dimensions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C005-T03 · Fixture material:** Create the concrete “Health data model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C005-T04 · Target preparation:** Prepare the “Health data model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C005-T05 · Initial-state record:** Record the initial “Health data model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C005-T06 · Valid-path execution:** Drive the “Health data model” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C005-T07 · Outcome comparison:** Compare every declared “Health data model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C005-T08 · State and bounds check:** Inspect the “Health data model” ownership/state effects and actual use of “Status fields and payload bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C005-T09 · Repeatability check:** Repeat the same “Health data model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C005-T10 · Positive evidence:** Attach the “Health data model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C006 · Negative test

**Original checklist item:** Negative case: A passing witness forces every health indicator to healthy. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Health data model” source counterexample: “A passing witness forces every health indicator to healthy”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Health data model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C006-T03 · Valid control:** Construct a valid “Health data model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C006-T04 · Minimal adverse input:** Derive the “Health data model” adverse fixture from the control with the smallest documented change needed to reproduce “A passing witness forces every health indicator to healthy”; retain that change as reproducible data.
- [ ] **UC-M10.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Health data model”; require “One green status cannot stand in for all health dimensions” and forbid a false-success verdict.
- [ ] **UC-M10.04-C006-T06 · Adverse execution:** Exercise the “Health data model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C006-T07 · Effect inspection:** Inspect “Health data model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C006-T08 · Refusal versus failure:** Confirm the “Health data model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C006-T09 · Reset and retention:** Restore only the disposable “Health data model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C006-T10 · Negative regression:** Register the “Health data model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C007 · Change / failure test

**Original checklist item:** Exercise health data model when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C007-T01 · Scenario record:** Write the “Health data model” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “One green status cannot stand in for all health dimensions”.
- [ ] **UC-M10.04-C007-T02 · Baseline capture:** Create a known-valid “Health data model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C007-T03 · Injection map:** Locate the “Health data model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Health data model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C007-T05 · Controlled trigger:** Introduce the controlled “Health data model” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C007-T06 · Intermediate inspection:** Inspect the “Health data model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Health data model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Health data model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C007-T09 · Repeat and compare:** Repeat the selected “Health data model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C007-T10 · Failure evidence:** Publish the “Health data model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C008 · Bounds

**Original checklist item:** Set and test limits for status fields and payload bytes; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Health data model”: “Status fields and payload bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C008-T02 · Measurement method:** Choose how to observe each “Health data model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C008-T03 · Budget decision:** Select justified update, payload and presentation limits for “Health data model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Health data model” cases for “Status fields and payload bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Health data model” limit; preserve “One green status cannot stand in for all health dimensions”.
- [ ] **UC-M10.04-C008-T06 · Normal measurement:** Run or review the normal “Health data model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C008-T07 · At-limit measurement:** Exercise the “Health data model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C008-T08 · Over-limit measurement:** Exercise the “Health data model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C008-T09 · Uncovered-scope report:** List the “Health data model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C008-T10 · Limit evidence:** Publish the selected “Health data model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C009 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for health data model; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C009-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Health data model”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C009-T02 · Authority text:** Write explicit nonsecret “Health data model” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C009-T03 · Freshness fields:** Show the “Health data model” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C009-T04 · Failure text:** Define the “Health data model” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C009-T05 · Permission behavior:** Test the “Health data model” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C009-T06 · Stale-state behavior:** Exercise “Health data model” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C009-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Health data model” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C009-T08 · Bounded updates:** Exercise “Health data model” update saturation within “Status fields and payload bytes”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C009-T09 · API reconciliation:** Compare the “Health data model” displayed text and available controls with actual management results; document discrepancies and preserve “One green status cannot stand in for all health dimensions”.
- [ ] **UC-M10.04-C009-T10 · UI diagnostic evidence:** Attach the “Health data model” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for health data model; label unexecuted checks as untested.

- [ ] **UC-M10.04-C010-T01 · Evidence inventory:** List the “Health data model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C010-T02 · Artifact references:** Record the exact “Health data model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C010-T03 · Fixture references:** Attach the “Health data model” fixture IDs, input identities and oracle definition; preserve the source counterexample “A passing witness forces every health indicator to healthy” as a distinct evidence case.
- [ ] **UC-M10.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Health data model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C010-T05 · Environment record:** Record the actual “Health data model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C010-T06 · Expected versus observed:** Pair every “Health data model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C010-T07 · Failure and limit records:** Attach “Health data model” change/failure and bounds evidence where required; include uncovered “Status fields and payload bytes” and unresolved violations of “One green status cannot stand in for all health dimensions”.
- [ ] **UC-M10.04-C010-T08 · Evidence hygiene:** Check the “Health data model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C010-T09 · Reproduction review:** Have the “Health data model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C010-T10 · Acceptance linkage:** Link the “Health data model” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Observed-state sourcing

**Source delivery:** Read current backend and controller observations rather than infer health from files.

**Source invariant:** Visible health is grounded in observed current state.

**Source negative case:** An old status file keeps a stopped guest green.

**Source bounded quantities:** Observation sources and refresh cost.

### UC-M10.04-C011 · Contract

**Original checklist item:** Specify the operator workflow for observed-state sourcing, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C011-T01 · Scope statement:** Describe the operator journey for “Observed-state sourcing”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Observed-state sourcing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C011-T03 · Output inventory:** List the outputs of “Observed-state sourcing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Observed-state sourcing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C011-T05 · Prerequisite contract:** Map “Observed-state sourcing” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Observed-state sourcing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C011-T07 · Invariant clause:** Add a normative clause for “Observed-state sourcing” that preserves “Visible health is grounded in observed current state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Observed-state sourcing”; include the source counterexample “An old status file keeps a stopped guest green” and the intended safe disposition.
- [ ] **UC-M10.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Observation sources and refresh cost” in the “Observed-state sourcing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C011-T10 · Contract review:** Review the “Observed-state sourcing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C012 · Delivery

**Original checklist item:** Read current backend and controller observations rather than infer health from files.

- [ ] **UC-M10.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Observed-state sourcing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C012-T02 · Change plan:** Break the source delivery for “Observed-state sourcing” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Observed-state sourcing” that realizes this source instruction: Read current backend and controller observations rather than infer health from files.
- [ ] **UC-M10.04-C012-T04 · Concrete realization:** Trace “Observed-state sourcing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Observed-state sourcing” needed to preserve “Visible health is grounded in observed current state”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C012-T06 · Dependency connection:** Connect the “Observed-state sourcing” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C012-T07 · Resource behavior:** Account for “Observation sources and refresh cost” in “Observed-state sourcing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C012-T08 · Delivery check:** Exercise the “Observed-state sourcing” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C012-T09 · Patch review:** Review the “Observed-state sourcing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C012-T10 · Delivery handoff:** Publish the “Observed-state sourcing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Visible health is grounded in observed current state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Observed-state sourcing”; copy its required invariant exactly: “Visible health is grounded in observed current state”.
- [ ] **UC-M10.04-C013-T02 · Observable terms:** Define each term in the “Observed-state sourcing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C013-T03 · Precondition set:** List the preconditions under which “Visible health is grounded in observed current state” must hold for “Observed-state sourcing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C013-T04 · Transition coverage:** Map the “Observed-state sourcing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Observed-state sourcing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C013-T06 · Satisfying fixture:** Create a concrete “Observed-state sourcing” case that satisfies “Visible health is grounded in observed current state”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C013-T07 · Violating fixture:** Create the source counterexample “An old status file keeps a stopped guest green” for “Observed-state sourcing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C013-T08 · Enforcement evidence:** Exercise the “Observed-state sourcing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C013-T09 · Regression linkage:** Link the “Observed-state sourcing” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Observed-state sourcing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C014 · Integration

**Original checklist item:** Integrate observed-state sourcing with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Observed-state sourcing” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C014-T02 · Field mapping:** Map every “Observed-state sourcing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Observed-state sourcing” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C014-T04 · Ownership agreement:** Specify who owns “Observed-state sourcing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C014-T05 · Handoff implementation:** Connect “Observed-state sourcing” through the mapped seam using the real adapter or explicit specification reference; preserve “Visible health is grounded in observed current state” across the handoff.
- [ ] **UC-M10.04-C014-T06 · Absent-input case:** Omit one required “Observed-state sourcing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C014-T07 · Stale-input case:** Supply an outdated “Observed-state sourcing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Observed-state sourcing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C014-T09 · Valid integration trace:** Run a valid “Observed-state sourcing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C014-T10 · Seam review:** Reconcile the “Observed-state sourcing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C015 · Valid-case test

**Original checklist item:** Test observed-state sourcing with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C015-T01 · Valid fixture choice:** Select an authorized-operator example for “Observed-state sourcing” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C015-T02 · Expected-result oracle:** Specify the “Observed-state sourcing” expected result independently of the implementation output; include the property “Visible health is grounded in observed current state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C015-T03 · Fixture material:** Create the concrete “Observed-state sourcing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C015-T04 · Target preparation:** Prepare the “Observed-state sourcing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C015-T05 · Initial-state record:** Record the initial “Observed-state sourcing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C015-T06 · Valid-path execution:** Drive the “Observed-state sourcing” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C015-T07 · Outcome comparison:** Compare every declared “Observed-state sourcing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C015-T08 · State and bounds check:** Inspect the “Observed-state sourcing” ownership/state effects and actual use of “Observation sources and refresh cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C015-T09 · Repeatability check:** Repeat the same “Observed-state sourcing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C015-T10 · Positive evidence:** Attach the “Observed-state sourcing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C016 · Negative test

**Original checklist item:** Negative case: An old status file keeps a stopped guest green. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Observed-state sourcing” source counterexample: “An old status file keeps a stopped guest green”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Observed-state sourcing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C016-T03 · Valid control:** Construct a valid “Observed-state sourcing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C016-T04 · Minimal adverse input:** Derive the “Observed-state sourcing” adverse fixture from the control with the smallest documented change needed to reproduce “An old status file keeps a stopped guest green”; retain that change as reproducible data.
- [ ] **UC-M10.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Observed-state sourcing”; require “Visible health is grounded in observed current state” and forbid a false-success verdict.
- [ ] **UC-M10.04-C016-T06 · Adverse execution:** Exercise the “Observed-state sourcing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C016-T07 · Effect inspection:** Inspect “Observed-state sourcing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C016-T08 · Refusal versus failure:** Confirm the “Observed-state sourcing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C016-T09 · Reset and retention:** Restore only the disposable “Observed-state sourcing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C016-T10 · Negative regression:** Register the “Observed-state sourcing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C017 · Change / failure test

**Original checklist item:** Exercise observed-state sourcing when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C017-T01 · Scenario record:** Write the “Observed-state sourcing” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “Visible health is grounded in observed current state”.
- [ ] **UC-M10.04-C017-T02 · Baseline capture:** Create a known-valid “Observed-state sourcing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C017-T03 · Injection map:** Locate the “Observed-state sourcing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Observed-state sourcing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C017-T05 · Controlled trigger:** Introduce the controlled “Observed-state sourcing” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C017-T06 · Intermediate inspection:** Inspect the “Observed-state sourcing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Observed-state sourcing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Observed-state sourcing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C017-T09 · Repeat and compare:** Repeat the selected “Observed-state sourcing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C017-T10 · Failure evidence:** Publish the “Observed-state sourcing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C018 · Bounds

**Original checklist item:** Set and test limits for observation sources and refresh cost; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Observed-state sourcing”: “Observation sources and refresh cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C018-T02 · Measurement method:** Choose how to observe each “Observed-state sourcing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C018-T03 · Budget decision:** Select justified update, payload and presentation limits for “Observed-state sourcing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Observed-state sourcing” cases for “Observation sources and refresh cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Observed-state sourcing” limit; preserve “Visible health is grounded in observed current state”.
- [ ] **UC-M10.04-C018-T06 · Normal measurement:** Run or review the normal “Observed-state sourcing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C018-T07 · At-limit measurement:** Exercise the “Observed-state sourcing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C018-T08 · Over-limit measurement:** Exercise the “Observed-state sourcing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C018-T09 · Uncovered-scope report:** List the “Observed-state sourcing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C018-T10 · Limit evidence:** Publish the selected “Observed-state sourcing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C019 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for observed-state sourcing; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C019-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Observed-state sourcing”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C019-T02 · Authority text:** Write explicit nonsecret “Observed-state sourcing” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C019-T03 · Freshness fields:** Show the “Observed-state sourcing” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C019-T04 · Failure text:** Define the “Observed-state sourcing” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C019-T05 · Permission behavior:** Test the “Observed-state sourcing” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C019-T06 · Stale-state behavior:** Exercise “Observed-state sourcing” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C019-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Observed-state sourcing” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C019-T08 · Bounded updates:** Exercise “Observed-state sourcing” update saturation within “Observation sources and refresh cost”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C019-T09 · API reconciliation:** Compare the “Observed-state sourcing” displayed text and available controls with actual management results; document discrepancies and preserve “Visible health is grounded in observed current state”.
- [ ] **UC-M10.04-C019-T10 · UI diagnostic evidence:** Attach the “Observed-state sourcing” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for observed-state sourcing; label unexecuted checks as untested.

- [ ] **UC-M10.04-C020-T01 · Evidence inventory:** List the “Observed-state sourcing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C020-T02 · Artifact references:** Record the exact “Observed-state sourcing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C020-T03 · Fixture references:** Attach the “Observed-state sourcing” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old status file keeps a stopped guest green” as a distinct evidence case.
- [ ] **UC-M10.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Observed-state sourcing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C020-T05 · Environment record:** Record the actual “Observed-state sourcing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C020-T06 · Expected versus observed:** Pair every “Observed-state sourcing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C020-T07 · Failure and limit records:** Attach “Observed-state sourcing” change/failure and bounds evidence where required; include uncovered “Observation sources and refresh cost” and unresolved violations of “Visible health is grounded in observed current state”.
- [ ] **UC-M10.04-C020-T08 · Evidence hygiene:** Check the “Observed-state sourcing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C020-T09 · Reproduction review:** Have the “Observed-state sourcing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C020-T10 · Acceptance linkage:** Link the “Observed-state sourcing” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Progress age

**Source delivery:** Show when meaningful progress was last observed.

**Source invariant:** A stalled workload cannot appear active solely through animation.

**Source negative case:** A spinner continues while no progress event arrives.

**Source bounded quantities:** Progress-age threshold and update interval.

### UC-M10.04-C021 · Contract

**Original checklist item:** Specify the operator workflow for progress age, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C021-T01 · Scope statement:** Describe the operator journey for “Progress age”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Progress age”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C021-T03 · Output inventory:** List the outputs of “Progress age” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Progress age”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C021-T05 · Prerequisite contract:** Map “Progress age” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Progress age”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C021-T07 · Invariant clause:** Add a normative clause for “Progress age” that preserves “A stalled workload cannot appear active solely through animation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Progress age”; include the source counterexample “A spinner continues while no progress event arrives” and the intended safe disposition.
- [ ] **UC-M10.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Progress-age threshold and update interval” in the “Progress age” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C021-T10 · Contract review:** Review the “Progress age” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C022 · Delivery

**Original checklist item:** Show when meaningful progress was last observed.

- [ ] **UC-M10.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Progress age”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C022-T02 · Change plan:** Break the source delivery for “Progress age” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C022-T03 · Core artifact:** Create the “Progress age” output artifact for this source instruction: Show when meaningful progress was last observed.
- [ ] **UC-M10.04-C022-T04 · Concrete realization:** Populate the “Progress age” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M10.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Progress age” needed to preserve “A stalled workload cannot appear active solely through animation”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C022-T06 · Dependency connection:** Connect the “Progress age” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C022-T07 · Resource behavior:** Account for “Progress-age threshold and update interval” in “Progress age”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C022-T08 · Delivery check:** Exercise the “Progress age” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C022-T09 · Patch review:** Review the “Progress age” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C022-T10 · Delivery handoff:** Publish the “Progress age” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stalled workload cannot appear active solely through animation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Progress age”; copy its required invariant exactly: “A stalled workload cannot appear active solely through animation”.
- [ ] **UC-M10.04-C023-T02 · Observable terms:** Define each term in the “Progress age” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C023-T03 · Precondition set:** List the preconditions under which “A stalled workload cannot appear active solely through animation” must hold for “Progress age”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C023-T04 · Transition coverage:** Map the “Progress age” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Progress age”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C023-T06 · Satisfying fixture:** Create a concrete “Progress age” case that satisfies “A stalled workload cannot appear active solely through animation”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C023-T07 · Violating fixture:** Create the source counterexample “A spinner continues while no progress event arrives” for “Progress age”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C023-T08 · Enforcement evidence:** Exercise the “Progress age” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C023-T09 · Regression linkage:** Link the “Progress age” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Progress age” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C024 · Integration

**Original checklist item:** Integrate progress age with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Progress age” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C024-T02 · Field mapping:** Map every “Progress age” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Progress age” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C024-T04 · Ownership agreement:** Specify who owns “Progress age” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C024-T05 · Handoff implementation:** Connect “Progress age” through the mapped seam using the real adapter or explicit specification reference; preserve “A stalled workload cannot appear active solely through animation” across the handoff.
- [ ] **UC-M10.04-C024-T06 · Absent-input case:** Omit one required “Progress age” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C024-T07 · Stale-input case:** Supply an outdated “Progress age” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Progress age” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C024-T09 · Valid integration trace:** Run a valid “Progress age” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C024-T10 · Seam review:** Reconcile the “Progress age” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C025 · Valid-case test

**Original checklist item:** Test progress age with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C025-T01 · Valid fixture choice:** Select an authorized-operator example for “Progress age” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C025-T02 · Expected-result oracle:** Specify the “Progress age” expected result independently of the implementation output; include the property “A stalled workload cannot appear active solely through animation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C025-T03 · Fixture material:** Create the concrete “Progress age” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C025-T04 · Target preparation:** Prepare the “Progress age” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C025-T05 · Initial-state record:** Record the initial “Progress age” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C025-T06 · Valid-path execution:** Drive the “Progress age” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C025-T07 · Outcome comparison:** Compare every declared “Progress age” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C025-T08 · State and bounds check:** Inspect the “Progress age” ownership/state effects and actual use of “Progress-age threshold and update interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C025-T09 · Repeatability check:** Repeat the same “Progress age” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C025-T10 · Positive evidence:** Attach the “Progress age” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C026 · Negative test

**Original checklist item:** Negative case: A spinner continues while no progress event arrives. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Progress age” source counterexample: “A spinner continues while no progress event arrives”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Progress age”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C026-T03 · Valid control:** Construct a valid “Progress age” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C026-T04 · Minimal adverse input:** Derive the “Progress age” adverse fixture from the control with the smallest documented change needed to reproduce “A spinner continues while no progress event arrives”; retain that change as reproducible data.
- [ ] **UC-M10.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Progress age”; require “A stalled workload cannot appear active solely through animation” and forbid a false-success verdict.
- [ ] **UC-M10.04-C026-T06 · Adverse execution:** Exercise the “Progress age” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C026-T07 · Effect inspection:** Inspect “Progress age” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C026-T08 · Refusal versus failure:** Confirm the “Progress age” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C026-T09 · Reset and retention:** Restore only the disposable “Progress age” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C026-T10 · Negative regression:** Register the “Progress age” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C027 · Change / failure test

**Original checklist item:** Exercise progress age when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C027-T01 · Scenario record:** Write the “Progress age” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “A stalled workload cannot appear active solely through animation”.
- [ ] **UC-M10.04-C027-T02 · Baseline capture:** Create a known-valid “Progress age” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C027-T03 · Injection map:** Locate the “Progress age” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Progress age” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C027-T05 · Controlled trigger:** Introduce the controlled “Progress age” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C027-T06 · Intermediate inspection:** Inspect the “Progress age” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Progress age”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Progress age” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C027-T09 · Repeat and compare:** Repeat the selected “Progress age” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C027-T10 · Failure evidence:** Publish the “Progress age” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C028 · Bounds

**Original checklist item:** Set and test limits for progress-age threshold and update interval; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Progress age”: “Progress-age threshold and update interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C028-T02 · Measurement method:** Choose how to observe each “Progress age” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C028-T03 · Budget decision:** Select justified update, payload and presentation limits for “Progress age”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Progress age” cases for “Progress-age threshold and update interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Progress age” limit; preserve “A stalled workload cannot appear active solely through animation”.
- [ ] **UC-M10.04-C028-T06 · Normal measurement:** Run or review the normal “Progress age” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C028-T07 · At-limit measurement:** Exercise the “Progress age” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C028-T08 · Over-limit measurement:** Exercise the “Progress age” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C028-T09 · Uncovered-scope report:** List the “Progress age” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C028-T10 · Limit evidence:** Publish the selected “Progress age” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C029 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for progress age; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C029-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Progress age”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C029-T02 · Authority text:** Write explicit nonsecret “Progress age” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C029-T03 · Freshness fields:** Show the “Progress age” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C029-T04 · Failure text:** Define the “Progress age” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C029-T05 · Permission behavior:** Test the “Progress age” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C029-T06 · Stale-state behavior:** Exercise “Progress age” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C029-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Progress age” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C029-T08 · Bounded updates:** Exercise “Progress age” update saturation within “Progress-age threshold and update interval”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C029-T09 · API reconciliation:** Compare the “Progress age” displayed text and available controls with actual management results; document discrepancies and preserve “A stalled workload cannot appear active solely through animation”.
- [ ] **UC-M10.04-C029-T10 · UI diagnostic evidence:** Attach the “Progress age” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for progress age; label unexecuted checks as untested.

- [ ] **UC-M10.04-C030-T01 · Evidence inventory:** List the “Progress age” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C030-T02 · Artifact references:** Record the exact “Progress age” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C030-T03 · Fixture references:** Attach the “Progress age” fixture IDs, input identities and oracle definition; preserve the source counterexample “A spinner continues while no progress event arrives” as a distinct evidence case.
- [ ] **UC-M10.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Progress age”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C030-T05 · Environment record:** Record the actual “Progress age” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C030-T06 · Expected versus observed:** Pair every “Progress age” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C030-T07 · Failure and limit records:** Attach “Progress age” change/failure and bounds evidence where required; include uncovered “Progress-age threshold and update interval” and unresolved violations of “A stalled workload cannot appear active solely through animation”.
- [ ] **UC-M10.04-C030-T08 · Evidence hygiene:** Check the “Progress age” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C030-T09 · Reproduction review:** Have the “Progress age” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C030-T10 · Acceptance linkage:** Link the “Progress age” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Current phase

**Source delivery:** Display actual admission, build, boot, execution, drain or recovery phase.

**Source invariant:** The displayed phase corresponds to the observed lifecycle.

**Source negative case:** The UI shows running while the workload is waiting in backoff.

**Source bounded quantities:** Phase transitions and event backlog.

### UC-M10.04-C031 · Contract

**Original checklist item:** Specify the operator workflow for current phase, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C031-T01 · Scope statement:** Describe the operator journey for “Current phase”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Current phase”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C031-T03 · Output inventory:** List the outputs of “Current phase” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Current phase”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C031-T05 · Prerequisite contract:** Map “Current phase” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Current phase”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C031-T07 · Invariant clause:** Add a normative clause for “Current phase” that preserves “The displayed phase corresponds to the observed lifecycle”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Current phase”; include the source counterexample “The UI shows running while the workload is waiting in backoff” and the intended safe disposition.
- [ ] **UC-M10.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Phase transitions and event backlog” in the “Current phase” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C031-T10 · Contract review:** Review the “Current phase” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C032 · Delivery

**Original checklist item:** Display actual admission, build, boot, execution, drain or recovery phase.

- [ ] **UC-M10.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Current phase”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C032-T02 · Change plan:** Break the source delivery for “Current phase” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C032-T03 · Core artifact:** Create the “Current phase” output artifact for this source instruction: Display actual admission, build, boot, execution, drain or recovery phase.
- [ ] **UC-M10.04-C032-T04 · Concrete realization:** Populate the “Current phase” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M10.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Current phase” needed to preserve “The displayed phase corresponds to the observed lifecycle”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C032-T06 · Dependency connection:** Connect the “Current phase” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C032-T07 · Resource behavior:** Account for “Phase transitions and event backlog” in “Current phase”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C032-T08 · Delivery check:** Exercise the “Current phase” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C032-T09 · Patch review:** Review the “Current phase” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C032-T10 · Delivery handoff:** Publish the “Current phase” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The displayed phase corresponds to the observed lifecycle. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Current phase”; copy its required invariant exactly: “The displayed phase corresponds to the observed lifecycle”.
- [ ] **UC-M10.04-C033-T02 · Observable terms:** Define each term in the “Current phase” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C033-T03 · Precondition set:** List the preconditions under which “The displayed phase corresponds to the observed lifecycle” must hold for “Current phase”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C033-T04 · Transition coverage:** Map the “Current phase” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Current phase”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C033-T06 · Satisfying fixture:** Create a concrete “Current phase” case that satisfies “The displayed phase corresponds to the observed lifecycle”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C033-T07 · Violating fixture:** Create the source counterexample “The UI shows running while the workload is waiting in backoff” for “Current phase”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C033-T08 · Enforcement evidence:** Exercise the “Current phase” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C033-T09 · Regression linkage:** Link the “Current phase” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Current phase” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C034 · Integration

**Original checklist item:** Integrate current phase with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Current phase” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C034-T02 · Field mapping:** Map every “Current phase” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Current phase” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C034-T04 · Ownership agreement:** Specify who owns “Current phase” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C034-T05 · Handoff implementation:** Connect “Current phase” through the mapped seam using the real adapter or explicit specification reference; preserve “The displayed phase corresponds to the observed lifecycle” across the handoff.
- [ ] **UC-M10.04-C034-T06 · Absent-input case:** Omit one required “Current phase” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C034-T07 · Stale-input case:** Supply an outdated “Current phase” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Current phase” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C034-T09 · Valid integration trace:** Run a valid “Current phase” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C034-T10 · Seam review:** Reconcile the “Current phase” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C035 · Valid-case test

**Original checklist item:** Test current phase with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C035-T01 · Valid fixture choice:** Select an authorized-operator example for “Current phase” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C035-T02 · Expected-result oracle:** Specify the “Current phase” expected result independently of the implementation output; include the property “The displayed phase corresponds to the observed lifecycle” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C035-T03 · Fixture material:** Create the concrete “Current phase” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C035-T04 · Target preparation:** Prepare the “Current phase” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C035-T05 · Initial-state record:** Record the initial “Current phase” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C035-T06 · Valid-path execution:** Drive the “Current phase” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C035-T07 · Outcome comparison:** Compare every declared “Current phase” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C035-T08 · State and bounds check:** Inspect the “Current phase” ownership/state effects and actual use of “Phase transitions and event backlog”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C035-T09 · Repeatability check:** Repeat the same “Current phase” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C035-T10 · Positive evidence:** Attach the “Current phase” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C036 · Negative test

**Original checklist item:** Negative case: The UI shows running while the workload is waiting in backoff. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Current phase” source counterexample: “The UI shows running while the workload is waiting in backoff”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Current phase”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C036-T03 · Valid control:** Construct a valid “Current phase” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C036-T04 · Minimal adverse input:** Derive the “Current phase” adverse fixture from the control with the smallest documented change needed to reproduce “The UI shows running while the workload is waiting in backoff”; retain that change as reproducible data.
- [ ] **UC-M10.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Current phase”; require “The displayed phase corresponds to the observed lifecycle” and forbid a false-success verdict.
- [ ] **UC-M10.04-C036-T06 · Adverse execution:** Exercise the “Current phase” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C036-T07 · Effect inspection:** Inspect “Current phase” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C036-T08 · Refusal versus failure:** Confirm the “Current phase” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C036-T09 · Reset and retention:** Restore only the disposable “Current phase” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C036-T10 · Negative regression:** Register the “Current phase” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C037 · Change / failure test

**Original checklist item:** Exercise current phase when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C037-T01 · Scenario record:** Write the “Current phase” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “The displayed phase corresponds to the observed lifecycle”.
- [ ] **UC-M10.04-C037-T02 · Baseline capture:** Create a known-valid “Current phase” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C037-T03 · Injection map:** Locate the “Current phase” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Current phase” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C037-T05 · Controlled trigger:** Introduce the controlled “Current phase” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C037-T06 · Intermediate inspection:** Inspect the “Current phase” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Current phase”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Current phase” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C037-T09 · Repeat and compare:** Repeat the selected “Current phase” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C037-T10 · Failure evidence:** Publish the “Current phase” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C038 · Bounds

**Original checklist item:** Set and test limits for phase transitions and event backlog; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Current phase”: “Phase transitions and event backlog”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C038-T02 · Measurement method:** Choose how to observe each “Current phase” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C038-T03 · Budget decision:** Select justified update, payload and presentation limits for “Current phase”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Current phase” cases for “Phase transitions and event backlog”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Current phase” limit; preserve “The displayed phase corresponds to the observed lifecycle”.
- [ ] **UC-M10.04-C038-T06 · Normal measurement:** Run or review the normal “Current phase” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C038-T07 · At-limit measurement:** Exercise the “Current phase” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C038-T08 · Over-limit measurement:** Exercise the “Current phase” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C038-T09 · Uncovered-scope report:** List the “Current phase” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C038-T10 · Limit evidence:** Publish the selected “Current phase” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C039 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for current phase; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C039-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Current phase”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C039-T02 · Authority text:** Write explicit nonsecret “Current phase” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C039-T03 · Freshness fields:** Show the “Current phase” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C039-T04 · Failure text:** Define the “Current phase” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C039-T05 · Permission behavior:** Test the “Current phase” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C039-T06 · Stale-state behavior:** Exercise “Current phase” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C039-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Current phase” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C039-T08 · Bounded updates:** Exercise “Current phase” update saturation within “Phase transitions and event backlog”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C039-T09 · API reconciliation:** Compare the “Current phase” displayed text and available controls with actual management results; document discrepancies and preserve “The displayed phase corresponds to the observed lifecycle”.
- [ ] **UC-M10.04-C039-T10 · UI diagnostic evidence:** Attach the “Current phase” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for current phase; label unexecuted checks as untested.

- [ ] **UC-M10.04-C040-T01 · Evidence inventory:** List the “Current phase” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C040-T02 · Artifact references:** Record the exact “Current phase” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C040-T03 · Fixture references:** Attach the “Current phase” fixture IDs, input identities and oracle definition; preserve the source counterexample “The UI shows running while the workload is waiting in backoff” as a distinct evidence case.
- [ ] **UC-M10.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Current phase”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C040-T05 · Environment record:** Record the actual “Current phase” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C040-T06 · Expected versus observed:** Pair every “Current phase” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C040-T07 · Failure and limit records:** Attach “Current phase” change/failure and bounds evidence where required; include uncovered “Phase transitions and event backlog” and unresolved violations of “The displayed phase corresponds to the observed lifecycle”.
- [ ] **UC-M10.04-C040-T08 · Evidence hygiene:** Check the “Current phase” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C040-T09 · Reproduction review:** Have the “Current phase” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C040-T10 · Acceptance linkage:** Link the “Current phase” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Blocked reason

**Source delivery:** Expose the precise dependency, policy, capacity or failure blocking progress.

**Source invariant:** A generic waiting state does not hide a known blocker.

**Source negative case:** A missing required backend is displayed as normal startup delay.

**Source bounded quantities:** Reason bytes and unresolved blockers.

### UC-M10.04-C041 · Contract

**Original checklist item:** Specify the operator workflow for blocked reason, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C041-T01 · Scope statement:** Describe the operator journey for “Blocked reason”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Blocked reason”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C041-T03 · Output inventory:** List the outputs of “Blocked reason” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Blocked reason”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C041-T05 · Prerequisite contract:** Map “Blocked reason” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Blocked reason”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C041-T07 · Invariant clause:** Add a normative clause for “Blocked reason” that preserves “A generic waiting state does not hide a known blocker”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Blocked reason”; include the source counterexample “A missing required backend is displayed as normal startup delay” and the intended safe disposition.
- [ ] **UC-M10.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reason bytes and unresolved blockers” in the “Blocked reason” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C041-T10 · Contract review:** Review the “Blocked reason” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C042 · Delivery

**Original checklist item:** Expose the precise dependency, policy, capacity or failure blocking progress.

- [ ] **UC-M10.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Blocked reason”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C042-T02 · Change plan:** Break the source delivery for “Blocked reason” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Blocked reason” that realizes this source instruction: Expose the precise dependency, policy, capacity or failure blocking progress.
- [ ] **UC-M10.04-C042-T04 · Concrete realization:** Trace “Blocked reason” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Blocked reason” needed to preserve “A generic waiting state does not hide a known blocker”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C042-T06 · Dependency connection:** Connect the “Blocked reason” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C042-T07 · Resource behavior:** Account for “Reason bytes and unresolved blockers” in “Blocked reason”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C042-T08 · Delivery check:** Exercise the “Blocked reason” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C042-T09 · Patch review:** Review the “Blocked reason” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C042-T10 · Delivery handoff:** Publish the “Blocked reason” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A generic waiting state does not hide a known blocker. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Blocked reason”; copy its required invariant exactly: “A generic waiting state does not hide a known blocker”.
- [ ] **UC-M10.04-C043-T02 · Observable terms:** Define each term in the “Blocked reason” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C043-T03 · Precondition set:** List the preconditions under which “A generic waiting state does not hide a known blocker” must hold for “Blocked reason”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C043-T04 · Transition coverage:** Map the “Blocked reason” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Blocked reason”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C043-T06 · Satisfying fixture:** Create a concrete “Blocked reason” case that satisfies “A generic waiting state does not hide a known blocker”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C043-T07 · Violating fixture:** Create the source counterexample “A missing required backend is displayed as normal startup delay” for “Blocked reason”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C043-T08 · Enforcement evidence:** Exercise the “Blocked reason” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C043-T09 · Regression linkage:** Link the “Blocked reason” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Blocked reason” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C044 · Integration

**Original checklist item:** Integrate blocked reason with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Blocked reason” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C044-T02 · Field mapping:** Map every “Blocked reason” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Blocked reason” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C044-T04 · Ownership agreement:** Specify who owns “Blocked reason” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C044-T05 · Handoff implementation:** Connect “Blocked reason” through the mapped seam using the real adapter or explicit specification reference; preserve “A generic waiting state does not hide a known blocker” across the handoff.
- [ ] **UC-M10.04-C044-T06 · Absent-input case:** Omit one required “Blocked reason” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C044-T07 · Stale-input case:** Supply an outdated “Blocked reason” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Blocked reason” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C044-T09 · Valid integration trace:** Run a valid “Blocked reason” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C044-T10 · Seam review:** Reconcile the “Blocked reason” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C045 · Valid-case test

**Original checklist item:** Test blocked reason with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C045-T01 · Valid fixture choice:** Select an authorized-operator example for “Blocked reason” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C045-T02 · Expected-result oracle:** Specify the “Blocked reason” expected result independently of the implementation output; include the property “A generic waiting state does not hide a known blocker” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C045-T03 · Fixture material:** Create the concrete “Blocked reason” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C045-T04 · Target preparation:** Prepare the “Blocked reason” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C045-T05 · Initial-state record:** Record the initial “Blocked reason” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C045-T06 · Valid-path execution:** Drive the “Blocked reason” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C045-T07 · Outcome comparison:** Compare every declared “Blocked reason” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C045-T08 · State and bounds check:** Inspect the “Blocked reason” ownership/state effects and actual use of “Reason bytes and unresolved blockers”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C045-T09 · Repeatability check:** Repeat the same “Blocked reason” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C045-T10 · Positive evidence:** Attach the “Blocked reason” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C046 · Negative test

**Original checklist item:** Negative case: A missing required backend is displayed as normal startup delay. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Blocked reason” source counterexample: “A missing required backend is displayed as normal startup delay”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Blocked reason”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C046-T03 · Valid control:** Construct a valid “Blocked reason” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C046-T04 · Minimal adverse input:** Derive the “Blocked reason” adverse fixture from the control with the smallest documented change needed to reproduce “A missing required backend is displayed as normal startup delay”; retain that change as reproducible data.
- [ ] **UC-M10.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Blocked reason”; require “A generic waiting state does not hide a known blocker” and forbid a false-success verdict.
- [ ] **UC-M10.04-C046-T06 · Adverse execution:** Exercise the “Blocked reason” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C046-T07 · Effect inspection:** Inspect “Blocked reason” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C046-T08 · Refusal versus failure:** Confirm the “Blocked reason” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C046-T09 · Reset and retention:** Restore only the disposable “Blocked reason” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C046-T10 · Negative regression:** Register the “Blocked reason” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C047 · Change / failure test

**Original checklist item:** Exercise blocked reason when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C047-T01 · Scenario record:** Write the “Blocked reason” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “A generic waiting state does not hide a known blocker”.
- [ ] **UC-M10.04-C047-T02 · Baseline capture:** Create a known-valid “Blocked reason” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C047-T03 · Injection map:** Locate the “Blocked reason” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Blocked reason” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C047-T05 · Controlled trigger:** Introduce the controlled “Blocked reason” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C047-T06 · Intermediate inspection:** Inspect the “Blocked reason” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Blocked reason”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Blocked reason” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C047-T09 · Repeat and compare:** Repeat the selected “Blocked reason” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C047-T10 · Failure evidence:** Publish the “Blocked reason” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C048 · Bounds

**Original checklist item:** Set and test limits for reason bytes and unresolved blockers; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Blocked reason”: “Reason bytes and unresolved blockers”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C048-T02 · Measurement method:** Choose how to observe each “Blocked reason” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C048-T03 · Budget decision:** Select justified update, payload and presentation limits for “Blocked reason”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Blocked reason” cases for “Reason bytes and unresolved blockers”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Blocked reason” limit; preserve “A generic waiting state does not hide a known blocker”.
- [ ] **UC-M10.04-C048-T06 · Normal measurement:** Run or review the normal “Blocked reason” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C048-T07 · At-limit measurement:** Exercise the “Blocked reason” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C048-T08 · Over-limit measurement:** Exercise the “Blocked reason” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C048-T09 · Uncovered-scope report:** List the “Blocked reason” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C048-T10 · Limit evidence:** Publish the selected “Blocked reason” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C049 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for blocked reason; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C049-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Blocked reason”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C049-T02 · Authority text:** Write explicit nonsecret “Blocked reason” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C049-T03 · Freshness fields:** Show the “Blocked reason” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C049-T04 · Failure text:** Define the “Blocked reason” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C049-T05 · Permission behavior:** Test the “Blocked reason” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C049-T06 · Stale-state behavior:** Exercise “Blocked reason” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C049-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Blocked reason” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C049-T08 · Bounded updates:** Exercise “Blocked reason” update saturation within “Reason bytes and unresolved blockers”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C049-T09 · API reconciliation:** Compare the “Blocked reason” displayed text and available controls with actual management results; document discrepancies and preserve “A generic waiting state does not hide a known blocker”.
- [ ] **UC-M10.04-C049-T10 · UI diagnostic evidence:** Attach the “Blocked reason” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for blocked reason; label unexecuted checks as untested.

- [ ] **UC-M10.04-C050-T01 · Evidence inventory:** List the “Blocked reason” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C050-T02 · Artifact references:** Record the exact “Blocked reason” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C050-T03 · Fixture references:** Attach the “Blocked reason” fixture IDs, input identities and oracle definition; preserve the source counterexample “A missing required backend is displayed as normal startup delay” as a distinct evidence case.
- [ ] **UC-M10.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Blocked reason”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C050-T05 · Environment record:** Record the actual “Blocked reason” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C050-T06 · Expected versus observed:** Pair every “Blocked reason” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C050-T07 · Failure and limit records:** Attach “Blocked reason” change/failure and bounds evidence where required; include uncovered “Reason bytes and unresolved blockers” and unresolved violations of “A generic waiting state does not hide a known blocker”.
- [ ] **UC-M10.04-C050-T08 · Evidence hygiene:** Check the “Blocked reason” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C050-T09 · Reproduction review:** Have the “Blocked reason” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C050-T10 · Acceptance linkage:** Link the “Blocked reason” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Stale-data presentation

**Source delivery:** Mark stale or unavailable observations visibly and machine-readably.

**Source invariant:** Stale last-known success is not current health.

**Source negative case:** A disconnected controller leaves healthy status unchanged.

**Source bounded quantities:** Maximum observation age and retry interval.

### UC-M10.04-C051 · Contract

**Original checklist item:** Specify the operator workflow for stale-data presentation, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C051-T01 · Scope statement:** Describe the operator journey for “Stale-data presentation”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Stale-data presentation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C051-T03 · Output inventory:** List the outputs of “Stale-data presentation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Stale-data presentation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C051-T05 · Prerequisite contract:** Map “Stale-data presentation” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Stale-data presentation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C051-T07 · Invariant clause:** Add a normative clause for “Stale-data presentation” that preserves “Stale last-known success is not current health”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Stale-data presentation”; include the source counterexample “A disconnected controller leaves healthy status unchanged” and the intended safe disposition.
- [ ] **UC-M10.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Maximum observation age and retry interval” in the “Stale-data presentation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C051-T10 · Contract review:** Review the “Stale-data presentation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C052 · Delivery

**Original checklist item:** Mark stale or unavailable observations visibly and machine-readably.

- [ ] **UC-M10.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Stale-data presentation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C052-T02 · Change plan:** Break the source delivery for “Stale-data presentation” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Stale-data presentation” that realizes this source instruction: Mark stale or unavailable observations visibly and machine-readably.
- [ ] **UC-M10.04-C052-T04 · Concrete realization:** Trace “Stale-data presentation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Stale-data presentation” needed to preserve “Stale last-known success is not current health”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C052-T06 · Dependency connection:** Connect the “Stale-data presentation” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C052-T07 · Resource behavior:** Account for “Maximum observation age and retry interval” in “Stale-data presentation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C052-T08 · Delivery check:** Exercise the “Stale-data presentation” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C052-T09 · Patch review:** Review the “Stale-data presentation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C052-T10 · Delivery handoff:** Publish the “Stale-data presentation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stale last-known success is not current health. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Stale-data presentation”; copy its required invariant exactly: “Stale last-known success is not current health”.
- [ ] **UC-M10.04-C053-T02 · Observable terms:** Define each term in the “Stale-data presentation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C053-T03 · Precondition set:** List the preconditions under which “Stale last-known success is not current health” must hold for “Stale-data presentation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C053-T04 · Transition coverage:** Map the “Stale-data presentation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Stale-data presentation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C053-T06 · Satisfying fixture:** Create a concrete “Stale-data presentation” case that satisfies “Stale last-known success is not current health”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C053-T07 · Violating fixture:** Create the source counterexample “A disconnected controller leaves healthy status unchanged” for “Stale-data presentation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C053-T08 · Enforcement evidence:** Exercise the “Stale-data presentation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C053-T09 · Regression linkage:** Link the “Stale-data presentation” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Stale-data presentation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C054 · Integration

**Original checklist item:** Integrate stale-data presentation with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Stale-data presentation” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C054-T02 · Field mapping:** Map every “Stale-data presentation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Stale-data presentation” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C054-T04 · Ownership agreement:** Specify who owns “Stale-data presentation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C054-T05 · Handoff implementation:** Connect “Stale-data presentation” through the mapped seam using the real adapter or explicit specification reference; preserve “Stale last-known success is not current health” across the handoff.
- [ ] **UC-M10.04-C054-T06 · Absent-input case:** Omit one required “Stale-data presentation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C054-T07 · Stale-input case:** Supply an outdated “Stale-data presentation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Stale-data presentation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C054-T09 · Valid integration trace:** Run a valid “Stale-data presentation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C054-T10 · Seam review:** Reconcile the “Stale-data presentation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C055 · Valid-case test

**Original checklist item:** Test stale-data presentation with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C055-T01 · Valid fixture choice:** Select an authorized-operator example for “Stale-data presentation” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C055-T02 · Expected-result oracle:** Specify the “Stale-data presentation” expected result independently of the implementation output; include the property “Stale last-known success is not current health” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C055-T03 · Fixture material:** Create the concrete “Stale-data presentation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C055-T04 · Target preparation:** Prepare the “Stale-data presentation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C055-T05 · Initial-state record:** Record the initial “Stale-data presentation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C055-T06 · Valid-path execution:** Drive the “Stale-data presentation” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C055-T07 · Outcome comparison:** Compare every declared “Stale-data presentation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C055-T08 · State and bounds check:** Inspect the “Stale-data presentation” ownership/state effects and actual use of “Maximum observation age and retry interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C055-T09 · Repeatability check:** Repeat the same “Stale-data presentation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C055-T10 · Positive evidence:** Attach the “Stale-data presentation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C056 · Negative test

**Original checklist item:** Negative case: A disconnected controller leaves healthy status unchanged. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Stale-data presentation” source counterexample: “A disconnected controller leaves healthy status unchanged”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Stale-data presentation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C056-T03 · Valid control:** Construct a valid “Stale-data presentation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C056-T04 · Minimal adverse input:** Derive the “Stale-data presentation” adverse fixture from the control with the smallest documented change needed to reproduce “A disconnected controller leaves healthy status unchanged”; retain that change as reproducible data.
- [ ] **UC-M10.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Stale-data presentation”; require “Stale last-known success is not current health” and forbid a false-success verdict.
- [ ] **UC-M10.04-C056-T06 · Adverse execution:** Exercise the “Stale-data presentation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C056-T07 · Effect inspection:** Inspect “Stale-data presentation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C056-T08 · Refusal versus failure:** Confirm the “Stale-data presentation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C056-T09 · Reset and retention:** Restore only the disposable “Stale-data presentation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C056-T10 · Negative regression:** Register the “Stale-data presentation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C057 · Change / failure test

**Original checklist item:** Exercise stale-data presentation when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C057-T01 · Scenario record:** Write the “Stale-data presentation” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “Stale last-known success is not current health”.
- [ ] **UC-M10.04-C057-T02 · Baseline capture:** Create a known-valid “Stale-data presentation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C057-T03 · Injection map:** Locate the “Stale-data presentation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Stale-data presentation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C057-T05 · Controlled trigger:** Introduce the controlled “Stale-data presentation” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C057-T06 · Intermediate inspection:** Inspect the “Stale-data presentation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Stale-data presentation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Stale-data presentation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C057-T09 · Repeat and compare:** Repeat the selected “Stale-data presentation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C057-T10 · Failure evidence:** Publish the “Stale-data presentation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C058 · Bounds

**Original checklist item:** Set and test limits for maximum observation age and retry interval; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Stale-data presentation”: “Maximum observation age and retry interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C058-T02 · Measurement method:** Choose how to observe each “Stale-data presentation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C058-T03 · Budget decision:** Select justified update, payload and presentation limits for “Stale-data presentation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Stale-data presentation” cases for “Maximum observation age and retry interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Stale-data presentation” limit; preserve “Stale last-known success is not current health”.
- [ ] **UC-M10.04-C058-T06 · Normal measurement:** Run or review the normal “Stale-data presentation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C058-T07 · At-limit measurement:** Exercise the “Stale-data presentation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C058-T08 · Over-limit measurement:** Exercise the “Stale-data presentation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C058-T09 · Uncovered-scope report:** List the “Stale-data presentation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C058-T10 · Limit evidence:** Publish the selected “Stale-data presentation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C059 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for stale-data presentation; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C059-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Stale-data presentation”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C059-T02 · Authority text:** Write explicit nonsecret “Stale-data presentation” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C059-T03 · Freshness fields:** Show the “Stale-data presentation” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C059-T04 · Failure text:** Define the “Stale-data presentation” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C059-T05 · Permission behavior:** Test the “Stale-data presentation” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C059-T06 · Stale-state behavior:** Exercise “Stale-data presentation” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C059-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Stale-data presentation” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C059-T08 · Bounded updates:** Exercise “Stale-data presentation” update saturation within “Maximum observation age and retry interval”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C059-T09 · API reconciliation:** Compare the “Stale-data presentation” displayed text and available controls with actual management results; document discrepancies and preserve “Stale last-known success is not current health”.
- [ ] **UC-M10.04-C059-T10 · UI diagnostic evidence:** Attach the “Stale-data presentation” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for stale-data presentation; label unexecuted checks as untested.

- [ ] **UC-M10.04-C060-T01 · Evidence inventory:** List the “Stale-data presentation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C060-T02 · Artifact references:** Record the exact “Stale-data presentation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C060-T03 · Fixture references:** Attach the “Stale-data presentation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A disconnected controller leaves healthy status unchanged” as a distinct evidence case.
- [ ] **UC-M10.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Stale-data presentation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C060-T05 · Environment record:** Record the actual “Stale-data presentation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C060-T06 · Expected versus observed:** Pair every “Stale-data presentation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C060-T07 · Failure and limit records:** Attach “Stale-data presentation” change/failure and bounds evidence where required; include uncovered “Maximum observation age and retry interval” and unresolved violations of “Stale last-known success is not current health”.
- [ ] **UC-M10.04-C060-T08 · Evidence hygiene:** Check the “Stale-data presentation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C060-T09 · Reproduction review:** Have the “Stale-data presentation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C060-T10 · Acceptance linkage:** Link the “Stale-data presentation” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Generation selection

**Source delivery:** Bind the displayed health to the selected immutable generation.

**Source invariant:** Replacing a workload cannot reuse the old generation's healthy display.

**Source negative case:** The UI associates an old successful probe with a new guest.

**Source bounded quantities:** Displayed generations and cached records.

### UC-M10.04-C061 · Contract

**Original checklist item:** Specify the operator workflow for generation selection, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C061-T01 · Scope statement:** Describe the operator journey for “Generation selection”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Generation selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C061-T03 · Output inventory:** List the outputs of “Generation selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Generation selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C061-T05 · Prerequisite contract:** Map “Generation selection” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Generation selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C061-T07 · Invariant clause:** Add a normative clause for “Generation selection” that preserves “Replacing a workload cannot reuse the old generation's healthy display”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Generation selection”; include the source counterexample “The UI associates an old successful probe with a new guest” and the intended safe disposition.
- [ ] **UC-M10.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Displayed generations and cached records” in the “Generation selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C061-T10 · Contract review:** Review the “Generation selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C062 · Delivery

**Original checklist item:** Bind the displayed health to the selected immutable generation.

- [ ] **UC-M10.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Generation selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C062-T02 · Change plan:** Break the source delivery for “Generation selection” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Generation selection” that realizes this source instruction: Bind the displayed health to the selected immutable generation.
- [ ] **UC-M10.04-C062-T04 · Concrete realization:** Trace “Generation selection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Generation selection” needed to preserve “Replacing a workload cannot reuse the old generation's healthy display”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C062-T06 · Dependency connection:** Connect the “Generation selection” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C062-T07 · Resource behavior:** Account for “Displayed generations and cached records” in “Generation selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C062-T08 · Delivery check:** Exercise the “Generation selection” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C062-T09 · Patch review:** Review the “Generation selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C062-T10 · Delivery handoff:** Publish the “Generation selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replacing a workload cannot reuse the old generation's healthy display. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Generation selection”; copy its required invariant exactly: “Replacing a workload cannot reuse the old generation's healthy display”.
- [ ] **UC-M10.04-C063-T02 · Observable terms:** Define each term in the “Generation selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C063-T03 · Precondition set:** List the preconditions under which “Replacing a workload cannot reuse the old generation's healthy display” must hold for “Generation selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C063-T04 · Transition coverage:** Map the “Generation selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Generation selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C063-T06 · Satisfying fixture:** Create a concrete “Generation selection” case that satisfies “Replacing a workload cannot reuse the old generation's healthy display”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C063-T07 · Violating fixture:** Create the source counterexample “The UI associates an old successful probe with a new guest” for “Generation selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C063-T08 · Enforcement evidence:** Exercise the “Generation selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C063-T09 · Regression linkage:** Link the “Generation selection” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Generation selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C064 · Integration

**Original checklist item:** Integrate generation selection with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Generation selection” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C064-T02 · Field mapping:** Map every “Generation selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Generation selection” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C064-T04 · Ownership agreement:** Specify who owns “Generation selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C064-T05 · Handoff implementation:** Connect “Generation selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Replacing a workload cannot reuse the old generation's healthy display” across the handoff.
- [ ] **UC-M10.04-C064-T06 · Absent-input case:** Omit one required “Generation selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C064-T07 · Stale-input case:** Supply an outdated “Generation selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Generation selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C064-T09 · Valid integration trace:** Run a valid “Generation selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C064-T10 · Seam review:** Reconcile the “Generation selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C065 · Valid-case test

**Original checklist item:** Test generation selection with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C065-T01 · Valid fixture choice:** Select an authorized-operator example for “Generation selection” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C065-T02 · Expected-result oracle:** Specify the “Generation selection” expected result independently of the implementation output; include the property “Replacing a workload cannot reuse the old generation's healthy display” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C065-T03 · Fixture material:** Create the concrete “Generation selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C065-T04 · Target preparation:** Prepare the “Generation selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C065-T05 · Initial-state record:** Record the initial “Generation selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C065-T06 · Valid-path execution:** Drive the “Generation selection” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C065-T07 · Outcome comparison:** Compare every declared “Generation selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C065-T08 · State and bounds check:** Inspect the “Generation selection” ownership/state effects and actual use of “Displayed generations and cached records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C065-T09 · Repeatability check:** Repeat the same “Generation selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C065-T10 · Positive evidence:** Attach the “Generation selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C066 · Negative test

**Original checklist item:** Negative case: The UI associates an old successful probe with a new guest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Generation selection” source counterexample: “The UI associates an old successful probe with a new guest”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Generation selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C066-T03 · Valid control:** Construct a valid “Generation selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C066-T04 · Minimal adverse input:** Derive the “Generation selection” adverse fixture from the control with the smallest documented change needed to reproduce “The UI associates an old successful probe with a new guest”; retain that change as reproducible data.
- [ ] **UC-M10.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Generation selection”; require “Replacing a workload cannot reuse the old generation's healthy display” and forbid a false-success verdict.
- [ ] **UC-M10.04-C066-T06 · Adverse execution:** Exercise the “Generation selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C066-T07 · Effect inspection:** Inspect “Generation selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C066-T08 · Refusal versus failure:** Confirm the “Generation selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C066-T09 · Reset and retention:** Restore only the disposable “Generation selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C066-T10 · Negative regression:** Register the “Generation selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C067 · Change / failure test

**Original checklist item:** Exercise generation selection when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C067-T01 · Scenario record:** Write the “Generation selection” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “Replacing a workload cannot reuse the old generation's healthy display”.
- [ ] **UC-M10.04-C067-T02 · Baseline capture:** Create a known-valid “Generation selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C067-T03 · Injection map:** Locate the “Generation selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Generation selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C067-T05 · Controlled trigger:** Introduce the controlled “Generation selection” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C067-T06 · Intermediate inspection:** Inspect the “Generation selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Generation selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Generation selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C067-T09 · Repeat and compare:** Repeat the selected “Generation selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C067-T10 · Failure evidence:** Publish the “Generation selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C068 · Bounds

**Original checklist item:** Set and test limits for displayed generations and cached records; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Generation selection”: “Displayed generations and cached records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C068-T02 · Measurement method:** Choose how to observe each “Generation selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C068-T03 · Budget decision:** Select justified update, payload and presentation limits for “Generation selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Generation selection” cases for “Displayed generations and cached records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Generation selection” limit; preserve “Replacing a workload cannot reuse the old generation's healthy display”.
- [ ] **UC-M10.04-C068-T06 · Normal measurement:** Run or review the normal “Generation selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C068-T07 · At-limit measurement:** Exercise the “Generation selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C068-T08 · Over-limit measurement:** Exercise the “Generation selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C068-T09 · Uncovered-scope report:** List the “Generation selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C068-T10 · Limit evidence:** Publish the selected “Generation selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C069 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for generation selection; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C069-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Generation selection”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C069-T02 · Authority text:** Write explicit nonsecret “Generation selection” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C069-T03 · Freshness fields:** Show the “Generation selection” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C069-T04 · Failure text:** Define the “Generation selection” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C069-T05 · Permission behavior:** Test the “Generation selection” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C069-T06 · Stale-state behavior:** Exercise “Generation selection” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C069-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Generation selection” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C069-T08 · Bounded updates:** Exercise “Generation selection” update saturation within “Displayed generations and cached records”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C069-T09 · API reconciliation:** Compare the “Generation selection” displayed text and available controls with actual management results; document discrepancies and preserve “Replacing a workload cannot reuse the old generation's healthy display”.
- [ ] **UC-M10.04-C069-T10 · UI diagnostic evidence:** Attach the “Generation selection” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for generation selection; label unexecuted checks as untested.

- [ ] **UC-M10.04-C070-T01 · Evidence inventory:** List the “Generation selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C070-T02 · Artifact references:** Record the exact “Generation selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C070-T03 · Fixture references:** Attach the “Generation selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “The UI associates an old successful probe with a new guest” as a distinct evidence case.
- [ ] **UC-M10.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Generation selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C070-T05 · Environment record:** Record the actual “Generation selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C070-T06 · Expected versus observed:** Pair every “Generation selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C070-T07 · Failure and limit records:** Attach “Generation selection” change/failure and bounds evidence where required; include uncovered “Displayed generations and cached records” and unresolved violations of “Replacing a workload cannot reuse the old generation's healthy display”.
- [ ] **UC-M10.04-C070-T08 · Evidence hygiene:** Check the “Generation selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C070-T09 · Reproduction review:** Have the “Generation selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C070-T10 · Acceptance linkage:** Link the “Generation selection” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Metric and trace links

**Source delivery:** Connect health indicators to the underlying measured metrics and execution records.

**Source invariant:** Operators can inspect the evidence behind a health claim.

**Source negative case:** A health badge has no traceable observation source.

**Source bounded quantities:** Linked records and drill-down latency.

### UC-M10.04-C071 · Contract

**Original checklist item:** Specify the operator workflow for metric and trace links, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C071-T01 · Scope statement:** Describe the operator journey for “Metric and trace links”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Metric and trace links”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C071-T03 · Output inventory:** List the outputs of “Metric and trace links” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Metric and trace links”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C071-T05 · Prerequisite contract:** Map “Metric and trace links” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Metric and trace links”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C071-T07 · Invariant clause:** Add a normative clause for “Metric and trace links” that preserves “Operators can inspect the evidence behind a health claim”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Metric and trace links”; include the source counterexample “A health badge has no traceable observation source” and the intended safe disposition.
- [ ] **UC-M10.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Linked records and drill-down latency” in the “Metric and trace links” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C071-T10 · Contract review:** Review the “Metric and trace links” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C072 · Delivery

**Original checklist item:** Connect health indicators to the underlying measured metrics and execution records.

- [ ] **UC-M10.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Metric and trace links”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C072-T02 · Change plan:** Break the source delivery for “Metric and trace links” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Metric and trace links” that realizes this source instruction: Connect health indicators to the underlying measured metrics and execution records.
- [ ] **UC-M10.04-C072-T04 · Concrete realization:** Trace “Metric and trace links” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Metric and trace links” needed to preserve “Operators can inspect the evidence behind a health claim”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C072-T06 · Dependency connection:** Connect the “Metric and trace links” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C072-T07 · Resource behavior:** Account for “Linked records and drill-down latency” in “Metric and trace links”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C072-T08 · Delivery check:** Exercise the “Metric and trace links” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C072-T09 · Patch review:** Review the “Metric and trace links” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C072-T10 · Delivery handoff:** Publish the “Metric and trace links” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Operators can inspect the evidence behind a health claim. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Metric and trace links”; copy its required invariant exactly: “Operators can inspect the evidence behind a health claim”.
- [ ] **UC-M10.04-C073-T02 · Observable terms:** Define each term in the “Metric and trace links” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C073-T03 · Precondition set:** List the preconditions under which “Operators can inspect the evidence behind a health claim” must hold for “Metric and trace links”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C073-T04 · Transition coverage:** Map the “Metric and trace links” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Metric and trace links”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C073-T06 · Satisfying fixture:** Create a concrete “Metric and trace links” case that satisfies “Operators can inspect the evidence behind a health claim”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C073-T07 · Violating fixture:** Create the source counterexample “A health badge has no traceable observation source” for “Metric and trace links”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C073-T08 · Enforcement evidence:** Exercise the “Metric and trace links” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C073-T09 · Regression linkage:** Link the “Metric and trace links” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Metric and trace links” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C074 · Integration

**Original checklist item:** Integrate metric and trace links with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Metric and trace links” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C074-T02 · Field mapping:** Map every “Metric and trace links” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Metric and trace links” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C074-T04 · Ownership agreement:** Specify who owns “Metric and trace links” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C074-T05 · Handoff implementation:** Connect “Metric and trace links” through the mapped seam using the real adapter or explicit specification reference; preserve “Operators can inspect the evidence behind a health claim” across the handoff.
- [ ] **UC-M10.04-C074-T06 · Absent-input case:** Omit one required “Metric and trace links” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C074-T07 · Stale-input case:** Supply an outdated “Metric and trace links” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Metric and trace links” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C074-T09 · Valid integration trace:** Run a valid “Metric and trace links” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C074-T10 · Seam review:** Reconcile the “Metric and trace links” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C075 · Valid-case test

**Original checklist item:** Test metric and trace links with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C075-T01 · Valid fixture choice:** Select an authorized-operator example for “Metric and trace links” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C075-T02 · Expected-result oracle:** Specify the “Metric and trace links” expected result independently of the implementation output; include the property “Operators can inspect the evidence behind a health claim” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C075-T03 · Fixture material:** Create the concrete “Metric and trace links” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C075-T04 · Target preparation:** Prepare the “Metric and trace links” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C075-T05 · Initial-state record:** Record the initial “Metric and trace links” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C075-T06 · Valid-path execution:** Drive the “Metric and trace links” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C075-T07 · Outcome comparison:** Compare every declared “Metric and trace links” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C075-T08 · State and bounds check:** Inspect the “Metric and trace links” ownership/state effects and actual use of “Linked records and drill-down latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C075-T09 · Repeatability check:** Repeat the same “Metric and trace links” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C075-T10 · Positive evidence:** Attach the “Metric and trace links” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C076 · Negative test

**Original checklist item:** Negative case: A health badge has no traceable observation source. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Metric and trace links” source counterexample: “A health badge has no traceable observation source”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Metric and trace links”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C076-T03 · Valid control:** Construct a valid “Metric and trace links” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C076-T04 · Minimal adverse input:** Derive the “Metric and trace links” adverse fixture from the control with the smallest documented change needed to reproduce “A health badge has no traceable observation source”; retain that change as reproducible data.
- [ ] **UC-M10.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Metric and trace links”; require “Operators can inspect the evidence behind a health claim” and forbid a false-success verdict.
- [ ] **UC-M10.04-C076-T06 · Adverse execution:** Exercise the “Metric and trace links” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C076-T07 · Effect inspection:** Inspect “Metric and trace links” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C076-T08 · Refusal versus failure:** Confirm the “Metric and trace links” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C076-T09 · Reset and retention:** Restore only the disposable “Metric and trace links” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C076-T10 · Negative regression:** Register the “Metric and trace links” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C077 · Change / failure test

**Original checklist item:** Exercise metric and trace links when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C077-T01 · Scenario record:** Write the “Metric and trace links” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “Operators can inspect the evidence behind a health claim”.
- [ ] **UC-M10.04-C077-T02 · Baseline capture:** Create a known-valid “Metric and trace links” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C077-T03 · Injection map:** Locate the “Metric and trace links” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Metric and trace links” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C077-T05 · Controlled trigger:** Introduce the controlled “Metric and trace links” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C077-T06 · Intermediate inspection:** Inspect the “Metric and trace links” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Metric and trace links”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Metric and trace links” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C077-T09 · Repeat and compare:** Repeat the selected “Metric and trace links” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C077-T10 · Failure evidence:** Publish the “Metric and trace links” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C078 · Bounds

**Original checklist item:** Set and test limits for linked records and drill-down latency; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Metric and trace links”: “Linked records and drill-down latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C078-T02 · Measurement method:** Choose how to observe each “Metric and trace links” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C078-T03 · Budget decision:** Select justified update, payload and presentation limits for “Metric and trace links”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Metric and trace links” cases for “Linked records and drill-down latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Metric and trace links” limit; preserve “Operators can inspect the evidence behind a health claim”.
- [ ] **UC-M10.04-C078-T06 · Normal measurement:** Run or review the normal “Metric and trace links” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C078-T07 · At-limit measurement:** Exercise the “Metric and trace links” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C078-T08 · Over-limit measurement:** Exercise the “Metric and trace links” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C078-T09 · Uncovered-scope report:** List the “Metric and trace links” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C078-T10 · Limit evidence:** Publish the selected “Metric and trace links” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C079 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for metric and trace links; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C079-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Metric and trace links”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C079-T02 · Authority text:** Write explicit nonsecret “Metric and trace links” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C079-T03 · Freshness fields:** Show the “Metric and trace links” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C079-T04 · Failure text:** Define the “Metric and trace links” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C079-T05 · Permission behavior:** Test the “Metric and trace links” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C079-T06 · Stale-state behavior:** Exercise “Metric and trace links” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C079-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Metric and trace links” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C079-T08 · Bounded updates:** Exercise “Metric and trace links” update saturation within “Linked records and drill-down latency”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C079-T09 · API reconciliation:** Compare the “Metric and trace links” displayed text and available controls with actual management results; document discrepancies and preserve “Operators can inspect the evidence behind a health claim”.
- [ ] **UC-M10.04-C079-T10 · UI diagnostic evidence:** Attach the “Metric and trace links” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for metric and trace links; label unexecuted checks as untested.

- [ ] **UC-M10.04-C080-T01 · Evidence inventory:** List the “Metric and trace links” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C080-T02 · Artifact references:** Record the exact “Metric and trace links” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C080-T03 · Fixture references:** Attach the “Metric and trace links” fixture IDs, input identities and oracle definition; preserve the source counterexample “A health badge has no traceable observation source” as a distinct evidence case.
- [ ] **UC-M10.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Metric and trace links”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C080-T05 · Environment record:** Record the actual “Metric and trace links” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C080-T06 · Expected versus observed:** Pair every “Metric and trace links” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C080-T07 · Failure and limit records:** Attach “Metric and trace links” change/failure and bounds evidence where required; include uncovered “Linked records and drill-down latency” and unresolved violations of “Operators can inspect the evidence behind a health claim”.
- [ ] **UC-M10.04-C080-T08 · Evidence hygiene:** Check the “Metric and trace links” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C080-T09 · Reproduction review:** Have the “Metric and trace links” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C080-T10 · Acceptance linkage:** Link the “Metric and trace links” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Accessible status representation

**Source delivery:** Use text and explicit status labels so health does not depend on motion or color alone.

**Source invariant:** A status remains interpretable when animations are disabled.

**Source negative case:** Stopped and ready states differ only by a subtle visual effect.

**Source bounded quantities:** Visible indicators and update frequency.

### UC-M10.04-C081 · Contract

**Original checklist item:** Specify the operator workflow for accessible status representation, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C081-T01 · Scope statement:** Describe the operator journey for “Accessible status representation”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Accessible status representation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C081-T03 · Output inventory:** List the outputs of “Accessible status representation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Accessible status representation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C081-T05 · Prerequisite contract:** Map “Accessible status representation” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Accessible status representation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C081-T07 · Invariant clause:** Add a normative clause for “Accessible status representation” that preserves “A status remains interpretable when animations are disabled”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Accessible status representation”; include the source counterexample “Stopped and ready states differ only by a subtle visual effect” and the intended safe disposition.
- [ ] **UC-M10.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Visible indicators and update frequency” in the “Accessible status representation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C081-T10 · Contract review:** Review the “Accessible status representation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C082 · Delivery

**Original checklist item:** Use text and explicit status labels so health does not depend on motion or color alone.

- [ ] **UC-M10.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Accessible status representation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C082-T02 · Change plan:** Break the source delivery for “Accessible status representation” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Accessible status representation” that realizes this source instruction: Use text and explicit status labels so health does not depend on motion or color alone.
- [ ] **UC-M10.04-C082-T04 · Concrete realization:** Trace “Accessible status representation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Accessible status representation” needed to preserve “A status remains interpretable when animations are disabled”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C082-T06 · Dependency connection:** Connect the “Accessible status representation” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C082-T07 · Resource behavior:** Account for “Visible indicators and update frequency” in “Accessible status representation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C082-T08 · Delivery check:** Exercise the “Accessible status representation” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C082-T09 · Patch review:** Review the “Accessible status representation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C082-T10 · Delivery handoff:** Publish the “Accessible status representation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A status remains interpretable when animations are disabled. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Accessible status representation”; copy its required invariant exactly: “A status remains interpretable when animations are disabled”.
- [ ] **UC-M10.04-C083-T02 · Observable terms:** Define each term in the “Accessible status representation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C083-T03 · Precondition set:** List the preconditions under which “A status remains interpretable when animations are disabled” must hold for “Accessible status representation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C083-T04 · Transition coverage:** Map the “Accessible status representation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Accessible status representation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C083-T06 · Satisfying fixture:** Create a concrete “Accessible status representation” case that satisfies “A status remains interpretable when animations are disabled”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C083-T07 · Violating fixture:** Create the source counterexample “Stopped and ready states differ only by a subtle visual effect” for “Accessible status representation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C083-T08 · Enforcement evidence:** Exercise the “Accessible status representation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C083-T09 · Regression linkage:** Link the “Accessible status representation” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Accessible status representation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C084 · Integration

**Original checklist item:** Integrate accessible status representation with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Accessible status representation” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C084-T02 · Field mapping:** Map every “Accessible status representation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Accessible status representation” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C084-T04 · Ownership agreement:** Specify who owns “Accessible status representation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C084-T05 · Handoff implementation:** Connect “Accessible status representation” through the mapped seam using the real adapter or explicit specification reference; preserve “A status remains interpretable when animations are disabled” across the handoff.
- [ ] **UC-M10.04-C084-T06 · Absent-input case:** Omit one required “Accessible status representation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C084-T07 · Stale-input case:** Supply an outdated “Accessible status representation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Accessible status representation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C084-T09 · Valid integration trace:** Run a valid “Accessible status representation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C084-T10 · Seam review:** Reconcile the “Accessible status representation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C085 · Valid-case test

**Original checklist item:** Test accessible status representation with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C085-T01 · Valid fixture choice:** Select an authorized-operator example for “Accessible status representation” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C085-T02 · Expected-result oracle:** Specify the “Accessible status representation” expected result independently of the implementation output; include the property “A status remains interpretable when animations are disabled” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C085-T03 · Fixture material:** Create the concrete “Accessible status representation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C085-T04 · Target preparation:** Prepare the “Accessible status representation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C085-T05 · Initial-state record:** Record the initial “Accessible status representation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C085-T06 · Valid-path execution:** Drive the “Accessible status representation” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C085-T07 · Outcome comparison:** Compare every declared “Accessible status representation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C085-T08 · State and bounds check:** Inspect the “Accessible status representation” ownership/state effects and actual use of “Visible indicators and update frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C085-T09 · Repeatability check:** Repeat the same “Accessible status representation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C085-T10 · Positive evidence:** Attach the “Accessible status representation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C086 · Negative test

**Original checklist item:** Negative case: Stopped and ready states differ only by a subtle visual effect. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Accessible status representation” source counterexample: “Stopped and ready states differ only by a subtle visual effect”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Accessible status representation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C086-T03 · Valid control:** Construct a valid “Accessible status representation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C086-T04 · Minimal adverse input:** Derive the “Accessible status representation” adverse fixture from the control with the smallest documented change needed to reproduce “Stopped and ready states differ only by a subtle visual effect”; retain that change as reproducible data.
- [ ] **UC-M10.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Accessible status representation”; require “A status remains interpretable when animations are disabled” and forbid a false-success verdict.
- [ ] **UC-M10.04-C086-T06 · Adverse execution:** Exercise the “Accessible status representation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C086-T07 · Effect inspection:** Inspect “Accessible status representation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C086-T08 · Refusal versus failure:** Confirm the “Accessible status representation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C086-T09 · Reset and retention:** Restore only the disposable “Accessible status representation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C086-T10 · Negative regression:** Register the “Accessible status representation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C087 · Change / failure test

**Original checklist item:** Exercise accessible status representation when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C087-T01 · Scenario record:** Write the “Accessible status representation” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “A status remains interpretable when animations are disabled”.
- [ ] **UC-M10.04-C087-T02 · Baseline capture:** Create a known-valid “Accessible status representation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C087-T03 · Injection map:** Locate the “Accessible status representation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Accessible status representation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C087-T05 · Controlled trigger:** Introduce the controlled “Accessible status representation” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C087-T06 · Intermediate inspection:** Inspect the “Accessible status representation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Accessible status representation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Accessible status representation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C087-T09 · Repeat and compare:** Repeat the selected “Accessible status representation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C087-T10 · Failure evidence:** Publish the “Accessible status representation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C088 · Bounds

**Original checklist item:** Set and test limits for visible indicators and update frequency; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Accessible status representation”: “Visible indicators and update frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C088-T02 · Measurement method:** Choose how to observe each “Accessible status representation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C088-T03 · Budget decision:** Select justified update, payload and presentation limits for “Accessible status representation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Accessible status representation” cases for “Visible indicators and update frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Accessible status representation” limit; preserve “A status remains interpretable when animations are disabled”.
- [ ] **UC-M10.04-C088-T06 · Normal measurement:** Run or review the normal “Accessible status representation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C088-T07 · At-limit measurement:** Exercise the “Accessible status representation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C088-T08 · Over-limit measurement:** Exercise the “Accessible status representation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C088-T09 · Uncovered-scope report:** List the “Accessible status representation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C088-T10 · Limit evidence:** Publish the selected “Accessible status representation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C089 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for accessible status representation; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C089-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Accessible status representation”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C089-T02 · Authority text:** Write explicit nonsecret “Accessible status representation” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C089-T03 · Freshness fields:** Show the “Accessible status representation” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C089-T04 · Failure text:** Define the “Accessible status representation” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C089-T05 · Permission behavior:** Test the “Accessible status representation” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C089-T06 · Stale-state behavior:** Exercise “Accessible status representation” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C089-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Accessible status representation” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C089-T08 · Bounded updates:** Exercise “Accessible status representation” update saturation within “Visible indicators and update frequency”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C089-T09 · API reconciliation:** Compare the “Accessible status representation” displayed text and available controls with actual management results; document discrepancies and preserve “A status remains interpretable when animations are disabled”.
- [ ] **UC-M10.04-C089-T10 · UI diagnostic evidence:** Attach the “Accessible status representation” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for accessible status representation; label unexecuted checks as untested.

- [ ] **UC-M10.04-C090-T01 · Evidence inventory:** List the “Accessible status representation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C090-T02 · Artifact references:** Record the exact “Accessible status representation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C090-T03 · Fixture references:** Attach the “Accessible status representation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Stopped and ready states differ only by a subtle visual effect” as a distinct evidence case.
- [ ] **UC-M10.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Accessible status representation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C090-T05 · Environment record:** Record the actual “Accessible status representation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C090-T06 · Expected versus observed:** Pair every “Accessible status representation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C090-T07 · Failure and limit records:** Attach “Accessible status representation” change/failure and bounds evidence where required; include uncovered “Visible indicators and update frequency” and unresolved violations of “A status remains interpretable when animations are disabled”.
- [ ] **UC-M10.04-C090-T08 · Evidence hygiene:** Check the “Accessible status representation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C090-T09 · Reproduction review:** Have the “Accessible status representation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C090-T10 · Acceptance linkage:** Link the “Accessible status representation” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Health-view qualification

**Source delivery:** Exercise stalled, stopped, unready, incorrect and healthy workload fixtures.

**Source invariant:** The view never reports current health solely from an old witness.

**Source negative case:** A stopped guest remains healthy after observation expiry.

**Source bounded quantities:** Fixture count and stale-state transitions.

### UC-M10.04-C091 · Contract

**Original checklist item:** Specify the operator workflow for health-view qualification, including target generation, allowed actions, authoritative data source and stale, denied or failed states.

- [ ] **UC-M10.04-C091-T01 · Scope statement:** Describe the operator journey for “Health-view qualification”; name the selected workload, generation, permitted action and authoritative displayed outcome.
- [ ] **UC-M10.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Health-view qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.04-C091-T03 · Output inventory:** List the outputs of “Health-view qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Health-view qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.04-C091-T05 · Prerequisite contract:** Map “Health-view qualification” to the source component prerequisites (UC-M05.05, UC-M10.02, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Health-view qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.04-C091-T07 · Invariant clause:** Add a normative clause for “Health-view qualification” that preserves “The view never reports current health solely from an old witness”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Health-view qualification”; include the source counterexample “A stopped guest remains healthy after observation expiry” and the intended safe disposition.
- [ ] **UC-M10.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture count and stale-state transitions” in the “Health-view qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.04-C091-T10 · Contract review:** Review the “Health-view qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.04-C092 · Delivery

**Original checklist item:** Exercise stalled, stopped, unready, incorrect and healthy workload fixtures.

- [ ] **UC-M10.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Health-view qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.04-C092-T02 · Change plan:** Break the source delivery for “Health-view qualification” into concrete edit targets and reviewable outputs; keep the UC-M10.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.04-C092-T03 · Core artifact:** Create the “Health-view qualification” fixture or harness for this source instruction: Exercise stalled, stopped, unready, incorrect and healthy workload fixtures.
- [ ] **UC-M10.04-C092-T04 · Concrete realization:** Connect the “Health-view qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Health-view qualification” needed to preserve “The view never reports current health solely from an old witness”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.04-C092-T06 · Dependency connection:** Connect the “Health-view qualification” view or interaction to current lifecycle observations, metrics, traces and stale-data presentation; do not substitute cached declarations or animation for observed status.
- [ ] **UC-M10.04-C092-T07 · Resource behavior:** Account for “Fixture count and stale-state transitions” in “Health-view qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.04-C092-T08 · Delivery check:** Exercise the “Health-view qualification” view with current, stale and denied data; compare its text and enabled actions with the authoritative response.
- [ ] **UC-M10.04-C092-T09 · Patch review:** Review the “Health-view qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.04-C092-T10 · Delivery handoff:** Publish the “Health-view qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The view never reports current health solely from an old witness. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Health-view qualification”; copy its required invariant exactly: “The view never reports current health solely from an old witness”.
- [ ] **UC-M10.04-C093-T02 · Observable terms:** Define each term in the “Health-view qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.04-C093-T03 · Precondition set:** List the preconditions under which “The view never reports current health solely from an old witness” must hold for “Health-view qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.04-C093-T04 · Transition coverage:** Map the “Health-view qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Health-view qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.04-C093-T06 · Satisfying fixture:** Create a concrete “Health-view qualification” case that satisfies “The view never reports current health solely from an old witness”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.04-C093-T07 · Violating fixture:** Create the source counterexample “A stopped guest remains healthy after observation expiry” for “Health-view qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.04-C093-T08 · Enforcement evidence:** Exercise the “Health-view qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.04-C093-T09 · Regression linkage:** Link the “Health-view qualification” property to changes in current lifecycle observations, metrics, traces and stale-data presentation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Health-view qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.04-C094 · Integration

**Original checklist item:** Integrate health-view qualification with current lifecycle observations, metrics, traces and stale-data presentation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Health-view qualification” across current lifecycle observations, metrics, traces and stale-data presentation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.04-C094-T02 · Field mapping:** Map every “Health-view qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Health-view qualification” (source dependency list: UC-M05.05, UC-M10.02, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.04-C094-T04 · Ownership agreement:** Specify who owns “Health-view qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.04-C094-T05 · Handoff implementation:** Connect “Health-view qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “The view never reports current health solely from an old witness” across the handoff.
- [ ] **UC-M10.04-C094-T06 · Absent-input case:** Omit one required “Health-view qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.04-C094-T07 · Stale-input case:** Supply an outdated “Health-view qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Health-view qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.04-C094-T09 · Valid integration trace:** Run a valid “Health-view qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.04-C094-T10 · Seam review:** Reconcile the “Health-view qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.04-C095 · Valid-case test

**Original checklist item:** Test health-view qualification with an authorized operator and current observed state; compare the displayed status and available actions with the actual management API result.

- [ ] **UC-M10.04-C095-T01 · Valid fixture choice:** Select an authorized-operator example for “Health-view qualification” with current observed state; record the expected text, generation and enabled actions.
- [ ] **UC-M10.04-C095-T02 · Expected-result oracle:** Specify the “Health-view qualification” expected result independently of the implementation output; include the property “The view never reports current health solely from an old witness” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.04-C095-T03 · Fixture material:** Create the concrete “Health-view qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.04-C095-T04 · Target preparation:** Prepare the “Health-view qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.04-C095-T05 · Initial-state record:** Record the initial “Health-view qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.04-C095-T06 · Valid-path execution:** Drive the “Health-view qualification” operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.
- [ ] **UC-M10.04-C095-T07 · Outcome comparison:** Compare every declared “Health-view qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.04-C095-T08 · State and bounds check:** Inspect the “Health-view qualification” ownership/state effects and actual use of “Fixture count and stale-state transitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.04-C095-T09 · Repeatability check:** Repeat the same “Health-view qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.04-C095-T10 · Positive evidence:** Attach the “Health-view qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.04-C096 · Negative test

**Original checklist item:** Negative case: A stopped guest remains healthy after observation expiry. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Health-view qualification” source counterexample: “A stopped guest remains healthy after observation expiry”; state which precondition or invariant it challenges.
- [ ] **UC-M10.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Health-view qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.04-C096-T03 · Valid control:** Construct a valid “Health-view qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.04-C096-T04 · Minimal adverse input:** Derive the “Health-view qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A stopped guest remains healthy after observation expiry”; retain that change as reproducible data.
- [ ] **UC-M10.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Health-view qualification”; require “The view never reports current health solely from an old witness” and forbid a false-success verdict.
- [ ] **UC-M10.04-C096-T06 · Adverse execution:** Exercise the “Health-view qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.04-C096-T07 · Effect inspection:** Inspect “Health-view qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.04-C096-T08 · Refusal versus failure:** Confirm the “Health-view qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.04-C096-T09 · Reset and retention:** Restore only the disposable “Health-view qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.04-C096-T10 · Negative regression:** Register the “Health-view qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.04-C097 · Change / failure test

**Original checklist item:** Exercise health-view qualification when a workload stops while the view still has its last successful observation cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.04-C097-T01 · Scenario record:** Write the “Health-view qualification” change/failure scenario exactly as supplied: a workload stops while the view still has its last successful observation cached; identify the property that must remain true: “The view never reports current health solely from an old witness”.
- [ ] **UC-M10.04-C097-T02 · Baseline capture:** Create a known-valid “Health-view qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.04-C097-T03 · Injection map:** Locate the “Health-view qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Health-view qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.04-C097-T05 · Controlled trigger:** Introduce the controlled “Health-view qualification” scenario in the disposable fixture: a workload stops while the view still has its last successful observation cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.04-C097-T06 · Intermediate inspection:** Inspect the “Health-view qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Health-view qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Health-view qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.04-C097-T09 · Repeat and compare:** Repeat the selected “Health-view qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.04-C097-T10 · Failure evidence:** Publish the “Health-view qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.04-C098 · Bounds

**Original checklist item:** Set and test limits for fixture count and stale-state transitions; check normal, saturated and unavailable-data behavior without allowing updates to obscure authority or final outcomes.

- [ ] **UC-M10.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Health-view qualification”: “Fixture count and stale-state transitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.04-C098-T02 · Measurement method:** Choose how to observe each “Health-view qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.04-C098-T03 · Budget decision:** Select justified update, payload and presentation limits for “Health-view qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Health-view qualification” cases for “Fixture count and stale-state transitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Health-view qualification” limit; preserve “The view never reports current health solely from an old witness”.
- [ ] **UC-M10.04-C098-T06 · Normal measurement:** Run or review the normal “Health-view qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.04-C098-T07 · At-limit measurement:** Exercise the “Health-view qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.04-C098-T08 · Over-limit measurement:** Exercise the “Health-view qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.04-C098-T09 · Uncovered-scope report:** List the “Health-view qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.04-C098-T10 · Limit evidence:** Publish the selected “Health-view qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.04-C099 · Diagnostics / review

**Original checklist item:** Provide explicit text and observed-state diagnostics for health-view qualification; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C099-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Health-view qualification”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C099-T02 · Authority text:** Write explicit nonsecret “Health-view qualification” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C099-T03 · Freshness fields:** Show the “Health-view qualification” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C099-T04 · Failure text:** Define the “Health-view qualification” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C099-T05 · Permission behavior:** Test the “Health-view qualification” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C099-T06 · Stale-state behavior:** Exercise “Health-view qualification” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C099-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Health-view qualification” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C099-T08 · Bounded updates:** Exercise “Health-view qualification” update saturation within “Fixture count and stale-state transitions”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C099-T09 · API reconciliation:** Compare the “Health-view qualification” displayed text and available controls with actual management results; document discrepancies and preserve “The view never reports current health solely from an old witness”.
- [ ] **UC-M10.04-C099-T10 · UI diagnostic evidence:** Attach the “Health-view qualification” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

### UC-M10.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for health-view qualification; label unexecuted checks as untested.

- [ ] **UC-M10.04-C100-T01 · Evidence inventory:** List the “Health-view qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.04-C100-T02 · Artifact references:** Record the exact “Health-view qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.04-C100-T03 · Fixture references:** Attach the “Health-view qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stopped guest remains healthy after observation expiry” as a distinct evidence case.
- [ ] **UC-M10.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Health-view qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.04-C100-T05 · Environment record:** Record the actual “Health-view qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.04-C100-T06 · Expected versus observed:** Pair every “Health-view qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.04-C100-T07 · Failure and limit records:** Attach “Health-view qualification” change/failure and bounds evidence where required; include uncovered “Fixture count and stale-state transitions” and unresolved violations of “The view never reports current health solely from an old witness”.
- [ ] **UC-M10.04-C100-T08 · Evidence hygiene:** Check the “Health-view qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.04-C100-T09 · Reproduction review:** Have the “Health-view qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.04-C100-T10 · Acceptance linkage:** Link the “Health-view qualification” evidence to its parent and UC-M10.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

