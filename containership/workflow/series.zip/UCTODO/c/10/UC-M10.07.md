# UC-M10.07 — Crash dumps and support bundle export

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/10.md)

| Field | Preserved source value |
|---|---|
| Workstream | 10. Observability and operator experience |
| Milestone | C |
| Priority | P1 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M06.07](../06/UC-M06.07.md), [UC-M07.07](../07/UC-M07.07.md), [UC-M10.01](../10/UC-M10.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4]. |

## Original requirement

Export versioned redacted state, logs, hashes and host capability evidence without keys, user cargo leakage or unbounded archives.

**Original acceptance criterion:** A support bundle is sufficient to reproduce a seeded failure and passes secret/content-scope checks.

**Source trace:** Original checklist `UC100/c/10/UC-M10.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 970–980 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Support bundle schema

**Source delivery:** Define a versioned bundle manifest with content scope and artifact identities.

**Source invariant:** A bundle has explicit contents rather than an unrestricted workspace copy.

**Source negative case:** Export recursively includes all user cargo by default.

**Source bounded quantities:** Bundle entries and metadata bytes.

### UC-M10.07-C001 · Contract

**Original checklist item:** Specify support bundle schema inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C001-T01 · Scope statement:** Draft the operation boundary for “Support bundle schema” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Support bundle schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C001-T03 · Output inventory:** List the outputs of “Support bundle schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Support bundle schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C001-T05 · Prerequisite contract:** Map “Support bundle schema” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Support bundle schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C001-T07 · Invariant clause:** Add a normative clause for “Support bundle schema” that preserves “A bundle has explicit contents rather than an unrestricted workspace copy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Support bundle schema”; include the source counterexample “Export recursively includes all user cargo by default” and the intended safe disposition.
- [ ] **UC-M10.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Bundle entries and metadata bytes” in the “Support bundle schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C001-T10 · Contract review:** Review the “Support bundle schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C002 · Delivery

**Original checklist item:** Define a versioned bundle manifest with content scope and artifact identities.

- [ ] **UC-M10.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Support bundle schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C002-T02 · Change plan:** Break the source delivery for “Support bundle schema” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C002-T03 · Core artifact:** Create the “Support bundle schema” model, schema or inventory that realizes this source instruction: Define a versioned bundle manifest with content scope and artifact identities.
- [ ] **UC-M10.07-C002-T04 · Concrete realization:** Populate “Support bundle schema” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M10.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Support bundle schema” needed to preserve “A bundle has explicit contents rather than an unrestricted workspace copy”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C002-T06 · Dependency connection:** Connect the “Support bundle schema” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C002-T07 · Resource behavior:** Account for “Bundle entries and metadata bytes” in “Support bundle schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C002-T08 · Delivery check:** Run the smallest real “Support bundle schema” path and its adverse fixture “Export recursively includes all user cargo by default”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C002-T09 · Patch review:** Review the “Support bundle schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C002-T10 · Delivery handoff:** Publish the “Support bundle schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A bundle has explicit contents rather than an unrestricted workspace copy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Support bundle schema”; copy its required invariant exactly: “A bundle has explicit contents rather than an unrestricted workspace copy”.
- [ ] **UC-M10.07-C003-T02 · Observable terms:** Define each term in the “Support bundle schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C003-T03 · Precondition set:** List the preconditions under which “A bundle has explicit contents rather than an unrestricted workspace copy” must hold for “Support bundle schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C003-T04 · Transition coverage:** Map the “Support bundle schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Support bundle schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C003-T06 · Satisfying fixture:** Create a concrete “Support bundle schema” case that satisfies “A bundle has explicit contents rather than an unrestricted workspace copy”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C003-T07 · Violating fixture:** Create the source counterexample “Export recursively includes all user cargo by default” for “Support bundle schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C003-T08 · Enforcement evidence:** Exercise the “Support bundle schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C003-T09 · Regression linkage:** Link the “Support bundle schema” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Support bundle schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C004 · Integration

**Original checklist item:** Integrate support bundle schema with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Support bundle schema” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C004-T02 · Field mapping:** Map every “Support bundle schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Support bundle schema” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C004-T04 · Ownership agreement:** Specify who owns “Support bundle schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C004-T05 · Handoff implementation:** Connect “Support bundle schema” through the mapped seam using the real adapter or explicit specification reference; preserve “A bundle has explicit contents rather than an unrestricted workspace copy” across the handoff.
- [ ] **UC-M10.07-C004-T06 · Absent-input case:** Omit one required “Support bundle schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C004-T07 · Stale-input case:** Supply an outdated “Support bundle schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Support bundle schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C004-T09 · Valid integration trace:** Run a valid “Support bundle schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C004-T10 · Seam review:** Reconcile the “Support bundle schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for support bundle schema; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Support bundle schema” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C005-T02 · Expected-result oracle:** Specify the “Support bundle schema” expected result independently of the implementation output; include the property “A bundle has explicit contents rather than an unrestricted workspace copy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C005-T03 · Fixture material:** Create the concrete “Support bundle schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C005-T04 · Target preparation:** Prepare the “Support bundle schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C005-T05 · Initial-state record:** Record the initial “Support bundle schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C005-T06 · Valid-path execution:** Execute the “Support bundle schema” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C005-T07 · Outcome comparison:** Compare every declared “Support bundle schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C005-T08 · State and bounds check:** Inspect the “Support bundle schema” ownership/state effects and actual use of “Bundle entries and metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C005-T09 · Repeatability check:** Repeat the same “Support bundle schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C005-T10 · Positive evidence:** Attach the “Support bundle schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C006 · Negative test

**Original checklist item:** Negative case: Export recursively includes all user cargo by default. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Support bundle schema” source counterexample: “Export recursively includes all user cargo by default”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Support bundle schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C006-T03 · Valid control:** Construct a valid “Support bundle schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C006-T04 · Minimal adverse input:** Derive the “Support bundle schema” adverse fixture from the control with the smallest documented change needed to reproduce “Export recursively includes all user cargo by default”; retain that change as reproducible data.
- [ ] **UC-M10.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Support bundle schema”; require “A bundle has explicit contents rather than an unrestricted workspace copy” and forbid a false-success verdict.
- [ ] **UC-M10.07-C006-T06 · Adverse execution:** Exercise the “Support bundle schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C006-T07 · Effect inspection:** Inspect “Support bundle schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C006-T08 · Refusal versus failure:** Confirm the “Support bundle schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C006-T09 · Reset and retention:** Restore only the disposable “Support bundle schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C006-T10 · Negative regression:** Register the “Support bundle schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C007 · Change / failure test

**Original checklist item:** Exercise support bundle schema when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C007-T01 · Scenario record:** Write the “Support bundle schema” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “A bundle has explicit contents rather than an unrestricted workspace copy”.
- [ ] **UC-M10.07-C007-T02 · Baseline capture:** Create a known-valid “Support bundle schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C007-T03 · Injection map:** Locate the “Support bundle schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Support bundle schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C007-T05 · Controlled trigger:** Introduce the controlled “Support bundle schema” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C007-T06 · Intermediate inspection:** Inspect the “Support bundle schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Support bundle schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Support bundle schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C007-T09 · Repeat and compare:** Repeat the selected “Support bundle schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C007-T10 · Failure evidence:** Publish the “Support bundle schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for bundle entries and metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Support bundle schema”: “Bundle entries and metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C008-T02 · Measurement method:** Choose how to observe each “Support bundle schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Support bundle schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Support bundle schema” cases for “Bundle entries and metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Support bundle schema” limit; preserve “A bundle has explicit contents rather than an unrestricted workspace copy”.
- [ ] **UC-M10.07-C008-T06 · Normal measurement:** Run or review the normal “Support bundle schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C008-T07 · At-limit measurement:** Exercise the “Support bundle schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C008-T08 · Over-limit measurement:** Exercise the “Support bundle schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C008-T09 · Uncovered-scope report:** List the “Support bundle schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C008-T10 · Limit evidence:** Publish the selected “Support bundle schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for support bundle schema with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C009-T01 · Event inventory:** List the “Support bundle schema” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Support bundle schema” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C009-T03 · Failure mapping:** Map each documented “Support bundle schema” refusal or error to a diagnostic outcome; include “Export recursively includes all user cargo by default” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C009-T04 · Emission path:** Add the “Support bundle schema” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C009-T05 · Redaction check:** Test “Support bundle schema” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C009-T06 · Output budget:** Set and exercise bounded “Support bundle schema” message size, rate and retention compatible with “Bundle entries and metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C009-T07 · Success/refusal fixtures:** Capture “Support bundle schema” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Support bundle schema” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C009-T09 · Operator review:** Read the “Support bundle schema” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C009-T10 · Diagnostic evidence:** Publish redacted “Support bundle schema” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for support bundle schema; label unexecuted checks as untested.

- [ ] **UC-M10.07-C010-T01 · Evidence inventory:** List the “Support bundle schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C010-T02 · Artifact references:** Record the exact “Support bundle schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C010-T03 · Fixture references:** Attach the “Support bundle schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “Export recursively includes all user cargo by default” as a distinct evidence case.
- [ ] **UC-M10.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Support bundle schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C010-T05 · Environment record:** Record the actual “Support bundle schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C010-T06 · Expected versus observed:** Pair every “Support bundle schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C010-T07 · Failure and limit records:** Attach “Support bundle schema” change/failure and bounds evidence where required; include uncovered “Bundle entries and metadata bytes” and unresolved violations of “A bundle has explicit contents rather than an unrestricted workspace copy”.
- [ ] **UC-M10.07-C010-T08 · Evidence hygiene:** Check the “Support bundle schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C010-T09 · Reproduction review:** Have the “Support bundle schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C010-T10 · Acceptance linkage:** Link the “Support bundle schema” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Failure context collection

**Source delivery:** Include bounded failure state and reproduction context for the selected incident.

**Source invariant:** The bundle contains the information required by its declared reproduction scope.

**Source negative case:** A support export omits the failing generation or invocation.

**Source bounded quantities:** Failure records and selected state bytes.

### UC-M10.07-C011 · Contract

**Original checklist item:** Specify failure context collection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C011-T01 · Scope statement:** Draft the operation boundary for “Failure context collection” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure context collection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C011-T03 · Output inventory:** List the outputs of “Failure context collection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure context collection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C011-T05 · Prerequisite contract:** Map “Failure context collection” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Failure context collection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C011-T07 · Invariant clause:** Add a normative clause for “Failure context collection” that preserves “The bundle contains the information required by its declared reproduction scope”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure context collection”; include the source counterexample “A support export omits the failing generation or invocation” and the intended safe disposition.
- [ ] **UC-M10.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure records and selected state bytes” in the “Failure context collection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C011-T10 · Contract review:** Review the “Failure context collection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C012 · Delivery

**Original checklist item:** Include bounded failure state and reproduction context for the selected incident.

- [ ] **UC-M10.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure context collection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C012-T02 · Change plan:** Break the source delivery for “Failure context collection” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Failure context collection” that realizes this source instruction: Include bounded failure state and reproduction context for the selected incident.
- [ ] **UC-M10.07-C012-T04 · Concrete realization:** Trace “Failure context collection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure context collection” needed to preserve “The bundle contains the information required by its declared reproduction scope”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C012-T06 · Dependency connection:** Connect the “Failure context collection” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C012-T07 · Resource behavior:** Account for “Failure records and selected state bytes” in “Failure context collection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C012-T08 · Delivery check:** Run the smallest real “Failure context collection” path and its adverse fixture “A support export omits the failing generation or invocation”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C012-T09 · Patch review:** Review the “Failure context collection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C012-T10 · Delivery handoff:** Publish the “Failure context collection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The bundle contains the information required by its declared reproduction scope. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Failure context collection”; copy its required invariant exactly: “The bundle contains the information required by its declared reproduction scope”.
- [ ] **UC-M10.07-C013-T02 · Observable terms:** Define each term in the “Failure context collection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C013-T03 · Precondition set:** List the preconditions under which “The bundle contains the information required by its declared reproduction scope” must hold for “Failure context collection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C013-T04 · Transition coverage:** Map the “Failure context collection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure context collection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C013-T06 · Satisfying fixture:** Create a concrete “Failure context collection” case that satisfies “The bundle contains the information required by its declared reproduction scope”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C013-T07 · Violating fixture:** Create the source counterexample “A support export omits the failing generation or invocation” for “Failure context collection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C013-T08 · Enforcement evidence:** Exercise the “Failure context collection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C013-T09 · Regression linkage:** Link the “Failure context collection” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Failure context collection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C014 · Integration

**Original checklist item:** Integrate failure context collection with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure context collection” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C014-T02 · Field mapping:** Map every “Failure context collection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure context collection” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C014-T04 · Ownership agreement:** Specify who owns “Failure context collection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C014-T05 · Handoff implementation:** Connect “Failure context collection” through the mapped seam using the real adapter or explicit specification reference; preserve “The bundle contains the information required by its declared reproduction scope” across the handoff.
- [ ] **UC-M10.07-C014-T06 · Absent-input case:** Omit one required “Failure context collection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C014-T07 · Stale-input case:** Supply an outdated “Failure context collection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Failure context collection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C014-T09 · Valid integration trace:** Run a valid “Failure context collection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C014-T10 · Seam review:** Reconcile the “Failure context collection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure context collection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure context collection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C015-T02 · Expected-result oracle:** Specify the “Failure context collection” expected result independently of the implementation output; include the property “The bundle contains the information required by its declared reproduction scope” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C015-T03 · Fixture material:** Create the concrete “Failure context collection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C015-T04 · Target preparation:** Prepare the “Failure context collection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C015-T05 · Initial-state record:** Record the initial “Failure context collection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C015-T06 · Valid-path execution:** Execute the “Failure context collection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C015-T07 · Outcome comparison:** Compare every declared “Failure context collection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C015-T08 · State and bounds check:** Inspect the “Failure context collection” ownership/state effects and actual use of “Failure records and selected state bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C015-T09 · Repeatability check:** Repeat the same “Failure context collection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C015-T10 · Positive evidence:** Attach the “Failure context collection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C016 · Negative test

**Original checklist item:** Negative case: A support export omits the failing generation or invocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Failure context collection” source counterexample: “A support export omits the failing generation or invocation”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure context collection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C016-T03 · Valid control:** Construct a valid “Failure context collection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C016-T04 · Minimal adverse input:** Derive the “Failure context collection” adverse fixture from the control with the smallest documented change needed to reproduce “A support export omits the failing generation or invocation”; retain that change as reproducible data.
- [ ] **UC-M10.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure context collection”; require “The bundle contains the information required by its declared reproduction scope” and forbid a false-success verdict.
- [ ] **UC-M10.07-C016-T06 · Adverse execution:** Exercise the “Failure context collection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C016-T07 · Effect inspection:** Inspect “Failure context collection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C016-T08 · Refusal versus failure:** Confirm the “Failure context collection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C016-T09 · Reset and retention:** Restore only the disposable “Failure context collection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C016-T10 · Negative regression:** Register the “Failure context collection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C017 · Change / failure test

**Original checklist item:** Exercise failure context collection when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C017-T01 · Scenario record:** Write the “Failure context collection” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “The bundle contains the information required by its declared reproduction scope”.
- [ ] **UC-M10.07-C017-T02 · Baseline capture:** Create a known-valid “Failure context collection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C017-T03 · Injection map:** Locate the “Failure context collection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Failure context collection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C017-T05 · Controlled trigger:** Introduce the controlled “Failure context collection” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C017-T06 · Intermediate inspection:** Inspect the “Failure context collection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure context collection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure context collection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C017-T09 · Repeat and compare:** Repeat the selected “Failure context collection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C017-T10 · Failure evidence:** Publish the “Failure context collection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for failure records and selected state bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Failure context collection”: “Failure records and selected state bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C018-T02 · Measurement method:** Choose how to observe each “Failure context collection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Failure context collection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure context collection” cases for “Failure records and selected state bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure context collection” limit; preserve “The bundle contains the information required by its declared reproduction scope”.
- [ ] **UC-M10.07-C018-T06 · Normal measurement:** Run or review the normal “Failure context collection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C018-T07 · At-limit measurement:** Exercise the “Failure context collection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C018-T08 · Over-limit measurement:** Exercise the “Failure context collection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C018-T09 · Uncovered-scope report:** List the “Failure context collection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C018-T10 · Limit evidence:** Publish the selected “Failure context collection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure context collection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C019-T01 · Event inventory:** List the “Failure context collection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Failure context collection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C019-T03 · Failure mapping:** Map each documented “Failure context collection” refusal or error to a diagnostic outcome; include “A support export omits the failing generation or invocation” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C019-T04 · Emission path:** Add the “Failure context collection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C019-T05 · Redaction check:** Test “Failure context collection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C019-T06 · Output budget:** Set and exercise bounded “Failure context collection” message size, rate and retention compatible with “Failure records and selected state bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C019-T07 · Success/refusal fixtures:** Capture “Failure context collection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure context collection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C019-T09 · Operator review:** Read the “Failure context collection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C019-T10 · Diagnostic evidence:** Publish redacted “Failure context collection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure context collection; label unexecuted checks as untested.

- [ ] **UC-M10.07-C020-T01 · Evidence inventory:** List the “Failure context collection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C020-T02 · Artifact references:** Record the exact “Failure context collection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C020-T03 · Fixture references:** Attach the “Failure context collection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A support export omits the failing generation or invocation” as a distinct evidence case.
- [ ] **UC-M10.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure context collection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C020-T05 · Environment record:** Record the actual “Failure context collection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C020-T06 · Expected versus observed:** Pair every “Failure context collection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C020-T07 · Failure and limit records:** Attach “Failure context collection” change/failure and bounds evidence where required; include uncovered “Failure records and selected state bytes” and unresolved violations of “The bundle contains the information required by its declared reproduction scope”.
- [ ] **UC-M10.07-C020-T08 · Evidence hygiene:** Check the “Failure context collection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C020-T09 · Reproduction review:** Have the “Failure context collection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C020-T10 · Acceptance linkage:** Link the “Failure context collection” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Version and digest inventory

**Source delivery:** Record ship, image, engine and relevant dependency identities.

**Source invariant:** Support analysis can identify the exact tested software.

**Source negative case:** A bundle contains only a display version without image identity.

**Source bounded quantities:** Inventory entries and hashing cost.

### UC-M10.07-C021 · Contract

**Original checklist item:** Specify version and digest inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C021-T01 · Scope statement:** Draft the operation boundary for “Version and digest inventory” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Version and digest inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C021-T03 · Output inventory:** List the outputs of “Version and digest inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Version and digest inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C021-T05 · Prerequisite contract:** Map “Version and digest inventory” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Version and digest inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C021-T07 · Invariant clause:** Add a normative clause for “Version and digest inventory” that preserves “Support analysis can identify the exact tested software”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Version and digest inventory”; include the source counterexample “A bundle contains only a display version without image identity” and the intended safe disposition.
- [ ] **UC-M10.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Inventory entries and hashing cost” in the “Version and digest inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C021-T10 · Contract review:** Review the “Version and digest inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C022 · Delivery

**Original checklist item:** Record ship, image, engine and relevant dependency identities.

- [ ] **UC-M10.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Version and digest inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C022-T02 · Change plan:** Break the source delivery for “Version and digest inventory” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C022-T03 · Core artifact:** Create the “Version and digest inventory” model, schema or inventory that realizes this source instruction: Record ship, image, engine and relevant dependency identities.
- [ ] **UC-M10.07-C022-T04 · Concrete realization:** Populate “Version and digest inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M10.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Version and digest inventory” needed to preserve “Support analysis can identify the exact tested software”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C022-T06 · Dependency connection:** Connect the “Version and digest inventory” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C022-T07 · Resource behavior:** Account for “Inventory entries and hashing cost” in “Version and digest inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C022-T08 · Delivery check:** Run the smallest real “Version and digest inventory” path and its adverse fixture “A bundle contains only a display version without image identity”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C022-T09 · Patch review:** Review the “Version and digest inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C022-T10 · Delivery handoff:** Publish the “Version and digest inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Support analysis can identify the exact tested software. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Version and digest inventory”; copy its required invariant exactly: “Support analysis can identify the exact tested software”.
- [ ] **UC-M10.07-C023-T02 · Observable terms:** Define each term in the “Version and digest inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C023-T03 · Precondition set:** List the preconditions under which “Support analysis can identify the exact tested software” must hold for “Version and digest inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C023-T04 · Transition coverage:** Map the “Version and digest inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Version and digest inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C023-T06 · Satisfying fixture:** Create a concrete “Version and digest inventory” case that satisfies “Support analysis can identify the exact tested software”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C023-T07 · Violating fixture:** Create the source counterexample “A bundle contains only a display version without image identity” for “Version and digest inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C023-T08 · Enforcement evidence:** Exercise the “Version and digest inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C023-T09 · Regression linkage:** Link the “Version and digest inventory” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Version and digest inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C024 · Integration

**Original checklist item:** Integrate version and digest inventory with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Version and digest inventory” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C024-T02 · Field mapping:** Map every “Version and digest inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Version and digest inventory” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C024-T04 · Ownership agreement:** Specify who owns “Version and digest inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C024-T05 · Handoff implementation:** Connect “Version and digest inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Support analysis can identify the exact tested software” across the handoff.
- [ ] **UC-M10.07-C024-T06 · Absent-input case:** Omit one required “Version and digest inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C024-T07 · Stale-input case:** Supply an outdated “Version and digest inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Version and digest inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C024-T09 · Valid integration trace:** Run a valid “Version and digest inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C024-T10 · Seam review:** Reconcile the “Version and digest inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for version and digest inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Version and digest inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C025-T02 · Expected-result oracle:** Specify the “Version and digest inventory” expected result independently of the implementation output; include the property “Support analysis can identify the exact tested software” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C025-T03 · Fixture material:** Create the concrete “Version and digest inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C025-T04 · Target preparation:** Prepare the “Version and digest inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C025-T05 · Initial-state record:** Record the initial “Version and digest inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C025-T06 · Valid-path execution:** Execute the “Version and digest inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C025-T07 · Outcome comparison:** Compare every declared “Version and digest inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C025-T08 · State and bounds check:** Inspect the “Version and digest inventory” ownership/state effects and actual use of “Inventory entries and hashing cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C025-T09 · Repeatability check:** Repeat the same “Version and digest inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C025-T10 · Positive evidence:** Attach the “Version and digest inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C026 · Negative test

**Original checklist item:** Negative case: A bundle contains only a display version without image identity. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Version and digest inventory” source counterexample: “A bundle contains only a display version without image identity”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Version and digest inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C026-T03 · Valid control:** Construct a valid “Version and digest inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C026-T04 · Minimal adverse input:** Derive the “Version and digest inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A bundle contains only a display version without image identity”; retain that change as reproducible data.
- [ ] **UC-M10.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Version and digest inventory”; require “Support analysis can identify the exact tested software” and forbid a false-success verdict.
- [ ] **UC-M10.07-C026-T06 · Adverse execution:** Exercise the “Version and digest inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C026-T07 · Effect inspection:** Inspect “Version and digest inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C026-T08 · Refusal versus failure:** Confirm the “Version and digest inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C026-T09 · Reset and retention:** Restore only the disposable “Version and digest inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C026-T10 · Negative regression:** Register the “Version and digest inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C027 · Change / failure test

**Original checklist item:** Exercise version and digest inventory when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C027-T01 · Scenario record:** Write the “Version and digest inventory” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “Support analysis can identify the exact tested software”.
- [ ] **UC-M10.07-C027-T02 · Baseline capture:** Create a known-valid “Version and digest inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C027-T03 · Injection map:** Locate the “Version and digest inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Version and digest inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C027-T05 · Controlled trigger:** Introduce the controlled “Version and digest inventory” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C027-T06 · Intermediate inspection:** Inspect the “Version and digest inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Version and digest inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Version and digest inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C027-T09 · Repeat and compare:** Repeat the selected “Version and digest inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C027-T10 · Failure evidence:** Publish the “Version and digest inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for inventory entries and hashing cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Version and digest inventory”: “Inventory entries and hashing cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C028-T02 · Measurement method:** Choose how to observe each “Version and digest inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Version and digest inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Version and digest inventory” cases for “Inventory entries and hashing cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Version and digest inventory” limit; preserve “Support analysis can identify the exact tested software”.
- [ ] **UC-M10.07-C028-T06 · Normal measurement:** Run or review the normal “Version and digest inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C028-T07 · At-limit measurement:** Exercise the “Version and digest inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C028-T08 · Over-limit measurement:** Exercise the “Version and digest inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C028-T09 · Uncovered-scope report:** List the “Version and digest inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C028-T10 · Limit evidence:** Publish the selected “Version and digest inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for version and digest inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C029-T01 · Event inventory:** List the “Version and digest inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Version and digest inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C029-T03 · Failure mapping:** Map each documented “Version and digest inventory” refusal or error to a diagnostic outcome; include “A bundle contains only a display version without image identity” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C029-T04 · Emission path:** Add the “Version and digest inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C029-T05 · Redaction check:** Test “Version and digest inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C029-T06 · Output budget:** Set and exercise bounded “Version and digest inventory” message size, rate and retention compatible with “Inventory entries and hashing cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C029-T07 · Success/refusal fixtures:** Capture “Version and digest inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Version and digest inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C029-T09 · Operator review:** Read the “Version and digest inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C029-T10 · Diagnostic evidence:** Publish redacted “Version and digest inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for version and digest inventory; label unexecuted checks as untested.

- [ ] **UC-M10.07-C030-T01 · Evidence inventory:** List the “Version and digest inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C030-T02 · Artifact references:** Record the exact “Version and digest inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C030-T03 · Fixture references:** Attach the “Version and digest inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A bundle contains only a display version without image identity” as a distinct evidence case.
- [ ] **UC-M10.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Version and digest inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C030-T05 · Environment record:** Record the actual “Version and digest inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C030-T06 · Expected versus observed:** Pair every “Version and digest inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C030-T07 · Failure and limit records:** Attach “Version and digest inventory” change/failure and bounds evidence where required; include uncovered “Inventory entries and hashing cost” and unresolved violations of “Support analysis can identify the exact tested software”.
- [ ] **UC-M10.07-C030-T08 · Evidence hygiene:** Check the “Version and digest inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C030-T09 · Reproduction review:** Have the “Version and digest inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C030-T10 · Acceptance linkage:** Link the “Version and digest inventory” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Host capability evidence

**Source delivery:** Include selected nonsecret backend and host constraint observations.

**Source invariant:** Support data identifies the actual execution profile.

**Source negative case:** An isolation issue is exported without backend information.

**Source bounded quantities:** Capability fields and report size.

### UC-M10.07-C031 · Contract

**Original checklist item:** Specify host capability evidence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C031-T01 · Scope statement:** Draft the operation boundary for “Host capability evidence” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Host capability evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C031-T03 · Output inventory:** List the outputs of “Host capability evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Host capability evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C031-T05 · Prerequisite contract:** Map “Host capability evidence” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Host capability evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C031-T07 · Invariant clause:** Add a normative clause for “Host capability evidence” that preserves “Support data identifies the actual execution profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Host capability evidence”; include the source counterexample “An isolation issue is exported without backend information” and the intended safe disposition.
- [ ] **UC-M10.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capability fields and report size” in the “Host capability evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C031-T10 · Contract review:** Review the “Host capability evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C032 · Delivery

**Original checklist item:** Include selected nonsecret backend and host constraint observations.

- [ ] **UC-M10.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Host capability evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C032-T02 · Change plan:** Break the source delivery for “Host capability evidence” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Host capability evidence” that realizes this source instruction: Include selected nonsecret backend and host constraint observations.
- [ ] **UC-M10.07-C032-T04 · Concrete realization:** Trace “Host capability evidence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Host capability evidence” needed to preserve “Support data identifies the actual execution profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C032-T06 · Dependency connection:** Connect the “Host capability evidence” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C032-T07 · Resource behavior:** Account for “Capability fields and report size” in “Host capability evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C032-T08 · Delivery check:** Run the smallest real “Host capability evidence” path and its adverse fixture “An isolation issue is exported without backend information”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C032-T09 · Patch review:** Review the “Host capability evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C032-T10 · Delivery handoff:** Publish the “Host capability evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Support data identifies the actual execution profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Host capability evidence”; copy its required invariant exactly: “Support data identifies the actual execution profile”.
- [ ] **UC-M10.07-C033-T02 · Observable terms:** Define each term in the “Host capability evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C033-T03 · Precondition set:** List the preconditions under which “Support data identifies the actual execution profile” must hold for “Host capability evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C033-T04 · Transition coverage:** Map the “Host capability evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Host capability evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C033-T06 · Satisfying fixture:** Create a concrete “Host capability evidence” case that satisfies “Support data identifies the actual execution profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C033-T07 · Violating fixture:** Create the source counterexample “An isolation issue is exported without backend information” for “Host capability evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C033-T08 · Enforcement evidence:** Exercise the “Host capability evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C033-T09 · Regression linkage:** Link the “Host capability evidence” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Host capability evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C034 · Integration

**Original checklist item:** Integrate host capability evidence with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Host capability evidence” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C034-T02 · Field mapping:** Map every “Host capability evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Host capability evidence” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C034-T04 · Ownership agreement:** Specify who owns “Host capability evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C034-T05 · Handoff implementation:** Connect “Host capability evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “Support data identifies the actual execution profile” across the handoff.
- [ ] **UC-M10.07-C034-T06 · Absent-input case:** Omit one required “Host capability evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C034-T07 · Stale-input case:** Supply an outdated “Host capability evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Host capability evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C034-T09 · Valid integration trace:** Run a valid “Host capability evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C034-T10 · Seam review:** Reconcile the “Host capability evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for host capability evidence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Host capability evidence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C035-T02 · Expected-result oracle:** Specify the “Host capability evidence” expected result independently of the implementation output; include the property “Support data identifies the actual execution profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C035-T03 · Fixture material:** Create the concrete “Host capability evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C035-T04 · Target preparation:** Prepare the “Host capability evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C035-T05 · Initial-state record:** Record the initial “Host capability evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C035-T06 · Valid-path execution:** Execute the “Host capability evidence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C035-T07 · Outcome comparison:** Compare every declared “Host capability evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C035-T08 · State and bounds check:** Inspect the “Host capability evidence” ownership/state effects and actual use of “Capability fields and report size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C035-T09 · Repeatability check:** Repeat the same “Host capability evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C035-T10 · Positive evidence:** Attach the “Host capability evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C036 · Negative test

**Original checklist item:** Negative case: An isolation issue is exported without backend information. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Host capability evidence” source counterexample: “An isolation issue is exported without backend information”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Host capability evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C036-T03 · Valid control:** Construct a valid “Host capability evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C036-T04 · Minimal adverse input:** Derive the “Host capability evidence” adverse fixture from the control with the smallest documented change needed to reproduce “An isolation issue is exported without backend information”; retain that change as reproducible data.
- [ ] **UC-M10.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Host capability evidence”; require “Support data identifies the actual execution profile” and forbid a false-success verdict.
- [ ] **UC-M10.07-C036-T06 · Adverse execution:** Exercise the “Host capability evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C036-T07 · Effect inspection:** Inspect “Host capability evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C036-T08 · Refusal versus failure:** Confirm the “Host capability evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C036-T09 · Reset and retention:** Restore only the disposable “Host capability evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C036-T10 · Negative regression:** Register the “Host capability evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C037 · Change / failure test

**Original checklist item:** Exercise host capability evidence when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C037-T01 · Scenario record:** Write the “Host capability evidence” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “Support data identifies the actual execution profile”.
- [ ] **UC-M10.07-C037-T02 · Baseline capture:** Create a known-valid “Host capability evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C037-T03 · Injection map:** Locate the “Host capability evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Host capability evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C037-T05 · Controlled trigger:** Introduce the controlled “Host capability evidence” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C037-T06 · Intermediate inspection:** Inspect the “Host capability evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Host capability evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Host capability evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C037-T09 · Repeat and compare:** Repeat the selected “Host capability evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C037-T10 · Failure evidence:** Publish the “Host capability evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for capability fields and report size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Host capability evidence”: “Capability fields and report size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C038-T02 · Measurement method:** Choose how to observe each “Host capability evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Host capability evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Host capability evidence” cases for “Capability fields and report size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Host capability evidence” limit; preserve “Support data identifies the actual execution profile”.
- [ ] **UC-M10.07-C038-T06 · Normal measurement:** Run or review the normal “Host capability evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C038-T07 · At-limit measurement:** Exercise the “Host capability evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C038-T08 · Over-limit measurement:** Exercise the “Host capability evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C038-T09 · Uncovered-scope report:** List the “Host capability evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C038-T10 · Limit evidence:** Publish the selected “Host capability evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for host capability evidence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C039-T01 · Event inventory:** List the “Host capability evidence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Host capability evidence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C039-T03 · Failure mapping:** Map each documented “Host capability evidence” refusal or error to a diagnostic outcome; include “An isolation issue is exported without backend information” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C039-T04 · Emission path:** Add the “Host capability evidence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C039-T05 · Redaction check:** Test “Host capability evidence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C039-T06 · Output budget:** Set and exercise bounded “Host capability evidence” message size, rate and retention compatible with “Capability fields and report size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C039-T07 · Success/refusal fixtures:** Capture “Host capability evidence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Host capability evidence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C039-T09 · Operator review:** Read the “Host capability evidence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C039-T10 · Diagnostic evidence:** Publish redacted “Host capability evidence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for host capability evidence; label unexecuted checks as untested.

- [ ] **UC-M10.07-C040-T01 · Evidence inventory:** List the “Host capability evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C040-T02 · Artifact references:** Record the exact “Host capability evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C040-T03 · Fixture references:** Attach the “Host capability evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “An isolation issue is exported without backend information” as a distinct evidence case.
- [ ] **UC-M10.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Host capability evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C040-T05 · Environment record:** Record the actual “Host capability evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C040-T06 · Expected versus observed:** Pair every “Host capability evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C040-T07 · Failure and limit records:** Attach “Host capability evidence” change/failure and bounds evidence where required; include uncovered “Capability fields and report size” and unresolved violations of “Support data identifies the actual execution profile”.
- [ ] **UC-M10.07-C040-T08 · Evidence hygiene:** Check the “Host capability evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C040-T09 · Reproduction review:** Have the “Host capability evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C040-T10 · Acceptance linkage:** Link the “Host capability evidence” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Log and trace selection

**Source delivery:** Select bounded relevant logs and traces rather than unfiltered history.

**Source invariant:** Exported context stays within declared content and retention scope.

**Source negative case:** A small incident exports every historical tenant log.

**Source bounded quantities:** Log bytes and time window.

### UC-M10.07-C041 · Contract

**Original checklist item:** Specify log and trace selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C041-T01 · Scope statement:** Draft the operation boundary for “Log and trace selection” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Log and trace selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C041-T03 · Output inventory:** List the outputs of “Log and trace selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Log and trace selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C041-T05 · Prerequisite contract:** Map “Log and trace selection” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Log and trace selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C041-T07 · Invariant clause:** Add a normative clause for “Log and trace selection” that preserves “Exported context stays within declared content and retention scope”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Log and trace selection”; include the source counterexample “A small incident exports every historical tenant log” and the intended safe disposition.
- [ ] **UC-M10.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Log bytes and time window” in the “Log and trace selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C041-T10 · Contract review:** Review the “Log and trace selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C042 · Delivery

**Original checklist item:** Select bounded relevant logs and traces rather than unfiltered history.

- [ ] **UC-M10.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Log and trace selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C042-T02 · Change plan:** Break the source delivery for “Log and trace selection” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C042-T03 · Core artifact:** Prepare the “Log and trace selection” decision record for this source instruction: Select bounded relevant logs and traces rather than unfiltered history.
- [ ] **UC-M10.07-C042-T04 · Concrete realization:** Evaluate the “Log and trace selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M10.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Log and trace selection” needed to preserve “Exported context stays within declared content and retention scope”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C042-T06 · Dependency connection:** Connect the “Log and trace selection” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C042-T07 · Resource behavior:** Account for “Log bytes and time window” in “Log and trace selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C042-T08 · Delivery check:** Run the smallest real “Log and trace selection” path and its adverse fixture “A small incident exports every historical tenant log”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C042-T09 · Patch review:** Review the “Log and trace selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C042-T10 · Delivery handoff:** Publish the “Log and trace selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Exported context stays within declared content and retention scope. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Log and trace selection”; copy its required invariant exactly: “Exported context stays within declared content and retention scope”.
- [ ] **UC-M10.07-C043-T02 · Observable terms:** Define each term in the “Log and trace selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C043-T03 · Precondition set:** List the preconditions under which “Exported context stays within declared content and retention scope” must hold for “Log and trace selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C043-T04 · Transition coverage:** Map the “Log and trace selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Log and trace selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C043-T06 · Satisfying fixture:** Create a concrete “Log and trace selection” case that satisfies “Exported context stays within declared content and retention scope”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C043-T07 · Violating fixture:** Create the source counterexample “A small incident exports every historical tenant log” for “Log and trace selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C043-T08 · Enforcement evidence:** Exercise the “Log and trace selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C043-T09 · Regression linkage:** Link the “Log and trace selection” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Log and trace selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C044 · Integration

**Original checklist item:** Integrate log and trace selection with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Log and trace selection” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C044-T02 · Field mapping:** Map every “Log and trace selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Log and trace selection” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C044-T04 · Ownership agreement:** Specify who owns “Log and trace selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C044-T05 · Handoff implementation:** Connect “Log and trace selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Exported context stays within declared content and retention scope” across the handoff.
- [ ] **UC-M10.07-C044-T06 · Absent-input case:** Omit one required “Log and trace selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C044-T07 · Stale-input case:** Supply an outdated “Log and trace selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Log and trace selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C044-T09 · Valid integration trace:** Run a valid “Log and trace selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C044-T10 · Seam review:** Reconcile the “Log and trace selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for log and trace selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Log and trace selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C045-T02 · Expected-result oracle:** Specify the “Log and trace selection” expected result independently of the implementation output; include the property “Exported context stays within declared content and retention scope” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C045-T03 · Fixture material:** Create the concrete “Log and trace selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C045-T04 · Target preparation:** Prepare the “Log and trace selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C045-T05 · Initial-state record:** Record the initial “Log and trace selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C045-T06 · Valid-path execution:** Execute the “Log and trace selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C045-T07 · Outcome comparison:** Compare every declared “Log and trace selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C045-T08 · State and bounds check:** Inspect the “Log and trace selection” ownership/state effects and actual use of “Log bytes and time window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C045-T09 · Repeatability check:** Repeat the same “Log and trace selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C045-T10 · Positive evidence:** Attach the “Log and trace selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C046 · Negative test

**Original checklist item:** Negative case: A small incident exports every historical tenant log. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Log and trace selection” source counterexample: “A small incident exports every historical tenant log”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Log and trace selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C046-T03 · Valid control:** Construct a valid “Log and trace selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C046-T04 · Minimal adverse input:** Derive the “Log and trace selection” adverse fixture from the control with the smallest documented change needed to reproduce “A small incident exports every historical tenant log”; retain that change as reproducible data.
- [ ] **UC-M10.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Log and trace selection”; require “Exported context stays within declared content and retention scope” and forbid a false-success verdict.
- [ ] **UC-M10.07-C046-T06 · Adverse execution:** Exercise the “Log and trace selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C046-T07 · Effect inspection:** Inspect “Log and trace selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C046-T08 · Refusal versus failure:** Confirm the “Log and trace selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C046-T09 · Reset and retention:** Restore only the disposable “Log and trace selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C046-T10 · Negative regression:** Register the “Log and trace selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C047 · Change / failure test

**Original checklist item:** Exercise log and trace selection when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C047-T01 · Scenario record:** Write the “Log and trace selection” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “Exported context stays within declared content and retention scope”.
- [ ] **UC-M10.07-C047-T02 · Baseline capture:** Create a known-valid “Log and trace selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C047-T03 · Injection map:** Locate the “Log and trace selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Log and trace selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C047-T05 · Controlled trigger:** Introduce the controlled “Log and trace selection” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C047-T06 · Intermediate inspection:** Inspect the “Log and trace selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Log and trace selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Log and trace selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C047-T09 · Repeat and compare:** Repeat the selected “Log and trace selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C047-T10 · Failure evidence:** Publish the “Log and trace selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for log bytes and time window; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Log and trace selection”: “Log bytes and time window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C048-T02 · Measurement method:** Choose how to observe each “Log and trace selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Log and trace selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Log and trace selection” cases for “Log bytes and time window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Log and trace selection” limit; preserve “Exported context stays within declared content and retention scope”.
- [ ] **UC-M10.07-C048-T06 · Normal measurement:** Run or review the normal “Log and trace selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C048-T07 · At-limit measurement:** Exercise the “Log and trace selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C048-T08 · Over-limit measurement:** Exercise the “Log and trace selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C048-T09 · Uncovered-scope report:** List the “Log and trace selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C048-T10 · Limit evidence:** Publish the selected “Log and trace selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for log and trace selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C049-T01 · Event inventory:** List the “Log and trace selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Log and trace selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C049-T03 · Failure mapping:** Map each documented “Log and trace selection” refusal or error to a diagnostic outcome; include “A small incident exports every historical tenant log” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C049-T04 · Emission path:** Add the “Log and trace selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C049-T05 · Redaction check:** Test “Log and trace selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C049-T06 · Output budget:** Set and exercise bounded “Log and trace selection” message size, rate and retention compatible with “Log bytes and time window”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C049-T07 · Success/refusal fixtures:** Capture “Log and trace selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Log and trace selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C049-T09 · Operator review:** Read the “Log and trace selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C049-T10 · Diagnostic evidence:** Publish redacted “Log and trace selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for log and trace selection; label unexecuted checks as untested.

- [ ] **UC-M10.07-C050-T01 · Evidence inventory:** List the “Log and trace selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C050-T02 · Artifact references:** Record the exact “Log and trace selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C050-T03 · Fixture references:** Attach the “Log and trace selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A small incident exports every historical tenant log” as a distinct evidence case.
- [ ] **UC-M10.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Log and trace selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C050-T05 · Environment record:** Record the actual “Log and trace selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C050-T06 · Expected versus observed:** Pair every “Log and trace selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C050-T07 · Failure and limit records:** Attach “Log and trace selection” change/failure and bounds evidence where required; include uncovered “Log bytes and time window” and unresolved violations of “Exported context stays within declared content and retention scope”.
- [ ] **UC-M10.07-C050-T08 · Evidence hygiene:** Check the “Log and trace selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C050-T09 · Reproduction review:** Have the “Log and trace selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C050-T10 · Acceptance linkage:** Link the “Log and trace selection” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Secret redaction

**Source delivery:** Scan and redact secret material before publishing the bundle.

**Source invariant:** Keys and runtime credentials are excluded from exported support data.

**Source negative case:** A panic record includes a planted test secret.

**Source bounded quantities:** Scanned bytes and redaction patterns.

### UC-M10.07-C051 · Contract

**Original checklist item:** Specify secret redaction inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C051-T01 · Scope statement:** Draft the operation boundary for “Secret redaction” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Secret redaction”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C051-T03 · Output inventory:** List the outputs of “Secret redaction” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Secret redaction”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C051-T05 · Prerequisite contract:** Map “Secret redaction” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Secret redaction”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C051-T07 · Invariant clause:** Add a normative clause for “Secret redaction” that preserves “Keys and runtime credentials are excluded from exported support data”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Secret redaction”; include the source counterexample “A panic record includes a planted test secret” and the intended safe disposition.
- [ ] **UC-M10.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scanned bytes and redaction patterns” in the “Secret redaction” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C051-T10 · Contract review:** Review the “Secret redaction” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C052 · Delivery

**Original checklist item:** Scan and redact secret material before publishing the bundle.

- [ ] **UC-M10.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Secret redaction”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C052-T02 · Change plan:** Break the source delivery for “Secret redaction” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Secret redaction” that realizes this source instruction: Scan and redact secret material before publishing the bundle.
- [ ] **UC-M10.07-C052-T04 · Concrete realization:** Trace “Secret redaction” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Secret redaction” needed to preserve “Keys and runtime credentials are excluded from exported support data”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C052-T06 · Dependency connection:** Connect the “Secret redaction” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C052-T07 · Resource behavior:** Account for “Scanned bytes and redaction patterns” in “Secret redaction”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C052-T08 · Delivery check:** Run the smallest real “Secret redaction” path and its adverse fixture “A panic record includes a planted test secret”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C052-T09 · Patch review:** Review the “Secret redaction” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C052-T10 · Delivery handoff:** Publish the “Secret redaction” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Keys and runtime credentials are excluded from exported support data. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Secret redaction”; copy its required invariant exactly: “Keys and runtime credentials are excluded from exported support data”.
- [ ] **UC-M10.07-C053-T02 · Observable terms:** Define each term in the “Secret redaction” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C053-T03 · Precondition set:** List the preconditions under which “Keys and runtime credentials are excluded from exported support data” must hold for “Secret redaction”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C053-T04 · Transition coverage:** Map the “Secret redaction” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Secret redaction”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C053-T06 · Satisfying fixture:** Create a concrete “Secret redaction” case that satisfies “Keys and runtime credentials are excluded from exported support data”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C053-T07 · Violating fixture:** Create the source counterexample “A panic record includes a planted test secret” for “Secret redaction”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C053-T08 · Enforcement evidence:** Exercise the “Secret redaction” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C053-T09 · Regression linkage:** Link the “Secret redaction” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Secret redaction” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C054 · Integration

**Original checklist item:** Integrate secret redaction with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Secret redaction” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C054-T02 · Field mapping:** Map every “Secret redaction” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Secret redaction” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C054-T04 · Ownership agreement:** Specify who owns “Secret redaction” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C054-T05 · Handoff implementation:** Connect “Secret redaction” through the mapped seam using the real adapter or explicit specification reference; preserve “Keys and runtime credentials are excluded from exported support data” across the handoff.
- [ ] **UC-M10.07-C054-T06 · Absent-input case:** Omit one required “Secret redaction” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C054-T07 · Stale-input case:** Supply an outdated “Secret redaction” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Secret redaction” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C054-T09 · Valid integration trace:** Run a valid “Secret redaction” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C054-T10 · Seam review:** Reconcile the “Secret redaction” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for secret redaction; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Secret redaction” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C055-T02 · Expected-result oracle:** Specify the “Secret redaction” expected result independently of the implementation output; include the property “Keys and runtime credentials are excluded from exported support data” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C055-T03 · Fixture material:** Create the concrete “Secret redaction” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C055-T04 · Target preparation:** Prepare the “Secret redaction” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C055-T05 · Initial-state record:** Record the initial “Secret redaction” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C055-T06 · Valid-path execution:** Execute the “Secret redaction” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C055-T07 · Outcome comparison:** Compare every declared “Secret redaction” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C055-T08 · State and bounds check:** Inspect the “Secret redaction” ownership/state effects and actual use of “Scanned bytes and redaction patterns”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C055-T09 · Repeatability check:** Repeat the same “Secret redaction” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C055-T10 · Positive evidence:** Attach the “Secret redaction” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C056 · Negative test

**Original checklist item:** Negative case: A panic record includes a planted test secret. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Secret redaction” source counterexample: “A panic record includes a planted test secret”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Secret redaction”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C056-T03 · Valid control:** Construct a valid “Secret redaction” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C056-T04 · Minimal adverse input:** Derive the “Secret redaction” adverse fixture from the control with the smallest documented change needed to reproduce “A panic record includes a planted test secret”; retain that change as reproducible data.
- [ ] **UC-M10.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Secret redaction”; require “Keys and runtime credentials are excluded from exported support data” and forbid a false-success verdict.
- [ ] **UC-M10.07-C056-T06 · Adverse execution:** Exercise the “Secret redaction” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C056-T07 · Effect inspection:** Inspect “Secret redaction” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C056-T08 · Refusal versus failure:** Confirm the “Secret redaction” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C056-T09 · Reset and retention:** Restore only the disposable “Secret redaction” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C056-T10 · Negative regression:** Register the “Secret redaction” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C057 · Change / failure test

**Original checklist item:** Exercise secret redaction when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C057-T01 · Scenario record:** Write the “Secret redaction” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “Keys and runtime credentials are excluded from exported support data”.
- [ ] **UC-M10.07-C057-T02 · Baseline capture:** Create a known-valid “Secret redaction” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C057-T03 · Injection map:** Locate the “Secret redaction” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Secret redaction” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C057-T05 · Controlled trigger:** Introduce the controlled “Secret redaction” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C057-T06 · Intermediate inspection:** Inspect the “Secret redaction” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Secret redaction”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Secret redaction” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C057-T09 · Repeat and compare:** Repeat the selected “Secret redaction” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C057-T10 · Failure evidence:** Publish the “Secret redaction” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for scanned bytes and redaction patterns; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Secret redaction”: “Scanned bytes and redaction patterns”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C058-T02 · Measurement method:** Choose how to observe each “Secret redaction” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C058-T03 · Budget decision:** Select justified resource and input limits for “Secret redaction”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Secret redaction” cases for “Scanned bytes and redaction patterns”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Secret redaction” limit; preserve “Keys and runtime credentials are excluded from exported support data”.
- [ ] **UC-M10.07-C058-T06 · Normal measurement:** Run or review the normal “Secret redaction” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C058-T07 · At-limit measurement:** Exercise the “Secret redaction” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C058-T08 · Over-limit measurement:** Exercise the “Secret redaction” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C058-T09 · Uncovered-scope report:** List the “Secret redaction” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C058-T10 · Limit evidence:** Publish the selected “Secret redaction” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for secret redaction with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C059-T01 · Event inventory:** List the “Secret redaction” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Secret redaction” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C059-T03 · Failure mapping:** Map each documented “Secret redaction” refusal or error to a diagnostic outcome; include “A panic record includes a planted test secret” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C059-T04 · Emission path:** Add the “Secret redaction” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C059-T05 · Redaction check:** Test “Secret redaction” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C059-T06 · Output budget:** Set and exercise bounded “Secret redaction” message size, rate and retention compatible with “Scanned bytes and redaction patterns”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C059-T07 · Success/refusal fixtures:** Capture “Secret redaction” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Secret redaction” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C059-T09 · Operator review:** Read the “Secret redaction” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C059-T10 · Diagnostic evidence:** Publish redacted “Secret redaction” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for secret redaction; label unexecuted checks as untested.

- [ ] **UC-M10.07-C060-T01 · Evidence inventory:** List the “Secret redaction” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C060-T02 · Artifact references:** Record the exact “Secret redaction” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C060-T03 · Fixture references:** Attach the “Secret redaction” fixture IDs, input identities and oracle definition; preserve the source counterexample “A panic record includes a planted test secret” as a distinct evidence case.
- [ ] **UC-M10.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Secret redaction”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C060-T05 · Environment record:** Record the actual “Secret redaction” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C060-T06 · Expected versus observed:** Pair every “Secret redaction” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C060-T07 · Failure and limit records:** Attach “Secret redaction” change/failure and bounds evidence where required; include uncovered “Scanned bytes and redaction patterns” and unresolved violations of “Keys and runtime credentials are excluded from exported support data”.
- [ ] **UC-M10.07-C060-T08 · Evidence hygiene:** Check the “Secret redaction” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C060-T09 · Reproduction review:** Have the “Secret redaction” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C060-T10 · Acceptance linkage:** Link the “Secret redaction” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Cargo privacy controls

**Source delivery:** Require explicit content scope for any user source or application data included.

**Source invariant:** Support export does not silently leak user cargo.

**Source negative case:** A source file is included because it shares a directory with diagnostics.

**Source bounded quantities:** Included cargo bytes and authorization decisions.

### UC-M10.07-C061 · Contract

**Original checklist item:** Specify cargo privacy controls inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C061-T01 · Scope statement:** Draft the operation boundary for “Cargo privacy controls” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cargo privacy controls”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C061-T03 · Output inventory:** List the outputs of “Cargo privacy controls” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Cargo privacy controls”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C061-T05 · Prerequisite contract:** Map “Cargo privacy controls” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Cargo privacy controls”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C061-T07 · Invariant clause:** Add a normative clause for “Cargo privacy controls” that preserves “Support export does not silently leak user cargo”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cargo privacy controls”; include the source counterexample “A source file is included because it shares a directory with diagnostics” and the intended safe disposition.
- [ ] **UC-M10.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Included cargo bytes and authorization decisions” in the “Cargo privacy controls” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C061-T10 · Contract review:** Review the “Cargo privacy controls” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C062 · Delivery

**Original checklist item:** Require explicit content scope for any user source or application data included.

- [ ] **UC-M10.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cargo privacy controls”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C062-T02 · Change plan:** Break the source delivery for “Cargo privacy controls” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Cargo privacy controls” that realizes this source instruction: Require explicit content scope for any user source or application data included.
- [ ] **UC-M10.07-C062-T04 · Concrete realization:** Trace “Cargo privacy controls” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cargo privacy controls” needed to preserve “Support export does not silently leak user cargo”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C062-T06 · Dependency connection:** Connect the “Cargo privacy controls” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C062-T07 · Resource behavior:** Account for “Included cargo bytes and authorization decisions” in “Cargo privacy controls”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C062-T08 · Delivery check:** Run the smallest real “Cargo privacy controls” path and its adverse fixture “A source file is included because it shares a directory with diagnostics”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C062-T09 · Patch review:** Review the “Cargo privacy controls” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C062-T10 · Delivery handoff:** Publish the “Cargo privacy controls” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Support export does not silently leak user cargo. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Cargo privacy controls”; copy its required invariant exactly: “Support export does not silently leak user cargo”.
- [ ] **UC-M10.07-C063-T02 · Observable terms:** Define each term in the “Cargo privacy controls” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C063-T03 · Precondition set:** List the preconditions under which “Support export does not silently leak user cargo” must hold for “Cargo privacy controls”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C063-T04 · Transition coverage:** Map the “Cargo privacy controls” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cargo privacy controls”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C063-T06 · Satisfying fixture:** Create a concrete “Cargo privacy controls” case that satisfies “Support export does not silently leak user cargo”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C063-T07 · Violating fixture:** Create the source counterexample “A source file is included because it shares a directory with diagnostics” for “Cargo privacy controls”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C063-T08 · Enforcement evidence:** Exercise the “Cargo privacy controls” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C063-T09 · Regression linkage:** Link the “Cargo privacy controls” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Cargo privacy controls” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C064 · Integration

**Original checklist item:** Integrate cargo privacy controls with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cargo privacy controls” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C064-T02 · Field mapping:** Map every “Cargo privacy controls” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Cargo privacy controls” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C064-T04 · Ownership agreement:** Specify who owns “Cargo privacy controls” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C064-T05 · Handoff implementation:** Connect “Cargo privacy controls” through the mapped seam using the real adapter or explicit specification reference; preserve “Support export does not silently leak user cargo” across the handoff.
- [ ] **UC-M10.07-C064-T06 · Absent-input case:** Omit one required “Cargo privacy controls” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C064-T07 · Stale-input case:** Supply an outdated “Cargo privacy controls” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Cargo privacy controls” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C064-T09 · Valid integration trace:** Run a valid “Cargo privacy controls” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C064-T10 · Seam review:** Reconcile the “Cargo privacy controls” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cargo privacy controls; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cargo privacy controls” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C065-T02 · Expected-result oracle:** Specify the “Cargo privacy controls” expected result independently of the implementation output; include the property “Support export does not silently leak user cargo” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C065-T03 · Fixture material:** Create the concrete “Cargo privacy controls” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C065-T04 · Target preparation:** Prepare the “Cargo privacy controls” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C065-T05 · Initial-state record:** Record the initial “Cargo privacy controls” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C065-T06 · Valid-path execution:** Execute the “Cargo privacy controls” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C065-T07 · Outcome comparison:** Compare every declared “Cargo privacy controls” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C065-T08 · State and bounds check:** Inspect the “Cargo privacy controls” ownership/state effects and actual use of “Included cargo bytes and authorization decisions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C065-T09 · Repeatability check:** Repeat the same “Cargo privacy controls” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C065-T10 · Positive evidence:** Attach the “Cargo privacy controls” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C066 · Negative test

**Original checklist item:** Negative case: A source file is included because it shares a directory with diagnostics. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Cargo privacy controls” source counterexample: “A source file is included because it shares a directory with diagnostics”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Cargo privacy controls”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C066-T03 · Valid control:** Construct a valid “Cargo privacy controls” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C066-T04 · Minimal adverse input:** Derive the “Cargo privacy controls” adverse fixture from the control with the smallest documented change needed to reproduce “A source file is included because it shares a directory with diagnostics”; retain that change as reproducible data.
- [ ] **UC-M10.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cargo privacy controls”; require “Support export does not silently leak user cargo” and forbid a false-success verdict.
- [ ] **UC-M10.07-C066-T06 · Adverse execution:** Exercise the “Cargo privacy controls” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C066-T07 · Effect inspection:** Inspect “Cargo privacy controls” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C066-T08 · Refusal versus failure:** Confirm the “Cargo privacy controls” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C066-T09 · Reset and retention:** Restore only the disposable “Cargo privacy controls” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C066-T10 · Negative regression:** Register the “Cargo privacy controls” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C067 · Change / failure test

**Original checklist item:** Exercise cargo privacy controls when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C067-T01 · Scenario record:** Write the “Cargo privacy controls” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “Support export does not silently leak user cargo”.
- [ ] **UC-M10.07-C067-T02 · Baseline capture:** Create a known-valid “Cargo privacy controls” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C067-T03 · Injection map:** Locate the “Cargo privacy controls” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Cargo privacy controls” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C067-T05 · Controlled trigger:** Introduce the controlled “Cargo privacy controls” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C067-T06 · Intermediate inspection:** Inspect the “Cargo privacy controls” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cargo privacy controls”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Cargo privacy controls” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C067-T09 · Repeat and compare:** Repeat the selected “Cargo privacy controls” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C067-T10 · Failure evidence:** Publish the “Cargo privacy controls” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for included cargo bytes and authorization decisions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Cargo privacy controls”: “Included cargo bytes and authorization decisions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C068-T02 · Measurement method:** Choose how to observe each “Cargo privacy controls” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Cargo privacy controls”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cargo privacy controls” cases for “Included cargo bytes and authorization decisions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cargo privacy controls” limit; preserve “Support export does not silently leak user cargo”.
- [ ] **UC-M10.07-C068-T06 · Normal measurement:** Run or review the normal “Cargo privacy controls” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C068-T07 · At-limit measurement:** Exercise the “Cargo privacy controls” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C068-T08 · Over-limit measurement:** Exercise the “Cargo privacy controls” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C068-T09 · Uncovered-scope report:** List the “Cargo privacy controls” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C068-T10 · Limit evidence:** Publish the selected “Cargo privacy controls” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cargo privacy controls with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C069-T01 · Event inventory:** List the “Cargo privacy controls” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Cargo privacy controls” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C069-T03 · Failure mapping:** Map each documented “Cargo privacy controls” refusal or error to a diagnostic outcome; include “A source file is included because it shares a directory with diagnostics” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C069-T04 · Emission path:** Add the “Cargo privacy controls” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C069-T05 · Redaction check:** Test “Cargo privacy controls” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C069-T06 · Output budget:** Set and exercise bounded “Cargo privacy controls” message size, rate and retention compatible with “Included cargo bytes and authorization decisions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C069-T07 · Success/refusal fixtures:** Capture “Cargo privacy controls” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cargo privacy controls” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C069-T09 · Operator review:** Read the “Cargo privacy controls” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C069-T10 · Diagnostic evidence:** Publish redacted “Cargo privacy controls” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cargo privacy controls; label unexecuted checks as untested.

- [ ] **UC-M10.07-C070-T01 · Evidence inventory:** List the “Cargo privacy controls” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C070-T02 · Artifact references:** Record the exact “Cargo privacy controls” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C070-T03 · Fixture references:** Attach the “Cargo privacy controls” fixture IDs, input identities and oracle definition; preserve the source counterexample “A source file is included because it shares a directory with diagnostics” as a distinct evidence case.
- [ ] **UC-M10.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cargo privacy controls”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C070-T05 · Environment record:** Record the actual “Cargo privacy controls” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C070-T06 · Expected versus observed:** Pair every “Cargo privacy controls” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C070-T07 · Failure and limit records:** Attach “Cargo privacy controls” change/failure and bounds evidence where required; include uncovered “Included cargo bytes and authorization decisions” and unresolved violations of “Support export does not silently leak user cargo”.
- [ ] **UC-M10.07-C070-T08 · Evidence hygiene:** Check the “Cargo privacy controls” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C070-T09 · Reproduction review:** Have the “Cargo privacy controls” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C070-T10 · Acceptance linkage:** Link the “Cargo privacy controls” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Archive admission safety

**Source delivery:** Create bounded safe filenames and validate bundle size and structure.

**Source invariant:** A support bundle cannot become an unbounded or path-unsafe archive.

**Source negative case:** A diagnostic filename contains traversal components.

**Source bounded quantities:** Archive entries, path length and total bytes.

### UC-M10.07-C071 · Contract

**Original checklist item:** Specify archive admission safety inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C071-T01 · Scope statement:** Draft the operation boundary for “Archive admission safety” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Archive admission safety”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C071-T03 · Output inventory:** List the outputs of “Archive admission safety” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Archive admission safety”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C071-T05 · Prerequisite contract:** Map “Archive admission safety” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Archive admission safety”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C071-T07 · Invariant clause:** Add a normative clause for “Archive admission safety” that preserves “A support bundle cannot become an unbounded or path-unsafe archive”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Archive admission safety”; include the source counterexample “A diagnostic filename contains traversal components” and the intended safe disposition.
- [ ] **UC-M10.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Archive entries, path length and total bytes” in the “Archive admission safety” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C071-T10 · Contract review:** Review the “Archive admission safety” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C072 · Delivery

**Original checklist item:** Create bounded safe filenames and validate bundle size and structure.

- [ ] **UC-M10.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Archive admission safety”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C072-T02 · Change plan:** Break the source delivery for “Archive admission safety” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Archive admission safety” that realizes this source instruction: Create bounded safe filenames and validate bundle size and structure.
- [ ] **UC-M10.07-C072-T04 · Concrete realization:** Trace “Archive admission safety” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Archive admission safety” needed to preserve “A support bundle cannot become an unbounded or path-unsafe archive”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C072-T06 · Dependency connection:** Connect the “Archive admission safety” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C072-T07 · Resource behavior:** Account for “Archive entries, path length and total bytes” in “Archive admission safety”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C072-T08 · Delivery check:** Run the smallest real “Archive admission safety” path and its adverse fixture “A diagnostic filename contains traversal components”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C072-T09 · Patch review:** Review the “Archive admission safety” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C072-T10 · Delivery handoff:** Publish the “Archive admission safety” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A support bundle cannot become an unbounded or path-unsafe archive. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Archive admission safety”; copy its required invariant exactly: “A support bundle cannot become an unbounded or path-unsafe archive”.
- [ ] **UC-M10.07-C073-T02 · Observable terms:** Define each term in the “Archive admission safety” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C073-T03 · Precondition set:** List the preconditions under which “A support bundle cannot become an unbounded or path-unsafe archive” must hold for “Archive admission safety”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C073-T04 · Transition coverage:** Map the “Archive admission safety” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Archive admission safety”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C073-T06 · Satisfying fixture:** Create a concrete “Archive admission safety” case that satisfies “A support bundle cannot become an unbounded or path-unsafe archive”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C073-T07 · Violating fixture:** Create the source counterexample “A diagnostic filename contains traversal components” for “Archive admission safety”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C073-T08 · Enforcement evidence:** Exercise the “Archive admission safety” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C073-T09 · Regression linkage:** Link the “Archive admission safety” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Archive admission safety” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C074 · Integration

**Original checklist item:** Integrate archive admission safety with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Archive admission safety” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C074-T02 · Field mapping:** Map every “Archive admission safety” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Archive admission safety” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C074-T04 · Ownership agreement:** Specify who owns “Archive admission safety” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C074-T05 · Handoff implementation:** Connect “Archive admission safety” through the mapped seam using the real adapter or explicit specification reference; preserve “A support bundle cannot become an unbounded or path-unsafe archive” across the handoff.
- [ ] **UC-M10.07-C074-T06 · Absent-input case:** Omit one required “Archive admission safety” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C074-T07 · Stale-input case:** Supply an outdated “Archive admission safety” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Archive admission safety” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C074-T09 · Valid integration trace:** Run a valid “Archive admission safety” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C074-T10 · Seam review:** Reconcile the “Archive admission safety” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for archive admission safety; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Archive admission safety” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C075-T02 · Expected-result oracle:** Specify the “Archive admission safety” expected result independently of the implementation output; include the property “A support bundle cannot become an unbounded or path-unsafe archive” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C075-T03 · Fixture material:** Create the concrete “Archive admission safety” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C075-T04 · Target preparation:** Prepare the “Archive admission safety” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C075-T05 · Initial-state record:** Record the initial “Archive admission safety” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C075-T06 · Valid-path execution:** Execute the “Archive admission safety” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C075-T07 · Outcome comparison:** Compare every declared “Archive admission safety” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C075-T08 · State and bounds check:** Inspect the “Archive admission safety” ownership/state effects and actual use of “Archive entries, path length and total bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C075-T09 · Repeatability check:** Repeat the same “Archive admission safety” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C075-T10 · Positive evidence:** Attach the “Archive admission safety” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C076 · Negative test

**Original checklist item:** Negative case: A diagnostic filename contains traversal components. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Archive admission safety” source counterexample: “A diagnostic filename contains traversal components”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Archive admission safety”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C076-T03 · Valid control:** Construct a valid “Archive admission safety” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C076-T04 · Minimal adverse input:** Derive the “Archive admission safety” adverse fixture from the control with the smallest documented change needed to reproduce “A diagnostic filename contains traversal components”; retain that change as reproducible data.
- [ ] **UC-M10.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Archive admission safety”; require “A support bundle cannot become an unbounded or path-unsafe archive” and forbid a false-success verdict.
- [ ] **UC-M10.07-C076-T06 · Adverse execution:** Exercise the “Archive admission safety” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C076-T07 · Effect inspection:** Inspect “Archive admission safety” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C076-T08 · Refusal versus failure:** Confirm the “Archive admission safety” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C076-T09 · Reset and retention:** Restore only the disposable “Archive admission safety” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C076-T10 · Negative regression:** Register the “Archive admission safety” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C077 · Change / failure test

**Original checklist item:** Exercise archive admission safety when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C077-T01 · Scenario record:** Write the “Archive admission safety” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “A support bundle cannot become an unbounded or path-unsafe archive”.
- [ ] **UC-M10.07-C077-T02 · Baseline capture:** Create a known-valid “Archive admission safety” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C077-T03 · Injection map:** Locate the “Archive admission safety” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Archive admission safety” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C077-T05 · Controlled trigger:** Introduce the controlled “Archive admission safety” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C077-T06 · Intermediate inspection:** Inspect the “Archive admission safety” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Archive admission safety”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Archive admission safety” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C077-T09 · Repeat and compare:** Repeat the selected “Archive admission safety” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C077-T10 · Failure evidence:** Publish the “Archive admission safety” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for archive entries, path length and total bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Archive admission safety”: “Archive entries, path length and total bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C078-T02 · Measurement method:** Choose how to observe each “Archive admission safety” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Archive admission safety”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Archive admission safety” cases for “Archive entries, path length and total bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Archive admission safety” limit; preserve “A support bundle cannot become an unbounded or path-unsafe archive”.
- [ ] **UC-M10.07-C078-T06 · Normal measurement:** Run or review the normal “Archive admission safety” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C078-T07 · At-limit measurement:** Exercise the “Archive admission safety” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C078-T08 · Over-limit measurement:** Exercise the “Archive admission safety” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C078-T09 · Uncovered-scope report:** List the “Archive admission safety” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C078-T10 · Limit evidence:** Publish the selected “Archive admission safety” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for archive admission safety with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C079-T01 · Event inventory:** List the “Archive admission safety” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Archive admission safety” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C079-T03 · Failure mapping:** Map each documented “Archive admission safety” refusal or error to a diagnostic outcome; include “A diagnostic filename contains traversal components” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C079-T04 · Emission path:** Add the “Archive admission safety” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C079-T05 · Redaction check:** Test “Archive admission safety” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C079-T06 · Output budget:** Set and exercise bounded “Archive admission safety” message size, rate and retention compatible with “Archive entries, path length and total bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C079-T07 · Success/refusal fixtures:** Capture “Archive admission safety” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Archive admission safety” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C079-T09 · Operator review:** Read the “Archive admission safety” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C079-T10 · Diagnostic evidence:** Publish redacted “Archive admission safety” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for archive admission safety; label unexecuted checks as untested.

- [ ] **UC-M10.07-C080-T01 · Evidence inventory:** List the “Archive admission safety” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C080-T02 · Artifact references:** Record the exact “Archive admission safety” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C080-T03 · Fixture references:** Attach the “Archive admission safety” fixture IDs, input identities and oracle definition; preserve the source counterexample “A diagnostic filename contains traversal components” as a distinct evidence case.
- [ ] **UC-M10.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Archive admission safety”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C080-T05 · Environment record:** Record the actual “Archive admission safety” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C080-T06 · Expected versus observed:** Pair every “Archive admission safety” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C080-T07 · Failure and limit records:** Attach “Archive admission safety” change/failure and bounds evidence where required; include uncovered “Archive entries, path length and total bytes” and unresolved violations of “A support bundle cannot become an unbounded or path-unsafe archive”.
- [ ] **UC-M10.07-C080-T08 · Evidence hygiene:** Check the “Archive admission safety” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C080-T09 · Reproduction review:** Have the “Archive admission safety” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C080-T10 · Acceptance linkage:** Link the “Archive admission safety” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Failure-safe publication

**Source delivery:** Stage and validate the bundle before exposing its final path.

**Source invariant:** Interrupted export cannot be mistaken for a complete support artifact.

**Source negative case:** Export is interrupted after creating a final-looking filename.

**Source bounded quantities:** Staging bytes and publication deadline.

### UC-M10.07-C081 · Contract

**Original checklist item:** Specify failure-safe publication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C081-T01 · Scope statement:** Draft the operation boundary for “Failure-safe publication” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure-safe publication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C081-T03 · Output inventory:** List the outputs of “Failure-safe publication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure-safe publication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C081-T05 · Prerequisite contract:** Map “Failure-safe publication” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Failure-safe publication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C081-T07 · Invariant clause:** Add a normative clause for “Failure-safe publication” that preserves “Interrupted export cannot be mistaken for a complete support artifact”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure-safe publication”; include the source counterexample “Export is interrupted after creating a final-looking filename” and the intended safe disposition.
- [ ] **UC-M10.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Staging bytes and publication deadline” in the “Failure-safe publication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C081-T10 · Contract review:** Review the “Failure-safe publication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C082 · Delivery

**Original checklist item:** Stage and validate the bundle before exposing its final path.

- [ ] **UC-M10.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure-safe publication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C082-T02 · Change plan:** Break the source delivery for “Failure-safe publication” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Failure-safe publication” that realizes this source instruction: Stage and validate the bundle before exposing its final path.
- [ ] **UC-M10.07-C082-T04 · Concrete realization:** Trace “Failure-safe publication” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure-safe publication” needed to preserve “Interrupted export cannot be mistaken for a complete support artifact”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C082-T06 · Dependency connection:** Connect the “Failure-safe publication” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C082-T07 · Resource behavior:** Account for “Staging bytes and publication deadline” in “Failure-safe publication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C082-T08 · Delivery check:** Run the smallest real “Failure-safe publication” path and its adverse fixture “Export is interrupted after creating a final-looking filename”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C082-T09 · Patch review:** Review the “Failure-safe publication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C082-T10 · Delivery handoff:** Publish the “Failure-safe publication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Interrupted export cannot be mistaken for a complete support artifact. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Failure-safe publication”; copy its required invariant exactly: “Interrupted export cannot be mistaken for a complete support artifact”.
- [ ] **UC-M10.07-C083-T02 · Observable terms:** Define each term in the “Failure-safe publication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C083-T03 · Precondition set:** List the preconditions under which “Interrupted export cannot be mistaken for a complete support artifact” must hold for “Failure-safe publication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C083-T04 · Transition coverage:** Map the “Failure-safe publication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure-safe publication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C083-T06 · Satisfying fixture:** Create a concrete “Failure-safe publication” case that satisfies “Interrupted export cannot be mistaken for a complete support artifact”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C083-T07 · Violating fixture:** Create the source counterexample “Export is interrupted after creating a final-looking filename” for “Failure-safe publication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C083-T08 · Enforcement evidence:** Exercise the “Failure-safe publication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C083-T09 · Regression linkage:** Link the “Failure-safe publication” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Failure-safe publication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C084 · Integration

**Original checklist item:** Integrate failure-safe publication with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure-safe publication” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C084-T02 · Field mapping:** Map every “Failure-safe publication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure-safe publication” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C084-T04 · Ownership agreement:** Specify who owns “Failure-safe publication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C084-T05 · Handoff implementation:** Connect “Failure-safe publication” through the mapped seam using the real adapter or explicit specification reference; preserve “Interrupted export cannot be mistaken for a complete support artifact” across the handoff.
- [ ] **UC-M10.07-C084-T06 · Absent-input case:** Omit one required “Failure-safe publication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C084-T07 · Stale-input case:** Supply an outdated “Failure-safe publication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Failure-safe publication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C084-T09 · Valid integration trace:** Run a valid “Failure-safe publication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C084-T10 · Seam review:** Reconcile the “Failure-safe publication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure-safe publication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure-safe publication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C085-T02 · Expected-result oracle:** Specify the “Failure-safe publication” expected result independently of the implementation output; include the property “Interrupted export cannot be mistaken for a complete support artifact” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C085-T03 · Fixture material:** Create the concrete “Failure-safe publication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C085-T04 · Target preparation:** Prepare the “Failure-safe publication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C085-T05 · Initial-state record:** Record the initial “Failure-safe publication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C085-T06 · Valid-path execution:** Execute the “Failure-safe publication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C085-T07 · Outcome comparison:** Compare every declared “Failure-safe publication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C085-T08 · State and bounds check:** Inspect the “Failure-safe publication” ownership/state effects and actual use of “Staging bytes and publication deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C085-T09 · Repeatability check:** Repeat the same “Failure-safe publication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C085-T10 · Positive evidence:** Attach the “Failure-safe publication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C086 · Negative test

**Original checklist item:** Negative case: Export is interrupted after creating a final-looking filename. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Failure-safe publication” source counterexample: “Export is interrupted after creating a final-looking filename”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure-safe publication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C086-T03 · Valid control:** Construct a valid “Failure-safe publication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C086-T04 · Minimal adverse input:** Derive the “Failure-safe publication” adverse fixture from the control with the smallest documented change needed to reproduce “Export is interrupted after creating a final-looking filename”; retain that change as reproducible data.
- [ ] **UC-M10.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure-safe publication”; require “Interrupted export cannot be mistaken for a complete support artifact” and forbid a false-success verdict.
- [ ] **UC-M10.07-C086-T06 · Adverse execution:** Exercise the “Failure-safe publication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C086-T07 · Effect inspection:** Inspect “Failure-safe publication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C086-T08 · Refusal versus failure:** Confirm the “Failure-safe publication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C086-T09 · Reset and retention:** Restore only the disposable “Failure-safe publication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C086-T10 · Negative regression:** Register the “Failure-safe publication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C087 · Change / failure test

**Original checklist item:** Exercise failure-safe publication when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C087-T01 · Scenario record:** Write the “Failure-safe publication” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “Interrupted export cannot be mistaken for a complete support artifact”.
- [ ] **UC-M10.07-C087-T02 · Baseline capture:** Create a known-valid “Failure-safe publication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C087-T03 · Injection map:** Locate the “Failure-safe publication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Failure-safe publication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C087-T05 · Controlled trigger:** Introduce the controlled “Failure-safe publication” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C087-T06 · Intermediate inspection:** Inspect the “Failure-safe publication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure-safe publication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure-safe publication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C087-T09 · Repeat and compare:** Repeat the selected “Failure-safe publication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C087-T10 · Failure evidence:** Publish the “Failure-safe publication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for staging bytes and publication deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Failure-safe publication”: “Staging bytes and publication deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C088-T02 · Measurement method:** Choose how to observe each “Failure-safe publication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C088-T03 · Budget decision:** Select justified resource and input limits for “Failure-safe publication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure-safe publication” cases for “Staging bytes and publication deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure-safe publication” limit; preserve “Interrupted export cannot be mistaken for a complete support artifact”.
- [ ] **UC-M10.07-C088-T06 · Normal measurement:** Run or review the normal “Failure-safe publication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C088-T07 · At-limit measurement:** Exercise the “Failure-safe publication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C088-T08 · Over-limit measurement:** Exercise the “Failure-safe publication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C088-T09 · Uncovered-scope report:** List the “Failure-safe publication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C088-T10 · Limit evidence:** Publish the selected “Failure-safe publication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure-safe publication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C089-T01 · Event inventory:** List the “Failure-safe publication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Failure-safe publication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C089-T03 · Failure mapping:** Map each documented “Failure-safe publication” refusal or error to a diagnostic outcome; include “Export is interrupted after creating a final-looking filename” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C089-T04 · Emission path:** Add the “Failure-safe publication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C089-T05 · Redaction check:** Test “Failure-safe publication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C089-T06 · Output budget:** Set and exercise bounded “Failure-safe publication” message size, rate and retention compatible with “Staging bytes and publication deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C089-T07 · Success/refusal fixtures:** Capture “Failure-safe publication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure-safe publication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C089-T09 · Operator review:** Read the “Failure-safe publication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C089-T10 · Diagnostic evidence:** Publish redacted “Failure-safe publication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure-safe publication; label unexecuted checks as untested.

- [ ] **UC-M10.07-C090-T01 · Evidence inventory:** List the “Failure-safe publication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C090-T02 · Artifact references:** Record the exact “Failure-safe publication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C090-T03 · Fixture references:** Attach the “Failure-safe publication” fixture IDs, input identities and oracle definition; preserve the source counterexample “Export is interrupted after creating a final-looking filename” as a distinct evidence case.
- [ ] **UC-M10.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure-safe publication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C090-T05 · Environment record:** Record the actual “Failure-safe publication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C090-T06 · Expected versus observed:** Pair every “Failure-safe publication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C090-T07 · Failure and limit records:** Attach “Failure-safe publication” change/failure and bounds evidence where required; include uncovered “Staging bytes and publication deadline” and unresolved violations of “Interrupted export cannot be mistaken for a complete support artifact”.
- [ ] **UC-M10.07-C090-T08 · Evidence hygiene:** Check the “Failure-safe publication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C090-T09 · Reproduction review:** Have the “Failure-safe publication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C090-T10 · Acceptance linkage:** Link the “Failure-safe publication” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Reproduction and leakage test

**Source delivery:** Use a seeded failure to verify reproduction usefulness and content exclusion.

**Source invariant:** The bundle both supports its stated reproduction and passes secret/scope checks.

**Source negative case:** The failure reproduces but the bundle contains a test credential.

**Source bounded quantities:** Fixture failures and export repetitions.

### UC-M10.07-C091 · Contract

**Original checklist item:** Specify reproduction and leakage test inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.07-C091-T01 · Scope statement:** Draft the operation boundary for “Reproduction and leakage test” within Crash dumps and support bundle export; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reproduction and leakage test”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.07-C091-T03 · Output inventory:** List the outputs of “Reproduction and leakage test” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Reproduction and leakage test”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.07-C091-T05 · Prerequisite contract:** Map “Reproduction and leakage test” to the source component prerequisites (UC-M06.07, UC-M07.07, UC-M10.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Reproduction and leakage test”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.07-C091-T07 · Invariant clause:** Add a normative clause for “Reproduction and leakage test” that preserves “The bundle both supports its stated reproduction and passes secret/scope checks”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reproduction and leakage test”; include the source counterexample “The failure reproduces but the bundle contains a test credential” and the intended safe disposition.
- [ ] **UC-M10.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture failures and export repetitions” in the “Reproduction and leakage test” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.07-C091-T10 · Contract review:** Review the “Reproduction and leakage test” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.07-C092 · Delivery

**Original checklist item:** Use a seeded failure to verify reproduction usefulness and content exclusion.

- [ ] **UC-M10.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reproduction and leakage test”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.07-C092-T02 · Change plan:** Break the source delivery for “Reproduction and leakage test” into concrete edit targets and reviewable outputs; keep the UC-M10.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.07-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Reproduction and leakage test” that realizes this source instruction: Use a seeded failure to verify reproduction usefulness and content exclusion.
- [ ] **UC-M10.07-C092-T04 · Concrete realization:** Trace “Reproduction and leakage test” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reproduction and leakage test” needed to preserve “The bundle both supports its stated reproduction and passes secret/scope checks”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.07-C092-T06 · Dependency connection:** Connect the “Reproduction and leakage test” implementation to bounded logs/state, host capability records and export redaction policy; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.07-C092-T07 · Resource behavior:** Account for “Fixture failures and export repetitions” in “Reproduction and leakage test”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.07-C092-T08 · Delivery check:** Run the smallest real “Reproduction and leakage test” path and its adverse fixture “The failure reproduces but the bundle contains a test credential”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.07-C092-T09 · Patch review:** Review the “Reproduction and leakage test” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.07-C092-T10 · Delivery handoff:** Publish the “Reproduction and leakage test” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The bundle both supports its stated reproduction and passes secret/scope checks. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Reproduction and leakage test”; copy its required invariant exactly: “The bundle both supports its stated reproduction and passes secret/scope checks”.
- [ ] **UC-M10.07-C093-T02 · Observable terms:** Define each term in the “Reproduction and leakage test” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.07-C093-T03 · Precondition set:** List the preconditions under which “The bundle both supports its stated reproduction and passes secret/scope checks” must hold for “Reproduction and leakage test”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.07-C093-T04 · Transition coverage:** Map the “Reproduction and leakage test” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reproduction and leakage test”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.07-C093-T06 · Satisfying fixture:** Create a concrete “Reproduction and leakage test” case that satisfies “The bundle both supports its stated reproduction and passes secret/scope checks”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.07-C093-T07 · Violating fixture:** Create the source counterexample “The failure reproduces but the bundle contains a test credential” for “Reproduction and leakage test”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.07-C093-T08 · Enforcement evidence:** Exercise the “Reproduction and leakage test” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.07-C093-T09 · Regression linkage:** Link the “Reproduction and leakage test” property to changes in bounded logs/state, host capability records and export redaction policy; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Reproduction and leakage test” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.07-C094 · Integration

**Original checklist item:** Integrate reproduction and leakage test with bounded logs/state, host capability records and export redaction policy; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reproduction and leakage test” across bounded logs/state, host capability records and export redaction policy; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.07-C094-T02 · Field mapping:** Map every “Reproduction and leakage test” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Reproduction and leakage test” (source dependency list: UC-M06.07, UC-M07.07, UC-M10.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.07-C094-T04 · Ownership agreement:** Specify who owns “Reproduction and leakage test” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.07-C094-T05 · Handoff implementation:** Connect “Reproduction and leakage test” through the mapped seam using the real adapter or explicit specification reference; preserve “The bundle both supports its stated reproduction and passes secret/scope checks” across the handoff.
- [ ] **UC-M10.07-C094-T06 · Absent-input case:** Omit one required “Reproduction and leakage test” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.07-C094-T07 · Stale-input case:** Supply an outdated “Reproduction and leakage test” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Reproduction and leakage test” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.07-C094-T09 · Valid integration trace:** Run a valid “Reproduction and leakage test” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.07-C094-T10 · Seam review:** Reconcile the “Reproduction and leakage test” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reproduction and leakage test; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reproduction and leakage test” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.07-C095-T02 · Expected-result oracle:** Specify the “Reproduction and leakage test” expected result independently of the implementation output; include the property “The bundle both supports its stated reproduction and passes secret/scope checks” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.07-C095-T03 · Fixture material:** Create the concrete “Reproduction and leakage test” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.07-C095-T04 · Target preparation:** Prepare the “Reproduction and leakage test” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.07-C095-T05 · Initial-state record:** Record the initial “Reproduction and leakage test” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.07-C095-T06 · Valid-path execution:** Execute the “Reproduction and leakage test” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.07-C095-T07 · Outcome comparison:** Compare every declared “Reproduction and leakage test” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.07-C095-T08 · State and bounds check:** Inspect the “Reproduction and leakage test” ownership/state effects and actual use of “Fixture failures and export repetitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.07-C095-T09 · Repeatability check:** Repeat the same “Reproduction and leakage test” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.07-C095-T10 · Positive evidence:** Attach the “Reproduction and leakage test” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.07-C096 · Negative test

**Original checklist item:** Negative case: The failure reproduces but the bundle contains a test credential. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Reproduction and leakage test” source counterexample: “The failure reproduces but the bundle contains a test credential”; state which precondition or invariant it challenges.
- [ ] **UC-M10.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Reproduction and leakage test”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.07-C096-T03 · Valid control:** Construct a valid “Reproduction and leakage test” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.07-C096-T04 · Minimal adverse input:** Derive the “Reproduction and leakage test” adverse fixture from the control with the smallest documented change needed to reproduce “The failure reproduces but the bundle contains a test credential”; retain that change as reproducible data.
- [ ] **UC-M10.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reproduction and leakage test”; require “The bundle both supports its stated reproduction and passes secret/scope checks” and forbid a false-success verdict.
- [ ] **UC-M10.07-C096-T06 · Adverse execution:** Exercise the “Reproduction and leakage test” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.07-C096-T07 · Effect inspection:** Inspect “Reproduction and leakage test” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.07-C096-T08 · Refusal versus failure:** Confirm the “Reproduction and leakage test” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.07-C096-T09 · Reset and retention:** Restore only the disposable “Reproduction and leakage test” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.07-C096-T10 · Negative regression:** Register the “Reproduction and leakage test” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.07-C097 · Change / failure test

**Original checklist item:** Exercise reproduction and leakage test when bundle export is interrupted or encounters secret-bearing diagnostic content; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.07-C097-T01 · Scenario record:** Write the “Reproduction and leakage test” change/failure scenario exactly as supplied: bundle export is interrupted or encounters secret-bearing diagnostic content; identify the property that must remain true: “The bundle both supports its stated reproduction and passes secret/scope checks”.
- [ ] **UC-M10.07-C097-T02 · Baseline capture:** Create a known-valid “Reproduction and leakage test” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.07-C097-T03 · Injection map:** Locate the “Reproduction and leakage test” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Reproduction and leakage test” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.07-C097-T05 · Controlled trigger:** Introduce the controlled “Reproduction and leakage test” scenario in the disposable fixture: bundle export is interrupted or encounters secret-bearing diagnostic content; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.07-C097-T06 · Intermediate inspection:** Inspect the “Reproduction and leakage test” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reproduction and leakage test”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Reproduction and leakage test” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.07-C097-T09 · Repeat and compare:** Repeat the selected “Reproduction and leakage test” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.07-C097-T10 · Failure evidence:** Publish the “Reproduction and leakage test” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fixture failures and export repetitions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Reproduction and leakage test”: “Fixture failures and export repetitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.07-C098-T02 · Measurement method:** Choose how to observe each “Reproduction and leakage test” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Reproduction and leakage test”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reproduction and leakage test” cases for “Fixture failures and export repetitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reproduction and leakage test” limit; preserve “The bundle both supports its stated reproduction and passes secret/scope checks”.
- [ ] **UC-M10.07-C098-T06 · Normal measurement:** Run or review the normal “Reproduction and leakage test” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.07-C098-T07 · At-limit measurement:** Exercise the “Reproduction and leakage test” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.07-C098-T08 · Over-limit measurement:** Exercise the “Reproduction and leakage test” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.07-C098-T09 · Uncovered-scope report:** List the “Reproduction and leakage test” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.07-C098-T10 · Limit evidence:** Publish the selected “Reproduction and leakage test” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reproduction and leakage test with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.07-C099-T01 · Event inventory:** List the “Reproduction and leakage test” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Reproduction and leakage test” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.07-C099-T03 · Failure mapping:** Map each documented “Reproduction and leakage test” refusal or error to a diagnostic outcome; include “The failure reproduces but the bundle contains a test credential” and prohibit conversion into a success message.
- [ ] **UC-M10.07-C099-T04 · Emission path:** Add the “Reproduction and leakage test” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.07-C099-T05 · Redaction check:** Test “Reproduction and leakage test” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.07-C099-T06 · Output budget:** Set and exercise bounded “Reproduction and leakage test” message size, rate and retention compatible with “Fixture failures and export repetitions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.07-C099-T07 · Success/refusal fixtures:** Capture “Reproduction and leakage test” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reproduction and leakage test” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.07-C099-T09 · Operator review:** Read the “Reproduction and leakage test” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.07-C099-T10 · Diagnostic evidence:** Publish redacted “Reproduction and leakage test” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reproduction and leakage test; label unexecuted checks as untested.

- [ ] **UC-M10.07-C100-T01 · Evidence inventory:** List the “Reproduction and leakage test” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.07-C100-T02 · Artifact references:** Record the exact “Reproduction and leakage test” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.07-C100-T03 · Fixture references:** Attach the “Reproduction and leakage test” fixture IDs, input identities and oracle definition; preserve the source counterexample “The failure reproduces but the bundle contains a test credential” as a distinct evidence case.
- [ ] **UC-M10.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reproduction and leakage test”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.07-C100-T05 · Environment record:** Record the actual “Reproduction and leakage test” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.07-C100-T06 · Expected versus observed:** Pair every “Reproduction and leakage test” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.07-C100-T07 · Failure and limit records:** Attach “Reproduction and leakage test” change/failure and bounds evidence where required; include uncovered “Fixture failures and export repetitions” and unresolved violations of “The bundle both supports its stated reproduction and passes secret/scope checks”.
- [ ] **UC-M10.07-C100-T08 · Evidence hygiene:** Check the “Reproduction and leakage test” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.07-C100-T09 · Reproduction review:** Have the “Reproduction and leakage test” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.07-C100-T10 · Acceptance linkage:** Link the “Reproduction and leakage test” evidence to its parent and UC-M10.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

