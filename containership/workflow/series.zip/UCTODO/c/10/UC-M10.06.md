# UC-M10.06 — Replay and interactive debugger

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/10.md)

| Field | Preserved source value |
|---|---|
| Workstream | 10. Observability and operator experience |
| Milestone | C |
| Priority | P1 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M02.08](../02/UC-M02.08.md), [UC-M08.04](../08/UC-M08.04.md), [UC-M10.03](../10/UC-M10.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4]. |

## Original requirement

Retain source maps and bounded deterministic inputs for guest stepping and reproduction; distinguish simulation from real-time I/O.

**Original acceptance criterion:** A recorded deterministic failure reproduces with the same observable state and flags unrecorded nondeterminism.

**Source trace:** Original checklist `UC100/c/10/UC-M10.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 959–969 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Replay scope

**Source delivery:** Define which workload behavior is deterministic and which external effects are outside replay.

**Source invariant:** Replay claims do not imply reproduction of unrecorded real-time I/O.

**Source negative case:** A replay is labeled exact despite missing network inputs.

**Source bounded quantities:** Supported behaviors and excluded input classes.

### UC-M10.06-C001 · Contract

**Original checklist item:** Specify replay scope inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C001-T01 · Scope statement:** Draft the operation boundary for “Replay scope” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Replay scope”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C001-T03 · Output inventory:** List the outputs of “Replay scope” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Replay scope”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C001-T05 · Prerequisite contract:** Map “Replay scope” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Replay scope”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C001-T07 · Invariant clause:** Add a normative clause for “Replay scope” that preserves “Replay claims do not imply reproduction of unrecorded real-time I/O”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Replay scope”; include the source counterexample “A replay is labeled exact despite missing network inputs” and the intended safe disposition.
- [ ] **UC-M10.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Supported behaviors and excluded input classes” in the “Replay scope” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C001-T10 · Contract review:** Review the “Replay scope” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C002 · Delivery

**Original checklist item:** Define which workload behavior is deterministic and which external effects are outside replay.

- [ ] **UC-M10.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Replay scope”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C002-T02 · Change plan:** Break the source delivery for “Replay scope” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C002-T03 · Core artifact:** Create the “Replay scope” model, schema or inventory that realizes this source instruction: Define which workload behavior is deterministic and which external effects are outside replay.
- [ ] **UC-M10.06-C002-T04 · Concrete realization:** Populate “Replay scope” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M10.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Replay scope” needed to preserve “Replay claims do not imply reproduction of unrecorded real-time I/O”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C002-T06 · Dependency connection:** Connect the “Replay scope” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C002-T07 · Resource behavior:** Account for “Supported behaviors and excluded input classes” in “Replay scope”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C002-T08 · Delivery check:** Run the smallest real “Replay scope” path and its adverse fixture “A replay is labeled exact despite missing network inputs”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C002-T09 · Patch review:** Review the “Replay scope” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C002-T10 · Delivery handoff:** Publish the “Replay scope” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replay claims do not imply reproduction of unrecorded real-time I/O. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Replay scope”; copy its required invariant exactly: “Replay claims do not imply reproduction of unrecorded real-time I/O”.
- [ ] **UC-M10.06-C003-T02 · Observable terms:** Define each term in the “Replay scope” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C003-T03 · Precondition set:** List the preconditions under which “Replay claims do not imply reproduction of unrecorded real-time I/O” must hold for “Replay scope”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C003-T04 · Transition coverage:** Map the “Replay scope” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Replay scope”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C003-T06 · Satisfying fixture:** Create a concrete “Replay scope” case that satisfies “Replay claims do not imply reproduction of unrecorded real-time I/O”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C003-T07 · Violating fixture:** Create the source counterexample “A replay is labeled exact despite missing network inputs” for “Replay scope”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C003-T08 · Enforcement evidence:** Exercise the “Replay scope” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C003-T09 · Regression linkage:** Link the “Replay scope” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Replay scope” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C004 · Integration

**Original checklist item:** Integrate replay scope with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Replay scope” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C004-T02 · Field mapping:** Map every “Replay scope” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Replay scope” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C004-T04 · Ownership agreement:** Specify who owns “Replay scope” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C004-T05 · Handoff implementation:** Connect “Replay scope” through the mapped seam using the real adapter or explicit specification reference; preserve “Replay claims do not imply reproduction of unrecorded real-time I/O” across the handoff.
- [ ] **UC-M10.06-C004-T06 · Absent-input case:** Omit one required “Replay scope” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C004-T07 · Stale-input case:** Supply an outdated “Replay scope” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Replay scope” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C004-T09 · Valid integration trace:** Run a valid “Replay scope” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C004-T10 · Seam review:** Reconcile the “Replay scope” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for replay scope; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Replay scope” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C005-T02 · Expected-result oracle:** Specify the “Replay scope” expected result independently of the implementation output; include the property “Replay claims do not imply reproduction of unrecorded real-time I/O” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C005-T03 · Fixture material:** Create the concrete “Replay scope” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C005-T04 · Target preparation:** Prepare the “Replay scope” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C005-T05 · Initial-state record:** Record the initial “Replay scope” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C005-T06 · Valid-path execution:** Execute the “Replay scope” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C005-T07 · Outcome comparison:** Compare every declared “Replay scope” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C005-T08 · State and bounds check:** Inspect the “Replay scope” ownership/state effects and actual use of “Supported behaviors and excluded input classes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C005-T09 · Repeatability check:** Repeat the same “Replay scope” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C005-T10 · Positive evidence:** Attach the “Replay scope” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C006 · Negative test

**Original checklist item:** Negative case: A replay is labeled exact despite missing network inputs. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Replay scope” source counterexample: “A replay is labeled exact despite missing network inputs”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Replay scope”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C006-T03 · Valid control:** Construct a valid “Replay scope” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C006-T04 · Minimal adverse input:** Derive the “Replay scope” adverse fixture from the control with the smallest documented change needed to reproduce “A replay is labeled exact despite missing network inputs”; retain that change as reproducible data.
- [ ] **UC-M10.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Replay scope”; require “Replay claims do not imply reproduction of unrecorded real-time I/O” and forbid a false-success verdict.
- [ ] **UC-M10.06-C006-T06 · Adverse execution:** Exercise the “Replay scope” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C006-T07 · Effect inspection:** Inspect “Replay scope” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C006-T08 · Refusal versus failure:** Confirm the “Replay scope” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C006-T09 · Reset and retention:** Restore only the disposable “Replay scope” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C006-T10 · Negative regression:** Register the “Replay scope” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C007 · Change / failure test

**Original checklist item:** Exercise replay scope when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C007-T01 · Scenario record:** Write the “Replay scope” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Replay claims do not imply reproduction of unrecorded real-time I/O”.
- [ ] **UC-M10.06-C007-T02 · Baseline capture:** Create a known-valid “Replay scope” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C007-T03 · Injection map:** Locate the “Replay scope” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Replay scope” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C007-T05 · Controlled trigger:** Introduce the controlled “Replay scope” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C007-T06 · Intermediate inspection:** Inspect the “Replay scope” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Replay scope”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Replay scope” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C007-T09 · Repeat and compare:** Repeat the selected “Replay scope” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C007-T10 · Failure evidence:** Publish the “Replay scope” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for supported behaviors and excluded input classes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Replay scope”: “Supported behaviors and excluded input classes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C008-T02 · Measurement method:** Choose how to observe each “Replay scope” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Replay scope”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Replay scope” cases for “Supported behaviors and excluded input classes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Replay scope” limit; preserve “Replay claims do not imply reproduction of unrecorded real-time I/O”.
- [ ] **UC-M10.06-C008-T06 · Normal measurement:** Run or review the normal “Replay scope” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C008-T07 · At-limit measurement:** Exercise the “Replay scope” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C008-T08 · Over-limit measurement:** Exercise the “Replay scope” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C008-T09 · Uncovered-scope report:** List the “Replay scope” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C008-T10 · Limit evidence:** Publish the selected “Replay scope” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for replay scope with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C009-T01 · Event inventory:** List the “Replay scope” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Replay scope” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C009-T03 · Failure mapping:** Map each documented “Replay scope” refusal or error to a diagnostic outcome; include “A replay is labeled exact despite missing network inputs” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C009-T04 · Emission path:** Add the “Replay scope” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C009-T05 · Redaction check:** Test “Replay scope” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C009-T06 · Output budget:** Set and exercise bounded “Replay scope” message size, rate and retention compatible with “Supported behaviors and excluded input classes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C009-T07 · Success/refusal fixtures:** Capture “Replay scope” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Replay scope” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C009-T09 · Operator review:** Read the “Replay scope” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C009-T10 · Diagnostic evidence:** Publish redacted “Replay scope” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for replay scope; label unexecuted checks as untested.

- [ ] **UC-M10.06-C010-T01 · Evidence inventory:** List the “Replay scope” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C010-T02 · Artifact references:** Record the exact “Replay scope” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C010-T03 · Fixture references:** Attach the “Replay scope” fixture IDs, input identities and oracle definition; preserve the source counterexample “A replay is labeled exact despite missing network inputs” as a distinct evidence case.
- [ ] **UC-M10.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Replay scope”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C010-T05 · Environment record:** Record the actual “Replay scope” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C010-T06 · Expected versus observed:** Pair every “Replay scope” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C010-T07 · Failure and limit records:** Attach “Replay scope” change/failure and bounds evidence where required; include uncovered “Supported behaviors and excluded input classes” and unresolved violations of “Replay claims do not imply reproduction of unrecorded real-time I/O”.
- [ ] **UC-M10.06-C010-T08 · Evidence hygiene:** Check the “Replay scope” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C010-T09 · Reproduction review:** Have the “Replay scope” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C010-T10 · Acceptance linkage:** Link the “Replay scope” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Input capture

**Source delivery:** Record identified deterministic inputs and relevant ordering information.

**Source invariant:** A failure's required replay inputs remain attributable to its generation.

**Source negative case:** A trace records outputs but omits a required input.

**Source bounded quantities:** Captured bytes and event count.

### UC-M10.06-C011 · Contract

**Original checklist item:** Specify input capture inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C011-T01 · Scope statement:** Draft the operation boundary for “Input capture” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Input capture”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C011-T03 · Output inventory:** List the outputs of “Input capture” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Input capture”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C011-T05 · Prerequisite contract:** Map “Input capture” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Input capture”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C011-T07 · Invariant clause:** Add a normative clause for “Input capture” that preserves “A failure's required replay inputs remain attributable to its generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Input capture”; include the source counterexample “A trace records outputs but omits a required input” and the intended safe disposition.
- [ ] **UC-M10.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Captured bytes and event count” in the “Input capture” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C011-T10 · Contract review:** Review the “Input capture” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C012 · Delivery

**Original checklist item:** Record identified deterministic inputs and relevant ordering information.

- [ ] **UC-M10.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Input capture”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C012-T02 · Change plan:** Break the source delivery for “Input capture” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C012-T03 · Core artifact:** Create the “Input capture” model, schema or inventory that realizes this source instruction: Record identified deterministic inputs and relevant ordering information.
- [ ] **UC-M10.06-C012-T04 · Concrete realization:** Populate “Input capture” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M10.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Input capture” needed to preserve “A failure's required replay inputs remain attributable to its generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C012-T06 · Dependency connection:** Connect the “Input capture” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C012-T07 · Resource behavior:** Account for “Captured bytes and event count” in “Input capture”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C012-T08 · Delivery check:** Run the smallest real “Input capture” path and its adverse fixture “A trace records outputs but omits a required input”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C012-T09 · Patch review:** Review the “Input capture” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C012-T10 · Delivery handoff:** Publish the “Input capture” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A failure's required replay inputs remain attributable to its generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Input capture”; copy its required invariant exactly: “A failure's required replay inputs remain attributable to its generation”.
- [ ] **UC-M10.06-C013-T02 · Observable terms:** Define each term in the “Input capture” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C013-T03 · Precondition set:** List the preconditions under which “A failure's required replay inputs remain attributable to its generation” must hold for “Input capture”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C013-T04 · Transition coverage:** Map the “Input capture” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Input capture”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C013-T06 · Satisfying fixture:** Create a concrete “Input capture” case that satisfies “A failure's required replay inputs remain attributable to its generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C013-T07 · Violating fixture:** Create the source counterexample “A trace records outputs but omits a required input” for “Input capture”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C013-T08 · Enforcement evidence:** Exercise the “Input capture” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C013-T09 · Regression linkage:** Link the “Input capture” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Input capture” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C014 · Integration

**Original checklist item:** Integrate input capture with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Input capture” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C014-T02 · Field mapping:** Map every “Input capture” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Input capture” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C014-T04 · Ownership agreement:** Specify who owns “Input capture” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C014-T05 · Handoff implementation:** Connect “Input capture” through the mapped seam using the real adapter or explicit specification reference; preserve “A failure's required replay inputs remain attributable to its generation” across the handoff.
- [ ] **UC-M10.06-C014-T06 · Absent-input case:** Omit one required “Input capture” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C014-T07 · Stale-input case:** Supply an outdated “Input capture” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Input capture” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C014-T09 · Valid integration trace:** Run a valid “Input capture” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C014-T10 · Seam review:** Reconcile the “Input capture” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for input capture; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Input capture” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C015-T02 · Expected-result oracle:** Specify the “Input capture” expected result independently of the implementation output; include the property “A failure's required replay inputs remain attributable to its generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C015-T03 · Fixture material:** Create the concrete “Input capture” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C015-T04 · Target preparation:** Prepare the “Input capture” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C015-T05 · Initial-state record:** Record the initial “Input capture” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C015-T06 · Valid-path execution:** Execute the “Input capture” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C015-T07 · Outcome comparison:** Compare every declared “Input capture” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C015-T08 · State and bounds check:** Inspect the “Input capture” ownership/state effects and actual use of “Captured bytes and event count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C015-T09 · Repeatability check:** Repeat the same “Input capture” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C015-T10 · Positive evidence:** Attach the “Input capture” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C016 · Negative test

**Original checklist item:** Negative case: A trace records outputs but omits a required input. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Input capture” source counterexample: “A trace records outputs but omits a required input”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Input capture”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C016-T03 · Valid control:** Construct a valid “Input capture” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C016-T04 · Minimal adverse input:** Derive the “Input capture” adverse fixture from the control with the smallest documented change needed to reproduce “A trace records outputs but omits a required input”; retain that change as reproducible data.
- [ ] **UC-M10.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Input capture”; require “A failure's required replay inputs remain attributable to its generation” and forbid a false-success verdict.
- [ ] **UC-M10.06-C016-T06 · Adverse execution:** Exercise the “Input capture” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C016-T07 · Effect inspection:** Inspect “Input capture” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C016-T08 · Refusal versus failure:** Confirm the “Input capture” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C016-T09 · Reset and retention:** Restore only the disposable “Input capture” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C016-T10 · Negative regression:** Register the “Input capture” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C017 · Change / failure test

**Original checklist item:** Exercise input capture when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C017-T01 · Scenario record:** Write the “Input capture” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “A failure's required replay inputs remain attributable to its generation”.
- [ ] **UC-M10.06-C017-T02 · Baseline capture:** Create a known-valid “Input capture” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C017-T03 · Injection map:** Locate the “Input capture” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Input capture” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C017-T05 · Controlled trigger:** Introduce the controlled “Input capture” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C017-T06 · Intermediate inspection:** Inspect the “Input capture” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Input capture”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Input capture” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C017-T09 · Repeat and compare:** Repeat the selected “Input capture” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C017-T10 · Failure evidence:** Publish the “Input capture” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for captured bytes and event count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Input capture”: “Captured bytes and event count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C018-T02 · Measurement method:** Choose how to observe each “Input capture” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Input capture”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Input capture” cases for “Captured bytes and event count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Input capture” limit; preserve “A failure's required replay inputs remain attributable to its generation”.
- [ ] **UC-M10.06-C018-T06 · Normal measurement:** Run or review the normal “Input capture” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C018-T07 · At-limit measurement:** Exercise the “Input capture” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C018-T08 · Over-limit measurement:** Exercise the “Input capture” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C018-T09 · Uncovered-scope report:** List the “Input capture” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C018-T10 · Limit evidence:** Publish the selected “Input capture” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for input capture with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C019-T01 · Event inventory:** List the “Input capture” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Input capture” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C019-T03 · Failure mapping:** Map each documented “Input capture” refusal or error to a diagnostic outcome; include “A trace records outputs but omits a required input” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C019-T04 · Emission path:** Add the “Input capture” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C019-T05 · Redaction check:** Test “Input capture” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C019-T06 · Output budget:** Set and exercise bounded “Input capture” message size, rate and retention compatible with “Captured bytes and event count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C019-T07 · Success/refusal fixtures:** Capture “Input capture” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Input capture” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C019-T09 · Operator review:** Read the “Input capture” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C019-T10 · Diagnostic evidence:** Publish redacted “Input capture” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for input capture; label unexecuted checks as untested.

- [ ] **UC-M10.06-C020-T01 · Evidence inventory:** List the “Input capture” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C020-T02 · Artifact references:** Record the exact “Input capture” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C020-T03 · Fixture references:** Attach the “Input capture” fixture IDs, input identities and oracle definition; preserve the source counterexample “A trace records outputs but omits a required input” as a distinct evidence case.
- [ ] **UC-M10.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Input capture”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C020-T05 · Environment record:** Record the actual “Input capture” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C020-T06 · Expected versus observed:** Pair every “Input capture” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C020-T07 · Failure and limit records:** Attach “Input capture” change/failure and bounds evidence where required; include uncovered “Captured bytes and event count” and unresolved violations of “A failure's required replay inputs remain attributable to its generation”.
- [ ] **UC-M10.06-C020-T08 · Evidence hygiene:** Check the “Input capture” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C020-T09 · Reproduction review:** Have the “Input capture” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C020-T10 · Acceptance linkage:** Link the “Input capture” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Source-map retention

**Source delivery:** Retain source maps bound to exact compiler and image identities.

**Source invariant:** Stepping uses the source map for the executed image.

**Source negative case:** A debugger opens a map from a different build.

**Source bounded quantities:** Map bytes and retained builds.

### UC-M10.06-C021 · Contract

**Original checklist item:** Specify source-map retention inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C021-T01 · Scope statement:** Draft the operation boundary for “Source-map retention” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Source-map retention”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C021-T03 · Output inventory:** List the outputs of “Source-map retention” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Source-map retention”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C021-T05 · Prerequisite contract:** Map “Source-map retention” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Source-map retention”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C021-T07 · Invariant clause:** Add a normative clause for “Source-map retention” that preserves “Stepping uses the source map for the executed image”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Source-map retention”; include the source counterexample “A debugger opens a map from a different build” and the intended safe disposition.
- [ ] **UC-M10.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Map bytes and retained builds” in the “Source-map retention” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C021-T10 · Contract review:** Review the “Source-map retention” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C022 · Delivery

**Original checklist item:** Retain source maps bound to exact compiler and image identities.

- [ ] **UC-M10.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Source-map retention”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C022-T02 · Change plan:** Break the source delivery for “Source-map retention” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Source-map retention” that realizes this source instruction: Retain source maps bound to exact compiler and image identities.
- [ ] **UC-M10.06-C022-T04 · Concrete realization:** Trace “Source-map retention” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Source-map retention” needed to preserve “Stepping uses the source map for the executed image”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C022-T06 · Dependency connection:** Connect the “Source-map retention” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C022-T07 · Resource behavior:** Account for “Map bytes and retained builds” in “Source-map retention”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C022-T08 · Delivery check:** Run the smallest real “Source-map retention” path and its adverse fixture “A debugger opens a map from a different build”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C022-T09 · Patch review:** Review the “Source-map retention” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C022-T10 · Delivery handoff:** Publish the “Source-map retention” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stepping uses the source map for the executed image. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Source-map retention”; copy its required invariant exactly: “Stepping uses the source map for the executed image”.
- [ ] **UC-M10.06-C023-T02 · Observable terms:** Define each term in the “Source-map retention” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C023-T03 · Precondition set:** List the preconditions under which “Stepping uses the source map for the executed image” must hold for “Source-map retention”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C023-T04 · Transition coverage:** Map the “Source-map retention” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Source-map retention”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C023-T06 · Satisfying fixture:** Create a concrete “Source-map retention” case that satisfies “Stepping uses the source map for the executed image”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C023-T07 · Violating fixture:** Create the source counterexample “A debugger opens a map from a different build” for “Source-map retention”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C023-T08 · Enforcement evidence:** Exercise the “Source-map retention” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C023-T09 · Regression linkage:** Link the “Source-map retention” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Source-map retention” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C024 · Integration

**Original checklist item:** Integrate source-map retention with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Source-map retention” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C024-T02 · Field mapping:** Map every “Source-map retention” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Source-map retention” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C024-T04 · Ownership agreement:** Specify who owns “Source-map retention” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C024-T05 · Handoff implementation:** Connect “Source-map retention” through the mapped seam using the real adapter or explicit specification reference; preserve “Stepping uses the source map for the executed image” across the handoff.
- [ ] **UC-M10.06-C024-T06 · Absent-input case:** Omit one required “Source-map retention” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C024-T07 · Stale-input case:** Supply an outdated “Source-map retention” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Source-map retention” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C024-T09 · Valid integration trace:** Run a valid “Source-map retention” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C024-T10 · Seam review:** Reconcile the “Source-map retention” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for source-map retention; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Source-map retention” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C025-T02 · Expected-result oracle:** Specify the “Source-map retention” expected result independently of the implementation output; include the property “Stepping uses the source map for the executed image” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C025-T03 · Fixture material:** Create the concrete “Source-map retention” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C025-T04 · Target preparation:** Prepare the “Source-map retention” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C025-T05 · Initial-state record:** Record the initial “Source-map retention” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C025-T06 · Valid-path execution:** Execute the “Source-map retention” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C025-T07 · Outcome comparison:** Compare every declared “Source-map retention” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C025-T08 · State and bounds check:** Inspect the “Source-map retention” ownership/state effects and actual use of “Map bytes and retained builds”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C025-T09 · Repeatability check:** Repeat the same “Source-map retention” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C025-T10 · Positive evidence:** Attach the “Source-map retention” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C026 · Negative test

**Original checklist item:** Negative case: A debugger opens a map from a different build. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Source-map retention” source counterexample: “A debugger opens a map from a different build”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Source-map retention”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C026-T03 · Valid control:** Construct a valid “Source-map retention” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C026-T04 · Minimal adverse input:** Derive the “Source-map retention” adverse fixture from the control with the smallest documented change needed to reproduce “A debugger opens a map from a different build”; retain that change as reproducible data.
- [ ] **UC-M10.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Source-map retention”; require “Stepping uses the source map for the executed image” and forbid a false-success verdict.
- [ ] **UC-M10.06-C026-T06 · Adverse execution:** Exercise the “Source-map retention” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C026-T07 · Effect inspection:** Inspect “Source-map retention” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C026-T08 · Refusal versus failure:** Confirm the “Source-map retention” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C026-T09 · Reset and retention:** Restore only the disposable “Source-map retention” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C026-T10 · Negative regression:** Register the “Source-map retention” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C027 · Change / failure test

**Original checklist item:** Exercise source-map retention when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C027-T01 · Scenario record:** Write the “Source-map retention” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Stepping uses the source map for the executed image”.
- [ ] **UC-M10.06-C027-T02 · Baseline capture:** Create a known-valid “Source-map retention” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C027-T03 · Injection map:** Locate the “Source-map retention” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Source-map retention” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C027-T05 · Controlled trigger:** Introduce the controlled “Source-map retention” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C027-T06 · Intermediate inspection:** Inspect the “Source-map retention” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Source-map retention”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Source-map retention” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C027-T09 · Repeat and compare:** Repeat the selected “Source-map retention” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C027-T10 · Failure evidence:** Publish the “Source-map retention” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for map bytes and retained builds; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Source-map retention”: “Map bytes and retained builds”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C028-T02 · Measurement method:** Choose how to observe each “Source-map retention” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Source-map retention”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Source-map retention” cases for “Map bytes and retained builds”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Source-map retention” limit; preserve “Stepping uses the source map for the executed image”.
- [ ] **UC-M10.06-C028-T06 · Normal measurement:** Run or review the normal “Source-map retention” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C028-T07 · At-limit measurement:** Exercise the “Source-map retention” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C028-T08 · Over-limit measurement:** Exercise the “Source-map retention” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C028-T09 · Uncovered-scope report:** List the “Source-map retention” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C028-T10 · Limit evidence:** Publish the selected “Source-map retention” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for source-map retention with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C029-T01 · Event inventory:** List the “Source-map retention” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Source-map retention” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C029-T03 · Failure mapping:** Map each documented “Source-map retention” refusal or error to a diagnostic outcome; include “A debugger opens a map from a different build” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C029-T04 · Emission path:** Add the “Source-map retention” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C029-T05 · Redaction check:** Test “Source-map retention” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C029-T06 · Output budget:** Set and exercise bounded “Source-map retention” message size, rate and retention compatible with “Map bytes and retained builds”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C029-T07 · Success/refusal fixtures:** Capture “Source-map retention” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Source-map retention” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C029-T09 · Operator review:** Read the “Source-map retention” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C029-T10 · Diagnostic evidence:** Publish redacted “Source-map retention” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for source-map retention; label unexecuted checks as untested.

- [ ] **UC-M10.06-C030-T01 · Evidence inventory:** List the “Source-map retention” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C030-T02 · Artifact references:** Record the exact “Source-map retention” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C030-T03 · Fixture references:** Attach the “Source-map retention” fixture IDs, input identities and oracle definition; preserve the source counterexample “A debugger opens a map from a different build” as a distinct evidence case.
- [ ] **UC-M10.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Source-map retention”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C030-T05 · Environment record:** Record the actual “Source-map retention” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C030-T06 · Expected versus observed:** Pair every “Source-map retention” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C030-T07 · Failure and limit records:** Attach “Source-map retention” change/failure and bounds evidence where required; include uncovered “Map bytes and retained builds” and unresolved violations of “Stepping uses the source map for the executed image”.
- [ ] **UC-M10.06-C030-T08 · Evidence hygiene:** Check the “Source-map retention” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C030-T09 · Reproduction review:** Have the “Source-map retention” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C030-T10 · Acceptance linkage:** Link the “Source-map retention” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Checkpoint integration

**Source delivery:** Start replay from a verified compatible state checkpoint.

**Source invariant:** Replay cannot use a convenient but incompatible snapshot.

**Source negative case:** A snapshot from another ABI is used to reproduce the failure.

**Source bounded quantities:** Checkpoint bytes and restore deadline.

### UC-M10.06-C031 · Contract

**Original checklist item:** Specify checkpoint integration inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C031-T01 · Scope statement:** Draft the operation boundary for “Checkpoint integration” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Checkpoint integration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C031-T03 · Output inventory:** List the outputs of “Checkpoint integration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Checkpoint integration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C031-T05 · Prerequisite contract:** Map “Checkpoint integration” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Checkpoint integration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C031-T07 · Invariant clause:** Add a normative clause for “Checkpoint integration” that preserves “Replay cannot use a convenient but incompatible snapshot”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Checkpoint integration”; include the source counterexample “A snapshot from another ABI is used to reproduce the failure” and the intended safe disposition.
- [ ] **UC-M10.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Checkpoint bytes and restore deadline” in the “Checkpoint integration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C031-T10 · Contract review:** Review the “Checkpoint integration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C032 · Delivery

**Original checklist item:** Start replay from a verified compatible state checkpoint.

- [ ] **UC-M10.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Checkpoint integration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C032-T02 · Change plan:** Break the source delivery for “Checkpoint integration” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Checkpoint integration” that realizes this source instruction: Start replay from a verified compatible state checkpoint.
- [ ] **UC-M10.06-C032-T04 · Concrete realization:** Trace “Checkpoint integration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Checkpoint integration” needed to preserve “Replay cannot use a convenient but incompatible snapshot”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C032-T06 · Dependency connection:** Connect the “Checkpoint integration” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C032-T07 · Resource behavior:** Account for “Checkpoint bytes and restore deadline” in “Checkpoint integration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C032-T08 · Delivery check:** Run the smallest real “Checkpoint integration” path and its adverse fixture “A snapshot from another ABI is used to reproduce the failure”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C032-T09 · Patch review:** Review the “Checkpoint integration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C032-T10 · Delivery handoff:** Publish the “Checkpoint integration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replay cannot use a convenient but incompatible snapshot. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Checkpoint integration”; copy its required invariant exactly: “Replay cannot use a convenient but incompatible snapshot”.
- [ ] **UC-M10.06-C033-T02 · Observable terms:** Define each term in the “Checkpoint integration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C033-T03 · Precondition set:** List the preconditions under which “Replay cannot use a convenient but incompatible snapshot” must hold for “Checkpoint integration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C033-T04 · Transition coverage:** Map the “Checkpoint integration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Checkpoint integration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C033-T06 · Satisfying fixture:** Create a concrete “Checkpoint integration” case that satisfies “Replay cannot use a convenient but incompatible snapshot”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C033-T07 · Violating fixture:** Create the source counterexample “A snapshot from another ABI is used to reproduce the failure” for “Checkpoint integration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C033-T08 · Enforcement evidence:** Exercise the “Checkpoint integration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C033-T09 · Regression linkage:** Link the “Checkpoint integration” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Checkpoint integration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C034 · Integration

**Original checklist item:** Integrate checkpoint integration with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Checkpoint integration” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C034-T02 · Field mapping:** Map every “Checkpoint integration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Checkpoint integration” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C034-T04 · Ownership agreement:** Specify who owns “Checkpoint integration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C034-T05 · Handoff implementation:** Connect “Checkpoint integration” through the mapped seam using the real adapter or explicit specification reference; preserve “Replay cannot use a convenient but incompatible snapshot” across the handoff.
- [ ] **UC-M10.06-C034-T06 · Absent-input case:** Omit one required “Checkpoint integration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C034-T07 · Stale-input case:** Supply an outdated “Checkpoint integration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Checkpoint integration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C034-T09 · Valid integration trace:** Run a valid “Checkpoint integration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C034-T10 · Seam review:** Reconcile the “Checkpoint integration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for checkpoint integration; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Checkpoint integration” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C035-T02 · Expected-result oracle:** Specify the “Checkpoint integration” expected result independently of the implementation output; include the property “Replay cannot use a convenient but incompatible snapshot” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C035-T03 · Fixture material:** Create the concrete “Checkpoint integration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C035-T04 · Target preparation:** Prepare the “Checkpoint integration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C035-T05 · Initial-state record:** Record the initial “Checkpoint integration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C035-T06 · Valid-path execution:** Execute the “Checkpoint integration” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C035-T07 · Outcome comparison:** Compare every declared “Checkpoint integration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C035-T08 · State and bounds check:** Inspect the “Checkpoint integration” ownership/state effects and actual use of “Checkpoint bytes and restore deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C035-T09 · Repeatability check:** Repeat the same “Checkpoint integration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C035-T10 · Positive evidence:** Attach the “Checkpoint integration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C036 · Negative test

**Original checklist item:** Negative case: A snapshot from another ABI is used to reproduce the failure. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Checkpoint integration” source counterexample: “A snapshot from another ABI is used to reproduce the failure”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Checkpoint integration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C036-T03 · Valid control:** Construct a valid “Checkpoint integration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C036-T04 · Minimal adverse input:** Derive the “Checkpoint integration” adverse fixture from the control with the smallest documented change needed to reproduce “A snapshot from another ABI is used to reproduce the failure”; retain that change as reproducible data.
- [ ] **UC-M10.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Checkpoint integration”; require “Replay cannot use a convenient but incompatible snapshot” and forbid a false-success verdict.
- [ ] **UC-M10.06-C036-T06 · Adverse execution:** Exercise the “Checkpoint integration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C036-T07 · Effect inspection:** Inspect “Checkpoint integration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C036-T08 · Refusal versus failure:** Confirm the “Checkpoint integration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C036-T09 · Reset and retention:** Restore only the disposable “Checkpoint integration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C036-T10 · Negative regression:** Register the “Checkpoint integration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C037 · Change / failure test

**Original checklist item:** Exercise checkpoint integration when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C037-T01 · Scenario record:** Write the “Checkpoint integration” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Replay cannot use a convenient but incompatible snapshot”.
- [ ] **UC-M10.06-C037-T02 · Baseline capture:** Create a known-valid “Checkpoint integration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C037-T03 · Injection map:** Locate the “Checkpoint integration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Checkpoint integration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C037-T05 · Controlled trigger:** Introduce the controlled “Checkpoint integration” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C037-T06 · Intermediate inspection:** Inspect the “Checkpoint integration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Checkpoint integration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Checkpoint integration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C037-T09 · Repeat and compare:** Repeat the selected “Checkpoint integration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C037-T10 · Failure evidence:** Publish the “Checkpoint integration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for checkpoint bytes and restore deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Checkpoint integration”: “Checkpoint bytes and restore deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C038-T02 · Measurement method:** Choose how to observe each “Checkpoint integration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Checkpoint integration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Checkpoint integration” cases for “Checkpoint bytes and restore deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Checkpoint integration” limit; preserve “Replay cannot use a convenient but incompatible snapshot”.
- [ ] **UC-M10.06-C038-T06 · Normal measurement:** Run or review the normal “Checkpoint integration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C038-T07 · At-limit measurement:** Exercise the “Checkpoint integration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C038-T08 · Over-limit measurement:** Exercise the “Checkpoint integration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C038-T09 · Uncovered-scope report:** List the “Checkpoint integration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C038-T10 · Limit evidence:** Publish the selected “Checkpoint integration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for checkpoint integration with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C039-T01 · Event inventory:** List the “Checkpoint integration” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Checkpoint integration” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C039-T03 · Failure mapping:** Map each documented “Checkpoint integration” refusal or error to a diagnostic outcome; include “A snapshot from another ABI is used to reproduce the failure” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C039-T04 · Emission path:** Add the “Checkpoint integration” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C039-T05 · Redaction check:** Test “Checkpoint integration” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C039-T06 · Output budget:** Set and exercise bounded “Checkpoint integration” message size, rate and retention compatible with “Checkpoint bytes and restore deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C039-T07 · Success/refusal fixtures:** Capture “Checkpoint integration” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Checkpoint integration” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C039-T09 · Operator review:** Read the “Checkpoint integration” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C039-T10 · Diagnostic evidence:** Publish redacted “Checkpoint integration” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for checkpoint integration; label unexecuted checks as untested.

- [ ] **UC-M10.06-C040-T01 · Evidence inventory:** List the “Checkpoint integration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C040-T02 · Artifact references:** Record the exact “Checkpoint integration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C040-T03 · Fixture references:** Attach the “Checkpoint integration” fixture IDs, input identities and oracle definition; preserve the source counterexample “A snapshot from another ABI is used to reproduce the failure” as a distinct evidence case.
- [ ] **UC-M10.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Checkpoint integration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C040-T05 · Environment record:** Record the actual “Checkpoint integration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C040-T06 · Expected versus observed:** Pair every “Checkpoint integration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C040-T07 · Failure and limit records:** Attach “Checkpoint integration” change/failure and bounds evidence where required; include uncovered “Checkpoint bytes and restore deadline” and unresolved violations of “Replay cannot use a convenient but incompatible snapshot”.
- [ ] **UC-M10.06-C040-T08 · Evidence hygiene:** Check the “Checkpoint integration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C040-T09 · Reproduction review:** Have the “Checkpoint integration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C040-T10 · Acceptance linkage:** Link the “Checkpoint integration” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Guest stepping interface

**Source delivery:** Implement the selected controlled guest stepping or pause interface.

**Source invariant:** Debug controls are explicit capabilities rather than assumed guest behavior.

**Source negative case:** A backend without stepping reports a simulated step as real execution.

**Source bounded quantities:** Step count and debugger command rate.

### UC-M10.06-C041 · Contract

**Original checklist item:** Specify guest stepping interface inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C041-T01 · Scope statement:** Draft the operation boundary for “Guest stepping interface” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Guest stepping interface”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C041-T03 · Output inventory:** List the outputs of “Guest stepping interface” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Guest stepping interface”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C041-T05 · Prerequisite contract:** Map “Guest stepping interface” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Guest stepping interface”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C041-T07 · Invariant clause:** Add a normative clause for “Guest stepping interface” that preserves “Debug controls are explicit capabilities rather than assumed guest behavior”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Guest stepping interface”; include the source counterexample “A backend without stepping reports a simulated step as real execution” and the intended safe disposition.
- [ ] **UC-M10.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Step count and debugger command rate” in the “Guest stepping interface” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C041-T10 · Contract review:** Review the “Guest stepping interface” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C042 · Delivery

**Original checklist item:** Implement the selected controlled guest stepping or pause interface.

- [ ] **UC-M10.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Guest stepping interface”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C042-T02 · Change plan:** Break the source delivery for “Guest stepping interface” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Guest stepping interface” that realizes this source instruction: Implement the selected controlled guest stepping or pause interface.
- [ ] **UC-M10.06-C042-T04 · Concrete realization:** Trace “Guest stepping interface” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Guest stepping interface” needed to preserve “Debug controls are explicit capabilities rather than assumed guest behavior”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C042-T06 · Dependency connection:** Connect the “Guest stepping interface” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C042-T07 · Resource behavior:** Account for “Step count and debugger command rate” in “Guest stepping interface”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C042-T08 · Delivery check:** Run the smallest real “Guest stepping interface” path and its adverse fixture “A backend without stepping reports a simulated step as real execution”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C042-T09 · Patch review:** Review the “Guest stepping interface” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C042-T10 · Delivery handoff:** Publish the “Guest stepping interface” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Debug controls are explicit capabilities rather than assumed guest behavior. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Guest stepping interface”; copy its required invariant exactly: “Debug controls are explicit capabilities rather than assumed guest behavior”.
- [ ] **UC-M10.06-C043-T02 · Observable terms:** Define each term in the “Guest stepping interface” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C043-T03 · Precondition set:** List the preconditions under which “Debug controls are explicit capabilities rather than assumed guest behavior” must hold for “Guest stepping interface”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C043-T04 · Transition coverage:** Map the “Guest stepping interface” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Guest stepping interface”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C043-T06 · Satisfying fixture:** Create a concrete “Guest stepping interface” case that satisfies “Debug controls are explicit capabilities rather than assumed guest behavior”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C043-T07 · Violating fixture:** Create the source counterexample “A backend without stepping reports a simulated step as real execution” for “Guest stepping interface”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C043-T08 · Enforcement evidence:** Exercise the “Guest stepping interface” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C043-T09 · Regression linkage:** Link the “Guest stepping interface” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Guest stepping interface” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C044 · Integration

**Original checklist item:** Integrate guest stepping interface with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Guest stepping interface” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C044-T02 · Field mapping:** Map every “Guest stepping interface” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Guest stepping interface” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C044-T04 · Ownership agreement:** Specify who owns “Guest stepping interface” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C044-T05 · Handoff implementation:** Connect “Guest stepping interface” through the mapped seam using the real adapter or explicit specification reference; preserve “Debug controls are explicit capabilities rather than assumed guest behavior” across the handoff.
- [ ] **UC-M10.06-C044-T06 · Absent-input case:** Omit one required “Guest stepping interface” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C044-T07 · Stale-input case:** Supply an outdated “Guest stepping interface” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Guest stepping interface” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C044-T09 · Valid integration trace:** Run a valid “Guest stepping interface” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C044-T10 · Seam review:** Reconcile the “Guest stepping interface” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for guest stepping interface; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Guest stepping interface” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C045-T02 · Expected-result oracle:** Specify the “Guest stepping interface” expected result independently of the implementation output; include the property “Debug controls are explicit capabilities rather than assumed guest behavior” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C045-T03 · Fixture material:** Create the concrete “Guest stepping interface” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C045-T04 · Target preparation:** Prepare the “Guest stepping interface” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C045-T05 · Initial-state record:** Record the initial “Guest stepping interface” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C045-T06 · Valid-path execution:** Execute the “Guest stepping interface” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C045-T07 · Outcome comparison:** Compare every declared “Guest stepping interface” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C045-T08 · State and bounds check:** Inspect the “Guest stepping interface” ownership/state effects and actual use of “Step count and debugger command rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C045-T09 · Repeatability check:** Repeat the same “Guest stepping interface” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C045-T10 · Positive evidence:** Attach the “Guest stepping interface” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C046 · Negative test

**Original checklist item:** Negative case: A backend without stepping reports a simulated step as real execution. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Guest stepping interface” source counterexample: “A backend without stepping reports a simulated step as real execution”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Guest stepping interface”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C046-T03 · Valid control:** Construct a valid “Guest stepping interface” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C046-T04 · Minimal adverse input:** Derive the “Guest stepping interface” adverse fixture from the control with the smallest documented change needed to reproduce “A backend without stepping reports a simulated step as real execution”; retain that change as reproducible data.
- [ ] **UC-M10.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Guest stepping interface”; require “Debug controls are explicit capabilities rather than assumed guest behavior” and forbid a false-success verdict.
- [ ] **UC-M10.06-C046-T06 · Adverse execution:** Exercise the “Guest stepping interface” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C046-T07 · Effect inspection:** Inspect “Guest stepping interface” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C046-T08 · Refusal versus failure:** Confirm the “Guest stepping interface” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C046-T09 · Reset and retention:** Restore only the disposable “Guest stepping interface” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C046-T10 · Negative regression:** Register the “Guest stepping interface” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C047 · Change / failure test

**Original checklist item:** Exercise guest stepping interface when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C047-T01 · Scenario record:** Write the “Guest stepping interface” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Debug controls are explicit capabilities rather than assumed guest behavior”.
- [ ] **UC-M10.06-C047-T02 · Baseline capture:** Create a known-valid “Guest stepping interface” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C047-T03 · Injection map:** Locate the “Guest stepping interface” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Guest stepping interface” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C047-T05 · Controlled trigger:** Introduce the controlled “Guest stepping interface” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C047-T06 · Intermediate inspection:** Inspect the “Guest stepping interface” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Guest stepping interface”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Guest stepping interface” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C047-T09 · Repeat and compare:** Repeat the selected “Guest stepping interface” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C047-T10 · Failure evidence:** Publish the “Guest stepping interface” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for step count and debugger command rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Guest stepping interface”: “Step count and debugger command rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C048-T02 · Measurement method:** Choose how to observe each “Guest stepping interface” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C048-T03 · Budget decision:** Select justified resource and input limits for “Guest stepping interface”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Guest stepping interface” cases for “Step count and debugger command rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Guest stepping interface” limit; preserve “Debug controls are explicit capabilities rather than assumed guest behavior”.
- [ ] **UC-M10.06-C048-T06 · Normal measurement:** Run or review the normal “Guest stepping interface” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C048-T07 · At-limit measurement:** Exercise the “Guest stepping interface” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C048-T08 · Over-limit measurement:** Exercise the “Guest stepping interface” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C048-T09 · Uncovered-scope report:** List the “Guest stepping interface” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C048-T10 · Limit evidence:** Publish the selected “Guest stepping interface” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for guest stepping interface with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C049-T01 · Event inventory:** List the “Guest stepping interface” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Guest stepping interface” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C049-T03 · Failure mapping:** Map each documented “Guest stepping interface” refusal or error to a diagnostic outcome; include “A backend without stepping reports a simulated step as real execution” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C049-T04 · Emission path:** Add the “Guest stepping interface” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C049-T05 · Redaction check:** Test “Guest stepping interface” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C049-T06 · Output budget:** Set and exercise bounded “Guest stepping interface” message size, rate and retention compatible with “Step count and debugger command rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C049-T07 · Success/refusal fixtures:** Capture “Guest stepping interface” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Guest stepping interface” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C049-T09 · Operator review:** Read the “Guest stepping interface” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C049-T10 · Diagnostic evidence:** Publish redacted “Guest stepping interface” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for guest stepping interface; label unexecuted checks as untested.

- [ ] **UC-M10.06-C050-T01 · Evidence inventory:** List the “Guest stepping interface” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C050-T02 · Artifact references:** Record the exact “Guest stepping interface” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C050-T03 · Fixture references:** Attach the “Guest stepping interface” fixture IDs, input identities and oracle definition; preserve the source counterexample “A backend without stepping reports a simulated step as real execution” as a distinct evidence case.
- [ ] **UC-M10.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Guest stepping interface”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C050-T05 · Environment record:** Record the actual “Guest stepping interface” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C050-T06 · Expected versus observed:** Pair every “Guest stepping interface” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C050-T07 · Failure and limit records:** Attach “Guest stepping interface” change/failure and bounds evidence where required; include uncovered “Step count and debugger command rate” and unresolved violations of “Debug controls are explicit capabilities rather than assumed guest behavior”.
- [ ] **UC-M10.06-C050-T08 · Evidence hygiene:** Check the “Guest stepping interface” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C050-T09 · Reproduction review:** Have the “Guest stepping interface” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C050-T10 · Acceptance linkage:** Link the “Guest stepping interface” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Clock separation

**Source delivery:** Use recorded simulation time while distinguishing live monotonic observations.

**Source invariant:** Replay does not accidentally replace real security clocks.

**Source negative case:** A debugger restores a simulated timestamp as live credential time.

**Source bounded quantities:** Clock events and conversion range.

### UC-M10.06-C051 · Contract

**Original checklist item:** Specify clock separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C051-T01 · Scope statement:** Draft the operation boundary for “Clock separation” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clock separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C051-T03 · Output inventory:** List the outputs of “Clock separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Clock separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C051-T05 · Prerequisite contract:** Map “Clock separation” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Clock separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C051-T07 · Invariant clause:** Add a normative clause for “Clock separation” that preserves “Replay does not accidentally replace real security clocks”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clock separation”; include the source counterexample “A debugger restores a simulated timestamp as live credential time” and the intended safe disposition.
- [ ] **UC-M10.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Clock events and conversion range” in the “Clock separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C051-T10 · Contract review:** Review the “Clock separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C052 · Delivery

**Original checklist item:** Use recorded simulation time while distinguishing live monotonic observations.

- [ ] **UC-M10.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clock separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C052-T02 · Change plan:** Break the source delivery for “Clock separation” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Clock separation” that realizes this source instruction: Use recorded simulation time while distinguishing live monotonic observations.
- [ ] **UC-M10.06-C052-T04 · Concrete realization:** Trace “Clock separation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clock separation” needed to preserve “Replay does not accidentally replace real security clocks”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C052-T06 · Dependency connection:** Connect the “Clock separation” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C052-T07 · Resource behavior:** Account for “Clock events and conversion range” in “Clock separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C052-T08 · Delivery check:** Run the smallest real “Clock separation” path and its adverse fixture “A debugger restores a simulated timestamp as live credential time”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C052-T09 · Patch review:** Review the “Clock separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C052-T10 · Delivery handoff:** Publish the “Clock separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replay does not accidentally replace real security clocks. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Clock separation”; copy its required invariant exactly: “Replay does not accidentally replace real security clocks”.
- [ ] **UC-M10.06-C053-T02 · Observable terms:** Define each term in the “Clock separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C053-T03 · Precondition set:** List the preconditions under which “Replay does not accidentally replace real security clocks” must hold for “Clock separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C053-T04 · Transition coverage:** Map the “Clock separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clock separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C053-T06 · Satisfying fixture:** Create a concrete “Clock separation” case that satisfies “Replay does not accidentally replace real security clocks”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C053-T07 · Violating fixture:** Create the source counterexample “A debugger restores a simulated timestamp as live credential time” for “Clock separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C053-T08 · Enforcement evidence:** Exercise the “Clock separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C053-T09 · Regression linkage:** Link the “Clock separation” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Clock separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C054 · Integration

**Original checklist item:** Integrate clock separation with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clock separation” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C054-T02 · Field mapping:** Map every “Clock separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Clock separation” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C054-T04 · Ownership agreement:** Specify who owns “Clock separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C054-T05 · Handoff implementation:** Connect “Clock separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Replay does not accidentally replace real security clocks” across the handoff.
- [ ] **UC-M10.06-C054-T06 · Absent-input case:** Omit one required “Clock separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C054-T07 · Stale-input case:** Supply an outdated “Clock separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Clock separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C054-T09 · Valid integration trace:** Run a valid “Clock separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C054-T10 · Seam review:** Reconcile the “Clock separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clock separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clock separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C055-T02 · Expected-result oracle:** Specify the “Clock separation” expected result independently of the implementation output; include the property “Replay does not accidentally replace real security clocks” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C055-T03 · Fixture material:** Create the concrete “Clock separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C055-T04 · Target preparation:** Prepare the “Clock separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C055-T05 · Initial-state record:** Record the initial “Clock separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C055-T06 · Valid-path execution:** Execute the “Clock separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C055-T07 · Outcome comparison:** Compare every declared “Clock separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C055-T08 · State and bounds check:** Inspect the “Clock separation” ownership/state effects and actual use of “Clock events and conversion range”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C055-T09 · Repeatability check:** Repeat the same “Clock separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C055-T10 · Positive evidence:** Attach the “Clock separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C056 · Negative test

**Original checklist item:** Negative case: A debugger restores a simulated timestamp as live credential time. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Clock separation” source counterexample: “A debugger restores a simulated timestamp as live credential time”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Clock separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C056-T03 · Valid control:** Construct a valid “Clock separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C056-T04 · Minimal adverse input:** Derive the “Clock separation” adverse fixture from the control with the smallest documented change needed to reproduce “A debugger restores a simulated timestamp as live credential time”; retain that change as reproducible data.
- [ ] **UC-M10.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clock separation”; require “Replay does not accidentally replace real security clocks” and forbid a false-success verdict.
- [ ] **UC-M10.06-C056-T06 · Adverse execution:** Exercise the “Clock separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C056-T07 · Effect inspection:** Inspect “Clock separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C056-T08 · Refusal versus failure:** Confirm the “Clock separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C056-T09 · Reset and retention:** Restore only the disposable “Clock separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C056-T10 · Negative regression:** Register the “Clock separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C057 · Change / failure test

**Original checklist item:** Exercise clock separation when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C057-T01 · Scenario record:** Write the “Clock separation” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Replay does not accidentally replace real security clocks”.
- [ ] **UC-M10.06-C057-T02 · Baseline capture:** Create a known-valid “Clock separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C057-T03 · Injection map:** Locate the “Clock separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Clock separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C057-T05 · Controlled trigger:** Introduce the controlled “Clock separation” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C057-T06 · Intermediate inspection:** Inspect the “Clock separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clock separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Clock separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C057-T09 · Repeat and compare:** Repeat the selected “Clock separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C057-T10 · Failure evidence:** Publish the “Clock separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for clock events and conversion range; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Clock separation”: “Clock events and conversion range”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C058-T02 · Measurement method:** Choose how to observe each “Clock separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C058-T03 · Budget decision:** Select justified resource and input limits for “Clock separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clock separation” cases for “Clock events and conversion range”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clock separation” limit; preserve “Replay does not accidentally replace real security clocks”.
- [ ] **UC-M10.06-C058-T06 · Normal measurement:** Run or review the normal “Clock separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C058-T07 · At-limit measurement:** Exercise the “Clock separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C058-T08 · Over-limit measurement:** Exercise the “Clock separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C058-T09 · Uncovered-scope report:** List the “Clock separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C058-T10 · Limit evidence:** Publish the selected “Clock separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clock separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C059-T01 · Event inventory:** List the “Clock separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Clock separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C059-T03 · Failure mapping:** Map each documented “Clock separation” refusal or error to a diagnostic outcome; include “A debugger restores a simulated timestamp as live credential time” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C059-T04 · Emission path:** Add the “Clock separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C059-T05 · Redaction check:** Test “Clock separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C059-T06 · Output budget:** Set and exercise bounded “Clock separation” message size, rate and retention compatible with “Clock events and conversion range”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C059-T07 · Success/refusal fixtures:** Capture “Clock separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clock separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C059-T09 · Operator review:** Read the “Clock separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C059-T10 · Diagnostic evidence:** Publish redacted “Clock separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clock separation; label unexecuted checks as untested.

- [ ] **UC-M10.06-C060-T01 · Evidence inventory:** List the “Clock separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C060-T02 · Artifact references:** Record the exact “Clock separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C060-T03 · Fixture references:** Attach the “Clock separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A debugger restores a simulated timestamp as live credential time” as a distinct evidence case.
- [ ] **UC-M10.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clock separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C060-T05 · Environment record:** Record the actual “Clock separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C060-T06 · Expected versus observed:** Pair every “Clock separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C060-T07 · Failure and limit records:** Attach “Clock separation” change/failure and bounds evidence where required; include uncovered “Clock events and conversion range” and unresolved violations of “Replay does not accidentally replace real security clocks”.
- [ ] **UC-M10.06-C060-T08 · Evidence hygiene:** Check the “Clock separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C060-T09 · Reproduction review:** Have the “Clock separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C060-T10 · Acceptance linkage:** Link the “Clock separation” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Nondeterminism detection

**Source delivery:** Flag missing inputs or observed divergence from the replay contract.

**Source invariant:** Unrecorded nondeterminism is not concealed as a successful reproduction.

**Source negative case:** A live clock read changes the result but the replay reports equivalent.

**Source bounded quantities:** Divergence records and comparison cost.

### UC-M10.06-C061 · Contract

**Original checklist item:** Specify nondeterminism detection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C061-T01 · Scope statement:** Draft the operation boundary for “Nondeterminism detection” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Nondeterminism detection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C061-T03 · Output inventory:** List the outputs of “Nondeterminism detection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Nondeterminism detection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C061-T05 · Prerequisite contract:** Map “Nondeterminism detection” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Nondeterminism detection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C061-T07 · Invariant clause:** Add a normative clause for “Nondeterminism detection” that preserves “Unrecorded nondeterminism is not concealed as a successful reproduction”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Nondeterminism detection”; include the source counterexample “A live clock read changes the result but the replay reports equivalent” and the intended safe disposition.
- [ ] **UC-M10.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Divergence records and comparison cost” in the “Nondeterminism detection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C061-T10 · Contract review:** Review the “Nondeterminism detection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C062 · Delivery

**Original checklist item:** Flag missing inputs or observed divergence from the replay contract.

- [ ] **UC-M10.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Nondeterminism detection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C062-T02 · Change plan:** Break the source delivery for “Nondeterminism detection” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Nondeterminism detection” that realizes this source instruction: Flag missing inputs or observed divergence from the replay contract.
- [ ] **UC-M10.06-C062-T04 · Concrete realization:** Trace “Nondeterminism detection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Nondeterminism detection” needed to preserve “Unrecorded nondeterminism is not concealed as a successful reproduction”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C062-T06 · Dependency connection:** Connect the “Nondeterminism detection” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C062-T07 · Resource behavior:** Account for “Divergence records and comparison cost” in “Nondeterminism detection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C062-T08 · Delivery check:** Run the smallest real “Nondeterminism detection” path and its adverse fixture “A live clock read changes the result but the replay reports equivalent”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C062-T09 · Patch review:** Review the “Nondeterminism detection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C062-T10 · Delivery handoff:** Publish the “Nondeterminism detection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unrecorded nondeterminism is not concealed as a successful reproduction. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Nondeterminism detection”; copy its required invariant exactly: “Unrecorded nondeterminism is not concealed as a successful reproduction”.
- [ ] **UC-M10.06-C063-T02 · Observable terms:** Define each term in the “Nondeterminism detection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C063-T03 · Precondition set:** List the preconditions under which “Unrecorded nondeterminism is not concealed as a successful reproduction” must hold for “Nondeterminism detection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C063-T04 · Transition coverage:** Map the “Nondeterminism detection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Nondeterminism detection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C063-T06 · Satisfying fixture:** Create a concrete “Nondeterminism detection” case that satisfies “Unrecorded nondeterminism is not concealed as a successful reproduction”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C063-T07 · Violating fixture:** Create the source counterexample “A live clock read changes the result but the replay reports equivalent” for “Nondeterminism detection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C063-T08 · Enforcement evidence:** Exercise the “Nondeterminism detection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C063-T09 · Regression linkage:** Link the “Nondeterminism detection” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Nondeterminism detection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C064 · Integration

**Original checklist item:** Integrate nondeterminism detection with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Nondeterminism detection” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C064-T02 · Field mapping:** Map every “Nondeterminism detection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Nondeterminism detection” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C064-T04 · Ownership agreement:** Specify who owns “Nondeterminism detection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C064-T05 · Handoff implementation:** Connect “Nondeterminism detection” through the mapped seam using the real adapter or explicit specification reference; preserve “Unrecorded nondeterminism is not concealed as a successful reproduction” across the handoff.
- [ ] **UC-M10.06-C064-T06 · Absent-input case:** Omit one required “Nondeterminism detection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C064-T07 · Stale-input case:** Supply an outdated “Nondeterminism detection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Nondeterminism detection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C064-T09 · Valid integration trace:** Run a valid “Nondeterminism detection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C064-T10 · Seam review:** Reconcile the “Nondeterminism detection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for nondeterminism detection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Nondeterminism detection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C065-T02 · Expected-result oracle:** Specify the “Nondeterminism detection” expected result independently of the implementation output; include the property “Unrecorded nondeterminism is not concealed as a successful reproduction” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C065-T03 · Fixture material:** Create the concrete “Nondeterminism detection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C065-T04 · Target preparation:** Prepare the “Nondeterminism detection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C065-T05 · Initial-state record:** Record the initial “Nondeterminism detection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C065-T06 · Valid-path execution:** Execute the “Nondeterminism detection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C065-T07 · Outcome comparison:** Compare every declared “Nondeterminism detection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C065-T08 · State and bounds check:** Inspect the “Nondeterminism detection” ownership/state effects and actual use of “Divergence records and comparison cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C065-T09 · Repeatability check:** Repeat the same “Nondeterminism detection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C065-T10 · Positive evidence:** Attach the “Nondeterminism detection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C066 · Negative test

**Original checklist item:** Negative case: A live clock read changes the result but the replay reports equivalent. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Nondeterminism detection” source counterexample: “A live clock read changes the result but the replay reports equivalent”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Nondeterminism detection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C066-T03 · Valid control:** Construct a valid “Nondeterminism detection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C066-T04 · Minimal adverse input:** Derive the “Nondeterminism detection” adverse fixture from the control with the smallest documented change needed to reproduce “A live clock read changes the result but the replay reports equivalent”; retain that change as reproducible data.
- [ ] **UC-M10.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Nondeterminism detection”; require “Unrecorded nondeterminism is not concealed as a successful reproduction” and forbid a false-success verdict.
- [ ] **UC-M10.06-C066-T06 · Adverse execution:** Exercise the “Nondeterminism detection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C066-T07 · Effect inspection:** Inspect “Nondeterminism detection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C066-T08 · Refusal versus failure:** Confirm the “Nondeterminism detection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C066-T09 · Reset and retention:** Restore only the disposable “Nondeterminism detection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C066-T10 · Negative regression:** Register the “Nondeterminism detection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C067 · Change / failure test

**Original checklist item:** Exercise nondeterminism detection when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C067-T01 · Scenario record:** Write the “Nondeterminism detection” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Unrecorded nondeterminism is not concealed as a successful reproduction”.
- [ ] **UC-M10.06-C067-T02 · Baseline capture:** Create a known-valid “Nondeterminism detection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C067-T03 · Injection map:** Locate the “Nondeterminism detection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Nondeterminism detection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C067-T05 · Controlled trigger:** Introduce the controlled “Nondeterminism detection” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C067-T06 · Intermediate inspection:** Inspect the “Nondeterminism detection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Nondeterminism detection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Nondeterminism detection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C067-T09 · Repeat and compare:** Repeat the selected “Nondeterminism detection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C067-T10 · Failure evidence:** Publish the “Nondeterminism detection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for divergence records and comparison cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Nondeterminism detection”: “Divergence records and comparison cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C068-T02 · Measurement method:** Choose how to observe each “Nondeterminism detection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Nondeterminism detection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Nondeterminism detection” cases for “Divergence records and comparison cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Nondeterminism detection” limit; preserve “Unrecorded nondeterminism is not concealed as a successful reproduction”.
- [ ] **UC-M10.06-C068-T06 · Normal measurement:** Run or review the normal “Nondeterminism detection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C068-T07 · At-limit measurement:** Exercise the “Nondeterminism detection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C068-T08 · Over-limit measurement:** Exercise the “Nondeterminism detection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C068-T09 · Uncovered-scope report:** List the “Nondeterminism detection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C068-T10 · Limit evidence:** Publish the selected “Nondeterminism detection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for nondeterminism detection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C069-T01 · Event inventory:** List the “Nondeterminism detection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Nondeterminism detection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C069-T03 · Failure mapping:** Map each documented “Nondeterminism detection” refusal or error to a diagnostic outcome; include “A live clock read changes the result but the replay reports equivalent” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C069-T04 · Emission path:** Add the “Nondeterminism detection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C069-T05 · Redaction check:** Test “Nondeterminism detection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C069-T06 · Output budget:** Set and exercise bounded “Nondeterminism detection” message size, rate and retention compatible with “Divergence records and comparison cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C069-T07 · Success/refusal fixtures:** Capture “Nondeterminism detection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Nondeterminism detection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C069-T09 · Operator review:** Read the “Nondeterminism detection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C069-T10 · Diagnostic evidence:** Publish redacted “Nondeterminism detection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for nondeterminism detection; label unexecuted checks as untested.

- [ ] **UC-M10.06-C070-T01 · Evidence inventory:** List the “Nondeterminism detection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C070-T02 · Artifact references:** Record the exact “Nondeterminism detection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C070-T03 · Fixture references:** Attach the “Nondeterminism detection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A live clock read changes the result but the replay reports equivalent” as a distinct evidence case.
- [ ] **UC-M10.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Nondeterminism detection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C070-T05 · Environment record:** Record the actual “Nondeterminism detection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C070-T06 · Expected versus observed:** Pair every “Nondeterminism detection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C070-T07 · Failure and limit records:** Attach “Nondeterminism detection” change/failure and bounds evidence where required; include uncovered “Divergence records and comparison cost” and unresolved violations of “Unrecorded nondeterminism is not concealed as a successful reproduction”.
- [ ] **UC-M10.06-C070-T08 · Evidence hygiene:** Check the “Nondeterminism detection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C070-T09 · Reproduction review:** Have the “Nondeterminism detection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C070-T10 · Acceptance linkage:** Link the “Nondeterminism detection” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Debug authority

**Source delivery:** Restrict inspection and mutation controls to authorized scope.

**Source invariant:** Debugger access cannot expose another tenant's secret or state.

**Source negative case:** A debug handle inspects a different tenant's guest.

**Source bounded quantities:** Debug sessions and accessible state bytes.

### UC-M10.06-C071 · Contract

**Original checklist item:** Specify debug authority inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C071-T01 · Scope statement:** Draft the operation boundary for “Debug authority” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Debug authority”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C071-T03 · Output inventory:** List the outputs of “Debug authority” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Debug authority”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C071-T05 · Prerequisite contract:** Map “Debug authority” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Debug authority”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C071-T07 · Invariant clause:** Add a normative clause for “Debug authority” that preserves “Debugger access cannot expose another tenant's secret or state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Debug authority”; include the source counterexample “A debug handle inspects a different tenant's guest” and the intended safe disposition.
- [ ] **UC-M10.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Debug sessions and accessible state bytes” in the “Debug authority” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C071-T10 · Contract review:** Review the “Debug authority” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C072 · Delivery

**Original checklist item:** Restrict inspection and mutation controls to authorized scope.

- [ ] **UC-M10.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Debug authority”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C072-T02 · Change plan:** Break the source delivery for “Debug authority” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Debug authority” that realizes this source instruction: Restrict inspection and mutation controls to authorized scope.
- [ ] **UC-M10.06-C072-T04 · Concrete realization:** Trace “Debug authority” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Debug authority” needed to preserve “Debugger access cannot expose another tenant's secret or state”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C072-T06 · Dependency connection:** Connect the “Debug authority” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C072-T07 · Resource behavior:** Account for “Debug sessions and accessible state bytes” in “Debug authority”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C072-T08 · Delivery check:** Run the smallest real “Debug authority” path and its adverse fixture “A debug handle inspects a different tenant's guest”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C072-T09 · Patch review:** Review the “Debug authority” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C072-T10 · Delivery handoff:** Publish the “Debug authority” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Debugger access cannot expose another tenant's secret or state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Debug authority”; copy its required invariant exactly: “Debugger access cannot expose another tenant's secret or state”.
- [ ] **UC-M10.06-C073-T02 · Observable terms:** Define each term in the “Debug authority” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C073-T03 · Precondition set:** List the preconditions under which “Debugger access cannot expose another tenant's secret or state” must hold for “Debug authority”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C073-T04 · Transition coverage:** Map the “Debug authority” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Debug authority”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C073-T06 · Satisfying fixture:** Create a concrete “Debug authority” case that satisfies “Debugger access cannot expose another tenant's secret or state”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C073-T07 · Violating fixture:** Create the source counterexample “A debug handle inspects a different tenant's guest” for “Debug authority”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C073-T08 · Enforcement evidence:** Exercise the “Debug authority” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C073-T09 · Regression linkage:** Link the “Debug authority” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Debug authority” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C074 · Integration

**Original checklist item:** Integrate debug authority with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Debug authority” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C074-T02 · Field mapping:** Map every “Debug authority” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Debug authority” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C074-T04 · Ownership agreement:** Specify who owns “Debug authority” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C074-T05 · Handoff implementation:** Connect “Debug authority” through the mapped seam using the real adapter or explicit specification reference; preserve “Debugger access cannot expose another tenant's secret or state” across the handoff.
- [ ] **UC-M10.06-C074-T06 · Absent-input case:** Omit one required “Debug authority” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C074-T07 · Stale-input case:** Supply an outdated “Debug authority” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Debug authority” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C074-T09 · Valid integration trace:** Run a valid “Debug authority” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C074-T10 · Seam review:** Reconcile the “Debug authority” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for debug authority; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Debug authority” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C075-T02 · Expected-result oracle:** Specify the “Debug authority” expected result independently of the implementation output; include the property “Debugger access cannot expose another tenant's secret or state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C075-T03 · Fixture material:** Create the concrete “Debug authority” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C075-T04 · Target preparation:** Prepare the “Debug authority” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C075-T05 · Initial-state record:** Record the initial “Debug authority” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C075-T06 · Valid-path execution:** Execute the “Debug authority” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C075-T07 · Outcome comparison:** Compare every declared “Debug authority” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C075-T08 · State and bounds check:** Inspect the “Debug authority” ownership/state effects and actual use of “Debug sessions and accessible state bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C075-T09 · Repeatability check:** Repeat the same “Debug authority” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C075-T10 · Positive evidence:** Attach the “Debug authority” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C076 · Negative test

**Original checklist item:** Negative case: A debug handle inspects a different tenant's guest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Debug authority” source counterexample: “A debug handle inspects a different tenant's guest”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Debug authority”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C076-T03 · Valid control:** Construct a valid “Debug authority” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C076-T04 · Minimal adverse input:** Derive the “Debug authority” adverse fixture from the control with the smallest documented change needed to reproduce “A debug handle inspects a different tenant's guest”; retain that change as reproducible data.
- [ ] **UC-M10.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Debug authority”; require “Debugger access cannot expose another tenant's secret or state” and forbid a false-success verdict.
- [ ] **UC-M10.06-C076-T06 · Adverse execution:** Exercise the “Debug authority” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C076-T07 · Effect inspection:** Inspect “Debug authority” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C076-T08 · Refusal versus failure:** Confirm the “Debug authority” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C076-T09 · Reset and retention:** Restore only the disposable “Debug authority” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C076-T10 · Negative regression:** Register the “Debug authority” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C077 · Change / failure test

**Original checklist item:** Exercise debug authority when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C077-T01 · Scenario record:** Write the “Debug authority” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Debugger access cannot expose another tenant's secret or state”.
- [ ] **UC-M10.06-C077-T02 · Baseline capture:** Create a known-valid “Debug authority” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C077-T03 · Injection map:** Locate the “Debug authority” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Debug authority” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C077-T05 · Controlled trigger:** Introduce the controlled “Debug authority” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C077-T06 · Intermediate inspection:** Inspect the “Debug authority” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Debug authority”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Debug authority” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C077-T09 · Repeat and compare:** Repeat the selected “Debug authority” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C077-T10 · Failure evidence:** Publish the “Debug authority” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for debug sessions and accessible state bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Debug authority”: “Debug sessions and accessible state bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C078-T02 · Measurement method:** Choose how to observe each “Debug authority” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C078-T03 · Budget decision:** Select justified resource and input limits for “Debug authority”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Debug authority” cases for “Debug sessions and accessible state bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Debug authority” limit; preserve “Debugger access cannot expose another tenant's secret or state”.
- [ ] **UC-M10.06-C078-T06 · Normal measurement:** Run or review the normal “Debug authority” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C078-T07 · At-limit measurement:** Exercise the “Debug authority” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C078-T08 · Over-limit measurement:** Exercise the “Debug authority” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C078-T09 · Uncovered-scope report:** List the “Debug authority” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C078-T10 · Limit evidence:** Publish the selected “Debug authority” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for debug authority with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C079-T01 · Event inventory:** List the “Debug authority” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Debug authority” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C079-T03 · Failure mapping:** Map each documented “Debug authority” refusal or error to a diagnostic outcome; include “A debug handle inspects a different tenant's guest” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C079-T04 · Emission path:** Add the “Debug authority” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C079-T05 · Redaction check:** Test “Debug authority” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C079-T06 · Output budget:** Set and exercise bounded “Debug authority” message size, rate and retention compatible with “Debug sessions and accessible state bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C079-T07 · Success/refusal fixtures:** Capture “Debug authority” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Debug authority” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C079-T09 · Operator review:** Read the “Debug authority” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C079-T10 · Diagnostic evidence:** Publish redacted “Debug authority” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for debug authority; label unexecuted checks as untested.

- [ ] **UC-M10.06-C080-T01 · Evidence inventory:** List the “Debug authority” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C080-T02 · Artifact references:** Record the exact “Debug authority” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C080-T03 · Fixture references:** Attach the “Debug authority” fixture IDs, input identities and oracle definition; preserve the source counterexample “A debug handle inspects a different tenant's guest” as a distinct evidence case.
- [ ] **UC-M10.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Debug authority”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C080-T05 · Environment record:** Record the actual “Debug authority” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C080-T06 · Expected versus observed:** Pair every “Debug authority” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C080-T07 · Failure and limit records:** Attach “Debug authority” change/failure and bounds evidence where required; include uncovered “Debug sessions and accessible state bytes” and unresolved violations of “Debugger access cannot expose another tenant's secret or state”.
- [ ] **UC-M10.06-C080-T08 · Evidence hygiene:** Check the “Debug authority” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C080-T09 · Reproduction review:** Have the “Debug authority” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C080-T10 · Acceptance linkage:** Link the “Debug authority” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Bounded recording

**Source delivery:** Limit traces and recorded state while documenting replay truncation.

**Source invariant:** A truncated recording cannot claim complete reproducibility.

**Source negative case:** Recording stops at a cap but the UI claims a full replay history.

**Source bounded quantities:** Recording bytes and retained checkpoints.

### UC-M10.06-C081 · Contract

**Original checklist item:** Specify bounded recording inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C081-T01 · Scope statement:** Draft the operation boundary for “Bounded recording” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Bounded recording”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C081-T03 · Output inventory:** List the outputs of “Bounded recording” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Bounded recording”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C081-T05 · Prerequisite contract:** Map “Bounded recording” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Bounded recording”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C081-T07 · Invariant clause:** Add a normative clause for “Bounded recording” that preserves “A truncated recording cannot claim complete reproducibility”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Bounded recording”; include the source counterexample “Recording stops at a cap but the UI claims a full replay history” and the intended safe disposition.
- [ ] **UC-M10.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recording bytes and retained checkpoints” in the “Bounded recording” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C081-T10 · Contract review:** Review the “Bounded recording” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C082 · Delivery

**Original checklist item:** Limit traces and recorded state while documenting replay truncation.

- [ ] **UC-M10.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Bounded recording”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C082-T02 · Change plan:** Break the source delivery for “Bounded recording” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Bounded recording” that realizes this source instruction: Limit traces and recorded state while documenting replay truncation.
- [ ] **UC-M10.06-C082-T04 · Concrete realization:** Trace “Bounded recording” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Bounded recording” needed to preserve “A truncated recording cannot claim complete reproducibility”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C082-T06 · Dependency connection:** Connect the “Bounded recording” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C082-T07 · Resource behavior:** Account for “Recording bytes and retained checkpoints” in “Bounded recording”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C082-T08 · Delivery check:** Run the smallest real “Bounded recording” path and its adverse fixture “Recording stops at a cap but the UI claims a full replay history”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C082-T09 · Patch review:** Review the “Bounded recording” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C082-T10 · Delivery handoff:** Publish the “Bounded recording” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A truncated recording cannot claim complete reproducibility. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Bounded recording”; copy its required invariant exactly: “A truncated recording cannot claim complete reproducibility”.
- [ ] **UC-M10.06-C083-T02 · Observable terms:** Define each term in the “Bounded recording” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C083-T03 · Precondition set:** List the preconditions under which “A truncated recording cannot claim complete reproducibility” must hold for “Bounded recording”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C083-T04 · Transition coverage:** Map the “Bounded recording” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Bounded recording”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C083-T06 · Satisfying fixture:** Create a concrete “Bounded recording” case that satisfies “A truncated recording cannot claim complete reproducibility”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C083-T07 · Violating fixture:** Create the source counterexample “Recording stops at a cap but the UI claims a full replay history” for “Bounded recording”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C083-T08 · Enforcement evidence:** Exercise the “Bounded recording” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C083-T09 · Regression linkage:** Link the “Bounded recording” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Bounded recording” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C084 · Integration

**Original checklist item:** Integrate bounded recording with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Bounded recording” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C084-T02 · Field mapping:** Map every “Bounded recording” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Bounded recording” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C084-T04 · Ownership agreement:** Specify who owns “Bounded recording” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C084-T05 · Handoff implementation:** Connect “Bounded recording” through the mapped seam using the real adapter or explicit specification reference; preserve “A truncated recording cannot claim complete reproducibility” across the handoff.
- [ ] **UC-M10.06-C084-T06 · Absent-input case:** Omit one required “Bounded recording” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C084-T07 · Stale-input case:** Supply an outdated “Bounded recording” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Bounded recording” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C084-T09 · Valid integration trace:** Run a valid “Bounded recording” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C084-T10 · Seam review:** Reconcile the “Bounded recording” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for bounded recording; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Bounded recording” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C085-T02 · Expected-result oracle:** Specify the “Bounded recording” expected result independently of the implementation output; include the property “A truncated recording cannot claim complete reproducibility” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C085-T03 · Fixture material:** Create the concrete “Bounded recording” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C085-T04 · Target preparation:** Prepare the “Bounded recording” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C085-T05 · Initial-state record:** Record the initial “Bounded recording” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C085-T06 · Valid-path execution:** Execute the “Bounded recording” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C085-T07 · Outcome comparison:** Compare every declared “Bounded recording” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C085-T08 · State and bounds check:** Inspect the “Bounded recording” ownership/state effects and actual use of “Recording bytes and retained checkpoints”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C085-T09 · Repeatability check:** Repeat the same “Bounded recording” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C085-T10 · Positive evidence:** Attach the “Bounded recording” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C086 · Negative test

**Original checklist item:** Negative case: Recording stops at a cap but the UI claims a full replay history. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Bounded recording” source counterexample: “Recording stops at a cap but the UI claims a full replay history”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Bounded recording”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C086-T03 · Valid control:** Construct a valid “Bounded recording” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C086-T04 · Minimal adverse input:** Derive the “Bounded recording” adverse fixture from the control with the smallest documented change needed to reproduce “Recording stops at a cap but the UI claims a full replay history”; retain that change as reproducible data.
- [ ] **UC-M10.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Bounded recording”; require “A truncated recording cannot claim complete reproducibility” and forbid a false-success verdict.
- [ ] **UC-M10.06-C086-T06 · Adverse execution:** Exercise the “Bounded recording” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C086-T07 · Effect inspection:** Inspect “Bounded recording” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C086-T08 · Refusal versus failure:** Confirm the “Bounded recording” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C086-T09 · Reset and retention:** Restore only the disposable “Bounded recording” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C086-T10 · Negative regression:** Register the “Bounded recording” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C087 · Change / failure test

**Original checklist item:** Exercise bounded recording when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C087-T01 · Scenario record:** Write the “Bounded recording” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “A truncated recording cannot claim complete reproducibility”.
- [ ] **UC-M10.06-C087-T02 · Baseline capture:** Create a known-valid “Bounded recording” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C087-T03 · Injection map:** Locate the “Bounded recording” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Bounded recording” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C087-T05 · Controlled trigger:** Introduce the controlled “Bounded recording” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C087-T06 · Intermediate inspection:** Inspect the “Bounded recording” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Bounded recording”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Bounded recording” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C087-T09 · Repeat and compare:** Repeat the selected “Bounded recording” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C087-T10 · Failure evidence:** Publish the “Bounded recording” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for recording bytes and retained checkpoints; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Bounded recording”: “Recording bytes and retained checkpoints”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C088-T02 · Measurement method:** Choose how to observe each “Bounded recording” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Bounded recording”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Bounded recording” cases for “Recording bytes and retained checkpoints”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Bounded recording” limit; preserve “A truncated recording cannot claim complete reproducibility”.
- [ ] **UC-M10.06-C088-T06 · Normal measurement:** Run or review the normal “Bounded recording” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C088-T07 · At-limit measurement:** Exercise the “Bounded recording” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C088-T08 · Over-limit measurement:** Exercise the “Bounded recording” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C088-T09 · Uncovered-scope report:** List the “Bounded recording” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C088-T10 · Limit evidence:** Publish the selected “Bounded recording” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for bounded recording with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C089-T01 · Event inventory:** List the “Bounded recording” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Bounded recording” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C089-T03 · Failure mapping:** Map each documented “Bounded recording” refusal or error to a diagnostic outcome; include “Recording stops at a cap but the UI claims a full replay history” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C089-T04 · Emission path:** Add the “Bounded recording” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C089-T05 · Redaction check:** Test “Bounded recording” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C089-T06 · Output budget:** Set and exercise bounded “Bounded recording” message size, rate and retention compatible with “Recording bytes and retained checkpoints”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C089-T07 · Success/refusal fixtures:** Capture “Bounded recording” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Bounded recording” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C089-T09 · Operator review:** Read the “Bounded recording” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C089-T10 · Diagnostic evidence:** Publish redacted “Bounded recording” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for bounded recording; label unexecuted checks as untested.

- [ ] **UC-M10.06-C090-T01 · Evidence inventory:** List the “Bounded recording” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C090-T02 · Artifact references:** Record the exact “Bounded recording” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C090-T03 · Fixture references:** Attach the “Bounded recording” fixture IDs, input identities and oracle definition; preserve the source counterexample “Recording stops at a cap but the UI claims a full replay history” as a distinct evidence case.
- [ ] **UC-M10.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Bounded recording”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C090-T05 · Environment record:** Record the actual “Bounded recording” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C090-T06 · Expected versus observed:** Pair every “Bounded recording” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C090-T07 · Failure and limit records:** Attach “Bounded recording” change/failure and bounds evidence where required; include uncovered “Recording bytes and retained checkpoints” and unresolved violations of “A truncated recording cannot claim complete reproducibility”.
- [ ] **UC-M10.06-C090-T08 · Evidence hygiene:** Check the “Bounded recording” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C090-T09 · Reproduction review:** Have the “Bounded recording” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C090-T10 · Acceptance linkage:** Link the “Bounded recording” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Replay qualification

**Source delivery:** Reproduce a recorded deterministic failure and compare observable state.

**Source invariant:** Reproduction evidence includes exact input, image and state identity.

**Source negative case:** Only the same error message is compared while state differs.

**Source bounded quantities:** Replay repetitions and state comparison bytes.

### UC-M10.06-C091 · Contract

**Original checklist item:** Specify replay qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.06-C091-T01 · Scope statement:** Draft the operation boundary for “Replay qualification” within Replay and interactive debugger; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Replay qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.06-C091-T03 · Output inventory:** List the outputs of “Replay qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Replay qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.06-C091-T05 · Prerequisite contract:** Map “Replay qualification” to the source component prerequisites (UC-M02.08, UC-M08.04, UC-M10.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Replay qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.06-C091-T07 · Invariant clause:** Add a normative clause for “Replay qualification” that preserves “Reproduction evidence includes exact input, image and state identity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Replay qualification”; include the source counterexample “Only the same error message is compared while state differs” and the intended safe disposition.
- [ ] **UC-M10.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Replay repetitions and state comparison bytes” in the “Replay qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.06-C091-T10 · Contract review:** Review the “Replay qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.06-C092 · Delivery

**Original checklist item:** Reproduce a recorded deterministic failure and compare observable state.

- [ ] **UC-M10.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Replay qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.06-C092-T02 · Change plan:** Break the source delivery for “Replay qualification” into concrete edit targets and reviewable outputs; keep the UC-M10.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.06-C092-T03 · Core artifact:** Create the “Replay qualification” fixture or harness for this source instruction: Reproduce a recorded deterministic failure and compare observable state.
- [ ] **UC-M10.06-C092-T04 · Concrete realization:** Connect the “Replay qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Replay qualification” needed to preserve “Reproduction evidence includes exact input, image and state identity”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.06-C092-T06 · Dependency connection:** Connect the “Replay qualification” implementation to source maps, recorded deterministic inputs and verified checkpoint restore; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.06-C092-T07 · Resource behavior:** Account for “Replay repetitions and state comparison bytes” in “Replay qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.06-C092-T08 · Delivery check:** Run the smallest real “Replay qualification” path and its adverse fixture “Only the same error message is compared while state differs”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.06-C092-T09 · Patch review:** Review the “Replay qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.06-C092-T10 · Delivery handoff:** Publish the “Replay qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Reproduction evidence includes exact input, image and state identity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Replay qualification”; copy its required invariant exactly: “Reproduction evidence includes exact input, image and state identity”.
- [ ] **UC-M10.06-C093-T02 · Observable terms:** Define each term in the “Replay qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.06-C093-T03 · Precondition set:** List the preconditions under which “Reproduction evidence includes exact input, image and state identity” must hold for “Replay qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.06-C093-T04 · Transition coverage:** Map the “Replay qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Replay qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.06-C093-T06 · Satisfying fixture:** Create a concrete “Replay qualification” case that satisfies “Reproduction evidence includes exact input, image and state identity”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.06-C093-T07 · Violating fixture:** Create the source counterexample “Only the same error message is compared while state differs” for “Replay qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.06-C093-T08 · Enforcement evidence:** Exercise the “Replay qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.06-C093-T09 · Regression linkage:** Link the “Replay qualification” property to changes in source maps, recorded deterministic inputs and verified checkpoint restore; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Replay qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.06-C094 · Integration

**Original checklist item:** Integrate replay qualification with source maps, recorded deterministic inputs and verified checkpoint restore; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Replay qualification” across source maps, recorded deterministic inputs and verified checkpoint restore; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.06-C094-T02 · Field mapping:** Map every “Replay qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Replay qualification” (source dependency list: UC-M02.08, UC-M08.04, UC-M10.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.06-C094-T04 · Ownership agreement:** Specify who owns “Replay qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.06-C094-T05 · Handoff implementation:** Connect “Replay qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Reproduction evidence includes exact input, image and state identity” across the handoff.
- [ ] **UC-M10.06-C094-T06 · Absent-input case:** Omit one required “Replay qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.06-C094-T07 · Stale-input case:** Supply an outdated “Replay qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Replay qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.06-C094-T09 · Valid integration trace:** Run a valid “Replay qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.06-C094-T10 · Seam review:** Reconcile the “Replay qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for replay qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Replay qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.06-C095-T02 · Expected-result oracle:** Specify the “Replay qualification” expected result independently of the implementation output; include the property “Reproduction evidence includes exact input, image and state identity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.06-C095-T03 · Fixture material:** Create the concrete “Replay qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.06-C095-T04 · Target preparation:** Prepare the “Replay qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.06-C095-T05 · Initial-state record:** Record the initial “Replay qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.06-C095-T06 · Valid-path execution:** Execute the “Replay qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.06-C095-T07 · Outcome comparison:** Compare every declared “Replay qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.06-C095-T08 · State and bounds check:** Inspect the “Replay qualification” ownership/state effects and actual use of “Replay repetitions and state comparison bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.06-C095-T09 · Repeatability check:** Repeat the same “Replay qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.06-C095-T10 · Positive evidence:** Attach the “Replay qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.06-C096 · Negative test

**Original checklist item:** Negative case: Only the same error message is compared while state differs. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Replay qualification” source counterexample: “Only the same error message is compared while state differs”; state which precondition or invariant it challenges.
- [ ] **UC-M10.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Replay qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.06-C096-T03 · Valid control:** Construct a valid “Replay qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.06-C096-T04 · Minimal adverse input:** Derive the “Replay qualification” adverse fixture from the control with the smallest documented change needed to reproduce “Only the same error message is compared while state differs”; retain that change as reproducible data.
- [ ] **UC-M10.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Replay qualification”; require “Reproduction evidence includes exact input, image and state identity” and forbid a false-success verdict.
- [ ] **UC-M10.06-C096-T06 · Adverse execution:** Exercise the “Replay qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.06-C096-T07 · Effect inspection:** Inspect “Replay qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.06-C096-T08 · Refusal versus failure:** Confirm the “Replay qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.06-C096-T09 · Reset and retention:** Restore only the disposable “Replay qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.06-C096-T10 · Negative regression:** Register the “Replay qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.06-C097 · Change / failure test

**Original checklist item:** Exercise replay qualification when replay encounters an unrecorded clock or external I/O dependency; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.06-C097-T01 · Scenario record:** Write the “Replay qualification” change/failure scenario exactly as supplied: replay encounters an unrecorded clock or external I/O dependency; identify the property that must remain true: “Reproduction evidence includes exact input, image and state identity”.
- [ ] **UC-M10.06-C097-T02 · Baseline capture:** Create a known-valid “Replay qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.06-C097-T03 · Injection map:** Locate the “Replay qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Replay qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.06-C097-T05 · Controlled trigger:** Introduce the controlled “Replay qualification” scenario in the disposable fixture: replay encounters an unrecorded clock or external I/O dependency; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.06-C097-T06 · Intermediate inspection:** Inspect the “Replay qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Replay qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Replay qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.06-C097-T09 · Repeat and compare:** Repeat the selected “Replay qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.06-C097-T10 · Failure evidence:** Publish the “Replay qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for replay repetitions and state comparison bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Replay qualification”: “Replay repetitions and state comparison bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.06-C098-T02 · Measurement method:** Choose how to observe each “Replay qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Replay qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Replay qualification” cases for “Replay repetitions and state comparison bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Replay qualification” limit; preserve “Reproduction evidence includes exact input, image and state identity”.
- [ ] **UC-M10.06-C098-T06 · Normal measurement:** Run or review the normal “Replay qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.06-C098-T07 · At-limit measurement:** Exercise the “Replay qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.06-C098-T08 · Over-limit measurement:** Exercise the “Replay qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.06-C098-T09 · Uncovered-scope report:** List the “Replay qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.06-C098-T10 · Limit evidence:** Publish the selected “Replay qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for replay qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.06-C099-T01 · Event inventory:** List the “Replay qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Replay qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.06-C099-T03 · Failure mapping:** Map each documented “Replay qualification” refusal or error to a diagnostic outcome; include “Only the same error message is compared while state differs” and prohibit conversion into a success message.
- [ ] **UC-M10.06-C099-T04 · Emission path:** Add the “Replay qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.06-C099-T05 · Redaction check:** Test “Replay qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.06-C099-T06 · Output budget:** Set and exercise bounded “Replay qualification” message size, rate and retention compatible with “Replay repetitions and state comparison bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.06-C099-T07 · Success/refusal fixtures:** Capture “Replay qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Replay qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.06-C099-T09 · Operator review:** Read the “Replay qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.06-C099-T10 · Diagnostic evidence:** Publish redacted “Replay qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for replay qualification; label unexecuted checks as untested.

- [ ] **UC-M10.06-C100-T01 · Evidence inventory:** List the “Replay qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.06-C100-T02 · Artifact references:** Record the exact “Replay qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.06-C100-T03 · Fixture references:** Attach the “Replay qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only the same error message is compared while state differs” as a distinct evidence case.
- [ ] **UC-M10.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Replay qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.06-C100-T05 · Environment record:** Record the actual “Replay qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.06-C100-T06 · Expected versus observed:** Pair every “Replay qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.06-C100-T07 · Failure and limit records:** Attach “Replay qualification” change/failure and bounds evidence where required; include uncovered “Replay repetitions and state comparison bytes” and unresolved violations of “Reproduction evidence includes exact input, image and state identity”.
- [ ] **UC-M10.06-C100-T08 · Evidence hygiene:** Check the “Replay qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.06-C100-T09 · Reproduction review:** Have the “Replay qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.06-C100-T10 · Acceptance linkage:** Link the “Replay qualification” evidence to its parent and UC-M10.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

