# UC-M10.02 — Resource and latency metrics

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/10.md)

| Field | Preserved source value |
|---|---|
| Workstream | 10. Observability and operator experience |
| Milestone | C |
| Priority | P1 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.05](../03/UC-M03.05.md), [UC-M05.03](../05/UC-M05.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4]. |

## Original requirement

Measure actual boot, queue, execution, memory, I/O and storage costs per image/generation with bounded label cardinality.

**Original acceptance criterion:** Metrics reconcile with host observations and distinguish guest work from compiler, decoder and controller overhead.

**Source trace:** Original checklist `UC100/c/10/UC-M10.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 915–925 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Metric vocabulary

**Source delivery:** Define units and meanings for boot, queue, execution, memory, I/O and storage metrics.

**Source invariant:** Metrics measure distinct phases rather than combining unlike costs.

**Source negative case:** Build time is mislabeled as guest boot time.

**Source bounded quantities:** Metric count and schema size.

### UC-M10.02-C001 · Contract

**Original checklist item:** Specify metric vocabulary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C001-T01 · Scope statement:** Draft the operation boundary for “Metric vocabulary” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Metric vocabulary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C001-T03 · Output inventory:** List the outputs of “Metric vocabulary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Metric vocabulary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C001-T05 · Prerequisite contract:** Map “Metric vocabulary” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Metric vocabulary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C001-T07 · Invariant clause:** Add a normative clause for “Metric vocabulary” that preserves “Metrics measure distinct phases rather than combining unlike costs”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Metric vocabulary”; include the source counterexample “Build time is mislabeled as guest boot time” and the intended safe disposition.
- [ ] **UC-M10.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Metric count and schema size” in the “Metric vocabulary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C001-T10 · Contract review:** Review the “Metric vocabulary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C002 · Delivery

**Original checklist item:** Define units and meanings for boot, queue, execution, memory, I/O and storage metrics.

- [ ] **UC-M10.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Metric vocabulary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C002-T02 · Change plan:** Break the source delivery for “Metric vocabulary” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C002-T03 · Core artifact:** Create the “Metric vocabulary” model, schema or inventory that realizes this source instruction: Define units and meanings for boot, queue, execution, memory, I/O and storage metrics.
- [ ] **UC-M10.02-C002-T04 · Concrete realization:** Populate “Metric vocabulary” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M10.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Metric vocabulary” needed to preserve “Metrics measure distinct phases rather than combining unlike costs”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C002-T06 · Dependency connection:** Connect the “Metric vocabulary” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C002-T07 · Resource behavior:** Account for “Metric count and schema size” in “Metric vocabulary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C002-T08 · Delivery check:** Run the smallest real “Metric vocabulary” path and its adverse fixture “Build time is mislabeled as guest boot time”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C002-T09 · Patch review:** Review the “Metric vocabulary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C002-T10 · Delivery handoff:** Publish the “Metric vocabulary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Metrics measure distinct phases rather than combining unlike costs. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Metric vocabulary”; copy its required invariant exactly: “Metrics measure distinct phases rather than combining unlike costs”.
- [ ] **UC-M10.02-C003-T02 · Observable terms:** Define each term in the “Metric vocabulary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C003-T03 · Precondition set:** List the preconditions under which “Metrics measure distinct phases rather than combining unlike costs” must hold for “Metric vocabulary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C003-T04 · Transition coverage:** Map the “Metric vocabulary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Metric vocabulary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C003-T06 · Satisfying fixture:** Create a concrete “Metric vocabulary” case that satisfies “Metrics measure distinct phases rather than combining unlike costs”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C003-T07 · Violating fixture:** Create the source counterexample “Build time is mislabeled as guest boot time” for “Metric vocabulary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C003-T08 · Enforcement evidence:** Exercise the “Metric vocabulary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C003-T09 · Regression linkage:** Link the “Metric vocabulary” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Metric vocabulary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C004 · Integration

**Original checklist item:** Integrate metric vocabulary with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Metric vocabulary” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C004-T02 · Field mapping:** Map every “Metric vocabulary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Metric vocabulary” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C004-T04 · Ownership agreement:** Specify who owns “Metric vocabulary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C004-T05 · Handoff implementation:** Connect “Metric vocabulary” through the mapped seam using the real adapter or explicit specification reference; preserve “Metrics measure distinct phases rather than combining unlike costs” across the handoff.
- [ ] **UC-M10.02-C004-T06 · Absent-input case:** Omit one required “Metric vocabulary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C004-T07 · Stale-input case:** Supply an outdated “Metric vocabulary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Metric vocabulary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C004-T09 · Valid integration trace:** Run a valid “Metric vocabulary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C004-T10 · Seam review:** Reconcile the “Metric vocabulary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for metric vocabulary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Metric vocabulary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C005-T02 · Expected-result oracle:** Specify the “Metric vocabulary” expected result independently of the implementation output; include the property “Metrics measure distinct phases rather than combining unlike costs” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C005-T03 · Fixture material:** Create the concrete “Metric vocabulary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C005-T04 · Target preparation:** Prepare the “Metric vocabulary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C005-T05 · Initial-state record:** Record the initial “Metric vocabulary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C005-T06 · Valid-path execution:** Execute the “Metric vocabulary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C005-T07 · Outcome comparison:** Compare every declared “Metric vocabulary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C005-T08 · State and bounds check:** Inspect the “Metric vocabulary” ownership/state effects and actual use of “Metric count and schema size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C005-T09 · Repeatability check:** Repeat the same “Metric vocabulary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C005-T10 · Positive evidence:** Attach the “Metric vocabulary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C006 · Negative test

**Original checklist item:** Negative case: Build time is mislabeled as guest boot time. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Metric vocabulary” source counterexample: “Build time is mislabeled as guest boot time”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Metric vocabulary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C006-T03 · Valid control:** Construct a valid “Metric vocabulary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C006-T04 · Minimal adverse input:** Derive the “Metric vocabulary” adverse fixture from the control with the smallest documented change needed to reproduce “Build time is mislabeled as guest boot time”; retain that change as reproducible data.
- [ ] **UC-M10.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Metric vocabulary”; require “Metrics measure distinct phases rather than combining unlike costs” and forbid a false-success verdict.
- [ ] **UC-M10.02-C006-T06 · Adverse execution:** Exercise the “Metric vocabulary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C006-T07 · Effect inspection:** Inspect “Metric vocabulary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C006-T08 · Refusal versus failure:** Confirm the “Metric vocabulary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C006-T09 · Reset and retention:** Restore only the disposable “Metric vocabulary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C006-T10 · Negative regression:** Register the “Metric vocabulary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C007 · Change / failure test

**Original checklist item:** Exercise metric vocabulary when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C007-T01 · Scenario record:** Write the “Metric vocabulary” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Metrics measure distinct phases rather than combining unlike costs”.
- [ ] **UC-M10.02-C007-T02 · Baseline capture:** Create a known-valid “Metric vocabulary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C007-T03 · Injection map:** Locate the “Metric vocabulary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Metric vocabulary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C007-T05 · Controlled trigger:** Introduce the controlled “Metric vocabulary” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C007-T06 · Intermediate inspection:** Inspect the “Metric vocabulary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Metric vocabulary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Metric vocabulary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C007-T09 · Repeat and compare:** Repeat the selected “Metric vocabulary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C007-T10 · Failure evidence:** Publish the “Metric vocabulary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for metric count and schema size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Metric vocabulary”: “Metric count and schema size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C008-T02 · Measurement method:** Choose how to observe each “Metric vocabulary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C008-T03 · Budget decision:** Select justified resource and input limits for “Metric vocabulary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Metric vocabulary” cases for “Metric count and schema size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Metric vocabulary” limit; preserve “Metrics measure distinct phases rather than combining unlike costs”.
- [ ] **UC-M10.02-C008-T06 · Normal measurement:** Run or review the normal “Metric vocabulary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C008-T07 · At-limit measurement:** Exercise the “Metric vocabulary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C008-T08 · Over-limit measurement:** Exercise the “Metric vocabulary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C008-T09 · Uncovered-scope report:** List the “Metric vocabulary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C008-T10 · Limit evidence:** Publish the selected “Metric vocabulary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for metric vocabulary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C009-T01 · Event inventory:** List the “Metric vocabulary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Metric vocabulary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C009-T03 · Failure mapping:** Map each documented “Metric vocabulary” refusal or error to a diagnostic outcome; include “Build time is mislabeled as guest boot time” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C009-T04 · Emission path:** Add the “Metric vocabulary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C009-T05 · Redaction check:** Test “Metric vocabulary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C009-T06 · Output budget:** Set and exercise bounded “Metric vocabulary” message size, rate and retention compatible with “Metric count and schema size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C009-T07 · Success/refusal fixtures:** Capture “Metric vocabulary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Metric vocabulary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C009-T09 · Operator review:** Read the “Metric vocabulary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C009-T10 · Diagnostic evidence:** Publish redacted “Metric vocabulary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for metric vocabulary; label unexecuted checks as untested.

- [ ] **UC-M10.02-C010-T01 · Evidence inventory:** List the “Metric vocabulary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C010-T02 · Artifact references:** Record the exact “Metric vocabulary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C010-T03 · Fixture references:** Attach the “Metric vocabulary” fixture IDs, input identities and oracle definition; preserve the source counterexample “Build time is mislabeled as guest boot time” as a distinct evidence case.
- [ ] **UC-M10.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Metric vocabulary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C010-T05 · Environment record:** Record the actual “Metric vocabulary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C010-T06 · Expected versus observed:** Pair every “Metric vocabulary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C010-T07 · Failure and limit records:** Attach “Metric vocabulary” change/failure and bounds evidence where required; include uncovered “Metric count and schema size” and unresolved violations of “Metrics measure distinct phases rather than combining unlike costs”.
- [ ] **UC-M10.02-C010-T08 · Evidence hygiene:** Check the “Metric vocabulary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C010-T09 · Reproduction review:** Have the “Metric vocabulary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C010-T10 · Acceptance linkage:** Link the “Metric vocabulary” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Boot measurement

**Source delivery:** Measure actual guest boot from the documented start to readiness boundary.

**Source invariant:** Boot latency is based on observed guest events.

**Source negative case:** Launcher start is treated as completed guest boot.

**Source bounded quantities:** Timestamp resolution and sample count.

### UC-M10.02-C011 · Contract

**Original checklist item:** Specify boot measurement inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C011-T01 · Scope statement:** Draft the operation boundary for “Boot measurement” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot measurement”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C011-T03 · Output inventory:** List the outputs of “Boot measurement” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot measurement”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C011-T05 · Prerequisite contract:** Map “Boot measurement” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Boot measurement”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C011-T07 · Invariant clause:** Add a normative clause for “Boot measurement” that preserves “Boot latency is based on observed guest events”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot measurement”; include the source counterexample “Launcher start is treated as completed guest boot” and the intended safe disposition.
- [ ] **UC-M10.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Timestamp resolution and sample count” in the “Boot measurement” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C011-T10 · Contract review:** Review the “Boot measurement” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C012 · Delivery

**Original checklist item:** Measure actual guest boot from the documented start to readiness boundary.

- [ ] **UC-M10.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot measurement”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C012-T02 · Change plan:** Break the source delivery for “Boot measurement” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C012-T03 · Core artifact:** Create the “Boot measurement” fixture or harness for this source instruction: Measure actual guest boot from the documented start to readiness boundary.
- [ ] **UC-M10.02-C012-T04 · Concrete realization:** Connect the “Boot measurement” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot measurement” needed to preserve “Boot latency is based on observed guest events”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C012-T06 · Dependency connection:** Connect the “Boot measurement” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C012-T07 · Resource behavior:** Account for “Timestamp resolution and sample count” in “Boot measurement”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C012-T08 · Delivery check:** Run the smallest real “Boot measurement” path and its adverse fixture “Launcher start is treated as completed guest boot”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C012-T09 · Patch review:** Review the “Boot measurement” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C012-T10 · Delivery handoff:** Publish the “Boot measurement” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Boot latency is based on observed guest events. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Boot measurement”; copy its required invariant exactly: “Boot latency is based on observed guest events”.
- [ ] **UC-M10.02-C013-T02 · Observable terms:** Define each term in the “Boot measurement” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C013-T03 · Precondition set:** List the preconditions under which “Boot latency is based on observed guest events” must hold for “Boot measurement”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C013-T04 · Transition coverage:** Map the “Boot measurement” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot measurement”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C013-T06 · Satisfying fixture:** Create a concrete “Boot measurement” case that satisfies “Boot latency is based on observed guest events”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C013-T07 · Violating fixture:** Create the source counterexample “Launcher start is treated as completed guest boot” for “Boot measurement”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C013-T08 · Enforcement evidence:** Exercise the “Boot measurement” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C013-T09 · Regression linkage:** Link the “Boot measurement” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Boot measurement” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C014 · Integration

**Original checklist item:** Integrate boot measurement with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot measurement” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C014-T02 · Field mapping:** Map every “Boot measurement” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot measurement” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C014-T04 · Ownership agreement:** Specify who owns “Boot measurement” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C014-T05 · Handoff implementation:** Connect “Boot measurement” through the mapped seam using the real adapter or explicit specification reference; preserve “Boot latency is based on observed guest events” across the handoff.
- [ ] **UC-M10.02-C014-T06 · Absent-input case:** Omit one required “Boot measurement” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C014-T07 · Stale-input case:** Supply an outdated “Boot measurement” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Boot measurement” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C014-T09 · Valid integration trace:** Run a valid “Boot measurement” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C014-T10 · Seam review:** Reconcile the “Boot measurement” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot measurement; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot measurement” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C015-T02 · Expected-result oracle:** Specify the “Boot measurement” expected result independently of the implementation output; include the property “Boot latency is based on observed guest events” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C015-T03 · Fixture material:** Create the concrete “Boot measurement” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C015-T04 · Target preparation:** Prepare the “Boot measurement” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C015-T05 · Initial-state record:** Record the initial “Boot measurement” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C015-T06 · Valid-path execution:** Execute the “Boot measurement” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C015-T07 · Outcome comparison:** Compare every declared “Boot measurement” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C015-T08 · State and bounds check:** Inspect the “Boot measurement” ownership/state effects and actual use of “Timestamp resolution and sample count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C015-T09 · Repeatability check:** Repeat the same “Boot measurement” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C015-T10 · Positive evidence:** Attach the “Boot measurement” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C016 · Negative test

**Original checklist item:** Negative case: Launcher start is treated as completed guest boot. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Boot measurement” source counterexample: “Launcher start is treated as completed guest boot”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot measurement”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C016-T03 · Valid control:** Construct a valid “Boot measurement” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C016-T04 · Minimal adverse input:** Derive the “Boot measurement” adverse fixture from the control with the smallest documented change needed to reproduce “Launcher start is treated as completed guest boot”; retain that change as reproducible data.
- [ ] **UC-M10.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot measurement”; require “Boot latency is based on observed guest events” and forbid a false-success verdict.
- [ ] **UC-M10.02-C016-T06 · Adverse execution:** Exercise the “Boot measurement” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C016-T07 · Effect inspection:** Inspect “Boot measurement” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C016-T08 · Refusal versus failure:** Confirm the “Boot measurement” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C016-T09 · Reset and retention:** Restore only the disposable “Boot measurement” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C016-T10 · Negative regression:** Register the “Boot measurement” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C017 · Change / failure test

**Original checklist item:** Exercise boot measurement when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C017-T01 · Scenario record:** Write the “Boot measurement” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Boot latency is based on observed guest events”.
- [ ] **UC-M10.02-C017-T02 · Baseline capture:** Create a known-valid “Boot measurement” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C017-T03 · Injection map:** Locate the “Boot measurement” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Boot measurement” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C017-T05 · Controlled trigger:** Introduce the controlled “Boot measurement” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C017-T06 · Intermediate inspection:** Inspect the “Boot measurement” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot measurement”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot measurement” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C017-T09 · Repeat and compare:** Repeat the selected “Boot measurement” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C017-T10 · Failure evidence:** Publish the “Boot measurement” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for timestamp resolution and sample count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Boot measurement”: “Timestamp resolution and sample count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C018-T02 · Measurement method:** Choose how to observe each “Boot measurement” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C018-T03 · Budget decision:** Select justified resource and input limits for “Boot measurement”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot measurement” cases for “Timestamp resolution and sample count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot measurement” limit; preserve “Boot latency is based on observed guest events”.
- [ ] **UC-M10.02-C018-T06 · Normal measurement:** Run or review the normal “Boot measurement” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C018-T07 · At-limit measurement:** Exercise the “Boot measurement” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C018-T08 · Over-limit measurement:** Exercise the “Boot measurement” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C018-T09 · Uncovered-scope report:** List the “Boot measurement” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C018-T10 · Limit evidence:** Publish the selected “Boot measurement” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot measurement with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C019-T01 · Event inventory:** List the “Boot measurement” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Boot measurement” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C019-T03 · Failure mapping:** Map each documented “Boot measurement” refusal or error to a diagnostic outcome; include “Launcher start is treated as completed guest boot” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C019-T04 · Emission path:** Add the “Boot measurement” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C019-T05 · Redaction check:** Test “Boot measurement” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C019-T06 · Output budget:** Set and exercise bounded “Boot measurement” message size, rate and retention compatible with “Timestamp resolution and sample count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C019-T07 · Success/refusal fixtures:** Capture “Boot measurement” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot measurement” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C019-T09 · Operator review:** Read the “Boot measurement” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C019-T10 · Diagnostic evidence:** Publish redacted “Boot measurement” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot measurement; label unexecuted checks as untested.

- [ ] **UC-M10.02-C020-T01 · Evidence inventory:** List the “Boot measurement” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C020-T02 · Artifact references:** Record the exact “Boot measurement” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C020-T03 · Fixture references:** Attach the “Boot measurement” fixture IDs, input identities and oracle definition; preserve the source counterexample “Launcher start is treated as completed guest boot” as a distinct evidence case.
- [ ] **UC-M10.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot measurement”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C020-T05 · Environment record:** Record the actual “Boot measurement” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C020-T06 · Expected versus observed:** Pair every “Boot measurement” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C020-T07 · Failure and limit records:** Attach “Boot measurement” change/failure and bounds evidence where required; include uncovered “Timestamp resolution and sample count” and unresolved violations of “Boot latency is based on observed guest events”.
- [ ] **UC-M10.02-C020-T08 · Evidence hygiene:** Check the “Boot measurement” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C020-T09 · Reproduction review:** Have the “Boot measurement” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C020-T10 · Acceptance linkage:** Link the “Boot measurement” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Queue and execution timing

**Source delivery:** Measure queue wait separately from actual invocation execution.

**Source invariant:** Latency reports do not hide queueing inside unrelated phases.

**Source negative case:** A fast execution value omits a long queue wait.

**Source bounded quantities:** Timing samples and retained window.

### UC-M10.02-C021 · Contract

**Original checklist item:** Specify queue and execution timing inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C021-T01 · Scope statement:** Draft the operation boundary for “Queue and execution timing” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Queue and execution timing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C021-T03 · Output inventory:** List the outputs of “Queue and execution timing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Queue and execution timing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C021-T05 · Prerequisite contract:** Map “Queue and execution timing” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Queue and execution timing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C021-T07 · Invariant clause:** Add a normative clause for “Queue and execution timing” that preserves “Latency reports do not hide queueing inside unrelated phases”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Queue and execution timing”; include the source counterexample “A fast execution value omits a long queue wait” and the intended safe disposition.
- [ ] **UC-M10.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Timing samples and retained window” in the “Queue and execution timing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C021-T10 · Contract review:** Review the “Queue and execution timing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C022 · Delivery

**Original checklist item:** Measure queue wait separately from actual invocation execution.

- [ ] **UC-M10.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Queue and execution timing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C022-T02 · Change plan:** Break the source delivery for “Queue and execution timing” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C022-T03 · Core artifact:** Create the “Queue and execution timing” fixture or harness for this source instruction: Measure queue wait separately from actual invocation execution.
- [ ] **UC-M10.02-C022-T04 · Concrete realization:** Connect the “Queue and execution timing” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Queue and execution timing” needed to preserve “Latency reports do not hide queueing inside unrelated phases”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C022-T06 · Dependency connection:** Connect the “Queue and execution timing” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C022-T07 · Resource behavior:** Account for “Timing samples and retained window” in “Queue and execution timing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C022-T08 · Delivery check:** Run the smallest real “Queue and execution timing” path and its adverse fixture “A fast execution value omits a long queue wait”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C022-T09 · Patch review:** Review the “Queue and execution timing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C022-T10 · Delivery handoff:** Publish the “Queue and execution timing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Latency reports do not hide queueing inside unrelated phases. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Queue and execution timing”; copy its required invariant exactly: “Latency reports do not hide queueing inside unrelated phases”.
- [ ] **UC-M10.02-C023-T02 · Observable terms:** Define each term in the “Queue and execution timing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C023-T03 · Precondition set:** List the preconditions under which “Latency reports do not hide queueing inside unrelated phases” must hold for “Queue and execution timing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C023-T04 · Transition coverage:** Map the “Queue and execution timing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Queue and execution timing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C023-T06 · Satisfying fixture:** Create a concrete “Queue and execution timing” case that satisfies “Latency reports do not hide queueing inside unrelated phases”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C023-T07 · Violating fixture:** Create the source counterexample “A fast execution value omits a long queue wait” for “Queue and execution timing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C023-T08 · Enforcement evidence:** Exercise the “Queue and execution timing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C023-T09 · Regression linkage:** Link the “Queue and execution timing” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Queue and execution timing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C024 · Integration

**Original checklist item:** Integrate queue and execution timing with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Queue and execution timing” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C024-T02 · Field mapping:** Map every “Queue and execution timing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Queue and execution timing” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C024-T04 · Ownership agreement:** Specify who owns “Queue and execution timing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C024-T05 · Handoff implementation:** Connect “Queue and execution timing” through the mapped seam using the real adapter or explicit specification reference; preserve “Latency reports do not hide queueing inside unrelated phases” across the handoff.
- [ ] **UC-M10.02-C024-T06 · Absent-input case:** Omit one required “Queue and execution timing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C024-T07 · Stale-input case:** Supply an outdated “Queue and execution timing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Queue and execution timing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C024-T09 · Valid integration trace:** Run a valid “Queue and execution timing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C024-T10 · Seam review:** Reconcile the “Queue and execution timing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for queue and execution timing; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Queue and execution timing” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C025-T02 · Expected-result oracle:** Specify the “Queue and execution timing” expected result independently of the implementation output; include the property “Latency reports do not hide queueing inside unrelated phases” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C025-T03 · Fixture material:** Create the concrete “Queue and execution timing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C025-T04 · Target preparation:** Prepare the “Queue and execution timing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C025-T05 · Initial-state record:** Record the initial “Queue and execution timing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C025-T06 · Valid-path execution:** Execute the “Queue and execution timing” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C025-T07 · Outcome comparison:** Compare every declared “Queue and execution timing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C025-T08 · State and bounds check:** Inspect the “Queue and execution timing” ownership/state effects and actual use of “Timing samples and retained window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C025-T09 · Repeatability check:** Repeat the same “Queue and execution timing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C025-T10 · Positive evidence:** Attach the “Queue and execution timing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C026 · Negative test

**Original checklist item:** Negative case: A fast execution value omits a long queue wait. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Queue and execution timing” source counterexample: “A fast execution value omits a long queue wait”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Queue and execution timing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C026-T03 · Valid control:** Construct a valid “Queue and execution timing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C026-T04 · Minimal adverse input:** Derive the “Queue and execution timing” adverse fixture from the control with the smallest documented change needed to reproduce “A fast execution value omits a long queue wait”; retain that change as reproducible data.
- [ ] **UC-M10.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Queue and execution timing”; require “Latency reports do not hide queueing inside unrelated phases” and forbid a false-success verdict.
- [ ] **UC-M10.02-C026-T06 · Adverse execution:** Exercise the “Queue and execution timing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C026-T07 · Effect inspection:** Inspect “Queue and execution timing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C026-T08 · Refusal versus failure:** Confirm the “Queue and execution timing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C026-T09 · Reset and retention:** Restore only the disposable “Queue and execution timing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C026-T10 · Negative regression:** Register the “Queue and execution timing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C027 · Change / failure test

**Original checklist item:** Exercise queue and execution timing when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C027-T01 · Scenario record:** Write the “Queue and execution timing” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Latency reports do not hide queueing inside unrelated phases”.
- [ ] **UC-M10.02-C027-T02 · Baseline capture:** Create a known-valid “Queue and execution timing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C027-T03 · Injection map:** Locate the “Queue and execution timing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Queue and execution timing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C027-T05 · Controlled trigger:** Introduce the controlled “Queue and execution timing” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C027-T06 · Intermediate inspection:** Inspect the “Queue and execution timing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Queue and execution timing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Queue and execution timing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C027-T09 · Repeat and compare:** Repeat the selected “Queue and execution timing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C027-T10 · Failure evidence:** Publish the “Queue and execution timing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for timing samples and retained window; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Queue and execution timing”: “Timing samples and retained window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C028-T02 · Measurement method:** Choose how to observe each “Queue and execution timing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Queue and execution timing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Queue and execution timing” cases for “Timing samples and retained window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Queue and execution timing” limit; preserve “Latency reports do not hide queueing inside unrelated phases”.
- [ ] **UC-M10.02-C028-T06 · Normal measurement:** Run or review the normal “Queue and execution timing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C028-T07 · At-limit measurement:** Exercise the “Queue and execution timing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C028-T08 · Over-limit measurement:** Exercise the “Queue and execution timing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C028-T09 · Uncovered-scope report:** List the “Queue and execution timing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C028-T10 · Limit evidence:** Publish the selected “Queue and execution timing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for queue and execution timing with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C029-T01 · Event inventory:** List the “Queue and execution timing” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Queue and execution timing” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C029-T03 · Failure mapping:** Map each documented “Queue and execution timing” refusal or error to a diagnostic outcome; include “A fast execution value omits a long queue wait” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C029-T04 · Emission path:** Add the “Queue and execution timing” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C029-T05 · Redaction check:** Test “Queue and execution timing” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C029-T06 · Output budget:** Set and exercise bounded “Queue and execution timing” message size, rate and retention compatible with “Timing samples and retained window”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C029-T07 · Success/refusal fixtures:** Capture “Queue and execution timing” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Queue and execution timing” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C029-T09 · Operator review:** Read the “Queue and execution timing” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C029-T10 · Diagnostic evidence:** Publish redacted “Queue and execution timing” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for queue and execution timing; label unexecuted checks as untested.

- [ ] **UC-M10.02-C030-T01 · Evidence inventory:** List the “Queue and execution timing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C030-T02 · Artifact references:** Record the exact “Queue and execution timing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C030-T03 · Fixture references:** Attach the “Queue and execution timing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A fast execution value omits a long queue wait” as a distinct evidence case.
- [ ] **UC-M10.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Queue and execution timing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C030-T05 · Environment record:** Record the actual “Queue and execution timing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C030-T06 · Expected versus observed:** Pair every “Queue and execution timing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C030-T07 · Failure and limit records:** Attach “Queue and execution timing” change/failure and bounds evidence where required; include uncovered “Timing samples and retained window” and unresolved violations of “Latency reports do not hide queueing inside unrelated phases”.
- [ ] **UC-M10.02-C030-T08 · Evidence hygiene:** Check the “Queue and execution timing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C030-T09 · Reproduction review:** Have the “Queue and execution timing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C030-T10 · Acceptance linkage:** Link the “Queue and execution timing” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Memory attribution

**Source delivery:** Measure guest, VMM, compiler, decoder and controller memory distinctly.

**Source invariant:** Guest memory claims do not omit required host overhead.

**Source negative case:** Only guest heap is reported as total platform memory.

**Source bounded quantities:** Processes and attribution interval.

### UC-M10.02-C031 · Contract

**Original checklist item:** Specify memory attribution inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C031-T01 · Scope statement:** Draft the operation boundary for “Memory attribution” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Memory attribution”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C031-T03 · Output inventory:** List the outputs of “Memory attribution” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Memory attribution”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C031-T05 · Prerequisite contract:** Map “Memory attribution” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Memory attribution”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C031-T07 · Invariant clause:** Add a normative clause for “Memory attribution” that preserves “Guest memory claims do not omit required host overhead”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Memory attribution”; include the source counterexample “Only guest heap is reported as total platform memory” and the intended safe disposition.
- [ ] **UC-M10.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Processes and attribution interval” in the “Memory attribution” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C031-T10 · Contract review:** Review the “Memory attribution” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C032 · Delivery

**Original checklist item:** Measure guest, VMM, compiler, decoder and controller memory distinctly.

- [ ] **UC-M10.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Memory attribution”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C032-T02 · Change plan:** Break the source delivery for “Memory attribution” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C032-T03 · Core artifact:** Create the “Memory attribution” fixture or harness for this source instruction: Measure guest, VMM, compiler, decoder and controller memory distinctly.
- [ ] **UC-M10.02-C032-T04 · Concrete realization:** Connect the “Memory attribution” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Memory attribution” needed to preserve “Guest memory claims do not omit required host overhead”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C032-T06 · Dependency connection:** Connect the “Memory attribution” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C032-T07 · Resource behavior:** Account for “Processes and attribution interval” in “Memory attribution”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C032-T08 · Delivery check:** Run the smallest real “Memory attribution” path and its adverse fixture “Only guest heap is reported as total platform memory”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C032-T09 · Patch review:** Review the “Memory attribution” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C032-T10 · Delivery handoff:** Publish the “Memory attribution” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Guest memory claims do not omit required host overhead. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Memory attribution”; copy its required invariant exactly: “Guest memory claims do not omit required host overhead”.
- [ ] **UC-M10.02-C033-T02 · Observable terms:** Define each term in the “Memory attribution” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C033-T03 · Precondition set:** List the preconditions under which “Guest memory claims do not omit required host overhead” must hold for “Memory attribution”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C033-T04 · Transition coverage:** Map the “Memory attribution” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Memory attribution”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C033-T06 · Satisfying fixture:** Create a concrete “Memory attribution” case that satisfies “Guest memory claims do not omit required host overhead”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C033-T07 · Violating fixture:** Create the source counterexample “Only guest heap is reported as total platform memory” for “Memory attribution”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C033-T08 · Enforcement evidence:** Exercise the “Memory attribution” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C033-T09 · Regression linkage:** Link the “Memory attribution” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Memory attribution” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C034 · Integration

**Original checklist item:** Integrate memory attribution with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Memory attribution” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C034-T02 · Field mapping:** Map every “Memory attribution” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Memory attribution” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C034-T04 · Ownership agreement:** Specify who owns “Memory attribution” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C034-T05 · Handoff implementation:** Connect “Memory attribution” through the mapped seam using the real adapter or explicit specification reference; preserve “Guest memory claims do not omit required host overhead” across the handoff.
- [ ] **UC-M10.02-C034-T06 · Absent-input case:** Omit one required “Memory attribution” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C034-T07 · Stale-input case:** Supply an outdated “Memory attribution” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Memory attribution” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C034-T09 · Valid integration trace:** Run a valid “Memory attribution” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C034-T10 · Seam review:** Reconcile the “Memory attribution” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for memory attribution; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Memory attribution” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C035-T02 · Expected-result oracle:** Specify the “Memory attribution” expected result independently of the implementation output; include the property “Guest memory claims do not omit required host overhead” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C035-T03 · Fixture material:** Create the concrete “Memory attribution” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C035-T04 · Target preparation:** Prepare the “Memory attribution” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C035-T05 · Initial-state record:** Record the initial “Memory attribution” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C035-T06 · Valid-path execution:** Execute the “Memory attribution” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C035-T07 · Outcome comparison:** Compare every declared “Memory attribution” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C035-T08 · State and bounds check:** Inspect the “Memory attribution” ownership/state effects and actual use of “Processes and attribution interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C035-T09 · Repeatability check:** Repeat the same “Memory attribution” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C035-T10 · Positive evidence:** Attach the “Memory attribution” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C036 · Negative test

**Original checklist item:** Negative case: Only guest heap is reported as total platform memory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Memory attribution” source counterexample: “Only guest heap is reported as total platform memory”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Memory attribution”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C036-T03 · Valid control:** Construct a valid “Memory attribution” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C036-T04 · Minimal adverse input:** Derive the “Memory attribution” adverse fixture from the control with the smallest documented change needed to reproduce “Only guest heap is reported as total platform memory”; retain that change as reproducible data.
- [ ] **UC-M10.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Memory attribution”; require “Guest memory claims do not omit required host overhead” and forbid a false-success verdict.
- [ ] **UC-M10.02-C036-T06 · Adverse execution:** Exercise the “Memory attribution” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C036-T07 · Effect inspection:** Inspect “Memory attribution” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C036-T08 · Refusal versus failure:** Confirm the “Memory attribution” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C036-T09 · Reset and retention:** Restore only the disposable “Memory attribution” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C036-T10 · Negative regression:** Register the “Memory attribution” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C037 · Change / failure test

**Original checklist item:** Exercise memory attribution when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C037-T01 · Scenario record:** Write the “Memory attribution” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Guest memory claims do not omit required host overhead”.
- [ ] **UC-M10.02-C037-T02 · Baseline capture:** Create a known-valid “Memory attribution” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C037-T03 · Injection map:** Locate the “Memory attribution” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Memory attribution” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C037-T05 · Controlled trigger:** Introduce the controlled “Memory attribution” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C037-T06 · Intermediate inspection:** Inspect the “Memory attribution” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Memory attribution”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Memory attribution” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C037-T09 · Repeat and compare:** Repeat the selected “Memory attribution” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C037-T10 · Failure evidence:** Publish the “Memory attribution” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for processes and attribution interval; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Memory attribution”: “Processes and attribution interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C038-T02 · Measurement method:** Choose how to observe each “Memory attribution” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C038-T03 · Budget decision:** Select justified resource and input limits for “Memory attribution”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Memory attribution” cases for “Processes and attribution interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Memory attribution” limit; preserve “Guest memory claims do not omit required host overhead”.
- [ ] **UC-M10.02-C038-T06 · Normal measurement:** Run or review the normal “Memory attribution” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C038-T07 · At-limit measurement:** Exercise the “Memory attribution” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C038-T08 · Over-limit measurement:** Exercise the “Memory attribution” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C038-T09 · Uncovered-scope report:** List the “Memory attribution” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C038-T10 · Limit evidence:** Publish the selected “Memory attribution” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for memory attribution with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C039-T01 · Event inventory:** List the “Memory attribution” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Memory attribution” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C039-T03 · Failure mapping:** Map each documented “Memory attribution” refusal or error to a diagnostic outcome; include “Only guest heap is reported as total platform memory” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C039-T04 · Emission path:** Add the “Memory attribution” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C039-T05 · Redaction check:** Test “Memory attribution” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C039-T06 · Output budget:** Set and exercise bounded “Memory attribution” message size, rate and retention compatible with “Processes and attribution interval”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C039-T07 · Success/refusal fixtures:** Capture “Memory attribution” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Memory attribution” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C039-T09 · Operator review:** Read the “Memory attribution” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C039-T10 · Diagnostic evidence:** Publish redacted “Memory attribution” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for memory attribution; label unexecuted checks as untested.

- [ ] **UC-M10.02-C040-T01 · Evidence inventory:** List the “Memory attribution” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C040-T02 · Artifact references:** Record the exact “Memory attribution” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C040-T03 · Fixture references:** Attach the “Memory attribution” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only guest heap is reported as total platform memory” as a distinct evidence case.
- [ ] **UC-M10.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Memory attribution”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C040-T05 · Environment record:** Record the actual “Memory attribution” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C040-T06 · Expected versus observed:** Pair every “Memory attribution” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C040-T07 · Failure and limit records:** Attach “Memory attribution” change/failure and bounds evidence where required; include uncovered “Processes and attribution interval” and unresolved violations of “Guest memory claims do not omit required host overhead”.
- [ ] **UC-M10.02-C040-T08 · Evidence hygiene:** Check the “Memory attribution” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C040-T09 · Reproduction review:** Have the “Memory attribution” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C040-T10 · Acceptance linkage:** Link the “Memory attribution” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. I/O and storage accounting

**Source delivery:** Measure actual I/O and persistent growth by image and generation.

**Source invariant:** Storage cost includes required history and checkpoint growth.

**Source negative case:** A benchmark reports only the initial image size.

**Source bounded quantities:** Observed bytes and sampling frequency.

### UC-M10.02-C041 · Contract

**Original checklist item:** Specify I/O and storage accounting inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C041-T01 · Scope statement:** Draft the operation boundary for “I/O and storage accounting” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “I/O and storage accounting”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C041-T03 · Output inventory:** List the outputs of “I/O and storage accounting” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “I/O and storage accounting”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C041-T05 · Prerequisite contract:** Map “I/O and storage accounting” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C041-T06 · Authority map:** Identify who may produce, change and consume “I/O and storage accounting”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C041-T07 · Invariant clause:** Add a normative clause for “I/O and storage accounting” that preserves “Storage cost includes required history and checkpoint growth”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “I/O and storage accounting”; include the source counterexample “A benchmark reports only the initial image size” and the intended safe disposition.
- [ ] **UC-M10.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Observed bytes and sampling frequency” in the “I/O and storage accounting” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C041-T10 · Contract review:** Review the “I/O and storage accounting” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C042 · Delivery

**Original checklist item:** Measure actual I/O and persistent growth by image and generation.

- [ ] **UC-M10.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “I/O and storage accounting”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C042-T02 · Change plan:** Break the source delivery for “I/O and storage accounting” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C042-T03 · Core artifact:** Create the “I/O and storage accounting” fixture or harness for this source instruction: Measure actual I/O and persistent growth by image and generation.
- [ ] **UC-M10.02-C042-T04 · Concrete realization:** Connect the “I/O and storage accounting” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “I/O and storage accounting” needed to preserve “Storage cost includes required history and checkpoint growth”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C042-T06 · Dependency connection:** Connect the “I/O and storage accounting” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C042-T07 · Resource behavior:** Account for “Observed bytes and sampling frequency” in “I/O and storage accounting”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C042-T08 · Delivery check:** Run the smallest real “I/O and storage accounting” path and its adverse fixture “A benchmark reports only the initial image size”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C042-T09 · Patch review:** Review the “I/O and storage accounting” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C042-T10 · Delivery handoff:** Publish the “I/O and storage accounting” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Storage cost includes required history and checkpoint growth. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “I/O and storage accounting”; copy its required invariant exactly: “Storage cost includes required history and checkpoint growth”.
- [ ] **UC-M10.02-C043-T02 · Observable terms:** Define each term in the “I/O and storage accounting” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C043-T03 · Precondition set:** List the preconditions under which “Storage cost includes required history and checkpoint growth” must hold for “I/O and storage accounting”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C043-T04 · Transition coverage:** Map the “I/O and storage accounting” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “I/O and storage accounting”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C043-T06 · Satisfying fixture:** Create a concrete “I/O and storage accounting” case that satisfies “Storage cost includes required history and checkpoint growth”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C043-T07 · Violating fixture:** Create the source counterexample “A benchmark reports only the initial image size” for “I/O and storage accounting”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C043-T08 · Enforcement evidence:** Exercise the “I/O and storage accounting” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C043-T09 · Regression linkage:** Link the “I/O and storage accounting” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C043-T10 · Property disposition:** Compare the satisfying and violating “I/O and storage accounting” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C044 · Integration

**Original checklist item:** Integrate I/O and storage accounting with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “I/O and storage accounting” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C044-T02 · Field mapping:** Map every “I/O and storage accounting” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “I/O and storage accounting” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C044-T04 · Ownership agreement:** Specify who owns “I/O and storage accounting” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C044-T05 · Handoff implementation:** Connect “I/O and storage accounting” through the mapped seam using the real adapter or explicit specification reference; preserve “Storage cost includes required history and checkpoint growth” across the handoff.
- [ ] **UC-M10.02-C044-T06 · Absent-input case:** Omit one required “I/O and storage accounting” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C044-T07 · Stale-input case:** Supply an outdated “I/O and storage accounting” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C044-T08 · Incompatible-input case:** Supply an incompatible “I/O and storage accounting” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C044-T09 · Valid integration trace:** Run a valid “I/O and storage accounting” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C044-T10 · Seam review:** Reconcile the “I/O and storage accounting” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for I/O and storage accounting; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “I/O and storage accounting” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C045-T02 · Expected-result oracle:** Specify the “I/O and storage accounting” expected result independently of the implementation output; include the property “Storage cost includes required history and checkpoint growth” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C045-T03 · Fixture material:** Create the concrete “I/O and storage accounting” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C045-T04 · Target preparation:** Prepare the “I/O and storage accounting” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C045-T05 · Initial-state record:** Record the initial “I/O and storage accounting” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C045-T06 · Valid-path execution:** Execute the “I/O and storage accounting” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C045-T07 · Outcome comparison:** Compare every declared “I/O and storage accounting” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C045-T08 · State and bounds check:** Inspect the “I/O and storage accounting” ownership/state effects and actual use of “Observed bytes and sampling frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C045-T09 · Repeatability check:** Repeat the same “I/O and storage accounting” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C045-T10 · Positive evidence:** Attach the “I/O and storage accounting” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C046 · Negative test

**Original checklist item:** Negative case: A benchmark reports only the initial image size. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “I/O and storage accounting” source counterexample: “A benchmark reports only the initial image size”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “I/O and storage accounting”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C046-T03 · Valid control:** Construct a valid “I/O and storage accounting” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C046-T04 · Minimal adverse input:** Derive the “I/O and storage accounting” adverse fixture from the control with the smallest documented change needed to reproduce “A benchmark reports only the initial image size”; retain that change as reproducible data.
- [ ] **UC-M10.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “I/O and storage accounting”; require “Storage cost includes required history and checkpoint growth” and forbid a false-success verdict.
- [ ] **UC-M10.02-C046-T06 · Adverse execution:** Exercise the “I/O and storage accounting” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C046-T07 · Effect inspection:** Inspect “I/O and storage accounting” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C046-T08 · Refusal versus failure:** Confirm the “I/O and storage accounting” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C046-T09 · Reset and retention:** Restore only the disposable “I/O and storage accounting” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C046-T10 · Negative regression:** Register the “I/O and storage accounting” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C047 · Change / failure test

**Original checklist item:** Exercise I/O and storage accounting when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C047-T01 · Scenario record:** Write the “I/O and storage accounting” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Storage cost includes required history and checkpoint growth”.
- [ ] **UC-M10.02-C047-T02 · Baseline capture:** Create a known-valid “I/O and storage accounting” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C047-T03 · Injection map:** Locate the “I/O and storage accounting” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “I/O and storage accounting” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C047-T05 · Controlled trigger:** Introduce the controlled “I/O and storage accounting” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C047-T06 · Intermediate inspection:** Inspect the “I/O and storage accounting” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “I/O and storage accounting”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “I/O and storage accounting” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C047-T09 · Repeat and compare:** Repeat the selected “I/O and storage accounting” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C047-T10 · Failure evidence:** Publish the “I/O and storage accounting” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for observed bytes and sampling frequency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “I/O and storage accounting”: “Observed bytes and sampling frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C048-T02 · Measurement method:** Choose how to observe each “I/O and storage accounting” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C048-T03 · Budget decision:** Select justified resource and input limits for “I/O and storage accounting”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “I/O and storage accounting” cases for “Observed bytes and sampling frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “I/O and storage accounting” limit; preserve “Storage cost includes required history and checkpoint growth”.
- [ ] **UC-M10.02-C048-T06 · Normal measurement:** Run or review the normal “I/O and storage accounting” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C048-T07 · At-limit measurement:** Exercise the “I/O and storage accounting” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C048-T08 · Over-limit measurement:** Exercise the “I/O and storage accounting” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C048-T09 · Uncovered-scope report:** List the “I/O and storage accounting” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C048-T10 · Limit evidence:** Publish the selected “I/O and storage accounting” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for I/O and storage accounting with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C049-T01 · Event inventory:** List the “I/O and storage accounting” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “I/O and storage accounting” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C049-T03 · Failure mapping:** Map each documented “I/O and storage accounting” refusal or error to a diagnostic outcome; include “A benchmark reports only the initial image size” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C049-T04 · Emission path:** Add the “I/O and storage accounting” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C049-T05 · Redaction check:** Test “I/O and storage accounting” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C049-T06 · Output budget:** Set and exercise bounded “I/O and storage accounting” message size, rate and retention compatible with “Observed bytes and sampling frequency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C049-T07 · Success/refusal fixtures:** Capture “I/O and storage accounting” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “I/O and storage accounting” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C049-T09 · Operator review:** Read the “I/O and storage accounting” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C049-T10 · Diagnostic evidence:** Publish redacted “I/O and storage accounting” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for I/O and storage accounting; label unexecuted checks as untested.

- [ ] **UC-M10.02-C050-T01 · Evidence inventory:** List the “I/O and storage accounting” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C050-T02 · Artifact references:** Record the exact “I/O and storage accounting” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C050-T03 · Fixture references:** Attach the “I/O and storage accounting” fixture IDs, input identities and oracle definition; preserve the source counterexample “A benchmark reports only the initial image size” as a distinct evidence case.
- [ ] **UC-M10.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “I/O and storage accounting”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C050-T05 · Environment record:** Record the actual “I/O and storage accounting” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C050-T06 · Expected versus observed:** Pair every “I/O and storage accounting” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C050-T07 · Failure and limit records:** Attach “I/O and storage accounting” change/failure and bounds evidence where required; include uncovered “Observed bytes and sampling frequency” and unresolved violations of “Storage cost includes required history and checkpoint growth”.
- [ ] **UC-M10.02-C050-T08 · Evidence hygiene:** Check the “I/O and storage accounting” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C050-T09 · Reproduction review:** Have the “I/O and storage accounting” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C050-T10 · Acceptance linkage:** Link the “I/O and storage accounting” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Bounded label cardinality

**Source delivery:** Limit metric dimensions and avoid unbounded user-input labels.

**Source invariant:** Metrics cannot exhaust resources through unique workload data.

**Source negative case:** Every request payload becomes a new metric label.

**Source bounded quantities:** Series count and label length.

### UC-M10.02-C051 · Contract

**Original checklist item:** Specify bounded label cardinality inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C051-T01 · Scope statement:** Draft the operation boundary for “Bounded label cardinality” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Bounded label cardinality”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C051-T03 · Output inventory:** List the outputs of “Bounded label cardinality” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Bounded label cardinality”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C051-T05 · Prerequisite contract:** Map “Bounded label cardinality” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Bounded label cardinality”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C051-T07 · Invariant clause:** Add a normative clause for “Bounded label cardinality” that preserves “Metrics cannot exhaust resources through unique workload data”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Bounded label cardinality”; include the source counterexample “Every request payload becomes a new metric label” and the intended safe disposition.
- [ ] **UC-M10.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Series count and label length” in the “Bounded label cardinality” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C051-T10 · Contract review:** Review the “Bounded label cardinality” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C052 · Delivery

**Original checklist item:** Limit metric dimensions and avoid unbounded user-input labels.

- [ ] **UC-M10.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Bounded label cardinality”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C052-T02 · Change plan:** Break the source delivery for “Bounded label cardinality” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Bounded label cardinality” that realizes this source instruction: Limit metric dimensions and avoid unbounded user-input labels.
- [ ] **UC-M10.02-C052-T04 · Concrete realization:** Trace “Bounded label cardinality” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Bounded label cardinality” needed to preserve “Metrics cannot exhaust resources through unique workload data”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C052-T06 · Dependency connection:** Connect the “Bounded label cardinality” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C052-T07 · Resource behavior:** Account for “Series count and label length” in “Bounded label cardinality”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C052-T08 · Delivery check:** Run the smallest real “Bounded label cardinality” path and its adverse fixture “Every request payload becomes a new metric label”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C052-T09 · Patch review:** Review the “Bounded label cardinality” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C052-T10 · Delivery handoff:** Publish the “Bounded label cardinality” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Metrics cannot exhaust resources through unique workload data. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Bounded label cardinality”; copy its required invariant exactly: “Metrics cannot exhaust resources through unique workload data”.
- [ ] **UC-M10.02-C053-T02 · Observable terms:** Define each term in the “Bounded label cardinality” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C053-T03 · Precondition set:** List the preconditions under which “Metrics cannot exhaust resources through unique workload data” must hold for “Bounded label cardinality”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C053-T04 · Transition coverage:** Map the “Bounded label cardinality” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Bounded label cardinality”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C053-T06 · Satisfying fixture:** Create a concrete “Bounded label cardinality” case that satisfies “Metrics cannot exhaust resources through unique workload data”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C053-T07 · Violating fixture:** Create the source counterexample “Every request payload becomes a new metric label” for “Bounded label cardinality”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C053-T08 · Enforcement evidence:** Exercise the “Bounded label cardinality” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C053-T09 · Regression linkage:** Link the “Bounded label cardinality” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Bounded label cardinality” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C054 · Integration

**Original checklist item:** Integrate bounded label cardinality with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Bounded label cardinality” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C054-T02 · Field mapping:** Map every “Bounded label cardinality” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Bounded label cardinality” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C054-T04 · Ownership agreement:** Specify who owns “Bounded label cardinality” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C054-T05 · Handoff implementation:** Connect “Bounded label cardinality” through the mapped seam using the real adapter or explicit specification reference; preserve “Metrics cannot exhaust resources through unique workload data” across the handoff.
- [ ] **UC-M10.02-C054-T06 · Absent-input case:** Omit one required “Bounded label cardinality” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C054-T07 · Stale-input case:** Supply an outdated “Bounded label cardinality” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Bounded label cardinality” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C054-T09 · Valid integration trace:** Run a valid “Bounded label cardinality” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C054-T10 · Seam review:** Reconcile the “Bounded label cardinality” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for bounded label cardinality; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Bounded label cardinality” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C055-T02 · Expected-result oracle:** Specify the “Bounded label cardinality” expected result independently of the implementation output; include the property “Metrics cannot exhaust resources through unique workload data” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C055-T03 · Fixture material:** Create the concrete “Bounded label cardinality” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C055-T04 · Target preparation:** Prepare the “Bounded label cardinality” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C055-T05 · Initial-state record:** Record the initial “Bounded label cardinality” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C055-T06 · Valid-path execution:** Execute the “Bounded label cardinality” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C055-T07 · Outcome comparison:** Compare every declared “Bounded label cardinality” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C055-T08 · State and bounds check:** Inspect the “Bounded label cardinality” ownership/state effects and actual use of “Series count and label length”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C055-T09 · Repeatability check:** Repeat the same “Bounded label cardinality” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C055-T10 · Positive evidence:** Attach the “Bounded label cardinality” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C056 · Negative test

**Original checklist item:** Negative case: Every request payload becomes a new metric label. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Bounded label cardinality” source counterexample: “Every request payload becomes a new metric label”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Bounded label cardinality”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C056-T03 · Valid control:** Construct a valid “Bounded label cardinality” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C056-T04 · Minimal adverse input:** Derive the “Bounded label cardinality” adverse fixture from the control with the smallest documented change needed to reproduce “Every request payload becomes a new metric label”; retain that change as reproducible data.
- [ ] **UC-M10.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Bounded label cardinality”; require “Metrics cannot exhaust resources through unique workload data” and forbid a false-success verdict.
- [ ] **UC-M10.02-C056-T06 · Adverse execution:** Exercise the “Bounded label cardinality” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C056-T07 · Effect inspection:** Inspect “Bounded label cardinality” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C056-T08 · Refusal versus failure:** Confirm the “Bounded label cardinality” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C056-T09 · Reset and retention:** Restore only the disposable “Bounded label cardinality” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C056-T10 · Negative regression:** Register the “Bounded label cardinality” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C057 · Change / failure test

**Original checklist item:** Exercise bounded label cardinality when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C057-T01 · Scenario record:** Write the “Bounded label cardinality” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Metrics cannot exhaust resources through unique workload data”.
- [ ] **UC-M10.02-C057-T02 · Baseline capture:** Create a known-valid “Bounded label cardinality” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C057-T03 · Injection map:** Locate the “Bounded label cardinality” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Bounded label cardinality” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C057-T05 · Controlled trigger:** Introduce the controlled “Bounded label cardinality” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C057-T06 · Intermediate inspection:** Inspect the “Bounded label cardinality” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Bounded label cardinality”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Bounded label cardinality” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C057-T09 · Repeat and compare:** Repeat the selected “Bounded label cardinality” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C057-T10 · Failure evidence:** Publish the “Bounded label cardinality” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for series count and label length; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Bounded label cardinality”: “Series count and label length”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C058-T02 · Measurement method:** Choose how to observe each “Bounded label cardinality” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Bounded label cardinality”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Bounded label cardinality” cases for “Series count and label length”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Bounded label cardinality” limit; preserve “Metrics cannot exhaust resources through unique workload data”.
- [ ] **UC-M10.02-C058-T06 · Normal measurement:** Run or review the normal “Bounded label cardinality” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C058-T07 · At-limit measurement:** Exercise the “Bounded label cardinality” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C058-T08 · Over-limit measurement:** Exercise the “Bounded label cardinality” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C058-T09 · Uncovered-scope report:** List the “Bounded label cardinality” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C058-T10 · Limit evidence:** Publish the selected “Bounded label cardinality” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for bounded label cardinality with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C059-T01 · Event inventory:** List the “Bounded label cardinality” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Bounded label cardinality” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C059-T03 · Failure mapping:** Map each documented “Bounded label cardinality” refusal or error to a diagnostic outcome; include “Every request payload becomes a new metric label” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C059-T04 · Emission path:** Add the “Bounded label cardinality” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C059-T05 · Redaction check:** Test “Bounded label cardinality” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C059-T06 · Output budget:** Set and exercise bounded “Bounded label cardinality” message size, rate and retention compatible with “Series count and label length”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C059-T07 · Success/refusal fixtures:** Capture “Bounded label cardinality” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Bounded label cardinality” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C059-T09 · Operator review:** Read the “Bounded label cardinality” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C059-T10 · Diagnostic evidence:** Publish redacted “Bounded label cardinality” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for bounded label cardinality; label unexecuted checks as untested.

- [ ] **UC-M10.02-C060-T01 · Evidence inventory:** List the “Bounded label cardinality” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C060-T02 · Artifact references:** Record the exact “Bounded label cardinality” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C060-T03 · Fixture references:** Attach the “Bounded label cardinality” fixture IDs, input identities and oracle definition; preserve the source counterexample “Every request payload becomes a new metric label” as a distinct evidence case.
- [ ] **UC-M10.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Bounded label cardinality”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C060-T05 · Environment record:** Record the actual “Bounded label cardinality” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C060-T06 · Expected versus observed:** Pair every “Bounded label cardinality” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C060-T07 · Failure and limit records:** Attach “Bounded label cardinality” change/failure and bounds evidence where required; include uncovered “Series count and label length” and unresolved violations of “Metrics cannot exhaust resources through unique workload data”.
- [ ] **UC-M10.02-C060-T08 · Evidence hygiene:** Check the “Bounded label cardinality” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C060-T09 · Reproduction review:** Have the “Bounded label cardinality” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C060-T10 · Acceptance linkage:** Link the “Bounded label cardinality” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Host reconciliation

**Source delivery:** Compare platform metrics with independent host observations.

**Source invariant:** Published resource totals reconcile within a documented measurement boundary.

**Source negative case:** Reported memory excludes a known active decoder process.

**Source bounded quantities:** Observation tools and comparison samples.

### UC-M10.02-C061 · Contract

**Original checklist item:** Specify host reconciliation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C061-T01 · Scope statement:** Draft the operation boundary for “Host reconciliation” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Host reconciliation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C061-T03 · Output inventory:** List the outputs of “Host reconciliation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Host reconciliation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C061-T05 · Prerequisite contract:** Map “Host reconciliation” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Host reconciliation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C061-T07 · Invariant clause:** Add a normative clause for “Host reconciliation” that preserves “Published resource totals reconcile within a documented measurement boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Host reconciliation”; include the source counterexample “Reported memory excludes a known active decoder process” and the intended safe disposition.
- [ ] **UC-M10.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Observation tools and comparison samples” in the “Host reconciliation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C061-T10 · Contract review:** Review the “Host reconciliation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C062 · Delivery

**Original checklist item:** Compare platform metrics with independent host observations.

- [ ] **UC-M10.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Host reconciliation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C062-T02 · Change plan:** Break the source delivery for “Host reconciliation” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C062-T03 · Core artifact:** Create the “Host reconciliation” fixture or harness for this source instruction: Compare platform metrics with independent host observations.
- [ ] **UC-M10.02-C062-T04 · Concrete realization:** Connect the “Host reconciliation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Host reconciliation” needed to preserve “Published resource totals reconcile within a documented measurement boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C062-T06 · Dependency connection:** Connect the “Host reconciliation” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C062-T07 · Resource behavior:** Account for “Observation tools and comparison samples” in “Host reconciliation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C062-T08 · Delivery check:** Run the smallest real “Host reconciliation” path and its adverse fixture “Reported memory excludes a known active decoder process”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C062-T09 · Patch review:** Review the “Host reconciliation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C062-T10 · Delivery handoff:** Publish the “Host reconciliation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Published resource totals reconcile within a documented measurement boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Host reconciliation”; copy its required invariant exactly: “Published resource totals reconcile within a documented measurement boundary”.
- [ ] **UC-M10.02-C063-T02 · Observable terms:** Define each term in the “Host reconciliation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C063-T03 · Precondition set:** List the preconditions under which “Published resource totals reconcile within a documented measurement boundary” must hold for “Host reconciliation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C063-T04 · Transition coverage:** Map the “Host reconciliation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Host reconciliation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C063-T06 · Satisfying fixture:** Create a concrete “Host reconciliation” case that satisfies “Published resource totals reconcile within a documented measurement boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C063-T07 · Violating fixture:** Create the source counterexample “Reported memory excludes a known active decoder process” for “Host reconciliation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C063-T08 · Enforcement evidence:** Exercise the “Host reconciliation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C063-T09 · Regression linkage:** Link the “Host reconciliation” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Host reconciliation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C064 · Integration

**Original checklist item:** Integrate host reconciliation with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Host reconciliation” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C064-T02 · Field mapping:** Map every “Host reconciliation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Host reconciliation” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C064-T04 · Ownership agreement:** Specify who owns “Host reconciliation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C064-T05 · Handoff implementation:** Connect “Host reconciliation” through the mapped seam using the real adapter or explicit specification reference; preserve “Published resource totals reconcile within a documented measurement boundary” across the handoff.
- [ ] **UC-M10.02-C064-T06 · Absent-input case:** Omit one required “Host reconciliation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C064-T07 · Stale-input case:** Supply an outdated “Host reconciliation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Host reconciliation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C064-T09 · Valid integration trace:** Run a valid “Host reconciliation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C064-T10 · Seam review:** Reconcile the “Host reconciliation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for host reconciliation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Host reconciliation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C065-T02 · Expected-result oracle:** Specify the “Host reconciliation” expected result independently of the implementation output; include the property “Published resource totals reconcile within a documented measurement boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C065-T03 · Fixture material:** Create the concrete “Host reconciliation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C065-T04 · Target preparation:** Prepare the “Host reconciliation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C065-T05 · Initial-state record:** Record the initial “Host reconciliation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C065-T06 · Valid-path execution:** Execute the “Host reconciliation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C065-T07 · Outcome comparison:** Compare every declared “Host reconciliation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C065-T08 · State and bounds check:** Inspect the “Host reconciliation” ownership/state effects and actual use of “Observation tools and comparison samples”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C065-T09 · Repeatability check:** Repeat the same “Host reconciliation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C065-T10 · Positive evidence:** Attach the “Host reconciliation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C066 · Negative test

**Original checklist item:** Negative case: Reported memory excludes a known active decoder process. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Host reconciliation” source counterexample: “Reported memory excludes a known active decoder process”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Host reconciliation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C066-T03 · Valid control:** Construct a valid “Host reconciliation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C066-T04 · Minimal adverse input:** Derive the “Host reconciliation” adverse fixture from the control with the smallest documented change needed to reproduce “Reported memory excludes a known active decoder process”; retain that change as reproducible data.
- [ ] **UC-M10.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Host reconciliation”; require “Published resource totals reconcile within a documented measurement boundary” and forbid a false-success verdict.
- [ ] **UC-M10.02-C066-T06 · Adverse execution:** Exercise the “Host reconciliation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C066-T07 · Effect inspection:** Inspect “Host reconciliation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C066-T08 · Refusal versus failure:** Confirm the “Host reconciliation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C066-T09 · Reset and retention:** Restore only the disposable “Host reconciliation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C066-T10 · Negative regression:** Register the “Host reconciliation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C067 · Change / failure test

**Original checklist item:** Exercise host reconciliation when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C067-T01 · Scenario record:** Write the “Host reconciliation” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Published resource totals reconcile within a documented measurement boundary”.
- [ ] **UC-M10.02-C067-T02 · Baseline capture:** Create a known-valid “Host reconciliation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C067-T03 · Injection map:** Locate the “Host reconciliation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Host reconciliation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C067-T05 · Controlled trigger:** Introduce the controlled “Host reconciliation” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C067-T06 · Intermediate inspection:** Inspect the “Host reconciliation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Host reconciliation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Host reconciliation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C067-T09 · Repeat and compare:** Repeat the selected “Host reconciliation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C067-T10 · Failure evidence:** Publish the “Host reconciliation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for observation tools and comparison samples; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Host reconciliation”: “Observation tools and comparison samples”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C068-T02 · Measurement method:** Choose how to observe each “Host reconciliation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Host reconciliation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Host reconciliation” cases for “Observation tools and comparison samples”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Host reconciliation” limit; preserve “Published resource totals reconcile within a documented measurement boundary”.
- [ ] **UC-M10.02-C068-T06 · Normal measurement:** Run or review the normal “Host reconciliation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C068-T07 · At-limit measurement:** Exercise the “Host reconciliation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C068-T08 · Over-limit measurement:** Exercise the “Host reconciliation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C068-T09 · Uncovered-scope report:** List the “Host reconciliation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C068-T10 · Limit evidence:** Publish the selected “Host reconciliation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for host reconciliation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C069-T01 · Event inventory:** List the “Host reconciliation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Host reconciliation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C069-T03 · Failure mapping:** Map each documented “Host reconciliation” refusal or error to a diagnostic outcome; include “Reported memory excludes a known active decoder process” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C069-T04 · Emission path:** Add the “Host reconciliation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C069-T05 · Redaction check:** Test “Host reconciliation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C069-T06 · Output budget:** Set and exercise bounded “Host reconciliation” message size, rate and retention compatible with “Observation tools and comparison samples”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C069-T07 · Success/refusal fixtures:** Capture “Host reconciliation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Host reconciliation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C069-T09 · Operator review:** Read the “Host reconciliation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C069-T10 · Diagnostic evidence:** Publish redacted “Host reconciliation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for host reconciliation; label unexecuted checks as untested.

- [ ] **UC-M10.02-C070-T01 · Evidence inventory:** List the “Host reconciliation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C070-T02 · Artifact references:** Record the exact “Host reconciliation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C070-T03 · Fixture references:** Attach the “Host reconciliation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Reported memory excludes a known active decoder process” as a distinct evidence case.
- [ ] **UC-M10.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Host reconciliation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C070-T05 · Environment record:** Record the actual “Host reconciliation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C070-T06 · Expected versus observed:** Pair every “Host reconciliation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C070-T07 · Failure and limit records:** Attach “Host reconciliation” change/failure and bounds evidence where required; include uncovered “Observation tools and comparison samples” and unresolved violations of “Published resource totals reconcile within a documented measurement boundary”.
- [ ] **UC-M10.02-C070-T08 · Evidence hygiene:** Check the “Host reconciliation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C070-T09 · Reproduction review:** Have the “Host reconciliation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C070-T10 · Acceptance linkage:** Link the “Host reconciliation” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Aggregation semantics

**Source delivery:** Specify rates, counters, distributions and reset behavior explicitly.

**Source invariant:** Aggregation preserves metric meaning across restart and generation changes.

**Source negative case:** A reset counter produces an impossible negative throughput.

**Source bounded quantities:** Aggregation windows and bucket count.

### UC-M10.02-C071 · Contract

**Original checklist item:** Specify aggregation semantics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C071-T01 · Scope statement:** Draft the operation boundary for “Aggregation semantics” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Aggregation semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C071-T03 · Output inventory:** List the outputs of “Aggregation semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Aggregation semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C071-T05 · Prerequisite contract:** Map “Aggregation semantics” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Aggregation semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C071-T07 · Invariant clause:** Add a normative clause for “Aggregation semantics” that preserves “Aggregation preserves metric meaning across restart and generation changes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Aggregation semantics”; include the source counterexample “A reset counter produces an impossible negative throughput” and the intended safe disposition.
- [ ] **UC-M10.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Aggregation windows and bucket count” in the “Aggregation semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C071-T10 · Contract review:** Review the “Aggregation semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C072 · Delivery

**Original checklist item:** Specify rates, counters, distributions and reset behavior explicitly.

- [ ] **UC-M10.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Aggregation semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C072-T02 · Change plan:** Break the source delivery for “Aggregation semantics” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C072-T03 · Core artifact:** Create the “Aggregation semantics” model, schema or inventory that realizes this source instruction: Specify rates, counters, distributions and reset behavior explicitly.
- [ ] **UC-M10.02-C072-T04 · Concrete realization:** Populate “Aggregation semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M10.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Aggregation semantics” needed to preserve “Aggregation preserves metric meaning across restart and generation changes”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C072-T06 · Dependency connection:** Connect the “Aggregation semantics” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C072-T07 · Resource behavior:** Account for “Aggregation windows and bucket count” in “Aggregation semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C072-T08 · Delivery check:** Run the smallest real “Aggregation semantics” path and its adverse fixture “A reset counter produces an impossible negative throughput”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C072-T09 · Patch review:** Review the “Aggregation semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C072-T10 · Delivery handoff:** Publish the “Aggregation semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Aggregation preserves metric meaning across restart and generation changes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Aggregation semantics”; copy its required invariant exactly: “Aggregation preserves metric meaning across restart and generation changes”.
- [ ] **UC-M10.02-C073-T02 · Observable terms:** Define each term in the “Aggregation semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C073-T03 · Precondition set:** List the preconditions under which “Aggregation preserves metric meaning across restart and generation changes” must hold for “Aggregation semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C073-T04 · Transition coverage:** Map the “Aggregation semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Aggregation semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C073-T06 · Satisfying fixture:** Create a concrete “Aggregation semantics” case that satisfies “Aggregation preserves metric meaning across restart and generation changes”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C073-T07 · Violating fixture:** Create the source counterexample “A reset counter produces an impossible negative throughput” for “Aggregation semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C073-T08 · Enforcement evidence:** Exercise the “Aggregation semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C073-T09 · Regression linkage:** Link the “Aggregation semantics” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Aggregation semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C074 · Integration

**Original checklist item:** Integrate aggregation semantics with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Aggregation semantics” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C074-T02 · Field mapping:** Map every “Aggregation semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Aggregation semantics” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C074-T04 · Ownership agreement:** Specify who owns “Aggregation semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C074-T05 · Handoff implementation:** Connect “Aggregation semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Aggregation preserves metric meaning across restart and generation changes” across the handoff.
- [ ] **UC-M10.02-C074-T06 · Absent-input case:** Omit one required “Aggregation semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C074-T07 · Stale-input case:** Supply an outdated “Aggregation semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Aggregation semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C074-T09 · Valid integration trace:** Run a valid “Aggregation semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C074-T10 · Seam review:** Reconcile the “Aggregation semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for aggregation semantics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Aggregation semantics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C075-T02 · Expected-result oracle:** Specify the “Aggregation semantics” expected result independently of the implementation output; include the property “Aggregation preserves metric meaning across restart and generation changes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C075-T03 · Fixture material:** Create the concrete “Aggregation semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C075-T04 · Target preparation:** Prepare the “Aggregation semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C075-T05 · Initial-state record:** Record the initial “Aggregation semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C075-T06 · Valid-path execution:** Execute the “Aggregation semantics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C075-T07 · Outcome comparison:** Compare every declared “Aggregation semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C075-T08 · State and bounds check:** Inspect the “Aggregation semantics” ownership/state effects and actual use of “Aggregation windows and bucket count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C075-T09 · Repeatability check:** Repeat the same “Aggregation semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C075-T10 · Positive evidence:** Attach the “Aggregation semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C076 · Negative test

**Original checklist item:** Negative case: A reset counter produces an impossible negative throughput. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Aggregation semantics” source counterexample: “A reset counter produces an impossible negative throughput”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Aggregation semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C076-T03 · Valid control:** Construct a valid “Aggregation semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C076-T04 · Minimal adverse input:** Derive the “Aggregation semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A reset counter produces an impossible negative throughput”; retain that change as reproducible data.
- [ ] **UC-M10.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Aggregation semantics”; require “Aggregation preserves metric meaning across restart and generation changes” and forbid a false-success verdict.
- [ ] **UC-M10.02-C076-T06 · Adverse execution:** Exercise the “Aggregation semantics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C076-T07 · Effect inspection:** Inspect “Aggregation semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C076-T08 · Refusal versus failure:** Confirm the “Aggregation semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C076-T09 · Reset and retention:** Restore only the disposable “Aggregation semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C076-T10 · Negative regression:** Register the “Aggregation semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C077 · Change / failure test

**Original checklist item:** Exercise aggregation semantics when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C077-T01 · Scenario record:** Write the “Aggregation semantics” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Aggregation preserves metric meaning across restart and generation changes”.
- [ ] **UC-M10.02-C077-T02 · Baseline capture:** Create a known-valid “Aggregation semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C077-T03 · Injection map:** Locate the “Aggregation semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Aggregation semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C077-T05 · Controlled trigger:** Introduce the controlled “Aggregation semantics” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C077-T06 · Intermediate inspection:** Inspect the “Aggregation semantics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Aggregation semantics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Aggregation semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C077-T09 · Repeat and compare:** Repeat the selected “Aggregation semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C077-T10 · Failure evidence:** Publish the “Aggregation semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for aggregation windows and bucket count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Aggregation semantics”: “Aggregation windows and bucket count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C078-T02 · Measurement method:** Choose how to observe each “Aggregation semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Aggregation semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Aggregation semantics” cases for “Aggregation windows and bucket count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Aggregation semantics” limit; preserve “Aggregation preserves metric meaning across restart and generation changes”.
- [ ] **UC-M10.02-C078-T06 · Normal measurement:** Run or review the normal “Aggregation semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C078-T07 · At-limit measurement:** Exercise the “Aggregation semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C078-T08 · Over-limit measurement:** Exercise the “Aggregation semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C078-T09 · Uncovered-scope report:** List the “Aggregation semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C078-T10 · Limit evidence:** Publish the selected “Aggregation semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for aggregation semantics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C079-T01 · Event inventory:** List the “Aggregation semantics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Aggregation semantics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C079-T03 · Failure mapping:** Map each documented “Aggregation semantics” refusal or error to a diagnostic outcome; include “A reset counter produces an impossible negative throughput” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C079-T04 · Emission path:** Add the “Aggregation semantics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C079-T05 · Redaction check:** Test “Aggregation semantics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C079-T06 · Output budget:** Set and exercise bounded “Aggregation semantics” message size, rate and retention compatible with “Aggregation windows and bucket count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C079-T07 · Success/refusal fixtures:** Capture “Aggregation semantics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Aggregation semantics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C079-T09 · Operator review:** Read the “Aggregation semantics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C079-T10 · Diagnostic evidence:** Publish redacted “Aggregation semantics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for aggregation semantics; label unexecuted checks as untested.

- [ ] **UC-M10.02-C080-T01 · Evidence inventory:** List the “Aggregation semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C080-T02 · Artifact references:** Record the exact “Aggregation semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C080-T03 · Fixture references:** Attach the “Aggregation semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A reset counter produces an impossible negative throughput” as a distinct evidence case.
- [ ] **UC-M10.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Aggregation semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C080-T05 · Environment record:** Record the actual “Aggregation semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C080-T06 · Expected versus observed:** Pair every “Aggregation semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C080-T07 · Failure and limit records:** Attach “Aggregation semantics” change/failure and bounds evidence where required; include uncovered “Aggregation windows and bucket count” and unresolved violations of “Aggregation preserves metric meaning across restart and generation changes”.
- [ ] **UC-M10.02-C080-T08 · Evidence hygiene:** Check the “Aggregation semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C080-T09 · Reproduction review:** Have the “Aggregation semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C080-T10 · Acceptance linkage:** Link the “Aggregation semantics” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Missing-data handling

**Source delivery:** Mark unavailable or stale measurements rather than inventing zeros.

**Source invariant:** Unknown resource use cannot appear as proven idle capacity.

**Source negative case:** A failed sampler reports zero memory use.

**Source bounded quantities:** Missing sample duration and diagnostic rate.

### UC-M10.02-C081 · Contract

**Original checklist item:** Specify missing-data handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C081-T01 · Scope statement:** Draft the operation boundary for “Missing-data handling” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Missing-data handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C081-T03 · Output inventory:** List the outputs of “Missing-data handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Missing-data handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C081-T05 · Prerequisite contract:** Map “Missing-data handling” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Missing-data handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C081-T07 · Invariant clause:** Add a normative clause for “Missing-data handling” that preserves “Unknown resource use cannot appear as proven idle capacity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Missing-data handling”; include the source counterexample “A failed sampler reports zero memory use” and the intended safe disposition.
- [ ] **UC-M10.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Missing sample duration and diagnostic rate” in the “Missing-data handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C081-T10 · Contract review:** Review the “Missing-data handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C082 · Delivery

**Original checklist item:** Mark unavailable or stale measurements rather than inventing zeros.

- [ ] **UC-M10.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Missing-data handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C082-T02 · Change plan:** Break the source delivery for “Missing-data handling” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Missing-data handling” that realizes this source instruction: Mark unavailable or stale measurements rather than inventing zeros.
- [ ] **UC-M10.02-C082-T04 · Concrete realization:** Trace “Missing-data handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M10.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Missing-data handling” needed to preserve “Unknown resource use cannot appear as proven idle capacity”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C082-T06 · Dependency connection:** Connect the “Missing-data handling” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C082-T07 · Resource behavior:** Account for “Missing sample duration and diagnostic rate” in “Missing-data handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C082-T08 · Delivery check:** Run the smallest real “Missing-data handling” path and its adverse fixture “A failed sampler reports zero memory use”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C082-T09 · Patch review:** Review the “Missing-data handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C082-T10 · Delivery handoff:** Publish the “Missing-data handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown resource use cannot appear as proven idle capacity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Missing-data handling”; copy its required invariant exactly: “Unknown resource use cannot appear as proven idle capacity”.
- [ ] **UC-M10.02-C083-T02 · Observable terms:** Define each term in the “Missing-data handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C083-T03 · Precondition set:** List the preconditions under which “Unknown resource use cannot appear as proven idle capacity” must hold for “Missing-data handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C083-T04 · Transition coverage:** Map the “Missing-data handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Missing-data handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C083-T06 · Satisfying fixture:** Create a concrete “Missing-data handling” case that satisfies “Unknown resource use cannot appear as proven idle capacity”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C083-T07 · Violating fixture:** Create the source counterexample “A failed sampler reports zero memory use” for “Missing-data handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C083-T08 · Enforcement evidence:** Exercise the “Missing-data handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C083-T09 · Regression linkage:** Link the “Missing-data handling” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Missing-data handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C084 · Integration

**Original checklist item:** Integrate missing-data handling with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Missing-data handling” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C084-T02 · Field mapping:** Map every “Missing-data handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Missing-data handling” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C084-T04 · Ownership agreement:** Specify who owns “Missing-data handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C084-T05 · Handoff implementation:** Connect “Missing-data handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown resource use cannot appear as proven idle capacity” across the handoff.
- [ ] **UC-M10.02-C084-T06 · Absent-input case:** Omit one required “Missing-data handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C084-T07 · Stale-input case:** Supply an outdated “Missing-data handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Missing-data handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C084-T09 · Valid integration trace:** Run a valid “Missing-data handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C084-T10 · Seam review:** Reconcile the “Missing-data handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for missing-data handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Missing-data handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C085-T02 · Expected-result oracle:** Specify the “Missing-data handling” expected result independently of the implementation output; include the property “Unknown resource use cannot appear as proven idle capacity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C085-T03 · Fixture material:** Create the concrete “Missing-data handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C085-T04 · Target preparation:** Prepare the “Missing-data handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C085-T05 · Initial-state record:** Record the initial “Missing-data handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C085-T06 · Valid-path execution:** Execute the “Missing-data handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C085-T07 · Outcome comparison:** Compare every declared “Missing-data handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C085-T08 · State and bounds check:** Inspect the “Missing-data handling” ownership/state effects and actual use of “Missing sample duration and diagnostic rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C085-T09 · Repeatability check:** Repeat the same “Missing-data handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C085-T10 · Positive evidence:** Attach the “Missing-data handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C086 · Negative test

**Original checklist item:** Negative case: A failed sampler reports zero memory use. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Missing-data handling” source counterexample: “A failed sampler reports zero memory use”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Missing-data handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C086-T03 · Valid control:** Construct a valid “Missing-data handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C086-T04 · Minimal adverse input:** Derive the “Missing-data handling” adverse fixture from the control with the smallest documented change needed to reproduce “A failed sampler reports zero memory use”; retain that change as reproducible data.
- [ ] **UC-M10.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Missing-data handling”; require “Unknown resource use cannot appear as proven idle capacity” and forbid a false-success verdict.
- [ ] **UC-M10.02-C086-T06 · Adverse execution:** Exercise the “Missing-data handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C086-T07 · Effect inspection:** Inspect “Missing-data handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C086-T08 · Refusal versus failure:** Confirm the “Missing-data handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C086-T09 · Reset and retention:** Restore only the disposable “Missing-data handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C086-T10 · Negative regression:** Register the “Missing-data handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C087 · Change / failure test

**Original checklist item:** Exercise missing-data handling when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C087-T01 · Scenario record:** Write the “Missing-data handling” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Unknown resource use cannot appear as proven idle capacity”.
- [ ] **UC-M10.02-C087-T02 · Baseline capture:** Create a known-valid “Missing-data handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C087-T03 · Injection map:** Locate the “Missing-data handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Missing-data handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C087-T05 · Controlled trigger:** Introduce the controlled “Missing-data handling” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C087-T06 · Intermediate inspection:** Inspect the “Missing-data handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Missing-data handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Missing-data handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C087-T09 · Repeat and compare:** Repeat the selected “Missing-data handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C087-T10 · Failure evidence:** Publish the “Missing-data handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for missing sample duration and diagnostic rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Missing-data handling”: “Missing sample duration and diagnostic rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C088-T02 · Measurement method:** Choose how to observe each “Missing-data handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Missing-data handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Missing-data handling” cases for “Missing sample duration and diagnostic rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Missing-data handling” limit; preserve “Unknown resource use cannot appear as proven idle capacity”.
- [ ] **UC-M10.02-C088-T06 · Normal measurement:** Run or review the normal “Missing-data handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C088-T07 · At-limit measurement:** Exercise the “Missing-data handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C088-T08 · Over-limit measurement:** Exercise the “Missing-data handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C088-T09 · Uncovered-scope report:** List the “Missing-data handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C088-T10 · Limit evidence:** Publish the selected “Missing-data handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for missing-data handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C089-T01 · Event inventory:** List the “Missing-data handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Missing-data handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C089-T03 · Failure mapping:** Map each documented “Missing-data handling” refusal or error to a diagnostic outcome; include “A failed sampler reports zero memory use” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C089-T04 · Emission path:** Add the “Missing-data handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C089-T05 · Redaction check:** Test “Missing-data handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C089-T06 · Output budget:** Set and exercise bounded “Missing-data handling” message size, rate and retention compatible with “Missing sample duration and diagnostic rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C089-T07 · Success/refusal fixtures:** Capture “Missing-data handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Missing-data handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C089-T09 · Operator review:** Read the “Missing-data handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C089-T10 · Diagnostic evidence:** Publish redacted “Missing-data handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for missing-data handling; label unexecuted checks as untested.

- [ ] **UC-M10.02-C090-T01 · Evidence inventory:** List the “Missing-data handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C090-T02 · Artifact references:** Record the exact “Missing-data handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C090-T03 · Fixture references:** Attach the “Missing-data handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed sampler reports zero memory use” as a distinct evidence case.
- [ ] **UC-M10.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Missing-data handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C090-T05 · Environment record:** Record the actual “Missing-data handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C090-T06 · Expected versus observed:** Pair every “Missing-data handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C090-T07 · Failure and limit records:** Attach “Missing-data handling” change/failure and bounds evidence where required; include uncovered “Missing sample duration and diagnostic rate” and unresolved violations of “Unknown resource use cannot appear as proven idle capacity”.
- [ ] **UC-M10.02-C090-T08 · Evidence hygiene:** Check the “Missing-data handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C090-T09 · Reproduction review:** Have the “Missing-data handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C090-T10 · Acceptance linkage:** Link the “Missing-data handling” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Metric qualification

**Source delivery:** Exercise measured workloads and verify timing, attribution and bounded series growth.

**Source invariant:** Metrics distinguish guest work from build, decode and control overhead.

**Source negative case:** A combined total is presented as guest-only consumption.

**Source bounded quantities:** Workload cases and observation duration.

### UC-M10.02-C091 · Contract

**Original checklist item:** Specify metric qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M10.02-C091-T01 · Scope statement:** Draft the operation boundary for “Metric qualification” within Resource and latency metrics; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M10.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Metric qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M10.02-C091-T03 · Output inventory:** List the outputs of “Metric qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M10.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Metric qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M10.02-C091-T05 · Prerequisite contract:** Map “Metric qualification” to the source component prerequisites (UC-M03.05, UC-M05.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M10.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Metric qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M10.02-C091-T07 · Invariant clause:** Add a normative clause for “Metric qualification” that preserves “Metrics distinguish guest work from build, decode and control overhead”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M10.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Metric qualification”; include the source counterexample “A combined total is presented as guest-only consumption” and the intended safe disposition.
- [ ] **UC-M10.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Workload cases and observation duration” in the “Metric qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M10.02-C091-T10 · Contract review:** Review the “Metric qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M10.02-C092 · Delivery

**Original checklist item:** Exercise measured workloads and verify timing, attribution and bounded series growth.

- [ ] **UC-M10.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Metric qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M10.02-C092-T02 · Change plan:** Break the source delivery for “Metric qualification” into concrete edit targets and reviewable outputs; keep the UC-M10.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M10.02-C092-T03 · Core artifact:** Create the “Metric qualification” fixture or harness for this source instruction: Exercise measured workloads and verify timing, attribution and bounded series growth.
- [ ] **UC-M10.02-C092-T04 · Concrete realization:** Connect the “Metric qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M10.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Metric qualification” needed to preserve “Metrics distinguish guest work from build, decode and control overhead”; record an enforcement gap where only a model exists.
- [ ] **UC-M10.02-C092-T06 · Dependency connection:** Connect the “Metric qualification” implementation to phase observations, host resource samplers and bounded metric aggregation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M10.02-C092-T07 · Resource behavior:** Account for “Workload cases and observation duration” in “Metric qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M10.02-C092-T08 · Delivery check:** Run the smallest real “Metric qualification” path and its adverse fixture “A combined total is presented as guest-only consumption”; retain actual output, state effects and final disposition.
- [ ] **UC-M10.02-C092-T09 · Patch review:** Review the “Metric qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M10.02-C092-T10 · Delivery handoff:** Publish the “Metric qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M10.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Metrics distinguish guest work from build, decode and control overhead. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M10.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Metric qualification”; copy its required invariant exactly: “Metrics distinguish guest work from build, decode and control overhead”.
- [ ] **UC-M10.02-C093-T02 · Observable terms:** Define each term in the “Metric qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M10.02-C093-T03 · Precondition set:** List the preconditions under which “Metrics distinguish guest work from build, decode and control overhead” must hold for “Metric qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M10.02-C093-T04 · Transition coverage:** Map the “Metric qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M10.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Metric qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M10.02-C093-T06 · Satisfying fixture:** Create a concrete “Metric qualification” case that satisfies “Metrics distinguish guest work from build, decode and control overhead”; record its expected observation before running the assertion or review.
- [ ] **UC-M10.02-C093-T07 · Violating fixture:** Create the source counterexample “A combined total is presented as guest-only consumption” for “Metric qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M10.02-C093-T08 · Enforcement evidence:** Exercise the “Metric qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M10.02-C093-T09 · Regression linkage:** Link the “Metric qualification” property to changes in phase observations, host resource samplers and bounded metric aggregation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M10.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Metric qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M10.02-C094 · Integration

**Original checklist item:** Integrate metric qualification with phase observations, host resource samplers and bounded metric aggregation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M10.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Metric qualification” across phase observations, host resource samplers and bounded metric aggregation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M10.02-C094-T02 · Field mapping:** Map every “Metric qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M10.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Metric qualification” (source dependency list: UC-M03.05, UC-M05.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M10.02-C094-T04 · Ownership agreement:** Specify who owns “Metric qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M10.02-C094-T05 · Handoff implementation:** Connect “Metric qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Metrics distinguish guest work from build, decode and control overhead” across the handoff.
- [ ] **UC-M10.02-C094-T06 · Absent-input case:** Omit one required “Metric qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M10.02-C094-T07 · Stale-input case:** Supply an outdated “Metric qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M10.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Metric qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M10.02-C094-T09 · Valid integration trace:** Run a valid “Metric qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M10.02-C094-T10 · Seam review:** Reconcile the “Metric qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M10.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for metric qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M10.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Metric qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M10.02-C095-T02 · Expected-result oracle:** Specify the “Metric qualification” expected result independently of the implementation output; include the property “Metrics distinguish guest work from build, decode and control overhead” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M10.02-C095-T03 · Fixture material:** Create the concrete “Metric qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M10.02-C095-T04 · Target preparation:** Prepare the “Metric qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M10.02-C095-T05 · Initial-state record:** Record the initial “Metric qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M10.02-C095-T06 · Valid-path execution:** Execute the “Metric qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M10.02-C095-T07 · Outcome comparison:** Compare every declared “Metric qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M10.02-C095-T08 · State and bounds check:** Inspect the “Metric qualification” ownership/state effects and actual use of “Workload cases and observation duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M10.02-C095-T09 · Repeatability check:** Repeat the same “Metric qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M10.02-C095-T10 · Positive evidence:** Attach the “Metric qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M10.02-C096 · Negative test

**Original checklist item:** Negative case: A combined total is presented as guest-only consumption. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M10.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Metric qualification” source counterexample: “A combined total is presented as guest-only consumption”; state which precondition or invariant it challenges.
- [ ] **UC-M10.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Metric qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M10.02-C096-T03 · Valid control:** Construct a valid “Metric qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M10.02-C096-T04 · Minimal adverse input:** Derive the “Metric qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A combined total is presented as guest-only consumption”; retain that change as reproducible data.
- [ ] **UC-M10.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Metric qualification”; require “Metrics distinguish guest work from build, decode and control overhead” and forbid a false-success verdict.
- [ ] **UC-M10.02-C096-T06 · Adverse execution:** Exercise the “Metric qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M10.02-C096-T07 · Effect inspection:** Inspect “Metric qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M10.02-C096-T08 · Refusal versus failure:** Confirm the “Metric qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M10.02-C096-T09 · Reset and retention:** Restore only the disposable “Metric qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M10.02-C096-T10 · Negative regression:** Register the “Metric qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M10.02-C097 · Change / failure test

**Original checklist item:** Exercise metric qualification when a sampler fails or a workload generation changes during measurement; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M10.02-C097-T01 · Scenario record:** Write the “Metric qualification” change/failure scenario exactly as supplied: a sampler fails or a workload generation changes during measurement; identify the property that must remain true: “Metrics distinguish guest work from build, decode and control overhead”.
- [ ] **UC-M10.02-C097-T02 · Baseline capture:** Create a known-valid “Metric qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M10.02-C097-T03 · Injection map:** Locate the “Metric qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M10.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Metric qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M10.02-C097-T05 · Controlled trigger:** Introduce the controlled “Metric qualification” scenario in the disposable fixture: a sampler fails or a workload generation changes during measurement; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M10.02-C097-T06 · Intermediate inspection:** Inspect the “Metric qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M10.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Metric qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M10.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Metric qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M10.02-C097-T09 · Repeat and compare:** Repeat the selected “Metric qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M10.02-C097-T10 · Failure evidence:** Publish the “Metric qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M10.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for workload cases and observation duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M10.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Metric qualification”: “Workload cases and observation duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M10.02-C098-T02 · Measurement method:** Choose how to observe each “Metric qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M10.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Metric qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M10.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Metric qualification” cases for “Workload cases and observation duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M10.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Metric qualification” limit; preserve “Metrics distinguish guest work from build, decode and control overhead”.
- [ ] **UC-M10.02-C098-T06 · Normal measurement:** Run or review the normal “Metric qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M10.02-C098-T07 · At-limit measurement:** Exercise the “Metric qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M10.02-C098-T08 · Over-limit measurement:** Exercise the “Metric qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M10.02-C098-T09 · Uncovered-scope report:** List the “Metric qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M10.02-C098-T10 · Limit evidence:** Publish the selected “Metric qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M10.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for metric qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M10.02-C099-T01 · Event inventory:** List the “Metric qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M10.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Metric qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M10.02-C099-T03 · Failure mapping:** Map each documented “Metric qualification” refusal or error to a diagnostic outcome; include “A combined total is presented as guest-only consumption” and prohibit conversion into a success message.
- [ ] **UC-M10.02-C099-T04 · Emission path:** Add the “Metric qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M10.02-C099-T05 · Redaction check:** Test “Metric qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M10.02-C099-T06 · Output budget:** Set and exercise bounded “Metric qualification” message size, rate and retention compatible with “Workload cases and observation duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M10.02-C099-T07 · Success/refusal fixtures:** Capture “Metric qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M10.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Metric qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M10.02-C099-T09 · Operator review:** Read the “Metric qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M10.02-C099-T10 · Diagnostic evidence:** Publish redacted “Metric qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M10.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for metric qualification; label unexecuted checks as untested.

- [ ] **UC-M10.02-C100-T01 · Evidence inventory:** List the “Metric qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M10.02-C100-T02 · Artifact references:** Record the exact “Metric qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M10.02-C100-T03 · Fixture references:** Attach the “Metric qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A combined total is presented as guest-only consumption” as a distinct evidence case.
- [ ] **UC-M10.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Metric qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M10.02-C100-T05 · Environment record:** Record the actual “Metric qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M10.02-C100-T06 · Expected versus observed:** Pair every “Metric qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M10.02-C100-T07 · Failure and limit records:** Attach “Metric qualification” change/failure and bounds evidence where required; include uncovered “Workload cases and observation duration” and unresolved violations of “Metrics distinguish guest work from build, decode and control overhead”.
- [ ] **UC-M10.02-C100-T08 · Evidence hygiene:** Check the “Metric qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M10.02-C100-T09 · Reproduction review:** Have the “Metric qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M10.02-C100-T10 · Acceptance linkage:** Link the “Metric qualification” evidence to its parent and UC-M10.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

