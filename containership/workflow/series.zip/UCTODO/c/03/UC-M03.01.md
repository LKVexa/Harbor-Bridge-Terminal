# UC-M03.01 — Pluggable execution backend boundary

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/03.md)

| Field | Preserved source value |
|---|---|
| Workstream | 03. Host isolation and supervision |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.02](../01/UC-M01.02.md), [UC-M02.08](../02/UC-M02.08.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S3], [S4]. |

## Original requirement

Separate host-process adapters from actual guest backends; expose explicit isolation classes and capability negotiation.

**Original acceptance criterion:** An isolation-required workload cannot silently fall back to an in-process or ordinary subprocess adapter.

**Source trace:** Original checklist `UC100/c/03/UC-M03.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 239–249 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Backend interface

**Source delivery:** Define separate adapter operations for prepare, boot, invoke, inspect, stop and release.

**Source invariant:** All adapters implement the same declared lifecycle semantics.

**Source negative case:** An adapter reports success without performing the requested operation.

**Source bounded quantities:** Operation count and request payload size.

### UC-M03.01-C001 · Contract

**Original checklist item:** Specify backend interface inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C001-T01 · Scope statement:** Draft the operation boundary for “Backend interface” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backend interface”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C001-T03 · Output inventory:** List the outputs of “Backend interface” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Backend interface”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C001-T05 · Prerequisite contract:** Map “Backend interface” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Backend interface”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C001-T07 · Invariant clause:** Add a normative clause for “Backend interface” that preserves “All adapters implement the same declared lifecycle semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backend interface”; include the source counterexample “An adapter reports success without performing the requested operation” and the intended safe disposition.
- [ ] **UC-M03.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Operation count and request payload size” in the “Backend interface” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C001-T10 · Contract review:** Review the “Backend interface” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C002 · Delivery

**Original checklist item:** Define separate adapter operations for prepare, boot, invoke, inspect, stop and release.

- [ ] **UC-M03.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backend interface”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C002-T02 · Change plan:** Break the source delivery for “Backend interface” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C002-T03 · Core artifact:** Create the “Backend interface” model, schema or inventory that realizes this source instruction: Define separate adapter operations for prepare, boot, invoke, inspect, stop and release.
- [ ] **UC-M03.01-C002-T04 · Concrete realization:** Populate “Backend interface” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backend interface” needed to preserve “All adapters implement the same declared lifecycle semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C002-T06 · Dependency connection:** Connect the “Backend interface” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C002-T07 · Resource behavior:** Account for “Operation count and request payload size” in “Backend interface”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C002-T08 · Delivery check:** Run the smallest real “Backend interface” path and its adverse fixture “An adapter reports success without performing the requested operation”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C002-T09 · Patch review:** Review the “Backend interface” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C002-T10 · Delivery handoff:** Publish the “Backend interface” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: All adapters implement the same declared lifecycle semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Backend interface”; copy its required invariant exactly: “All adapters implement the same declared lifecycle semantics”.
- [ ] **UC-M03.01-C003-T02 · Observable terms:** Define each term in the “Backend interface” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C003-T03 · Precondition set:** List the preconditions under which “All adapters implement the same declared lifecycle semantics” must hold for “Backend interface”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C003-T04 · Transition coverage:** Map the “Backend interface” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backend interface”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C003-T06 · Satisfying fixture:** Create a concrete “Backend interface” case that satisfies “All adapters implement the same declared lifecycle semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C003-T07 · Violating fixture:** Create the source counterexample “An adapter reports success without performing the requested operation” for “Backend interface”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C003-T08 · Enforcement evidence:** Exercise the “Backend interface” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C003-T09 · Regression linkage:** Link the “Backend interface” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Backend interface” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C004 · Integration

**Original checklist item:** Integrate backend interface with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backend interface” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C004-T02 · Field mapping:** Map every “Backend interface” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Backend interface” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C004-T04 · Ownership agreement:** Specify who owns “Backend interface” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C004-T05 · Handoff implementation:** Connect “Backend interface” through the mapped seam using the real adapter or explicit specification reference; preserve “All adapters implement the same declared lifecycle semantics” across the handoff.
- [ ] **UC-M03.01-C004-T06 · Absent-input case:** Omit one required “Backend interface” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C004-T07 · Stale-input case:** Supply an outdated “Backend interface” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Backend interface” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C004-T09 · Valid integration trace:** Run a valid “Backend interface” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C004-T10 · Seam review:** Reconcile the “Backend interface” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for backend interface; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Backend interface” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C005-T02 · Expected-result oracle:** Specify the “Backend interface” expected result independently of the implementation output; include the property “All adapters implement the same declared lifecycle semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C005-T03 · Fixture material:** Create the concrete “Backend interface” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C005-T04 · Target preparation:** Prepare the “Backend interface” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C005-T05 · Initial-state record:** Record the initial “Backend interface” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C005-T06 · Valid-path execution:** Execute the “Backend interface” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C005-T07 · Outcome comparison:** Compare every declared “Backend interface” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C005-T08 · State and bounds check:** Inspect the “Backend interface” ownership/state effects and actual use of “Operation count and request payload size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C005-T09 · Repeatability check:** Repeat the same “Backend interface” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C005-T10 · Positive evidence:** Attach the “Backend interface” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C006 · Negative test

**Original checklist item:** Negative case: An adapter reports success without performing the requested operation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Backend interface” source counterexample: “An adapter reports success without performing the requested operation”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Backend interface”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C006-T03 · Valid control:** Construct a valid “Backend interface” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C006-T04 · Minimal adverse input:** Derive the “Backend interface” adverse fixture from the control with the smallest documented change needed to reproduce “An adapter reports success without performing the requested operation”; retain that change as reproducible data.
- [ ] **UC-M03.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backend interface”; require “All adapters implement the same declared lifecycle semantics” and forbid a false-success verdict.
- [ ] **UC-M03.01-C006-T06 · Adverse execution:** Exercise the “Backend interface” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C006-T07 · Effect inspection:** Inspect “Backend interface” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C006-T08 · Refusal versus failure:** Confirm the “Backend interface” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C006-T09 · Reset and retention:** Restore only the disposable “Backend interface” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C006-T10 · Negative regression:** Register the “Backend interface” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C007 · Change / failure test

**Original checklist item:** Exercise backend interface when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C007-T01 · Scenario record:** Write the “Backend interface” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “All adapters implement the same declared lifecycle semantics”.
- [ ] **UC-M03.01-C007-T02 · Baseline capture:** Create a known-valid “Backend interface” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C007-T03 · Injection map:** Locate the “Backend interface” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Backend interface” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C007-T05 · Controlled trigger:** Introduce the controlled “Backend interface” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C007-T06 · Intermediate inspection:** Inspect the “Backend interface” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backend interface”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Backend interface” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C007-T09 · Repeat and compare:** Repeat the selected “Backend interface” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C007-T10 · Failure evidence:** Publish the “Backend interface” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for operation count and request payload size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Backend interface”: “Operation count and request payload size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C008-T02 · Measurement method:** Choose how to observe each “Backend interface” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Backend interface”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backend interface” cases for “Operation count and request payload size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backend interface” limit; preserve “All adapters implement the same declared lifecycle semantics”.
- [ ] **UC-M03.01-C008-T06 · Normal measurement:** Run or review the normal “Backend interface” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C008-T07 · At-limit measurement:** Exercise the “Backend interface” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C008-T08 · Over-limit measurement:** Exercise the “Backend interface” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C008-T09 · Uncovered-scope report:** List the “Backend interface” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C008-T10 · Limit evidence:** Publish the selected “Backend interface” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for backend interface with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C009-T01 · Event inventory:** List the “Backend interface” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Backend interface” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C009-T03 · Failure mapping:** Map each documented “Backend interface” refusal or error to a diagnostic outcome; include “An adapter reports success without performing the requested operation” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C009-T04 · Emission path:** Add the “Backend interface” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C009-T05 · Redaction check:** Test “Backend interface” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C009-T06 · Output budget:** Set and exercise bounded “Backend interface” message size, rate and retention compatible with “Operation count and request payload size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C009-T07 · Success/refusal fixtures:** Capture “Backend interface” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Backend interface” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C009-T09 · Operator review:** Read the “Backend interface” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C009-T10 · Diagnostic evidence:** Publish redacted “Backend interface” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backend interface; label unexecuted checks as untested.

- [ ] **UC-M03.01-C010-T01 · Evidence inventory:** List the “Backend interface” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C010-T02 · Artifact references:** Record the exact “Backend interface” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C010-T03 · Fixture references:** Attach the “Backend interface” fixture IDs, input identities and oracle definition; preserve the source counterexample “An adapter reports success without performing the requested operation” as a distinct evidence case.
- [ ] **UC-M03.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backend interface”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C010-T05 · Environment record:** Record the actual “Backend interface” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C010-T06 · Expected versus observed:** Pair every “Backend interface” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C010-T07 · Failure and limit records:** Attach “Backend interface” change/failure and bounds evidence where required; include uncovered “Operation count and request payload size” and unresolved violations of “All adapters implement the same declared lifecycle semantics”.
- [ ] **UC-M03.01-C010-T08 · Evidence hygiene:** Check the “Backend interface” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C010-T09 · Reproduction review:** Have the “Backend interface” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C010-T10 · Acceptance linkage:** Link the “Backend interface” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Isolation class taxonomy

**Source delivery:** Name host-process and actual guest isolation classes separately.

**Source invariant:** An ordinary subprocess cannot advertise a guest boundary.

**Source negative case:** A process adapter claims hypervisor isolation through configuration alone.

**Source bounded quantities:** Class count and supported backend profiles.

### UC-M03.01-C011 · Contract

**Original checklist item:** Specify isolation class taxonomy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C011-T01 · Scope statement:** Draft the operation boundary for “Isolation class taxonomy” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Isolation class taxonomy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C011-T03 · Output inventory:** List the outputs of “Isolation class taxonomy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Isolation class taxonomy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C011-T05 · Prerequisite contract:** Map “Isolation class taxonomy” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Isolation class taxonomy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C011-T07 · Invariant clause:** Add a normative clause for “Isolation class taxonomy” that preserves “An ordinary subprocess cannot advertise a guest boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Isolation class taxonomy”; include the source counterexample “A process adapter claims hypervisor isolation through configuration alone” and the intended safe disposition.
- [ ] **UC-M03.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Class count and supported backend profiles” in the “Isolation class taxonomy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C011-T10 · Contract review:** Review the “Isolation class taxonomy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C012 · Delivery

**Original checklist item:** Name host-process and actual guest isolation classes separately.

- [ ] **UC-M03.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Isolation class taxonomy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C012-T02 · Change plan:** Break the source delivery for “Isolation class taxonomy” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Isolation class taxonomy” that realizes this source instruction: Name host-process and actual guest isolation classes separately.
- [ ] **UC-M03.01-C012-T04 · Concrete realization:** Trace “Isolation class taxonomy” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Isolation class taxonomy” needed to preserve “An ordinary subprocess cannot advertise a guest boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C012-T06 · Dependency connection:** Connect the “Isolation class taxonomy” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C012-T07 · Resource behavior:** Account for “Class count and supported backend profiles” in “Isolation class taxonomy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C012-T08 · Delivery check:** Run the smallest real “Isolation class taxonomy” path and its adverse fixture “A process adapter claims hypervisor isolation through configuration alone”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C012-T09 · Patch review:** Review the “Isolation class taxonomy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C012-T10 · Delivery handoff:** Publish the “Isolation class taxonomy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An ordinary subprocess cannot advertise a guest boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Isolation class taxonomy”; copy its required invariant exactly: “An ordinary subprocess cannot advertise a guest boundary”.
- [ ] **UC-M03.01-C013-T02 · Observable terms:** Define each term in the “Isolation class taxonomy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C013-T03 · Precondition set:** List the preconditions under which “An ordinary subprocess cannot advertise a guest boundary” must hold for “Isolation class taxonomy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C013-T04 · Transition coverage:** Map the “Isolation class taxonomy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Isolation class taxonomy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C013-T06 · Satisfying fixture:** Create a concrete “Isolation class taxonomy” case that satisfies “An ordinary subprocess cannot advertise a guest boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C013-T07 · Violating fixture:** Create the source counterexample “A process adapter claims hypervisor isolation through configuration alone” for “Isolation class taxonomy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C013-T08 · Enforcement evidence:** Exercise the “Isolation class taxonomy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C013-T09 · Regression linkage:** Link the “Isolation class taxonomy” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Isolation class taxonomy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C014 · Integration

**Original checklist item:** Integrate isolation class taxonomy with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Isolation class taxonomy” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C014-T02 · Field mapping:** Map every “Isolation class taxonomy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Isolation class taxonomy” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C014-T04 · Ownership agreement:** Specify who owns “Isolation class taxonomy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C014-T05 · Handoff implementation:** Connect “Isolation class taxonomy” through the mapped seam using the real adapter or explicit specification reference; preserve “An ordinary subprocess cannot advertise a guest boundary” across the handoff.
- [ ] **UC-M03.01-C014-T06 · Absent-input case:** Omit one required “Isolation class taxonomy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C014-T07 · Stale-input case:** Supply an outdated “Isolation class taxonomy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Isolation class taxonomy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C014-T09 · Valid integration trace:** Run a valid “Isolation class taxonomy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C014-T10 · Seam review:** Reconcile the “Isolation class taxonomy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for isolation class taxonomy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Isolation class taxonomy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C015-T02 · Expected-result oracle:** Specify the “Isolation class taxonomy” expected result independently of the implementation output; include the property “An ordinary subprocess cannot advertise a guest boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C015-T03 · Fixture material:** Create the concrete “Isolation class taxonomy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C015-T04 · Target preparation:** Prepare the “Isolation class taxonomy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C015-T05 · Initial-state record:** Record the initial “Isolation class taxonomy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C015-T06 · Valid-path execution:** Execute the “Isolation class taxonomy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C015-T07 · Outcome comparison:** Compare every declared “Isolation class taxonomy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C015-T08 · State and bounds check:** Inspect the “Isolation class taxonomy” ownership/state effects and actual use of “Class count and supported backend profiles”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C015-T09 · Repeatability check:** Repeat the same “Isolation class taxonomy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C015-T10 · Positive evidence:** Attach the “Isolation class taxonomy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C016 · Negative test

**Original checklist item:** Negative case: A process adapter claims hypervisor isolation through configuration alone. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Isolation class taxonomy” source counterexample: “A process adapter claims hypervisor isolation through configuration alone”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Isolation class taxonomy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C016-T03 · Valid control:** Construct a valid “Isolation class taxonomy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C016-T04 · Minimal adverse input:** Derive the “Isolation class taxonomy” adverse fixture from the control with the smallest documented change needed to reproduce “A process adapter claims hypervisor isolation through configuration alone”; retain that change as reproducible data.
- [ ] **UC-M03.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Isolation class taxonomy”; require “An ordinary subprocess cannot advertise a guest boundary” and forbid a false-success verdict.
- [ ] **UC-M03.01-C016-T06 · Adverse execution:** Exercise the “Isolation class taxonomy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C016-T07 · Effect inspection:** Inspect “Isolation class taxonomy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C016-T08 · Refusal versus failure:** Confirm the “Isolation class taxonomy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C016-T09 · Reset and retention:** Restore only the disposable “Isolation class taxonomy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C016-T10 · Negative regression:** Register the “Isolation class taxonomy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C017 · Change / failure test

**Original checklist item:** Exercise isolation class taxonomy when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C017-T01 · Scenario record:** Write the “Isolation class taxonomy” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “An ordinary subprocess cannot advertise a guest boundary”.
- [ ] **UC-M03.01-C017-T02 · Baseline capture:** Create a known-valid “Isolation class taxonomy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C017-T03 · Injection map:** Locate the “Isolation class taxonomy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Isolation class taxonomy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C017-T05 · Controlled trigger:** Introduce the controlled “Isolation class taxonomy” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C017-T06 · Intermediate inspection:** Inspect the “Isolation class taxonomy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Isolation class taxonomy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Isolation class taxonomy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C017-T09 · Repeat and compare:** Repeat the selected “Isolation class taxonomy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C017-T10 · Failure evidence:** Publish the “Isolation class taxonomy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for class count and supported backend profiles; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Isolation class taxonomy”: “Class count and supported backend profiles”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C018-T02 · Measurement method:** Choose how to observe each “Isolation class taxonomy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Isolation class taxonomy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Isolation class taxonomy” cases for “Class count and supported backend profiles”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Isolation class taxonomy” limit; preserve “An ordinary subprocess cannot advertise a guest boundary”.
- [ ] **UC-M03.01-C018-T06 · Normal measurement:** Run or review the normal “Isolation class taxonomy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C018-T07 · At-limit measurement:** Exercise the “Isolation class taxonomy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C018-T08 · Over-limit measurement:** Exercise the “Isolation class taxonomy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C018-T09 · Uncovered-scope report:** List the “Isolation class taxonomy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C018-T10 · Limit evidence:** Publish the selected “Isolation class taxonomy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for isolation class taxonomy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C019-T01 · Event inventory:** List the “Isolation class taxonomy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Isolation class taxonomy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C019-T03 · Failure mapping:** Map each documented “Isolation class taxonomy” refusal or error to a diagnostic outcome; include “A process adapter claims hypervisor isolation through configuration alone” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C019-T04 · Emission path:** Add the “Isolation class taxonomy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C019-T05 · Redaction check:** Test “Isolation class taxonomy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C019-T06 · Output budget:** Set and exercise bounded “Isolation class taxonomy” message size, rate and retention compatible with “Class count and supported backend profiles”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C019-T07 · Success/refusal fixtures:** Capture “Isolation class taxonomy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Isolation class taxonomy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C019-T09 · Operator review:** Read the “Isolation class taxonomy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C019-T10 · Diagnostic evidence:** Publish redacted “Isolation class taxonomy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for isolation class taxonomy; label unexecuted checks as untested.

- [ ] **UC-M03.01-C020-T01 · Evidence inventory:** List the “Isolation class taxonomy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C020-T02 · Artifact references:** Record the exact “Isolation class taxonomy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C020-T03 · Fixture references:** Attach the “Isolation class taxonomy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A process adapter claims hypervisor isolation through configuration alone” as a distinct evidence case.
- [ ] **UC-M03.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Isolation class taxonomy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C020-T05 · Environment record:** Record the actual “Isolation class taxonomy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C020-T06 · Expected versus observed:** Pair every “Isolation class taxonomy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C020-T07 · Failure and limit records:** Attach “Isolation class taxonomy” change/failure and bounds evidence where required; include uncovered “Class count and supported backend profiles” and unresolved violations of “An ordinary subprocess cannot advertise a guest boundary”.
- [ ] **UC-M03.01-C020-T08 · Evidence hygiene:** Check the “Isolation class taxonomy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C020-T09 · Reproduction review:** Have the “Isolation class taxonomy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C020-T10 · Acceptance linkage:** Link the “Isolation class taxonomy” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Capability advertisement

**Source delivery:** Expose supported devices, snapshots, architectures and resource controls per backend.

**Source invariant:** Advertised capabilities correspond to exercised implementation paths.

**Source negative case:** A backend advertises an unimplemented snapshot capability.

**Source bounded quantities:** Capability count and probe cost.

### UC-M03.01-C021 · Contract

**Original checklist item:** Specify capability advertisement inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C021-T01 · Scope statement:** Draft the operation boundary for “Capability advertisement” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capability advertisement”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C021-T03 · Output inventory:** List the outputs of “Capability advertisement” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Capability advertisement”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C021-T05 · Prerequisite contract:** Map “Capability advertisement” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Capability advertisement”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C021-T07 · Invariant clause:** Add a normative clause for “Capability advertisement” that preserves “Advertised capabilities correspond to exercised implementation paths”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capability advertisement”; include the source counterexample “A backend advertises an unimplemented snapshot capability” and the intended safe disposition.
- [ ] **UC-M03.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capability count and probe cost” in the “Capability advertisement” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C021-T10 · Contract review:** Review the “Capability advertisement” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C022 · Delivery

**Original checklist item:** Expose supported devices, snapshots, architectures and resource controls per backend.

- [ ] **UC-M03.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capability advertisement”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C022-T02 · Change plan:** Break the source delivery for “Capability advertisement” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Capability advertisement” that realizes this source instruction: Expose supported devices, snapshots, architectures and resource controls per backend.
- [ ] **UC-M03.01-C022-T04 · Concrete realization:** Trace “Capability advertisement” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capability advertisement” needed to preserve “Advertised capabilities correspond to exercised implementation paths”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C022-T06 · Dependency connection:** Connect the “Capability advertisement” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C022-T07 · Resource behavior:** Account for “Capability count and probe cost” in “Capability advertisement”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C022-T08 · Delivery check:** Run the smallest real “Capability advertisement” path and its adverse fixture “A backend advertises an unimplemented snapshot capability”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C022-T09 · Patch review:** Review the “Capability advertisement” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C022-T10 · Delivery handoff:** Publish the “Capability advertisement” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Advertised capabilities correspond to exercised implementation paths. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Capability advertisement”; copy its required invariant exactly: “Advertised capabilities correspond to exercised implementation paths”.
- [ ] **UC-M03.01-C023-T02 · Observable terms:** Define each term in the “Capability advertisement” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C023-T03 · Precondition set:** List the preconditions under which “Advertised capabilities correspond to exercised implementation paths” must hold for “Capability advertisement”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C023-T04 · Transition coverage:** Map the “Capability advertisement” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capability advertisement”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C023-T06 · Satisfying fixture:** Create a concrete “Capability advertisement” case that satisfies “Advertised capabilities correspond to exercised implementation paths”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C023-T07 · Violating fixture:** Create the source counterexample “A backend advertises an unimplemented snapshot capability” for “Capability advertisement”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C023-T08 · Enforcement evidence:** Exercise the “Capability advertisement” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C023-T09 · Regression linkage:** Link the “Capability advertisement” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Capability advertisement” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C024 · Integration

**Original checklist item:** Integrate capability advertisement with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capability advertisement” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C024-T02 · Field mapping:** Map every “Capability advertisement” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Capability advertisement” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C024-T04 · Ownership agreement:** Specify who owns “Capability advertisement” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C024-T05 · Handoff implementation:** Connect “Capability advertisement” through the mapped seam using the real adapter or explicit specification reference; preserve “Advertised capabilities correspond to exercised implementation paths” across the handoff.
- [ ] **UC-M03.01-C024-T06 · Absent-input case:** Omit one required “Capability advertisement” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C024-T07 · Stale-input case:** Supply an outdated “Capability advertisement” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Capability advertisement” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C024-T09 · Valid integration trace:** Run a valid “Capability advertisement” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C024-T10 · Seam review:** Reconcile the “Capability advertisement” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capability advertisement; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capability advertisement” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C025-T02 · Expected-result oracle:** Specify the “Capability advertisement” expected result independently of the implementation output; include the property “Advertised capabilities correspond to exercised implementation paths” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C025-T03 · Fixture material:** Create the concrete “Capability advertisement” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C025-T04 · Target preparation:** Prepare the “Capability advertisement” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C025-T05 · Initial-state record:** Record the initial “Capability advertisement” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C025-T06 · Valid-path execution:** Execute the “Capability advertisement” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C025-T07 · Outcome comparison:** Compare every declared “Capability advertisement” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C025-T08 · State and bounds check:** Inspect the “Capability advertisement” ownership/state effects and actual use of “Capability count and probe cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C025-T09 · Repeatability check:** Repeat the same “Capability advertisement” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C025-T10 · Positive evidence:** Attach the “Capability advertisement” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C026 · Negative test

**Original checklist item:** Negative case: A backend advertises an unimplemented snapshot capability. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Capability advertisement” source counterexample: “A backend advertises an unimplemented snapshot capability”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Capability advertisement”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C026-T03 · Valid control:** Construct a valid “Capability advertisement” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C026-T04 · Minimal adverse input:** Derive the “Capability advertisement” adverse fixture from the control with the smallest documented change needed to reproduce “A backend advertises an unimplemented snapshot capability”; retain that change as reproducible data.
- [ ] **UC-M03.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capability advertisement”; require “Advertised capabilities correspond to exercised implementation paths” and forbid a false-success verdict.
- [ ] **UC-M03.01-C026-T06 · Adverse execution:** Exercise the “Capability advertisement” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C026-T07 · Effect inspection:** Inspect “Capability advertisement” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C026-T08 · Refusal versus failure:** Confirm the “Capability advertisement” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C026-T09 · Reset and retention:** Restore only the disposable “Capability advertisement” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C026-T10 · Negative regression:** Register the “Capability advertisement” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C027 · Change / failure test

**Original checklist item:** Exercise capability advertisement when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C027-T01 · Scenario record:** Write the “Capability advertisement” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “Advertised capabilities correspond to exercised implementation paths”.
- [ ] **UC-M03.01-C027-T02 · Baseline capture:** Create a known-valid “Capability advertisement” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C027-T03 · Injection map:** Locate the “Capability advertisement” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Capability advertisement” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C027-T05 · Controlled trigger:** Introduce the controlled “Capability advertisement” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C027-T06 · Intermediate inspection:** Inspect the “Capability advertisement” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capability advertisement”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Capability advertisement” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C027-T09 · Repeat and compare:** Repeat the selected “Capability advertisement” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C027-T10 · Failure evidence:** Publish the “Capability advertisement” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for capability count and probe cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Capability advertisement”: “Capability count and probe cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C028-T02 · Measurement method:** Choose how to observe each “Capability advertisement” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Capability advertisement”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capability advertisement” cases for “Capability count and probe cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capability advertisement” limit; preserve “Advertised capabilities correspond to exercised implementation paths”.
- [ ] **UC-M03.01-C028-T06 · Normal measurement:** Run or review the normal “Capability advertisement” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C028-T07 · At-limit measurement:** Exercise the “Capability advertisement” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C028-T08 · Over-limit measurement:** Exercise the “Capability advertisement” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C028-T09 · Uncovered-scope report:** List the “Capability advertisement” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C028-T10 · Limit evidence:** Publish the selected “Capability advertisement” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capability advertisement with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C029-T01 · Event inventory:** List the “Capability advertisement” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Capability advertisement” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C029-T03 · Failure mapping:** Map each documented “Capability advertisement” refusal or error to a diagnostic outcome; include “A backend advertises an unimplemented snapshot capability” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C029-T04 · Emission path:** Add the “Capability advertisement” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C029-T05 · Redaction check:** Test “Capability advertisement” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C029-T06 · Output budget:** Set and exercise bounded “Capability advertisement” message size, rate and retention compatible with “Capability count and probe cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C029-T07 · Success/refusal fixtures:** Capture “Capability advertisement” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capability advertisement” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C029-T09 · Operator review:** Read the “Capability advertisement” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C029-T10 · Diagnostic evidence:** Publish redacted “Capability advertisement” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capability advertisement; label unexecuted checks as untested.

- [ ] **UC-M03.01-C030-T01 · Evidence inventory:** List the “Capability advertisement” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C030-T02 · Artifact references:** Record the exact “Capability advertisement” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C030-T03 · Fixture references:** Attach the “Capability advertisement” fixture IDs, input identities and oracle definition; preserve the source counterexample “A backend advertises an unimplemented snapshot capability” as a distinct evidence case.
- [ ] **UC-M03.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capability advertisement”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C030-T05 · Environment record:** Record the actual “Capability advertisement” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C030-T06 · Expected versus observed:** Pair every “Capability advertisement” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C030-T07 · Failure and limit records:** Attach “Capability advertisement” change/failure and bounds evidence where required; include uncovered “Capability count and probe cost” and unresolved violations of “Advertised capabilities correspond to exercised implementation paths”.
- [ ] **UC-M03.01-C030-T08 · Evidence hygiene:** Check the “Capability advertisement” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C030-T09 · Reproduction review:** Have the “Capability advertisement” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C030-T10 · Acceptance linkage:** Link the “Capability advertisement” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Mandatory capability admission

**Source delivery:** Reject requests whose required capabilities are not available.

**Source invariant:** Required isolation cannot be silently downgraded.

**Source negative case:** An isolation-required request falls back to a subprocess.

**Source bounded quantities:** Admission time and capability comparison size.

### UC-M03.01-C031 · Contract

**Original checklist item:** Specify mandatory capability admission inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C031-T01 · Scope statement:** Draft the operation boundary for “Mandatory capability admission” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Mandatory capability admission”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C031-T03 · Output inventory:** List the outputs of “Mandatory capability admission” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Mandatory capability admission”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C031-T05 · Prerequisite contract:** Map “Mandatory capability admission” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Mandatory capability admission”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C031-T07 · Invariant clause:** Add a normative clause for “Mandatory capability admission” that preserves “Required isolation cannot be silently downgraded”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Mandatory capability admission”; include the source counterexample “An isolation-required request falls back to a subprocess” and the intended safe disposition.
- [ ] **UC-M03.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Admission time and capability comparison size” in the “Mandatory capability admission” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C031-T10 · Contract review:** Review the “Mandatory capability admission” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C032 · Delivery

**Original checklist item:** Reject requests whose required capabilities are not available.

- [ ] **UC-M03.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Mandatory capability admission”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C032-T02 · Change plan:** Break the source delivery for “Mandatory capability admission” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Mandatory capability admission” that realizes this source instruction: Reject requests whose required capabilities are not available.
- [ ] **UC-M03.01-C032-T04 · Concrete realization:** Trace “Mandatory capability admission” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Mandatory capability admission” needed to preserve “Required isolation cannot be silently downgraded”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C032-T06 · Dependency connection:** Connect the “Mandatory capability admission” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C032-T07 · Resource behavior:** Account for “Admission time and capability comparison size” in “Mandatory capability admission”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C032-T08 · Delivery check:** Run the smallest real “Mandatory capability admission” path and its adverse fixture “An isolation-required request falls back to a subprocess”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C032-T09 · Patch review:** Review the “Mandatory capability admission” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C032-T10 · Delivery handoff:** Publish the “Mandatory capability admission” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Required isolation cannot be silently downgraded. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Mandatory capability admission”; copy its required invariant exactly: “Required isolation cannot be silently downgraded”.
- [ ] **UC-M03.01-C033-T02 · Observable terms:** Define each term in the “Mandatory capability admission” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C033-T03 · Precondition set:** List the preconditions under which “Required isolation cannot be silently downgraded” must hold for “Mandatory capability admission”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C033-T04 · Transition coverage:** Map the “Mandatory capability admission” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Mandatory capability admission”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C033-T06 · Satisfying fixture:** Create a concrete “Mandatory capability admission” case that satisfies “Required isolation cannot be silently downgraded”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C033-T07 · Violating fixture:** Create the source counterexample “An isolation-required request falls back to a subprocess” for “Mandatory capability admission”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C033-T08 · Enforcement evidence:** Exercise the “Mandatory capability admission” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C033-T09 · Regression linkage:** Link the “Mandatory capability admission” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Mandatory capability admission” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C034 · Integration

**Original checklist item:** Integrate mandatory capability admission with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Mandatory capability admission” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C034-T02 · Field mapping:** Map every “Mandatory capability admission” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Mandatory capability admission” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C034-T04 · Ownership agreement:** Specify who owns “Mandatory capability admission” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C034-T05 · Handoff implementation:** Connect “Mandatory capability admission” through the mapped seam using the real adapter or explicit specification reference; preserve “Required isolation cannot be silently downgraded” across the handoff.
- [ ] **UC-M03.01-C034-T06 · Absent-input case:** Omit one required “Mandatory capability admission” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C034-T07 · Stale-input case:** Supply an outdated “Mandatory capability admission” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Mandatory capability admission” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C034-T09 · Valid integration trace:** Run a valid “Mandatory capability admission” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C034-T10 · Seam review:** Reconcile the “Mandatory capability admission” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for mandatory capability admission; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Mandatory capability admission” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C035-T02 · Expected-result oracle:** Specify the “Mandatory capability admission” expected result independently of the implementation output; include the property “Required isolation cannot be silently downgraded” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C035-T03 · Fixture material:** Create the concrete “Mandatory capability admission” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C035-T04 · Target preparation:** Prepare the “Mandatory capability admission” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C035-T05 · Initial-state record:** Record the initial “Mandatory capability admission” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C035-T06 · Valid-path execution:** Execute the “Mandatory capability admission” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C035-T07 · Outcome comparison:** Compare every declared “Mandatory capability admission” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C035-T08 · State and bounds check:** Inspect the “Mandatory capability admission” ownership/state effects and actual use of “Admission time and capability comparison size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C035-T09 · Repeatability check:** Repeat the same “Mandatory capability admission” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C035-T10 · Positive evidence:** Attach the “Mandatory capability admission” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C036 · Negative test

**Original checklist item:** Negative case: An isolation-required request falls back to a subprocess. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Mandatory capability admission” source counterexample: “An isolation-required request falls back to a subprocess”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Mandatory capability admission”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C036-T03 · Valid control:** Construct a valid “Mandatory capability admission” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C036-T04 · Minimal adverse input:** Derive the “Mandatory capability admission” adverse fixture from the control with the smallest documented change needed to reproduce “An isolation-required request falls back to a subprocess”; retain that change as reproducible data.
- [ ] **UC-M03.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Mandatory capability admission”; require “Required isolation cannot be silently downgraded” and forbid a false-success verdict.
- [ ] **UC-M03.01-C036-T06 · Adverse execution:** Exercise the “Mandatory capability admission” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C036-T07 · Effect inspection:** Inspect “Mandatory capability admission” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C036-T08 · Refusal versus failure:** Confirm the “Mandatory capability admission” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C036-T09 · Reset and retention:** Restore only the disposable “Mandatory capability admission” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C036-T10 · Negative regression:** Register the “Mandatory capability admission” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C037 · Change / failure test

**Original checklist item:** Exercise mandatory capability admission when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C037-T01 · Scenario record:** Write the “Mandatory capability admission” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “Required isolation cannot be silently downgraded”.
- [ ] **UC-M03.01-C037-T02 · Baseline capture:** Create a known-valid “Mandatory capability admission” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C037-T03 · Injection map:** Locate the “Mandatory capability admission” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Mandatory capability admission” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C037-T05 · Controlled trigger:** Introduce the controlled “Mandatory capability admission” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C037-T06 · Intermediate inspection:** Inspect the “Mandatory capability admission” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Mandatory capability admission”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Mandatory capability admission” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C037-T09 · Repeat and compare:** Repeat the selected “Mandatory capability admission” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C037-T10 · Failure evidence:** Publish the “Mandatory capability admission” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for admission time and capability comparison size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Mandatory capability admission”: “Admission time and capability comparison size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C038-T02 · Measurement method:** Choose how to observe each “Mandatory capability admission” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Mandatory capability admission”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Mandatory capability admission” cases for “Admission time and capability comparison size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Mandatory capability admission” limit; preserve “Required isolation cannot be silently downgraded”.
- [ ] **UC-M03.01-C038-T06 · Normal measurement:** Run or review the normal “Mandatory capability admission” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C038-T07 · At-limit measurement:** Exercise the “Mandatory capability admission” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C038-T08 · Over-limit measurement:** Exercise the “Mandatory capability admission” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C038-T09 · Uncovered-scope report:** List the “Mandatory capability admission” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C038-T10 · Limit evidence:** Publish the selected “Mandatory capability admission” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for mandatory capability admission with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C039-T01 · Event inventory:** List the “Mandatory capability admission” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Mandatory capability admission” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C039-T03 · Failure mapping:** Map each documented “Mandatory capability admission” refusal or error to a diagnostic outcome; include “An isolation-required request falls back to a subprocess” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C039-T04 · Emission path:** Add the “Mandatory capability admission” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C039-T05 · Redaction check:** Test “Mandatory capability admission” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C039-T06 · Output budget:** Set and exercise bounded “Mandatory capability admission” message size, rate and retention compatible with “Admission time and capability comparison size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C039-T07 · Success/refusal fixtures:** Capture “Mandatory capability admission” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Mandatory capability admission” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C039-T09 · Operator review:** Read the “Mandatory capability admission” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C039-T10 · Diagnostic evidence:** Publish redacted “Mandatory capability admission” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for mandatory capability admission; label unexecuted checks as untested.

- [ ] **UC-M03.01-C040-T01 · Evidence inventory:** List the “Mandatory capability admission” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C040-T02 · Artifact references:** Record the exact “Mandatory capability admission” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C040-T03 · Fixture references:** Attach the “Mandatory capability admission” fixture IDs, input identities and oracle definition; preserve the source counterexample “An isolation-required request falls back to a subprocess” as a distinct evidence case.
- [ ] **UC-M03.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Mandatory capability admission”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C040-T05 · Environment record:** Record the actual “Mandatory capability admission” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C040-T06 · Expected versus observed:** Pair every “Mandatory capability admission” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C040-T07 · Failure and limit records:** Attach “Mandatory capability admission” change/failure and bounds evidence where required; include uncovered “Admission time and capability comparison size” and unresolved violations of “Required isolation cannot be silently downgraded”.
- [ ] **UC-M03.01-C040-T08 · Evidence hygiene:** Check the “Mandatory capability admission” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C040-T09 · Reproduction review:** Have the “Mandatory capability admission” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C040-T10 · Acceptance linkage:** Link the “Mandatory capability admission” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Backend selection

**Source delivery:** Choose an adapter from explicit workload requirements and operator policy.

**Source invariant:** Selection is reproducible from recorded constraints.

**Source negative case:** Ambient PATH changes which backend handles a workload.

**Source bounded quantities:** Candidate backend count and selection time.

### UC-M03.01-C041 · Contract

**Original checklist item:** Specify backend selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C041-T01 · Scope statement:** Draft the operation boundary for “Backend selection” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backend selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C041-T03 · Output inventory:** List the outputs of “Backend selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Backend selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C041-T05 · Prerequisite contract:** Map “Backend selection” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Backend selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C041-T07 · Invariant clause:** Add a normative clause for “Backend selection” that preserves “Selection is reproducible from recorded constraints”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backend selection”; include the source counterexample “Ambient PATH changes which backend handles a workload” and the intended safe disposition.
- [ ] **UC-M03.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Candidate backend count and selection time” in the “Backend selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C041-T10 · Contract review:** Review the “Backend selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C042 · Delivery

**Original checklist item:** Choose an adapter from explicit workload requirements and operator policy.

- [ ] **UC-M03.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backend selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C042-T02 · Change plan:** Break the source delivery for “Backend selection” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C042-T03 · Core artifact:** Prepare the “Backend selection” decision record for this source instruction: Choose an adapter from explicit workload requirements and operator policy.
- [ ] **UC-M03.01-C042-T04 · Concrete realization:** Evaluate the “Backend selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M03.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backend selection” needed to preserve “Selection is reproducible from recorded constraints”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C042-T06 · Dependency connection:** Connect the “Backend selection” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C042-T07 · Resource behavior:** Account for “Candidate backend count and selection time” in “Backend selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C042-T08 · Delivery check:** Run the smallest real “Backend selection” path and its adverse fixture “Ambient PATH changes which backend handles a workload”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C042-T09 · Patch review:** Review the “Backend selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C042-T10 · Delivery handoff:** Publish the “Backend selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Selection is reproducible from recorded constraints. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Backend selection”; copy its required invariant exactly: “Selection is reproducible from recorded constraints”.
- [ ] **UC-M03.01-C043-T02 · Observable terms:** Define each term in the “Backend selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C043-T03 · Precondition set:** List the preconditions under which “Selection is reproducible from recorded constraints” must hold for “Backend selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C043-T04 · Transition coverage:** Map the “Backend selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backend selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C043-T06 · Satisfying fixture:** Create a concrete “Backend selection” case that satisfies “Selection is reproducible from recorded constraints”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C043-T07 · Violating fixture:** Create the source counterexample “Ambient PATH changes which backend handles a workload” for “Backend selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C043-T08 · Enforcement evidence:** Exercise the “Backend selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C043-T09 · Regression linkage:** Link the “Backend selection” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Backend selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C044 · Integration

**Original checklist item:** Integrate backend selection with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backend selection” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C044-T02 · Field mapping:** Map every “Backend selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Backend selection” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C044-T04 · Ownership agreement:** Specify who owns “Backend selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C044-T05 · Handoff implementation:** Connect “Backend selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Selection is reproducible from recorded constraints” across the handoff.
- [ ] **UC-M03.01-C044-T06 · Absent-input case:** Omit one required “Backend selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C044-T07 · Stale-input case:** Supply an outdated “Backend selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Backend selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C044-T09 · Valid integration trace:** Run a valid “Backend selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C044-T10 · Seam review:** Reconcile the “Backend selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for backend selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Backend selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C045-T02 · Expected-result oracle:** Specify the “Backend selection” expected result independently of the implementation output; include the property “Selection is reproducible from recorded constraints” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C045-T03 · Fixture material:** Create the concrete “Backend selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C045-T04 · Target preparation:** Prepare the “Backend selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C045-T05 · Initial-state record:** Record the initial “Backend selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C045-T06 · Valid-path execution:** Execute the “Backend selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C045-T07 · Outcome comparison:** Compare every declared “Backend selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C045-T08 · State and bounds check:** Inspect the “Backend selection” ownership/state effects and actual use of “Candidate backend count and selection time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C045-T09 · Repeatability check:** Repeat the same “Backend selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C045-T10 · Positive evidence:** Attach the “Backend selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C046 · Negative test

**Original checklist item:** Negative case: Ambient PATH changes which backend handles a workload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Backend selection” source counterexample: “Ambient PATH changes which backend handles a workload”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Backend selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C046-T03 · Valid control:** Construct a valid “Backend selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C046-T04 · Minimal adverse input:** Derive the “Backend selection” adverse fixture from the control with the smallest documented change needed to reproduce “Ambient PATH changes which backend handles a workload”; retain that change as reproducible data.
- [ ] **UC-M03.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backend selection”; require “Selection is reproducible from recorded constraints” and forbid a false-success verdict.
- [ ] **UC-M03.01-C046-T06 · Adverse execution:** Exercise the “Backend selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C046-T07 · Effect inspection:** Inspect “Backend selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C046-T08 · Refusal versus failure:** Confirm the “Backend selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C046-T09 · Reset and retention:** Restore only the disposable “Backend selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C046-T10 · Negative regression:** Register the “Backend selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C047 · Change / failure test

**Original checklist item:** Exercise backend selection when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C047-T01 · Scenario record:** Write the “Backend selection” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “Selection is reproducible from recorded constraints”.
- [ ] **UC-M03.01-C047-T02 · Baseline capture:** Create a known-valid “Backend selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C047-T03 · Injection map:** Locate the “Backend selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Backend selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C047-T05 · Controlled trigger:** Introduce the controlled “Backend selection” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C047-T06 · Intermediate inspection:** Inspect the “Backend selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backend selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Backend selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C047-T09 · Repeat and compare:** Repeat the selected “Backend selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C047-T10 · Failure evidence:** Publish the “Backend selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for candidate backend count and selection time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Backend selection”: “Candidate backend count and selection time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C048-T02 · Measurement method:** Choose how to observe each “Backend selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Backend selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backend selection” cases for “Candidate backend count and selection time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backend selection” limit; preserve “Selection is reproducible from recorded constraints”.
- [ ] **UC-M03.01-C048-T06 · Normal measurement:** Run or review the normal “Backend selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C048-T07 · At-limit measurement:** Exercise the “Backend selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C048-T08 · Over-limit measurement:** Exercise the “Backend selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C048-T09 · Uncovered-scope report:** List the “Backend selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C048-T10 · Limit evidence:** Publish the selected “Backend selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for backend selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C049-T01 · Event inventory:** List the “Backend selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Backend selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C049-T03 · Failure mapping:** Map each documented “Backend selection” refusal or error to a diagnostic outcome; include “Ambient PATH changes which backend handles a workload” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C049-T04 · Emission path:** Add the “Backend selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C049-T05 · Redaction check:** Test “Backend selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C049-T06 · Output budget:** Set and exercise bounded “Backend selection” message size, rate and retention compatible with “Candidate backend count and selection time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C049-T07 · Success/refusal fixtures:** Capture “Backend selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Backend selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C049-T09 · Operator review:** Read the “Backend selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C049-T10 · Diagnostic evidence:** Publish redacted “Backend selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backend selection; label unexecuted checks as untested.

- [ ] **UC-M03.01-C050-T01 · Evidence inventory:** List the “Backend selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C050-T02 · Artifact references:** Record the exact “Backend selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C050-T03 · Fixture references:** Attach the “Backend selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “Ambient PATH changes which backend handles a workload” as a distinct evidence case.
- [ ] **UC-M03.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backend selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C050-T05 · Environment record:** Record the actual “Backend selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C050-T06 · Expected versus observed:** Pair every “Backend selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C050-T07 · Failure and limit records:** Attach “Backend selection” change/failure and bounds evidence where required; include uncovered “Candidate backend count and selection time” and unresolved violations of “Selection is reproducible from recorded constraints”.
- [ ] **UC-M03.01-C050-T08 · Evidence hygiene:** Check the “Backend selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C050-T09 · Reproduction review:** Have the “Backend selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C050-T10 · Acceptance linkage:** Link the “Backend selection” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Opaque instance handles

**Source delivery:** Return generation-bound backend handles instead of raw caller-selected resources.

**Source invariant:** A handle resolves only to its owning workload instance.

**Source negative case:** A stale handle targets a newly created guest.

**Source bounded quantities:** Handle count and handle lifetime.

### UC-M03.01-C051 · Contract

**Original checklist item:** Specify opaque instance handles inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C051-T01 · Scope statement:** Draft the operation boundary for “Opaque instance handles” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Opaque instance handles”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C051-T03 · Output inventory:** List the outputs of “Opaque instance handles” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Opaque instance handles”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C051-T05 · Prerequisite contract:** Map “Opaque instance handles” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Opaque instance handles”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C051-T07 · Invariant clause:** Add a normative clause for “Opaque instance handles” that preserves “A handle resolves only to its owning workload instance”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Opaque instance handles”; include the source counterexample “A stale handle targets a newly created guest” and the intended safe disposition.
- [ ] **UC-M03.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Handle count and handle lifetime” in the “Opaque instance handles” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C051-T10 · Contract review:** Review the “Opaque instance handles” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C052 · Delivery

**Original checklist item:** Return generation-bound backend handles instead of raw caller-selected resources.

- [ ] **UC-M03.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Opaque instance handles”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C052-T02 · Change plan:** Break the source delivery for “Opaque instance handles” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Opaque instance handles” that realizes this source instruction: Return generation-bound backend handles instead of raw caller-selected resources.
- [ ] **UC-M03.01-C052-T04 · Concrete realization:** Trace “Opaque instance handles” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Opaque instance handles” needed to preserve “A handle resolves only to its owning workload instance”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C052-T06 · Dependency connection:** Connect the “Opaque instance handles” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C052-T07 · Resource behavior:** Account for “Handle count and handle lifetime” in “Opaque instance handles”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C052-T08 · Delivery check:** Run the smallest real “Opaque instance handles” path and its adverse fixture “A stale handle targets a newly created guest”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C052-T09 · Patch review:** Review the “Opaque instance handles” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C052-T10 · Delivery handoff:** Publish the “Opaque instance handles” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A handle resolves only to its owning workload instance. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Opaque instance handles”; copy its required invariant exactly: “A handle resolves only to its owning workload instance”.
- [ ] **UC-M03.01-C053-T02 · Observable terms:** Define each term in the “Opaque instance handles” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C053-T03 · Precondition set:** List the preconditions under which “A handle resolves only to its owning workload instance” must hold for “Opaque instance handles”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C053-T04 · Transition coverage:** Map the “Opaque instance handles” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Opaque instance handles”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C053-T06 · Satisfying fixture:** Create a concrete “Opaque instance handles” case that satisfies “A handle resolves only to its owning workload instance”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C053-T07 · Violating fixture:** Create the source counterexample “A stale handle targets a newly created guest” for “Opaque instance handles”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C053-T08 · Enforcement evidence:** Exercise the “Opaque instance handles” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C053-T09 · Regression linkage:** Link the “Opaque instance handles” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Opaque instance handles” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C054 · Integration

**Original checklist item:** Integrate opaque instance handles with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Opaque instance handles” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C054-T02 · Field mapping:** Map every “Opaque instance handles” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Opaque instance handles” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C054-T04 · Ownership agreement:** Specify who owns “Opaque instance handles” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C054-T05 · Handoff implementation:** Connect “Opaque instance handles” through the mapped seam using the real adapter or explicit specification reference; preserve “A handle resolves only to its owning workload instance” across the handoff.
- [ ] **UC-M03.01-C054-T06 · Absent-input case:** Omit one required “Opaque instance handles” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C054-T07 · Stale-input case:** Supply an outdated “Opaque instance handles” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Opaque instance handles” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C054-T09 · Valid integration trace:** Run a valid “Opaque instance handles” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C054-T10 · Seam review:** Reconcile the “Opaque instance handles” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for opaque instance handles; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Opaque instance handles” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C055-T02 · Expected-result oracle:** Specify the “Opaque instance handles” expected result independently of the implementation output; include the property “A handle resolves only to its owning workload instance” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C055-T03 · Fixture material:** Create the concrete “Opaque instance handles” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C055-T04 · Target preparation:** Prepare the “Opaque instance handles” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C055-T05 · Initial-state record:** Record the initial “Opaque instance handles” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C055-T06 · Valid-path execution:** Execute the “Opaque instance handles” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C055-T07 · Outcome comparison:** Compare every declared “Opaque instance handles” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C055-T08 · State and bounds check:** Inspect the “Opaque instance handles” ownership/state effects and actual use of “Handle count and handle lifetime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C055-T09 · Repeatability check:** Repeat the same “Opaque instance handles” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C055-T10 · Positive evidence:** Attach the “Opaque instance handles” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C056 · Negative test

**Original checklist item:** Negative case: A stale handle targets a newly created guest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Opaque instance handles” source counterexample: “A stale handle targets a newly created guest”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Opaque instance handles”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C056-T03 · Valid control:** Construct a valid “Opaque instance handles” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C056-T04 · Minimal adverse input:** Derive the “Opaque instance handles” adverse fixture from the control with the smallest documented change needed to reproduce “A stale handle targets a newly created guest”; retain that change as reproducible data.
- [ ] **UC-M03.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Opaque instance handles”; require “A handle resolves only to its owning workload instance” and forbid a false-success verdict.
- [ ] **UC-M03.01-C056-T06 · Adverse execution:** Exercise the “Opaque instance handles” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C056-T07 · Effect inspection:** Inspect “Opaque instance handles” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C056-T08 · Refusal versus failure:** Confirm the “Opaque instance handles” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C056-T09 · Reset and retention:** Restore only the disposable “Opaque instance handles” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C056-T10 · Negative regression:** Register the “Opaque instance handles” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C057 · Change / failure test

**Original checklist item:** Exercise opaque instance handles when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C057-T01 · Scenario record:** Write the “Opaque instance handles” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “A handle resolves only to its owning workload instance”.
- [ ] **UC-M03.01-C057-T02 · Baseline capture:** Create a known-valid “Opaque instance handles” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C057-T03 · Injection map:** Locate the “Opaque instance handles” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Opaque instance handles” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C057-T05 · Controlled trigger:** Introduce the controlled “Opaque instance handles” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C057-T06 · Intermediate inspection:** Inspect the “Opaque instance handles” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Opaque instance handles”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Opaque instance handles” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C057-T09 · Repeat and compare:** Repeat the selected “Opaque instance handles” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C057-T10 · Failure evidence:** Publish the “Opaque instance handles” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for handle count and handle lifetime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Opaque instance handles”: “Handle count and handle lifetime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C058-T02 · Measurement method:** Choose how to observe each “Opaque instance handles” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Opaque instance handles”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Opaque instance handles” cases for “Handle count and handle lifetime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Opaque instance handles” limit; preserve “A handle resolves only to its owning workload instance”.
- [ ] **UC-M03.01-C058-T06 · Normal measurement:** Run or review the normal “Opaque instance handles” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C058-T07 · At-limit measurement:** Exercise the “Opaque instance handles” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C058-T08 · Over-limit measurement:** Exercise the “Opaque instance handles” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C058-T09 · Uncovered-scope report:** List the “Opaque instance handles” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C058-T10 · Limit evidence:** Publish the selected “Opaque instance handles” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for opaque instance handles with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C059-T01 · Event inventory:** List the “Opaque instance handles” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Opaque instance handles” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C059-T03 · Failure mapping:** Map each documented “Opaque instance handles” refusal or error to a diagnostic outcome; include “A stale handle targets a newly created guest” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C059-T04 · Emission path:** Add the “Opaque instance handles” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C059-T05 · Redaction check:** Test “Opaque instance handles” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C059-T06 · Output budget:** Set and exercise bounded “Opaque instance handles” message size, rate and retention compatible with “Handle count and handle lifetime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C059-T07 · Success/refusal fixtures:** Capture “Opaque instance handles” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Opaque instance handles” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C059-T09 · Operator review:** Read the “Opaque instance handles” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C059-T10 · Diagnostic evidence:** Publish redacted “Opaque instance handles” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for opaque instance handles; label unexecuted checks as untested.

- [ ] **UC-M03.01-C060-T01 · Evidence inventory:** List the “Opaque instance handles” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C060-T02 · Artifact references:** Record the exact “Opaque instance handles” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C060-T03 · Fixture references:** Attach the “Opaque instance handles” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale handle targets a newly created guest” as a distinct evidence case.
- [ ] **UC-M03.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Opaque instance handles”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C060-T05 · Environment record:** Record the actual “Opaque instance handles” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C060-T06 · Expected versus observed:** Pair every “Opaque instance handles” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C060-T07 · Failure and limit records:** Attach “Opaque instance handles” change/failure and bounds evidence where required; include uncovered “Handle count and handle lifetime” and unresolved violations of “A handle resolves only to its owning workload instance”.
- [ ] **UC-M03.01-C060-T08 · Evidence hygiene:** Check the “Opaque instance handles” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C060-T09 · Reproduction review:** Have the “Opaque instance handles” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C060-T10 · Acceptance linkage:** Link the “Opaque instance handles” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Error translation

**Source delivery:** Map backend failures into stable runtime-contract errors without hiding causes.

**Source invariant:** A failed backend action cannot become a generic success.

**Source negative case:** A timeout is converted into an empty successful response.

**Source bounded quantities:** Cause-chain depth and error bytes.

### UC-M03.01-C061 · Contract

**Original checklist item:** Specify error translation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C061-T01 · Scope statement:** Draft the operation boundary for “Error translation” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Error translation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C061-T03 · Output inventory:** List the outputs of “Error translation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Error translation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C061-T05 · Prerequisite contract:** Map “Error translation” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Error translation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C061-T07 · Invariant clause:** Add a normative clause for “Error translation” that preserves “A failed backend action cannot become a generic success”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Error translation”; include the source counterexample “A timeout is converted into an empty successful response” and the intended safe disposition.
- [ ] **UC-M03.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Cause-chain depth and error bytes” in the “Error translation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C061-T10 · Contract review:** Review the “Error translation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C062 · Delivery

**Original checklist item:** Map backend failures into stable runtime-contract errors without hiding causes.

- [ ] **UC-M03.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Error translation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C062-T02 · Change plan:** Break the source delivery for “Error translation” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C062-T03 · Core artifact:** Create the “Error translation” model, schema or inventory that realizes this source instruction: Map backend failures into stable runtime-contract errors without hiding causes.
- [ ] **UC-M03.01-C062-T04 · Concrete realization:** Populate “Error translation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Error translation” needed to preserve “A failed backend action cannot become a generic success”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C062-T06 · Dependency connection:** Connect the “Error translation” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C062-T07 · Resource behavior:** Account for “Cause-chain depth and error bytes” in “Error translation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C062-T08 · Delivery check:** Run the smallest real “Error translation” path and its adverse fixture “A timeout is converted into an empty successful response”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C062-T09 · Patch review:** Review the “Error translation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C062-T10 · Delivery handoff:** Publish the “Error translation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A failed backend action cannot become a generic success. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Error translation”; copy its required invariant exactly: “A failed backend action cannot become a generic success”.
- [ ] **UC-M03.01-C063-T02 · Observable terms:** Define each term in the “Error translation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C063-T03 · Precondition set:** List the preconditions under which “A failed backend action cannot become a generic success” must hold for “Error translation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C063-T04 · Transition coverage:** Map the “Error translation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Error translation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C063-T06 · Satisfying fixture:** Create a concrete “Error translation” case that satisfies “A failed backend action cannot become a generic success”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C063-T07 · Violating fixture:** Create the source counterexample “A timeout is converted into an empty successful response” for “Error translation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C063-T08 · Enforcement evidence:** Exercise the “Error translation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C063-T09 · Regression linkage:** Link the “Error translation” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Error translation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C064 · Integration

**Original checklist item:** Integrate error translation with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Error translation” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C064-T02 · Field mapping:** Map every “Error translation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Error translation” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C064-T04 · Ownership agreement:** Specify who owns “Error translation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C064-T05 · Handoff implementation:** Connect “Error translation” through the mapped seam using the real adapter or explicit specification reference; preserve “A failed backend action cannot become a generic success” across the handoff.
- [ ] **UC-M03.01-C064-T06 · Absent-input case:** Omit one required “Error translation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C064-T07 · Stale-input case:** Supply an outdated “Error translation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Error translation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C064-T09 · Valid integration trace:** Run a valid “Error translation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C064-T10 · Seam review:** Reconcile the “Error translation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for error translation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Error translation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C065-T02 · Expected-result oracle:** Specify the “Error translation” expected result independently of the implementation output; include the property “A failed backend action cannot become a generic success” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C065-T03 · Fixture material:** Create the concrete “Error translation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C065-T04 · Target preparation:** Prepare the “Error translation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C065-T05 · Initial-state record:** Record the initial “Error translation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C065-T06 · Valid-path execution:** Execute the “Error translation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C065-T07 · Outcome comparison:** Compare every declared “Error translation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C065-T08 · State and bounds check:** Inspect the “Error translation” ownership/state effects and actual use of “Cause-chain depth and error bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C065-T09 · Repeatability check:** Repeat the same “Error translation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C065-T10 · Positive evidence:** Attach the “Error translation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C066 · Negative test

**Original checklist item:** Negative case: A timeout is converted into an empty successful response. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Error translation” source counterexample: “A timeout is converted into an empty successful response”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Error translation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C066-T03 · Valid control:** Construct a valid “Error translation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C066-T04 · Minimal adverse input:** Derive the “Error translation” adverse fixture from the control with the smallest documented change needed to reproduce “A timeout is converted into an empty successful response”; retain that change as reproducible data.
- [ ] **UC-M03.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Error translation”; require “A failed backend action cannot become a generic success” and forbid a false-success verdict.
- [ ] **UC-M03.01-C066-T06 · Adverse execution:** Exercise the “Error translation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C066-T07 · Effect inspection:** Inspect “Error translation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C066-T08 · Refusal versus failure:** Confirm the “Error translation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C066-T09 · Reset and retention:** Restore only the disposable “Error translation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C066-T10 · Negative regression:** Register the “Error translation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C067 · Change / failure test

**Original checklist item:** Exercise error translation when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C067-T01 · Scenario record:** Write the “Error translation” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “A failed backend action cannot become a generic success”.
- [ ] **UC-M03.01-C067-T02 · Baseline capture:** Create a known-valid “Error translation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C067-T03 · Injection map:** Locate the “Error translation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Error translation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C067-T05 · Controlled trigger:** Introduce the controlled “Error translation” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C067-T06 · Intermediate inspection:** Inspect the “Error translation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Error translation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Error translation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C067-T09 · Repeat and compare:** Repeat the selected “Error translation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C067-T10 · Failure evidence:** Publish the “Error translation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for cause-chain depth and error bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Error translation”: “Cause-chain depth and error bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C068-T02 · Measurement method:** Choose how to observe each “Error translation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Error translation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Error translation” cases for “Cause-chain depth and error bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Error translation” limit; preserve “A failed backend action cannot become a generic success”.
- [ ] **UC-M03.01-C068-T06 · Normal measurement:** Run or review the normal “Error translation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C068-T07 · At-limit measurement:** Exercise the “Error translation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C068-T08 · Over-limit measurement:** Exercise the “Error translation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C068-T09 · Uncovered-scope report:** List the “Error translation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C068-T10 · Limit evidence:** Publish the selected “Error translation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for error translation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C069-T01 · Event inventory:** List the “Error translation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Error translation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C069-T03 · Failure mapping:** Map each documented “Error translation” refusal or error to a diagnostic outcome; include “A timeout is converted into an empty successful response” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C069-T04 · Emission path:** Add the “Error translation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C069-T05 · Redaction check:** Test “Error translation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C069-T06 · Output budget:** Set and exercise bounded “Error translation” message size, rate and retention compatible with “Cause-chain depth and error bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C069-T07 · Success/refusal fixtures:** Capture “Error translation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Error translation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C069-T09 · Operator review:** Read the “Error translation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C069-T10 · Diagnostic evidence:** Publish redacted “Error translation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for error translation; label unexecuted checks as untested.

- [ ] **UC-M03.01-C070-T01 · Evidence inventory:** List the “Error translation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C070-T02 · Artifact references:** Record the exact “Error translation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C070-T03 · Fixture references:** Attach the “Error translation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A timeout is converted into an empty successful response” as a distinct evidence case.
- [ ] **UC-M03.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Error translation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C070-T05 · Environment record:** Record the actual “Error translation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C070-T06 · Expected versus observed:** Pair every “Error translation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C070-T07 · Failure and limit records:** Attach “Error translation” change/failure and bounds evidence where required; include uncovered “Cause-chain depth and error bytes” and unresolved violations of “A failed backend action cannot become a generic success”.
- [ ] **UC-M03.01-C070-T08 · Evidence hygiene:** Check the “Error translation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C070-T09 · Reproduction review:** Have the “Error translation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C070-T10 · Acceptance linkage:** Link the “Error translation” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Cleanup contract

**Source delivery:** Specify partial-creation cleanup and resource release responsibilities.

**Source invariant:** Failed preparation leaves no usable unowned guest resources.

**Source negative case:** Backend preparation fails after allocating a device.

**Source bounded quantities:** Allocated resource count and cleanup deadline.

### UC-M03.01-C071 · Contract

**Original checklist item:** Specify cleanup contract inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C071-T01 · Scope statement:** Draft the operation boundary for “Cleanup contract” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cleanup contract”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C071-T03 · Output inventory:** List the outputs of “Cleanup contract” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Cleanup contract”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C071-T05 · Prerequisite contract:** Map “Cleanup contract” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Cleanup contract”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C071-T07 · Invariant clause:** Add a normative clause for “Cleanup contract” that preserves “Failed preparation leaves no usable unowned guest resources”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cleanup contract”; include the source counterexample “Backend preparation fails after allocating a device” and the intended safe disposition.
- [ ] **UC-M03.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Allocated resource count and cleanup deadline” in the “Cleanup contract” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C071-T10 · Contract review:** Review the “Cleanup contract” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C072 · Delivery

**Original checklist item:** Specify partial-creation cleanup and resource release responsibilities.

- [ ] **UC-M03.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cleanup contract”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C072-T02 · Change plan:** Break the source delivery for “Cleanup contract” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C072-T03 · Core artifact:** Create the “Cleanup contract” model, schema or inventory that realizes this source instruction: Specify partial-creation cleanup and resource release responsibilities.
- [ ] **UC-M03.01-C072-T04 · Concrete realization:** Populate “Cleanup contract” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cleanup contract” needed to preserve “Failed preparation leaves no usable unowned guest resources”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C072-T06 · Dependency connection:** Connect the “Cleanup contract” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C072-T07 · Resource behavior:** Account for “Allocated resource count and cleanup deadline” in “Cleanup contract”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C072-T08 · Delivery check:** Run the smallest real “Cleanup contract” path and its adverse fixture “Backend preparation fails after allocating a device”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C072-T09 · Patch review:** Review the “Cleanup contract” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C072-T10 · Delivery handoff:** Publish the “Cleanup contract” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Failed preparation leaves no usable unowned guest resources. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Cleanup contract”; copy its required invariant exactly: “Failed preparation leaves no usable unowned guest resources”.
- [ ] **UC-M03.01-C073-T02 · Observable terms:** Define each term in the “Cleanup contract” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C073-T03 · Precondition set:** List the preconditions under which “Failed preparation leaves no usable unowned guest resources” must hold for “Cleanup contract”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C073-T04 · Transition coverage:** Map the “Cleanup contract” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cleanup contract”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C073-T06 · Satisfying fixture:** Create a concrete “Cleanup contract” case that satisfies “Failed preparation leaves no usable unowned guest resources”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C073-T07 · Violating fixture:** Create the source counterexample “Backend preparation fails after allocating a device” for “Cleanup contract”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C073-T08 · Enforcement evidence:** Exercise the “Cleanup contract” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C073-T09 · Regression linkage:** Link the “Cleanup contract” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Cleanup contract” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C074 · Integration

**Original checklist item:** Integrate cleanup contract with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cleanup contract” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C074-T02 · Field mapping:** Map every “Cleanup contract” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Cleanup contract” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C074-T04 · Ownership agreement:** Specify who owns “Cleanup contract” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C074-T05 · Handoff implementation:** Connect “Cleanup contract” through the mapped seam using the real adapter or explicit specification reference; preserve “Failed preparation leaves no usable unowned guest resources” across the handoff.
- [ ] **UC-M03.01-C074-T06 · Absent-input case:** Omit one required “Cleanup contract” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C074-T07 · Stale-input case:** Supply an outdated “Cleanup contract” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Cleanup contract” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C074-T09 · Valid integration trace:** Run a valid “Cleanup contract” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C074-T10 · Seam review:** Reconcile the “Cleanup contract” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cleanup contract; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cleanup contract” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C075-T02 · Expected-result oracle:** Specify the “Cleanup contract” expected result independently of the implementation output; include the property “Failed preparation leaves no usable unowned guest resources” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C075-T03 · Fixture material:** Create the concrete “Cleanup contract” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C075-T04 · Target preparation:** Prepare the “Cleanup contract” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C075-T05 · Initial-state record:** Record the initial “Cleanup contract” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C075-T06 · Valid-path execution:** Execute the “Cleanup contract” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C075-T07 · Outcome comparison:** Compare every declared “Cleanup contract” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C075-T08 · State and bounds check:** Inspect the “Cleanup contract” ownership/state effects and actual use of “Allocated resource count and cleanup deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C075-T09 · Repeatability check:** Repeat the same “Cleanup contract” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C075-T10 · Positive evidence:** Attach the “Cleanup contract” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C076 · Negative test

**Original checklist item:** Negative case: Backend preparation fails after allocating a device. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Cleanup contract” source counterexample: “Backend preparation fails after allocating a device”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Cleanup contract”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C076-T03 · Valid control:** Construct a valid “Cleanup contract” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C076-T04 · Minimal adverse input:** Derive the “Cleanup contract” adverse fixture from the control with the smallest documented change needed to reproduce “Backend preparation fails after allocating a device”; retain that change as reproducible data.
- [ ] **UC-M03.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cleanup contract”; require “Failed preparation leaves no usable unowned guest resources” and forbid a false-success verdict.
- [ ] **UC-M03.01-C076-T06 · Adverse execution:** Exercise the “Cleanup contract” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C076-T07 · Effect inspection:** Inspect “Cleanup contract” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C076-T08 · Refusal versus failure:** Confirm the “Cleanup contract” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C076-T09 · Reset and retention:** Restore only the disposable “Cleanup contract” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C076-T10 · Negative regression:** Register the “Cleanup contract” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C077 · Change / failure test

**Original checklist item:** Exercise cleanup contract when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C077-T01 · Scenario record:** Write the “Cleanup contract” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “Failed preparation leaves no usable unowned guest resources”.
- [ ] **UC-M03.01-C077-T02 · Baseline capture:** Create a known-valid “Cleanup contract” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C077-T03 · Injection map:** Locate the “Cleanup contract” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Cleanup contract” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C077-T05 · Controlled trigger:** Introduce the controlled “Cleanup contract” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C077-T06 · Intermediate inspection:** Inspect the “Cleanup contract” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cleanup contract”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Cleanup contract” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C077-T09 · Repeat and compare:** Repeat the selected “Cleanup contract” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C077-T10 · Failure evidence:** Publish the “Cleanup contract” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for allocated resource count and cleanup deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Cleanup contract”: “Allocated resource count and cleanup deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C078-T02 · Measurement method:** Choose how to observe each “Cleanup contract” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Cleanup contract”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cleanup contract” cases for “Allocated resource count and cleanup deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cleanup contract” limit; preserve “Failed preparation leaves no usable unowned guest resources”.
- [ ] **UC-M03.01-C078-T06 · Normal measurement:** Run or review the normal “Cleanup contract” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C078-T07 · At-limit measurement:** Exercise the “Cleanup contract” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C078-T08 · Over-limit measurement:** Exercise the “Cleanup contract” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C078-T09 · Uncovered-scope report:** List the “Cleanup contract” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C078-T10 · Limit evidence:** Publish the selected “Cleanup contract” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cleanup contract with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C079-T01 · Event inventory:** List the “Cleanup contract” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Cleanup contract” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C079-T03 · Failure mapping:** Map each documented “Cleanup contract” refusal or error to a diagnostic outcome; include “Backend preparation fails after allocating a device” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C079-T04 · Emission path:** Add the “Cleanup contract” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C079-T05 · Redaction check:** Test “Cleanup contract” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C079-T06 · Output budget:** Set and exercise bounded “Cleanup contract” message size, rate and retention compatible with “Allocated resource count and cleanup deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C079-T07 · Success/refusal fixtures:** Capture “Cleanup contract” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cleanup contract” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C079-T09 · Operator review:** Read the “Cleanup contract” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C079-T10 · Diagnostic evidence:** Publish redacted “Cleanup contract” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cleanup contract; label unexecuted checks as untested.

- [ ] **UC-M03.01-C080-T01 · Evidence inventory:** List the “Cleanup contract” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C080-T02 · Artifact references:** Record the exact “Cleanup contract” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C080-T03 · Fixture references:** Attach the “Cleanup contract” fixture IDs, input identities and oracle definition; preserve the source counterexample “Backend preparation fails after allocating a device” as a distinct evidence case.
- [ ] **UC-M03.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cleanup contract”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C080-T05 · Environment record:** Record the actual “Cleanup contract” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C080-T06 · Expected versus observed:** Pair every “Cleanup contract” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C080-T07 · Failure and limit records:** Attach “Cleanup contract” change/failure and bounds evidence where required; include uncovered “Allocated resource count and cleanup deadline” and unresolved violations of “Failed preparation leaves no usable unowned guest resources”.
- [ ] **UC-M03.01-C080-T08 · Evidence hygiene:** Check the “Cleanup contract” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C080-T09 · Reproduction review:** Have the “Cleanup contract” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C080-T10 · Acceptance linkage:** Link the “Cleanup contract” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Adapter conformance tests

**Source delivery:** Run the same contract fixture set against each supported backend class.

**Source invariant:** A class is qualified only for the fixtures it actually passes.

**Source negative case:** A mock adapter pass is reused as evidence for a real VMM.

**Source bounded quantities:** Adapter matrix and fixture runtime.

### UC-M03.01-C081 · Contract

**Original checklist item:** Specify adapter conformance tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C081-T01 · Scope statement:** Draft the operation boundary for “Adapter conformance tests” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Adapter conformance tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C081-T03 · Output inventory:** List the outputs of “Adapter conformance tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Adapter conformance tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C081-T05 · Prerequisite contract:** Map “Adapter conformance tests” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Adapter conformance tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C081-T07 · Invariant clause:** Add a normative clause for “Adapter conformance tests” that preserves “A class is qualified only for the fixtures it actually passes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Adapter conformance tests”; include the source counterexample “A mock adapter pass is reused as evidence for a real VMM” and the intended safe disposition.
- [ ] **UC-M03.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Adapter matrix and fixture runtime” in the “Adapter conformance tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C081-T10 · Contract review:** Review the “Adapter conformance tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C082 · Delivery

**Original checklist item:** Run the same contract fixture set against each supported backend class.

- [ ] **UC-M03.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Adapter conformance tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C082-T02 · Change plan:** Break the source delivery for “Adapter conformance tests” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C082-T03 · Core artifact:** Create the “Adapter conformance tests” fixture or harness for this source instruction: Run the same contract fixture set against each supported backend class.
- [ ] **UC-M03.01-C082-T04 · Concrete realization:** Connect the “Adapter conformance tests” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Adapter conformance tests” needed to preserve “A class is qualified only for the fixtures it actually passes”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C082-T06 · Dependency connection:** Connect the “Adapter conformance tests” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C082-T07 · Resource behavior:** Account for “Adapter matrix and fixture runtime” in “Adapter conformance tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C082-T08 · Delivery check:** Run the smallest real “Adapter conformance tests” path and its adverse fixture “A mock adapter pass is reused as evidence for a real VMM”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C082-T09 · Patch review:** Review the “Adapter conformance tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C082-T10 · Delivery handoff:** Publish the “Adapter conformance tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A class is qualified only for the fixtures it actually passes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Adapter conformance tests”; copy its required invariant exactly: “A class is qualified only for the fixtures it actually passes”.
- [ ] **UC-M03.01-C083-T02 · Observable terms:** Define each term in the “Adapter conformance tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C083-T03 · Precondition set:** List the preconditions under which “A class is qualified only for the fixtures it actually passes” must hold for “Adapter conformance tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C083-T04 · Transition coverage:** Map the “Adapter conformance tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Adapter conformance tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C083-T06 · Satisfying fixture:** Create a concrete “Adapter conformance tests” case that satisfies “A class is qualified only for the fixtures it actually passes”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C083-T07 · Violating fixture:** Create the source counterexample “A mock adapter pass is reused as evidence for a real VMM” for “Adapter conformance tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C083-T08 · Enforcement evidence:** Exercise the “Adapter conformance tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C083-T09 · Regression linkage:** Link the “Adapter conformance tests” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Adapter conformance tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C084 · Integration

**Original checklist item:** Integrate adapter conformance tests with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Adapter conformance tests” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C084-T02 · Field mapping:** Map every “Adapter conformance tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Adapter conformance tests” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C084-T04 · Ownership agreement:** Specify who owns “Adapter conformance tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C084-T05 · Handoff implementation:** Connect “Adapter conformance tests” through the mapped seam using the real adapter or explicit specification reference; preserve “A class is qualified only for the fixtures it actually passes” across the handoff.
- [ ] **UC-M03.01-C084-T06 · Absent-input case:** Omit one required “Adapter conformance tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C084-T07 · Stale-input case:** Supply an outdated “Adapter conformance tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Adapter conformance tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C084-T09 · Valid integration trace:** Run a valid “Adapter conformance tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C084-T10 · Seam review:** Reconcile the “Adapter conformance tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for adapter conformance tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Adapter conformance tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C085-T02 · Expected-result oracle:** Specify the “Adapter conformance tests” expected result independently of the implementation output; include the property “A class is qualified only for the fixtures it actually passes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C085-T03 · Fixture material:** Create the concrete “Adapter conformance tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C085-T04 · Target preparation:** Prepare the “Adapter conformance tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C085-T05 · Initial-state record:** Record the initial “Adapter conformance tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C085-T06 · Valid-path execution:** Execute the “Adapter conformance tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C085-T07 · Outcome comparison:** Compare every declared “Adapter conformance tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C085-T08 · State and bounds check:** Inspect the “Adapter conformance tests” ownership/state effects and actual use of “Adapter matrix and fixture runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C085-T09 · Repeatability check:** Repeat the same “Adapter conformance tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C085-T10 · Positive evidence:** Attach the “Adapter conformance tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C086 · Negative test

**Original checklist item:** Negative case: A mock adapter pass is reused as evidence for a real VMM. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Adapter conformance tests” source counterexample: “A mock adapter pass is reused as evidence for a real VMM”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Adapter conformance tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C086-T03 · Valid control:** Construct a valid “Adapter conformance tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C086-T04 · Minimal adverse input:** Derive the “Adapter conformance tests” adverse fixture from the control with the smallest documented change needed to reproduce “A mock adapter pass is reused as evidence for a real VMM”; retain that change as reproducible data.
- [ ] **UC-M03.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Adapter conformance tests”; require “A class is qualified only for the fixtures it actually passes” and forbid a false-success verdict.
- [ ] **UC-M03.01-C086-T06 · Adverse execution:** Exercise the “Adapter conformance tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C086-T07 · Effect inspection:** Inspect “Adapter conformance tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C086-T08 · Refusal versus failure:** Confirm the “Adapter conformance tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C086-T09 · Reset and retention:** Restore only the disposable “Adapter conformance tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C086-T10 · Negative regression:** Register the “Adapter conformance tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C087 · Change / failure test

**Original checklist item:** Exercise adapter conformance tests when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C087-T01 · Scenario record:** Write the “Adapter conformance tests” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “A class is qualified only for the fixtures it actually passes”.
- [ ] **UC-M03.01-C087-T02 · Baseline capture:** Create a known-valid “Adapter conformance tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C087-T03 · Injection map:** Locate the “Adapter conformance tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Adapter conformance tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C087-T05 · Controlled trigger:** Introduce the controlled “Adapter conformance tests” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C087-T06 · Intermediate inspection:** Inspect the “Adapter conformance tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Adapter conformance tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Adapter conformance tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C087-T09 · Repeat and compare:** Repeat the selected “Adapter conformance tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C087-T10 · Failure evidence:** Publish the “Adapter conformance tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for adapter matrix and fixture runtime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Adapter conformance tests”: “Adapter matrix and fixture runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C088-T02 · Measurement method:** Choose how to observe each “Adapter conformance tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Adapter conformance tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Adapter conformance tests” cases for “Adapter matrix and fixture runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Adapter conformance tests” limit; preserve “A class is qualified only for the fixtures it actually passes”.
- [ ] **UC-M03.01-C088-T06 · Normal measurement:** Run or review the normal “Adapter conformance tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C088-T07 · At-limit measurement:** Exercise the “Adapter conformance tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C088-T08 · Over-limit measurement:** Exercise the “Adapter conformance tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C088-T09 · Uncovered-scope report:** List the “Adapter conformance tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C088-T10 · Limit evidence:** Publish the selected “Adapter conformance tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for adapter conformance tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C089-T01 · Event inventory:** List the “Adapter conformance tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Adapter conformance tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C089-T03 · Failure mapping:** Map each documented “Adapter conformance tests” refusal or error to a diagnostic outcome; include “A mock adapter pass is reused as evidence for a real VMM” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C089-T04 · Emission path:** Add the “Adapter conformance tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C089-T05 · Redaction check:** Test “Adapter conformance tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C089-T06 · Output budget:** Set and exercise bounded “Adapter conformance tests” message size, rate and retention compatible with “Adapter matrix and fixture runtime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C089-T07 · Success/refusal fixtures:** Capture “Adapter conformance tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Adapter conformance tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C089-T09 · Operator review:** Read the “Adapter conformance tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C089-T10 · Diagnostic evidence:** Publish redacted “Adapter conformance tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for adapter conformance tests; label unexecuted checks as untested.

- [ ] **UC-M03.01-C090-T01 · Evidence inventory:** List the “Adapter conformance tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C090-T02 · Artifact references:** Record the exact “Adapter conformance tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C090-T03 · Fixture references:** Attach the “Adapter conformance tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “A mock adapter pass is reused as evidence for a real VMM” as a distinct evidence case.
- [ ] **UC-M03.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Adapter conformance tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C090-T05 · Environment record:** Record the actual “Adapter conformance tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C090-T06 · Expected versus observed:** Pair every “Adapter conformance tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C090-T07 · Failure and limit records:** Attach “Adapter conformance tests” change/failure and bounds evidence where required; include uncovered “Adapter matrix and fixture runtime” and unresolved violations of “A class is qualified only for the fixtures it actually passes”.
- [ ] **UC-M03.01-C090-T08 · Evidence hygiene:** Check the “Adapter conformance tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C090-T09 · Reproduction review:** Have the “Adapter conformance tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C090-T10 · Acceptance linkage:** Link the “Adapter conformance tests” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Backend evidence record

**Source delivery:** Record adapter version, isolation class and exercised capabilities per run.

**Source invariant:** Run evidence distinguishes host execution from guest execution.

**Source negative case:** A result omits which adapter actually performed execution.

**Source bounded quantities:** Record size and evidence retention.

### UC-M03.01-C091 · Contract

**Original checklist item:** Specify backend evidence record inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.01-C091-T01 · Scope statement:** Draft the operation boundary for “Backend evidence record” within Pluggable execution backend boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backend evidence record”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.01-C091-T03 · Output inventory:** List the outputs of “Backend evidence record” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Backend evidence record”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.01-C091-T05 · Prerequisite contract:** Map “Backend evidence record” to the source component prerequisites (UC-M01.02, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Backend evidence record”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.01-C091-T07 · Invariant clause:** Add a normative clause for “Backend evidence record” that preserves “Run evidence distinguishes host execution from guest execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backend evidence record”; include the source counterexample “A result omits which adapter actually performed execution” and the intended safe disposition.
- [ ] **UC-M03.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Record size and evidence retention” in the “Backend evidence record” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.01-C091-T10 · Contract review:** Review the “Backend evidence record” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.01-C092 · Delivery

**Original checklist item:** Record adapter version, isolation class and exercised capabilities per run.

- [ ] **UC-M03.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backend evidence record”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.01-C092-T02 · Change plan:** Break the source delivery for “Backend evidence record” into concrete edit targets and reviewable outputs; keep the UC-M03.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.01-C092-T03 · Core artifact:** Create the “Backend evidence record” model, schema or inventory that realizes this source instruction: Record adapter version, isolation class and exercised capabilities per run.
- [ ] **UC-M03.01-C092-T04 · Concrete realization:** Populate “Backend evidence record” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backend evidence record” needed to preserve “Run evidence distinguishes host execution from guest execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.01-C092-T06 · Dependency connection:** Connect the “Backend evidence record” implementation to runtime operation contracts, backend selection and required-isolation admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.01-C092-T07 · Resource behavior:** Account for “Record size and evidence retention” in “Backend evidence record”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.01-C092-T08 · Delivery check:** Run the smallest real “Backend evidence record” path and its adverse fixture “A result omits which adapter actually performed execution”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.01-C092-T09 · Patch review:** Review the “Backend evidence record” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.01-C092-T10 · Delivery handoff:** Publish the “Backend evidence record” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Run evidence distinguishes host execution from guest execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Backend evidence record”; copy its required invariant exactly: “Run evidence distinguishes host execution from guest execution”.
- [ ] **UC-M03.01-C093-T02 · Observable terms:** Define each term in the “Backend evidence record” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.01-C093-T03 · Precondition set:** List the preconditions under which “Run evidence distinguishes host execution from guest execution” must hold for “Backend evidence record”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.01-C093-T04 · Transition coverage:** Map the “Backend evidence record” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backend evidence record”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.01-C093-T06 · Satisfying fixture:** Create a concrete “Backend evidence record” case that satisfies “Run evidence distinguishes host execution from guest execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.01-C093-T07 · Violating fixture:** Create the source counterexample “A result omits which adapter actually performed execution” for “Backend evidence record”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.01-C093-T08 · Enforcement evidence:** Exercise the “Backend evidence record” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.01-C093-T09 · Regression linkage:** Link the “Backend evidence record” property to changes in runtime operation contracts, backend selection and required-isolation admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Backend evidence record” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.01-C094 · Integration

**Original checklist item:** Integrate backend evidence record with runtime operation contracts, backend selection and required-isolation admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backend evidence record” across runtime operation contracts, backend selection and required-isolation admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.01-C094-T02 · Field mapping:** Map every “Backend evidence record” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Backend evidence record” (source dependency list: UC-M01.02, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.01-C094-T04 · Ownership agreement:** Specify who owns “Backend evidence record” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.01-C094-T05 · Handoff implementation:** Connect “Backend evidence record” through the mapped seam using the real adapter or explicit specification reference; preserve “Run evidence distinguishes host execution from guest execution” across the handoff.
- [ ] **UC-M03.01-C094-T06 · Absent-input case:** Omit one required “Backend evidence record” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.01-C094-T07 · Stale-input case:** Supply an outdated “Backend evidence record” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Backend evidence record” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.01-C094-T09 · Valid integration trace:** Run a valid “Backend evidence record” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.01-C094-T10 · Seam review:** Reconcile the “Backend evidence record” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for backend evidence record; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Backend evidence record” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.01-C095-T02 · Expected-result oracle:** Specify the “Backend evidence record” expected result independently of the implementation output; include the property “Run evidence distinguishes host execution from guest execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.01-C095-T03 · Fixture material:** Create the concrete “Backend evidence record” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.01-C095-T04 · Target preparation:** Prepare the “Backend evidence record” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.01-C095-T05 · Initial-state record:** Record the initial “Backend evidence record” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.01-C095-T06 · Valid-path execution:** Execute the “Backend evidence record” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.01-C095-T07 · Outcome comparison:** Compare every declared “Backend evidence record” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.01-C095-T08 · State and bounds check:** Inspect the “Backend evidence record” ownership/state effects and actual use of “Record size and evidence retention”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.01-C095-T09 · Repeatability check:** Repeat the same “Backend evidence record” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.01-C095-T10 · Positive evidence:** Attach the “Backend evidence record” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.01-C096 · Negative test

**Original checklist item:** Negative case: A result omits which adapter actually performed execution. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Backend evidence record” source counterexample: “A result omits which adapter actually performed execution”; state which precondition or invariant it challenges.
- [ ] **UC-M03.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Backend evidence record”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.01-C096-T03 · Valid control:** Construct a valid “Backend evidence record” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.01-C096-T04 · Minimal adverse input:** Derive the “Backend evidence record” adverse fixture from the control with the smallest documented change needed to reproduce “A result omits which adapter actually performed execution”; retain that change as reproducible data.
- [ ] **UC-M03.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backend evidence record”; require “Run evidence distinguishes host execution from guest execution” and forbid a false-success verdict.
- [ ] **UC-M03.01-C096-T06 · Adverse execution:** Exercise the “Backend evidence record” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.01-C096-T07 · Effect inspection:** Inspect “Backend evidence record” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.01-C096-T08 · Refusal versus failure:** Confirm the “Backend evidence record” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.01-C096-T09 · Reset and retention:** Restore only the disposable “Backend evidence record” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.01-C096-T10 · Negative regression:** Register the “Backend evidence record” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.01-C097 · Change / failure test

**Original checklist item:** Exercise backend evidence record when the requested backend becomes unavailable after initial selection; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.01-C097-T01 · Scenario record:** Write the “Backend evidence record” change/failure scenario exactly as supplied: the requested backend becomes unavailable after initial selection; identify the property that must remain true: “Run evidence distinguishes host execution from guest execution”.
- [ ] **UC-M03.01-C097-T02 · Baseline capture:** Create a known-valid “Backend evidence record” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.01-C097-T03 · Injection map:** Locate the “Backend evidence record” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Backend evidence record” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.01-C097-T05 · Controlled trigger:** Introduce the controlled “Backend evidence record” scenario in the disposable fixture: the requested backend becomes unavailable after initial selection; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.01-C097-T06 · Intermediate inspection:** Inspect the “Backend evidence record” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backend evidence record”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Backend evidence record” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.01-C097-T09 · Repeat and compare:** Repeat the selected “Backend evidence record” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.01-C097-T10 · Failure evidence:** Publish the “Backend evidence record” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for record size and evidence retention; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Backend evidence record”: “Record size and evidence retention”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.01-C098-T02 · Measurement method:** Choose how to observe each “Backend evidence record” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.01-C098-T03 · Budget decision:** Select justified resource and input limits for “Backend evidence record”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backend evidence record” cases for “Record size and evidence retention”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backend evidence record” limit; preserve “Run evidence distinguishes host execution from guest execution”.
- [ ] **UC-M03.01-C098-T06 · Normal measurement:** Run or review the normal “Backend evidence record” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.01-C098-T07 · At-limit measurement:** Exercise the “Backend evidence record” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.01-C098-T08 · Over-limit measurement:** Exercise the “Backend evidence record” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.01-C098-T09 · Uncovered-scope report:** List the “Backend evidence record” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.01-C098-T10 · Limit evidence:** Publish the selected “Backend evidence record” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for backend evidence record with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.01-C099-T01 · Event inventory:** List the “Backend evidence record” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Backend evidence record” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.01-C099-T03 · Failure mapping:** Map each documented “Backend evidence record” refusal or error to a diagnostic outcome; include “A result omits which adapter actually performed execution” and prohibit conversion into a success message.
- [ ] **UC-M03.01-C099-T04 · Emission path:** Add the “Backend evidence record” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.01-C099-T05 · Redaction check:** Test “Backend evidence record” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.01-C099-T06 · Output budget:** Set and exercise bounded “Backend evidence record” message size, rate and retention compatible with “Record size and evidence retention”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.01-C099-T07 · Success/refusal fixtures:** Capture “Backend evidence record” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Backend evidence record” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.01-C099-T09 · Operator review:** Read the “Backend evidence record” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.01-C099-T10 · Diagnostic evidence:** Publish redacted “Backend evidence record” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backend evidence record; label unexecuted checks as untested.

- [ ] **UC-M03.01-C100-T01 · Evidence inventory:** List the “Backend evidence record” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.01-C100-T02 · Artifact references:** Record the exact “Backend evidence record” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.01-C100-T03 · Fixture references:** Attach the “Backend evidence record” fixture IDs, input identities and oracle definition; preserve the source counterexample “A result omits which adapter actually performed execution” as a distinct evidence case.
- [ ] **UC-M03.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backend evidence record”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.01-C100-T05 · Environment record:** Record the actual “Backend evidence record” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.01-C100-T06 · Expected versus observed:** Pair every “Backend evidence record” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.01-C100-T07 · Failure and limit records:** Attach “Backend evidence record” change/failure and bounds evidence where required; include uncovered “Record size and evidence retention” and unresolved violations of “Run evidence distinguishes host execution from guest execution”.
- [ ] **UC-M03.01-C100-T08 · Evidence hygiene:** Check the “Backend evidence record” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.01-C100-T09 · Reproduction review:** Have the “Backend evidence record” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.01-C100-T10 · Acceptance linkage:** Link the “Backend evidence record” evidence to its parent and UC-M03.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

