# UC-M03.02 — Real hypervisor or tender integration

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/03.md)

| Field | Preserved source value |
|---|---|
| Workstream | 03. Host isolation and supervision |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.01](../03/UC-M03.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S3], [S4]. |

## Original requirement

Implement one supported backend that creates a separate guest instance from the built image and validates its boot configuration.

**Original acceptance criterion:** Two guest instances are independently booted, inspected and stopped; host-only VM interpreter runs cannot pass this gate.

**Source trace:** Original checklist `UC100/c/03/UC-M03.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 250–260 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Backend platform selection

**Source delivery:** Pin one supported VMM or tender and its host prerequisites.

**Source invariant:** A backend is identified by an explicit supported configuration.

**Source negative case:** An unqualified backend version is selected automatically.

**Source bounded quantities:** Supported versions and host configurations.

### UC-M03.02-C001 · Contract

**Original checklist item:** Specify backend platform selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C001-T01 · Scope statement:** Draft the operation boundary for “Backend platform selection” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backend platform selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C001-T03 · Output inventory:** List the outputs of “Backend platform selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Backend platform selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C001-T05 · Prerequisite contract:** Map “Backend platform selection” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Backend platform selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C001-T07 · Invariant clause:** Add a normative clause for “Backend platform selection” that preserves “A backend is identified by an explicit supported configuration”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backend platform selection”; include the source counterexample “An unqualified backend version is selected automatically” and the intended safe disposition.
- [ ] **UC-M03.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Supported versions and host configurations” in the “Backend platform selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C001-T10 · Contract review:** Review the “Backend platform selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C002 · Delivery

**Original checklist item:** Pin one supported VMM or tender and its host prerequisites.

- [ ] **UC-M03.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backend platform selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C002-T02 · Change plan:** Break the source delivery for “Backend platform selection” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C002-T03 · Core artifact:** Prepare the “Backend platform selection” decision record for this source instruction: Pin one supported VMM or tender and its host prerequisites.
- [ ] **UC-M03.02-C002-T04 · Concrete realization:** Evaluate the “Backend platform selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M03.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backend platform selection” needed to preserve “A backend is identified by an explicit supported configuration”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C002-T06 · Dependency connection:** Connect the “Backend platform selection” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C002-T07 · Resource behavior:** Account for “Supported versions and host configurations” in “Backend platform selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C002-T08 · Delivery check:** Run the smallest real “Backend platform selection” path and its adverse fixture “An unqualified backend version is selected automatically”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C002-T09 · Patch review:** Review the “Backend platform selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C002-T10 · Delivery handoff:** Publish the “Backend platform selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A backend is identified by an explicit supported configuration. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Backend platform selection”; copy its required invariant exactly: “A backend is identified by an explicit supported configuration”.
- [ ] **UC-M03.02-C003-T02 · Observable terms:** Define each term in the “Backend platform selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C003-T03 · Precondition set:** List the preconditions under which “A backend is identified by an explicit supported configuration” must hold for “Backend platform selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C003-T04 · Transition coverage:** Map the “Backend platform selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backend platform selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C003-T06 · Satisfying fixture:** Create a concrete “Backend platform selection” case that satisfies “A backend is identified by an explicit supported configuration”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C003-T07 · Violating fixture:** Create the source counterexample “An unqualified backend version is selected automatically” for “Backend platform selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C003-T08 · Enforcement evidence:** Exercise the “Backend platform selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C003-T09 · Regression linkage:** Link the “Backend platform selection” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Backend platform selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C004 · Integration

**Original checklist item:** Integrate backend platform selection with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backend platform selection” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C004-T02 · Field mapping:** Map every “Backend platform selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Backend platform selection” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C004-T04 · Ownership agreement:** Specify who owns “Backend platform selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C004-T05 · Handoff implementation:** Connect “Backend platform selection” through the mapped seam using the real adapter or explicit specification reference; preserve “A backend is identified by an explicit supported configuration” across the handoff.
- [ ] **UC-M03.02-C004-T06 · Absent-input case:** Omit one required “Backend platform selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C004-T07 · Stale-input case:** Supply an outdated “Backend platform selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Backend platform selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C004-T09 · Valid integration trace:** Run a valid “Backend platform selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C004-T10 · Seam review:** Reconcile the “Backend platform selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for backend platform selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Backend platform selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C005-T02 · Expected-result oracle:** Specify the “Backend platform selection” expected result independently of the implementation output; include the property “A backend is identified by an explicit supported configuration” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C005-T03 · Fixture material:** Create the concrete “Backend platform selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C005-T04 · Target preparation:** Prepare the “Backend platform selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C005-T05 · Initial-state record:** Record the initial “Backend platform selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C005-T06 · Valid-path execution:** Execute the “Backend platform selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C005-T07 · Outcome comparison:** Compare every declared “Backend platform selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C005-T08 · State and bounds check:** Inspect the “Backend platform selection” ownership/state effects and actual use of “Supported versions and host configurations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C005-T09 · Repeatability check:** Repeat the same “Backend platform selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C005-T10 · Positive evidence:** Attach the “Backend platform selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C006 · Negative test

**Original checklist item:** Negative case: An unqualified backend version is selected automatically. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Backend platform selection” source counterexample: “An unqualified backend version is selected automatically”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Backend platform selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C006-T03 · Valid control:** Construct a valid “Backend platform selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C006-T04 · Minimal adverse input:** Derive the “Backend platform selection” adverse fixture from the control with the smallest documented change needed to reproduce “An unqualified backend version is selected automatically”; retain that change as reproducible data.
- [ ] **UC-M03.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backend platform selection”; require “A backend is identified by an explicit supported configuration” and forbid a false-success verdict.
- [ ] **UC-M03.02-C006-T06 · Adverse execution:** Exercise the “Backend platform selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C006-T07 · Effect inspection:** Inspect “Backend platform selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C006-T08 · Refusal versus failure:** Confirm the “Backend platform selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C006-T09 · Reset and retention:** Restore only the disposable “Backend platform selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C006-T10 · Negative regression:** Register the “Backend platform selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C007 · Change / failure test

**Original checklist item:** Exercise backend platform selection when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C007-T01 · Scenario record:** Write the “Backend platform selection” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “A backend is identified by an explicit supported configuration”.
- [ ] **UC-M03.02-C007-T02 · Baseline capture:** Create a known-valid “Backend platform selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C007-T03 · Injection map:** Locate the “Backend platform selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Backend platform selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C007-T05 · Controlled trigger:** Introduce the controlled “Backend platform selection” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C007-T06 · Intermediate inspection:** Inspect the “Backend platform selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backend platform selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Backend platform selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C007-T09 · Repeat and compare:** Repeat the selected “Backend platform selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C007-T10 · Failure evidence:** Publish the “Backend platform selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for supported versions and host configurations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Backend platform selection”: “Supported versions and host configurations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C008-T02 · Measurement method:** Choose how to observe each “Backend platform selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C008-T03 · Budget decision:** Select justified resource and input limits for “Backend platform selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backend platform selection” cases for “Supported versions and host configurations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backend platform selection” limit; preserve “A backend is identified by an explicit supported configuration”.
- [ ] **UC-M03.02-C008-T06 · Normal measurement:** Run or review the normal “Backend platform selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C008-T07 · At-limit measurement:** Exercise the “Backend platform selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C008-T08 · Over-limit measurement:** Exercise the “Backend platform selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C008-T09 · Uncovered-scope report:** List the “Backend platform selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C008-T10 · Limit evidence:** Publish the selected “Backend platform selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for backend platform selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C009-T01 · Event inventory:** List the “Backend platform selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Backend platform selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C009-T03 · Failure mapping:** Map each documented “Backend platform selection” refusal or error to a diagnostic outcome; include “An unqualified backend version is selected automatically” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C009-T04 · Emission path:** Add the “Backend platform selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C009-T05 · Redaction check:** Test “Backend platform selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C009-T06 · Output budget:** Set and exercise bounded “Backend platform selection” message size, rate and retention compatible with “Supported versions and host configurations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C009-T07 · Success/refusal fixtures:** Capture “Backend platform selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Backend platform selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C009-T09 · Operator review:** Read the “Backend platform selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C009-T10 · Diagnostic evidence:** Publish redacted “Backend platform selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backend platform selection; label unexecuted checks as untested.

- [ ] **UC-M03.02-C010-T01 · Evidence inventory:** List the “Backend platform selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C010-T02 · Artifact references:** Record the exact “Backend platform selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C010-T03 · Fixture references:** Attach the “Backend platform selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unqualified backend version is selected automatically” as a distinct evidence case.
- [ ] **UC-M03.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backend platform selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C010-T05 · Environment record:** Record the actual “Backend platform selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C010-T06 · Expected versus observed:** Pair every “Backend platform selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C010-T07 · Failure and limit records:** Attach “Backend platform selection” change/failure and bounds evidence where required; include uncovered “Supported versions and host configurations” and unresolved violations of “A backend is identified by an explicit supported configuration”.
- [ ] **UC-M03.02-C010-T08 · Evidence hygiene:** Check the “Backend platform selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C010-T09 · Reproduction review:** Have the “Backend platform selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C010-T10 · Acceptance linkage:** Link the “Backend platform selection” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Instance creation

**Source delivery:** Create a separate guest instance from the admitted guest image.

**Source invariant:** Each created instance has an independently controlled execution boundary.

**Source negative case:** Two workload records accidentally share one instance.

**Source bounded quantities:** Concurrent instances and creation deadline.

### UC-M03.02-C011 · Contract

**Original checklist item:** Specify instance creation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C011-T01 · Scope statement:** Draft the operation boundary for “Instance creation” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Instance creation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C011-T03 · Output inventory:** List the outputs of “Instance creation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Instance creation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C011-T05 · Prerequisite contract:** Map “Instance creation” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Instance creation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C011-T07 · Invariant clause:** Add a normative clause for “Instance creation” that preserves “Each created instance has an independently controlled execution boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Instance creation”; include the source counterexample “Two workload records accidentally share one instance” and the intended safe disposition.
- [ ] **UC-M03.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent instances and creation deadline” in the “Instance creation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C011-T10 · Contract review:** Review the “Instance creation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C012 · Delivery

**Original checklist item:** Create a separate guest instance from the admitted guest image.

- [ ] **UC-M03.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Instance creation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C012-T02 · Change plan:** Break the source delivery for “Instance creation” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Instance creation” that realizes this source instruction: Create a separate guest instance from the admitted guest image.
- [ ] **UC-M03.02-C012-T04 · Concrete realization:** Trace “Instance creation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Instance creation” needed to preserve “Each created instance has an independently controlled execution boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C012-T06 · Dependency connection:** Connect the “Instance creation” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C012-T07 · Resource behavior:** Account for “Concurrent instances and creation deadline” in “Instance creation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C012-T08 · Delivery check:** Run the smallest real “Instance creation” path and its adverse fixture “Two workload records accidentally share one instance”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C012-T09 · Patch review:** Review the “Instance creation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C012-T10 · Delivery handoff:** Publish the “Instance creation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each created instance has an independently controlled execution boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Instance creation”; copy its required invariant exactly: “Each created instance has an independently controlled execution boundary”.
- [ ] **UC-M03.02-C013-T02 · Observable terms:** Define each term in the “Instance creation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C013-T03 · Precondition set:** List the preconditions under which “Each created instance has an independently controlled execution boundary” must hold for “Instance creation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C013-T04 · Transition coverage:** Map the “Instance creation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Instance creation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C013-T06 · Satisfying fixture:** Create a concrete “Instance creation” case that satisfies “Each created instance has an independently controlled execution boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C013-T07 · Violating fixture:** Create the source counterexample “Two workload records accidentally share one instance” for “Instance creation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C013-T08 · Enforcement evidence:** Exercise the “Instance creation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C013-T09 · Regression linkage:** Link the “Instance creation” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Instance creation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C014 · Integration

**Original checklist item:** Integrate instance creation with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Instance creation” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C014-T02 · Field mapping:** Map every “Instance creation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Instance creation” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C014-T04 · Ownership agreement:** Specify who owns “Instance creation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C014-T05 · Handoff implementation:** Connect “Instance creation” through the mapped seam using the real adapter or explicit specification reference; preserve “Each created instance has an independently controlled execution boundary” across the handoff.
- [ ] **UC-M03.02-C014-T06 · Absent-input case:** Omit one required “Instance creation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C014-T07 · Stale-input case:** Supply an outdated “Instance creation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Instance creation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C014-T09 · Valid integration trace:** Run a valid “Instance creation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C014-T10 · Seam review:** Reconcile the “Instance creation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for instance creation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Instance creation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C015-T02 · Expected-result oracle:** Specify the “Instance creation” expected result independently of the implementation output; include the property “Each created instance has an independently controlled execution boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C015-T03 · Fixture material:** Create the concrete “Instance creation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C015-T04 · Target preparation:** Prepare the “Instance creation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C015-T05 · Initial-state record:** Record the initial “Instance creation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C015-T06 · Valid-path execution:** Execute the “Instance creation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C015-T07 · Outcome comparison:** Compare every declared “Instance creation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C015-T08 · State and bounds check:** Inspect the “Instance creation” ownership/state effects and actual use of “Concurrent instances and creation deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C015-T09 · Repeatability check:** Repeat the same “Instance creation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C015-T10 · Positive evidence:** Attach the “Instance creation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C016 · Negative test

**Original checklist item:** Negative case: Two workload records accidentally share one instance. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Instance creation” source counterexample: “Two workload records accidentally share one instance”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Instance creation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C016-T03 · Valid control:** Construct a valid “Instance creation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C016-T04 · Minimal adverse input:** Derive the “Instance creation” adverse fixture from the control with the smallest documented change needed to reproduce “Two workload records accidentally share one instance”; retain that change as reproducible data.
- [ ] **UC-M03.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Instance creation”; require “Each created instance has an independently controlled execution boundary” and forbid a false-success verdict.
- [ ] **UC-M03.02-C016-T06 · Adverse execution:** Exercise the “Instance creation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C016-T07 · Effect inspection:** Inspect “Instance creation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C016-T08 · Refusal versus failure:** Confirm the “Instance creation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C016-T09 · Reset and retention:** Restore only the disposable “Instance creation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C016-T10 · Negative regression:** Register the “Instance creation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C017 · Change / failure test

**Original checklist item:** Exercise instance creation when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C017-T01 · Scenario record:** Write the “Instance creation” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “Each created instance has an independently controlled execution boundary”.
- [ ] **UC-M03.02-C017-T02 · Baseline capture:** Create a known-valid “Instance creation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C017-T03 · Injection map:** Locate the “Instance creation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Instance creation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C017-T05 · Controlled trigger:** Introduce the controlled “Instance creation” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C017-T06 · Intermediate inspection:** Inspect the “Instance creation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Instance creation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Instance creation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C017-T09 · Repeat and compare:** Repeat the selected “Instance creation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C017-T10 · Failure evidence:** Publish the “Instance creation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for concurrent instances and creation deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Instance creation”: “Concurrent instances and creation deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C018-T02 · Measurement method:** Choose how to observe each “Instance creation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C018-T03 · Budget decision:** Select justified resource and input limits for “Instance creation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Instance creation” cases for “Concurrent instances and creation deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Instance creation” limit; preserve “Each created instance has an independently controlled execution boundary”.
- [ ] **UC-M03.02-C018-T06 · Normal measurement:** Run or review the normal “Instance creation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C018-T07 · At-limit measurement:** Exercise the “Instance creation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C018-T08 · Over-limit measurement:** Exercise the “Instance creation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C018-T09 · Uncovered-scope report:** List the “Instance creation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C018-T10 · Limit evidence:** Publish the selected “Instance creation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for instance creation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C019-T01 · Event inventory:** List the “Instance creation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Instance creation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C019-T03 · Failure mapping:** Map each documented “Instance creation” refusal or error to a diagnostic outcome; include “Two workload records accidentally share one instance” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C019-T04 · Emission path:** Add the “Instance creation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C019-T05 · Redaction check:** Test “Instance creation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C019-T06 · Output budget:** Set and exercise bounded “Instance creation” message size, rate and retention compatible with “Concurrent instances and creation deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C019-T07 · Success/refusal fixtures:** Capture “Instance creation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Instance creation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C019-T09 · Operator review:** Read the “Instance creation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C019-T10 · Diagnostic evidence:** Publish redacted “Instance creation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for instance creation; label unexecuted checks as untested.

- [ ] **UC-M03.02-C020-T01 · Evidence inventory:** List the “Instance creation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C020-T02 · Artifact references:** Record the exact “Instance creation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C020-T03 · Fixture references:** Attach the “Instance creation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two workload records accidentally share one instance” as a distinct evidence case.
- [ ] **UC-M03.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Instance creation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C020-T05 · Environment record:** Record the actual “Instance creation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C020-T06 · Expected versus observed:** Pair every “Instance creation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C020-T07 · Failure and limit records:** Attach “Instance creation” change/failure and bounds evidence where required; include uncovered “Concurrent instances and creation deadline” and unresolved violations of “Each created instance has an independently controlled execution boundary”.
- [ ] **UC-M03.02-C020-T08 · Evidence hygiene:** Check the “Instance creation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C020-T09 · Reproduction review:** Have the “Instance creation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C020-T10 · Acceptance linkage:** Link the “Instance creation” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Boot configuration validation

**Source delivery:** Validate memory, CPUs, devices, image and boot parameters before creation.

**Source invariant:** The boot configuration matches the admitted workload profile.

**Source negative case:** A caller adds an unapproved device at boot.

**Source bounded quantities:** Configuration bytes and descriptor count.

### UC-M03.02-C021 · Contract

**Original checklist item:** Specify boot configuration validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C021-T01 · Scope statement:** Draft the operation boundary for “Boot configuration validation” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot configuration validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C021-T03 · Output inventory:** List the outputs of “Boot configuration validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot configuration validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C021-T05 · Prerequisite contract:** Map “Boot configuration validation” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Boot configuration validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C021-T07 · Invariant clause:** Add a normative clause for “Boot configuration validation” that preserves “The boot configuration matches the admitted workload profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot configuration validation”; include the source counterexample “A caller adds an unapproved device at boot” and the intended safe disposition.
- [ ] **UC-M03.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Configuration bytes and descriptor count” in the “Boot configuration validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C021-T10 · Contract review:** Review the “Boot configuration validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C022 · Delivery

**Original checklist item:** Validate memory, CPUs, devices, image and boot parameters before creation.

- [ ] **UC-M03.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot configuration validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C022-T02 · Change plan:** Break the source delivery for “Boot configuration validation” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Boot configuration validation” that realizes this source instruction: Validate memory, CPUs, devices, image and boot parameters before creation.
- [ ] **UC-M03.02-C022-T04 · Concrete realization:** Trace “Boot configuration validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot configuration validation” needed to preserve “The boot configuration matches the admitted workload profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C022-T06 · Dependency connection:** Connect the “Boot configuration validation” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C022-T07 · Resource behavior:** Account for “Configuration bytes and descriptor count” in “Boot configuration validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C022-T08 · Delivery check:** Run the smallest real “Boot configuration validation” path and its adverse fixture “A caller adds an unapproved device at boot”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C022-T09 · Patch review:** Review the “Boot configuration validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C022-T10 · Delivery handoff:** Publish the “Boot configuration validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The boot configuration matches the admitted workload profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Boot configuration validation”; copy its required invariant exactly: “The boot configuration matches the admitted workload profile”.
- [ ] **UC-M03.02-C023-T02 · Observable terms:** Define each term in the “Boot configuration validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C023-T03 · Precondition set:** List the preconditions under which “The boot configuration matches the admitted workload profile” must hold for “Boot configuration validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C023-T04 · Transition coverage:** Map the “Boot configuration validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot configuration validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C023-T06 · Satisfying fixture:** Create a concrete “Boot configuration validation” case that satisfies “The boot configuration matches the admitted workload profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C023-T07 · Violating fixture:** Create the source counterexample “A caller adds an unapproved device at boot” for “Boot configuration validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C023-T08 · Enforcement evidence:** Exercise the “Boot configuration validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C023-T09 · Regression linkage:** Link the “Boot configuration validation” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Boot configuration validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C024 · Integration

**Original checklist item:** Integrate boot configuration validation with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot configuration validation” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C024-T02 · Field mapping:** Map every “Boot configuration validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot configuration validation” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C024-T04 · Ownership agreement:** Specify who owns “Boot configuration validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C024-T05 · Handoff implementation:** Connect “Boot configuration validation” through the mapped seam using the real adapter or explicit specification reference; preserve “The boot configuration matches the admitted workload profile” across the handoff.
- [ ] **UC-M03.02-C024-T06 · Absent-input case:** Omit one required “Boot configuration validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C024-T07 · Stale-input case:** Supply an outdated “Boot configuration validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Boot configuration validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C024-T09 · Valid integration trace:** Run a valid “Boot configuration validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C024-T10 · Seam review:** Reconcile the “Boot configuration validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot configuration validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot configuration validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C025-T02 · Expected-result oracle:** Specify the “Boot configuration validation” expected result independently of the implementation output; include the property “The boot configuration matches the admitted workload profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C025-T03 · Fixture material:** Create the concrete “Boot configuration validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C025-T04 · Target preparation:** Prepare the “Boot configuration validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C025-T05 · Initial-state record:** Record the initial “Boot configuration validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C025-T06 · Valid-path execution:** Execute the “Boot configuration validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C025-T07 · Outcome comparison:** Compare every declared “Boot configuration validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C025-T08 · State and bounds check:** Inspect the “Boot configuration validation” ownership/state effects and actual use of “Configuration bytes and descriptor count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C025-T09 · Repeatability check:** Repeat the same “Boot configuration validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C025-T10 · Positive evidence:** Attach the “Boot configuration validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C026 · Negative test

**Original checklist item:** Negative case: A caller adds an unapproved device at boot. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Boot configuration validation” source counterexample: “A caller adds an unapproved device at boot”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot configuration validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C026-T03 · Valid control:** Construct a valid “Boot configuration validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C026-T04 · Minimal adverse input:** Derive the “Boot configuration validation” adverse fixture from the control with the smallest documented change needed to reproduce “A caller adds an unapproved device at boot”; retain that change as reproducible data.
- [ ] **UC-M03.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot configuration validation”; require “The boot configuration matches the admitted workload profile” and forbid a false-success verdict.
- [ ] **UC-M03.02-C026-T06 · Adverse execution:** Exercise the “Boot configuration validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C026-T07 · Effect inspection:** Inspect “Boot configuration validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C026-T08 · Refusal versus failure:** Confirm the “Boot configuration validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C026-T09 · Reset and retention:** Restore only the disposable “Boot configuration validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C026-T10 · Negative regression:** Register the “Boot configuration validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C027 · Change / failure test

**Original checklist item:** Exercise boot configuration validation when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C027-T01 · Scenario record:** Write the “Boot configuration validation” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “The boot configuration matches the admitted workload profile”.
- [ ] **UC-M03.02-C027-T02 · Baseline capture:** Create a known-valid “Boot configuration validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C027-T03 · Injection map:** Locate the “Boot configuration validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Boot configuration validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C027-T05 · Controlled trigger:** Introduce the controlled “Boot configuration validation” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C027-T06 · Intermediate inspection:** Inspect the “Boot configuration validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot configuration validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot configuration validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C027-T09 · Repeat and compare:** Repeat the selected “Boot configuration validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C027-T10 · Failure evidence:** Publish the “Boot configuration validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for configuration bytes and descriptor count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Boot configuration validation”: “Configuration bytes and descriptor count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C028-T02 · Measurement method:** Choose how to observe each “Boot configuration validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Boot configuration validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot configuration validation” cases for “Configuration bytes and descriptor count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot configuration validation” limit; preserve “The boot configuration matches the admitted workload profile”.
- [ ] **UC-M03.02-C028-T06 · Normal measurement:** Run or review the normal “Boot configuration validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C028-T07 · At-limit measurement:** Exercise the “Boot configuration validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C028-T08 · Over-limit measurement:** Exercise the “Boot configuration validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C028-T09 · Uncovered-scope report:** List the “Boot configuration validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C028-T10 · Limit evidence:** Publish the selected “Boot configuration validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot configuration validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C029-T01 · Event inventory:** List the “Boot configuration validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Boot configuration validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C029-T03 · Failure mapping:** Map each documented “Boot configuration validation” refusal or error to a diagnostic outcome; include “A caller adds an unapproved device at boot” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C029-T04 · Emission path:** Add the “Boot configuration validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C029-T05 · Redaction check:** Test “Boot configuration validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C029-T06 · Output budget:** Set and exercise bounded “Boot configuration validation” message size, rate and retention compatible with “Configuration bytes and descriptor count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C029-T07 · Success/refusal fixtures:** Capture “Boot configuration validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot configuration validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C029-T09 · Operator review:** Read the “Boot configuration validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C029-T10 · Diagnostic evidence:** Publish redacted “Boot configuration validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot configuration validation; label unexecuted checks as untested.

- [ ] **UC-M03.02-C030-T01 · Evidence inventory:** List the “Boot configuration validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C030-T02 · Artifact references:** Record the exact “Boot configuration validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C030-T03 · Fixture references:** Attach the “Boot configuration validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A caller adds an unapproved device at boot” as a distinct evidence case.
- [ ] **UC-M03.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot configuration validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C030-T05 · Environment record:** Record the actual “Boot configuration validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C030-T06 · Expected versus observed:** Pair every “Boot configuration validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C030-T07 · Failure and limit records:** Attach “Boot configuration validation” change/failure and bounds evidence where required; include uncovered “Configuration bytes and descriptor count” and unresolved violations of “The boot configuration matches the admitted workload profile”.
- [ ] **UC-M03.02-C030-T08 · Evidence hygiene:** Check the “Boot configuration validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C030-T09 · Reproduction review:** Have the “Boot configuration validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C030-T10 · Acceptance linkage:** Link the “Boot configuration validation” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Image handoff

**Source delivery:** Supply verified image bytes through the selected backend's documented loading path.

**Source invariant:** The executed image matches the admitted image identity.

**Source negative case:** A mutable image path changes before backend loading.

**Source bounded quantities:** Image bytes and handoff duration.

### UC-M03.02-C031 · Contract

**Original checklist item:** Specify image handoff inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C031-T01 · Scope statement:** Draft the operation boundary for “Image handoff” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Image handoff”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C031-T03 · Output inventory:** List the outputs of “Image handoff” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Image handoff”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C031-T05 · Prerequisite contract:** Map “Image handoff” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Image handoff”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C031-T07 · Invariant clause:** Add a normative clause for “Image handoff” that preserves “The executed image matches the admitted image identity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Image handoff”; include the source counterexample “A mutable image path changes before backend loading” and the intended safe disposition.
- [ ] **UC-M03.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Image bytes and handoff duration” in the “Image handoff” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C031-T10 · Contract review:** Review the “Image handoff” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C032 · Delivery

**Original checklist item:** Supply verified image bytes through the selected backend's documented loading path.

- [ ] **UC-M03.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Image handoff”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C032-T02 · Change plan:** Break the source delivery for “Image handoff” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Image handoff” that realizes this source instruction: Supply verified image bytes through the selected backend's documented loading path.
- [ ] **UC-M03.02-C032-T04 · Concrete realization:** Trace “Image handoff” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Image handoff” needed to preserve “The executed image matches the admitted image identity”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C032-T06 · Dependency connection:** Connect the “Image handoff” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C032-T07 · Resource behavior:** Account for “Image bytes and handoff duration” in “Image handoff”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C032-T08 · Delivery check:** Run the smallest real “Image handoff” path and its adverse fixture “A mutable image path changes before backend loading”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C032-T09 · Patch review:** Review the “Image handoff” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C032-T10 · Delivery handoff:** Publish the “Image handoff” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The executed image matches the admitted image identity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Image handoff”; copy its required invariant exactly: “The executed image matches the admitted image identity”.
- [ ] **UC-M03.02-C033-T02 · Observable terms:** Define each term in the “Image handoff” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C033-T03 · Precondition set:** List the preconditions under which “The executed image matches the admitted image identity” must hold for “Image handoff”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C033-T04 · Transition coverage:** Map the “Image handoff” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Image handoff”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C033-T06 · Satisfying fixture:** Create a concrete “Image handoff” case that satisfies “The executed image matches the admitted image identity”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C033-T07 · Violating fixture:** Create the source counterexample “A mutable image path changes before backend loading” for “Image handoff”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C033-T08 · Enforcement evidence:** Exercise the “Image handoff” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C033-T09 · Regression linkage:** Link the “Image handoff” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Image handoff” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C034 · Integration

**Original checklist item:** Integrate image handoff with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Image handoff” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C034-T02 · Field mapping:** Map every “Image handoff” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Image handoff” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C034-T04 · Ownership agreement:** Specify who owns “Image handoff” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C034-T05 · Handoff implementation:** Connect “Image handoff” through the mapped seam using the real adapter or explicit specification reference; preserve “The executed image matches the admitted image identity” across the handoff.
- [ ] **UC-M03.02-C034-T06 · Absent-input case:** Omit one required “Image handoff” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C034-T07 · Stale-input case:** Supply an outdated “Image handoff” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Image handoff” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C034-T09 · Valid integration trace:** Run a valid “Image handoff” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C034-T10 · Seam review:** Reconcile the “Image handoff” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for image handoff; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Image handoff” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C035-T02 · Expected-result oracle:** Specify the “Image handoff” expected result independently of the implementation output; include the property “The executed image matches the admitted image identity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C035-T03 · Fixture material:** Create the concrete “Image handoff” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C035-T04 · Target preparation:** Prepare the “Image handoff” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C035-T05 · Initial-state record:** Record the initial “Image handoff” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C035-T06 · Valid-path execution:** Execute the “Image handoff” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C035-T07 · Outcome comparison:** Compare every declared “Image handoff” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C035-T08 · State and bounds check:** Inspect the “Image handoff” ownership/state effects and actual use of “Image bytes and handoff duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C035-T09 · Repeatability check:** Repeat the same “Image handoff” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C035-T10 · Positive evidence:** Attach the “Image handoff” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C036 · Negative test

**Original checklist item:** Negative case: A mutable image path changes before backend loading. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Image handoff” source counterexample: “A mutable image path changes before backend loading”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Image handoff”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C036-T03 · Valid control:** Construct a valid “Image handoff” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C036-T04 · Minimal adverse input:** Derive the “Image handoff” adverse fixture from the control with the smallest documented change needed to reproduce “A mutable image path changes before backend loading”; retain that change as reproducible data.
- [ ] **UC-M03.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Image handoff”; require “The executed image matches the admitted image identity” and forbid a false-success verdict.
- [ ] **UC-M03.02-C036-T06 · Adverse execution:** Exercise the “Image handoff” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C036-T07 · Effect inspection:** Inspect “Image handoff” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C036-T08 · Refusal versus failure:** Confirm the “Image handoff” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C036-T09 · Reset and retention:** Restore only the disposable “Image handoff” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C036-T10 · Negative regression:** Register the “Image handoff” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C037 · Change / failure test

**Original checklist item:** Exercise image handoff when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C037-T01 · Scenario record:** Write the “Image handoff” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “The executed image matches the admitted image identity”.
- [ ] **UC-M03.02-C037-T02 · Baseline capture:** Create a known-valid “Image handoff” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C037-T03 · Injection map:** Locate the “Image handoff” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Image handoff” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C037-T05 · Controlled trigger:** Introduce the controlled “Image handoff” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C037-T06 · Intermediate inspection:** Inspect the “Image handoff” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Image handoff”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Image handoff” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C037-T09 · Repeat and compare:** Repeat the selected “Image handoff” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C037-T10 · Failure evidence:** Publish the “Image handoff” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for image bytes and handoff duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Image handoff”: “Image bytes and handoff duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C038-T02 · Measurement method:** Choose how to observe each “Image handoff” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C038-T03 · Budget decision:** Select justified resource and input limits for “Image handoff”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Image handoff” cases for “Image bytes and handoff duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Image handoff” limit; preserve “The executed image matches the admitted image identity”.
- [ ] **UC-M03.02-C038-T06 · Normal measurement:** Run or review the normal “Image handoff” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C038-T07 · At-limit measurement:** Exercise the “Image handoff” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C038-T08 · Over-limit measurement:** Exercise the “Image handoff” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C038-T09 · Uncovered-scope report:** List the “Image handoff” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C038-T10 · Limit evidence:** Publish the selected “Image handoff” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for image handoff with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C039-T01 · Event inventory:** List the “Image handoff” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Image handoff” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C039-T03 · Failure mapping:** Map each documented “Image handoff” refusal or error to a diagnostic outcome; include “A mutable image path changes before backend loading” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C039-T04 · Emission path:** Add the “Image handoff” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C039-T05 · Redaction check:** Test “Image handoff” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C039-T06 · Output budget:** Set and exercise bounded “Image handoff” message size, rate and retention compatible with “Image bytes and handoff duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C039-T07 · Success/refusal fixtures:** Capture “Image handoff” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Image handoff” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C039-T09 · Operator review:** Read the “Image handoff” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C039-T10 · Diagnostic evidence:** Publish redacted “Image handoff” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for image handoff; label unexecuted checks as untested.

- [ ] **UC-M03.02-C040-T01 · Evidence inventory:** List the “Image handoff” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C040-T02 · Artifact references:** Record the exact “Image handoff” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C040-T03 · Fixture references:** Attach the “Image handoff” fixture IDs, input identities and oracle definition; preserve the source counterexample “A mutable image path changes before backend loading” as a distinct evidence case.
- [ ] **UC-M03.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Image handoff”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C040-T05 · Environment record:** Record the actual “Image handoff” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C040-T06 · Expected versus observed:** Pair every “Image handoff” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C040-T07 · Failure and limit records:** Attach “Image handoff” change/failure and bounds evidence where required; include uncovered “Image bytes and handoff duration” and unresolved violations of “The executed image matches the admitted image identity”.
- [ ] **UC-M03.02-C040-T08 · Evidence hygiene:** Check the “Image handoff” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C040-T09 · Reproduction review:** Have the “Image handoff” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C040-T10 · Acceptance linkage:** Link the “Image handoff” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Instance identity

**Source delivery:** Associate backend instance handles with workload identity and generation.

**Source invariant:** Backend identity cannot be inferred solely from a display name.

**Source negative case:** A stale instance handle is reused after replacement.

**Source bounded quantities:** Instance registry size and lookup time.

### UC-M03.02-C041 · Contract

**Original checklist item:** Specify instance identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C041-T01 · Scope statement:** Draft the operation boundary for “Instance identity” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Instance identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C041-T03 · Output inventory:** List the outputs of “Instance identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Instance identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C041-T05 · Prerequisite contract:** Map “Instance identity” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Instance identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C041-T07 · Invariant clause:** Add a normative clause for “Instance identity” that preserves “Backend identity cannot be inferred solely from a display name”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Instance identity”; include the source counterexample “A stale instance handle is reused after replacement” and the intended safe disposition.
- [ ] **UC-M03.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Instance registry size and lookup time” in the “Instance identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C041-T10 · Contract review:** Review the “Instance identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C042 · Delivery

**Original checklist item:** Associate backend instance handles with workload identity and generation.

- [ ] **UC-M03.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Instance identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C042-T02 · Change plan:** Break the source delivery for “Instance identity” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Instance identity” that realizes this source instruction: Associate backend instance handles with workload identity and generation.
- [ ] **UC-M03.02-C042-T04 · Concrete realization:** Trace “Instance identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Instance identity” needed to preserve “Backend identity cannot be inferred solely from a display name”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C042-T06 · Dependency connection:** Connect the “Instance identity” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C042-T07 · Resource behavior:** Account for “Instance registry size and lookup time” in “Instance identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C042-T08 · Delivery check:** Run the smallest real “Instance identity” path and its adverse fixture “A stale instance handle is reused after replacement”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C042-T09 · Patch review:** Review the “Instance identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C042-T10 · Delivery handoff:** Publish the “Instance identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Backend identity cannot be inferred solely from a display name. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Instance identity”; copy its required invariant exactly: “Backend identity cannot be inferred solely from a display name”.
- [ ] **UC-M03.02-C043-T02 · Observable terms:** Define each term in the “Instance identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C043-T03 · Precondition set:** List the preconditions under which “Backend identity cannot be inferred solely from a display name” must hold for “Instance identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C043-T04 · Transition coverage:** Map the “Instance identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Instance identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C043-T06 · Satisfying fixture:** Create a concrete “Instance identity” case that satisfies “Backend identity cannot be inferred solely from a display name”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C043-T07 · Violating fixture:** Create the source counterexample “A stale instance handle is reused after replacement” for “Instance identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C043-T08 · Enforcement evidence:** Exercise the “Instance identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C043-T09 · Regression linkage:** Link the “Instance identity” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Instance identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C044 · Integration

**Original checklist item:** Integrate instance identity with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Instance identity” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C044-T02 · Field mapping:** Map every “Instance identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Instance identity” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C044-T04 · Ownership agreement:** Specify who owns “Instance identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C044-T05 · Handoff implementation:** Connect “Instance identity” through the mapped seam using the real adapter or explicit specification reference; preserve “Backend identity cannot be inferred solely from a display name” across the handoff.
- [ ] **UC-M03.02-C044-T06 · Absent-input case:** Omit one required “Instance identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C044-T07 · Stale-input case:** Supply an outdated “Instance identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Instance identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C044-T09 · Valid integration trace:** Run a valid “Instance identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C044-T10 · Seam review:** Reconcile the “Instance identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for instance identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Instance identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C045-T02 · Expected-result oracle:** Specify the “Instance identity” expected result independently of the implementation output; include the property “Backend identity cannot be inferred solely from a display name” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C045-T03 · Fixture material:** Create the concrete “Instance identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C045-T04 · Target preparation:** Prepare the “Instance identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C045-T05 · Initial-state record:** Record the initial “Instance identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C045-T06 · Valid-path execution:** Execute the “Instance identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C045-T07 · Outcome comparison:** Compare every declared “Instance identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C045-T08 · State and bounds check:** Inspect the “Instance identity” ownership/state effects and actual use of “Instance registry size and lookup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C045-T09 · Repeatability check:** Repeat the same “Instance identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C045-T10 · Positive evidence:** Attach the “Instance identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C046 · Negative test

**Original checklist item:** Negative case: A stale instance handle is reused after replacement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Instance identity” source counterexample: “A stale instance handle is reused after replacement”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Instance identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C046-T03 · Valid control:** Construct a valid “Instance identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C046-T04 · Minimal adverse input:** Derive the “Instance identity” adverse fixture from the control with the smallest documented change needed to reproduce “A stale instance handle is reused after replacement”; retain that change as reproducible data.
- [ ] **UC-M03.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Instance identity”; require “Backend identity cannot be inferred solely from a display name” and forbid a false-success verdict.
- [ ] **UC-M03.02-C046-T06 · Adverse execution:** Exercise the “Instance identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C046-T07 · Effect inspection:** Inspect “Instance identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C046-T08 · Refusal versus failure:** Confirm the “Instance identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C046-T09 · Reset and retention:** Restore only the disposable “Instance identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C046-T10 · Negative regression:** Register the “Instance identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C047 · Change / failure test

**Original checklist item:** Exercise instance identity when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C047-T01 · Scenario record:** Write the “Instance identity” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “Backend identity cannot be inferred solely from a display name”.
- [ ] **UC-M03.02-C047-T02 · Baseline capture:** Create a known-valid “Instance identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C047-T03 · Injection map:** Locate the “Instance identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Instance identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C047-T05 · Controlled trigger:** Introduce the controlled “Instance identity” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C047-T06 · Intermediate inspection:** Inspect the “Instance identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Instance identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Instance identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C047-T09 · Repeat and compare:** Repeat the selected “Instance identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C047-T10 · Failure evidence:** Publish the “Instance identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for instance registry size and lookup time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Instance identity”: “Instance registry size and lookup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C048-T02 · Measurement method:** Choose how to observe each “Instance identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C048-T03 · Budget decision:** Select justified resource and input limits for “Instance identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Instance identity” cases for “Instance registry size and lookup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Instance identity” limit; preserve “Backend identity cannot be inferred solely from a display name”.
- [ ] **UC-M03.02-C048-T06 · Normal measurement:** Run or review the normal “Instance identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C048-T07 · At-limit measurement:** Exercise the “Instance identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C048-T08 · Over-limit measurement:** Exercise the “Instance identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C048-T09 · Uncovered-scope report:** List the “Instance identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C048-T10 · Limit evidence:** Publish the selected “Instance identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for instance identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C049-T01 · Event inventory:** List the “Instance identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Instance identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C049-T03 · Failure mapping:** Map each documented “Instance identity” refusal or error to a diagnostic outcome; include “A stale instance handle is reused after replacement” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C049-T04 · Emission path:** Add the “Instance identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C049-T05 · Redaction check:** Test “Instance identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C049-T06 · Output budget:** Set and exercise bounded “Instance identity” message size, rate and retention compatible with “Instance registry size and lookup time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C049-T07 · Success/refusal fixtures:** Capture “Instance identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Instance identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C049-T09 · Operator review:** Read the “Instance identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C049-T10 · Diagnostic evidence:** Publish redacted “Instance identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for instance identity; label unexecuted checks as untested.

- [ ] **UC-M03.02-C050-T01 · Evidence inventory:** List the “Instance identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C050-T02 · Artifact references:** Record the exact “Instance identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C050-T03 · Fixture references:** Attach the “Instance identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale instance handle is reused after replacement” as a distinct evidence case.
- [ ] **UC-M03.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Instance identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C050-T05 · Environment record:** Record the actual “Instance identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C050-T06 · Expected versus observed:** Pair every “Instance identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C050-T07 · Failure and limit records:** Attach “Instance identity” change/failure and bounds evidence where required; include uncovered “Instance registry size and lookup time” and unresolved violations of “Backend identity cannot be inferred solely from a display name”.
- [ ] **UC-M03.02-C050-T08 · Evidence hygiene:** Check the “Instance identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C050-T09 · Reproduction review:** Have the “Instance identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C050-T10 · Acceptance linkage:** Link the “Instance identity” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Independent inspection

**Source delivery:** Inspect each guest's actual backend state independently.

**Source invariant:** One guest's ready signal cannot establish another guest's state.

**Source negative case:** Inspection returns a shared cached running value for all guests.

**Source bounded quantities:** Inspection polling rate and response size.

### UC-M03.02-C051 · Contract

**Original checklist item:** Specify independent inspection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C051-T01 · Scope statement:** Draft the operation boundary for “Independent inspection” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Independent inspection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C051-T03 · Output inventory:** List the outputs of “Independent inspection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Independent inspection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C051-T05 · Prerequisite contract:** Map “Independent inspection” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Independent inspection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C051-T07 · Invariant clause:** Add a normative clause for “Independent inspection” that preserves “One guest's ready signal cannot establish another guest's state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Independent inspection”; include the source counterexample “Inspection returns a shared cached running value for all guests” and the intended safe disposition.
- [ ] **UC-M03.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Inspection polling rate and response size” in the “Independent inspection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C051-T10 · Contract review:** Review the “Independent inspection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C052 · Delivery

**Original checklist item:** Inspect each guest's actual backend state independently.

- [ ] **UC-M03.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Independent inspection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C052-T02 · Change plan:** Break the source delivery for “Independent inspection” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Independent inspection” that realizes this source instruction: Inspect each guest's actual backend state independently.
- [ ] **UC-M03.02-C052-T04 · Concrete realization:** Trace “Independent inspection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Independent inspection” needed to preserve “One guest's ready signal cannot establish another guest's state”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C052-T06 · Dependency connection:** Connect the “Independent inspection” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C052-T07 · Resource behavior:** Account for “Inspection polling rate and response size” in “Independent inspection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C052-T08 · Delivery check:** Run the smallest real “Independent inspection” path and its adverse fixture “Inspection returns a shared cached running value for all guests”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C052-T09 · Patch review:** Review the “Independent inspection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C052-T10 · Delivery handoff:** Publish the “Independent inspection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One guest's ready signal cannot establish another guest's state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Independent inspection”; copy its required invariant exactly: “One guest's ready signal cannot establish another guest's state”.
- [ ] **UC-M03.02-C053-T02 · Observable terms:** Define each term in the “Independent inspection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C053-T03 · Precondition set:** List the preconditions under which “One guest's ready signal cannot establish another guest's state” must hold for “Independent inspection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C053-T04 · Transition coverage:** Map the “Independent inspection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Independent inspection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C053-T06 · Satisfying fixture:** Create a concrete “Independent inspection” case that satisfies “One guest's ready signal cannot establish another guest's state”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C053-T07 · Violating fixture:** Create the source counterexample “Inspection returns a shared cached running value for all guests” for “Independent inspection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C053-T08 · Enforcement evidence:** Exercise the “Independent inspection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C053-T09 · Regression linkage:** Link the “Independent inspection” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Independent inspection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C054 · Integration

**Original checklist item:** Integrate independent inspection with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Independent inspection” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C054-T02 · Field mapping:** Map every “Independent inspection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Independent inspection” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C054-T04 · Ownership agreement:** Specify who owns “Independent inspection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C054-T05 · Handoff implementation:** Connect “Independent inspection” through the mapped seam using the real adapter or explicit specification reference; preserve “One guest's ready signal cannot establish another guest's state” across the handoff.
- [ ] **UC-M03.02-C054-T06 · Absent-input case:** Omit one required “Independent inspection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C054-T07 · Stale-input case:** Supply an outdated “Independent inspection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Independent inspection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C054-T09 · Valid integration trace:** Run a valid “Independent inspection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C054-T10 · Seam review:** Reconcile the “Independent inspection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for independent inspection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Independent inspection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C055-T02 · Expected-result oracle:** Specify the “Independent inspection” expected result independently of the implementation output; include the property “One guest's ready signal cannot establish another guest's state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C055-T03 · Fixture material:** Create the concrete “Independent inspection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C055-T04 · Target preparation:** Prepare the “Independent inspection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C055-T05 · Initial-state record:** Record the initial “Independent inspection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C055-T06 · Valid-path execution:** Execute the “Independent inspection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C055-T07 · Outcome comparison:** Compare every declared “Independent inspection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C055-T08 · State and bounds check:** Inspect the “Independent inspection” ownership/state effects and actual use of “Inspection polling rate and response size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C055-T09 · Repeatability check:** Repeat the same “Independent inspection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C055-T10 · Positive evidence:** Attach the “Independent inspection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C056 · Negative test

**Original checklist item:** Negative case: Inspection returns a shared cached running value for all guests. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Independent inspection” source counterexample: “Inspection returns a shared cached running value for all guests”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Independent inspection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C056-T03 · Valid control:** Construct a valid “Independent inspection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C056-T04 · Minimal adverse input:** Derive the “Independent inspection” adverse fixture from the control with the smallest documented change needed to reproduce “Inspection returns a shared cached running value for all guests”; retain that change as reproducible data.
- [ ] **UC-M03.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Independent inspection”; require “One guest's ready signal cannot establish another guest's state” and forbid a false-success verdict.
- [ ] **UC-M03.02-C056-T06 · Adverse execution:** Exercise the “Independent inspection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C056-T07 · Effect inspection:** Inspect “Independent inspection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C056-T08 · Refusal versus failure:** Confirm the “Independent inspection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C056-T09 · Reset and retention:** Restore only the disposable “Independent inspection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C056-T10 · Negative regression:** Register the “Independent inspection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C057 · Change / failure test

**Original checklist item:** Exercise independent inspection when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C057-T01 · Scenario record:** Write the “Independent inspection” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “One guest's ready signal cannot establish another guest's state”.
- [ ] **UC-M03.02-C057-T02 · Baseline capture:** Create a known-valid “Independent inspection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C057-T03 · Injection map:** Locate the “Independent inspection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Independent inspection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C057-T05 · Controlled trigger:** Introduce the controlled “Independent inspection” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C057-T06 · Intermediate inspection:** Inspect the “Independent inspection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Independent inspection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Independent inspection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C057-T09 · Repeat and compare:** Repeat the selected “Independent inspection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C057-T10 · Failure evidence:** Publish the “Independent inspection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for inspection polling rate and response size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Independent inspection”: “Inspection polling rate and response size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C058-T02 · Measurement method:** Choose how to observe each “Independent inspection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Independent inspection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Independent inspection” cases for “Inspection polling rate and response size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Independent inspection” limit; preserve “One guest's ready signal cannot establish another guest's state”.
- [ ] **UC-M03.02-C058-T06 · Normal measurement:** Run or review the normal “Independent inspection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C058-T07 · At-limit measurement:** Exercise the “Independent inspection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C058-T08 · Over-limit measurement:** Exercise the “Independent inspection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C058-T09 · Uncovered-scope report:** List the “Independent inspection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C058-T10 · Limit evidence:** Publish the selected “Independent inspection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for independent inspection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C059-T01 · Event inventory:** List the “Independent inspection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Independent inspection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C059-T03 · Failure mapping:** Map each documented “Independent inspection” refusal or error to a diagnostic outcome; include “Inspection returns a shared cached running value for all guests” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C059-T04 · Emission path:** Add the “Independent inspection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C059-T05 · Redaction check:** Test “Independent inspection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C059-T06 · Output budget:** Set and exercise bounded “Independent inspection” message size, rate and retention compatible with “Inspection polling rate and response size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C059-T07 · Success/refusal fixtures:** Capture “Independent inspection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Independent inspection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C059-T09 · Operator review:** Read the “Independent inspection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C059-T10 · Diagnostic evidence:** Publish redacted “Independent inspection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for independent inspection; label unexecuted checks as untested.

- [ ] **UC-M03.02-C060-T01 · Evidence inventory:** List the “Independent inspection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C060-T02 · Artifact references:** Record the exact “Independent inspection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C060-T03 · Fixture references:** Attach the “Independent inspection” fixture IDs, input identities and oracle definition; preserve the source counterexample “Inspection returns a shared cached running value for all guests” as a distinct evidence case.
- [ ] **UC-M03.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Independent inspection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C060-T05 · Environment record:** Record the actual “Independent inspection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C060-T06 · Expected versus observed:** Pair every “Independent inspection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C060-T07 · Failure and limit records:** Attach “Independent inspection” change/failure and bounds evidence where required; include uncovered “Inspection polling rate and response size” and unresolved violations of “One guest's ready signal cannot establish another guest's state”.
- [ ] **UC-M03.02-C060-T08 · Evidence hygiene:** Check the “Independent inspection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C060-T09 · Reproduction review:** Have the “Independent inspection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C060-T10 · Acceptance linkage:** Link the “Independent inspection” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Independent stop

**Source delivery:** Stop a selected guest without stopping unrelated instances.

**Source invariant:** Per-instance control respects workload identity and generation.

**Source negative case:** Stopping one guest terminates every backend process.

**Source bounded quantities:** Stop deadline and simultaneous stop requests.

### UC-M03.02-C061 · Contract

**Original checklist item:** Specify independent stop inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C061-T01 · Scope statement:** Draft the operation boundary for “Independent stop” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Independent stop”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C061-T03 · Output inventory:** List the outputs of “Independent stop” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Independent stop”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C061-T05 · Prerequisite contract:** Map “Independent stop” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Independent stop”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C061-T07 · Invariant clause:** Add a normative clause for “Independent stop” that preserves “Per-instance control respects workload identity and generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Independent stop”; include the source counterexample “Stopping one guest terminates every backend process” and the intended safe disposition.
- [ ] **UC-M03.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Stop deadline and simultaneous stop requests” in the “Independent stop” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C061-T10 · Contract review:** Review the “Independent stop” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C062 · Delivery

**Original checklist item:** Stop a selected guest without stopping unrelated instances.

- [ ] **UC-M03.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Independent stop”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C062-T02 · Change plan:** Break the source delivery for “Independent stop” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Independent stop” that realizes this source instruction: Stop a selected guest without stopping unrelated instances.
- [ ] **UC-M03.02-C062-T04 · Concrete realization:** Trace “Independent stop” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Independent stop” needed to preserve “Per-instance control respects workload identity and generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C062-T06 · Dependency connection:** Connect the “Independent stop” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C062-T07 · Resource behavior:** Account for “Stop deadline and simultaneous stop requests” in “Independent stop”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C062-T08 · Delivery check:** Run the smallest real “Independent stop” path and its adverse fixture “Stopping one guest terminates every backend process”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C062-T09 · Patch review:** Review the “Independent stop” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C062-T10 · Delivery handoff:** Publish the “Independent stop” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Per-instance control respects workload identity and generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Independent stop”; copy its required invariant exactly: “Per-instance control respects workload identity and generation”.
- [ ] **UC-M03.02-C063-T02 · Observable terms:** Define each term in the “Independent stop” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C063-T03 · Precondition set:** List the preconditions under which “Per-instance control respects workload identity and generation” must hold for “Independent stop”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C063-T04 · Transition coverage:** Map the “Independent stop” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Independent stop”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C063-T06 · Satisfying fixture:** Create a concrete “Independent stop” case that satisfies “Per-instance control respects workload identity and generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C063-T07 · Violating fixture:** Create the source counterexample “Stopping one guest terminates every backend process” for “Independent stop”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C063-T08 · Enforcement evidence:** Exercise the “Independent stop” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C063-T09 · Regression linkage:** Link the “Independent stop” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Independent stop” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C064 · Integration

**Original checklist item:** Integrate independent stop with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Independent stop” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C064-T02 · Field mapping:** Map every “Independent stop” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Independent stop” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C064-T04 · Ownership agreement:** Specify who owns “Independent stop” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C064-T05 · Handoff implementation:** Connect “Independent stop” through the mapped seam using the real adapter or explicit specification reference; preserve “Per-instance control respects workload identity and generation” across the handoff.
- [ ] **UC-M03.02-C064-T06 · Absent-input case:** Omit one required “Independent stop” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C064-T07 · Stale-input case:** Supply an outdated “Independent stop” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Independent stop” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C064-T09 · Valid integration trace:** Run a valid “Independent stop” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C064-T10 · Seam review:** Reconcile the “Independent stop” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for independent stop; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Independent stop” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C065-T02 · Expected-result oracle:** Specify the “Independent stop” expected result independently of the implementation output; include the property “Per-instance control respects workload identity and generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C065-T03 · Fixture material:** Create the concrete “Independent stop” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C065-T04 · Target preparation:** Prepare the “Independent stop” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C065-T05 · Initial-state record:** Record the initial “Independent stop” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C065-T06 · Valid-path execution:** Execute the “Independent stop” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C065-T07 · Outcome comparison:** Compare every declared “Independent stop” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C065-T08 · State and bounds check:** Inspect the “Independent stop” ownership/state effects and actual use of “Stop deadline and simultaneous stop requests”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C065-T09 · Repeatability check:** Repeat the same “Independent stop” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C065-T10 · Positive evidence:** Attach the “Independent stop” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C066 · Negative test

**Original checklist item:** Negative case: Stopping one guest terminates every backend process. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Independent stop” source counterexample: “Stopping one guest terminates every backend process”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Independent stop”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C066-T03 · Valid control:** Construct a valid “Independent stop” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C066-T04 · Minimal adverse input:** Derive the “Independent stop” adverse fixture from the control with the smallest documented change needed to reproduce “Stopping one guest terminates every backend process”; retain that change as reproducible data.
- [ ] **UC-M03.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Independent stop”; require “Per-instance control respects workload identity and generation” and forbid a false-success verdict.
- [ ] **UC-M03.02-C066-T06 · Adverse execution:** Exercise the “Independent stop” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C066-T07 · Effect inspection:** Inspect “Independent stop” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C066-T08 · Refusal versus failure:** Confirm the “Independent stop” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C066-T09 · Reset and retention:** Restore only the disposable “Independent stop” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C066-T10 · Negative regression:** Register the “Independent stop” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C067 · Change / failure test

**Original checklist item:** Exercise independent stop when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C067-T01 · Scenario record:** Write the “Independent stop” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “Per-instance control respects workload identity and generation”.
- [ ] **UC-M03.02-C067-T02 · Baseline capture:** Create a known-valid “Independent stop” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C067-T03 · Injection map:** Locate the “Independent stop” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Independent stop” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C067-T05 · Controlled trigger:** Introduce the controlled “Independent stop” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C067-T06 · Intermediate inspection:** Inspect the “Independent stop” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Independent stop”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Independent stop” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C067-T09 · Repeat and compare:** Repeat the selected “Independent stop” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C067-T10 · Failure evidence:** Publish the “Independent stop” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for stop deadline and simultaneous stop requests; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Independent stop”: “Stop deadline and simultaneous stop requests”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C068-T02 · Measurement method:** Choose how to observe each “Independent stop” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Independent stop”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Independent stop” cases for “Stop deadline and simultaneous stop requests”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Independent stop” limit; preserve “Per-instance control respects workload identity and generation”.
- [ ] **UC-M03.02-C068-T06 · Normal measurement:** Run or review the normal “Independent stop” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C068-T07 · At-limit measurement:** Exercise the “Independent stop” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C068-T08 · Over-limit measurement:** Exercise the “Independent stop” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C068-T09 · Uncovered-scope report:** List the “Independent stop” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C068-T10 · Limit evidence:** Publish the selected “Independent stop” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for independent stop with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C069-T01 · Event inventory:** List the “Independent stop” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Independent stop” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C069-T03 · Failure mapping:** Map each documented “Independent stop” refusal or error to a diagnostic outcome; include “Stopping one guest terminates every backend process” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C069-T04 · Emission path:** Add the “Independent stop” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C069-T05 · Redaction check:** Test “Independent stop” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C069-T06 · Output budget:** Set and exercise bounded “Independent stop” message size, rate and retention compatible with “Stop deadline and simultaneous stop requests”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C069-T07 · Success/refusal fixtures:** Capture “Independent stop” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Independent stop” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C069-T09 · Operator review:** Read the “Independent stop” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C069-T10 · Diagnostic evidence:** Publish redacted “Independent stop” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for independent stop; label unexecuted checks as untested.

- [ ] **UC-M03.02-C070-T01 · Evidence inventory:** List the “Independent stop” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C070-T02 · Artifact references:** Record the exact “Independent stop” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C070-T03 · Fixture references:** Attach the “Independent stop” fixture IDs, input identities and oracle definition; preserve the source counterexample “Stopping one guest terminates every backend process” as a distinct evidence case.
- [ ] **UC-M03.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Independent stop”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C070-T05 · Environment record:** Record the actual “Independent stop” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C070-T06 · Expected versus observed:** Pair every “Independent stop” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C070-T07 · Failure and limit records:** Attach “Independent stop” change/failure and bounds evidence where required; include uncovered “Stop deadline and simultaneous stop requests” and unresolved violations of “Per-instance control respects workload identity and generation”.
- [ ] **UC-M03.02-C070-T08 · Evidence hygiene:** Check the “Independent stop” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C070-T09 · Reproduction review:** Have the “Independent stop” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C070-T10 · Acceptance linkage:** Link the “Independent stop” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Lifecycle cleanup

**Source delivery:** Release devices, mappings and temporary resources after instance termination.

**Source invariant:** Stopped guests leave no active executable or device ownership.

**Source negative case:** A failed boot leaves a live tender process.

**Source bounded quantities:** Residual resources and cleanup deadline.

### UC-M03.02-C071 · Contract

**Original checklist item:** Specify lifecycle cleanup inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C071-T01 · Scope statement:** Draft the operation boundary for “Lifecycle cleanup” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Lifecycle cleanup”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C071-T03 · Output inventory:** List the outputs of “Lifecycle cleanup” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Lifecycle cleanup”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C071-T05 · Prerequisite contract:** Map “Lifecycle cleanup” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Lifecycle cleanup”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C071-T07 · Invariant clause:** Add a normative clause for “Lifecycle cleanup” that preserves “Stopped guests leave no active executable or device ownership”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Lifecycle cleanup”; include the source counterexample “A failed boot leaves a live tender process” and the intended safe disposition.
- [ ] **UC-M03.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Residual resources and cleanup deadline” in the “Lifecycle cleanup” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C071-T10 · Contract review:** Review the “Lifecycle cleanup” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C072 · Delivery

**Original checklist item:** Release devices, mappings and temporary resources after instance termination.

- [ ] **UC-M03.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Lifecycle cleanup”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C072-T02 · Change plan:** Break the source delivery for “Lifecycle cleanup” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Lifecycle cleanup” that realizes this source instruction: Release devices, mappings and temporary resources after instance termination.
- [ ] **UC-M03.02-C072-T04 · Concrete realization:** Trace “Lifecycle cleanup” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Lifecycle cleanup” needed to preserve “Stopped guests leave no active executable or device ownership”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C072-T06 · Dependency connection:** Connect the “Lifecycle cleanup” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C072-T07 · Resource behavior:** Account for “Residual resources and cleanup deadline” in “Lifecycle cleanup”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C072-T08 · Delivery check:** Run the smallest real “Lifecycle cleanup” path and its adverse fixture “A failed boot leaves a live tender process”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C072-T09 · Patch review:** Review the “Lifecycle cleanup” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C072-T10 · Delivery handoff:** Publish the “Lifecycle cleanup” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stopped guests leave no active executable or device ownership. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Lifecycle cleanup”; copy its required invariant exactly: “Stopped guests leave no active executable or device ownership”.
- [ ] **UC-M03.02-C073-T02 · Observable terms:** Define each term in the “Lifecycle cleanup” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C073-T03 · Precondition set:** List the preconditions under which “Stopped guests leave no active executable or device ownership” must hold for “Lifecycle cleanup”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C073-T04 · Transition coverage:** Map the “Lifecycle cleanup” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Lifecycle cleanup”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C073-T06 · Satisfying fixture:** Create a concrete “Lifecycle cleanup” case that satisfies “Stopped guests leave no active executable or device ownership”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C073-T07 · Violating fixture:** Create the source counterexample “A failed boot leaves a live tender process” for “Lifecycle cleanup”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C073-T08 · Enforcement evidence:** Exercise the “Lifecycle cleanup” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C073-T09 · Regression linkage:** Link the “Lifecycle cleanup” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Lifecycle cleanup” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C074 · Integration

**Original checklist item:** Integrate lifecycle cleanup with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Lifecycle cleanup” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C074-T02 · Field mapping:** Map every “Lifecycle cleanup” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Lifecycle cleanup” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C074-T04 · Ownership agreement:** Specify who owns “Lifecycle cleanup” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C074-T05 · Handoff implementation:** Connect “Lifecycle cleanup” through the mapped seam using the real adapter or explicit specification reference; preserve “Stopped guests leave no active executable or device ownership” across the handoff.
- [ ] **UC-M03.02-C074-T06 · Absent-input case:** Omit one required “Lifecycle cleanup” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C074-T07 · Stale-input case:** Supply an outdated “Lifecycle cleanup” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Lifecycle cleanup” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C074-T09 · Valid integration trace:** Run a valid “Lifecycle cleanup” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C074-T10 · Seam review:** Reconcile the “Lifecycle cleanup” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for lifecycle cleanup; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Lifecycle cleanup” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C075-T02 · Expected-result oracle:** Specify the “Lifecycle cleanup” expected result independently of the implementation output; include the property “Stopped guests leave no active executable or device ownership” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C075-T03 · Fixture material:** Create the concrete “Lifecycle cleanup” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C075-T04 · Target preparation:** Prepare the “Lifecycle cleanup” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C075-T05 · Initial-state record:** Record the initial “Lifecycle cleanup” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C075-T06 · Valid-path execution:** Execute the “Lifecycle cleanup” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C075-T07 · Outcome comparison:** Compare every declared “Lifecycle cleanup” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C075-T08 · State and bounds check:** Inspect the “Lifecycle cleanup” ownership/state effects and actual use of “Residual resources and cleanup deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C075-T09 · Repeatability check:** Repeat the same “Lifecycle cleanup” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C075-T10 · Positive evidence:** Attach the “Lifecycle cleanup” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C076 · Negative test

**Original checklist item:** Negative case: A failed boot leaves a live tender process. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Lifecycle cleanup” source counterexample: “A failed boot leaves a live tender process”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Lifecycle cleanup”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C076-T03 · Valid control:** Construct a valid “Lifecycle cleanup” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C076-T04 · Minimal adverse input:** Derive the “Lifecycle cleanup” adverse fixture from the control with the smallest documented change needed to reproduce “A failed boot leaves a live tender process”; retain that change as reproducible data.
- [ ] **UC-M03.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Lifecycle cleanup”; require “Stopped guests leave no active executable or device ownership” and forbid a false-success verdict.
- [ ] **UC-M03.02-C076-T06 · Adverse execution:** Exercise the “Lifecycle cleanup” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C076-T07 · Effect inspection:** Inspect “Lifecycle cleanup” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C076-T08 · Refusal versus failure:** Confirm the “Lifecycle cleanup” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C076-T09 · Reset and retention:** Restore only the disposable “Lifecycle cleanup” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C076-T10 · Negative regression:** Register the “Lifecycle cleanup” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C077 · Change / failure test

**Original checklist item:** Exercise lifecycle cleanup when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C077-T01 · Scenario record:** Write the “Lifecycle cleanup” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “Stopped guests leave no active executable or device ownership”.
- [ ] **UC-M03.02-C077-T02 · Baseline capture:** Create a known-valid “Lifecycle cleanup” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C077-T03 · Injection map:** Locate the “Lifecycle cleanup” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Lifecycle cleanup” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C077-T05 · Controlled trigger:** Introduce the controlled “Lifecycle cleanup” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C077-T06 · Intermediate inspection:** Inspect the “Lifecycle cleanup” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Lifecycle cleanup”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Lifecycle cleanup” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C077-T09 · Repeat and compare:** Repeat the selected “Lifecycle cleanup” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C077-T10 · Failure evidence:** Publish the “Lifecycle cleanup” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for residual resources and cleanup deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Lifecycle cleanup”: “Residual resources and cleanup deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C078-T02 · Measurement method:** Choose how to observe each “Lifecycle cleanup” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Lifecycle cleanup”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Lifecycle cleanup” cases for “Residual resources and cleanup deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Lifecycle cleanup” limit; preserve “Stopped guests leave no active executable or device ownership”.
- [ ] **UC-M03.02-C078-T06 · Normal measurement:** Run or review the normal “Lifecycle cleanup” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C078-T07 · At-limit measurement:** Exercise the “Lifecycle cleanup” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C078-T08 · Over-limit measurement:** Exercise the “Lifecycle cleanup” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C078-T09 · Uncovered-scope report:** List the “Lifecycle cleanup” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C078-T10 · Limit evidence:** Publish the selected “Lifecycle cleanup” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for lifecycle cleanup with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C079-T01 · Event inventory:** List the “Lifecycle cleanup” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Lifecycle cleanup” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C079-T03 · Failure mapping:** Map each documented “Lifecycle cleanup” refusal or error to a diagnostic outcome; include “A failed boot leaves a live tender process” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C079-T04 · Emission path:** Add the “Lifecycle cleanup” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C079-T05 · Redaction check:** Test “Lifecycle cleanup” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C079-T06 · Output budget:** Set and exercise bounded “Lifecycle cleanup” message size, rate and retention compatible with “Residual resources and cleanup deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C079-T07 · Success/refusal fixtures:** Capture “Lifecycle cleanup” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Lifecycle cleanup” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C079-T09 · Operator review:** Read the “Lifecycle cleanup” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C079-T10 · Diagnostic evidence:** Publish redacted “Lifecycle cleanup” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for lifecycle cleanup; label unexecuted checks as untested.

- [ ] **UC-M03.02-C080-T01 · Evidence inventory:** List the “Lifecycle cleanup” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C080-T02 · Artifact references:** Record the exact “Lifecycle cleanup” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C080-T03 · Fixture references:** Attach the “Lifecycle cleanup” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed boot leaves a live tender process” as a distinct evidence case.
- [ ] **UC-M03.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Lifecycle cleanup”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C080-T05 · Environment record:** Record the actual “Lifecycle cleanup” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C080-T06 · Expected versus observed:** Pair every “Lifecycle cleanup” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C080-T07 · Failure and limit records:** Attach “Lifecycle cleanup” change/failure and bounds evidence where required; include uncovered “Residual resources and cleanup deadline” and unresolved violations of “Stopped guests leave no active executable or device ownership”.
- [ ] **UC-M03.02-C080-T08 · Evidence hygiene:** Check the “Lifecycle cleanup” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C080-T09 · Reproduction review:** Have the “Lifecycle cleanup” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C080-T10 · Acceptance linkage:** Link the “Lifecycle cleanup” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Two-guest qualification

**Source delivery:** Boot, inspect, exercise and stop two guests independently.

**Source invariant:** Host-only interpreter execution cannot satisfy the two-guest gate.

**Source negative case:** The test launches two host interpreters instead of guest images.

**Source bounded quantities:** Guest count, host capacity and observation duration.

### UC-M03.02-C081 · Contract

**Original checklist item:** Specify two-guest qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C081-T01 · Scope statement:** Draft the operation boundary for “Two-guest qualification” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Two-guest qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C081-T03 · Output inventory:** List the outputs of “Two-guest qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Two-guest qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C081-T05 · Prerequisite contract:** Map “Two-guest qualification” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Two-guest qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C081-T07 · Invariant clause:** Add a normative clause for “Two-guest qualification” that preserves “Host-only interpreter execution cannot satisfy the two-guest gate”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Two-guest qualification”; include the source counterexample “The test launches two host interpreters instead of guest images” and the intended safe disposition.
- [ ] **UC-M03.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Guest count, host capacity and observation duration” in the “Two-guest qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C081-T10 · Contract review:** Review the “Two-guest qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C082 · Delivery

**Original checklist item:** Boot, inspect, exercise and stop two guests independently.

- [ ] **UC-M03.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Two-guest qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C082-T02 · Change plan:** Break the source delivery for “Two-guest qualification” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Two-guest qualification” that realizes this source instruction: Boot, inspect, exercise and stop two guests independently.
- [ ] **UC-M03.02-C082-T04 · Concrete realization:** Trace “Two-guest qualification” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Two-guest qualification” needed to preserve “Host-only interpreter execution cannot satisfy the two-guest gate”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C082-T06 · Dependency connection:** Connect the “Two-guest qualification” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C082-T07 · Resource behavior:** Account for “Guest count, host capacity and observation duration” in “Two-guest qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C082-T08 · Delivery check:** Run the smallest real “Two-guest qualification” path and its adverse fixture “The test launches two host interpreters instead of guest images”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C082-T09 · Patch review:** Review the “Two-guest qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C082-T10 · Delivery handoff:** Publish the “Two-guest qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Host-only interpreter execution cannot satisfy the two-guest gate. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Two-guest qualification”; copy its required invariant exactly: “Host-only interpreter execution cannot satisfy the two-guest gate”.
- [ ] **UC-M03.02-C083-T02 · Observable terms:** Define each term in the “Two-guest qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C083-T03 · Precondition set:** List the preconditions under which “Host-only interpreter execution cannot satisfy the two-guest gate” must hold for “Two-guest qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C083-T04 · Transition coverage:** Map the “Two-guest qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Two-guest qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C083-T06 · Satisfying fixture:** Create a concrete “Two-guest qualification” case that satisfies “Host-only interpreter execution cannot satisfy the two-guest gate”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C083-T07 · Violating fixture:** Create the source counterexample “The test launches two host interpreters instead of guest images” for “Two-guest qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C083-T08 · Enforcement evidence:** Exercise the “Two-guest qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C083-T09 · Regression linkage:** Link the “Two-guest qualification” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Two-guest qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C084 · Integration

**Original checklist item:** Integrate two-guest qualification with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Two-guest qualification” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C084-T02 · Field mapping:** Map every “Two-guest qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Two-guest qualification” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C084-T04 · Ownership agreement:** Specify who owns “Two-guest qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C084-T05 · Handoff implementation:** Connect “Two-guest qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Host-only interpreter execution cannot satisfy the two-guest gate” across the handoff.
- [ ] **UC-M03.02-C084-T06 · Absent-input case:** Omit one required “Two-guest qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C084-T07 · Stale-input case:** Supply an outdated “Two-guest qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Two-guest qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C084-T09 · Valid integration trace:** Run a valid “Two-guest qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C084-T10 · Seam review:** Reconcile the “Two-guest qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for two-guest qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Two-guest qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C085-T02 · Expected-result oracle:** Specify the “Two-guest qualification” expected result independently of the implementation output; include the property “Host-only interpreter execution cannot satisfy the two-guest gate” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C085-T03 · Fixture material:** Create the concrete “Two-guest qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C085-T04 · Target preparation:** Prepare the “Two-guest qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C085-T05 · Initial-state record:** Record the initial “Two-guest qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C085-T06 · Valid-path execution:** Execute the “Two-guest qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C085-T07 · Outcome comparison:** Compare every declared “Two-guest qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C085-T08 · State and bounds check:** Inspect the “Two-guest qualification” ownership/state effects and actual use of “Guest count, host capacity and observation duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C085-T09 · Repeatability check:** Repeat the same “Two-guest qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C085-T10 · Positive evidence:** Attach the “Two-guest qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C086 · Negative test

**Original checklist item:** Negative case: The test launches two host interpreters instead of guest images. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Two-guest qualification” source counterexample: “The test launches two host interpreters instead of guest images”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Two-guest qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C086-T03 · Valid control:** Construct a valid “Two-guest qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C086-T04 · Minimal adverse input:** Derive the “Two-guest qualification” adverse fixture from the control with the smallest documented change needed to reproduce “The test launches two host interpreters instead of guest images”; retain that change as reproducible data.
- [ ] **UC-M03.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Two-guest qualification”; require “Host-only interpreter execution cannot satisfy the two-guest gate” and forbid a false-success verdict.
- [ ] **UC-M03.02-C086-T06 · Adverse execution:** Exercise the “Two-guest qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C086-T07 · Effect inspection:** Inspect “Two-guest qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C086-T08 · Refusal versus failure:** Confirm the “Two-guest qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C086-T09 · Reset and retention:** Restore only the disposable “Two-guest qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C086-T10 · Negative regression:** Register the “Two-guest qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C087 · Change / failure test

**Original checklist item:** Exercise two-guest qualification when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C087-T01 · Scenario record:** Write the “Two-guest qualification” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “Host-only interpreter execution cannot satisfy the two-guest gate”.
- [ ] **UC-M03.02-C087-T02 · Baseline capture:** Create a known-valid “Two-guest qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C087-T03 · Injection map:** Locate the “Two-guest qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Two-guest qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C087-T05 · Controlled trigger:** Introduce the controlled “Two-guest qualification” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C087-T06 · Intermediate inspection:** Inspect the “Two-guest qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Two-guest qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Two-guest qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C087-T09 · Repeat and compare:** Repeat the selected “Two-guest qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C087-T10 · Failure evidence:** Publish the “Two-guest qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for guest count, host capacity and observation duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Two-guest qualification”: “Guest count, host capacity and observation duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C088-T02 · Measurement method:** Choose how to observe each “Two-guest qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Two-guest qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Two-guest qualification” cases for “Guest count, host capacity and observation duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Two-guest qualification” limit; preserve “Host-only interpreter execution cannot satisfy the two-guest gate”.
- [ ] **UC-M03.02-C088-T06 · Normal measurement:** Run or review the normal “Two-guest qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C088-T07 · At-limit measurement:** Exercise the “Two-guest qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C088-T08 · Over-limit measurement:** Exercise the “Two-guest qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C088-T09 · Uncovered-scope report:** List the “Two-guest qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C088-T10 · Limit evidence:** Publish the selected “Two-guest qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for two-guest qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C089-T01 · Event inventory:** List the “Two-guest qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Two-guest qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C089-T03 · Failure mapping:** Map each documented “Two-guest qualification” refusal or error to a diagnostic outcome; include “The test launches two host interpreters instead of guest images” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C089-T04 · Emission path:** Add the “Two-guest qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C089-T05 · Redaction check:** Test “Two-guest qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C089-T06 · Output budget:** Set and exercise bounded “Two-guest qualification” message size, rate and retention compatible with “Guest count, host capacity and observation duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C089-T07 · Success/refusal fixtures:** Capture “Two-guest qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Two-guest qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C089-T09 · Operator review:** Read the “Two-guest qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C089-T10 · Diagnostic evidence:** Publish redacted “Two-guest qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for two-guest qualification; label unexecuted checks as untested.

- [ ] **UC-M03.02-C090-T01 · Evidence inventory:** List the “Two-guest qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C090-T02 · Artifact references:** Record the exact “Two-guest qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C090-T03 · Fixture references:** Attach the “Two-guest qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “The test launches two host interpreters instead of guest images” as a distinct evidence case.
- [ ] **UC-M03.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Two-guest qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C090-T05 · Environment record:** Record the actual “Two-guest qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C090-T06 · Expected versus observed:** Pair every “Two-guest qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C090-T07 · Failure and limit records:** Attach “Two-guest qualification” change/failure and bounds evidence where required; include uncovered “Guest count, host capacity and observation duration” and unresolved violations of “Host-only interpreter execution cannot satisfy the two-guest gate”.
- [ ] **UC-M03.02-C090-T08 · Evidence hygiene:** Check the “Two-guest qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C090-T09 · Reproduction review:** Have the “Two-guest qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C090-T10 · Acceptance linkage:** Link the “Two-guest qualification” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Backend failure diagnostics

**Source delivery:** Capture bounded backend startup and runtime failures with image identity.

**Source invariant:** Backend errors remain visible in the workload's final disposition.

**Source negative case:** The VMM exits before readiness and the ship reports running.

**Source bounded quantities:** Diagnostic bytes and failure reporting latency.

### UC-M03.02-C091 · Contract

**Original checklist item:** Specify backend failure diagnostics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.02-C091-T01 · Scope statement:** Draft the operation boundary for “Backend failure diagnostics” within Real hypervisor or tender integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backend failure diagnostics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.02-C091-T03 · Output inventory:** List the outputs of “Backend failure diagnostics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Backend failure diagnostics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.02-C091-T05 · Prerequisite contract:** Map “Backend failure diagnostics” to the source component prerequisites (UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Backend failure diagnostics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.02-C091-T07 · Invariant clause:** Add a normative clause for “Backend failure diagnostics” that preserves “Backend errors remain visible in the workload's final disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backend failure diagnostics”; include the source counterexample “The VMM exits before readiness and the ship reports running” and the intended safe disposition.
- [ ] **UC-M03.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Diagnostic bytes and failure reporting latency” in the “Backend failure diagnostics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.02-C091-T10 · Contract review:** Review the “Backend failure diagnostics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.02-C092 · Delivery

**Original checklist item:** Capture bounded backend startup and runtime failures with image identity.

- [ ] **UC-M03.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backend failure diagnostics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.02-C092-T02 · Change plan:** Break the source delivery for “Backend failure diagnostics” into concrete edit targets and reviewable outputs; keep the UC-M03.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.02-C092-T03 · Core artifact:** Create the “Backend failure diagnostics” output artifact for this source instruction: Capture bounded backend startup and runtime failures with image identity.
- [ ] **UC-M03.02-C092-T04 · Concrete realization:** Populate the “Backend failure diagnostics” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M03.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backend failure diagnostics” needed to preserve “Backend errors remain visible in the workload's final disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.02-C092-T06 · Dependency connection:** Connect the “Backend failure diagnostics” implementation to admitted images, boot configuration and per-instance backend controls; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.02-C092-T07 · Resource behavior:** Account for “Diagnostic bytes and failure reporting latency” in “Backend failure diagnostics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.02-C092-T08 · Delivery check:** Run the smallest real “Backend failure diagnostics” path and its adverse fixture “The VMM exits before readiness and the ship reports running”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.02-C092-T09 · Patch review:** Review the “Backend failure diagnostics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.02-C092-T10 · Delivery handoff:** Publish the “Backend failure diagnostics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Backend errors remain visible in the workload's final disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Backend failure diagnostics”; copy its required invariant exactly: “Backend errors remain visible in the workload's final disposition”.
- [ ] **UC-M03.02-C093-T02 · Observable terms:** Define each term in the “Backend failure diagnostics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.02-C093-T03 · Precondition set:** List the preconditions under which “Backend errors remain visible in the workload's final disposition” must hold for “Backend failure diagnostics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.02-C093-T04 · Transition coverage:** Map the “Backend failure diagnostics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backend failure diagnostics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.02-C093-T06 · Satisfying fixture:** Create a concrete “Backend failure diagnostics” case that satisfies “Backend errors remain visible in the workload's final disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.02-C093-T07 · Violating fixture:** Create the source counterexample “The VMM exits before readiness and the ship reports running” for “Backend failure diagnostics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.02-C093-T08 · Enforcement evidence:** Exercise the “Backend failure diagnostics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.02-C093-T09 · Regression linkage:** Link the “Backend failure diagnostics” property to changes in admitted images, boot configuration and per-instance backend controls; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Backend failure diagnostics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.02-C094 · Integration

**Original checklist item:** Integrate backend failure diagnostics with admitted images, boot configuration and per-instance backend controls; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backend failure diagnostics” across admitted images, boot configuration and per-instance backend controls; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.02-C094-T02 · Field mapping:** Map every “Backend failure diagnostics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Backend failure diagnostics” (source dependency list: UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.02-C094-T04 · Ownership agreement:** Specify who owns “Backend failure diagnostics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.02-C094-T05 · Handoff implementation:** Connect “Backend failure diagnostics” through the mapped seam using the real adapter or explicit specification reference; preserve “Backend errors remain visible in the workload's final disposition” across the handoff.
- [ ] **UC-M03.02-C094-T06 · Absent-input case:** Omit one required “Backend failure diagnostics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.02-C094-T07 · Stale-input case:** Supply an outdated “Backend failure diagnostics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Backend failure diagnostics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.02-C094-T09 · Valid integration trace:** Run a valid “Backend failure diagnostics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.02-C094-T10 · Seam review:** Reconcile the “Backend failure diagnostics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for backend failure diagnostics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Backend failure diagnostics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.02-C095-T02 · Expected-result oracle:** Specify the “Backend failure diagnostics” expected result independently of the implementation output; include the property “Backend errors remain visible in the workload's final disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.02-C095-T03 · Fixture material:** Create the concrete “Backend failure diagnostics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.02-C095-T04 · Target preparation:** Prepare the “Backend failure diagnostics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.02-C095-T05 · Initial-state record:** Record the initial “Backend failure diagnostics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.02-C095-T06 · Valid-path execution:** Execute the “Backend failure diagnostics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.02-C095-T07 · Outcome comparison:** Compare every declared “Backend failure diagnostics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.02-C095-T08 · State and bounds check:** Inspect the “Backend failure diagnostics” ownership/state effects and actual use of “Diagnostic bytes and failure reporting latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.02-C095-T09 · Repeatability check:** Repeat the same “Backend failure diagnostics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.02-C095-T10 · Positive evidence:** Attach the “Backend failure diagnostics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.02-C096 · Negative test

**Original checklist item:** Negative case: The VMM exits before readiness and the ship reports running. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Backend failure diagnostics” source counterexample: “The VMM exits before readiness and the ship reports running”; state which precondition or invariant it challenges.
- [ ] **UC-M03.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Backend failure diagnostics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.02-C096-T03 · Valid control:** Construct a valid “Backend failure diagnostics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.02-C096-T04 · Minimal adverse input:** Derive the “Backend failure diagnostics” adverse fixture from the control with the smallest documented change needed to reproduce “The VMM exits before readiness and the ship reports running”; retain that change as reproducible data.
- [ ] **UC-M03.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backend failure diagnostics”; require “Backend errors remain visible in the workload's final disposition” and forbid a false-success verdict.
- [ ] **UC-M03.02-C096-T06 · Adverse execution:** Exercise the “Backend failure diagnostics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.02-C096-T07 · Effect inspection:** Inspect “Backend failure diagnostics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.02-C096-T08 · Refusal versus failure:** Confirm the “Backend failure diagnostics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.02-C096-T09 · Reset and retention:** Restore only the disposable “Backend failure diagnostics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.02-C096-T10 · Negative regression:** Register the “Backend failure diagnostics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.02-C097 · Change / failure test

**Original checklist item:** Exercise backend failure diagnostics when one guest fails while a second independently controlled guest remains active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.02-C097-T01 · Scenario record:** Write the “Backend failure diagnostics” change/failure scenario exactly as supplied: one guest fails while a second independently controlled guest remains active; identify the property that must remain true: “Backend errors remain visible in the workload's final disposition”.
- [ ] **UC-M03.02-C097-T02 · Baseline capture:** Create a known-valid “Backend failure diagnostics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.02-C097-T03 · Injection map:** Locate the “Backend failure diagnostics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Backend failure diagnostics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.02-C097-T05 · Controlled trigger:** Introduce the controlled “Backend failure diagnostics” scenario in the disposable fixture: one guest fails while a second independently controlled guest remains active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.02-C097-T06 · Intermediate inspection:** Inspect the “Backend failure diagnostics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backend failure diagnostics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Backend failure diagnostics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.02-C097-T09 · Repeat and compare:** Repeat the selected “Backend failure diagnostics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.02-C097-T10 · Failure evidence:** Publish the “Backend failure diagnostics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for diagnostic bytes and failure reporting latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Backend failure diagnostics”: “Diagnostic bytes and failure reporting latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.02-C098-T02 · Measurement method:** Choose how to observe each “Backend failure diagnostics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Backend failure diagnostics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backend failure diagnostics” cases for “Diagnostic bytes and failure reporting latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backend failure diagnostics” limit; preserve “Backend errors remain visible in the workload's final disposition”.
- [ ] **UC-M03.02-C098-T06 · Normal measurement:** Run or review the normal “Backend failure diagnostics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.02-C098-T07 · At-limit measurement:** Exercise the “Backend failure diagnostics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.02-C098-T08 · Over-limit measurement:** Exercise the “Backend failure diagnostics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.02-C098-T09 · Uncovered-scope report:** List the “Backend failure diagnostics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.02-C098-T10 · Limit evidence:** Publish the selected “Backend failure diagnostics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for backend failure diagnostics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.02-C099-T01 · Event inventory:** List the “Backend failure diagnostics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Backend failure diagnostics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.02-C099-T03 · Failure mapping:** Map each documented “Backend failure diagnostics” refusal or error to a diagnostic outcome; include “The VMM exits before readiness and the ship reports running” and prohibit conversion into a success message.
- [ ] **UC-M03.02-C099-T04 · Emission path:** Add the “Backend failure diagnostics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.02-C099-T05 · Redaction check:** Test “Backend failure diagnostics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.02-C099-T06 · Output budget:** Set and exercise bounded “Backend failure diagnostics” message size, rate and retention compatible with “Diagnostic bytes and failure reporting latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.02-C099-T07 · Success/refusal fixtures:** Capture “Backend failure diagnostics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Backend failure diagnostics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.02-C099-T09 · Operator review:** Read the “Backend failure diagnostics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.02-C099-T10 · Diagnostic evidence:** Publish redacted “Backend failure diagnostics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backend failure diagnostics; label unexecuted checks as untested.

- [ ] **UC-M03.02-C100-T01 · Evidence inventory:** List the “Backend failure diagnostics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.02-C100-T02 · Artifact references:** Record the exact “Backend failure diagnostics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.02-C100-T03 · Fixture references:** Attach the “Backend failure diagnostics” fixture IDs, input identities and oracle definition; preserve the source counterexample “The VMM exits before readiness and the ship reports running” as a distinct evidence case.
- [ ] **UC-M03.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backend failure diagnostics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.02-C100-T05 · Environment record:** Record the actual “Backend failure diagnostics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.02-C100-T06 · Expected versus observed:** Pair every “Backend failure diagnostics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.02-C100-T07 · Failure and limit records:** Attach “Backend failure diagnostics” change/failure and bounds evidence where required; include uncovered “Diagnostic bytes and failure reporting latency” and unresolved violations of “Backend errors remain visible in the workload's final disposition”.
- [ ] **UC-M03.02-C100-T08 · Evidence hygiene:** Check the “Backend failure diagnostics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.02-C100-T09 · Reproduction review:** Have the “Backend failure diagnostics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.02-C100-T10 · Acceptance linkage:** Link the “Backend failure diagnostics” evidence to its parent and UC-M03.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

