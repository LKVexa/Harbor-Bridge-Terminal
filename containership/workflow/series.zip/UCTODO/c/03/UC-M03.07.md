# UC-M03.07 — Privilege-separated resource broker

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/03.md)

| Field | Preserved source value |
|---|---|
| Workstream | 03. Host isolation and supervision |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.03](../03/UC-M03.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S3], [S4]. |

## Original requirement

Concentrate privileged device/network operations in a small authenticated broker instead of the entire ship process.

**Original acceptance criterion:** Unprivileged ship operation succeeds with only narrowly scoped broker requests; arbitrary paths and commands are denied.

**Source trace:** Original checklist `UC100/c/03/UC-M03.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 305–315 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Privilege inventory

**Source delivery:** List device, network and resource actions that actually require elevated authority.

**Source invariant:** Only necessary privileged actions belong in the broker.

**Source negative case:** A convenience operation grants the broker unrestricted shell execution.

**Source bounded quantities:** Privileged operation count and exposed surface.

### UC-M03.07-C001 · Contract

**Original checklist item:** Specify privilege inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C001-T01 · Scope statement:** Draft the operation boundary for “Privilege inventory” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Privilege inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C001-T03 · Output inventory:** List the outputs of “Privilege inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Privilege inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C001-T05 · Prerequisite contract:** Map “Privilege inventory” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Privilege inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C001-T07 · Invariant clause:** Add a normative clause for “Privilege inventory” that preserves “Only necessary privileged actions belong in the broker”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Privilege inventory”; include the source counterexample “A convenience operation grants the broker unrestricted shell execution” and the intended safe disposition.
- [ ] **UC-M03.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Privileged operation count and exposed surface” in the “Privilege inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C001-T10 · Contract review:** Review the “Privilege inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C002 · Delivery

**Original checklist item:** List device, network and resource actions that actually require elevated authority.

- [ ] **UC-M03.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Privilege inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C002-T02 · Change plan:** Break the source delivery for “Privilege inventory” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C002-T03 · Core artifact:** Create the “Privilege inventory” model, schema or inventory that realizes this source instruction: List device, network and resource actions that actually require elevated authority.
- [ ] **UC-M03.07-C002-T04 · Concrete realization:** Populate “Privilege inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Privilege inventory” needed to preserve “Only necessary privileged actions belong in the broker”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C002-T06 · Dependency connection:** Connect the “Privilege inventory” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C002-T07 · Resource behavior:** Account for “Privileged operation count and exposed surface” in “Privilege inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C002-T08 · Delivery check:** Run the smallest real “Privilege inventory” path and its adverse fixture “A convenience operation grants the broker unrestricted shell execution”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C002-T09 · Patch review:** Review the “Privilege inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C002-T10 · Delivery handoff:** Publish the “Privilege inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Only necessary privileged actions belong in the broker. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Privilege inventory”; copy its required invariant exactly: “Only necessary privileged actions belong in the broker”.
- [ ] **UC-M03.07-C003-T02 · Observable terms:** Define each term in the “Privilege inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C003-T03 · Precondition set:** List the preconditions under which “Only necessary privileged actions belong in the broker” must hold for “Privilege inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C003-T04 · Transition coverage:** Map the “Privilege inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Privilege inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C003-T06 · Satisfying fixture:** Create a concrete “Privilege inventory” case that satisfies “Only necessary privileged actions belong in the broker”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C003-T07 · Violating fixture:** Create the source counterexample “A convenience operation grants the broker unrestricted shell execution” for “Privilege inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C003-T08 · Enforcement evidence:** Exercise the “Privilege inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C003-T09 · Regression linkage:** Link the “Privilege inventory” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Privilege inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C004 · Integration

**Original checklist item:** Integrate privilege inventory with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Privilege inventory” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C004-T02 · Field mapping:** Map every “Privilege inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Privilege inventory” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C004-T04 · Ownership agreement:** Specify who owns “Privilege inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C004-T05 · Handoff implementation:** Connect “Privilege inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Only necessary privileged actions belong in the broker” across the handoff.
- [ ] **UC-M03.07-C004-T06 · Absent-input case:** Omit one required “Privilege inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C004-T07 · Stale-input case:** Supply an outdated “Privilege inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Privilege inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C004-T09 · Valid integration trace:** Run a valid “Privilege inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C004-T10 · Seam review:** Reconcile the “Privilege inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for privilege inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Privilege inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C005-T02 · Expected-result oracle:** Specify the “Privilege inventory” expected result independently of the implementation output; include the property “Only necessary privileged actions belong in the broker” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C005-T03 · Fixture material:** Create the concrete “Privilege inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C005-T04 · Target preparation:** Prepare the “Privilege inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C005-T05 · Initial-state record:** Record the initial “Privilege inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C005-T06 · Valid-path execution:** Execute the “Privilege inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C005-T07 · Outcome comparison:** Compare every declared “Privilege inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C005-T08 · State and bounds check:** Inspect the “Privilege inventory” ownership/state effects and actual use of “Privileged operation count and exposed surface”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C005-T09 · Repeatability check:** Repeat the same “Privilege inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C005-T10 · Positive evidence:** Attach the “Privilege inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C006 · Negative test

**Original checklist item:** Negative case: A convenience operation grants the broker unrestricted shell execution. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Privilege inventory” source counterexample: “A convenience operation grants the broker unrestricted shell execution”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Privilege inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C006-T03 · Valid control:** Construct a valid “Privilege inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C006-T04 · Minimal adverse input:** Derive the “Privilege inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A convenience operation grants the broker unrestricted shell execution”; retain that change as reproducible data.
- [ ] **UC-M03.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Privilege inventory”; require “Only necessary privileged actions belong in the broker” and forbid a false-success verdict.
- [ ] **UC-M03.07-C006-T06 · Adverse execution:** Exercise the “Privilege inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C006-T07 · Effect inspection:** Inspect “Privilege inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C006-T08 · Refusal versus failure:** Confirm the “Privilege inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C006-T09 · Reset and retention:** Restore only the disposable “Privilege inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C006-T10 · Negative regression:** Register the “Privilege inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C007 · Change / failure test

**Original checklist item:** Exercise privilege inventory when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C007-T01 · Scenario record:** Write the “Privilege inventory” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “Only necessary privileged actions belong in the broker”.
- [ ] **UC-M03.07-C007-T02 · Baseline capture:** Create a known-valid “Privilege inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C007-T03 · Injection map:** Locate the “Privilege inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Privilege inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C007-T05 · Controlled trigger:** Introduce the controlled “Privilege inventory” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C007-T06 · Intermediate inspection:** Inspect the “Privilege inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Privilege inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Privilege inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C007-T09 · Repeat and compare:** Repeat the selected “Privilege inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C007-T10 · Failure evidence:** Publish the “Privilege inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for privileged operation count and exposed surface; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Privilege inventory”: “Privileged operation count and exposed surface”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C008-T02 · Measurement method:** Choose how to observe each “Privilege inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Privilege inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Privilege inventory” cases for “Privileged operation count and exposed surface”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Privilege inventory” limit; preserve “Only necessary privileged actions belong in the broker”.
- [ ] **UC-M03.07-C008-T06 · Normal measurement:** Run or review the normal “Privilege inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C008-T07 · At-limit measurement:** Exercise the “Privilege inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C008-T08 · Over-limit measurement:** Exercise the “Privilege inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C008-T09 · Uncovered-scope report:** List the “Privilege inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C008-T10 · Limit evidence:** Publish the selected “Privilege inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for privilege inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C009-T01 · Event inventory:** List the “Privilege inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Privilege inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C009-T03 · Failure mapping:** Map each documented “Privilege inventory” refusal or error to a diagnostic outcome; include “A convenience operation grants the broker unrestricted shell execution” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C009-T04 · Emission path:** Add the “Privilege inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C009-T05 · Redaction check:** Test “Privilege inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C009-T06 · Output budget:** Set and exercise bounded “Privilege inventory” message size, rate and retention compatible with “Privileged operation count and exposed surface”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C009-T07 · Success/refusal fixtures:** Capture “Privilege inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Privilege inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C009-T09 · Operator review:** Read the “Privilege inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C009-T10 · Diagnostic evidence:** Publish redacted “Privilege inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for privilege inventory; label unexecuted checks as untested.

- [ ] **UC-M03.07-C010-T01 · Evidence inventory:** List the “Privilege inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C010-T02 · Artifact references:** Record the exact “Privilege inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C010-T03 · Fixture references:** Attach the “Privilege inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A convenience operation grants the broker unrestricted shell execution” as a distinct evidence case.
- [ ] **UC-M03.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Privilege inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C010-T05 · Environment record:** Record the actual “Privilege inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C010-T06 · Expected versus observed:** Pair every “Privilege inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C010-T07 · Failure and limit records:** Attach “Privilege inventory” change/failure and bounds evidence where required; include uncovered “Privileged operation count and exposed surface” and unresolved violations of “Only necessary privileged actions belong in the broker”.
- [ ] **UC-M03.07-C010-T08 · Evidence hygiene:** Check the “Privilege inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C010-T09 · Reproduction review:** Have the “Privilege inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C010-T10 · Acceptance linkage:** Link the “Privilege inventory” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Broker request schema

**Source delivery:** Define typed requests with explicit resource identity and permitted parameters.

**Source invariant:** A broker request cannot contain an arbitrary command.

**Source negative case:** A request supplies a shell fragment instead of a typed operation.

**Source bounded quantities:** Request bytes, field count and nesting.

### UC-M03.07-C011 · Contract

**Original checklist item:** Specify broker request schema inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C011-T01 · Scope statement:** Draft the operation boundary for “Broker request schema” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Broker request schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C011-T03 · Output inventory:** List the outputs of “Broker request schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Broker request schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C011-T05 · Prerequisite contract:** Map “Broker request schema” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Broker request schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C011-T07 · Invariant clause:** Add a normative clause for “Broker request schema” that preserves “A broker request cannot contain an arbitrary command”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Broker request schema”; include the source counterexample “A request supplies a shell fragment instead of a typed operation” and the intended safe disposition.
- [ ] **UC-M03.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Request bytes, field count and nesting” in the “Broker request schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C011-T10 · Contract review:** Review the “Broker request schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C012 · Delivery

**Original checklist item:** Define typed requests with explicit resource identity and permitted parameters.

- [ ] **UC-M03.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Broker request schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C012-T02 · Change plan:** Break the source delivery for “Broker request schema” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C012-T03 · Core artifact:** Create the “Broker request schema” model, schema or inventory that realizes this source instruction: Define typed requests with explicit resource identity and permitted parameters.
- [ ] **UC-M03.07-C012-T04 · Concrete realization:** Populate “Broker request schema” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Broker request schema” needed to preserve “A broker request cannot contain an arbitrary command”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C012-T06 · Dependency connection:** Connect the “Broker request schema” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C012-T07 · Resource behavior:** Account for “Request bytes, field count and nesting” in “Broker request schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C012-T08 · Delivery check:** Run the smallest real “Broker request schema” path and its adverse fixture “A request supplies a shell fragment instead of a typed operation”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C012-T09 · Patch review:** Review the “Broker request schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C012-T10 · Delivery handoff:** Publish the “Broker request schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A broker request cannot contain an arbitrary command. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Broker request schema”; copy its required invariant exactly: “A broker request cannot contain an arbitrary command”.
- [ ] **UC-M03.07-C013-T02 · Observable terms:** Define each term in the “Broker request schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C013-T03 · Precondition set:** List the preconditions under which “A broker request cannot contain an arbitrary command” must hold for “Broker request schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C013-T04 · Transition coverage:** Map the “Broker request schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Broker request schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C013-T06 · Satisfying fixture:** Create a concrete “Broker request schema” case that satisfies “A broker request cannot contain an arbitrary command”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C013-T07 · Violating fixture:** Create the source counterexample “A request supplies a shell fragment instead of a typed operation” for “Broker request schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C013-T08 · Enforcement evidence:** Exercise the “Broker request schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C013-T09 · Regression linkage:** Link the “Broker request schema” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Broker request schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C014 · Integration

**Original checklist item:** Integrate broker request schema with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Broker request schema” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C014-T02 · Field mapping:** Map every “Broker request schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Broker request schema” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C014-T04 · Ownership agreement:** Specify who owns “Broker request schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C014-T05 · Handoff implementation:** Connect “Broker request schema” through the mapped seam using the real adapter or explicit specification reference; preserve “A broker request cannot contain an arbitrary command” across the handoff.
- [ ] **UC-M03.07-C014-T06 · Absent-input case:** Omit one required “Broker request schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C014-T07 · Stale-input case:** Supply an outdated “Broker request schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Broker request schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C014-T09 · Valid integration trace:** Run a valid “Broker request schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C014-T10 · Seam review:** Reconcile the “Broker request schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for broker request schema; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Broker request schema” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C015-T02 · Expected-result oracle:** Specify the “Broker request schema” expected result independently of the implementation output; include the property “A broker request cannot contain an arbitrary command” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C015-T03 · Fixture material:** Create the concrete “Broker request schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C015-T04 · Target preparation:** Prepare the “Broker request schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C015-T05 · Initial-state record:** Record the initial “Broker request schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C015-T06 · Valid-path execution:** Execute the “Broker request schema” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C015-T07 · Outcome comparison:** Compare every declared “Broker request schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C015-T08 · State and bounds check:** Inspect the “Broker request schema” ownership/state effects and actual use of “Request bytes, field count and nesting”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C015-T09 · Repeatability check:** Repeat the same “Broker request schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C015-T10 · Positive evidence:** Attach the “Broker request schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C016 · Negative test

**Original checklist item:** Negative case: A request supplies a shell fragment instead of a typed operation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Broker request schema” source counterexample: “A request supplies a shell fragment instead of a typed operation”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Broker request schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C016-T03 · Valid control:** Construct a valid “Broker request schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C016-T04 · Minimal adverse input:** Derive the “Broker request schema” adverse fixture from the control with the smallest documented change needed to reproduce “A request supplies a shell fragment instead of a typed operation”; retain that change as reproducible data.
- [ ] **UC-M03.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Broker request schema”; require “A broker request cannot contain an arbitrary command” and forbid a false-success verdict.
- [ ] **UC-M03.07-C016-T06 · Adverse execution:** Exercise the “Broker request schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C016-T07 · Effect inspection:** Inspect “Broker request schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C016-T08 · Refusal versus failure:** Confirm the “Broker request schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C016-T09 · Reset and retention:** Restore only the disposable “Broker request schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C016-T10 · Negative regression:** Register the “Broker request schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C017 · Change / failure test

**Original checklist item:** Exercise broker request schema when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C017-T01 · Scenario record:** Write the “Broker request schema” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “A broker request cannot contain an arbitrary command”.
- [ ] **UC-M03.07-C017-T02 · Baseline capture:** Create a known-valid “Broker request schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C017-T03 · Injection map:** Locate the “Broker request schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Broker request schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C017-T05 · Controlled trigger:** Introduce the controlled “Broker request schema” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C017-T06 · Intermediate inspection:** Inspect the “Broker request schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Broker request schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Broker request schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C017-T09 · Repeat and compare:** Repeat the selected “Broker request schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C017-T10 · Failure evidence:** Publish the “Broker request schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for request bytes, field count and nesting; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Broker request schema”: “Request bytes, field count and nesting”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C018-T02 · Measurement method:** Choose how to observe each “Broker request schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Broker request schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Broker request schema” cases for “Request bytes, field count and nesting”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Broker request schema” limit; preserve “A broker request cannot contain an arbitrary command”.
- [ ] **UC-M03.07-C018-T06 · Normal measurement:** Run or review the normal “Broker request schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C018-T07 · At-limit measurement:** Exercise the “Broker request schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C018-T08 · Over-limit measurement:** Exercise the “Broker request schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C018-T09 · Uncovered-scope report:** List the “Broker request schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C018-T10 · Limit evidence:** Publish the selected “Broker request schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for broker request schema with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C019-T01 · Event inventory:** List the “Broker request schema” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Broker request schema” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C019-T03 · Failure mapping:** Map each documented “Broker request schema” refusal or error to a diagnostic outcome; include “A request supplies a shell fragment instead of a typed operation” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C019-T04 · Emission path:** Add the “Broker request schema” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C019-T05 · Redaction check:** Test “Broker request schema” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C019-T06 · Output budget:** Set and exercise bounded “Broker request schema” message size, rate and retention compatible with “Request bytes, field count and nesting”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C019-T07 · Success/refusal fixtures:** Capture “Broker request schema” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Broker request schema” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C019-T09 · Operator review:** Read the “Broker request schema” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C019-T10 · Diagnostic evidence:** Publish redacted “Broker request schema” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for broker request schema; label unexecuted checks as untested.

- [ ] **UC-M03.07-C020-T01 · Evidence inventory:** List the “Broker request schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C020-T02 · Artifact references:** Record the exact “Broker request schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C020-T03 · Fixture references:** Attach the “Broker request schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “A request supplies a shell fragment instead of a typed operation” as a distinct evidence case.
- [ ] **UC-M03.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Broker request schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C020-T05 · Environment record:** Record the actual “Broker request schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C020-T06 · Expected versus observed:** Pair every “Broker request schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C020-T07 · Failure and limit records:** Attach “Broker request schema” change/failure and bounds evidence where required; include uncovered “Request bytes, field count and nesting” and unresolved violations of “A broker request cannot contain an arbitrary command”.
- [ ] **UC-M03.07-C020-T08 · Evidence hygiene:** Check the “Broker request schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C020-T09 · Reproduction review:** Have the “Broker request schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C020-T10 · Acceptance linkage:** Link the “Broker request schema” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Client authentication

**Source delivery:** Authenticate management clients before processing privileged requests.

**Source invariant:** Unidentified clients cannot exercise broker authority.

**Source negative case:** An unauthenticated local process sends a valid-looking device request.

**Source bounded quantities:** Client count and authentication deadline.

### UC-M03.07-C021 · Contract

**Original checklist item:** Specify client authentication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C021-T01 · Scope statement:** Draft the operation boundary for “Client authentication” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Client authentication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C021-T03 · Output inventory:** List the outputs of “Client authentication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Client authentication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C021-T05 · Prerequisite contract:** Map “Client authentication” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Client authentication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C021-T07 · Invariant clause:** Add a normative clause for “Client authentication” that preserves “Unidentified clients cannot exercise broker authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Client authentication”; include the source counterexample “An unauthenticated local process sends a valid-looking device request” and the intended safe disposition.
- [ ] **UC-M03.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Client count and authentication deadline” in the “Client authentication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C021-T10 · Contract review:** Review the “Client authentication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C022 · Delivery

**Original checklist item:** Authenticate management clients before processing privileged requests.

- [ ] **UC-M03.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Client authentication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C022-T02 · Change plan:** Break the source delivery for “Client authentication” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Client authentication” that realizes this source instruction: Authenticate management clients before processing privileged requests.
- [ ] **UC-M03.07-C022-T04 · Concrete realization:** Trace “Client authentication” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Client authentication” needed to preserve “Unidentified clients cannot exercise broker authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C022-T06 · Dependency connection:** Connect the “Client authentication” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C022-T07 · Resource behavior:** Account for “Client count and authentication deadline” in “Client authentication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C022-T08 · Delivery check:** Run the smallest real “Client authentication” path and its adverse fixture “An unauthenticated local process sends a valid-looking device request”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C022-T09 · Patch review:** Review the “Client authentication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C022-T10 · Delivery handoff:** Publish the “Client authentication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unidentified clients cannot exercise broker authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Client authentication”; copy its required invariant exactly: “Unidentified clients cannot exercise broker authority”.
- [ ] **UC-M03.07-C023-T02 · Observable terms:** Define each term in the “Client authentication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C023-T03 · Precondition set:** List the preconditions under which “Unidentified clients cannot exercise broker authority” must hold for “Client authentication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C023-T04 · Transition coverage:** Map the “Client authentication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Client authentication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C023-T06 · Satisfying fixture:** Create a concrete “Client authentication” case that satisfies “Unidentified clients cannot exercise broker authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C023-T07 · Violating fixture:** Create the source counterexample “An unauthenticated local process sends a valid-looking device request” for “Client authentication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C023-T08 · Enforcement evidence:** Exercise the “Client authentication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C023-T09 · Regression linkage:** Link the “Client authentication” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Client authentication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C024 · Integration

**Original checklist item:** Integrate client authentication with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Client authentication” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C024-T02 · Field mapping:** Map every “Client authentication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Client authentication” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C024-T04 · Ownership agreement:** Specify who owns “Client authentication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C024-T05 · Handoff implementation:** Connect “Client authentication” through the mapped seam using the real adapter or explicit specification reference; preserve “Unidentified clients cannot exercise broker authority” across the handoff.
- [ ] **UC-M03.07-C024-T06 · Absent-input case:** Omit one required “Client authentication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C024-T07 · Stale-input case:** Supply an outdated “Client authentication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Client authentication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C024-T09 · Valid integration trace:** Run a valid “Client authentication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C024-T10 · Seam review:** Reconcile the “Client authentication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for client authentication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Client authentication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C025-T02 · Expected-result oracle:** Specify the “Client authentication” expected result independently of the implementation output; include the property “Unidentified clients cannot exercise broker authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C025-T03 · Fixture material:** Create the concrete “Client authentication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C025-T04 · Target preparation:** Prepare the “Client authentication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C025-T05 · Initial-state record:** Record the initial “Client authentication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C025-T06 · Valid-path execution:** Execute the “Client authentication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C025-T07 · Outcome comparison:** Compare every declared “Client authentication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C025-T08 · State and bounds check:** Inspect the “Client authentication” ownership/state effects and actual use of “Client count and authentication deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C025-T09 · Repeatability check:** Repeat the same “Client authentication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C025-T10 · Positive evidence:** Attach the “Client authentication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C026 · Negative test

**Original checklist item:** Negative case: An unauthenticated local process sends a valid-looking device request. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Client authentication” source counterexample: “An unauthenticated local process sends a valid-looking device request”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Client authentication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C026-T03 · Valid control:** Construct a valid “Client authentication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C026-T04 · Minimal adverse input:** Derive the “Client authentication” adverse fixture from the control with the smallest documented change needed to reproduce “An unauthenticated local process sends a valid-looking device request”; retain that change as reproducible data.
- [ ] **UC-M03.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Client authentication”; require “Unidentified clients cannot exercise broker authority” and forbid a false-success verdict.
- [ ] **UC-M03.07-C026-T06 · Adverse execution:** Exercise the “Client authentication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C026-T07 · Effect inspection:** Inspect “Client authentication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C026-T08 · Refusal versus failure:** Confirm the “Client authentication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C026-T09 · Reset and retention:** Restore only the disposable “Client authentication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C026-T10 · Negative regression:** Register the “Client authentication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C027 · Change / failure test

**Original checklist item:** Exercise client authentication when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C027-T01 · Scenario record:** Write the “Client authentication” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “Unidentified clients cannot exercise broker authority”.
- [ ] **UC-M03.07-C027-T02 · Baseline capture:** Create a known-valid “Client authentication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C027-T03 · Injection map:** Locate the “Client authentication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Client authentication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C027-T05 · Controlled trigger:** Introduce the controlled “Client authentication” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C027-T06 · Intermediate inspection:** Inspect the “Client authentication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Client authentication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Client authentication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C027-T09 · Repeat and compare:** Repeat the selected “Client authentication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C027-T10 · Failure evidence:** Publish the “Client authentication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for client count and authentication deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Client authentication”: “Client count and authentication deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C028-T02 · Measurement method:** Choose how to observe each “Client authentication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Client authentication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Client authentication” cases for “Client count and authentication deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Client authentication” limit; preserve “Unidentified clients cannot exercise broker authority”.
- [ ] **UC-M03.07-C028-T06 · Normal measurement:** Run or review the normal “Client authentication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C028-T07 · At-limit measurement:** Exercise the “Client authentication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C028-T08 · Over-limit measurement:** Exercise the “Client authentication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C028-T09 · Uncovered-scope report:** List the “Client authentication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C028-T10 · Limit evidence:** Publish the selected “Client authentication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for client authentication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C029-T01 · Event inventory:** List the “Client authentication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Client authentication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C029-T03 · Failure mapping:** Map each documented “Client authentication” refusal or error to a diagnostic outcome; include “An unauthenticated local process sends a valid-looking device request” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C029-T04 · Emission path:** Add the “Client authentication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C029-T05 · Redaction check:** Test “Client authentication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C029-T06 · Output budget:** Set and exercise bounded “Client authentication” message size, rate and retention compatible with “Client count and authentication deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C029-T07 · Success/refusal fixtures:** Capture “Client authentication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Client authentication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C029-T09 · Operator review:** Read the “Client authentication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C029-T10 · Diagnostic evidence:** Publish redacted “Client authentication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for client authentication; label unexecuted checks as untested.

- [ ] **UC-M03.07-C030-T01 · Evidence inventory:** List the “Client authentication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C030-T02 · Artifact references:** Record the exact “Client authentication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C030-T03 · Fixture references:** Attach the “Client authentication” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unauthenticated local process sends a valid-looking device request” as a distinct evidence case.
- [ ] **UC-M03.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Client authentication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C030-T05 · Environment record:** Record the actual “Client authentication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C030-T06 · Expected versus observed:** Pair every “Client authentication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C030-T07 · Failure and limit records:** Attach “Client authentication” change/failure and bounds evidence where required; include uncovered “Client count and authentication deadline” and unresolved violations of “Unidentified clients cannot exercise broker authority”.
- [ ] **UC-M03.07-C030-T08 · Evidence hygiene:** Check the “Client authentication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C030-T09 · Reproduction review:** Have the “Client authentication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C030-T10 · Acceptance linkage:** Link the “Client authentication” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Per-operation authorization

**Source delivery:** Check caller permission and workload scope for each privileged operation.

**Source invariant:** Authentication alone does not authorize every broker function.

**Source negative case:** A read-only client requests device creation.

**Source bounded quantities:** Policy rules and authorization time.

### UC-M03.07-C031 · Contract

**Original checklist item:** Specify per-operation authorization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C031-T01 · Scope statement:** Draft the operation boundary for “Per-operation authorization” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Per-operation authorization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C031-T03 · Output inventory:** List the outputs of “Per-operation authorization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Per-operation authorization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C031-T05 · Prerequisite contract:** Map “Per-operation authorization” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Per-operation authorization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C031-T07 · Invariant clause:** Add a normative clause for “Per-operation authorization” that preserves “Authentication alone does not authorize every broker function”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Per-operation authorization”; include the source counterexample “A read-only client requests device creation” and the intended safe disposition.
- [ ] **UC-M03.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Policy rules and authorization time” in the “Per-operation authorization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C031-T10 · Contract review:** Review the “Per-operation authorization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C032 · Delivery

**Original checklist item:** Check caller permission and workload scope for each privileged operation.

- [ ] **UC-M03.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Per-operation authorization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C032-T02 · Change plan:** Break the source delivery for “Per-operation authorization” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C032-T03 · Core artifact:** Create the “Per-operation authorization” fixture or harness for this source instruction: Check caller permission and workload scope for each privileged operation.
- [ ] **UC-M03.07-C032-T04 · Concrete realization:** Connect the “Per-operation authorization” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Per-operation authorization” needed to preserve “Authentication alone does not authorize every broker function”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C032-T06 · Dependency connection:** Connect the “Per-operation authorization” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C032-T07 · Resource behavior:** Account for “Policy rules and authorization time” in “Per-operation authorization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C032-T08 · Delivery check:** Run the smallest real “Per-operation authorization” path and its adverse fixture “A read-only client requests device creation”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C032-T09 · Patch review:** Review the “Per-operation authorization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C032-T10 · Delivery handoff:** Publish the “Per-operation authorization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Authentication alone does not authorize every broker function. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Per-operation authorization”; copy its required invariant exactly: “Authentication alone does not authorize every broker function”.
- [ ] **UC-M03.07-C033-T02 · Observable terms:** Define each term in the “Per-operation authorization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C033-T03 · Precondition set:** List the preconditions under which “Authentication alone does not authorize every broker function” must hold for “Per-operation authorization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C033-T04 · Transition coverage:** Map the “Per-operation authorization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Per-operation authorization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C033-T06 · Satisfying fixture:** Create a concrete “Per-operation authorization” case that satisfies “Authentication alone does not authorize every broker function”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C033-T07 · Violating fixture:** Create the source counterexample “A read-only client requests device creation” for “Per-operation authorization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C033-T08 · Enforcement evidence:** Exercise the “Per-operation authorization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C033-T09 · Regression linkage:** Link the “Per-operation authorization” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Per-operation authorization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C034 · Integration

**Original checklist item:** Integrate per-operation authorization with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Per-operation authorization” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C034-T02 · Field mapping:** Map every “Per-operation authorization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Per-operation authorization” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C034-T04 · Ownership agreement:** Specify who owns “Per-operation authorization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C034-T05 · Handoff implementation:** Connect “Per-operation authorization” through the mapped seam using the real adapter or explicit specification reference; preserve “Authentication alone does not authorize every broker function” across the handoff.
- [ ] **UC-M03.07-C034-T06 · Absent-input case:** Omit one required “Per-operation authorization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C034-T07 · Stale-input case:** Supply an outdated “Per-operation authorization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Per-operation authorization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C034-T09 · Valid integration trace:** Run a valid “Per-operation authorization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C034-T10 · Seam review:** Reconcile the “Per-operation authorization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for per-operation authorization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Per-operation authorization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C035-T02 · Expected-result oracle:** Specify the “Per-operation authorization” expected result independently of the implementation output; include the property “Authentication alone does not authorize every broker function” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C035-T03 · Fixture material:** Create the concrete “Per-operation authorization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C035-T04 · Target preparation:** Prepare the “Per-operation authorization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C035-T05 · Initial-state record:** Record the initial “Per-operation authorization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C035-T06 · Valid-path execution:** Execute the “Per-operation authorization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C035-T07 · Outcome comparison:** Compare every declared “Per-operation authorization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C035-T08 · State and bounds check:** Inspect the “Per-operation authorization” ownership/state effects and actual use of “Policy rules and authorization time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C035-T09 · Repeatability check:** Repeat the same “Per-operation authorization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C035-T10 · Positive evidence:** Attach the “Per-operation authorization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C036 · Negative test

**Original checklist item:** Negative case: A read-only client requests device creation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Per-operation authorization” source counterexample: “A read-only client requests device creation”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Per-operation authorization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C036-T03 · Valid control:** Construct a valid “Per-operation authorization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C036-T04 · Minimal adverse input:** Derive the “Per-operation authorization” adverse fixture from the control with the smallest documented change needed to reproduce “A read-only client requests device creation”; retain that change as reproducible data.
- [ ] **UC-M03.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Per-operation authorization”; require “Authentication alone does not authorize every broker function” and forbid a false-success verdict.
- [ ] **UC-M03.07-C036-T06 · Adverse execution:** Exercise the “Per-operation authorization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C036-T07 · Effect inspection:** Inspect “Per-operation authorization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C036-T08 · Refusal versus failure:** Confirm the “Per-operation authorization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C036-T09 · Reset and retention:** Restore only the disposable “Per-operation authorization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C036-T10 · Negative regression:** Register the “Per-operation authorization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C037 · Change / failure test

**Original checklist item:** Exercise per-operation authorization when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C037-T01 · Scenario record:** Write the “Per-operation authorization” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “Authentication alone does not authorize every broker function”.
- [ ] **UC-M03.07-C037-T02 · Baseline capture:** Create a known-valid “Per-operation authorization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C037-T03 · Injection map:** Locate the “Per-operation authorization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Per-operation authorization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C037-T05 · Controlled trigger:** Introduce the controlled “Per-operation authorization” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C037-T06 · Intermediate inspection:** Inspect the “Per-operation authorization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Per-operation authorization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Per-operation authorization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C037-T09 · Repeat and compare:** Repeat the selected “Per-operation authorization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C037-T10 · Failure evidence:** Publish the “Per-operation authorization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for policy rules and authorization time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Per-operation authorization”: “Policy rules and authorization time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C038-T02 · Measurement method:** Choose how to observe each “Per-operation authorization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Per-operation authorization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Per-operation authorization” cases for “Policy rules and authorization time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Per-operation authorization” limit; preserve “Authentication alone does not authorize every broker function”.
- [ ] **UC-M03.07-C038-T06 · Normal measurement:** Run or review the normal “Per-operation authorization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C038-T07 · At-limit measurement:** Exercise the “Per-operation authorization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C038-T08 · Over-limit measurement:** Exercise the “Per-operation authorization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C038-T09 · Uncovered-scope report:** List the “Per-operation authorization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C038-T10 · Limit evidence:** Publish the selected “Per-operation authorization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for per-operation authorization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C039-T01 · Event inventory:** List the “Per-operation authorization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Per-operation authorization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C039-T03 · Failure mapping:** Map each documented “Per-operation authorization” refusal or error to a diagnostic outcome; include “A read-only client requests device creation” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C039-T04 · Emission path:** Add the “Per-operation authorization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C039-T05 · Redaction check:** Test “Per-operation authorization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C039-T06 · Output budget:** Set and exercise bounded “Per-operation authorization” message size, rate and retention compatible with “Policy rules and authorization time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C039-T07 · Success/refusal fixtures:** Capture “Per-operation authorization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Per-operation authorization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C039-T09 · Operator review:** Read the “Per-operation authorization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C039-T10 · Diagnostic evidence:** Publish redacted “Per-operation authorization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for per-operation authorization; label unexecuted checks as untested.

- [ ] **UC-M03.07-C040-T01 · Evidence inventory:** List the “Per-operation authorization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C040-T02 · Artifact references:** Record the exact “Per-operation authorization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C040-T03 · Fixture references:** Attach the “Per-operation authorization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A read-only client requests device creation” as a distinct evidence case.
- [ ] **UC-M03.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Per-operation authorization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C040-T05 · Environment record:** Record the actual “Per-operation authorization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C040-T06 · Expected versus observed:** Pair every “Per-operation authorization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C040-T07 · Failure and limit records:** Attach “Per-operation authorization” change/failure and bounds evidence where required; include uncovered “Policy rules and authorization time” and unresolved violations of “Authentication alone does not authorize every broker function”.
- [ ] **UC-M03.07-C040-T08 · Evidence hygiene:** Check the “Per-operation authorization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C040-T09 · Reproduction review:** Have the “Per-operation authorization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C040-T10 · Acceptance linkage:** Link the “Per-operation authorization” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Path and handle validation

**Source delivery:** Resolve broker resources through scoped identities or tightly validated paths.

**Source invariant:** Caller-selected paths cannot escape the authorized resource scope.

**Source negative case:** A request references an unrelated host file through an alias.

**Source bounded quantities:** Path length, handle count and resolution steps.

### UC-M03.07-C041 · Contract

**Original checklist item:** Specify path and handle validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C041-T01 · Scope statement:** Draft the operation boundary for “Path and handle validation” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Path and handle validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C041-T03 · Output inventory:** List the outputs of “Path and handle validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Path and handle validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C041-T05 · Prerequisite contract:** Map “Path and handle validation” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Path and handle validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C041-T07 · Invariant clause:** Add a normative clause for “Path and handle validation” that preserves “Caller-selected paths cannot escape the authorized resource scope”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Path and handle validation”; include the source counterexample “A request references an unrelated host file through an alias” and the intended safe disposition.
- [ ] **UC-M03.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Path length, handle count and resolution steps” in the “Path and handle validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C041-T10 · Contract review:** Review the “Path and handle validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C042 · Delivery

**Original checklist item:** Resolve broker resources through scoped identities or tightly validated paths.

- [ ] **UC-M03.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Path and handle validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C042-T02 · Change plan:** Break the source delivery for “Path and handle validation” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Path and handle validation” that realizes this source instruction: Resolve broker resources through scoped identities or tightly validated paths.
- [ ] **UC-M03.07-C042-T04 · Concrete realization:** Trace “Path and handle validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Path and handle validation” needed to preserve “Caller-selected paths cannot escape the authorized resource scope”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C042-T06 · Dependency connection:** Connect the “Path and handle validation” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C042-T07 · Resource behavior:** Account for “Path length, handle count and resolution steps” in “Path and handle validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C042-T08 · Delivery check:** Run the smallest real “Path and handle validation” path and its adverse fixture “A request references an unrelated host file through an alias”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C042-T09 · Patch review:** Review the “Path and handle validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C042-T10 · Delivery handoff:** Publish the “Path and handle validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Caller-selected paths cannot escape the authorized resource scope. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Path and handle validation”; copy its required invariant exactly: “Caller-selected paths cannot escape the authorized resource scope”.
- [ ] **UC-M03.07-C043-T02 · Observable terms:** Define each term in the “Path and handle validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C043-T03 · Precondition set:** List the preconditions under which “Caller-selected paths cannot escape the authorized resource scope” must hold for “Path and handle validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C043-T04 · Transition coverage:** Map the “Path and handle validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Path and handle validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C043-T06 · Satisfying fixture:** Create a concrete “Path and handle validation” case that satisfies “Caller-selected paths cannot escape the authorized resource scope”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C043-T07 · Violating fixture:** Create the source counterexample “A request references an unrelated host file through an alias” for “Path and handle validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C043-T08 · Enforcement evidence:** Exercise the “Path and handle validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C043-T09 · Regression linkage:** Link the “Path and handle validation” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Path and handle validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C044 · Integration

**Original checklist item:** Integrate path and handle validation with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Path and handle validation” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C044-T02 · Field mapping:** Map every “Path and handle validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Path and handle validation” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C044-T04 · Ownership agreement:** Specify who owns “Path and handle validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C044-T05 · Handoff implementation:** Connect “Path and handle validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Caller-selected paths cannot escape the authorized resource scope” across the handoff.
- [ ] **UC-M03.07-C044-T06 · Absent-input case:** Omit one required “Path and handle validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C044-T07 · Stale-input case:** Supply an outdated “Path and handle validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Path and handle validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C044-T09 · Valid integration trace:** Run a valid “Path and handle validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C044-T10 · Seam review:** Reconcile the “Path and handle validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for path and handle validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Path and handle validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C045-T02 · Expected-result oracle:** Specify the “Path and handle validation” expected result independently of the implementation output; include the property “Caller-selected paths cannot escape the authorized resource scope” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C045-T03 · Fixture material:** Create the concrete “Path and handle validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C045-T04 · Target preparation:** Prepare the “Path and handle validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C045-T05 · Initial-state record:** Record the initial “Path and handle validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C045-T06 · Valid-path execution:** Execute the “Path and handle validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C045-T07 · Outcome comparison:** Compare every declared “Path and handle validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C045-T08 · State and bounds check:** Inspect the “Path and handle validation” ownership/state effects and actual use of “Path length, handle count and resolution steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C045-T09 · Repeatability check:** Repeat the same “Path and handle validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C045-T10 · Positive evidence:** Attach the “Path and handle validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C046 · Negative test

**Original checklist item:** Negative case: A request references an unrelated host file through an alias. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Path and handle validation” source counterexample: “A request references an unrelated host file through an alias”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Path and handle validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C046-T03 · Valid control:** Construct a valid “Path and handle validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C046-T04 · Minimal adverse input:** Derive the “Path and handle validation” adverse fixture from the control with the smallest documented change needed to reproduce “A request references an unrelated host file through an alias”; retain that change as reproducible data.
- [ ] **UC-M03.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Path and handle validation”; require “Caller-selected paths cannot escape the authorized resource scope” and forbid a false-success verdict.
- [ ] **UC-M03.07-C046-T06 · Adverse execution:** Exercise the “Path and handle validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C046-T07 · Effect inspection:** Inspect “Path and handle validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C046-T08 · Refusal versus failure:** Confirm the “Path and handle validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C046-T09 · Reset and retention:** Restore only the disposable “Path and handle validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C046-T10 · Negative regression:** Register the “Path and handle validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C047 · Change / failure test

**Original checklist item:** Exercise path and handle validation when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C047-T01 · Scenario record:** Write the “Path and handle validation” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “Caller-selected paths cannot escape the authorized resource scope”.
- [ ] **UC-M03.07-C047-T02 · Baseline capture:** Create a known-valid “Path and handle validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C047-T03 · Injection map:** Locate the “Path and handle validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Path and handle validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C047-T05 · Controlled trigger:** Introduce the controlled “Path and handle validation” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C047-T06 · Intermediate inspection:** Inspect the “Path and handle validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Path and handle validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Path and handle validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C047-T09 · Repeat and compare:** Repeat the selected “Path and handle validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C047-T10 · Failure evidence:** Publish the “Path and handle validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for path length, handle count and resolution steps; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Path and handle validation”: “Path length, handle count and resolution steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C048-T02 · Measurement method:** Choose how to observe each “Path and handle validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Path and handle validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Path and handle validation” cases for “Path length, handle count and resolution steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Path and handle validation” limit; preserve “Caller-selected paths cannot escape the authorized resource scope”.
- [ ] **UC-M03.07-C048-T06 · Normal measurement:** Run or review the normal “Path and handle validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C048-T07 · At-limit measurement:** Exercise the “Path and handle validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C048-T08 · Over-limit measurement:** Exercise the “Path and handle validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C048-T09 · Uncovered-scope report:** List the “Path and handle validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C048-T10 · Limit evidence:** Publish the selected “Path and handle validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for path and handle validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C049-T01 · Event inventory:** List the “Path and handle validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Path and handle validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C049-T03 · Failure mapping:** Map each documented “Path and handle validation” refusal or error to a diagnostic outcome; include “A request references an unrelated host file through an alias” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C049-T04 · Emission path:** Add the “Path and handle validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C049-T05 · Redaction check:** Test “Path and handle validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C049-T06 · Output budget:** Set and exercise bounded “Path and handle validation” message size, rate and retention compatible with “Path length, handle count and resolution steps”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C049-T07 · Success/refusal fixtures:** Capture “Path and handle validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Path and handle validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C049-T09 · Operator review:** Read the “Path and handle validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C049-T10 · Diagnostic evidence:** Publish redacted “Path and handle validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for path and handle validation; label unexecuted checks as untested.

- [ ] **UC-M03.07-C050-T01 · Evidence inventory:** List the “Path and handle validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C050-T02 · Artifact references:** Record the exact “Path and handle validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C050-T03 · Fixture references:** Attach the “Path and handle validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A request references an unrelated host file through an alias” as a distinct evidence case.
- [ ] **UC-M03.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Path and handle validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C050-T05 · Environment record:** Record the actual “Path and handle validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C050-T06 · Expected versus observed:** Pair every “Path and handle validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C050-T07 · Failure and limit records:** Attach “Path and handle validation” change/failure and bounds evidence where required; include uncovered “Path length, handle count and resolution steps” and unresolved violations of “Caller-selected paths cannot escape the authorized resource scope”.
- [ ] **UC-M03.07-C050-T08 · Evidence hygiene:** Check the “Path and handle validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C050-T09 · Reproduction review:** Have the “Path and handle validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C050-T10 · Acceptance linkage:** Link the “Path and handle validation” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Least-privilege broker identity

**Source delivery:** Run the broker with only the privileges needed by its supported operations.

**Source invariant:** Compromising one broker operation does not imply unlimited host authority.

**Source negative case:** The broker retains privileges unrelated to its configured profile.

**Source bounded quantities:** Granted privileges and open device handles.

### UC-M03.07-C051 · Contract

**Original checklist item:** Specify least-privilege broker identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C051-T01 · Scope statement:** Draft the operation boundary for “Least-privilege broker identity” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Least-privilege broker identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C051-T03 · Output inventory:** List the outputs of “Least-privilege broker identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Least-privilege broker identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C051-T05 · Prerequisite contract:** Map “Least-privilege broker identity” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Least-privilege broker identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C051-T07 · Invariant clause:** Add a normative clause for “Least-privilege broker identity” that preserves “Compromising one broker operation does not imply unlimited host authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Least-privilege broker identity”; include the source counterexample “The broker retains privileges unrelated to its configured profile” and the intended safe disposition.
- [ ] **UC-M03.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Granted privileges and open device handles” in the “Least-privilege broker identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C051-T10 · Contract review:** Review the “Least-privilege broker identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C052 · Delivery

**Original checklist item:** Run the broker with only the privileges needed by its supported operations.

- [ ] **UC-M03.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Least-privilege broker identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C052-T02 · Change plan:** Break the source delivery for “Least-privilege broker identity” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C052-T03 · Core artifact:** Create the “Least-privilege broker identity” fixture or harness for this source instruction: Run the broker with only the privileges needed by its supported operations.
- [ ] **UC-M03.07-C052-T04 · Concrete realization:** Connect the “Least-privilege broker identity” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Least-privilege broker identity” needed to preserve “Compromising one broker operation does not imply unlimited host authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C052-T06 · Dependency connection:** Connect the “Least-privilege broker identity” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C052-T07 · Resource behavior:** Account for “Granted privileges and open device handles” in “Least-privilege broker identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C052-T08 · Delivery check:** Run the smallest real “Least-privilege broker identity” path and its adverse fixture “The broker retains privileges unrelated to its configured profile”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C052-T09 · Patch review:** Review the “Least-privilege broker identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C052-T10 · Delivery handoff:** Publish the “Least-privilege broker identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Compromising one broker operation does not imply unlimited host authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Least-privilege broker identity”; copy its required invariant exactly: “Compromising one broker operation does not imply unlimited host authority”.
- [ ] **UC-M03.07-C053-T02 · Observable terms:** Define each term in the “Least-privilege broker identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C053-T03 · Precondition set:** List the preconditions under which “Compromising one broker operation does not imply unlimited host authority” must hold for “Least-privilege broker identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C053-T04 · Transition coverage:** Map the “Least-privilege broker identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Least-privilege broker identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C053-T06 · Satisfying fixture:** Create a concrete “Least-privilege broker identity” case that satisfies “Compromising one broker operation does not imply unlimited host authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C053-T07 · Violating fixture:** Create the source counterexample “The broker retains privileges unrelated to its configured profile” for “Least-privilege broker identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C053-T08 · Enforcement evidence:** Exercise the “Least-privilege broker identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C053-T09 · Regression linkage:** Link the “Least-privilege broker identity” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Least-privilege broker identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C054 · Integration

**Original checklist item:** Integrate least-privilege broker identity with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Least-privilege broker identity” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C054-T02 · Field mapping:** Map every “Least-privilege broker identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Least-privilege broker identity” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C054-T04 · Ownership agreement:** Specify who owns “Least-privilege broker identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C054-T05 · Handoff implementation:** Connect “Least-privilege broker identity” through the mapped seam using the real adapter or explicit specification reference; preserve “Compromising one broker operation does not imply unlimited host authority” across the handoff.
- [ ] **UC-M03.07-C054-T06 · Absent-input case:** Omit one required “Least-privilege broker identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C054-T07 · Stale-input case:** Supply an outdated “Least-privilege broker identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Least-privilege broker identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C054-T09 · Valid integration trace:** Run a valid “Least-privilege broker identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C054-T10 · Seam review:** Reconcile the “Least-privilege broker identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for least-privilege broker identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Least-privilege broker identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C055-T02 · Expected-result oracle:** Specify the “Least-privilege broker identity” expected result independently of the implementation output; include the property “Compromising one broker operation does not imply unlimited host authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C055-T03 · Fixture material:** Create the concrete “Least-privilege broker identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C055-T04 · Target preparation:** Prepare the “Least-privilege broker identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C055-T05 · Initial-state record:** Record the initial “Least-privilege broker identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C055-T06 · Valid-path execution:** Execute the “Least-privilege broker identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C055-T07 · Outcome comparison:** Compare every declared “Least-privilege broker identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C055-T08 · State and bounds check:** Inspect the “Least-privilege broker identity” ownership/state effects and actual use of “Granted privileges and open device handles”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C055-T09 · Repeatability check:** Repeat the same “Least-privilege broker identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C055-T10 · Positive evidence:** Attach the “Least-privilege broker identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C056 · Negative test

**Original checklist item:** Negative case: The broker retains privileges unrelated to its configured profile. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Least-privilege broker identity” source counterexample: “The broker retains privileges unrelated to its configured profile”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Least-privilege broker identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C056-T03 · Valid control:** Construct a valid “Least-privilege broker identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C056-T04 · Minimal adverse input:** Derive the “Least-privilege broker identity” adverse fixture from the control with the smallest documented change needed to reproduce “The broker retains privileges unrelated to its configured profile”; retain that change as reproducible data.
- [ ] **UC-M03.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Least-privilege broker identity”; require “Compromising one broker operation does not imply unlimited host authority” and forbid a false-success verdict.
- [ ] **UC-M03.07-C056-T06 · Adverse execution:** Exercise the “Least-privilege broker identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C056-T07 · Effect inspection:** Inspect “Least-privilege broker identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C056-T08 · Refusal versus failure:** Confirm the “Least-privilege broker identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C056-T09 · Reset and retention:** Restore only the disposable “Least-privilege broker identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C056-T10 · Negative regression:** Register the “Least-privilege broker identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C057 · Change / failure test

**Original checklist item:** Exercise least-privilege broker identity when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C057-T01 · Scenario record:** Write the “Least-privilege broker identity” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “Compromising one broker operation does not imply unlimited host authority”.
- [ ] **UC-M03.07-C057-T02 · Baseline capture:** Create a known-valid “Least-privilege broker identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C057-T03 · Injection map:** Locate the “Least-privilege broker identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Least-privilege broker identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C057-T05 · Controlled trigger:** Introduce the controlled “Least-privilege broker identity” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C057-T06 · Intermediate inspection:** Inspect the “Least-privilege broker identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Least-privilege broker identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Least-privilege broker identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C057-T09 · Repeat and compare:** Repeat the selected “Least-privilege broker identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C057-T10 · Failure evidence:** Publish the “Least-privilege broker identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for granted privileges and open device handles; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Least-privilege broker identity”: “Granted privileges and open device handles”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C058-T02 · Measurement method:** Choose how to observe each “Least-privilege broker identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C058-T03 · Budget decision:** Select justified resource and input limits for “Least-privilege broker identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Least-privilege broker identity” cases for “Granted privileges and open device handles”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Least-privilege broker identity” limit; preserve “Compromising one broker operation does not imply unlimited host authority”.
- [ ] **UC-M03.07-C058-T06 · Normal measurement:** Run or review the normal “Least-privilege broker identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C058-T07 · At-limit measurement:** Exercise the “Least-privilege broker identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C058-T08 · Over-limit measurement:** Exercise the “Least-privilege broker identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C058-T09 · Uncovered-scope report:** List the “Least-privilege broker identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C058-T10 · Limit evidence:** Publish the selected “Least-privilege broker identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for least-privilege broker identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C059-T01 · Event inventory:** List the “Least-privilege broker identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Least-privilege broker identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C059-T03 · Failure mapping:** Map each documented “Least-privilege broker identity” refusal or error to a diagnostic outcome; include “The broker retains privileges unrelated to its configured profile” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C059-T04 · Emission path:** Add the “Least-privilege broker identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C059-T05 · Redaction check:** Test “Least-privilege broker identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C059-T06 · Output budget:** Set and exercise bounded “Least-privilege broker identity” message size, rate and retention compatible with “Granted privileges and open device handles”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C059-T07 · Success/refusal fixtures:** Capture “Least-privilege broker identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Least-privilege broker identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C059-T09 · Operator review:** Read the “Least-privilege broker identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C059-T10 · Diagnostic evidence:** Publish redacted “Least-privilege broker identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for least-privilege broker identity; label unexecuted checks as untested.

- [ ] **UC-M03.07-C060-T01 · Evidence inventory:** List the “Least-privilege broker identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C060-T02 · Artifact references:** Record the exact “Least-privilege broker identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C060-T03 · Fixture references:** Attach the “Least-privilege broker identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “The broker retains privileges unrelated to its configured profile” as a distinct evidence case.
- [ ] **UC-M03.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Least-privilege broker identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C060-T05 · Environment record:** Record the actual “Least-privilege broker identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C060-T06 · Expected versus observed:** Pair every “Least-privilege broker identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C060-T07 · Failure and limit records:** Attach “Least-privilege broker identity” change/failure and bounds evidence where required; include uncovered “Granted privileges and open device handles” and unresolved violations of “Compromising one broker operation does not imply unlimited host authority”.
- [ ] **UC-M03.07-C060-T08 · Evidence hygiene:** Check the “Least-privilege broker identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C060-T09 · Reproduction review:** Have the “Least-privilege broker identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C060-T10 · Acceptance linkage:** Link the “Least-privilege broker identity” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Request replay handling

**Source delivery:** Bind broker requests to identities, generations and replay rules.

**Source invariant:** A stale request cannot recreate resources after replacement.

**Source negative case:** A previously valid create request is replayed for an obsolete generation.

**Source bounded quantities:** Replay records and request lifetime.

### UC-M03.07-C061 · Contract

**Original checklist item:** Specify request replay handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C061-T01 · Scope statement:** Draft the operation boundary for “Request replay handling” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Request replay handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C061-T03 · Output inventory:** List the outputs of “Request replay handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Request replay handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C061-T05 · Prerequisite contract:** Map “Request replay handling” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Request replay handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C061-T07 · Invariant clause:** Add a normative clause for “Request replay handling” that preserves “A stale request cannot recreate resources after replacement”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Request replay handling”; include the source counterexample “A previously valid create request is replayed for an obsolete generation” and the intended safe disposition.
- [ ] **UC-M03.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Replay records and request lifetime” in the “Request replay handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C061-T10 · Contract review:** Review the “Request replay handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C062 · Delivery

**Original checklist item:** Bind broker requests to identities, generations and replay rules.

- [ ] **UC-M03.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Request replay handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C062-T02 · Change plan:** Break the source delivery for “Request replay handling” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Request replay handling” that realizes this source instruction: Bind broker requests to identities, generations and replay rules.
- [ ] **UC-M03.07-C062-T04 · Concrete realization:** Trace “Request replay handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Request replay handling” needed to preserve “A stale request cannot recreate resources after replacement”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C062-T06 · Dependency connection:** Connect the “Request replay handling” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C062-T07 · Resource behavior:** Account for “Replay records and request lifetime” in “Request replay handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C062-T08 · Delivery check:** Run the smallest real “Request replay handling” path and its adverse fixture “A previously valid create request is replayed for an obsolete generation”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C062-T09 · Patch review:** Review the “Request replay handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C062-T10 · Delivery handoff:** Publish the “Request replay handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stale request cannot recreate resources after replacement. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Request replay handling”; copy its required invariant exactly: “A stale request cannot recreate resources after replacement”.
- [ ] **UC-M03.07-C063-T02 · Observable terms:** Define each term in the “Request replay handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C063-T03 · Precondition set:** List the preconditions under which “A stale request cannot recreate resources after replacement” must hold for “Request replay handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C063-T04 · Transition coverage:** Map the “Request replay handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Request replay handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C063-T06 · Satisfying fixture:** Create a concrete “Request replay handling” case that satisfies “A stale request cannot recreate resources after replacement”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C063-T07 · Violating fixture:** Create the source counterexample “A previously valid create request is replayed for an obsolete generation” for “Request replay handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C063-T08 · Enforcement evidence:** Exercise the “Request replay handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C063-T09 · Regression linkage:** Link the “Request replay handling” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Request replay handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C064 · Integration

**Original checklist item:** Integrate request replay handling with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Request replay handling” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C064-T02 · Field mapping:** Map every “Request replay handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Request replay handling” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C064-T04 · Ownership agreement:** Specify who owns “Request replay handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C064-T05 · Handoff implementation:** Connect “Request replay handling” through the mapped seam using the real adapter or explicit specification reference; preserve “A stale request cannot recreate resources after replacement” across the handoff.
- [ ] **UC-M03.07-C064-T06 · Absent-input case:** Omit one required “Request replay handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C064-T07 · Stale-input case:** Supply an outdated “Request replay handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Request replay handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C064-T09 · Valid integration trace:** Run a valid “Request replay handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C064-T10 · Seam review:** Reconcile the “Request replay handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for request replay handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Request replay handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C065-T02 · Expected-result oracle:** Specify the “Request replay handling” expected result independently of the implementation output; include the property “A stale request cannot recreate resources after replacement” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C065-T03 · Fixture material:** Create the concrete “Request replay handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C065-T04 · Target preparation:** Prepare the “Request replay handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C065-T05 · Initial-state record:** Record the initial “Request replay handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C065-T06 · Valid-path execution:** Execute the “Request replay handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C065-T07 · Outcome comparison:** Compare every declared “Request replay handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C065-T08 · State and bounds check:** Inspect the “Request replay handling” ownership/state effects and actual use of “Replay records and request lifetime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C065-T09 · Repeatability check:** Repeat the same “Request replay handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C065-T10 · Positive evidence:** Attach the “Request replay handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C066 · Negative test

**Original checklist item:** Negative case: A previously valid create request is replayed for an obsolete generation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Request replay handling” source counterexample: “A previously valid create request is replayed for an obsolete generation”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Request replay handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C066-T03 · Valid control:** Construct a valid “Request replay handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C066-T04 · Minimal adverse input:** Derive the “Request replay handling” adverse fixture from the control with the smallest documented change needed to reproduce “A previously valid create request is replayed for an obsolete generation”; retain that change as reproducible data.
- [ ] **UC-M03.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Request replay handling”; require “A stale request cannot recreate resources after replacement” and forbid a false-success verdict.
- [ ] **UC-M03.07-C066-T06 · Adverse execution:** Exercise the “Request replay handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C066-T07 · Effect inspection:** Inspect “Request replay handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C066-T08 · Refusal versus failure:** Confirm the “Request replay handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C066-T09 · Reset and retention:** Restore only the disposable “Request replay handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C066-T10 · Negative regression:** Register the “Request replay handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C067 · Change / failure test

**Original checklist item:** Exercise request replay handling when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C067-T01 · Scenario record:** Write the “Request replay handling” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “A stale request cannot recreate resources after replacement”.
- [ ] **UC-M03.07-C067-T02 · Baseline capture:** Create a known-valid “Request replay handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C067-T03 · Injection map:** Locate the “Request replay handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Request replay handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C067-T05 · Controlled trigger:** Introduce the controlled “Request replay handling” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C067-T06 · Intermediate inspection:** Inspect the “Request replay handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Request replay handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Request replay handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C067-T09 · Repeat and compare:** Repeat the selected “Request replay handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C067-T10 · Failure evidence:** Publish the “Request replay handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for replay records and request lifetime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Request replay handling”: “Replay records and request lifetime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C068-T02 · Measurement method:** Choose how to observe each “Request replay handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Request replay handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Request replay handling” cases for “Replay records and request lifetime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Request replay handling” limit; preserve “A stale request cannot recreate resources after replacement”.
- [ ] **UC-M03.07-C068-T06 · Normal measurement:** Run or review the normal “Request replay handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C068-T07 · At-limit measurement:** Exercise the “Request replay handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C068-T08 · Over-limit measurement:** Exercise the “Request replay handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C068-T09 · Uncovered-scope report:** List the “Request replay handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C068-T10 · Limit evidence:** Publish the selected “Request replay handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for request replay handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C069-T01 · Event inventory:** List the “Request replay handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Request replay handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C069-T03 · Failure mapping:** Map each documented “Request replay handling” refusal or error to a diagnostic outcome; include “A previously valid create request is replayed for an obsolete generation” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C069-T04 · Emission path:** Add the “Request replay handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C069-T05 · Redaction check:** Test “Request replay handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C069-T06 · Output budget:** Set and exercise bounded “Request replay handling” message size, rate and retention compatible with “Replay records and request lifetime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C069-T07 · Success/refusal fixtures:** Capture “Request replay handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Request replay handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C069-T09 · Operator review:** Read the “Request replay handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C069-T10 · Diagnostic evidence:** Publish redacted “Request replay handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for request replay handling; label unexecuted checks as untested.

- [ ] **UC-M03.07-C070-T01 · Evidence inventory:** List the “Request replay handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C070-T02 · Artifact references:** Record the exact “Request replay handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C070-T03 · Fixture references:** Attach the “Request replay handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A previously valid create request is replayed for an obsolete generation” as a distinct evidence case.
- [ ] **UC-M03.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Request replay handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C070-T05 · Environment record:** Record the actual “Request replay handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C070-T06 · Expected versus observed:** Pair every “Request replay handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C070-T07 · Failure and limit records:** Attach “Request replay handling” change/failure and bounds evidence where required; include uncovered “Replay records and request lifetime” and unresolved violations of “A stale request cannot recreate resources after replacement”.
- [ ] **UC-M03.07-C070-T08 · Evidence hygiene:** Check the “Request replay handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C070-T09 · Reproduction review:** Have the “Request replay handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C070-T10 · Acceptance linkage:** Link the “Request replay handling” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Resource ownership ledger

**Source delivery:** Record broker-created resources and their owning workload generation.

**Source invariant:** A resource cannot be adopted by an unrelated workload.

**Source negative case:** A caller requests cleanup of another workload's device.

**Source bounded quantities:** Owned resources and ledger growth.

### UC-M03.07-C071 · Contract

**Original checklist item:** Specify resource ownership ledger inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C071-T01 · Scope statement:** Draft the operation boundary for “Resource ownership ledger” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource ownership ledger”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C071-T03 · Output inventory:** List the outputs of “Resource ownership ledger” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource ownership ledger”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C071-T05 · Prerequisite contract:** Map “Resource ownership ledger” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Resource ownership ledger”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C071-T07 · Invariant clause:** Add a normative clause for “Resource ownership ledger” that preserves “A resource cannot be adopted by an unrelated workload”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource ownership ledger”; include the source counterexample “A caller requests cleanup of another workload's device” and the intended safe disposition.
- [ ] **UC-M03.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Owned resources and ledger growth” in the “Resource ownership ledger” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C071-T10 · Contract review:** Review the “Resource ownership ledger” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C072 · Delivery

**Original checklist item:** Record broker-created resources and their owning workload generation.

- [ ] **UC-M03.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource ownership ledger”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C072-T02 · Change plan:** Break the source delivery for “Resource ownership ledger” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C072-T03 · Core artifact:** Create the “Resource ownership ledger” model, schema or inventory that realizes this source instruction: Record broker-created resources and their owning workload generation.
- [ ] **UC-M03.07-C072-T04 · Concrete realization:** Populate “Resource ownership ledger” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource ownership ledger” needed to preserve “A resource cannot be adopted by an unrelated workload”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C072-T06 · Dependency connection:** Connect the “Resource ownership ledger” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C072-T07 · Resource behavior:** Account for “Owned resources and ledger growth” in “Resource ownership ledger”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C072-T08 · Delivery check:** Run the smallest real “Resource ownership ledger” path and its adverse fixture “A caller requests cleanup of another workload's device”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C072-T09 · Patch review:** Review the “Resource ownership ledger” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C072-T10 · Delivery handoff:** Publish the “Resource ownership ledger” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A resource cannot be adopted by an unrelated workload. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Resource ownership ledger”; copy its required invariant exactly: “A resource cannot be adopted by an unrelated workload”.
- [ ] **UC-M03.07-C073-T02 · Observable terms:** Define each term in the “Resource ownership ledger” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C073-T03 · Precondition set:** List the preconditions under which “A resource cannot be adopted by an unrelated workload” must hold for “Resource ownership ledger”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C073-T04 · Transition coverage:** Map the “Resource ownership ledger” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource ownership ledger”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C073-T06 · Satisfying fixture:** Create a concrete “Resource ownership ledger” case that satisfies “A resource cannot be adopted by an unrelated workload”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C073-T07 · Violating fixture:** Create the source counterexample “A caller requests cleanup of another workload's device” for “Resource ownership ledger”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C073-T08 · Enforcement evidence:** Exercise the “Resource ownership ledger” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C073-T09 · Regression linkage:** Link the “Resource ownership ledger” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Resource ownership ledger” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C074 · Integration

**Original checklist item:** Integrate resource ownership ledger with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource ownership ledger” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C074-T02 · Field mapping:** Map every “Resource ownership ledger” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource ownership ledger” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C074-T04 · Ownership agreement:** Specify who owns “Resource ownership ledger” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C074-T05 · Handoff implementation:** Connect “Resource ownership ledger” through the mapped seam using the real adapter or explicit specification reference; preserve “A resource cannot be adopted by an unrelated workload” across the handoff.
- [ ] **UC-M03.07-C074-T06 · Absent-input case:** Omit one required “Resource ownership ledger” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C074-T07 · Stale-input case:** Supply an outdated “Resource ownership ledger” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Resource ownership ledger” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C074-T09 · Valid integration trace:** Run a valid “Resource ownership ledger” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C074-T10 · Seam review:** Reconcile the “Resource ownership ledger” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for resource ownership ledger; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Resource ownership ledger” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C075-T02 · Expected-result oracle:** Specify the “Resource ownership ledger” expected result independently of the implementation output; include the property “A resource cannot be adopted by an unrelated workload” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C075-T03 · Fixture material:** Create the concrete “Resource ownership ledger” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C075-T04 · Target preparation:** Prepare the “Resource ownership ledger” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C075-T05 · Initial-state record:** Record the initial “Resource ownership ledger” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C075-T06 · Valid-path execution:** Execute the “Resource ownership ledger” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C075-T07 · Outcome comparison:** Compare every declared “Resource ownership ledger” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C075-T08 · State and bounds check:** Inspect the “Resource ownership ledger” ownership/state effects and actual use of “Owned resources and ledger growth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C075-T09 · Repeatability check:** Repeat the same “Resource ownership ledger” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C075-T10 · Positive evidence:** Attach the “Resource ownership ledger” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C076 · Negative test

**Original checklist item:** Negative case: A caller requests cleanup of another workload's device. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Resource ownership ledger” source counterexample: “A caller requests cleanup of another workload's device”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource ownership ledger”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C076-T03 · Valid control:** Construct a valid “Resource ownership ledger” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C076-T04 · Minimal adverse input:** Derive the “Resource ownership ledger” adverse fixture from the control with the smallest documented change needed to reproduce “A caller requests cleanup of another workload's device”; retain that change as reproducible data.
- [ ] **UC-M03.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource ownership ledger”; require “A resource cannot be adopted by an unrelated workload” and forbid a false-success verdict.
- [ ] **UC-M03.07-C076-T06 · Adverse execution:** Exercise the “Resource ownership ledger” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C076-T07 · Effect inspection:** Inspect “Resource ownership ledger” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C076-T08 · Refusal versus failure:** Confirm the “Resource ownership ledger” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C076-T09 · Reset and retention:** Restore only the disposable “Resource ownership ledger” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C076-T10 · Negative regression:** Register the “Resource ownership ledger” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C077 · Change / failure test

**Original checklist item:** Exercise resource ownership ledger when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C077-T01 · Scenario record:** Write the “Resource ownership ledger” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “A resource cannot be adopted by an unrelated workload”.
- [ ] **UC-M03.07-C077-T02 · Baseline capture:** Create a known-valid “Resource ownership ledger” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C077-T03 · Injection map:** Locate the “Resource ownership ledger” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Resource ownership ledger” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C077-T05 · Controlled trigger:** Introduce the controlled “Resource ownership ledger” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C077-T06 · Intermediate inspection:** Inspect the “Resource ownership ledger” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource ownership ledger”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource ownership ledger” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C077-T09 · Repeat and compare:** Repeat the selected “Resource ownership ledger” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C077-T10 · Failure evidence:** Publish the “Resource ownership ledger” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for owned resources and ledger growth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Resource ownership ledger”: “Owned resources and ledger growth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C078-T02 · Measurement method:** Choose how to observe each “Resource ownership ledger” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Resource ownership ledger”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource ownership ledger” cases for “Owned resources and ledger growth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource ownership ledger” limit; preserve “A resource cannot be adopted by an unrelated workload”.
- [ ] **UC-M03.07-C078-T06 · Normal measurement:** Run or review the normal “Resource ownership ledger” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C078-T07 · At-limit measurement:** Exercise the “Resource ownership ledger” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C078-T08 · Over-limit measurement:** Exercise the “Resource ownership ledger” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C078-T09 · Uncovered-scope report:** List the “Resource ownership ledger” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C078-T10 · Limit evidence:** Publish the selected “Resource ownership ledger” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for resource ownership ledger with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C079-T01 · Event inventory:** List the “Resource ownership ledger” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Resource ownership ledger” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C079-T03 · Failure mapping:** Map each documented “Resource ownership ledger” refusal or error to a diagnostic outcome; include “A caller requests cleanup of another workload's device” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C079-T04 · Emission path:** Add the “Resource ownership ledger” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C079-T05 · Redaction check:** Test “Resource ownership ledger” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C079-T06 · Output budget:** Set and exercise bounded “Resource ownership ledger” message size, rate and retention compatible with “Owned resources and ledger growth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C079-T07 · Success/refusal fixtures:** Capture “Resource ownership ledger” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Resource ownership ledger” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C079-T09 · Operator review:** Read the “Resource ownership ledger” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C079-T10 · Diagnostic evidence:** Publish redacted “Resource ownership ledger” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource ownership ledger; label unexecuted checks as untested.

- [ ] **UC-M03.07-C080-T01 · Evidence inventory:** List the “Resource ownership ledger” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C080-T02 · Artifact references:** Record the exact “Resource ownership ledger” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C080-T03 · Fixture references:** Attach the “Resource ownership ledger” fixture IDs, input identities and oracle definition; preserve the source counterexample “A caller requests cleanup of another workload's device” as a distinct evidence case.
- [ ] **UC-M03.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource ownership ledger”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C080-T05 · Environment record:** Record the actual “Resource ownership ledger” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C080-T06 · Expected versus observed:** Pair every “Resource ownership ledger” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C080-T07 · Failure and limit records:** Attach “Resource ownership ledger” change/failure and bounds evidence where required; include uncovered “Owned resources and ledger growth” and unresolved violations of “A resource cannot be adopted by an unrelated workload”.
- [ ] **UC-M03.07-C080-T08 · Evidence hygiene:** Check the “Resource ownership ledger” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C080-T09 · Reproduction review:** Have the “Resource ownership ledger” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C080-T10 · Acceptance linkage:** Link the “Resource ownership ledger” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Broker failure recovery

**Source delivery:** Define behavior for broker restart and interrupted resource operations.

**Source invariant:** Partial broker operations leave a recoverable ownership disposition.

**Source negative case:** The broker exits after device creation but before acknowledgment.

**Source bounded quantities:** Recovery scan size and operation timeout.

### UC-M03.07-C081 · Contract

**Original checklist item:** Specify broker failure recovery inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C081-T01 · Scope statement:** Draft the operation boundary for “Broker failure recovery” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Broker failure recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C081-T03 · Output inventory:** List the outputs of “Broker failure recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Broker failure recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C081-T05 · Prerequisite contract:** Map “Broker failure recovery” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Broker failure recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C081-T07 · Invariant clause:** Add a normative clause for “Broker failure recovery” that preserves “Partial broker operations leave a recoverable ownership disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Broker failure recovery”; include the source counterexample “The broker exits after device creation but before acknowledgment” and the intended safe disposition.
- [ ] **UC-M03.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recovery scan size and operation timeout” in the “Broker failure recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C081-T10 · Contract review:** Review the “Broker failure recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C082 · Delivery

**Original checklist item:** Define behavior for broker restart and interrupted resource operations.

- [ ] **UC-M03.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Broker failure recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C082-T02 · Change plan:** Break the source delivery for “Broker failure recovery” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C082-T03 · Core artifact:** Create the “Broker failure recovery” model, schema or inventory that realizes this source instruction: Define behavior for broker restart and interrupted resource operations.
- [ ] **UC-M03.07-C082-T04 · Concrete realization:** Populate “Broker failure recovery” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Broker failure recovery” needed to preserve “Partial broker operations leave a recoverable ownership disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C082-T06 · Dependency connection:** Connect the “Broker failure recovery” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C082-T07 · Resource behavior:** Account for “Recovery scan size and operation timeout” in “Broker failure recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C082-T08 · Delivery check:** Run the smallest real “Broker failure recovery” path and its adverse fixture “The broker exits after device creation but before acknowledgment”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C082-T09 · Patch review:** Review the “Broker failure recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C082-T10 · Delivery handoff:** Publish the “Broker failure recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Partial broker operations leave a recoverable ownership disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Broker failure recovery”; copy its required invariant exactly: “Partial broker operations leave a recoverable ownership disposition”.
- [ ] **UC-M03.07-C083-T02 · Observable terms:** Define each term in the “Broker failure recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C083-T03 · Precondition set:** List the preconditions under which “Partial broker operations leave a recoverable ownership disposition” must hold for “Broker failure recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C083-T04 · Transition coverage:** Map the “Broker failure recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Broker failure recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C083-T06 · Satisfying fixture:** Create a concrete “Broker failure recovery” case that satisfies “Partial broker operations leave a recoverable ownership disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C083-T07 · Violating fixture:** Create the source counterexample “The broker exits after device creation but before acknowledgment” for “Broker failure recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C083-T08 · Enforcement evidence:** Exercise the “Broker failure recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C083-T09 · Regression linkage:** Link the “Broker failure recovery” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Broker failure recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C084 · Integration

**Original checklist item:** Integrate broker failure recovery with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Broker failure recovery” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C084-T02 · Field mapping:** Map every “Broker failure recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Broker failure recovery” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C084-T04 · Ownership agreement:** Specify who owns “Broker failure recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C084-T05 · Handoff implementation:** Connect “Broker failure recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Partial broker operations leave a recoverable ownership disposition” across the handoff.
- [ ] **UC-M03.07-C084-T06 · Absent-input case:** Omit one required “Broker failure recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C084-T07 · Stale-input case:** Supply an outdated “Broker failure recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Broker failure recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C084-T09 · Valid integration trace:** Run a valid “Broker failure recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C084-T10 · Seam review:** Reconcile the “Broker failure recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for broker failure recovery; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Broker failure recovery” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C085-T02 · Expected-result oracle:** Specify the “Broker failure recovery” expected result independently of the implementation output; include the property “Partial broker operations leave a recoverable ownership disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C085-T03 · Fixture material:** Create the concrete “Broker failure recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C085-T04 · Target preparation:** Prepare the “Broker failure recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C085-T05 · Initial-state record:** Record the initial “Broker failure recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C085-T06 · Valid-path execution:** Execute the “Broker failure recovery” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C085-T07 · Outcome comparison:** Compare every declared “Broker failure recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C085-T08 · State and bounds check:** Inspect the “Broker failure recovery” ownership/state effects and actual use of “Recovery scan size and operation timeout”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C085-T09 · Repeatability check:** Repeat the same “Broker failure recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C085-T10 · Positive evidence:** Attach the “Broker failure recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C086 · Negative test

**Original checklist item:** Negative case: The broker exits after device creation but before acknowledgment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Broker failure recovery” source counterexample: “The broker exits after device creation but before acknowledgment”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Broker failure recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C086-T03 · Valid control:** Construct a valid “Broker failure recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C086-T04 · Minimal adverse input:** Derive the “Broker failure recovery” adverse fixture from the control with the smallest documented change needed to reproduce “The broker exits after device creation but before acknowledgment”; retain that change as reproducible data.
- [ ] **UC-M03.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Broker failure recovery”; require “Partial broker operations leave a recoverable ownership disposition” and forbid a false-success verdict.
- [ ] **UC-M03.07-C086-T06 · Adverse execution:** Exercise the “Broker failure recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C086-T07 · Effect inspection:** Inspect “Broker failure recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C086-T08 · Refusal versus failure:** Confirm the “Broker failure recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C086-T09 · Reset and retention:** Restore only the disposable “Broker failure recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C086-T10 · Negative regression:** Register the “Broker failure recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C087 · Change / failure test

**Original checklist item:** Exercise broker failure recovery when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C087-T01 · Scenario record:** Write the “Broker failure recovery” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “Partial broker operations leave a recoverable ownership disposition”.
- [ ] **UC-M03.07-C087-T02 · Baseline capture:** Create a known-valid “Broker failure recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C087-T03 · Injection map:** Locate the “Broker failure recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Broker failure recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C087-T05 · Controlled trigger:** Introduce the controlled “Broker failure recovery” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C087-T06 · Intermediate inspection:** Inspect the “Broker failure recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Broker failure recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Broker failure recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C087-T09 · Repeat and compare:** Repeat the selected “Broker failure recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C087-T10 · Failure evidence:** Publish the “Broker failure recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for recovery scan size and operation timeout; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Broker failure recovery”: “Recovery scan size and operation timeout”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C088-T02 · Measurement method:** Choose how to observe each “Broker failure recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C088-T03 · Budget decision:** Select justified resource and input limits for “Broker failure recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Broker failure recovery” cases for “Recovery scan size and operation timeout”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Broker failure recovery” limit; preserve “Partial broker operations leave a recoverable ownership disposition”.
- [ ] **UC-M03.07-C088-T06 · Normal measurement:** Run or review the normal “Broker failure recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C088-T07 · At-limit measurement:** Exercise the “Broker failure recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C088-T08 · Over-limit measurement:** Exercise the “Broker failure recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C088-T09 · Uncovered-scope report:** List the “Broker failure recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C088-T10 · Limit evidence:** Publish the selected “Broker failure recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for broker failure recovery with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C089-T01 · Event inventory:** List the “Broker failure recovery” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Broker failure recovery” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C089-T03 · Failure mapping:** Map each documented “Broker failure recovery” refusal or error to a diagnostic outcome; include “The broker exits after device creation but before acknowledgment” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C089-T04 · Emission path:** Add the “Broker failure recovery” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C089-T05 · Redaction check:** Test “Broker failure recovery” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C089-T06 · Output budget:** Set and exercise bounded “Broker failure recovery” message size, rate and retention compatible with “Recovery scan size and operation timeout”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C089-T07 · Success/refusal fixtures:** Capture “Broker failure recovery” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Broker failure recovery” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C089-T09 · Operator review:** Read the “Broker failure recovery” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C089-T10 · Diagnostic evidence:** Publish redacted “Broker failure recovery” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for broker failure recovery; label unexecuted checks as untested.

- [ ] **UC-M03.07-C090-T01 · Evidence inventory:** List the “Broker failure recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C090-T02 · Artifact references:** Record the exact “Broker failure recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C090-T03 · Fixture references:** Attach the “Broker failure recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “The broker exits after device creation but before acknowledgment” as a distinct evidence case.
- [ ] **UC-M03.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Broker failure recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C090-T05 · Environment record:** Record the actual “Broker failure recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C090-T06 · Expected versus observed:** Pair every “Broker failure recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C090-T07 · Failure and limit records:** Attach “Broker failure recovery” change/failure and bounds evidence where required; include uncovered “Recovery scan size and operation timeout” and unresolved violations of “Partial broker operations leave a recoverable ownership disposition”.
- [ ] **UC-M03.07-C090-T08 · Evidence hygiene:** Check the “Broker failure recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C090-T09 · Reproduction review:** Have the “Broker failure recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C090-T10 · Acceptance linkage:** Link the “Broker failure recovery” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Unprivileged ship qualification

**Source delivery:** Run management operations without elevating the entire ship process.

**Source invariant:** Only authenticated narrow broker calls perform privileged work.

**Source negative case:** The ship succeeds only when launched with unrestricted privileges.

**Source bounded quantities:** Qualification cases and broker call budget.

### UC-M03.07-C091 · Contract

**Original checklist item:** Specify unprivileged ship qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.07-C091-T01 · Scope statement:** Draft the operation boundary for “Unprivileged ship qualification” within Privilege-separated resource broker; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Unprivileged ship qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.07-C091-T03 · Output inventory:** List the outputs of “Unprivileged ship qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Unprivileged ship qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.07-C091-T05 · Prerequisite contract:** Map “Unprivileged ship qualification” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Unprivileged ship qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.07-C091-T07 · Invariant clause:** Add a normative clause for “Unprivileged ship qualification” that preserves “Only authenticated narrow broker calls perform privileged work”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Unprivileged ship qualification”; include the source counterexample “The ship succeeds only when launched with unrestricted privileges” and the intended safe disposition.
- [ ] **UC-M03.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Qualification cases and broker call budget” in the “Unprivileged ship qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.07-C091-T10 · Contract review:** Review the “Unprivileged ship qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.07-C092 · Delivery

**Original checklist item:** Run management operations without elevating the entire ship process.

- [ ] **UC-M03.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Unprivileged ship qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.07-C092-T02 · Change plan:** Break the source delivery for “Unprivileged ship qualification” into concrete edit targets and reviewable outputs; keep the UC-M03.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.07-C092-T03 · Core artifact:** Create the “Unprivileged ship qualification” fixture or harness for this source instruction: Run management operations without elevating the entire ship process.
- [ ] **UC-M03.07-C092-T04 · Concrete realization:** Connect the “Unprivileged ship qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Unprivileged ship qualification” needed to preserve “Only authenticated narrow broker calls perform privileged work”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.07-C092-T06 · Dependency connection:** Connect the “Unprivileged ship qualification” implementation to authenticated local requests, narrow privileged operations and resource ownership records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.07-C092-T07 · Resource behavior:** Account for “Qualification cases and broker call budget” in “Unprivileged ship qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.07-C092-T08 · Delivery check:** Run the smallest real “Unprivileged ship qualification” path and its adverse fixture “The ship succeeds only when launched with unrestricted privileges”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.07-C092-T09 · Patch review:** Review the “Unprivileged ship qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.07-C092-T10 · Delivery handoff:** Publish the “Unprivileged ship qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Only authenticated narrow broker calls perform privileged work. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Unprivileged ship qualification”; copy its required invariant exactly: “Only authenticated narrow broker calls perform privileged work”.
- [ ] **UC-M03.07-C093-T02 · Observable terms:** Define each term in the “Unprivileged ship qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.07-C093-T03 · Precondition set:** List the preconditions under which “Only authenticated narrow broker calls perform privileged work” must hold for “Unprivileged ship qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.07-C093-T04 · Transition coverage:** Map the “Unprivileged ship qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Unprivileged ship qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.07-C093-T06 · Satisfying fixture:** Create a concrete “Unprivileged ship qualification” case that satisfies “Only authenticated narrow broker calls perform privileged work”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.07-C093-T07 · Violating fixture:** Create the source counterexample “The ship succeeds only when launched with unrestricted privileges” for “Unprivileged ship qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.07-C093-T08 · Enforcement evidence:** Exercise the “Unprivileged ship qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.07-C093-T09 · Regression linkage:** Link the “Unprivileged ship qualification” property to changes in authenticated local requests, narrow privileged operations and resource ownership records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Unprivileged ship qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.07-C094 · Integration

**Original checklist item:** Integrate unprivileged ship qualification with authenticated local requests, narrow privileged operations and resource ownership records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Unprivileged ship qualification” across authenticated local requests, narrow privileged operations and resource ownership records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.07-C094-T02 · Field mapping:** Map every “Unprivileged ship qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Unprivileged ship qualification” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.07-C094-T04 · Ownership agreement:** Specify who owns “Unprivileged ship qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.07-C094-T05 · Handoff implementation:** Connect “Unprivileged ship qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Only authenticated narrow broker calls perform privileged work” across the handoff.
- [ ] **UC-M03.07-C094-T06 · Absent-input case:** Omit one required “Unprivileged ship qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.07-C094-T07 · Stale-input case:** Supply an outdated “Unprivileged ship qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Unprivileged ship qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.07-C094-T09 · Valid integration trace:** Run a valid “Unprivileged ship qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.07-C094-T10 · Seam review:** Reconcile the “Unprivileged ship qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for unprivileged ship qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Unprivileged ship qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.07-C095-T02 · Expected-result oracle:** Specify the “Unprivileged ship qualification” expected result independently of the implementation output; include the property “Only authenticated narrow broker calls perform privileged work” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.07-C095-T03 · Fixture material:** Create the concrete “Unprivileged ship qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.07-C095-T04 · Target preparation:** Prepare the “Unprivileged ship qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.07-C095-T05 · Initial-state record:** Record the initial “Unprivileged ship qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.07-C095-T06 · Valid-path execution:** Execute the “Unprivileged ship qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.07-C095-T07 · Outcome comparison:** Compare every declared “Unprivileged ship qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.07-C095-T08 · State and bounds check:** Inspect the “Unprivileged ship qualification” ownership/state effects and actual use of “Qualification cases and broker call budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.07-C095-T09 · Repeatability check:** Repeat the same “Unprivileged ship qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.07-C095-T10 · Positive evidence:** Attach the “Unprivileged ship qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.07-C096 · Negative test

**Original checklist item:** Negative case: The ship succeeds only when launched with unrestricted privileges. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Unprivileged ship qualification” source counterexample: “The ship succeeds only when launched with unrestricted privileges”; state which precondition or invariant it challenges.
- [ ] **UC-M03.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Unprivileged ship qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.07-C096-T03 · Valid control:** Construct a valid “Unprivileged ship qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.07-C096-T04 · Minimal adverse input:** Derive the “Unprivileged ship qualification” adverse fixture from the control with the smallest documented change needed to reproduce “The ship succeeds only when launched with unrestricted privileges”; retain that change as reproducible data.
- [ ] **UC-M03.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Unprivileged ship qualification”; require “Only authenticated narrow broker calls perform privileged work” and forbid a false-success verdict.
- [ ] **UC-M03.07-C096-T06 · Adverse execution:** Exercise the “Unprivileged ship qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.07-C096-T07 · Effect inspection:** Inspect “Unprivileged ship qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.07-C096-T08 · Refusal versus failure:** Confirm the “Unprivileged ship qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.07-C096-T09 · Reset and retention:** Restore only the disposable “Unprivileged ship qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.07-C096-T10 · Negative regression:** Register the “Unprivileged ship qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.07-C097 · Change / failure test

**Original checklist item:** Exercise unprivileged ship qualification when the broker restarts after allocating a resource but before returning its handle; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.07-C097-T01 · Scenario record:** Write the “Unprivileged ship qualification” change/failure scenario exactly as supplied: the broker restarts after allocating a resource but before returning its handle; identify the property that must remain true: “Only authenticated narrow broker calls perform privileged work”.
- [ ] **UC-M03.07-C097-T02 · Baseline capture:** Create a known-valid “Unprivileged ship qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.07-C097-T03 · Injection map:** Locate the “Unprivileged ship qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Unprivileged ship qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.07-C097-T05 · Controlled trigger:** Introduce the controlled “Unprivileged ship qualification” scenario in the disposable fixture: the broker restarts after allocating a resource but before returning its handle; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.07-C097-T06 · Intermediate inspection:** Inspect the “Unprivileged ship qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Unprivileged ship qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Unprivileged ship qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.07-C097-T09 · Repeat and compare:** Repeat the selected “Unprivileged ship qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.07-C097-T10 · Failure evidence:** Publish the “Unprivileged ship qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for qualification cases and broker call budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Unprivileged ship qualification”: “Qualification cases and broker call budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.07-C098-T02 · Measurement method:** Choose how to observe each “Unprivileged ship qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Unprivileged ship qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Unprivileged ship qualification” cases for “Qualification cases and broker call budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Unprivileged ship qualification” limit; preserve “Only authenticated narrow broker calls perform privileged work”.
- [ ] **UC-M03.07-C098-T06 · Normal measurement:** Run or review the normal “Unprivileged ship qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.07-C098-T07 · At-limit measurement:** Exercise the “Unprivileged ship qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.07-C098-T08 · Over-limit measurement:** Exercise the “Unprivileged ship qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.07-C098-T09 · Uncovered-scope report:** List the “Unprivileged ship qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.07-C098-T10 · Limit evidence:** Publish the selected “Unprivileged ship qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for unprivileged ship qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.07-C099-T01 · Event inventory:** List the “Unprivileged ship qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Unprivileged ship qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.07-C099-T03 · Failure mapping:** Map each documented “Unprivileged ship qualification” refusal or error to a diagnostic outcome; include “The ship succeeds only when launched with unrestricted privileges” and prohibit conversion into a success message.
- [ ] **UC-M03.07-C099-T04 · Emission path:** Add the “Unprivileged ship qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.07-C099-T05 · Redaction check:** Test “Unprivileged ship qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.07-C099-T06 · Output budget:** Set and exercise bounded “Unprivileged ship qualification” message size, rate and retention compatible with “Qualification cases and broker call budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.07-C099-T07 · Success/refusal fixtures:** Capture “Unprivileged ship qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Unprivileged ship qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.07-C099-T09 · Operator review:** Read the “Unprivileged ship qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.07-C099-T10 · Diagnostic evidence:** Publish redacted “Unprivileged ship qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for unprivileged ship qualification; label unexecuted checks as untested.

- [ ] **UC-M03.07-C100-T01 · Evidence inventory:** List the “Unprivileged ship qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.07-C100-T02 · Artifact references:** Record the exact “Unprivileged ship qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.07-C100-T03 · Fixture references:** Attach the “Unprivileged ship qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “The ship succeeds only when launched with unrestricted privileges” as a distinct evidence case.
- [ ] **UC-M03.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Unprivileged ship qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.07-C100-T05 · Environment record:** Record the actual “Unprivileged ship qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.07-C100-T06 · Expected versus observed:** Pair every “Unprivileged ship qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.07-C100-T07 · Failure and limit records:** Attach “Unprivileged ship qualification” change/failure and bounds evidence where required; include uncovered “Qualification cases and broker call budget” and unresolved violations of “Only authenticated narrow broker calls perform privileged work”.
- [ ] **UC-M03.07-C100-T08 · Evidence hygiene:** Check the “Unprivileged ship qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.07-C100-T09 · Reproduction review:** Have the “Unprivileged ship qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.07-C100-T10 · Acceptance linkage:** Link the “Unprivileged ship qualification” evidence to its parent and UC-M03.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

