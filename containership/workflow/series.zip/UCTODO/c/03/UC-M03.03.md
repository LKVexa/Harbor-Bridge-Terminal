# UC-M03.03 — Host process sandbox profile

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/03.md)

| Field | Preserved source value |
|---|---|
| Workstream | 03. Host isolation and supervision |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.02](../03/UC-M03.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S3], [S4]. |

## Original requirement

Constrain the VMM/tender with the selected OS mechanisms: user identity, syscall policy, filesystem access and process isolation.

**Original acceptance criterion:** An adversarial guest cannot access unrelated host files or make forbidden host operations through exposed devices.

**Source trace:** Original checklist `UC100/c/03/UC-M03.03.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 261–271 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Restricted execution identity

**Source delivery:** Run the VMM or tender under the selected restricted host identity.

**Source invariant:** The execution process has only the privileges required by its profile.

**Source negative case:** The backend inherits the operator's unrestricted identity.

**Source bounded quantities:** Identity count and privilege inventory size.

### UC-M03.03-C001 · Contract

**Original checklist item:** Specify restricted execution identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C001-T01 · Scope statement:** Draft the operation boundary for “Restricted execution identity” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restricted execution identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C001-T03 · Output inventory:** List the outputs of “Restricted execution identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Restricted execution identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C001-T05 · Prerequisite contract:** Map “Restricted execution identity” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C001-T06 · Authority map:** Identify who may produce, change and consume “Restricted execution identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C001-T07 · Invariant clause:** Add a normative clause for “Restricted execution identity” that preserves “The execution process has only the privileges required by its profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restricted execution identity”; include the source counterexample “The backend inherits the operator's unrestricted identity” and the intended safe disposition.
- [ ] **UC-M03.03-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Identity count and privilege inventory size” in the “Restricted execution identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C001-T10 · Contract review:** Review the “Restricted execution identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C002 · Delivery

**Original checklist item:** Run the VMM or tender under the selected restricted host identity.

- [ ] **UC-M03.03-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restricted execution identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C002-T02 · Change plan:** Break the source delivery for “Restricted execution identity” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C002-T03 · Core artifact:** Create the “Restricted execution identity” fixture or harness for this source instruction: Run the VMM or tender under the selected restricted host identity.
- [ ] **UC-M03.03-C002-T04 · Concrete realization:** Connect the “Restricted execution identity” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.03-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restricted execution identity” needed to preserve “The execution process has only the privileges required by its profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C002-T06 · Dependency connection:** Connect the “Restricted execution identity” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C002-T07 · Resource behavior:** Account for “Identity count and privilege inventory size” in “Restricted execution identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C002-T08 · Delivery check:** Run the smallest real “Restricted execution identity” path and its adverse fixture “The backend inherits the operator's unrestricted identity”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C002-T09 · Patch review:** Review the “Restricted execution identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C002-T10 · Delivery handoff:** Publish the “Restricted execution identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The execution process has only the privileges required by its profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C003-T01 · Named property:** Create a stable property/check name under this parent for “Restricted execution identity”; copy its required invariant exactly: “The execution process has only the privileges required by its profile”.
- [ ] **UC-M03.03-C003-T02 · Observable terms:** Define each term in the “Restricted execution identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C003-T03 · Precondition set:** List the preconditions under which “The execution process has only the privileges required by its profile” must hold for “Restricted execution identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C003-T04 · Transition coverage:** Map the “Restricted execution identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restricted execution identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C003-T06 · Satisfying fixture:** Create a concrete “Restricted execution identity” case that satisfies “The execution process has only the privileges required by its profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C003-T07 · Violating fixture:** Create the source counterexample “The backend inherits the operator's unrestricted identity” for “Restricted execution identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C003-T08 · Enforcement evidence:** Exercise the “Restricted execution identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C003-T09 · Regression linkage:** Link the “Restricted execution identity” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C003-T10 · Property disposition:** Compare the satisfying and violating “Restricted execution identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C004 · Integration

**Original checklist item:** Integrate restricted execution identity with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restricted execution identity” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C004-T02 · Field mapping:** Map every “Restricted execution identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Restricted execution identity” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C004-T04 · Ownership agreement:** Specify who owns “Restricted execution identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C004-T05 · Handoff implementation:** Connect “Restricted execution identity” through the mapped seam using the real adapter or explicit specification reference; preserve “The execution process has only the privileges required by its profile” across the handoff.
- [ ] **UC-M03.03-C004-T06 · Absent-input case:** Omit one required “Restricted execution identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C004-T07 · Stale-input case:** Supply an outdated “Restricted execution identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C004-T08 · Incompatible-input case:** Supply an incompatible “Restricted execution identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C004-T09 · Valid integration trace:** Run a valid “Restricted execution identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C004-T10 · Seam review:** Reconcile the “Restricted execution identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restricted execution identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restricted execution identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C005-T02 · Expected-result oracle:** Specify the “Restricted execution identity” expected result independently of the implementation output; include the property “The execution process has only the privileges required by its profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C005-T03 · Fixture material:** Create the concrete “Restricted execution identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C005-T04 · Target preparation:** Prepare the “Restricted execution identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C005-T05 · Initial-state record:** Record the initial “Restricted execution identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C005-T06 · Valid-path execution:** Execute the “Restricted execution identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C005-T07 · Outcome comparison:** Compare every declared “Restricted execution identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C005-T08 · State and bounds check:** Inspect the “Restricted execution identity” ownership/state effects and actual use of “Identity count and privilege inventory size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C005-T09 · Repeatability check:** Repeat the same “Restricted execution identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C005-T10 · Positive evidence:** Attach the “Restricted execution identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C006 · Negative test

**Original checklist item:** Negative case: The backend inherits the operator's unrestricted identity. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C006-T01 · Adverse-case definition:** Create a test record for the exact “Restricted execution identity” source counterexample: “The backend inherits the operator's unrestricted identity”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Restricted execution identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C006-T03 · Valid control:** Construct a valid “Restricted execution identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C006-T04 · Minimal adverse input:** Derive the “Restricted execution identity” adverse fixture from the control with the smallest documented change needed to reproduce “The backend inherits the operator's unrestricted identity”; retain that change as reproducible data.
- [ ] **UC-M03.03-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restricted execution identity”; require “The execution process has only the privileges required by its profile” and forbid a false-success verdict.
- [ ] **UC-M03.03-C006-T06 · Adverse execution:** Exercise the “Restricted execution identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C006-T07 · Effect inspection:** Inspect “Restricted execution identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C006-T08 · Refusal versus failure:** Confirm the “Restricted execution identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C006-T09 · Reset and retention:** Restore only the disposable “Restricted execution identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C006-T10 · Negative regression:** Register the “Restricted execution identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C007 · Change / failure test

**Original checklist item:** Exercise restricted execution identity when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C007-T01 · Scenario record:** Write the “Restricted execution identity” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “The execution process has only the privileges required by its profile”.
- [ ] **UC-M03.03-C007-T02 · Baseline capture:** Create a known-valid “Restricted execution identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C007-T03 · Injection map:** Locate the “Restricted execution identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Restricted execution identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C007-T05 · Controlled trigger:** Introduce the controlled “Restricted execution identity” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C007-T06 · Intermediate inspection:** Inspect the “Restricted execution identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restricted execution identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Restricted execution identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C007-T09 · Repeat and compare:** Repeat the selected “Restricted execution identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C007-T10 · Failure evidence:** Publish the “Restricted execution identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C008 · Bounds

**Original checklist item:** Choose, document and test limits for identity count and privilege inventory size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C008-T01 · Quantity inventory:** Create a measurement inventory for “Restricted execution identity”: “Identity count and privilege inventory size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C008-T02 · Measurement method:** Choose how to observe each “Restricted execution identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C008-T03 · Budget decision:** Select justified resource and input limits for “Restricted execution identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restricted execution identity” cases for “Identity count and privilege inventory size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restricted execution identity” limit; preserve “The execution process has only the privileges required by its profile”.
- [ ] **UC-M03.03-C008-T06 · Normal measurement:** Run or review the normal “Restricted execution identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C008-T07 · At-limit measurement:** Exercise the “Restricted execution identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C008-T08 · Over-limit measurement:** Exercise the “Restricted execution identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C008-T09 · Uncovered-scope report:** List the “Restricted execution identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C008-T10 · Limit evidence:** Publish the selected “Restricted execution identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restricted execution identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C009-T01 · Event inventory:** List the “Restricted execution identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Restricted execution identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C009-T03 · Failure mapping:** Map each documented “Restricted execution identity” refusal or error to a diagnostic outcome; include “The backend inherits the operator's unrestricted identity” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C009-T04 · Emission path:** Add the “Restricted execution identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C009-T05 · Redaction check:** Test “Restricted execution identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C009-T06 · Output budget:** Set and exercise bounded “Restricted execution identity” message size, rate and retention compatible with “Identity count and privilege inventory size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C009-T07 · Success/refusal fixtures:** Capture “Restricted execution identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restricted execution identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C009-T09 · Operator review:** Read the “Restricted execution identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C009-T10 · Diagnostic evidence:** Publish redacted “Restricted execution identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restricted execution identity; label unexecuted checks as untested.

- [ ] **UC-M03.03-C010-T01 · Evidence inventory:** List the “Restricted execution identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C010-T02 · Artifact references:** Record the exact “Restricted execution identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C010-T03 · Fixture references:** Attach the “Restricted execution identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “The backend inherits the operator's unrestricted identity” as a distinct evidence case.
- [ ] **UC-M03.03-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restricted execution identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C010-T05 · Environment record:** Record the actual “Restricted execution identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C010-T06 · Expected versus observed:** Pair every “Restricted execution identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C010-T07 · Failure and limit records:** Attach “Restricted execution identity” change/failure and bounds evidence where required; include uncovered “Identity count and privilege inventory size” and unresolved violations of “The execution process has only the privileges required by its profile”.
- [ ] **UC-M03.03-C010-T08 · Evidence hygiene:** Check the “Restricted execution identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C010-T09 · Reproduction review:** Have the “Restricted execution identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C010-T10 · Acceptance linkage:** Link the “Restricted execution identity” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Filesystem view

**Source delivery:** Limit visible and writable host paths for the selected backend.

**Source invariant:** A guest-facing process cannot access unrelated workspace or user files.

**Source negative case:** A device request references a host file outside the allowlist.

**Source bounded quantities:** Visible paths, writable bytes and mount count.

### UC-M03.03-C011 · Contract

**Original checklist item:** Specify filesystem view inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C011-T01 · Scope statement:** Draft the operation boundary for “Filesystem view” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Filesystem view”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C011-T03 · Output inventory:** List the outputs of “Filesystem view” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Filesystem view”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C011-T05 · Prerequisite contract:** Map “Filesystem view” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C011-T06 · Authority map:** Identify who may produce, change and consume “Filesystem view”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C011-T07 · Invariant clause:** Add a normative clause for “Filesystem view” that preserves “A guest-facing process cannot access unrelated workspace or user files”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Filesystem view”; include the source counterexample “A device request references a host file outside the allowlist” and the intended safe disposition.
- [ ] **UC-M03.03-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Visible paths, writable bytes and mount count” in the “Filesystem view” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C011-T10 · Contract review:** Review the “Filesystem view” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C012 · Delivery

**Original checklist item:** Limit visible and writable host paths for the selected backend.

- [ ] **UC-M03.03-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Filesystem view”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C012-T02 · Change plan:** Break the source delivery for “Filesystem view” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Filesystem view” that realizes this source instruction: Limit visible and writable host paths for the selected backend.
- [ ] **UC-M03.03-C012-T04 · Concrete realization:** Trace “Filesystem view” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.03-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Filesystem view” needed to preserve “A guest-facing process cannot access unrelated workspace or user files”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C012-T06 · Dependency connection:** Connect the “Filesystem view” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C012-T07 · Resource behavior:** Account for “Visible paths, writable bytes and mount count” in “Filesystem view”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C012-T08 · Delivery check:** Run the smallest real “Filesystem view” path and its adverse fixture “A device request references a host file outside the allowlist”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C012-T09 · Patch review:** Review the “Filesystem view” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C012-T10 · Delivery handoff:** Publish the “Filesystem view” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A guest-facing process cannot access unrelated workspace or user files. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C013-T01 · Named property:** Create a stable property/check name under this parent for “Filesystem view”; copy its required invariant exactly: “A guest-facing process cannot access unrelated workspace or user files”.
- [ ] **UC-M03.03-C013-T02 · Observable terms:** Define each term in the “Filesystem view” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C013-T03 · Precondition set:** List the preconditions under which “A guest-facing process cannot access unrelated workspace or user files” must hold for “Filesystem view”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C013-T04 · Transition coverage:** Map the “Filesystem view” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Filesystem view”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C013-T06 · Satisfying fixture:** Create a concrete “Filesystem view” case that satisfies “A guest-facing process cannot access unrelated workspace or user files”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C013-T07 · Violating fixture:** Create the source counterexample “A device request references a host file outside the allowlist” for “Filesystem view”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C013-T08 · Enforcement evidence:** Exercise the “Filesystem view” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C013-T09 · Regression linkage:** Link the “Filesystem view” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C013-T10 · Property disposition:** Compare the satisfying and violating “Filesystem view” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C014 · Integration

**Original checklist item:** Integrate filesystem view with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Filesystem view” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C014-T02 · Field mapping:** Map every “Filesystem view” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Filesystem view” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C014-T04 · Ownership agreement:** Specify who owns “Filesystem view” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C014-T05 · Handoff implementation:** Connect “Filesystem view” through the mapped seam using the real adapter or explicit specification reference; preserve “A guest-facing process cannot access unrelated workspace or user files” across the handoff.
- [ ] **UC-M03.03-C014-T06 · Absent-input case:** Omit one required “Filesystem view” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C014-T07 · Stale-input case:** Supply an outdated “Filesystem view” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C014-T08 · Incompatible-input case:** Supply an incompatible “Filesystem view” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C014-T09 · Valid integration trace:** Run a valid “Filesystem view” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C014-T10 · Seam review:** Reconcile the “Filesystem view” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for filesystem view; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Filesystem view” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C015-T02 · Expected-result oracle:** Specify the “Filesystem view” expected result independently of the implementation output; include the property “A guest-facing process cannot access unrelated workspace or user files” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C015-T03 · Fixture material:** Create the concrete “Filesystem view” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C015-T04 · Target preparation:** Prepare the “Filesystem view” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C015-T05 · Initial-state record:** Record the initial “Filesystem view” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C015-T06 · Valid-path execution:** Execute the “Filesystem view” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C015-T07 · Outcome comparison:** Compare every declared “Filesystem view” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C015-T08 · State and bounds check:** Inspect the “Filesystem view” ownership/state effects and actual use of “Visible paths, writable bytes and mount count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C015-T09 · Repeatability check:** Repeat the same “Filesystem view” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C015-T10 · Positive evidence:** Attach the “Filesystem view” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C016 · Negative test

**Original checklist item:** Negative case: A device request references a host file outside the allowlist. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C016-T01 · Adverse-case definition:** Create a test record for the exact “Filesystem view” source counterexample: “A device request references a host file outside the allowlist”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Filesystem view”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C016-T03 · Valid control:** Construct a valid “Filesystem view” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C016-T04 · Minimal adverse input:** Derive the “Filesystem view” adverse fixture from the control with the smallest documented change needed to reproduce “A device request references a host file outside the allowlist”; retain that change as reproducible data.
- [ ] **UC-M03.03-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Filesystem view”; require “A guest-facing process cannot access unrelated workspace or user files” and forbid a false-success verdict.
- [ ] **UC-M03.03-C016-T06 · Adverse execution:** Exercise the “Filesystem view” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C016-T07 · Effect inspection:** Inspect “Filesystem view” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C016-T08 · Refusal versus failure:** Confirm the “Filesystem view” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C016-T09 · Reset and retention:** Restore only the disposable “Filesystem view” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C016-T10 · Negative regression:** Register the “Filesystem view” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C017 · Change / failure test

**Original checklist item:** Exercise filesystem view when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C017-T01 · Scenario record:** Write the “Filesystem view” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “A guest-facing process cannot access unrelated workspace or user files”.
- [ ] **UC-M03.03-C017-T02 · Baseline capture:** Create a known-valid “Filesystem view” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C017-T03 · Injection map:** Locate the “Filesystem view” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Filesystem view” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C017-T05 · Controlled trigger:** Introduce the controlled “Filesystem view” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C017-T06 · Intermediate inspection:** Inspect the “Filesystem view” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Filesystem view”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Filesystem view” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C017-T09 · Repeat and compare:** Repeat the selected “Filesystem view” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C017-T10 · Failure evidence:** Publish the “Filesystem view” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C018 · Bounds

**Original checklist item:** Choose, document and test limits for visible paths, writable bytes and mount count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C018-T01 · Quantity inventory:** Create a measurement inventory for “Filesystem view”: “Visible paths, writable bytes and mount count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C018-T02 · Measurement method:** Choose how to observe each “Filesystem view” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C018-T03 · Budget decision:** Select justified resource and input limits for “Filesystem view”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Filesystem view” cases for “Visible paths, writable bytes and mount count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Filesystem view” limit; preserve “A guest-facing process cannot access unrelated workspace or user files”.
- [ ] **UC-M03.03-C018-T06 · Normal measurement:** Run or review the normal “Filesystem view” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C018-T07 · At-limit measurement:** Exercise the “Filesystem view” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C018-T08 · Over-limit measurement:** Exercise the “Filesystem view” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C018-T09 · Uncovered-scope report:** List the “Filesystem view” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C018-T10 · Limit evidence:** Publish the selected “Filesystem view” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for filesystem view with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C019-T01 · Event inventory:** List the “Filesystem view” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Filesystem view” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C019-T03 · Failure mapping:** Map each documented “Filesystem view” refusal or error to a diagnostic outcome; include “A device request references a host file outside the allowlist” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C019-T04 · Emission path:** Add the “Filesystem view” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C019-T05 · Redaction check:** Test “Filesystem view” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C019-T06 · Output budget:** Set and exercise bounded “Filesystem view” message size, rate and retention compatible with “Visible paths, writable bytes and mount count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C019-T07 · Success/refusal fixtures:** Capture “Filesystem view” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Filesystem view” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C019-T09 · Operator review:** Read the “Filesystem view” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C019-T10 · Diagnostic evidence:** Publish redacted “Filesystem view” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for filesystem view; label unexecuted checks as untested.

- [ ] **UC-M03.03-C020-T01 · Evidence inventory:** List the “Filesystem view” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C020-T02 · Artifact references:** Record the exact “Filesystem view” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C020-T03 · Fixture references:** Attach the “Filesystem view” fixture IDs, input identities and oracle definition; preserve the source counterexample “A device request references a host file outside the allowlist” as a distinct evidence case.
- [ ] **UC-M03.03-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Filesystem view”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C020-T05 · Environment record:** Record the actual “Filesystem view” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C020-T06 · Expected versus observed:** Pair every “Filesystem view” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C020-T07 · Failure and limit records:** Attach “Filesystem view” change/failure and bounds evidence where required; include uncovered “Visible paths, writable bytes and mount count” and unresolved violations of “A guest-facing process cannot access unrelated workspace or user files”.
- [ ] **UC-M03.03-C020-T08 · Evidence hygiene:** Check the “Filesystem view” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C020-T09 · Reproduction review:** Have the “Filesystem view” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C020-T10 · Acceptance linkage:** Link the “Filesystem view” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. System-call policy

**Source delivery:** Define and exercise the selected host's syscall restriction mechanism.

**Source invariant:** Forbidden host operations remain blocked during guest execution.

**Source negative case:** A test attempts an operation outside the backend's permitted syscall set.

**Source bounded quantities:** Policy rule count and violation log rate.

### UC-M03.03-C021 · Contract

**Original checklist item:** Specify system-call policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C021-T01 · Scope statement:** Draft the operation boundary for “System-call policy” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “System-call policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C021-T03 · Output inventory:** List the outputs of “System-call policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “System-call policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C021-T05 · Prerequisite contract:** Map “System-call policy” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C021-T06 · Authority map:** Identify who may produce, change and consume “System-call policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C021-T07 · Invariant clause:** Add a normative clause for “System-call policy” that preserves “Forbidden host operations remain blocked during guest execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “System-call policy”; include the source counterexample “A test attempts an operation outside the backend's permitted syscall set” and the intended safe disposition.
- [ ] **UC-M03.03-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Policy rule count and violation log rate” in the “System-call policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C021-T10 · Contract review:** Review the “System-call policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C022 · Delivery

**Original checklist item:** Define and exercise the selected host's syscall restriction mechanism.

- [ ] **UC-M03.03-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “System-call policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C022-T02 · Change plan:** Break the source delivery for “System-call policy” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C022-T03 · Core artifact:** Create the “System-call policy” model, schema or inventory that realizes this source instruction: Define and exercise the selected host's syscall restriction mechanism.
- [ ] **UC-M03.03-C022-T04 · Concrete realization:** Populate “System-call policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.03-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “System-call policy” needed to preserve “Forbidden host operations remain blocked during guest execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C022-T06 · Dependency connection:** Connect the “System-call policy” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C022-T07 · Resource behavior:** Account for “Policy rule count and violation log rate” in “System-call policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C022-T08 · Delivery check:** Run the smallest real “System-call policy” path and its adverse fixture “A test attempts an operation outside the backend's permitted syscall set”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C022-T09 · Patch review:** Review the “System-call policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C022-T10 · Delivery handoff:** Publish the “System-call policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Forbidden host operations remain blocked during guest execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C023-T01 · Named property:** Create a stable property/check name under this parent for “System-call policy”; copy its required invariant exactly: “Forbidden host operations remain blocked during guest execution”.
- [ ] **UC-M03.03-C023-T02 · Observable terms:** Define each term in the “System-call policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C023-T03 · Precondition set:** List the preconditions under which “Forbidden host operations remain blocked during guest execution” must hold for “System-call policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C023-T04 · Transition coverage:** Map the “System-call policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “System-call policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C023-T06 · Satisfying fixture:** Create a concrete “System-call policy” case that satisfies “Forbidden host operations remain blocked during guest execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C023-T07 · Violating fixture:** Create the source counterexample “A test attempts an operation outside the backend's permitted syscall set” for “System-call policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C023-T08 · Enforcement evidence:** Exercise the “System-call policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C023-T09 · Regression linkage:** Link the “System-call policy” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C023-T10 · Property disposition:** Compare the satisfying and violating “System-call policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C024 · Integration

**Original checklist item:** Integrate system-call policy with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “System-call policy” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C024-T02 · Field mapping:** Map every “System-call policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “System-call policy” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C024-T04 · Ownership agreement:** Specify who owns “System-call policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C024-T05 · Handoff implementation:** Connect “System-call policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Forbidden host operations remain blocked during guest execution” across the handoff.
- [ ] **UC-M03.03-C024-T06 · Absent-input case:** Omit one required “System-call policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C024-T07 · Stale-input case:** Supply an outdated “System-call policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C024-T08 · Incompatible-input case:** Supply an incompatible “System-call policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C024-T09 · Valid integration trace:** Run a valid “System-call policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C024-T10 · Seam review:** Reconcile the “System-call policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for system-call policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “System-call policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C025-T02 · Expected-result oracle:** Specify the “System-call policy” expected result independently of the implementation output; include the property “Forbidden host operations remain blocked during guest execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C025-T03 · Fixture material:** Create the concrete “System-call policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C025-T04 · Target preparation:** Prepare the “System-call policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C025-T05 · Initial-state record:** Record the initial “System-call policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C025-T06 · Valid-path execution:** Execute the “System-call policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C025-T07 · Outcome comparison:** Compare every declared “System-call policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C025-T08 · State and bounds check:** Inspect the “System-call policy” ownership/state effects and actual use of “Policy rule count and violation log rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C025-T09 · Repeatability check:** Repeat the same “System-call policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C025-T10 · Positive evidence:** Attach the “System-call policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C026 · Negative test

**Original checklist item:** Negative case: A test attempts an operation outside the backend's permitted syscall set. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C026-T01 · Adverse-case definition:** Create a test record for the exact “System-call policy” source counterexample: “A test attempts an operation outside the backend's permitted syscall set”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “System-call policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C026-T03 · Valid control:** Construct a valid “System-call policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C026-T04 · Minimal adverse input:** Derive the “System-call policy” adverse fixture from the control with the smallest documented change needed to reproduce “A test attempts an operation outside the backend's permitted syscall set”; retain that change as reproducible data.
- [ ] **UC-M03.03-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “System-call policy”; require “Forbidden host operations remain blocked during guest execution” and forbid a false-success verdict.
- [ ] **UC-M03.03-C026-T06 · Adverse execution:** Exercise the “System-call policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C026-T07 · Effect inspection:** Inspect “System-call policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C026-T08 · Refusal versus failure:** Confirm the “System-call policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C026-T09 · Reset and retention:** Restore only the disposable “System-call policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C026-T10 · Negative regression:** Register the “System-call policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C027 · Change / failure test

**Original checklist item:** Exercise system-call policy when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C027-T01 · Scenario record:** Write the “System-call policy” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “Forbidden host operations remain blocked during guest execution”.
- [ ] **UC-M03.03-C027-T02 · Baseline capture:** Create a known-valid “System-call policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C027-T03 · Injection map:** Locate the “System-call policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C027-T04 · Disposition oracle:** Define the legal intermediate and final “System-call policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C027-T05 · Controlled trigger:** Introduce the controlled “System-call policy” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C027-T06 · Intermediate inspection:** Inspect the “System-call policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “System-call policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “System-call policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C027-T09 · Repeat and compare:** Repeat the selected “System-call policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C027-T10 · Failure evidence:** Publish the “System-call policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C028 · Bounds

**Original checklist item:** Choose, document and test limits for policy rule count and violation log rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C028-T01 · Quantity inventory:** Create a measurement inventory for “System-call policy”: “Policy rule count and violation log rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C028-T02 · Measurement method:** Choose how to observe each “System-call policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C028-T03 · Budget decision:** Select justified resource and input limits for “System-call policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “System-call policy” cases for “Policy rule count and violation log rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “System-call policy” limit; preserve “Forbidden host operations remain blocked during guest execution”.
- [ ] **UC-M03.03-C028-T06 · Normal measurement:** Run or review the normal “System-call policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C028-T07 · At-limit measurement:** Exercise the “System-call policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C028-T08 · Over-limit measurement:** Exercise the “System-call policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C028-T09 · Uncovered-scope report:** List the “System-call policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C028-T10 · Limit evidence:** Publish the selected “System-call policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for system-call policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C029-T01 · Event inventory:** List the “System-call policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C029-T02 · Diagnostic schema:** Define nonsecret fields for “System-call policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C029-T03 · Failure mapping:** Map each documented “System-call policy” refusal or error to a diagnostic outcome; include “A test attempts an operation outside the backend's permitted syscall set” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C029-T04 · Emission path:** Add the “System-call policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C029-T05 · Redaction check:** Test “System-call policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C029-T06 · Output budget:** Set and exercise bounded “System-call policy” message size, rate and retention compatible with “Policy rule count and violation log rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C029-T07 · Success/refusal fixtures:** Capture “System-call policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “System-call policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C029-T09 · Operator review:** Read the “System-call policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C029-T10 · Diagnostic evidence:** Publish redacted “System-call policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for system-call policy; label unexecuted checks as untested.

- [ ] **UC-M03.03-C030-T01 · Evidence inventory:** List the “System-call policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C030-T02 · Artifact references:** Record the exact “System-call policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C030-T03 · Fixture references:** Attach the “System-call policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test attempts an operation outside the backend's permitted syscall set” as a distinct evidence case.
- [ ] **UC-M03.03-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “System-call policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C030-T05 · Environment record:** Record the actual “System-call policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C030-T06 · Expected versus observed:** Pair every “System-call policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C030-T07 · Failure and limit records:** Attach “System-call policy” change/failure and bounds evidence where required; include uncovered “Policy rule count and violation log rate” and unresolved violations of “Forbidden host operations remain blocked during guest execution”.
- [ ] **UC-M03.03-C030-T08 · Evidence hygiene:** Check the “System-call policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C030-T09 · Reproduction review:** Have the “System-call policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C030-T10 · Acceptance linkage:** Link the “System-call policy” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Process isolation

**Source delivery:** Apply the selected OS mechanisms for process visibility and descendant confinement.

**Source invariant:** The backend cannot control unrelated host processes.

**Source negative case:** A backend child attempts to inspect or signal another workload.

**Source bounded quantities:** Child count and process-observation scope.

### UC-M03.03-C031 · Contract

**Original checklist item:** Specify process isolation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C031-T01 · Scope statement:** Draft the operation boundary for “Process isolation” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Process isolation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C031-T03 · Output inventory:** List the outputs of “Process isolation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Process isolation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C031-T05 · Prerequisite contract:** Map “Process isolation” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C031-T06 · Authority map:** Identify who may produce, change and consume “Process isolation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C031-T07 · Invariant clause:** Add a normative clause for “Process isolation” that preserves “The backend cannot control unrelated host processes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Process isolation”; include the source counterexample “A backend child attempts to inspect or signal another workload” and the intended safe disposition.
- [ ] **UC-M03.03-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Child count and process-observation scope” in the “Process isolation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C031-T10 · Contract review:** Review the “Process isolation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C032 · Delivery

**Original checklist item:** Apply the selected OS mechanisms for process visibility and descendant confinement.

- [ ] **UC-M03.03-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Process isolation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C032-T02 · Change plan:** Break the source delivery for “Process isolation” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Process isolation” that realizes this source instruction: Apply the selected OS mechanisms for process visibility and descendant confinement.
- [ ] **UC-M03.03-C032-T04 · Concrete realization:** Trace “Process isolation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.03-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Process isolation” needed to preserve “The backend cannot control unrelated host processes”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C032-T06 · Dependency connection:** Connect the “Process isolation” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C032-T07 · Resource behavior:** Account for “Child count and process-observation scope” in “Process isolation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C032-T08 · Delivery check:** Run the smallest real “Process isolation” path and its adverse fixture “A backend child attempts to inspect or signal another workload”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C032-T09 · Patch review:** Review the “Process isolation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C032-T10 · Delivery handoff:** Publish the “Process isolation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The backend cannot control unrelated host processes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C033-T01 · Named property:** Create a stable property/check name under this parent for “Process isolation”; copy its required invariant exactly: “The backend cannot control unrelated host processes”.
- [ ] **UC-M03.03-C033-T02 · Observable terms:** Define each term in the “Process isolation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C033-T03 · Precondition set:** List the preconditions under which “The backend cannot control unrelated host processes” must hold for “Process isolation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C033-T04 · Transition coverage:** Map the “Process isolation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Process isolation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C033-T06 · Satisfying fixture:** Create a concrete “Process isolation” case that satisfies “The backend cannot control unrelated host processes”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C033-T07 · Violating fixture:** Create the source counterexample “A backend child attempts to inspect or signal another workload” for “Process isolation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C033-T08 · Enforcement evidence:** Exercise the “Process isolation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C033-T09 · Regression linkage:** Link the “Process isolation” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C033-T10 · Property disposition:** Compare the satisfying and violating “Process isolation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C034 · Integration

**Original checklist item:** Integrate process isolation with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Process isolation” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C034-T02 · Field mapping:** Map every “Process isolation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Process isolation” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C034-T04 · Ownership agreement:** Specify who owns “Process isolation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C034-T05 · Handoff implementation:** Connect “Process isolation” through the mapped seam using the real adapter or explicit specification reference; preserve “The backend cannot control unrelated host processes” across the handoff.
- [ ] **UC-M03.03-C034-T06 · Absent-input case:** Omit one required “Process isolation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C034-T07 · Stale-input case:** Supply an outdated “Process isolation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C034-T08 · Incompatible-input case:** Supply an incompatible “Process isolation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C034-T09 · Valid integration trace:** Run a valid “Process isolation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C034-T10 · Seam review:** Reconcile the “Process isolation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for process isolation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Process isolation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C035-T02 · Expected-result oracle:** Specify the “Process isolation” expected result independently of the implementation output; include the property “The backend cannot control unrelated host processes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C035-T03 · Fixture material:** Create the concrete “Process isolation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C035-T04 · Target preparation:** Prepare the “Process isolation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C035-T05 · Initial-state record:** Record the initial “Process isolation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C035-T06 · Valid-path execution:** Execute the “Process isolation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C035-T07 · Outcome comparison:** Compare every declared “Process isolation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C035-T08 · State and bounds check:** Inspect the “Process isolation” ownership/state effects and actual use of “Child count and process-observation scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C035-T09 · Repeatability check:** Repeat the same “Process isolation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C035-T10 · Positive evidence:** Attach the “Process isolation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C036 · Negative test

**Original checklist item:** Negative case: A backend child attempts to inspect or signal another workload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C036-T01 · Adverse-case definition:** Create a test record for the exact “Process isolation” source counterexample: “A backend child attempts to inspect or signal another workload”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Process isolation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C036-T03 · Valid control:** Construct a valid “Process isolation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C036-T04 · Minimal adverse input:** Derive the “Process isolation” adverse fixture from the control with the smallest documented change needed to reproduce “A backend child attempts to inspect or signal another workload”; retain that change as reproducible data.
- [ ] **UC-M03.03-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Process isolation”; require “The backend cannot control unrelated host processes” and forbid a false-success verdict.
- [ ] **UC-M03.03-C036-T06 · Adverse execution:** Exercise the “Process isolation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C036-T07 · Effect inspection:** Inspect “Process isolation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C036-T08 · Refusal versus failure:** Confirm the “Process isolation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C036-T09 · Reset and retention:** Restore only the disposable “Process isolation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C036-T10 · Negative regression:** Register the “Process isolation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C037 · Change / failure test

**Original checklist item:** Exercise process isolation when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C037-T01 · Scenario record:** Write the “Process isolation” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “The backend cannot control unrelated host processes”.
- [ ] **UC-M03.03-C037-T02 · Baseline capture:** Create a known-valid “Process isolation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C037-T03 · Injection map:** Locate the “Process isolation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Process isolation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C037-T05 · Controlled trigger:** Introduce the controlled “Process isolation” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C037-T06 · Intermediate inspection:** Inspect the “Process isolation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Process isolation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Process isolation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C037-T09 · Repeat and compare:** Repeat the selected “Process isolation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C037-T10 · Failure evidence:** Publish the “Process isolation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C038 · Bounds

**Original checklist item:** Choose, document and test limits for child count and process-observation scope; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C038-T01 · Quantity inventory:** Create a measurement inventory for “Process isolation”: “Child count and process-observation scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C038-T02 · Measurement method:** Choose how to observe each “Process isolation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C038-T03 · Budget decision:** Select justified resource and input limits for “Process isolation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Process isolation” cases for “Child count and process-observation scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Process isolation” limit; preserve “The backend cannot control unrelated host processes”.
- [ ] **UC-M03.03-C038-T06 · Normal measurement:** Run or review the normal “Process isolation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C038-T07 · At-limit measurement:** Exercise the “Process isolation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C038-T08 · Over-limit measurement:** Exercise the “Process isolation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C038-T09 · Uncovered-scope report:** List the “Process isolation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C038-T10 · Limit evidence:** Publish the selected “Process isolation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for process isolation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C039-T01 · Event inventory:** List the “Process isolation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Process isolation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C039-T03 · Failure mapping:** Map each documented “Process isolation” refusal or error to a diagnostic outcome; include “A backend child attempts to inspect or signal another workload” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C039-T04 · Emission path:** Add the “Process isolation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C039-T05 · Redaction check:** Test “Process isolation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C039-T06 · Output budget:** Set and exercise bounded “Process isolation” message size, rate and retention compatible with “Child count and process-observation scope”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C039-T07 · Success/refusal fixtures:** Capture “Process isolation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Process isolation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C039-T09 · Operator review:** Read the “Process isolation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C039-T10 · Diagnostic evidence:** Publish redacted “Process isolation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for process isolation; label unexecuted checks as untested.

- [ ] **UC-M03.03-C040-T01 · Evidence inventory:** List the “Process isolation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C040-T02 · Artifact references:** Record the exact “Process isolation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C040-T03 · Fixture references:** Attach the “Process isolation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A backend child attempts to inspect or signal another workload” as a distinct evidence case.
- [ ] **UC-M03.03-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Process isolation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C040-T05 · Environment record:** Record the actual “Process isolation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C040-T06 · Expected versus observed:** Pair every “Process isolation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C040-T07 · Failure and limit records:** Attach “Process isolation” change/failure and bounds evidence where required; include uncovered “Child count and process-observation scope” and unresolved violations of “The backend cannot control unrelated host processes”.
- [ ] **UC-M03.03-C040-T08 · Evidence hygiene:** Check the “Process isolation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C040-T09 · Reproduction review:** Have the “Process isolation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C040-T10 · Acceptance linkage:** Link the “Process isolation” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Environment sanitization

**Source delivery:** Pass only required environment variables and remove ambient credentials.

**Source invariant:** The backend cannot inherit operator secrets accidentally.

**Source negative case:** A test secret is present in the parent environment.

**Source bounded quantities:** Environment entries and total bytes.

### UC-M03.03-C041 · Contract

**Original checklist item:** Specify environment sanitization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C041-T01 · Scope statement:** Draft the operation boundary for “Environment sanitization” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Environment sanitization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C041-T03 · Output inventory:** List the outputs of “Environment sanitization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Environment sanitization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C041-T05 · Prerequisite contract:** Map “Environment sanitization” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C041-T06 · Authority map:** Identify who may produce, change and consume “Environment sanitization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C041-T07 · Invariant clause:** Add a normative clause for “Environment sanitization” that preserves “The backend cannot inherit operator secrets accidentally”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Environment sanitization”; include the source counterexample “A test secret is present in the parent environment” and the intended safe disposition.
- [ ] **UC-M03.03-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Environment entries and total bytes” in the “Environment sanitization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C041-T10 · Contract review:** Review the “Environment sanitization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C042 · Delivery

**Original checklist item:** Pass only required environment variables and remove ambient credentials.

- [ ] **UC-M03.03-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Environment sanitization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C042-T02 · Change plan:** Break the source delivery for “Environment sanitization” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Environment sanitization” that realizes this source instruction: Pass only required environment variables and remove ambient credentials.
- [ ] **UC-M03.03-C042-T04 · Concrete realization:** Trace “Environment sanitization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.03-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Environment sanitization” needed to preserve “The backend cannot inherit operator secrets accidentally”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C042-T06 · Dependency connection:** Connect the “Environment sanitization” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C042-T07 · Resource behavior:** Account for “Environment entries and total bytes” in “Environment sanitization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C042-T08 · Delivery check:** Run the smallest real “Environment sanitization” path and its adverse fixture “A test secret is present in the parent environment”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C042-T09 · Patch review:** Review the “Environment sanitization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C042-T10 · Delivery handoff:** Publish the “Environment sanitization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The backend cannot inherit operator secrets accidentally. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C043-T01 · Named property:** Create a stable property/check name under this parent for “Environment sanitization”; copy its required invariant exactly: “The backend cannot inherit operator secrets accidentally”.
- [ ] **UC-M03.03-C043-T02 · Observable terms:** Define each term in the “Environment sanitization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C043-T03 · Precondition set:** List the preconditions under which “The backend cannot inherit operator secrets accidentally” must hold for “Environment sanitization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C043-T04 · Transition coverage:** Map the “Environment sanitization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Environment sanitization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C043-T06 · Satisfying fixture:** Create a concrete “Environment sanitization” case that satisfies “The backend cannot inherit operator secrets accidentally”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C043-T07 · Violating fixture:** Create the source counterexample “A test secret is present in the parent environment” for “Environment sanitization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C043-T08 · Enforcement evidence:** Exercise the “Environment sanitization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C043-T09 · Regression linkage:** Link the “Environment sanitization” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C043-T10 · Property disposition:** Compare the satisfying and violating “Environment sanitization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C044 · Integration

**Original checklist item:** Integrate environment sanitization with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Environment sanitization” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C044-T02 · Field mapping:** Map every “Environment sanitization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Environment sanitization” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C044-T04 · Ownership agreement:** Specify who owns “Environment sanitization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C044-T05 · Handoff implementation:** Connect “Environment sanitization” through the mapped seam using the real adapter or explicit specification reference; preserve “The backend cannot inherit operator secrets accidentally” across the handoff.
- [ ] **UC-M03.03-C044-T06 · Absent-input case:** Omit one required “Environment sanitization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C044-T07 · Stale-input case:** Supply an outdated “Environment sanitization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C044-T08 · Incompatible-input case:** Supply an incompatible “Environment sanitization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C044-T09 · Valid integration trace:** Run a valid “Environment sanitization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C044-T10 · Seam review:** Reconcile the “Environment sanitization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for environment sanitization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Environment sanitization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C045-T02 · Expected-result oracle:** Specify the “Environment sanitization” expected result independently of the implementation output; include the property “The backend cannot inherit operator secrets accidentally” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C045-T03 · Fixture material:** Create the concrete “Environment sanitization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C045-T04 · Target preparation:** Prepare the “Environment sanitization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C045-T05 · Initial-state record:** Record the initial “Environment sanitization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C045-T06 · Valid-path execution:** Execute the “Environment sanitization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C045-T07 · Outcome comparison:** Compare every declared “Environment sanitization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C045-T08 · State and bounds check:** Inspect the “Environment sanitization” ownership/state effects and actual use of “Environment entries and total bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C045-T09 · Repeatability check:** Repeat the same “Environment sanitization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C045-T10 · Positive evidence:** Attach the “Environment sanitization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C046 · Negative test

**Original checklist item:** Negative case: A test secret is present in the parent environment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C046-T01 · Adverse-case definition:** Create a test record for the exact “Environment sanitization” source counterexample: “A test secret is present in the parent environment”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Environment sanitization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C046-T03 · Valid control:** Construct a valid “Environment sanitization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C046-T04 · Minimal adverse input:** Derive the “Environment sanitization” adverse fixture from the control with the smallest documented change needed to reproduce “A test secret is present in the parent environment”; retain that change as reproducible data.
- [ ] **UC-M03.03-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Environment sanitization”; require “The backend cannot inherit operator secrets accidentally” and forbid a false-success verdict.
- [ ] **UC-M03.03-C046-T06 · Adverse execution:** Exercise the “Environment sanitization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C046-T07 · Effect inspection:** Inspect “Environment sanitization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C046-T08 · Refusal versus failure:** Confirm the “Environment sanitization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C046-T09 · Reset and retention:** Restore only the disposable “Environment sanitization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C046-T10 · Negative regression:** Register the “Environment sanitization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C047 · Change / failure test

**Original checklist item:** Exercise environment sanitization when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C047-T01 · Scenario record:** Write the “Environment sanitization” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “The backend cannot inherit operator secrets accidentally”.
- [ ] **UC-M03.03-C047-T02 · Baseline capture:** Create a known-valid “Environment sanitization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C047-T03 · Injection map:** Locate the “Environment sanitization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Environment sanitization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C047-T05 · Controlled trigger:** Introduce the controlled “Environment sanitization” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C047-T06 · Intermediate inspection:** Inspect the “Environment sanitization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Environment sanitization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Environment sanitization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C047-T09 · Repeat and compare:** Repeat the selected “Environment sanitization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C047-T10 · Failure evidence:** Publish the “Environment sanitization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C048 · Bounds

**Original checklist item:** Choose, document and test limits for environment entries and total bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C048-T01 · Quantity inventory:** Create a measurement inventory for “Environment sanitization”: “Environment entries and total bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C048-T02 · Measurement method:** Choose how to observe each “Environment sanitization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C048-T03 · Budget decision:** Select justified resource and input limits for “Environment sanitization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Environment sanitization” cases for “Environment entries and total bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Environment sanitization” limit; preserve “The backend cannot inherit operator secrets accidentally”.
- [ ] **UC-M03.03-C048-T06 · Normal measurement:** Run or review the normal “Environment sanitization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C048-T07 · At-limit measurement:** Exercise the “Environment sanitization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C048-T08 · Over-limit measurement:** Exercise the “Environment sanitization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C048-T09 · Uncovered-scope report:** List the “Environment sanitization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C048-T10 · Limit evidence:** Publish the selected “Environment sanitization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for environment sanitization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C049-T01 · Event inventory:** List the “Environment sanitization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Environment sanitization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C049-T03 · Failure mapping:** Map each documented “Environment sanitization” refusal or error to a diagnostic outcome; include “A test secret is present in the parent environment” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C049-T04 · Emission path:** Add the “Environment sanitization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C049-T05 · Redaction check:** Test “Environment sanitization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C049-T06 · Output budget:** Set and exercise bounded “Environment sanitization” message size, rate and retention compatible with “Environment entries and total bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C049-T07 · Success/refusal fixtures:** Capture “Environment sanitization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Environment sanitization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C049-T09 · Operator review:** Read the “Environment sanitization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C049-T10 · Diagnostic evidence:** Publish redacted “Environment sanitization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for environment sanitization; label unexecuted checks as untested.

- [ ] **UC-M03.03-C050-T01 · Evidence inventory:** List the “Environment sanitization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C050-T02 · Artifact references:** Record the exact “Environment sanitization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C050-T03 · Fixture references:** Attach the “Environment sanitization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test secret is present in the parent environment” as a distinct evidence case.
- [ ] **UC-M03.03-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Environment sanitization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C050-T05 · Environment record:** Record the actual “Environment sanitization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C050-T06 · Expected versus observed:** Pair every “Environment sanitization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C050-T07 · Failure and limit records:** Attach “Environment sanitization” change/failure and bounds evidence where required; include uncovered “Environment entries and total bytes” and unresolved violations of “The backend cannot inherit operator secrets accidentally”.
- [ ] **UC-M03.03-C050-T08 · Evidence hygiene:** Check the “Environment sanitization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C050-T09 · Reproduction review:** Have the “Environment sanitization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C050-T10 · Acceptance linkage:** Link the “Environment sanitization” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Device access allowlist

**Source delivery:** Grant only devices required by the selected guest profile.

**Source invariant:** An unlisted host device cannot be opened by the backend.

**Source negative case:** A guest-facing process attempts to access an unrelated device.

**Source bounded quantities:** Granted device count and open handles.

### UC-M03.03-C051 · Contract

**Original checklist item:** Specify device access allowlist inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C051-T01 · Scope statement:** Draft the operation boundary for “Device access allowlist” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Device access allowlist”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C051-T03 · Output inventory:** List the outputs of “Device access allowlist” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Device access allowlist”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C051-T05 · Prerequisite contract:** Map “Device access allowlist” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C051-T06 · Authority map:** Identify who may produce, change and consume “Device access allowlist”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C051-T07 · Invariant clause:** Add a normative clause for “Device access allowlist” that preserves “An unlisted host device cannot be opened by the backend”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Device access allowlist”; include the source counterexample “A guest-facing process attempts to access an unrelated device” and the intended safe disposition.
- [ ] **UC-M03.03-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Granted device count and open handles” in the “Device access allowlist” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C051-T10 · Contract review:** Review the “Device access allowlist” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C052 · Delivery

**Original checklist item:** Grant only devices required by the selected guest profile.

- [ ] **UC-M03.03-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Device access allowlist”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C052-T02 · Change plan:** Break the source delivery for “Device access allowlist” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Device access allowlist” that realizes this source instruction: Grant only devices required by the selected guest profile.
- [ ] **UC-M03.03-C052-T04 · Concrete realization:** Trace “Device access allowlist” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.03-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Device access allowlist” needed to preserve “An unlisted host device cannot be opened by the backend”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C052-T06 · Dependency connection:** Connect the “Device access allowlist” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C052-T07 · Resource behavior:** Account for “Granted device count and open handles” in “Device access allowlist”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C052-T08 · Delivery check:** Run the smallest real “Device access allowlist” path and its adverse fixture “A guest-facing process attempts to access an unrelated device”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C052-T09 · Patch review:** Review the “Device access allowlist” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C052-T10 · Delivery handoff:** Publish the “Device access allowlist” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An unlisted host device cannot be opened by the backend. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C053-T01 · Named property:** Create a stable property/check name under this parent for “Device access allowlist”; copy its required invariant exactly: “An unlisted host device cannot be opened by the backend”.
- [ ] **UC-M03.03-C053-T02 · Observable terms:** Define each term in the “Device access allowlist” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C053-T03 · Precondition set:** List the preconditions under which “An unlisted host device cannot be opened by the backend” must hold for “Device access allowlist”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C053-T04 · Transition coverage:** Map the “Device access allowlist” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Device access allowlist”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C053-T06 · Satisfying fixture:** Create a concrete “Device access allowlist” case that satisfies “An unlisted host device cannot be opened by the backend”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C053-T07 · Violating fixture:** Create the source counterexample “A guest-facing process attempts to access an unrelated device” for “Device access allowlist”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C053-T08 · Enforcement evidence:** Exercise the “Device access allowlist” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C053-T09 · Regression linkage:** Link the “Device access allowlist” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C053-T10 · Property disposition:** Compare the satisfying and violating “Device access allowlist” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C054 · Integration

**Original checklist item:** Integrate device access allowlist with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Device access allowlist” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C054-T02 · Field mapping:** Map every “Device access allowlist” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Device access allowlist” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C054-T04 · Ownership agreement:** Specify who owns “Device access allowlist” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C054-T05 · Handoff implementation:** Connect “Device access allowlist” through the mapped seam using the real adapter or explicit specification reference; preserve “An unlisted host device cannot be opened by the backend” across the handoff.
- [ ] **UC-M03.03-C054-T06 · Absent-input case:** Omit one required “Device access allowlist” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C054-T07 · Stale-input case:** Supply an outdated “Device access allowlist” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C054-T08 · Incompatible-input case:** Supply an incompatible “Device access allowlist” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C054-T09 · Valid integration trace:** Run a valid “Device access allowlist” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C054-T10 · Seam review:** Reconcile the “Device access allowlist” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for device access allowlist; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Device access allowlist” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C055-T02 · Expected-result oracle:** Specify the “Device access allowlist” expected result independently of the implementation output; include the property “An unlisted host device cannot be opened by the backend” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C055-T03 · Fixture material:** Create the concrete “Device access allowlist” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C055-T04 · Target preparation:** Prepare the “Device access allowlist” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C055-T05 · Initial-state record:** Record the initial “Device access allowlist” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C055-T06 · Valid-path execution:** Execute the “Device access allowlist” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C055-T07 · Outcome comparison:** Compare every declared “Device access allowlist” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C055-T08 · State and bounds check:** Inspect the “Device access allowlist” ownership/state effects and actual use of “Granted device count and open handles”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C055-T09 · Repeatability check:** Repeat the same “Device access allowlist” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C055-T10 · Positive evidence:** Attach the “Device access allowlist” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C056 · Negative test

**Original checklist item:** Negative case: A guest-facing process attempts to access an unrelated device. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C056-T01 · Adverse-case definition:** Create a test record for the exact “Device access allowlist” source counterexample: “A guest-facing process attempts to access an unrelated device”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Device access allowlist”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C056-T03 · Valid control:** Construct a valid “Device access allowlist” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C056-T04 · Minimal adverse input:** Derive the “Device access allowlist” adverse fixture from the control with the smallest documented change needed to reproduce “A guest-facing process attempts to access an unrelated device”; retain that change as reproducible data.
- [ ] **UC-M03.03-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Device access allowlist”; require “An unlisted host device cannot be opened by the backend” and forbid a false-success verdict.
- [ ] **UC-M03.03-C056-T06 · Adverse execution:** Exercise the “Device access allowlist” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C056-T07 · Effect inspection:** Inspect “Device access allowlist” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C056-T08 · Refusal versus failure:** Confirm the “Device access allowlist” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C056-T09 · Reset and retention:** Restore only the disposable “Device access allowlist” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C056-T10 · Negative regression:** Register the “Device access allowlist” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C057 · Change / failure test

**Original checklist item:** Exercise device access allowlist when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C057-T01 · Scenario record:** Write the “Device access allowlist” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “An unlisted host device cannot be opened by the backend”.
- [ ] **UC-M03.03-C057-T02 · Baseline capture:** Create a known-valid “Device access allowlist” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C057-T03 · Injection map:** Locate the “Device access allowlist” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Device access allowlist” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C057-T05 · Controlled trigger:** Introduce the controlled “Device access allowlist” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C057-T06 · Intermediate inspection:** Inspect the “Device access allowlist” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Device access allowlist”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Device access allowlist” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C057-T09 · Repeat and compare:** Repeat the selected “Device access allowlist” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C057-T10 · Failure evidence:** Publish the “Device access allowlist” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C058 · Bounds

**Original checklist item:** Choose, document and test limits for granted device count and open handles; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C058-T01 · Quantity inventory:** Create a measurement inventory for “Device access allowlist”: “Granted device count and open handles”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C058-T02 · Measurement method:** Choose how to observe each “Device access allowlist” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C058-T03 · Budget decision:** Select justified resource and input limits for “Device access allowlist”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Device access allowlist” cases for “Granted device count and open handles”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Device access allowlist” limit; preserve “An unlisted host device cannot be opened by the backend”.
- [ ] **UC-M03.03-C058-T06 · Normal measurement:** Run or review the normal “Device access allowlist” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C058-T07 · At-limit measurement:** Exercise the “Device access allowlist” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C058-T08 · Over-limit measurement:** Exercise the “Device access allowlist” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C058-T09 · Uncovered-scope report:** List the “Device access allowlist” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C058-T10 · Limit evidence:** Publish the selected “Device access allowlist” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for device access allowlist with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C059-T01 · Event inventory:** List the “Device access allowlist” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Device access allowlist” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C059-T03 · Failure mapping:** Map each documented “Device access allowlist” refusal or error to a diagnostic outcome; include “A guest-facing process attempts to access an unrelated device” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C059-T04 · Emission path:** Add the “Device access allowlist” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C059-T05 · Redaction check:** Test “Device access allowlist” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C059-T06 · Output budget:** Set and exercise bounded “Device access allowlist” message size, rate and retention compatible with “Granted device count and open handles”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C059-T07 · Success/refusal fixtures:** Capture “Device access allowlist” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Device access allowlist” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C059-T09 · Operator review:** Read the “Device access allowlist” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C059-T10 · Diagnostic evidence:** Publish redacted “Device access allowlist” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for device access allowlist; label unexecuted checks as untested.

- [ ] **UC-M03.03-C060-T01 · Evidence inventory:** List the “Device access allowlist” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C060-T02 · Artifact references:** Record the exact “Device access allowlist” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C060-T03 · Fixture references:** Attach the “Device access allowlist” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest-facing process attempts to access an unrelated device” as a distinct evidence case.
- [ ] **UC-M03.03-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Device access allowlist”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C060-T05 · Environment record:** Record the actual “Device access allowlist” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C060-T06 · Expected versus observed:** Pair every “Device access allowlist” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C060-T07 · Failure and limit records:** Attach “Device access allowlist” change/failure and bounds evidence where required; include uncovered “Granted device count and open handles” and unresolved violations of “An unlisted host device cannot be opened by the backend”.
- [ ] **UC-M03.03-C060-T08 · Evidence hygiene:** Check the “Device access allowlist” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C060-T09 · Reproduction review:** Have the “Device access allowlist” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C060-T10 · Acceptance linkage:** Link the “Device access allowlist” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Sandbox setup ordering

**Source delivery:** Apply required restrictions before untrusted image or device processing.

**Source invariant:** Untrusted input never runs during an unrestricted setup interval.

**Source negative case:** The backend parses cargo before entering its sandbox.

**Source bounded quantities:** Setup duration and pre-restriction operations.

### UC-M03.03-C061 · Contract

**Original checklist item:** Specify sandbox setup ordering inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C061-T01 · Scope statement:** Draft the operation boundary for “Sandbox setup ordering” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Sandbox setup ordering”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C061-T03 · Output inventory:** List the outputs of “Sandbox setup ordering” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Sandbox setup ordering”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C061-T05 · Prerequisite contract:** Map “Sandbox setup ordering” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C061-T06 · Authority map:** Identify who may produce, change and consume “Sandbox setup ordering”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C061-T07 · Invariant clause:** Add a normative clause for “Sandbox setup ordering” that preserves “Untrusted input never runs during an unrestricted setup interval”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Sandbox setup ordering”; include the source counterexample “The backend parses cargo before entering its sandbox” and the intended safe disposition.
- [ ] **UC-M03.03-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Setup duration and pre-restriction operations” in the “Sandbox setup ordering” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C061-T10 · Contract review:** Review the “Sandbox setup ordering” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C062 · Delivery

**Original checklist item:** Apply required restrictions before untrusted image or device processing.

- [ ] **UC-M03.03-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Sandbox setup ordering”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C062-T02 · Change plan:** Break the source delivery for “Sandbox setup ordering” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Sandbox setup ordering” that realizes this source instruction: Apply required restrictions before untrusted image or device processing.
- [ ] **UC-M03.03-C062-T04 · Concrete realization:** Trace “Sandbox setup ordering” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.03-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Sandbox setup ordering” needed to preserve “Untrusted input never runs during an unrestricted setup interval”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C062-T06 · Dependency connection:** Connect the “Sandbox setup ordering” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C062-T07 · Resource behavior:** Account for “Setup duration and pre-restriction operations” in “Sandbox setup ordering”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C062-T08 · Delivery check:** Run the smallest real “Sandbox setup ordering” path and its adverse fixture “The backend parses cargo before entering its sandbox”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C062-T09 · Patch review:** Review the “Sandbox setup ordering” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C062-T10 · Delivery handoff:** Publish the “Sandbox setup ordering” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Untrusted input never runs during an unrestricted setup interval. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C063-T01 · Named property:** Create a stable property/check name under this parent for “Sandbox setup ordering”; copy its required invariant exactly: “Untrusted input never runs during an unrestricted setup interval”.
- [ ] **UC-M03.03-C063-T02 · Observable terms:** Define each term in the “Sandbox setup ordering” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C063-T03 · Precondition set:** List the preconditions under which “Untrusted input never runs during an unrestricted setup interval” must hold for “Sandbox setup ordering”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C063-T04 · Transition coverage:** Map the “Sandbox setup ordering” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Sandbox setup ordering”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C063-T06 · Satisfying fixture:** Create a concrete “Sandbox setup ordering” case that satisfies “Untrusted input never runs during an unrestricted setup interval”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C063-T07 · Violating fixture:** Create the source counterexample “The backend parses cargo before entering its sandbox” for “Sandbox setup ordering”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C063-T08 · Enforcement evidence:** Exercise the “Sandbox setup ordering” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C063-T09 · Regression linkage:** Link the “Sandbox setup ordering” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C063-T10 · Property disposition:** Compare the satisfying and violating “Sandbox setup ordering” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C064 · Integration

**Original checklist item:** Integrate sandbox setup ordering with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Sandbox setup ordering” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C064-T02 · Field mapping:** Map every “Sandbox setup ordering” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Sandbox setup ordering” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C064-T04 · Ownership agreement:** Specify who owns “Sandbox setup ordering” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C064-T05 · Handoff implementation:** Connect “Sandbox setup ordering” through the mapped seam using the real adapter or explicit specification reference; preserve “Untrusted input never runs during an unrestricted setup interval” across the handoff.
- [ ] **UC-M03.03-C064-T06 · Absent-input case:** Omit one required “Sandbox setup ordering” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C064-T07 · Stale-input case:** Supply an outdated “Sandbox setup ordering” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C064-T08 · Incompatible-input case:** Supply an incompatible “Sandbox setup ordering” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C064-T09 · Valid integration trace:** Run a valid “Sandbox setup ordering” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C064-T10 · Seam review:** Reconcile the “Sandbox setup ordering” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for sandbox setup ordering; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Sandbox setup ordering” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C065-T02 · Expected-result oracle:** Specify the “Sandbox setup ordering” expected result independently of the implementation output; include the property “Untrusted input never runs during an unrestricted setup interval” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C065-T03 · Fixture material:** Create the concrete “Sandbox setup ordering” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C065-T04 · Target preparation:** Prepare the “Sandbox setup ordering” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C065-T05 · Initial-state record:** Record the initial “Sandbox setup ordering” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C065-T06 · Valid-path execution:** Execute the “Sandbox setup ordering” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C065-T07 · Outcome comparison:** Compare every declared “Sandbox setup ordering” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C065-T08 · State and bounds check:** Inspect the “Sandbox setup ordering” ownership/state effects and actual use of “Setup duration and pre-restriction operations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C065-T09 · Repeatability check:** Repeat the same “Sandbox setup ordering” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C065-T10 · Positive evidence:** Attach the “Sandbox setup ordering” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C066 · Negative test

**Original checklist item:** Negative case: The backend parses cargo before entering its sandbox. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C066-T01 · Adverse-case definition:** Create a test record for the exact “Sandbox setup ordering” source counterexample: “The backend parses cargo before entering its sandbox”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Sandbox setup ordering”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C066-T03 · Valid control:** Construct a valid “Sandbox setup ordering” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C066-T04 · Minimal adverse input:** Derive the “Sandbox setup ordering” adverse fixture from the control with the smallest documented change needed to reproduce “The backend parses cargo before entering its sandbox”; retain that change as reproducible data.
- [ ] **UC-M03.03-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Sandbox setup ordering”; require “Untrusted input never runs during an unrestricted setup interval” and forbid a false-success verdict.
- [ ] **UC-M03.03-C066-T06 · Adverse execution:** Exercise the “Sandbox setup ordering” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C066-T07 · Effect inspection:** Inspect “Sandbox setup ordering” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C066-T08 · Refusal versus failure:** Confirm the “Sandbox setup ordering” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C066-T09 · Reset and retention:** Restore only the disposable “Sandbox setup ordering” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C066-T10 · Negative regression:** Register the “Sandbox setup ordering” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C067 · Change / failure test

**Original checklist item:** Exercise sandbox setup ordering when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C067-T01 · Scenario record:** Write the “Sandbox setup ordering” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “Untrusted input never runs during an unrestricted setup interval”.
- [ ] **UC-M03.03-C067-T02 · Baseline capture:** Create a known-valid “Sandbox setup ordering” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C067-T03 · Injection map:** Locate the “Sandbox setup ordering” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Sandbox setup ordering” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C067-T05 · Controlled trigger:** Introduce the controlled “Sandbox setup ordering” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C067-T06 · Intermediate inspection:** Inspect the “Sandbox setup ordering” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Sandbox setup ordering”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Sandbox setup ordering” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C067-T09 · Repeat and compare:** Repeat the selected “Sandbox setup ordering” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C067-T10 · Failure evidence:** Publish the “Sandbox setup ordering” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C068 · Bounds

**Original checklist item:** Choose, document and test limits for setup duration and pre-restriction operations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C068-T01 · Quantity inventory:** Create a measurement inventory for “Sandbox setup ordering”: “Setup duration and pre-restriction operations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C068-T02 · Measurement method:** Choose how to observe each “Sandbox setup ordering” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C068-T03 · Budget decision:** Select justified resource and input limits for “Sandbox setup ordering”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Sandbox setup ordering” cases for “Setup duration and pre-restriction operations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Sandbox setup ordering” limit; preserve “Untrusted input never runs during an unrestricted setup interval”.
- [ ] **UC-M03.03-C068-T06 · Normal measurement:** Run or review the normal “Sandbox setup ordering” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C068-T07 · At-limit measurement:** Exercise the “Sandbox setup ordering” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C068-T08 · Over-limit measurement:** Exercise the “Sandbox setup ordering” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C068-T09 · Uncovered-scope report:** List the “Sandbox setup ordering” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C068-T10 · Limit evidence:** Publish the selected “Sandbox setup ordering” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for sandbox setup ordering with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C069-T01 · Event inventory:** List the “Sandbox setup ordering” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Sandbox setup ordering” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C069-T03 · Failure mapping:** Map each documented “Sandbox setup ordering” refusal or error to a diagnostic outcome; include “The backend parses cargo before entering its sandbox” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C069-T04 · Emission path:** Add the “Sandbox setup ordering” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C069-T05 · Redaction check:** Test “Sandbox setup ordering” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C069-T06 · Output budget:** Set and exercise bounded “Sandbox setup ordering” message size, rate and retention compatible with “Setup duration and pre-restriction operations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C069-T07 · Success/refusal fixtures:** Capture “Sandbox setup ordering” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Sandbox setup ordering” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C069-T09 · Operator review:** Read the “Sandbox setup ordering” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C069-T10 · Diagnostic evidence:** Publish redacted “Sandbox setup ordering” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for sandbox setup ordering; label unexecuted checks as untested.

- [ ] **UC-M03.03-C070-T01 · Evidence inventory:** List the “Sandbox setup ordering” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C070-T02 · Artifact references:** Record the exact “Sandbox setup ordering” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C070-T03 · Fixture references:** Attach the “Sandbox setup ordering” fixture IDs, input identities and oracle definition; preserve the source counterexample “The backend parses cargo before entering its sandbox” as a distinct evidence case.
- [ ] **UC-M03.03-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Sandbox setup ordering”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C070-T05 · Environment record:** Record the actual “Sandbox setup ordering” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C070-T06 · Expected versus observed:** Pair every “Sandbox setup ordering” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C070-T07 · Failure and limit records:** Attach “Sandbox setup ordering” change/failure and bounds evidence where required; include uncovered “Setup duration and pre-restriction operations” and unresolved violations of “Untrusted input never runs during an unrestricted setup interval”.
- [ ] **UC-M03.03-C070-T08 · Evidence hygiene:** Check the “Sandbox setup ordering” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C070-T09 · Reproduction review:** Have the “Sandbox setup ordering” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C070-T10 · Acceptance linkage:** Link the “Sandbox setup ordering” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Sandbox refusal behavior

**Source delivery:** Fail admission when a required restriction cannot be applied.

**Source invariant:** Failed sandbox setup cannot degrade into unrestricted execution.

**Source negative case:** The host refuses a required isolation primitive.

**Source bounded quantities:** Setup retries and refusal diagnostic size.

### UC-M03.03-C071 · Contract

**Original checklist item:** Specify sandbox refusal behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C071-T01 · Scope statement:** Draft the operation boundary for “Sandbox refusal behavior” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Sandbox refusal behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C071-T03 · Output inventory:** List the outputs of “Sandbox refusal behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Sandbox refusal behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C071-T05 · Prerequisite contract:** Map “Sandbox refusal behavior” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C071-T06 · Authority map:** Identify who may produce, change and consume “Sandbox refusal behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C071-T07 · Invariant clause:** Add a normative clause for “Sandbox refusal behavior” that preserves “Failed sandbox setup cannot degrade into unrestricted execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Sandbox refusal behavior”; include the source counterexample “The host refuses a required isolation primitive” and the intended safe disposition.
- [ ] **UC-M03.03-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Setup retries and refusal diagnostic size” in the “Sandbox refusal behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C071-T10 · Contract review:** Review the “Sandbox refusal behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C072 · Delivery

**Original checklist item:** Fail admission when a required restriction cannot be applied.

- [ ] **UC-M03.03-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Sandbox refusal behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C072-T02 · Change plan:** Break the source delivery for “Sandbox refusal behavior” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Sandbox refusal behavior” that realizes this source instruction: Fail admission when a required restriction cannot be applied.
- [ ] **UC-M03.03-C072-T04 · Concrete realization:** Trace “Sandbox refusal behavior” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.03-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Sandbox refusal behavior” needed to preserve “Failed sandbox setup cannot degrade into unrestricted execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C072-T06 · Dependency connection:** Connect the “Sandbox refusal behavior” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C072-T07 · Resource behavior:** Account for “Setup retries and refusal diagnostic size” in “Sandbox refusal behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C072-T08 · Delivery check:** Run the smallest real “Sandbox refusal behavior” path and its adverse fixture “The host refuses a required isolation primitive”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C072-T09 · Patch review:** Review the “Sandbox refusal behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C072-T10 · Delivery handoff:** Publish the “Sandbox refusal behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Failed sandbox setup cannot degrade into unrestricted execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C073-T01 · Named property:** Create a stable property/check name under this parent for “Sandbox refusal behavior”; copy its required invariant exactly: “Failed sandbox setup cannot degrade into unrestricted execution”.
- [ ] **UC-M03.03-C073-T02 · Observable terms:** Define each term in the “Sandbox refusal behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C073-T03 · Precondition set:** List the preconditions under which “Failed sandbox setup cannot degrade into unrestricted execution” must hold for “Sandbox refusal behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C073-T04 · Transition coverage:** Map the “Sandbox refusal behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Sandbox refusal behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C073-T06 · Satisfying fixture:** Create a concrete “Sandbox refusal behavior” case that satisfies “Failed sandbox setup cannot degrade into unrestricted execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C073-T07 · Violating fixture:** Create the source counterexample “The host refuses a required isolation primitive” for “Sandbox refusal behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C073-T08 · Enforcement evidence:** Exercise the “Sandbox refusal behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C073-T09 · Regression linkage:** Link the “Sandbox refusal behavior” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C073-T10 · Property disposition:** Compare the satisfying and violating “Sandbox refusal behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C074 · Integration

**Original checklist item:** Integrate sandbox refusal behavior with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Sandbox refusal behavior” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C074-T02 · Field mapping:** Map every “Sandbox refusal behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Sandbox refusal behavior” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C074-T04 · Ownership agreement:** Specify who owns “Sandbox refusal behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C074-T05 · Handoff implementation:** Connect “Sandbox refusal behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Failed sandbox setup cannot degrade into unrestricted execution” across the handoff.
- [ ] **UC-M03.03-C074-T06 · Absent-input case:** Omit one required “Sandbox refusal behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C074-T07 · Stale-input case:** Supply an outdated “Sandbox refusal behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C074-T08 · Incompatible-input case:** Supply an incompatible “Sandbox refusal behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C074-T09 · Valid integration trace:** Run a valid “Sandbox refusal behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C074-T10 · Seam review:** Reconcile the “Sandbox refusal behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for sandbox refusal behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Sandbox refusal behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C075-T02 · Expected-result oracle:** Specify the “Sandbox refusal behavior” expected result independently of the implementation output; include the property “Failed sandbox setup cannot degrade into unrestricted execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C075-T03 · Fixture material:** Create the concrete “Sandbox refusal behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C075-T04 · Target preparation:** Prepare the “Sandbox refusal behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C075-T05 · Initial-state record:** Record the initial “Sandbox refusal behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C075-T06 · Valid-path execution:** Execute the “Sandbox refusal behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C075-T07 · Outcome comparison:** Compare every declared “Sandbox refusal behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C075-T08 · State and bounds check:** Inspect the “Sandbox refusal behavior” ownership/state effects and actual use of “Setup retries and refusal diagnostic size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C075-T09 · Repeatability check:** Repeat the same “Sandbox refusal behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C075-T10 · Positive evidence:** Attach the “Sandbox refusal behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C076 · Negative test

**Original checklist item:** Negative case: The host refuses a required isolation primitive. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C076-T01 · Adverse-case definition:** Create a test record for the exact “Sandbox refusal behavior” source counterexample: “The host refuses a required isolation primitive”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Sandbox refusal behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C076-T03 · Valid control:** Construct a valid “Sandbox refusal behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C076-T04 · Minimal adverse input:** Derive the “Sandbox refusal behavior” adverse fixture from the control with the smallest documented change needed to reproduce “The host refuses a required isolation primitive”; retain that change as reproducible data.
- [ ] **UC-M03.03-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Sandbox refusal behavior”; require “Failed sandbox setup cannot degrade into unrestricted execution” and forbid a false-success verdict.
- [ ] **UC-M03.03-C076-T06 · Adverse execution:** Exercise the “Sandbox refusal behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C076-T07 · Effect inspection:** Inspect “Sandbox refusal behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C076-T08 · Refusal versus failure:** Confirm the “Sandbox refusal behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C076-T09 · Reset and retention:** Restore only the disposable “Sandbox refusal behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C076-T10 · Negative regression:** Register the “Sandbox refusal behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C077 · Change / failure test

**Original checklist item:** Exercise sandbox refusal behavior when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C077-T01 · Scenario record:** Write the “Sandbox refusal behavior” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “Failed sandbox setup cannot degrade into unrestricted execution”.
- [ ] **UC-M03.03-C077-T02 · Baseline capture:** Create a known-valid “Sandbox refusal behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C077-T03 · Injection map:** Locate the “Sandbox refusal behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Sandbox refusal behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C077-T05 · Controlled trigger:** Introduce the controlled “Sandbox refusal behavior” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C077-T06 · Intermediate inspection:** Inspect the “Sandbox refusal behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Sandbox refusal behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Sandbox refusal behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C077-T09 · Repeat and compare:** Repeat the selected “Sandbox refusal behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C077-T10 · Failure evidence:** Publish the “Sandbox refusal behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C078 · Bounds

**Original checklist item:** Choose, document and test limits for setup retries and refusal diagnostic size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C078-T01 · Quantity inventory:** Create a measurement inventory for “Sandbox refusal behavior”: “Setup retries and refusal diagnostic size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C078-T02 · Measurement method:** Choose how to observe each “Sandbox refusal behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C078-T03 · Budget decision:** Select justified resource and input limits for “Sandbox refusal behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Sandbox refusal behavior” cases for “Setup retries and refusal diagnostic size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Sandbox refusal behavior” limit; preserve “Failed sandbox setup cannot degrade into unrestricted execution”.
- [ ] **UC-M03.03-C078-T06 · Normal measurement:** Run or review the normal “Sandbox refusal behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C078-T07 · At-limit measurement:** Exercise the “Sandbox refusal behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C078-T08 · Over-limit measurement:** Exercise the “Sandbox refusal behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C078-T09 · Uncovered-scope report:** List the “Sandbox refusal behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C078-T10 · Limit evidence:** Publish the selected “Sandbox refusal behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for sandbox refusal behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C079-T01 · Event inventory:** List the “Sandbox refusal behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Sandbox refusal behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C079-T03 · Failure mapping:** Map each documented “Sandbox refusal behavior” refusal or error to a diagnostic outcome; include “The host refuses a required isolation primitive” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C079-T04 · Emission path:** Add the “Sandbox refusal behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C079-T05 · Redaction check:** Test “Sandbox refusal behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C079-T06 · Output budget:** Set and exercise bounded “Sandbox refusal behavior” message size, rate and retention compatible with “Setup retries and refusal diagnostic size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C079-T07 · Success/refusal fixtures:** Capture “Sandbox refusal behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Sandbox refusal behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C079-T09 · Operator review:** Read the “Sandbox refusal behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C079-T10 · Diagnostic evidence:** Publish redacted “Sandbox refusal behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for sandbox refusal behavior; label unexecuted checks as untested.

- [ ] **UC-M03.03-C080-T01 · Evidence inventory:** List the “Sandbox refusal behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C080-T02 · Artifact references:** Record the exact “Sandbox refusal behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C080-T03 · Fixture references:** Attach the “Sandbox refusal behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “The host refuses a required isolation primitive” as a distinct evidence case.
- [ ] **UC-M03.03-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Sandbox refusal behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C080-T05 · Environment record:** Record the actual “Sandbox refusal behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C080-T06 · Expected versus observed:** Pair every “Sandbox refusal behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C080-T07 · Failure and limit records:** Attach “Sandbox refusal behavior” change/failure and bounds evidence where required; include uncovered “Setup retries and refusal diagnostic size” and unresolved violations of “Failed sandbox setup cannot degrade into unrestricted execution”.
- [ ] **UC-M03.03-C080-T08 · Evidence hygiene:** Check the “Sandbox refusal behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C080-T09 · Reproduction review:** Have the “Sandbox refusal behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C080-T10 · Acceptance linkage:** Link the “Sandbox refusal behavior” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Adversarial access tests

**Source delivery:** Probe unrelated file, process and operation access in a disposable test environment.

**Source invariant:** Tests show actual denial rather than declared policy intent.

**Source negative case:** A forbidden file read succeeds despite a configured deny rule.

**Source bounded quantities:** Probe runtime and test-environment resource budget.

### UC-M03.03-C081 · Contract

**Original checklist item:** Specify adversarial access tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C081-T01 · Scope statement:** Draft the operation boundary for “Adversarial access tests” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Adversarial access tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C081-T03 · Output inventory:** List the outputs of “Adversarial access tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Adversarial access tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C081-T05 · Prerequisite contract:** Map “Adversarial access tests” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C081-T06 · Authority map:** Identify who may produce, change and consume “Adversarial access tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C081-T07 · Invariant clause:** Add a normative clause for “Adversarial access tests” that preserves “Tests show actual denial rather than declared policy intent”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Adversarial access tests”; include the source counterexample “A forbidden file read succeeds despite a configured deny rule” and the intended safe disposition.
- [ ] **UC-M03.03-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe runtime and test-environment resource budget” in the “Adversarial access tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C081-T10 · Contract review:** Review the “Adversarial access tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C082 · Delivery

**Original checklist item:** Probe unrelated file, process and operation access in a disposable test environment.

- [ ] **UC-M03.03-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Adversarial access tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C082-T02 · Change plan:** Break the source delivery for “Adversarial access tests” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C082-T03 · Core artifact:** Create the “Adversarial access tests” fixture or harness for this source instruction: Probe unrelated file, process and operation access in a disposable test environment.
- [ ] **UC-M03.03-C082-T04 · Concrete realization:** Connect the “Adversarial access tests” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.03-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Adversarial access tests” needed to preserve “Tests show actual denial rather than declared policy intent”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C082-T06 · Dependency connection:** Connect the “Adversarial access tests” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C082-T07 · Resource behavior:** Account for “Probe runtime and test-environment resource budget” in “Adversarial access tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C082-T08 · Delivery check:** Run the smallest real “Adversarial access tests” path and its adverse fixture “A forbidden file read succeeds despite a configured deny rule”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C082-T09 · Patch review:** Review the “Adversarial access tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C082-T10 · Delivery handoff:** Publish the “Adversarial access tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Tests show actual denial rather than declared policy intent. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C083-T01 · Named property:** Create a stable property/check name under this parent for “Adversarial access tests”; copy its required invariant exactly: “Tests show actual denial rather than declared policy intent”.
- [ ] **UC-M03.03-C083-T02 · Observable terms:** Define each term in the “Adversarial access tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C083-T03 · Precondition set:** List the preconditions under which “Tests show actual denial rather than declared policy intent” must hold for “Adversarial access tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C083-T04 · Transition coverage:** Map the “Adversarial access tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Adversarial access tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C083-T06 · Satisfying fixture:** Create a concrete “Adversarial access tests” case that satisfies “Tests show actual denial rather than declared policy intent”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C083-T07 · Violating fixture:** Create the source counterexample “A forbidden file read succeeds despite a configured deny rule” for “Adversarial access tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C083-T08 · Enforcement evidence:** Exercise the “Adversarial access tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C083-T09 · Regression linkage:** Link the “Adversarial access tests” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C083-T10 · Property disposition:** Compare the satisfying and violating “Adversarial access tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C084 · Integration

**Original checklist item:** Integrate adversarial access tests with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Adversarial access tests” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C084-T02 · Field mapping:** Map every “Adversarial access tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Adversarial access tests” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C084-T04 · Ownership agreement:** Specify who owns “Adversarial access tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C084-T05 · Handoff implementation:** Connect “Adversarial access tests” through the mapped seam using the real adapter or explicit specification reference; preserve “Tests show actual denial rather than declared policy intent” across the handoff.
- [ ] **UC-M03.03-C084-T06 · Absent-input case:** Omit one required “Adversarial access tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C084-T07 · Stale-input case:** Supply an outdated “Adversarial access tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C084-T08 · Incompatible-input case:** Supply an incompatible “Adversarial access tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C084-T09 · Valid integration trace:** Run a valid “Adversarial access tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C084-T10 · Seam review:** Reconcile the “Adversarial access tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for adversarial access tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Adversarial access tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C085-T02 · Expected-result oracle:** Specify the “Adversarial access tests” expected result independently of the implementation output; include the property “Tests show actual denial rather than declared policy intent” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C085-T03 · Fixture material:** Create the concrete “Adversarial access tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C085-T04 · Target preparation:** Prepare the “Adversarial access tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C085-T05 · Initial-state record:** Record the initial “Adversarial access tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C085-T06 · Valid-path execution:** Execute the “Adversarial access tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C085-T07 · Outcome comparison:** Compare every declared “Adversarial access tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C085-T08 · State and bounds check:** Inspect the “Adversarial access tests” ownership/state effects and actual use of “Probe runtime and test-environment resource budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C085-T09 · Repeatability check:** Repeat the same “Adversarial access tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C085-T10 · Positive evidence:** Attach the “Adversarial access tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C086 · Negative test

**Original checklist item:** Negative case: A forbidden file read succeeds despite a configured deny rule. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C086-T01 · Adverse-case definition:** Create a test record for the exact “Adversarial access tests” source counterexample: “A forbidden file read succeeds despite a configured deny rule”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Adversarial access tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C086-T03 · Valid control:** Construct a valid “Adversarial access tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C086-T04 · Minimal adverse input:** Derive the “Adversarial access tests” adverse fixture from the control with the smallest documented change needed to reproduce “A forbidden file read succeeds despite a configured deny rule”; retain that change as reproducible data.
- [ ] **UC-M03.03-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Adversarial access tests”; require “Tests show actual denial rather than declared policy intent” and forbid a false-success verdict.
- [ ] **UC-M03.03-C086-T06 · Adverse execution:** Exercise the “Adversarial access tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C086-T07 · Effect inspection:** Inspect “Adversarial access tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C086-T08 · Refusal versus failure:** Confirm the “Adversarial access tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C086-T09 · Reset and retention:** Restore only the disposable “Adversarial access tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C086-T10 · Negative regression:** Register the “Adversarial access tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C087 · Change / failure test

**Original checklist item:** Exercise adversarial access tests when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C087-T01 · Scenario record:** Write the “Adversarial access tests” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “Tests show actual denial rather than declared policy intent”.
- [ ] **UC-M03.03-C087-T02 · Baseline capture:** Create a known-valid “Adversarial access tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C087-T03 · Injection map:** Locate the “Adversarial access tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Adversarial access tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C087-T05 · Controlled trigger:** Introduce the controlled “Adversarial access tests” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C087-T06 · Intermediate inspection:** Inspect the “Adversarial access tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Adversarial access tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Adversarial access tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C087-T09 · Repeat and compare:** Repeat the selected “Adversarial access tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C087-T10 · Failure evidence:** Publish the “Adversarial access tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C088 · Bounds

**Original checklist item:** Choose, document and test limits for probe runtime and test-environment resource budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C088-T01 · Quantity inventory:** Create a measurement inventory for “Adversarial access tests”: “Probe runtime and test-environment resource budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C088-T02 · Measurement method:** Choose how to observe each “Adversarial access tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C088-T03 · Budget decision:** Select justified resource and input limits for “Adversarial access tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Adversarial access tests” cases for “Probe runtime and test-environment resource budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Adversarial access tests” limit; preserve “Tests show actual denial rather than declared policy intent”.
- [ ] **UC-M03.03-C088-T06 · Normal measurement:** Run or review the normal “Adversarial access tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C088-T07 · At-limit measurement:** Exercise the “Adversarial access tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C088-T08 · Over-limit measurement:** Exercise the “Adversarial access tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C088-T09 · Uncovered-scope report:** List the “Adversarial access tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C088-T10 · Limit evidence:** Publish the selected “Adversarial access tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for adversarial access tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C089-T01 · Event inventory:** List the “Adversarial access tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Adversarial access tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C089-T03 · Failure mapping:** Map each documented “Adversarial access tests” refusal or error to a diagnostic outcome; include “A forbidden file read succeeds despite a configured deny rule” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C089-T04 · Emission path:** Add the “Adversarial access tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C089-T05 · Redaction check:** Test “Adversarial access tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C089-T06 · Output budget:** Set and exercise bounded “Adversarial access tests” message size, rate and retention compatible with “Probe runtime and test-environment resource budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C089-T07 · Success/refusal fixtures:** Capture “Adversarial access tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Adversarial access tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C089-T09 · Operator review:** Read the “Adversarial access tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C089-T10 · Diagnostic evidence:** Publish redacted “Adversarial access tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for adversarial access tests; label unexecuted checks as untested.

- [ ] **UC-M03.03-C090-T01 · Evidence inventory:** List the “Adversarial access tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C090-T02 · Artifact references:** Record the exact “Adversarial access tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C090-T03 · Fixture references:** Attach the “Adversarial access tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “A forbidden file read succeeds despite a configured deny rule” as a distinct evidence case.
- [ ] **UC-M03.03-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Adversarial access tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C090-T05 · Environment record:** Record the actual “Adversarial access tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C090-T06 · Expected versus observed:** Pair every “Adversarial access tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C090-T07 · Failure and limit records:** Attach “Adversarial access tests” change/failure and bounds evidence where required; include uncovered “Probe runtime and test-environment resource budget” and unresolved violations of “Tests show actual denial rather than declared policy intent”.
- [ ] **UC-M03.03-C090-T08 · Evidence hygiene:** Check the “Adversarial access tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C090-T09 · Reproduction review:** Have the “Adversarial access tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C090-T10 · Acceptance linkage:** Link the “Adversarial access tests” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Effective policy evidence

**Source delivery:** Record effective identity, filesystem, syscall and device restrictions.

**Source invariant:** The evidence describes observed host enforcement for this instance.

**Source negative case:** Only the requested policy is recorded while actual setup differs.

**Source bounded quantities:** Evidence fields and maximum observation age.

### UC-M03.03-C091 · Contract

**Original checklist item:** Specify effective policy evidence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.03-C091-T01 · Scope statement:** Draft the operation boundary for “Effective policy evidence” within Host process sandbox profile; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.03-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Effective policy evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.03-C091-T03 · Output inventory:** List the outputs of “Effective policy evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.03-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Effective policy evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.03-C091-T05 · Prerequisite contract:** Map “Effective policy evidence” to the source component prerequisites (UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.03-C091-T06 · Authority map:** Identify who may produce, change and consume “Effective policy evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.03-C091-T07 · Invariant clause:** Add a normative clause for “Effective policy evidence” that preserves “The evidence describes observed host enforcement for this instance”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.03-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Effective policy evidence”; include the source counterexample “Only the requested policy is recorded while actual setup differs” and the intended safe disposition.
- [ ] **UC-M03.03-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence fields and maximum observation age” in the “Effective policy evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.03-C091-T10 · Contract review:** Review the “Effective policy evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.03-C092 · Delivery

**Original checklist item:** Record effective identity, filesystem, syscall and device restrictions.

- [ ] **UC-M03.03-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Effective policy evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.03-C092-T02 · Change plan:** Break the source delivery for “Effective policy evidence” into concrete edit targets and reviewable outputs; keep the UC-M03.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.03-C092-T03 · Core artifact:** Create the “Effective policy evidence” model, schema or inventory that realizes this source instruction: Record effective identity, filesystem, syscall and device restrictions.
- [ ] **UC-M03.03-C092-T04 · Concrete realization:** Populate “Effective policy evidence” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.03-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Effective policy evidence” needed to preserve “The evidence describes observed host enforcement for this instance”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.03-C092-T06 · Dependency connection:** Connect the “Effective policy evidence” implementation to backend launch, host identity controls and allowed resource views; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.03-C092-T07 · Resource behavior:** Account for “Evidence fields and maximum observation age” in “Effective policy evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.03-C092-T08 · Delivery check:** Run the smallest real “Effective policy evidence” path and its adverse fixture “Only the requested policy is recorded while actual setup differs”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.03-C092-T09 · Patch review:** Review the “Effective policy evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.03-C092-T10 · Delivery handoff:** Publish the “Effective policy evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.03-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The evidence describes observed host enforcement for this instance. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.03-C093-T01 · Named property:** Create a stable property/check name under this parent for “Effective policy evidence”; copy its required invariant exactly: “The evidence describes observed host enforcement for this instance”.
- [ ] **UC-M03.03-C093-T02 · Observable terms:** Define each term in the “Effective policy evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.03-C093-T03 · Precondition set:** List the preconditions under which “The evidence describes observed host enforcement for this instance” must hold for “Effective policy evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.03-C093-T04 · Transition coverage:** Map the “Effective policy evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.03-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Effective policy evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.03-C093-T06 · Satisfying fixture:** Create a concrete “Effective policy evidence” case that satisfies “The evidence describes observed host enforcement for this instance”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.03-C093-T07 · Violating fixture:** Create the source counterexample “Only the requested policy is recorded while actual setup differs” for “Effective policy evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.03-C093-T08 · Enforcement evidence:** Exercise the “Effective policy evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.03-C093-T09 · Regression linkage:** Link the “Effective policy evidence” property to changes in backend launch, host identity controls and allowed resource views; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.03-C093-T10 · Property disposition:** Compare the satisfying and violating “Effective policy evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.03-C094 · Integration

**Original checklist item:** Integrate effective policy evidence with backend launch, host identity controls and allowed resource views; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.03-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Effective policy evidence” across backend launch, host identity controls and allowed resource views; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.03-C094-T02 · Field mapping:** Map every “Effective policy evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.03-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Effective policy evidence” (source dependency list: UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.03-C094-T04 · Ownership agreement:** Specify who owns “Effective policy evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.03-C094-T05 · Handoff implementation:** Connect “Effective policy evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “The evidence describes observed host enforcement for this instance” across the handoff.
- [ ] **UC-M03.03-C094-T06 · Absent-input case:** Omit one required “Effective policy evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.03-C094-T07 · Stale-input case:** Supply an outdated “Effective policy evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.03-C094-T08 · Incompatible-input case:** Supply an incompatible “Effective policy evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.03-C094-T09 · Valid integration trace:** Run a valid “Effective policy evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.03-C094-T10 · Seam review:** Reconcile the “Effective policy evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.03-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for effective policy evidence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.03-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Effective policy evidence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.03-C095-T02 · Expected-result oracle:** Specify the “Effective policy evidence” expected result independently of the implementation output; include the property “The evidence describes observed host enforcement for this instance” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.03-C095-T03 · Fixture material:** Create the concrete “Effective policy evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.03-C095-T04 · Target preparation:** Prepare the “Effective policy evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.03-C095-T05 · Initial-state record:** Record the initial “Effective policy evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.03-C095-T06 · Valid-path execution:** Execute the “Effective policy evidence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.03-C095-T07 · Outcome comparison:** Compare every declared “Effective policy evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.03-C095-T08 · State and bounds check:** Inspect the “Effective policy evidence” ownership/state effects and actual use of “Evidence fields and maximum observation age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.03-C095-T09 · Repeatability check:** Repeat the same “Effective policy evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.03-C095-T10 · Positive evidence:** Attach the “Effective policy evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.03-C096 · Negative test

**Original checklist item:** Negative case: Only the requested policy is recorded while actual setup differs. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.03-C096-T01 · Adverse-case definition:** Create a test record for the exact “Effective policy evidence” source counterexample: “Only the requested policy is recorded while actual setup differs”; state which precondition or invariant it challenges.
- [ ] **UC-M03.03-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Effective policy evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.03-C096-T03 · Valid control:** Construct a valid “Effective policy evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.03-C096-T04 · Minimal adverse input:** Derive the “Effective policy evidence” adverse fixture from the control with the smallest documented change needed to reproduce “Only the requested policy is recorded while actual setup differs”; retain that change as reproducible data.
- [ ] **UC-M03.03-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Effective policy evidence”; require “The evidence describes observed host enforcement for this instance” and forbid a false-success verdict.
- [ ] **UC-M03.03-C096-T06 · Adverse execution:** Exercise the “Effective policy evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.03-C096-T07 · Effect inspection:** Inspect “Effective policy evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.03-C096-T08 · Refusal versus failure:** Confirm the “Effective policy evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.03-C096-T09 · Reset and retention:** Restore only the disposable “Effective policy evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.03-C096-T10 · Negative regression:** Register the “Effective policy evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.03-C097 · Change / failure test

**Original checklist item:** Exercise effective policy evidence when sandbox setup fails partway through preparing a guest instance; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.03-C097-T01 · Scenario record:** Write the “Effective policy evidence” change/failure scenario exactly as supplied: sandbox setup fails partway through preparing a guest instance; identify the property that must remain true: “The evidence describes observed host enforcement for this instance”.
- [ ] **UC-M03.03-C097-T02 · Baseline capture:** Create a known-valid “Effective policy evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.03-C097-T03 · Injection map:** Locate the “Effective policy evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.03-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Effective policy evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.03-C097-T05 · Controlled trigger:** Introduce the controlled “Effective policy evidence” scenario in the disposable fixture: sandbox setup fails partway through preparing a guest instance; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.03-C097-T06 · Intermediate inspection:** Inspect the “Effective policy evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.03-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Effective policy evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.03-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Effective policy evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.03-C097-T09 · Repeat and compare:** Repeat the selected “Effective policy evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.03-C097-T10 · Failure evidence:** Publish the “Effective policy evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.03-C098 · Bounds

**Original checklist item:** Choose, document and test limits for evidence fields and maximum observation age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.03-C098-T01 · Quantity inventory:** Create a measurement inventory for “Effective policy evidence”: “Evidence fields and maximum observation age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.03-C098-T02 · Measurement method:** Choose how to observe each “Effective policy evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.03-C098-T03 · Budget decision:** Select justified resource and input limits for “Effective policy evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.03-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Effective policy evidence” cases for “Evidence fields and maximum observation age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.03-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Effective policy evidence” limit; preserve “The evidence describes observed host enforcement for this instance”.
- [ ] **UC-M03.03-C098-T06 · Normal measurement:** Run or review the normal “Effective policy evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.03-C098-T07 · At-limit measurement:** Exercise the “Effective policy evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.03-C098-T08 · Over-limit measurement:** Exercise the “Effective policy evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.03-C098-T09 · Uncovered-scope report:** List the “Effective policy evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.03-C098-T10 · Limit evidence:** Publish the selected “Effective policy evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.03-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for effective policy evidence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.03-C099-T01 · Event inventory:** List the “Effective policy evidence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.03-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Effective policy evidence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.03-C099-T03 · Failure mapping:** Map each documented “Effective policy evidence” refusal or error to a diagnostic outcome; include “Only the requested policy is recorded while actual setup differs” and prohibit conversion into a success message.
- [ ] **UC-M03.03-C099-T04 · Emission path:** Add the “Effective policy evidence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.03-C099-T05 · Redaction check:** Test “Effective policy evidence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.03-C099-T06 · Output budget:** Set and exercise bounded “Effective policy evidence” message size, rate and retention compatible with “Evidence fields and maximum observation age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.03-C099-T07 · Success/refusal fixtures:** Capture “Effective policy evidence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.03-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Effective policy evidence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.03-C099-T09 · Operator review:** Read the “Effective policy evidence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.03-C099-T10 · Diagnostic evidence:** Publish redacted “Effective policy evidence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.03-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for effective policy evidence; label unexecuted checks as untested.

- [ ] **UC-M03.03-C100-T01 · Evidence inventory:** List the “Effective policy evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.03-C100-T02 · Artifact references:** Record the exact “Effective policy evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.03-C100-T03 · Fixture references:** Attach the “Effective policy evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only the requested policy is recorded while actual setup differs” as a distinct evidence case.
- [ ] **UC-M03.03-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Effective policy evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.03-C100-T05 · Environment record:** Record the actual “Effective policy evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.03-C100-T06 · Expected versus observed:** Pair every “Effective policy evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.03-C100-T07 · Failure and limit records:** Attach “Effective policy evidence” change/failure and bounds evidence where required; include uncovered “Evidence fields and maximum observation age” and unresolved violations of “The evidence describes observed host enforcement for this instance”.
- [ ] **UC-M03.03-C100-T08 · Evidence hygiene:** Check the “Effective policy evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.03-C100-T09 · Reproduction review:** Have the “Effective policy evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.03-C100-T10 · Acceptance linkage:** Link the “Effective policy evidence” evidence to its parent and UC-M03.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

