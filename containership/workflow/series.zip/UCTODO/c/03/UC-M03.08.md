# UC-M03.08 — Host capability and isolation evidence

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/03.md)

| Field | Preserved source value |
|---|---|
| Workstream | 03. Host isolation and supervision |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M03.02](../03/UC-M03.02.md), [UC-M03.04](../03/UC-M03.04.md), [UC-M03.05](../03/UC-M03.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S3], [S4]. |

## Original requirement

Expand doctor from informational checks to exercised backend capability probes, patch policy and immutable run-time evidence.

**Original acceptance criterion:** Admission records the selected backend and verified constraints; unavailable virtualization blocks rather than degrades security.

**Source trace:** Original checklist `UC100/c/03/UC-M03.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 316–327 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Capability probe inventory

**Source delivery:** List required virtualization, device, resource and sandbox capabilities per profile.

**Source invariant:** Required capabilities have exercised probes rather than only version checks.

**Source negative case:** Doctor reports virtualization available without creating a test instance.

**Source bounded quantities:** Probe count and per-probe deadline.

### UC-M03.08-C001 · Contract

**Original checklist item:** Define the qualification objective for capability probe inventory, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C001-T01 · Scope statement:** Write the qualification question for “Capability probe inventory”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capability probe inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C001-T03 · Output inventory:** List the outputs of “Capability probe inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Capability probe inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C001-T05 · Prerequisite contract:** Map “Capability probe inventory” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C001-T06 · Authority map:** Identify who may produce, change and consume “Capability probe inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C001-T07 · Invariant clause:** Add a normative clause for “Capability probe inventory” that preserves “Required capabilities have exercised probes rather than only version checks”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capability probe inventory”; include the source counterexample “Doctor reports virtualization available without creating a test instance” and the intended safe disposition.
- [ ] **UC-M03.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe count and per-probe deadline” in the “Capability probe inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C001-T10 · Contract review:** Review the “Capability probe inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C002 · Delivery

**Original checklist item:** List required virtualization, device, resource and sandbox capabilities per profile.

- [ ] **UC-M03.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capability probe inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C002-T02 · Change plan:** Break the source delivery for “Capability probe inventory” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C002-T03 · Core artifact:** Create the “Capability probe inventory” model, schema or inventory that realizes this source instruction: List required virtualization, device, resource and sandbox capabilities per profile.
- [ ] **UC-M03.08-C002-T04 · Concrete realization:** Populate “Capability probe inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capability probe inventory” needed to preserve “Required capabilities have exercised probes rather than only version checks”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C002-T06 · Dependency connection:** Connect the “Capability probe inventory” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C002-T07 · Resource behavior:** Account for “Probe count and per-probe deadline” in “Capability probe inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Capability probe inventory”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C002-T09 · Patch review:** Review the “Capability probe inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C002-T10 · Delivery handoff:** Publish the “Capability probe inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Required capabilities have exercised probes rather than only version checks. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “Capability probe inventory”; copy its required invariant exactly: “Required capabilities have exercised probes rather than only version checks”.
- [ ] **UC-M03.08-C003-T02 · Observable terms:** Define each term in the “Capability probe inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C003-T03 · Precondition set:** List the preconditions under which “Required capabilities have exercised probes rather than only version checks” must hold for “Capability probe inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C003-T04 · Transition coverage:** Map the “Capability probe inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capability probe inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C003-T06 · Satisfying fixture:** Create a concrete “Capability probe inventory” case that satisfies “Required capabilities have exercised probes rather than only version checks”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C003-T07 · Violating fixture:** Create the source counterexample “Doctor reports virtualization available without creating a test instance” for “Capability probe inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C003-T08 · Enforcement evidence:** Exercise the “Capability probe inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C003-T09 · Regression linkage:** Link the “Capability probe inventory” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C003-T10 · Property disposition:** Compare the satisfying and violating “Capability probe inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C004 · Integration

**Original checklist item:** Integrate capability probe inventory with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capability probe inventory” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C004-T02 · Field mapping:** Map every “Capability probe inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Capability probe inventory” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C004-T04 · Ownership agreement:** Specify who owns “Capability probe inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C004-T05 · Handoff implementation:** Connect “Capability probe inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Required capabilities have exercised probes rather than only version checks” across the handoff.
- [ ] **UC-M03.08-C004-T06 · Absent-input case:** Omit one required “Capability probe inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C004-T07 · Stale-input case:** Supply an outdated “Capability probe inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C004-T08 · Incompatible-input case:** Supply an incompatible “Capability probe inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C004-T09 · Valid integration trace:** Run a valid “Capability probe inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C004-T10 · Seam review:** Reconcile the “Capability probe inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for capability probe inventory; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Capability probe inventory”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C005-T02 · Expected-result oracle:** Specify the “Capability probe inventory” expected result independently of the implementation output; include the property “Required capabilities have exercised probes rather than only version checks” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C005-T03 · Fixture material:** Create the concrete “Capability probe inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C005-T04 · Target preparation:** Prepare the “Capability probe inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C005-T05 · Initial-state record:** Record the initial “Capability probe inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C005-T06 · Valid-path execution:** Run the “Capability probe inventory” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C005-T07 · Outcome comparison:** Compare every declared “Capability probe inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C005-T08 · State and bounds check:** Inspect the “Capability probe inventory” ownership/state effects and actual use of “Probe count and per-probe deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C005-T09 · Repeatability check:** Repeat the same “Capability probe inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C005-T10 · Positive evidence:** Attach the “Capability probe inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C006 · Negative test

**Original checklist item:** Negative case: Doctor reports virtualization available without creating a test instance. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “Capability probe inventory” source counterexample: “Doctor reports virtualization available without creating a test instance”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Capability probe inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C006-T03 · Valid control:** Construct a valid “Capability probe inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C006-T04 · Minimal adverse input:** Derive the “Capability probe inventory” adverse fixture from the control with the smallest documented change needed to reproduce “Doctor reports virtualization available without creating a test instance”; retain that change as reproducible data.
- [ ] **UC-M03.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capability probe inventory”; require “Required capabilities have exercised probes rather than only version checks” and forbid a false-success verdict.
- [ ] **UC-M03.08-C006-T06 · Adverse execution:** Exercise the “Capability probe inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C006-T07 · Effect inspection:** Inspect “Capability probe inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C006-T08 · Refusal versus failure:** Confirm the “Capability probe inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C006-T09 · Reset and retention:** Restore only the disposable “Capability probe inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C006-T10 · Negative regression:** Register the “Capability probe inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C007 · Change / failure test

**Original checklist item:** Exercise capability probe inventory when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C007-T01 · Scenario record:** Write the “Capability probe inventory” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “Required capabilities have exercised probes rather than only version checks”.
- [ ] **UC-M03.08-C007-T02 · Baseline capture:** Create a known-valid “Capability probe inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C007-T03 · Injection map:** Locate the “Capability probe inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Capability probe inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C007-T05 · Controlled trigger:** Introduce the controlled “Capability probe inventory” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C007-T06 · Intermediate inspection:** Inspect the “Capability probe inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capability probe inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Capability probe inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C007-T09 · Repeat and compare:** Repeat the selected “Capability probe inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C007-T10 · Failure evidence:** Publish the “Capability probe inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for probe count and per-probe deadline; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “Capability probe inventory”: “Probe count and per-probe deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C008-T02 · Measurement method:** Choose how to observe each “Capability probe inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Capability probe inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capability probe inventory” cases for “Probe count and per-probe deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capability probe inventory” limit; preserve “Required capabilities have exercised probes rather than only version checks”.
- [ ] **UC-M03.08-C008-T06 · Normal measurement:** Run or review the normal “Capability probe inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C008-T07 · At-limit measurement:** Exercise the “Capability probe inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C008-T08 · Over-limit measurement:** Exercise the “Capability probe inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C008-T09 · Uncovered-scope report:** List the “Capability probe inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C008-T10 · Limit evidence:** Publish the selected “Capability probe inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C009 · Diagnostics / review

**Original checklist item:** Report capability probe inventory results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C009-T01 · Result inventory:** Enumerate the required “Capability probe inventory” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Capability probe inventory”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Capability probe inventory” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C009-T04 · Observation capture:** Capture bounded raw “Capability probe inventory” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C009-T05 · Aggregation rules:** Implement the “Capability probe inventory” count/reduction rule so failures and missing measurements cannot disappear; preserve “Required capabilities have exercised probes rather than only version checks”.
- [ ] **UC-M03.08-C009-T06 · Failure visibility:** Feed a failing “Capability probe inventory” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C009-T07 · Missing-result visibility:** Withhold a required “Capability probe inventory” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C009-T08 · Bounds and redaction:** Check “Capability probe inventory” report size and retention against “Probe count and per-probe deadline”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C009-T09 · Report reconciliation:** Reconcile the “Capability probe inventory” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C009-T10 · Qualification handoff:** Publish the “Capability probe inventory” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capability probe inventory; label unexecuted checks as untested.

- [ ] **UC-M03.08-C010-T01 · Evidence inventory:** List the “Capability probe inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C010-T02 · Artifact references:** Record the exact “Capability probe inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C010-T03 · Fixture references:** Attach the “Capability probe inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “Doctor reports virtualization available without creating a test instance” as a distinct evidence case.
- [ ] **UC-M03.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capability probe inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C010-T05 · Environment record:** Record the actual “Capability probe inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C010-T06 · Expected versus observed:** Pair every “Capability probe inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C010-T07 · Failure and limit records:** Attach “Capability probe inventory” change/failure and bounds evidence where required; include uncovered “Probe count and per-probe deadline” and unresolved violations of “Required capabilities have exercised probes rather than only version checks”.
- [ ] **UC-M03.08-C010-T08 · Evidence hygiene:** Check the “Capability probe inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C010-T09 · Reproduction review:** Have the “Capability probe inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C010-T10 · Acceptance linkage:** Link the “Capability probe inventory” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Virtualization availability

**Source delivery:** Exercise the selected backend's required virtualization or tender path.

**Source invariant:** Unavailable required virtualization blocks isolated admission.

**Source negative case:** The host lacks virtualization but the ship silently uses a process adapter.

**Source bounded quantities:** Probe memory and temporary instances.

### UC-M03.08-C011 · Contract

**Original checklist item:** Define the qualification objective for virtualization availability, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C011-T01 · Scope statement:** Write the qualification question for “Virtualization availability”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Virtualization availability”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C011-T03 · Output inventory:** List the outputs of “Virtualization availability” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Virtualization availability”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C011-T05 · Prerequisite contract:** Map “Virtualization availability” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Virtualization availability”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C011-T07 · Invariant clause:** Add a normative clause for “Virtualization availability” that preserves “Unavailable required virtualization blocks isolated admission”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Virtualization availability”; include the source counterexample “The host lacks virtualization but the ship silently uses a process adapter” and the intended safe disposition.
- [ ] **UC-M03.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe memory and temporary instances” in the “Virtualization availability” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C011-T10 · Contract review:** Review the “Virtualization availability” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C012 · Delivery

**Original checklist item:** Exercise the selected backend's required virtualization or tender path.

- [ ] **UC-M03.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Virtualization availability”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C012-T02 · Change plan:** Break the source delivery for “Virtualization availability” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C012-T03 · Core artifact:** Create the “Virtualization availability” fixture or harness for this source instruction: Exercise the selected backend's required virtualization or tender path.
- [ ] **UC-M03.08-C012-T04 · Concrete realization:** Connect the “Virtualization availability” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Virtualization availability” needed to preserve “Unavailable required virtualization blocks isolated admission”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C012-T06 · Dependency connection:** Connect the “Virtualization availability” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C012-T07 · Resource behavior:** Account for “Probe memory and temporary instances” in “Virtualization availability”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Virtualization availability”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C012-T09 · Patch review:** Review the “Virtualization availability” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C012-T10 · Delivery handoff:** Publish the “Virtualization availability” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unavailable required virtualization blocks isolated admission. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Virtualization availability”; copy its required invariant exactly: “Unavailable required virtualization blocks isolated admission”.
- [ ] **UC-M03.08-C013-T02 · Observable terms:** Define each term in the “Virtualization availability” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C013-T03 · Precondition set:** List the preconditions under which “Unavailable required virtualization blocks isolated admission” must hold for “Virtualization availability”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C013-T04 · Transition coverage:** Map the “Virtualization availability” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Virtualization availability”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C013-T06 · Satisfying fixture:** Create a concrete “Virtualization availability” case that satisfies “Unavailable required virtualization blocks isolated admission”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C013-T07 · Violating fixture:** Create the source counterexample “The host lacks virtualization but the ship silently uses a process adapter” for “Virtualization availability”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C013-T08 · Enforcement evidence:** Exercise the “Virtualization availability” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C013-T09 · Regression linkage:** Link the “Virtualization availability” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Virtualization availability” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C014 · Integration

**Original checklist item:** Integrate virtualization availability with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Virtualization availability” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C014-T02 · Field mapping:** Map every “Virtualization availability” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Virtualization availability” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C014-T04 · Ownership agreement:** Specify who owns “Virtualization availability” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C014-T05 · Handoff implementation:** Connect “Virtualization availability” through the mapped seam using the real adapter or explicit specification reference; preserve “Unavailable required virtualization blocks isolated admission” across the handoff.
- [ ] **UC-M03.08-C014-T06 · Absent-input case:** Omit one required “Virtualization availability” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C014-T07 · Stale-input case:** Supply an outdated “Virtualization availability” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Virtualization availability” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C014-T09 · Valid integration trace:** Run a valid “Virtualization availability” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C014-T10 · Seam review:** Reconcile the “Virtualization availability” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for virtualization availability; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Virtualization availability”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C015-T02 · Expected-result oracle:** Specify the “Virtualization availability” expected result independently of the implementation output; include the property “Unavailable required virtualization blocks isolated admission” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C015-T03 · Fixture material:** Create the concrete “Virtualization availability” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C015-T04 · Target preparation:** Prepare the “Virtualization availability” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C015-T05 · Initial-state record:** Record the initial “Virtualization availability” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C015-T06 · Valid-path execution:** Run the “Virtualization availability” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C015-T07 · Outcome comparison:** Compare every declared “Virtualization availability” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C015-T08 · State and bounds check:** Inspect the “Virtualization availability” ownership/state effects and actual use of “Probe memory and temporary instances”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C015-T09 · Repeatability check:** Repeat the same “Virtualization availability” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C015-T10 · Positive evidence:** Attach the “Virtualization availability” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C016 · Negative test

**Original checklist item:** Negative case: The host lacks virtualization but the ship silently uses a process adapter. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Virtualization availability” source counterexample: “The host lacks virtualization but the ship silently uses a process adapter”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Virtualization availability”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C016-T03 · Valid control:** Construct a valid “Virtualization availability” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C016-T04 · Minimal adverse input:** Derive the “Virtualization availability” adverse fixture from the control with the smallest documented change needed to reproduce “The host lacks virtualization but the ship silently uses a process adapter”; retain that change as reproducible data.
- [ ] **UC-M03.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Virtualization availability”; require “Unavailable required virtualization blocks isolated admission” and forbid a false-success verdict.
- [ ] **UC-M03.08-C016-T06 · Adverse execution:** Exercise the “Virtualization availability” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C016-T07 · Effect inspection:** Inspect “Virtualization availability” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C016-T08 · Refusal versus failure:** Confirm the “Virtualization availability” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C016-T09 · Reset and retention:** Restore only the disposable “Virtualization availability” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C016-T10 · Negative regression:** Register the “Virtualization availability” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C017 · Change / failure test

**Original checklist item:** Exercise virtualization availability when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C017-T01 · Scenario record:** Write the “Virtualization availability” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “Unavailable required virtualization blocks isolated admission”.
- [ ] **UC-M03.08-C017-T02 · Baseline capture:** Create a known-valid “Virtualization availability” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C017-T03 · Injection map:** Locate the “Virtualization availability” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Virtualization availability” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C017-T05 · Controlled trigger:** Introduce the controlled “Virtualization availability” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C017-T06 · Intermediate inspection:** Inspect the “Virtualization availability” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Virtualization availability”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Virtualization availability” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C017-T09 · Repeat and compare:** Repeat the selected “Virtualization availability” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C017-T10 · Failure evidence:** Publish the “Virtualization availability” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for probe memory and temporary instances; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Virtualization availability”: “Probe memory and temporary instances”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C018-T02 · Measurement method:** Choose how to observe each “Virtualization availability” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Virtualization availability”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Virtualization availability” cases for “Probe memory and temporary instances”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Virtualization availability” limit; preserve “Unavailable required virtualization blocks isolated admission”.
- [ ] **UC-M03.08-C018-T06 · Normal measurement:** Run or review the normal “Virtualization availability” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C018-T07 · At-limit measurement:** Exercise the “Virtualization availability” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C018-T08 · Over-limit measurement:** Exercise the “Virtualization availability” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C018-T09 · Uncovered-scope report:** List the “Virtualization availability” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C018-T10 · Limit evidence:** Publish the selected “Virtualization availability” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C019 · Diagnostics / review

**Original checklist item:** Report virtualization availability results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C019-T01 · Result inventory:** Enumerate the required “Virtualization availability” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Virtualization availability”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Virtualization availability” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C019-T04 · Observation capture:** Capture bounded raw “Virtualization availability” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C019-T05 · Aggregation rules:** Implement the “Virtualization availability” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unavailable required virtualization blocks isolated admission”.
- [ ] **UC-M03.08-C019-T06 · Failure visibility:** Feed a failing “Virtualization availability” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C019-T07 · Missing-result visibility:** Withhold a required “Virtualization availability” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C019-T08 · Bounds and redaction:** Check “Virtualization availability” report size and retention against “Probe memory and temporary instances”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C019-T09 · Report reconciliation:** Reconcile the “Virtualization availability” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C019-T10 · Qualification handoff:** Publish the “Virtualization availability” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for virtualization availability; label unexecuted checks as untested.

- [ ] **UC-M03.08-C020-T01 · Evidence inventory:** List the “Virtualization availability” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C020-T02 · Artifact references:** Record the exact “Virtualization availability” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C020-T03 · Fixture references:** Attach the “Virtualization availability” fixture IDs, input identities and oracle definition; preserve the source counterexample “The host lacks virtualization but the ship silently uses a process adapter” as a distinct evidence case.
- [ ] **UC-M03.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Virtualization availability”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C020-T05 · Environment record:** Record the actual “Virtualization availability” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C020-T06 · Expected versus observed:** Pair every “Virtualization availability” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C020-T07 · Failure and limit records:** Attach “Virtualization availability” change/failure and bounds evidence where required; include uncovered “Probe memory and temporary instances” and unresolved violations of “Unavailable required virtualization blocks isolated admission”.
- [ ] **UC-M03.08-C020-T08 · Evidence hygiene:** Check the “Virtualization availability” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C020-T09 · Reproduction review:** Have the “Virtualization availability” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C020-T10 · Acceptance linkage:** Link the “Virtualization availability” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Resource-control probes

**Source delivery:** Verify that required CPU, memory and process restrictions take effect.

**Source invariant:** A supported API name alone does not establish effective quotas.

**Source negative case:** A quota-setting call succeeds but the limit is not applied.

**Source bounded quantities:** Probe workload size and measurement duration.

### UC-M03.08-C021 · Contract

**Original checklist item:** Define the qualification objective for resource-control probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C021-T01 · Scope statement:** Write the qualification question for “Resource-control probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource-control probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C021-T03 · Output inventory:** List the outputs of “Resource-control probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource-control probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C021-T05 · Prerequisite contract:** Map “Resource-control probes” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Resource-control probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C021-T07 · Invariant clause:** Add a normative clause for “Resource-control probes” that preserves “A supported API name alone does not establish effective quotas”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource-control probes”; include the source counterexample “A quota-setting call succeeds but the limit is not applied” and the intended safe disposition.
- [ ] **UC-M03.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe workload size and measurement duration” in the “Resource-control probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C021-T10 · Contract review:** Review the “Resource-control probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C022 · Delivery

**Original checklist item:** Verify that required CPU, memory and process restrictions take effect.

- [ ] **UC-M03.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource-control probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C022-T02 · Change plan:** Break the source delivery for “Resource-control probes” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C022-T03 · Core artifact:** Create the “Resource-control probes” fixture or harness for this source instruction: Verify that required CPU, memory and process restrictions take effect.
- [ ] **UC-M03.08-C022-T04 · Concrete realization:** Connect the “Resource-control probes” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource-control probes” needed to preserve “A supported API name alone does not establish effective quotas”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C022-T06 · Dependency connection:** Connect the “Resource-control probes” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C022-T07 · Resource behavior:** Account for “Probe workload size and measurement duration” in “Resource-control probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Resource-control probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C022-T09 · Patch review:** Review the “Resource-control probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C022-T10 · Delivery handoff:** Publish the “Resource-control probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A supported API name alone does not establish effective quotas. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Resource-control probes”; copy its required invariant exactly: “A supported API name alone does not establish effective quotas”.
- [ ] **UC-M03.08-C023-T02 · Observable terms:** Define each term in the “Resource-control probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C023-T03 · Precondition set:** List the preconditions under which “A supported API name alone does not establish effective quotas” must hold for “Resource-control probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C023-T04 · Transition coverage:** Map the “Resource-control probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource-control probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C023-T06 · Satisfying fixture:** Create a concrete “Resource-control probes” case that satisfies “A supported API name alone does not establish effective quotas”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C023-T07 · Violating fixture:** Create the source counterexample “A quota-setting call succeeds but the limit is not applied” for “Resource-control probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C023-T08 · Enforcement evidence:** Exercise the “Resource-control probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C023-T09 · Regression linkage:** Link the “Resource-control probes” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Resource-control probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C024 · Integration

**Original checklist item:** Integrate resource-control probes with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource-control probes” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C024-T02 · Field mapping:** Map every “Resource-control probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource-control probes” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C024-T04 · Ownership agreement:** Specify who owns “Resource-control probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C024-T05 · Handoff implementation:** Connect “Resource-control probes” through the mapped seam using the real adapter or explicit specification reference; preserve “A supported API name alone does not establish effective quotas” across the handoff.
- [ ] **UC-M03.08-C024-T06 · Absent-input case:** Omit one required “Resource-control probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C024-T07 · Stale-input case:** Supply an outdated “Resource-control probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Resource-control probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C024-T09 · Valid integration trace:** Run a valid “Resource-control probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C024-T10 · Seam review:** Reconcile the “Resource-control probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for resource-control probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Resource-control probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C025-T02 · Expected-result oracle:** Specify the “Resource-control probes” expected result independently of the implementation output; include the property “A supported API name alone does not establish effective quotas” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C025-T03 · Fixture material:** Create the concrete “Resource-control probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C025-T04 · Target preparation:** Prepare the “Resource-control probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C025-T05 · Initial-state record:** Record the initial “Resource-control probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C025-T06 · Valid-path execution:** Run the “Resource-control probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C025-T07 · Outcome comparison:** Compare every declared “Resource-control probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C025-T08 · State and bounds check:** Inspect the “Resource-control probes” ownership/state effects and actual use of “Probe workload size and measurement duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C025-T09 · Repeatability check:** Repeat the same “Resource-control probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C025-T10 · Positive evidence:** Attach the “Resource-control probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C026 · Negative test

**Original checklist item:** Negative case: A quota-setting call succeeds but the limit is not applied. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Resource-control probes” source counterexample: “A quota-setting call succeeds but the limit is not applied”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource-control probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C026-T03 · Valid control:** Construct a valid “Resource-control probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C026-T04 · Minimal adverse input:** Derive the “Resource-control probes” adverse fixture from the control with the smallest documented change needed to reproduce “A quota-setting call succeeds but the limit is not applied”; retain that change as reproducible data.
- [ ] **UC-M03.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource-control probes”; require “A supported API name alone does not establish effective quotas” and forbid a false-success verdict.
- [ ] **UC-M03.08-C026-T06 · Adverse execution:** Exercise the “Resource-control probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C026-T07 · Effect inspection:** Inspect “Resource-control probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C026-T08 · Refusal versus failure:** Confirm the “Resource-control probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C026-T09 · Reset and retention:** Restore only the disposable “Resource-control probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C026-T10 · Negative regression:** Register the “Resource-control probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C027 · Change / failure test

**Original checklist item:** Exercise resource-control probes when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C027-T01 · Scenario record:** Write the “Resource-control probes” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “A supported API name alone does not establish effective quotas”.
- [ ] **UC-M03.08-C027-T02 · Baseline capture:** Create a known-valid “Resource-control probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C027-T03 · Injection map:** Locate the “Resource-control probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Resource-control probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C027-T05 · Controlled trigger:** Introduce the controlled “Resource-control probes” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C027-T06 · Intermediate inspection:** Inspect the “Resource-control probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource-control probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource-control probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C027-T09 · Repeat and compare:** Repeat the selected “Resource-control probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C027-T10 · Failure evidence:** Publish the “Resource-control probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for probe workload size and measurement duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Resource-control probes”: “Probe workload size and measurement duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C028-T02 · Measurement method:** Choose how to observe each “Resource-control probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Resource-control probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource-control probes” cases for “Probe workload size and measurement duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource-control probes” limit; preserve “A supported API name alone does not establish effective quotas”.
- [ ] **UC-M03.08-C028-T06 · Normal measurement:** Run or review the normal “Resource-control probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C028-T07 · At-limit measurement:** Exercise the “Resource-control probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C028-T08 · Over-limit measurement:** Exercise the “Resource-control probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C028-T09 · Uncovered-scope report:** List the “Resource-control probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C028-T10 · Limit evidence:** Publish the selected “Resource-control probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C029 · Diagnostics / review

**Original checklist item:** Report resource-control probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C029-T01 · Result inventory:** Enumerate the required “Resource-control probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Resource-control probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Resource-control probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C029-T04 · Observation capture:** Capture bounded raw “Resource-control probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C029-T05 · Aggregation rules:** Implement the “Resource-control probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “A supported API name alone does not establish effective quotas”.
- [ ] **UC-M03.08-C029-T06 · Failure visibility:** Feed a failing “Resource-control probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C029-T07 · Missing-result visibility:** Withhold a required “Resource-control probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C029-T08 · Bounds and redaction:** Check “Resource-control probes” report size and retention against “Probe workload size and measurement duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C029-T09 · Report reconciliation:** Reconcile the “Resource-control probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C029-T10 · Qualification handoff:** Publish the “Resource-control probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource-control probes; label unexecuted checks as untested.

- [ ] **UC-M03.08-C030-T01 · Evidence inventory:** List the “Resource-control probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C030-T02 · Artifact references:** Record the exact “Resource-control probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C030-T03 · Fixture references:** Attach the “Resource-control probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A quota-setting call succeeds but the limit is not applied” as a distinct evidence case.
- [ ] **UC-M03.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource-control probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C030-T05 · Environment record:** Record the actual “Resource-control probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C030-T06 · Expected versus observed:** Pair every “Resource-control probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C030-T07 · Failure and limit records:** Attach “Resource-control probes” change/failure and bounds evidence where required; include uncovered “Probe workload size and measurement duration” and unresolved violations of “A supported API name alone does not establish effective quotas”.
- [ ] **UC-M03.08-C030-T08 · Evidence hygiene:** Check the “Resource-control probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C030-T09 · Reproduction review:** Have the “Resource-control probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C030-T10 · Acceptance linkage:** Link the “Resource-control probes” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Network-policy probes

**Source delivery:** Exercise device absence or filter behavior for the selected profile.

**Source invariant:** Recorded network constraints reflect observed connectivity.

**Source negative case:** A configured deny policy still allows guest egress.

**Source bounded quantities:** Traffic volume and probe timeout.

### UC-M03.08-C031 · Contract

**Original checklist item:** Define the qualification objective for network-policy probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C031-T01 · Scope statement:** Write the qualification question for “Network-policy probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Network-policy probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C031-T03 · Output inventory:** List the outputs of “Network-policy probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Network-policy probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C031-T05 · Prerequisite contract:** Map “Network-policy probes” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Network-policy probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C031-T07 · Invariant clause:** Add a normative clause for “Network-policy probes” that preserves “Recorded network constraints reflect observed connectivity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Network-policy probes”; include the source counterexample “A configured deny policy still allows guest egress” and the intended safe disposition.
- [ ] **UC-M03.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Traffic volume and probe timeout” in the “Network-policy probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C031-T10 · Contract review:** Review the “Network-policy probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C032 · Delivery

**Original checklist item:** Exercise device absence or filter behavior for the selected profile.

- [ ] **UC-M03.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Network-policy probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C032-T02 · Change plan:** Break the source delivery for “Network-policy probes” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C032-T03 · Core artifact:** Create the “Network-policy probes” fixture or harness for this source instruction: Exercise device absence or filter behavior for the selected profile.
- [ ] **UC-M03.08-C032-T04 · Concrete realization:** Connect the “Network-policy probes” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Network-policy probes” needed to preserve “Recorded network constraints reflect observed connectivity”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C032-T06 · Dependency connection:** Connect the “Network-policy probes” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C032-T07 · Resource behavior:** Account for “Traffic volume and probe timeout” in “Network-policy probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Network-policy probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C032-T09 · Patch review:** Review the “Network-policy probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C032-T10 · Delivery handoff:** Publish the “Network-policy probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recorded network constraints reflect observed connectivity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Network-policy probes”; copy its required invariant exactly: “Recorded network constraints reflect observed connectivity”.
- [ ] **UC-M03.08-C033-T02 · Observable terms:** Define each term in the “Network-policy probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C033-T03 · Precondition set:** List the preconditions under which “Recorded network constraints reflect observed connectivity” must hold for “Network-policy probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C033-T04 · Transition coverage:** Map the “Network-policy probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Network-policy probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C033-T06 · Satisfying fixture:** Create a concrete “Network-policy probes” case that satisfies “Recorded network constraints reflect observed connectivity”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C033-T07 · Violating fixture:** Create the source counterexample “A configured deny policy still allows guest egress” for “Network-policy probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C033-T08 · Enforcement evidence:** Exercise the “Network-policy probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C033-T09 · Regression linkage:** Link the “Network-policy probes” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Network-policy probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C034 · Integration

**Original checklist item:** Integrate network-policy probes with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Network-policy probes” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C034-T02 · Field mapping:** Map every “Network-policy probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Network-policy probes” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C034-T04 · Ownership agreement:** Specify who owns “Network-policy probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C034-T05 · Handoff implementation:** Connect “Network-policy probes” through the mapped seam using the real adapter or explicit specification reference; preserve “Recorded network constraints reflect observed connectivity” across the handoff.
- [ ] **UC-M03.08-C034-T06 · Absent-input case:** Omit one required “Network-policy probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C034-T07 · Stale-input case:** Supply an outdated “Network-policy probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Network-policy probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C034-T09 · Valid integration trace:** Run a valid “Network-policy probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C034-T10 · Seam review:** Reconcile the “Network-policy probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for network-policy probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Network-policy probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C035-T02 · Expected-result oracle:** Specify the “Network-policy probes” expected result independently of the implementation output; include the property “Recorded network constraints reflect observed connectivity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C035-T03 · Fixture material:** Create the concrete “Network-policy probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C035-T04 · Target preparation:** Prepare the “Network-policy probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C035-T05 · Initial-state record:** Record the initial “Network-policy probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C035-T06 · Valid-path execution:** Run the “Network-policy probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C035-T07 · Outcome comparison:** Compare every declared “Network-policy probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C035-T08 · State and bounds check:** Inspect the “Network-policy probes” ownership/state effects and actual use of “Traffic volume and probe timeout”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C035-T09 · Repeatability check:** Repeat the same “Network-policy probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C035-T10 · Positive evidence:** Attach the “Network-policy probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C036 · Negative test

**Original checklist item:** Negative case: A configured deny policy still allows guest egress. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Network-policy probes” source counterexample: “A configured deny policy still allows guest egress”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Network-policy probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C036-T03 · Valid control:** Construct a valid “Network-policy probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C036-T04 · Minimal adverse input:** Derive the “Network-policy probes” adverse fixture from the control with the smallest documented change needed to reproduce “A configured deny policy still allows guest egress”; retain that change as reproducible data.
- [ ] **UC-M03.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Network-policy probes”; require “Recorded network constraints reflect observed connectivity” and forbid a false-success verdict.
- [ ] **UC-M03.08-C036-T06 · Adverse execution:** Exercise the “Network-policy probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C036-T07 · Effect inspection:** Inspect “Network-policy probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C036-T08 · Refusal versus failure:** Confirm the “Network-policy probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C036-T09 · Reset and retention:** Restore only the disposable “Network-policy probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C036-T10 · Negative regression:** Register the “Network-policy probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C037 · Change / failure test

**Original checklist item:** Exercise network-policy probes when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C037-T01 · Scenario record:** Write the “Network-policy probes” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “Recorded network constraints reflect observed connectivity”.
- [ ] **UC-M03.08-C037-T02 · Baseline capture:** Create a known-valid “Network-policy probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C037-T03 · Injection map:** Locate the “Network-policy probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Network-policy probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C037-T05 · Controlled trigger:** Introduce the controlled “Network-policy probes” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C037-T06 · Intermediate inspection:** Inspect the “Network-policy probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Network-policy probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Network-policy probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C037-T09 · Repeat and compare:** Repeat the selected “Network-policy probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C037-T10 · Failure evidence:** Publish the “Network-policy probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for traffic volume and probe timeout; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Network-policy probes”: “Traffic volume and probe timeout”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C038-T02 · Measurement method:** Choose how to observe each “Network-policy probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Network-policy probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Network-policy probes” cases for “Traffic volume and probe timeout”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Network-policy probes” limit; preserve “Recorded network constraints reflect observed connectivity”.
- [ ] **UC-M03.08-C038-T06 · Normal measurement:** Run or review the normal “Network-policy probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C038-T07 · At-limit measurement:** Exercise the “Network-policy probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C038-T08 · Over-limit measurement:** Exercise the “Network-policy probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C038-T09 · Uncovered-scope report:** List the “Network-policy probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C038-T10 · Limit evidence:** Publish the selected “Network-policy probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C039 · Diagnostics / review

**Original checklist item:** Report network-policy probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C039-T01 · Result inventory:** Enumerate the required “Network-policy probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Network-policy probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Network-policy probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C039-T04 · Observation capture:** Capture bounded raw “Network-policy probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C039-T05 · Aggregation rules:** Implement the “Network-policy probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “Recorded network constraints reflect observed connectivity”.
- [ ] **UC-M03.08-C039-T06 · Failure visibility:** Feed a failing “Network-policy probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C039-T07 · Missing-result visibility:** Withhold a required “Network-policy probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C039-T08 · Bounds and redaction:** Check “Network-policy probes” report size and retention against “Traffic volume and probe timeout”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C039-T09 · Report reconciliation:** Reconcile the “Network-policy probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C039-T10 · Qualification handoff:** Publish the “Network-policy probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for network-policy probes; label unexecuted checks as untested.

- [ ] **UC-M03.08-C040-T01 · Evidence inventory:** List the “Network-policy probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C040-T02 · Artifact references:** Record the exact “Network-policy probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C040-T03 · Fixture references:** Attach the “Network-policy probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A configured deny policy still allows guest egress” as a distinct evidence case.
- [ ] **UC-M03.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Network-policy probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C040-T05 · Environment record:** Record the actual “Network-policy probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C040-T06 · Expected versus observed:** Pair every “Network-policy probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C040-T07 · Failure and limit records:** Attach “Network-policy probes” change/failure and bounds evidence where required; include uncovered “Traffic volume and probe timeout” and unresolved violations of “Recorded network constraints reflect observed connectivity”.
- [ ] **UC-M03.08-C040-T08 · Evidence hygiene:** Check the “Network-policy probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C040-T09 · Reproduction review:** Have the “Network-policy probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C040-T10 · Acceptance linkage:** Link the “Network-policy probes” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Host patch policy

**Source delivery:** Define and record the operator's supported host/backend patch policy.

**Source invariant:** Unqualified host state is visible and cannot masquerade as approved.

**Source negative case:** A backend outside the approved patch policy is admitted.

**Source bounded quantities:** Policy entries and review interval.

### UC-M03.08-C041 · Contract

**Original checklist item:** Define the qualification objective for host patch policy, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C041-T01 · Scope statement:** Write the qualification question for “Host patch policy”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Host patch policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C041-T03 · Output inventory:** List the outputs of “Host patch policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Host patch policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C041-T05 · Prerequisite contract:** Map “Host patch policy” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Host patch policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C041-T07 · Invariant clause:** Add a normative clause for “Host patch policy” that preserves “Unqualified host state is visible and cannot masquerade as approved”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Host patch policy”; include the source counterexample “A backend outside the approved patch policy is admitted” and the intended safe disposition.
- [ ] **UC-M03.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Policy entries and review interval” in the “Host patch policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C041-T10 · Contract review:** Review the “Host patch policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C042 · Delivery

**Original checklist item:** Define and record the operator's supported host/backend patch policy.

- [ ] **UC-M03.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Host patch policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C042-T02 · Change plan:** Break the source delivery for “Host patch policy” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C042-T03 · Core artifact:** Create the “Host patch policy” model, schema or inventory that realizes this source instruction: Define and record the operator's supported host/backend patch policy.
- [ ] **UC-M03.08-C042-T04 · Concrete realization:** Populate “Host patch policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Host patch policy” needed to preserve “Unqualified host state is visible and cannot masquerade as approved”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C042-T06 · Dependency connection:** Connect the “Host patch policy” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C042-T07 · Resource behavior:** Account for “Policy entries and review interval” in “Host patch policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Host patch policy”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C042-T09 · Patch review:** Review the “Host patch policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C042-T10 · Delivery handoff:** Publish the “Host patch policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unqualified host state is visible and cannot masquerade as approved. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Host patch policy”; copy its required invariant exactly: “Unqualified host state is visible and cannot masquerade as approved”.
- [ ] **UC-M03.08-C043-T02 · Observable terms:** Define each term in the “Host patch policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C043-T03 · Precondition set:** List the preconditions under which “Unqualified host state is visible and cannot masquerade as approved” must hold for “Host patch policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C043-T04 · Transition coverage:** Map the “Host patch policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Host patch policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C043-T06 · Satisfying fixture:** Create a concrete “Host patch policy” case that satisfies “Unqualified host state is visible and cannot masquerade as approved”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C043-T07 · Violating fixture:** Create the source counterexample “A backend outside the approved patch policy is admitted” for “Host patch policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C043-T08 · Enforcement evidence:** Exercise the “Host patch policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C043-T09 · Regression linkage:** Link the “Host patch policy” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Host patch policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C044 · Integration

**Original checklist item:** Integrate host patch policy with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Host patch policy” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C044-T02 · Field mapping:** Map every “Host patch policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Host patch policy” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C044-T04 · Ownership agreement:** Specify who owns “Host patch policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C044-T05 · Handoff implementation:** Connect “Host patch policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Unqualified host state is visible and cannot masquerade as approved” across the handoff.
- [ ] **UC-M03.08-C044-T06 · Absent-input case:** Omit one required “Host patch policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C044-T07 · Stale-input case:** Supply an outdated “Host patch policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Host patch policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C044-T09 · Valid integration trace:** Run a valid “Host patch policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C044-T10 · Seam review:** Reconcile the “Host patch policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for host patch policy; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Host patch policy”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C045-T02 · Expected-result oracle:** Specify the “Host patch policy” expected result independently of the implementation output; include the property “Unqualified host state is visible and cannot masquerade as approved” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C045-T03 · Fixture material:** Create the concrete “Host patch policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C045-T04 · Target preparation:** Prepare the “Host patch policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C045-T05 · Initial-state record:** Record the initial “Host patch policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C045-T06 · Valid-path execution:** Run the “Host patch policy” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C045-T07 · Outcome comparison:** Compare every declared “Host patch policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C045-T08 · State and bounds check:** Inspect the “Host patch policy” ownership/state effects and actual use of “Policy entries and review interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C045-T09 · Repeatability check:** Repeat the same “Host patch policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C045-T10 · Positive evidence:** Attach the “Host patch policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C046 · Negative test

**Original checklist item:** Negative case: A backend outside the approved patch policy is admitted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Host patch policy” source counterexample: “A backend outside the approved patch policy is admitted”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Host patch policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C046-T03 · Valid control:** Construct a valid “Host patch policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C046-T04 · Minimal adverse input:** Derive the “Host patch policy” adverse fixture from the control with the smallest documented change needed to reproduce “A backend outside the approved patch policy is admitted”; retain that change as reproducible data.
- [ ] **UC-M03.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Host patch policy”; require “Unqualified host state is visible and cannot masquerade as approved” and forbid a false-success verdict.
- [ ] **UC-M03.08-C046-T06 · Adverse execution:** Exercise the “Host patch policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C046-T07 · Effect inspection:** Inspect “Host patch policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C046-T08 · Refusal versus failure:** Confirm the “Host patch policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C046-T09 · Reset and retention:** Restore only the disposable “Host patch policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C046-T10 · Negative regression:** Register the “Host patch policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C047 · Change / failure test

**Original checklist item:** Exercise host patch policy when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C047-T01 · Scenario record:** Write the “Host patch policy” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “Unqualified host state is visible and cannot masquerade as approved”.
- [ ] **UC-M03.08-C047-T02 · Baseline capture:** Create a known-valid “Host patch policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C047-T03 · Injection map:** Locate the “Host patch policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Host patch policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C047-T05 · Controlled trigger:** Introduce the controlled “Host patch policy” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C047-T06 · Intermediate inspection:** Inspect the “Host patch policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Host patch policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Host patch policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C047-T09 · Repeat and compare:** Repeat the selected “Host patch policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C047-T10 · Failure evidence:** Publish the “Host patch policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for policy entries and review interval; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Host patch policy”: “Policy entries and review interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C048-T02 · Measurement method:** Choose how to observe each “Host patch policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Host patch policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Host patch policy” cases for “Policy entries and review interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Host patch policy” limit; preserve “Unqualified host state is visible and cannot masquerade as approved”.
- [ ] **UC-M03.08-C048-T06 · Normal measurement:** Run or review the normal “Host patch policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C048-T07 · At-limit measurement:** Exercise the “Host patch policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C048-T08 · Over-limit measurement:** Exercise the “Host patch policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C048-T09 · Uncovered-scope report:** List the “Host patch policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C048-T10 · Limit evidence:** Publish the selected “Host patch policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C049 · Diagnostics / review

**Original checklist item:** Report host patch policy results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C049-T01 · Result inventory:** Enumerate the required “Host patch policy” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Host patch policy”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Host patch policy” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C049-T04 · Observation capture:** Capture bounded raw “Host patch policy” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C049-T05 · Aggregation rules:** Implement the “Host patch policy” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unqualified host state is visible and cannot masquerade as approved”.
- [ ] **UC-M03.08-C049-T06 · Failure visibility:** Feed a failing “Host patch policy” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C049-T07 · Missing-result visibility:** Withhold a required “Host patch policy” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C049-T08 · Bounds and redaction:** Check “Host patch policy” report size and retention against “Policy entries and review interval”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C049-T09 · Report reconciliation:** Reconcile the “Host patch policy” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C049-T10 · Qualification handoff:** Publish the “Host patch policy” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for host patch policy; label unexecuted checks as untested.

- [ ] **UC-M03.08-C050-T01 · Evidence inventory:** List the “Host patch policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C050-T02 · Artifact references:** Record the exact “Host patch policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C050-T03 · Fixture references:** Attach the “Host patch policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A backend outside the approved patch policy is admitted” as a distinct evidence case.
- [ ] **UC-M03.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Host patch policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C050-T05 · Environment record:** Record the actual “Host patch policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C050-T06 · Expected versus observed:** Pair every “Host patch policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C050-T07 · Failure and limit records:** Attach “Host patch policy” change/failure and bounds evidence where required; include uncovered “Policy entries and review interval” and unresolved violations of “Unqualified host state is visible and cannot masquerade as approved”.
- [ ] **UC-M03.08-C050-T08 · Evidence hygiene:** Check the “Host patch policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C050-T09 · Reproduction review:** Have the “Host patch policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C050-T10 · Acceptance linkage:** Link the “Host patch policy” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Capability freshness

**Source delivery:** Attach observation time and relevant host configuration identity to probes.

**Source invariant:** A materially changed host cannot reuse stale capability evidence.

**Source negative case:** A host policy changes after the last successful doctor run.

**Source bounded quantities:** Evidence lifetime and drift-check frequency.

### UC-M03.08-C051 · Contract

**Original checklist item:** Define the qualification objective for capability freshness, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C051-T01 · Scope statement:** Write the qualification question for “Capability freshness”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capability freshness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C051-T03 · Output inventory:** List the outputs of “Capability freshness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Capability freshness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C051-T05 · Prerequisite contract:** Map “Capability freshness” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Capability freshness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C051-T07 · Invariant clause:** Add a normative clause for “Capability freshness” that preserves “A materially changed host cannot reuse stale capability evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capability freshness”; include the source counterexample “A host policy changes after the last successful doctor run” and the intended safe disposition.
- [ ] **UC-M03.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence lifetime and drift-check frequency” in the “Capability freshness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C051-T10 · Contract review:** Review the “Capability freshness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C052 · Delivery

**Original checklist item:** Attach observation time and relevant host configuration identity to probes.

- [ ] **UC-M03.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capability freshness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C052-T02 · Change plan:** Break the source delivery for “Capability freshness” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C052-T03 · Core artifact:** Create the “Capability freshness” output artifact for this source instruction: Attach observation time and relevant host configuration identity to probes.
- [ ] **UC-M03.08-C052-T04 · Concrete realization:** Populate the “Capability freshness” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M03.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capability freshness” needed to preserve “A materially changed host cannot reuse stale capability evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C052-T06 · Dependency connection:** Connect the “Capability freshness” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C052-T07 · Resource behavior:** Account for “Evidence lifetime and drift-check frequency” in “Capability freshness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Capability freshness”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C052-T09 · Patch review:** Review the “Capability freshness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C052-T10 · Delivery handoff:** Publish the “Capability freshness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A materially changed host cannot reuse stale capability evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Capability freshness”; copy its required invariant exactly: “A materially changed host cannot reuse stale capability evidence”.
- [ ] **UC-M03.08-C053-T02 · Observable terms:** Define each term in the “Capability freshness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C053-T03 · Precondition set:** List the preconditions under which “A materially changed host cannot reuse stale capability evidence” must hold for “Capability freshness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C053-T04 · Transition coverage:** Map the “Capability freshness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capability freshness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C053-T06 · Satisfying fixture:** Create a concrete “Capability freshness” case that satisfies “A materially changed host cannot reuse stale capability evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C053-T07 · Violating fixture:** Create the source counterexample “A host policy changes after the last successful doctor run” for “Capability freshness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C053-T08 · Enforcement evidence:** Exercise the “Capability freshness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C053-T09 · Regression linkage:** Link the “Capability freshness” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Capability freshness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C054 · Integration

**Original checklist item:** Integrate capability freshness with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capability freshness” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C054-T02 · Field mapping:** Map every “Capability freshness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Capability freshness” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C054-T04 · Ownership agreement:** Specify who owns “Capability freshness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C054-T05 · Handoff implementation:** Connect “Capability freshness” through the mapped seam using the real adapter or explicit specification reference; preserve “A materially changed host cannot reuse stale capability evidence” across the handoff.
- [ ] **UC-M03.08-C054-T06 · Absent-input case:** Omit one required “Capability freshness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C054-T07 · Stale-input case:** Supply an outdated “Capability freshness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Capability freshness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C054-T09 · Valid integration trace:** Run a valid “Capability freshness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C054-T10 · Seam review:** Reconcile the “Capability freshness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for capability freshness; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Capability freshness”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C055-T02 · Expected-result oracle:** Specify the “Capability freshness” expected result independently of the implementation output; include the property “A materially changed host cannot reuse stale capability evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C055-T03 · Fixture material:** Create the concrete “Capability freshness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C055-T04 · Target preparation:** Prepare the “Capability freshness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C055-T05 · Initial-state record:** Record the initial “Capability freshness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C055-T06 · Valid-path execution:** Run the “Capability freshness” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C055-T07 · Outcome comparison:** Compare every declared “Capability freshness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C055-T08 · State and bounds check:** Inspect the “Capability freshness” ownership/state effects and actual use of “Evidence lifetime and drift-check frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C055-T09 · Repeatability check:** Repeat the same “Capability freshness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C055-T10 · Positive evidence:** Attach the “Capability freshness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C056 · Negative test

**Original checklist item:** Negative case: A host policy changes after the last successful doctor run. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Capability freshness” source counterexample: “A host policy changes after the last successful doctor run”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Capability freshness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C056-T03 · Valid control:** Construct a valid “Capability freshness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C056-T04 · Minimal adverse input:** Derive the “Capability freshness” adverse fixture from the control with the smallest documented change needed to reproduce “A host policy changes after the last successful doctor run”; retain that change as reproducible data.
- [ ] **UC-M03.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capability freshness”; require “A materially changed host cannot reuse stale capability evidence” and forbid a false-success verdict.
- [ ] **UC-M03.08-C056-T06 · Adverse execution:** Exercise the “Capability freshness” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C056-T07 · Effect inspection:** Inspect “Capability freshness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C056-T08 · Refusal versus failure:** Confirm the “Capability freshness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C056-T09 · Reset and retention:** Restore only the disposable “Capability freshness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C056-T10 · Negative regression:** Register the “Capability freshness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C057 · Change / failure test

**Original checklist item:** Exercise capability freshness when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C057-T01 · Scenario record:** Write the “Capability freshness” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “A materially changed host cannot reuse stale capability evidence”.
- [ ] **UC-M03.08-C057-T02 · Baseline capture:** Create a known-valid “Capability freshness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C057-T03 · Injection map:** Locate the “Capability freshness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Capability freshness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C057-T05 · Controlled trigger:** Introduce the controlled “Capability freshness” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C057-T06 · Intermediate inspection:** Inspect the “Capability freshness” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capability freshness”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Capability freshness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C057-T09 · Repeat and compare:** Repeat the selected “Capability freshness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C057-T10 · Failure evidence:** Publish the “Capability freshness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for evidence lifetime and drift-check frequency; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Capability freshness”: “Evidence lifetime and drift-check frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C058-T02 · Measurement method:** Choose how to observe each “Capability freshness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Capability freshness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capability freshness” cases for “Evidence lifetime and drift-check frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capability freshness” limit; preserve “A materially changed host cannot reuse stale capability evidence”.
- [ ] **UC-M03.08-C058-T06 · Normal measurement:** Run or review the normal “Capability freshness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C058-T07 · At-limit measurement:** Exercise the “Capability freshness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C058-T08 · Over-limit measurement:** Exercise the “Capability freshness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C058-T09 · Uncovered-scope report:** List the “Capability freshness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C058-T10 · Limit evidence:** Publish the selected “Capability freshness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C059 · Diagnostics / review

**Original checklist item:** Report capability freshness results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C059-T01 · Result inventory:** Enumerate the required “Capability freshness” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Capability freshness”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Capability freshness” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C059-T04 · Observation capture:** Capture bounded raw “Capability freshness” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C059-T05 · Aggregation rules:** Implement the “Capability freshness” count/reduction rule so failures and missing measurements cannot disappear; preserve “A materially changed host cannot reuse stale capability evidence”.
- [ ] **UC-M03.08-C059-T06 · Failure visibility:** Feed a failing “Capability freshness” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C059-T07 · Missing-result visibility:** Withhold a required “Capability freshness” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C059-T08 · Bounds and redaction:** Check “Capability freshness” report size and retention against “Evidence lifetime and drift-check frequency”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C059-T09 · Report reconciliation:** Reconcile the “Capability freshness” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C059-T10 · Qualification handoff:** Publish the “Capability freshness” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capability freshness; label unexecuted checks as untested.

- [ ] **UC-M03.08-C060-T01 · Evidence inventory:** List the “Capability freshness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C060-T02 · Artifact references:** Record the exact “Capability freshness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C060-T03 · Fixture references:** Attach the “Capability freshness” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host policy changes after the last successful doctor run” as a distinct evidence case.
- [ ] **UC-M03.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capability freshness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C060-T05 · Environment record:** Record the actual “Capability freshness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C060-T06 · Expected versus observed:** Pair every “Capability freshness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C060-T07 · Failure and limit records:** Attach “Capability freshness” change/failure and bounds evidence where required; include uncovered “Evidence lifetime and drift-check frequency” and unresolved violations of “A materially changed host cannot reuse stale capability evidence”.
- [ ] **UC-M03.08-C060-T08 · Evidence hygiene:** Check the “Capability freshness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C060-T09 · Reproduction review:** Have the “Capability freshness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C060-T10 · Acceptance linkage:** Link the “Capability freshness” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Admission binding

**Source delivery:** Bind chosen backend and verified constraints to each admitted workload.

**Source invariant:** Admission cannot cite evidence for a different host profile.

**Source negative case:** A workload uses capabilities measured on another host.

**Source bounded quantities:** Admission record size and lookup time.

### UC-M03.08-C061 · Contract

**Original checklist item:** Define the qualification objective for admission binding, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C061-T01 · Scope statement:** Write the qualification question for “Admission binding”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Admission binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C061-T03 · Output inventory:** List the outputs of “Admission binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Admission binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C061-T05 · Prerequisite contract:** Map “Admission binding” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C061-T06 · Authority map:** Identify who may produce, change and consume “Admission binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C061-T07 · Invariant clause:** Add a normative clause for “Admission binding” that preserves “Admission cannot cite evidence for a different host profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Admission binding”; include the source counterexample “A workload uses capabilities measured on another host” and the intended safe disposition.
- [ ] **UC-M03.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Admission record size and lookup time” in the “Admission binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C061-T10 · Contract review:** Review the “Admission binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C062 · Delivery

**Original checklist item:** Bind chosen backend and verified constraints to each admitted workload.

- [ ] **UC-M03.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Admission binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C062-T02 · Change plan:** Break the source delivery for “Admission binding” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Admission binding” that realizes this source instruction: Bind chosen backend and verified constraints to each admitted workload.
- [ ] **UC-M03.08-C062-T04 · Concrete realization:** Trace “Admission binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Admission binding” needed to preserve “Admission cannot cite evidence for a different host profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C062-T06 · Dependency connection:** Connect the “Admission binding” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C062-T07 · Resource behavior:** Account for “Admission record size and lookup time” in “Admission binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Admission binding”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C062-T09 · Patch review:** Review the “Admission binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C062-T10 · Delivery handoff:** Publish the “Admission binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Admission cannot cite evidence for a different host profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “Admission binding”; copy its required invariant exactly: “Admission cannot cite evidence for a different host profile”.
- [ ] **UC-M03.08-C063-T02 · Observable terms:** Define each term in the “Admission binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C063-T03 · Precondition set:** List the preconditions under which “Admission cannot cite evidence for a different host profile” must hold for “Admission binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C063-T04 · Transition coverage:** Map the “Admission binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Admission binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C063-T06 · Satisfying fixture:** Create a concrete “Admission binding” case that satisfies “Admission cannot cite evidence for a different host profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C063-T07 · Violating fixture:** Create the source counterexample “A workload uses capabilities measured on another host” for “Admission binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C063-T08 · Enforcement evidence:** Exercise the “Admission binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C063-T09 · Regression linkage:** Link the “Admission binding” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C063-T10 · Property disposition:** Compare the satisfying and violating “Admission binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C064 · Integration

**Original checklist item:** Integrate admission binding with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Admission binding” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C064-T02 · Field mapping:** Map every “Admission binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Admission binding” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C064-T04 · Ownership agreement:** Specify who owns “Admission binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C064-T05 · Handoff implementation:** Connect “Admission binding” through the mapped seam using the real adapter or explicit specification reference; preserve “Admission cannot cite evidence for a different host profile” across the handoff.
- [ ] **UC-M03.08-C064-T06 · Absent-input case:** Omit one required “Admission binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C064-T07 · Stale-input case:** Supply an outdated “Admission binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C064-T08 · Incompatible-input case:** Supply an incompatible “Admission binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C064-T09 · Valid integration trace:** Run a valid “Admission binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C064-T10 · Seam review:** Reconcile the “Admission binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for admission binding; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Admission binding”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C065-T02 · Expected-result oracle:** Specify the “Admission binding” expected result independently of the implementation output; include the property “Admission cannot cite evidence for a different host profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C065-T03 · Fixture material:** Create the concrete “Admission binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C065-T04 · Target preparation:** Prepare the “Admission binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C065-T05 · Initial-state record:** Record the initial “Admission binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C065-T06 · Valid-path execution:** Run the “Admission binding” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C065-T07 · Outcome comparison:** Compare every declared “Admission binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C065-T08 · State and bounds check:** Inspect the “Admission binding” ownership/state effects and actual use of “Admission record size and lookup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C065-T09 · Repeatability check:** Repeat the same “Admission binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C065-T10 · Positive evidence:** Attach the “Admission binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C066 · Negative test

**Original checklist item:** Negative case: A workload uses capabilities measured on another host. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “Admission binding” source counterexample: “A workload uses capabilities measured on another host”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Admission binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C066-T03 · Valid control:** Construct a valid “Admission binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C066-T04 · Minimal adverse input:** Derive the “Admission binding” adverse fixture from the control with the smallest documented change needed to reproduce “A workload uses capabilities measured on another host”; retain that change as reproducible data.
- [ ] **UC-M03.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Admission binding”; require “Admission cannot cite evidence for a different host profile” and forbid a false-success verdict.
- [ ] **UC-M03.08-C066-T06 · Adverse execution:** Exercise the “Admission binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C066-T07 · Effect inspection:** Inspect “Admission binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C066-T08 · Refusal versus failure:** Confirm the “Admission binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C066-T09 · Reset and retention:** Restore only the disposable “Admission binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C066-T10 · Negative regression:** Register the “Admission binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C067 · Change / failure test

**Original checklist item:** Exercise admission binding when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C067-T01 · Scenario record:** Write the “Admission binding” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “Admission cannot cite evidence for a different host profile”.
- [ ] **UC-M03.08-C067-T02 · Baseline capture:** Create a known-valid “Admission binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C067-T03 · Injection map:** Locate the “Admission binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Admission binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C067-T05 · Controlled trigger:** Introduce the controlled “Admission binding” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C067-T06 · Intermediate inspection:** Inspect the “Admission binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Admission binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Admission binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C067-T09 · Repeat and compare:** Repeat the selected “Admission binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C067-T10 · Failure evidence:** Publish the “Admission binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for admission record size and lookup time; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “Admission binding”: “Admission record size and lookup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C068-T02 · Measurement method:** Choose how to observe each “Admission binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Admission binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Admission binding” cases for “Admission record size and lookup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Admission binding” limit; preserve “Admission cannot cite evidence for a different host profile”.
- [ ] **UC-M03.08-C068-T06 · Normal measurement:** Run or review the normal “Admission binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C068-T07 · At-limit measurement:** Exercise the “Admission binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C068-T08 · Over-limit measurement:** Exercise the “Admission binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C068-T09 · Uncovered-scope report:** List the “Admission binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C068-T10 · Limit evidence:** Publish the selected “Admission binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C069 · Diagnostics / review

**Original checklist item:** Report admission binding results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C069-T01 · Result inventory:** Enumerate the required “Admission binding” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Admission binding”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Admission binding” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C069-T04 · Observation capture:** Capture bounded raw “Admission binding” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C069-T05 · Aggregation rules:** Implement the “Admission binding” count/reduction rule so failures and missing measurements cannot disappear; preserve “Admission cannot cite evidence for a different host profile”.
- [ ] **UC-M03.08-C069-T06 · Failure visibility:** Feed a failing “Admission binding” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C069-T07 · Missing-result visibility:** Withhold a required “Admission binding” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C069-T08 · Bounds and redaction:** Check “Admission binding” report size and retention against “Admission record size and lookup time”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C069-T09 · Report reconciliation:** Reconcile the “Admission binding” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C069-T10 · Qualification handoff:** Publish the “Admission binding” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for admission binding; label unexecuted checks as untested.

- [ ] **UC-M03.08-C070-T01 · Evidence inventory:** List the “Admission binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C070-T02 · Artifact references:** Record the exact “Admission binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C070-T03 · Fixture references:** Attach the “Admission binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload uses capabilities measured on another host” as a distinct evidence case.
- [ ] **UC-M03.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Admission binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C070-T05 · Environment record:** Record the actual “Admission binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C070-T06 · Expected versus observed:** Pair every “Admission binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C070-T07 · Failure and limit records:** Attach “Admission binding” change/failure and bounds evidence where required; include uncovered “Admission record size and lookup time” and unresolved violations of “Admission cannot cite evidence for a different host profile”.
- [ ] **UC-M03.08-C070-T08 · Evidence hygiene:** Check the “Admission binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C070-T09 · Reproduction review:** Have the “Admission binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C070-T10 · Acceptance linkage:** Link the “Admission binding” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Immutable evidence publication

**Source delivery:** Publish capability observations with immutable run identifiers and digests.

**Source invariant:** A later mutable doctor report cannot rewrite old admission evidence.

**Source negative case:** Editing a shared status file changes historical run claims.

**Source bounded quantities:** Evidence bytes and publication rate.

### UC-M03.08-C071 · Contract

**Original checklist item:** Define the qualification objective for immutable evidence publication, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C071-T01 · Scope statement:** Write the qualification question for “Immutable evidence publication”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Immutable evidence publication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C071-T03 · Output inventory:** List the outputs of “Immutable evidence publication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Immutable evidence publication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C071-T05 · Prerequisite contract:** Map “Immutable evidence publication” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Immutable evidence publication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C071-T07 · Invariant clause:** Add a normative clause for “Immutable evidence publication” that preserves “A later mutable doctor report cannot rewrite old admission evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Immutable evidence publication”; include the source counterexample “Editing a shared status file changes historical run claims” and the intended safe disposition.
- [ ] **UC-M03.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence bytes and publication rate” in the “Immutable evidence publication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C071-T10 · Contract review:** Review the “Immutable evidence publication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C072 · Delivery

**Original checklist item:** Publish capability observations with immutable run identifiers and digests.

- [ ] **UC-M03.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Immutable evidence publication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C072-T02 · Change plan:** Break the source delivery for “Immutable evidence publication” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C072-T03 · Core artifact:** Create the “Immutable evidence publication” output artifact for this source instruction: Publish capability observations with immutable run identifiers and digests.
- [ ] **UC-M03.08-C072-T04 · Concrete realization:** Populate the “Immutable evidence publication” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M03.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Immutable evidence publication” needed to preserve “A later mutable doctor report cannot rewrite old admission evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C072-T06 · Dependency connection:** Connect the “Immutable evidence publication” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C072-T07 · Resource behavior:** Account for “Evidence bytes and publication rate” in “Immutable evidence publication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Immutable evidence publication”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C072-T09 · Patch review:** Review the “Immutable evidence publication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C072-T10 · Delivery handoff:** Publish the “Immutable evidence publication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A later mutable doctor report cannot rewrite old admission evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Immutable evidence publication”; copy its required invariant exactly: “A later mutable doctor report cannot rewrite old admission evidence”.
- [ ] **UC-M03.08-C073-T02 · Observable terms:** Define each term in the “Immutable evidence publication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C073-T03 · Precondition set:** List the preconditions under which “A later mutable doctor report cannot rewrite old admission evidence” must hold for “Immutable evidence publication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C073-T04 · Transition coverage:** Map the “Immutable evidence publication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Immutable evidence publication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C073-T06 · Satisfying fixture:** Create a concrete “Immutable evidence publication” case that satisfies “A later mutable doctor report cannot rewrite old admission evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C073-T07 · Violating fixture:** Create the source counterexample “Editing a shared status file changes historical run claims” for “Immutable evidence publication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C073-T08 · Enforcement evidence:** Exercise the “Immutable evidence publication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C073-T09 · Regression linkage:** Link the “Immutable evidence publication” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Immutable evidence publication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C074 · Integration

**Original checklist item:** Integrate immutable evidence publication with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Immutable evidence publication” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C074-T02 · Field mapping:** Map every “Immutable evidence publication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Immutable evidence publication” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C074-T04 · Ownership agreement:** Specify who owns “Immutable evidence publication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C074-T05 · Handoff implementation:** Connect “Immutable evidence publication” through the mapped seam using the real adapter or explicit specification reference; preserve “A later mutable doctor report cannot rewrite old admission evidence” across the handoff.
- [ ] **UC-M03.08-C074-T06 · Absent-input case:** Omit one required “Immutable evidence publication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C074-T07 · Stale-input case:** Supply an outdated “Immutable evidence publication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Immutable evidence publication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C074-T09 · Valid integration trace:** Run a valid “Immutable evidence publication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C074-T10 · Seam review:** Reconcile the “Immutable evidence publication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for immutable evidence publication; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Immutable evidence publication”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C075-T02 · Expected-result oracle:** Specify the “Immutable evidence publication” expected result independently of the implementation output; include the property “A later mutable doctor report cannot rewrite old admission evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C075-T03 · Fixture material:** Create the concrete “Immutable evidence publication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C075-T04 · Target preparation:** Prepare the “Immutable evidence publication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C075-T05 · Initial-state record:** Record the initial “Immutable evidence publication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C075-T06 · Valid-path execution:** Run the “Immutable evidence publication” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C075-T07 · Outcome comparison:** Compare every declared “Immutable evidence publication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C075-T08 · State and bounds check:** Inspect the “Immutable evidence publication” ownership/state effects and actual use of “Evidence bytes and publication rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C075-T09 · Repeatability check:** Repeat the same “Immutable evidence publication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C075-T10 · Positive evidence:** Attach the “Immutable evidence publication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C076 · Negative test

**Original checklist item:** Negative case: Editing a shared status file changes historical run claims. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Immutable evidence publication” source counterexample: “Editing a shared status file changes historical run claims”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Immutable evidence publication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C076-T03 · Valid control:** Construct a valid “Immutable evidence publication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C076-T04 · Minimal adverse input:** Derive the “Immutable evidence publication” adverse fixture from the control with the smallest documented change needed to reproduce “Editing a shared status file changes historical run claims”; retain that change as reproducible data.
- [ ] **UC-M03.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Immutable evidence publication”; require “A later mutable doctor report cannot rewrite old admission evidence” and forbid a false-success verdict.
- [ ] **UC-M03.08-C076-T06 · Adverse execution:** Exercise the “Immutable evidence publication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C076-T07 · Effect inspection:** Inspect “Immutable evidence publication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C076-T08 · Refusal versus failure:** Confirm the “Immutable evidence publication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C076-T09 · Reset and retention:** Restore only the disposable “Immutable evidence publication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C076-T10 · Negative regression:** Register the “Immutable evidence publication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C077 · Change / failure test

**Original checklist item:** Exercise immutable evidence publication when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C077-T01 · Scenario record:** Write the “Immutable evidence publication” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “A later mutable doctor report cannot rewrite old admission evidence”.
- [ ] **UC-M03.08-C077-T02 · Baseline capture:** Create a known-valid “Immutable evidence publication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C077-T03 · Injection map:** Locate the “Immutable evidence publication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Immutable evidence publication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C077-T05 · Controlled trigger:** Introduce the controlled “Immutable evidence publication” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C077-T06 · Intermediate inspection:** Inspect the “Immutable evidence publication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Immutable evidence publication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Immutable evidence publication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C077-T09 · Repeat and compare:** Repeat the selected “Immutable evidence publication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C077-T10 · Failure evidence:** Publish the “Immutable evidence publication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for evidence bytes and publication rate; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Immutable evidence publication”: “Evidence bytes and publication rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C078-T02 · Measurement method:** Choose how to observe each “Immutable evidence publication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Immutable evidence publication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Immutable evidence publication” cases for “Evidence bytes and publication rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Immutable evidence publication” limit; preserve “A later mutable doctor report cannot rewrite old admission evidence”.
- [ ] **UC-M03.08-C078-T06 · Normal measurement:** Run or review the normal “Immutable evidence publication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C078-T07 · At-limit measurement:** Exercise the “Immutable evidence publication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C078-T08 · Over-limit measurement:** Exercise the “Immutable evidence publication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C078-T09 · Uncovered-scope report:** List the “Immutable evidence publication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C078-T10 · Limit evidence:** Publish the selected “Immutable evidence publication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C079 · Diagnostics / review

**Original checklist item:** Report immutable evidence publication results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C079-T01 · Result inventory:** Enumerate the required “Immutable evidence publication” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Immutable evidence publication”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Immutable evidence publication” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C079-T04 · Observation capture:** Capture bounded raw “Immutable evidence publication” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C079-T05 · Aggregation rules:** Implement the “Immutable evidence publication” count/reduction rule so failures and missing measurements cannot disappear; preserve “A later mutable doctor report cannot rewrite old admission evidence”.
- [ ] **UC-M03.08-C079-T06 · Failure visibility:** Feed a failing “Immutable evidence publication” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C079-T07 · Missing-result visibility:** Withhold a required “Immutable evidence publication” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C079-T08 · Bounds and redaction:** Check “Immutable evidence publication” report size and retention against “Evidence bytes and publication rate”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C079-T09 · Report reconciliation:** Reconcile the “Immutable evidence publication” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C079-T10 · Qualification handoff:** Publish the “Immutable evidence publication” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for immutable evidence publication; label unexecuted checks as untested.

- [ ] **UC-M03.08-C080-T01 · Evidence inventory:** List the “Immutable evidence publication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C080-T02 · Artifact references:** Record the exact “Immutable evidence publication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C080-T03 · Fixture references:** Attach the “Immutable evidence publication” fixture IDs, input identities and oracle definition; preserve the source counterexample “Editing a shared status file changes historical run claims” as a distinct evidence case.
- [ ] **UC-M03.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Immutable evidence publication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C080-T05 · Environment record:** Record the actual “Immutable evidence publication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C080-T06 · Expected versus observed:** Pair every “Immutable evidence publication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C080-T07 · Failure and limit records:** Attach “Immutable evidence publication” change/failure and bounds evidence where required; include uncovered “Evidence bytes and publication rate” and unresolved violations of “A later mutable doctor report cannot rewrite old admission evidence”.
- [ ] **UC-M03.08-C080-T08 · Evidence hygiene:** Check the “Immutable evidence publication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C080-T09 · Reproduction review:** Have the “Immutable evidence publication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C080-T10 · Acceptance linkage:** Link the “Immutable evidence publication” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Required-capability refusal

**Source delivery:** Return explicit blockers for unavailable required protections.

**Source invariant:** Security-required admission never becomes a degraded-success path.

**Source negative case:** A missing sandbox primitive is labeled as a harmless warning.

**Source bounded quantities:** Refusal details and retry budget.

### UC-M03.08-C081 · Contract

**Original checklist item:** Define the qualification objective for required-capability refusal, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C081-T01 · Scope statement:** Write the qualification question for “Required-capability refusal”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Required-capability refusal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C081-T03 · Output inventory:** List the outputs of “Required-capability refusal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Required-capability refusal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C081-T05 · Prerequisite contract:** Map “Required-capability refusal” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Required-capability refusal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C081-T07 · Invariant clause:** Add a normative clause for “Required-capability refusal” that preserves “Security-required admission never becomes a degraded-success path”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Required-capability refusal”; include the source counterexample “A missing sandbox primitive is labeled as a harmless warning” and the intended safe disposition.
- [ ] **UC-M03.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Refusal details and retry budget” in the “Required-capability refusal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C081-T10 · Contract review:** Review the “Required-capability refusal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C082 · Delivery

**Original checklist item:** Return explicit blockers for unavailable required protections.

- [ ] **UC-M03.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Required-capability refusal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C082-T02 · Change plan:** Break the source delivery for “Required-capability refusal” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Required-capability refusal” that realizes this source instruction: Return explicit blockers for unavailable required protections.
- [ ] **UC-M03.08-C082-T04 · Concrete realization:** Trace “Required-capability refusal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Required-capability refusal” needed to preserve “Security-required admission never becomes a degraded-success path”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C082-T06 · Dependency connection:** Connect the “Required-capability refusal” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C082-T07 · Resource behavior:** Account for “Refusal details and retry budget” in “Required-capability refusal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Required-capability refusal”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C082-T09 · Patch review:** Review the “Required-capability refusal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C082-T10 · Delivery handoff:** Publish the “Required-capability refusal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Security-required admission never becomes a degraded-success path. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Required-capability refusal”; copy its required invariant exactly: “Security-required admission never becomes a degraded-success path”.
- [ ] **UC-M03.08-C083-T02 · Observable terms:** Define each term in the “Required-capability refusal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C083-T03 · Precondition set:** List the preconditions under which “Security-required admission never becomes a degraded-success path” must hold for “Required-capability refusal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C083-T04 · Transition coverage:** Map the “Required-capability refusal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Required-capability refusal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C083-T06 · Satisfying fixture:** Create a concrete “Required-capability refusal” case that satisfies “Security-required admission never becomes a degraded-success path”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C083-T07 · Violating fixture:** Create the source counterexample “A missing sandbox primitive is labeled as a harmless warning” for “Required-capability refusal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C083-T08 · Enforcement evidence:** Exercise the “Required-capability refusal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C083-T09 · Regression linkage:** Link the “Required-capability refusal” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Required-capability refusal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C084 · Integration

**Original checklist item:** Integrate required-capability refusal with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Required-capability refusal” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C084-T02 · Field mapping:** Map every “Required-capability refusal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Required-capability refusal” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C084-T04 · Ownership agreement:** Specify who owns “Required-capability refusal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C084-T05 · Handoff implementation:** Connect “Required-capability refusal” through the mapped seam using the real adapter or explicit specification reference; preserve “Security-required admission never becomes a degraded-success path” across the handoff.
- [ ] **UC-M03.08-C084-T06 · Absent-input case:** Omit one required “Required-capability refusal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C084-T07 · Stale-input case:** Supply an outdated “Required-capability refusal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Required-capability refusal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C084-T09 · Valid integration trace:** Run a valid “Required-capability refusal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C084-T10 · Seam review:** Reconcile the “Required-capability refusal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for required-capability refusal; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Required-capability refusal”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C085-T02 · Expected-result oracle:** Specify the “Required-capability refusal” expected result independently of the implementation output; include the property “Security-required admission never becomes a degraded-success path” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C085-T03 · Fixture material:** Create the concrete “Required-capability refusal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C085-T04 · Target preparation:** Prepare the “Required-capability refusal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C085-T05 · Initial-state record:** Record the initial “Required-capability refusal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C085-T06 · Valid-path execution:** Run the “Required-capability refusal” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C085-T07 · Outcome comparison:** Compare every declared “Required-capability refusal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C085-T08 · State and bounds check:** Inspect the “Required-capability refusal” ownership/state effects and actual use of “Refusal details and retry budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C085-T09 · Repeatability check:** Repeat the same “Required-capability refusal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C085-T10 · Positive evidence:** Attach the “Required-capability refusal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C086 · Negative test

**Original checklist item:** Negative case: A missing sandbox primitive is labeled as a harmless warning. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Required-capability refusal” source counterexample: “A missing sandbox primitive is labeled as a harmless warning”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Required-capability refusal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C086-T03 · Valid control:** Construct a valid “Required-capability refusal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C086-T04 · Minimal adverse input:** Derive the “Required-capability refusal” adverse fixture from the control with the smallest documented change needed to reproduce “A missing sandbox primitive is labeled as a harmless warning”; retain that change as reproducible data.
- [ ] **UC-M03.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Required-capability refusal”; require “Security-required admission never becomes a degraded-success path” and forbid a false-success verdict.
- [ ] **UC-M03.08-C086-T06 · Adverse execution:** Exercise the “Required-capability refusal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C086-T07 · Effect inspection:** Inspect “Required-capability refusal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C086-T08 · Refusal versus failure:** Confirm the “Required-capability refusal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C086-T09 · Reset and retention:** Restore only the disposable “Required-capability refusal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C086-T10 · Negative regression:** Register the “Required-capability refusal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C087 · Change / failure test

**Original checklist item:** Exercise required-capability refusal when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C087-T01 · Scenario record:** Write the “Required-capability refusal” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “Security-required admission never becomes a degraded-success path”.
- [ ] **UC-M03.08-C087-T02 · Baseline capture:** Create a known-valid “Required-capability refusal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C087-T03 · Injection map:** Locate the “Required-capability refusal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Required-capability refusal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C087-T05 · Controlled trigger:** Introduce the controlled “Required-capability refusal” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C087-T06 · Intermediate inspection:** Inspect the “Required-capability refusal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Required-capability refusal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Required-capability refusal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C087-T09 · Repeat and compare:** Repeat the selected “Required-capability refusal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C087-T10 · Failure evidence:** Publish the “Required-capability refusal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for refusal details and retry budget; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Required-capability refusal”: “Refusal details and retry budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C088-T02 · Measurement method:** Choose how to observe each “Required-capability refusal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Required-capability refusal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Required-capability refusal” cases for “Refusal details and retry budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Required-capability refusal” limit; preserve “Security-required admission never becomes a degraded-success path”.
- [ ] **UC-M03.08-C088-T06 · Normal measurement:** Run or review the normal “Required-capability refusal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C088-T07 · At-limit measurement:** Exercise the “Required-capability refusal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C088-T08 · Over-limit measurement:** Exercise the “Required-capability refusal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C088-T09 · Uncovered-scope report:** List the “Required-capability refusal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C088-T10 · Limit evidence:** Publish the selected “Required-capability refusal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C089 · Diagnostics / review

**Original checklist item:** Report required-capability refusal results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C089-T01 · Result inventory:** Enumerate the required “Required-capability refusal” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Required-capability refusal”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Required-capability refusal” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C089-T04 · Observation capture:** Capture bounded raw “Required-capability refusal” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C089-T05 · Aggregation rules:** Implement the “Required-capability refusal” count/reduction rule so failures and missing measurements cannot disappear; preserve “Security-required admission never becomes a degraded-success path”.
- [ ] **UC-M03.08-C089-T06 · Failure visibility:** Feed a failing “Required-capability refusal” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C089-T07 · Missing-result visibility:** Withhold a required “Required-capability refusal” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C089-T08 · Bounds and redaction:** Check “Required-capability refusal” report size and retention against “Refusal details and retry budget”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C089-T09 · Report reconciliation:** Reconcile the “Required-capability refusal” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C089-T10 · Qualification handoff:** Publish the “Required-capability refusal” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for required-capability refusal; label unexecuted checks as untested.

- [ ] **UC-M03.08-C090-T01 · Evidence inventory:** List the “Required-capability refusal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C090-T02 · Artifact references:** Record the exact “Required-capability refusal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C090-T03 · Fixture references:** Attach the “Required-capability refusal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A missing sandbox primitive is labeled as a harmless warning” as a distinct evidence case.
- [ ] **UC-M03.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Required-capability refusal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C090-T05 · Environment record:** Record the actual “Required-capability refusal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C090-T06 · Expected versus observed:** Pair every “Required-capability refusal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C090-T07 · Failure and limit records:** Attach “Required-capability refusal” change/failure and bounds evidence where required; include uncovered “Refusal details and retry budget” and unresolved violations of “Security-required admission never becomes a degraded-success path”.
- [ ] **UC-M03.08-C090-T08 · Evidence hygiene:** Check the “Required-capability refusal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C090-T09 · Reproduction review:** Have the “Required-capability refusal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C090-T10 · Acceptance linkage:** Link the “Required-capability refusal” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Doctor-to-run consistency

**Source delivery:** Compare preflight evidence with the effective settings of the launched backend.

**Source invariant:** Runtime constraints match the capabilities used to approve admission.

**Source negative case:** A backend starts with a weaker configuration than the probe tested.

**Source bounded quantities:** Consistency-check cost and supported backend matrix.

### UC-M03.08-C091 · Contract

**Original checklist item:** Define the qualification objective for doctor-to-run consistency, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M03.08-C091-T01 · Scope statement:** Write the qualification question for “Doctor-to-run consistency”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M03.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Doctor-to-run consistency”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.08-C091-T03 · Output inventory:** List the outputs of “Doctor-to-run consistency” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Doctor-to-run consistency”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.08-C091-T05 · Prerequisite contract:** Map “Doctor-to-run consistency” to the source component prerequisites (UC-M03.02, UC-M03.04, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.08-C091-T06 · Authority map:** Identify who may produce, change and consume “Doctor-to-run consistency”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.08-C091-T07 · Invariant clause:** Add a normative clause for “Doctor-to-run consistency” that preserves “Runtime constraints match the capabilities used to approve admission”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Doctor-to-run consistency”; include the source counterexample “A backend starts with a weaker configuration than the probe tested” and the intended safe disposition.
- [ ] **UC-M03.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Consistency-check cost and supported backend matrix” in the “Doctor-to-run consistency” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.08-C091-T10 · Contract review:** Review the “Doctor-to-run consistency” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.08-C092 · Delivery

**Original checklist item:** Compare preflight evidence with the effective settings of the launched backend.

- [ ] **UC-M03.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Doctor-to-run consistency”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.08-C092-T02 · Change plan:** Break the source delivery for “Doctor-to-run consistency” into concrete edit targets and reviewable outputs; keep the UC-M03.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.08-C092-T03 · Core artifact:** Create the “Doctor-to-run consistency” fixture or harness for this source instruction: Compare preflight evidence with the effective settings of the launched backend.
- [ ] **UC-M03.08-C092-T04 · Concrete realization:** Connect the “Doctor-to-run consistency” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Doctor-to-run consistency” needed to preserve “Runtime constraints match the capabilities used to approve admission”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.08-C092-T06 · Dependency connection:** Connect the “Doctor-to-run consistency” qualification artifact to doctor probes, admission policy and effective runtime configuration; record the target identity and what the harness actually exercises.
- [ ] **UC-M03.08-C092-T07 · Resource behavior:** Account for “Consistency-check cost and supported backend matrix” in “Doctor-to-run consistency”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.08-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Doctor-to-run consistency”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M03.08-C092-T09 · Patch review:** Review the “Doctor-to-run consistency” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.08-C092-T10 · Delivery handoff:** Publish the “Doctor-to-run consistency” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Runtime constraints match the capabilities used to approve admission. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “Doctor-to-run consistency”; copy its required invariant exactly: “Runtime constraints match the capabilities used to approve admission”.
- [ ] **UC-M03.08-C093-T02 · Observable terms:** Define each term in the “Doctor-to-run consistency” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.08-C093-T03 · Precondition set:** List the preconditions under which “Runtime constraints match the capabilities used to approve admission” must hold for “Doctor-to-run consistency”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.08-C093-T04 · Transition coverage:** Map the “Doctor-to-run consistency” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Doctor-to-run consistency”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.08-C093-T06 · Satisfying fixture:** Create a concrete “Doctor-to-run consistency” case that satisfies “Runtime constraints match the capabilities used to approve admission”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.08-C093-T07 · Violating fixture:** Create the source counterexample “A backend starts with a weaker configuration than the probe tested” for “Doctor-to-run consistency”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.08-C093-T08 · Enforcement evidence:** Exercise the “Doctor-to-run consistency” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.08-C093-T09 · Regression linkage:** Link the “Doctor-to-run consistency” property to changes in doctor probes, admission policy and effective runtime configuration; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.08-C093-T10 · Property disposition:** Compare the satisfying and violating “Doctor-to-run consistency” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.08-C094 · Integration

**Original checklist item:** Integrate doctor-to-run consistency with doctor probes, admission policy and effective runtime configuration; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Doctor-to-run consistency” across doctor probes, admission policy and effective runtime configuration; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.08-C094-T02 · Field mapping:** Map every “Doctor-to-run consistency” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Doctor-to-run consistency” (source dependency list: UC-M03.02, UC-M03.04, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.08-C094-T04 · Ownership agreement:** Specify who owns “Doctor-to-run consistency” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.08-C094-T05 · Handoff implementation:** Connect “Doctor-to-run consistency” through the mapped seam using the real adapter or explicit specification reference; preserve “Runtime constraints match the capabilities used to approve admission” across the handoff.
- [ ] **UC-M03.08-C094-T06 · Absent-input case:** Omit one required “Doctor-to-run consistency” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.08-C094-T07 · Stale-input case:** Supply an outdated “Doctor-to-run consistency” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.08-C094-T08 · Incompatible-input case:** Supply an incompatible “Doctor-to-run consistency” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.08-C094-T09 · Valid integration trace:** Run a valid “Doctor-to-run consistency” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.08-C094-T10 · Seam review:** Reconcile the “Doctor-to-run consistency” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.08-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for doctor-to-run consistency; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M03.08-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Doctor-to-run consistency”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M03.08-C095-T02 · Expected-result oracle:** Specify the “Doctor-to-run consistency” expected result independently of the implementation output; include the property “Runtime constraints match the capabilities used to approve admission” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.08-C095-T03 · Fixture material:** Create the concrete “Doctor-to-run consistency” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.08-C095-T04 · Target preparation:** Prepare the “Doctor-to-run consistency” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.08-C095-T05 · Initial-state record:** Record the initial “Doctor-to-run consistency” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.08-C095-T06 · Valid-path execution:** Run the “Doctor-to-run consistency” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M03.08-C095-T07 · Outcome comparison:** Compare every declared “Doctor-to-run consistency” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.08-C095-T08 · State and bounds check:** Inspect the “Doctor-to-run consistency” ownership/state effects and actual use of “Consistency-check cost and supported backend matrix”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.08-C095-T09 · Repeatability check:** Repeat the same “Doctor-to-run consistency” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.08-C095-T10 · Positive evidence:** Attach the “Doctor-to-run consistency” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.08-C096 · Negative test

**Original checklist item:** Negative case: A backend starts with a weaker configuration than the probe tested. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “Doctor-to-run consistency” source counterexample: “A backend starts with a weaker configuration than the probe tested”; state which precondition or invariant it challenges.
- [ ] **UC-M03.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Doctor-to-run consistency”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.08-C096-T03 · Valid control:** Construct a valid “Doctor-to-run consistency” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.08-C096-T04 · Minimal adverse input:** Derive the “Doctor-to-run consistency” adverse fixture from the control with the smallest documented change needed to reproduce “A backend starts with a weaker configuration than the probe tested”; retain that change as reproducible data.
- [ ] **UC-M03.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Doctor-to-run consistency”; require “Runtime constraints match the capabilities used to approve admission” and forbid a false-success verdict.
- [ ] **UC-M03.08-C096-T06 · Adverse execution:** Exercise the “Doctor-to-run consistency” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.08-C096-T07 · Effect inspection:** Inspect “Doctor-to-run consistency” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.08-C096-T08 · Refusal versus failure:** Confirm the “Doctor-to-run consistency” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.08-C096-T09 · Reset and retention:** Restore only the disposable “Doctor-to-run consistency” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.08-C096-T10 · Negative regression:** Register the “Doctor-to-run consistency” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.08-C097 · Change / failure test

**Original checklist item:** Exercise doctor-to-run consistency when host configuration changes after the last successful capability probe; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.08-C097-T01 · Scenario record:** Write the “Doctor-to-run consistency” change/failure scenario exactly as supplied: host configuration changes after the last successful capability probe; identify the property that must remain true: “Runtime constraints match the capabilities used to approve admission”.
- [ ] **UC-M03.08-C097-T02 · Baseline capture:** Create a known-valid “Doctor-to-run consistency” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.08-C097-T03 · Injection map:** Locate the “Doctor-to-run consistency” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Doctor-to-run consistency” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.08-C097-T05 · Controlled trigger:** Introduce the controlled “Doctor-to-run consistency” scenario in the disposable fixture: host configuration changes after the last successful capability probe; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.08-C097-T06 · Intermediate inspection:** Inspect the “Doctor-to-run consistency” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Doctor-to-run consistency”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Doctor-to-run consistency” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.08-C097-T09 · Repeat and compare:** Repeat the selected “Doctor-to-run consistency” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.08-C097-T10 · Failure evidence:** Publish the “Doctor-to-run consistency” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.08-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for consistency-check cost and supported backend matrix; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M03.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “Doctor-to-run consistency”: “Consistency-check cost and supported backend matrix”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.08-C098-T02 · Measurement method:** Choose how to observe each “Doctor-to-run consistency” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.08-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Doctor-to-run consistency”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Doctor-to-run consistency” cases for “Consistency-check cost and supported backend matrix”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Doctor-to-run consistency” limit; preserve “Runtime constraints match the capabilities used to approve admission”.
- [ ] **UC-M03.08-C098-T06 · Normal measurement:** Run or review the normal “Doctor-to-run consistency” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.08-C098-T07 · At-limit measurement:** Exercise the “Doctor-to-run consistency” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.08-C098-T08 · Over-limit measurement:** Exercise the “Doctor-to-run consistency” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.08-C098-T09 · Uncovered-scope report:** List the “Doctor-to-run consistency” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.08-C098-T10 · Limit evidence:** Publish the selected “Doctor-to-run consistency” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.08-C099 · Diagnostics / review

**Original checklist item:** Report doctor-to-run consistency results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M03.08-C099-T01 · Result inventory:** Enumerate the required “Doctor-to-run consistency” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M03.08-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Doctor-to-run consistency”; document how incomplete cases block relevant claims.
- [ ] **UC-M03.08-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Doctor-to-run consistency” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M03.08-C099-T04 · Observation capture:** Capture bounded raw “Doctor-to-run consistency” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M03.08-C099-T05 · Aggregation rules:** Implement the “Doctor-to-run consistency” count/reduction rule so failures and missing measurements cannot disappear; preserve “Runtime constraints match the capabilities used to approve admission”.
- [ ] **UC-M03.08-C099-T06 · Failure visibility:** Feed a failing “Doctor-to-run consistency” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M03.08-C099-T07 · Missing-result visibility:** Withhold a required “Doctor-to-run consistency” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M03.08-C099-T08 · Bounds and redaction:** Check “Doctor-to-run consistency” report size and retention against “Consistency-check cost and supported backend matrix”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M03.08-C099-T09 · Report reconciliation:** Reconcile the “Doctor-to-run consistency” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M03.08-C099-T10 · Qualification handoff:** Publish the “Doctor-to-run consistency” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M03.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for doctor-to-run consistency; label unexecuted checks as untested.

- [ ] **UC-M03.08-C100-T01 · Evidence inventory:** List the “Doctor-to-run consistency” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.08-C100-T02 · Artifact references:** Record the exact “Doctor-to-run consistency” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.08-C100-T03 · Fixture references:** Attach the “Doctor-to-run consistency” fixture IDs, input identities and oracle definition; preserve the source counterexample “A backend starts with a weaker configuration than the probe tested” as a distinct evidence case.
- [ ] **UC-M03.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Doctor-to-run consistency”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.08-C100-T05 · Environment record:** Record the actual “Doctor-to-run consistency” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.08-C100-T06 · Expected versus observed:** Pair every “Doctor-to-run consistency” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.08-C100-T07 · Failure and limit records:** Attach “Doctor-to-run consistency” change/failure and bounds evidence where required; include uncovered “Consistency-check cost and supported backend matrix” and unresolved violations of “Runtime constraints match the capabilities used to approve admission”.
- [ ] **UC-M03.08-C100-T08 · Evidence hygiene:** Check the “Doctor-to-run consistency” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.08-C100-T09 · Reproduction review:** Have the “Doctor-to-run consistency” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.08-C100-T10 · Acceptance linkage:** Link the “Doctor-to-run consistency” evidence to its parent and UC-M03.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

