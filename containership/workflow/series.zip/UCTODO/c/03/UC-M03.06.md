# UC-M03.06 — Supervisor, watchdog and child-tree cleanup

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/03.md)

| Field | Preserved source value |
|---|---|
| Workstream | 03. Host isolation and supervision |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M03.01](../03/UC-M03.01.md), [UC-M03.05](../03/UC-M03.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S3], [S4]. |

## Original requirement

Track each child by generation, enforce deadlines, bound stdout/stderr, kill the complete tree and reap zombies.

**Original acceptance criterion:** Timeout and parent crash leave no executable orphan; failure reason and last bounded log survive.

**Source trace:** Original checklist `UC100/c/03/UC-M03.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 294–304 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Child-tree registry

**Source delivery:** Record every child and descendant under workload identity and generation.

**Source invariant:** A child is never managed solely by a stale PID.

**Source negative case:** A PID is reused after the original process exits.

**Source bounded quantities:** Registry entries and stale-record retention.

### UC-M03.06-C001 · Contract

**Original checklist item:** Specify child-tree registry inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C001-T01 · Scope statement:** Draft the operation boundary for “Child-tree registry” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Child-tree registry”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C001-T03 · Output inventory:** List the outputs of “Child-tree registry” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Child-tree registry”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C001-T05 · Prerequisite contract:** Map “Child-tree registry” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Child-tree registry”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C001-T07 · Invariant clause:** Add a normative clause for “Child-tree registry” that preserves “A child is never managed solely by a stale PID”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Child-tree registry”; include the source counterexample “A PID is reused after the original process exits” and the intended safe disposition.
- [ ] **UC-M03.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Registry entries and stale-record retention” in the “Child-tree registry” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C001-T10 · Contract review:** Review the “Child-tree registry” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C002 · Delivery

**Original checklist item:** Record every child and descendant under workload identity and generation.

- [ ] **UC-M03.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Child-tree registry”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C002-T02 · Change plan:** Break the source delivery for “Child-tree registry” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C002-T03 · Core artifact:** Create the “Child-tree registry” model, schema or inventory that realizes this source instruction: Record every child and descendant under workload identity and generation.
- [ ] **UC-M03.06-C002-T04 · Concrete realization:** Populate “Child-tree registry” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Child-tree registry” needed to preserve “A child is never managed solely by a stale PID”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C002-T06 · Dependency connection:** Connect the “Child-tree registry” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C002-T07 · Resource behavior:** Account for “Registry entries and stale-record retention” in “Child-tree registry”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C002-T08 · Delivery check:** Run the smallest real “Child-tree registry” path and its adverse fixture “A PID is reused after the original process exits”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C002-T09 · Patch review:** Review the “Child-tree registry” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C002-T10 · Delivery handoff:** Publish the “Child-tree registry” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A child is never managed solely by a stale PID. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Child-tree registry”; copy its required invariant exactly: “A child is never managed solely by a stale PID”.
- [ ] **UC-M03.06-C003-T02 · Observable terms:** Define each term in the “Child-tree registry” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C003-T03 · Precondition set:** List the preconditions under which “A child is never managed solely by a stale PID” must hold for “Child-tree registry”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C003-T04 · Transition coverage:** Map the “Child-tree registry” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Child-tree registry”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C003-T06 · Satisfying fixture:** Create a concrete “Child-tree registry” case that satisfies “A child is never managed solely by a stale PID”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C003-T07 · Violating fixture:** Create the source counterexample “A PID is reused after the original process exits” for “Child-tree registry”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C003-T08 · Enforcement evidence:** Exercise the “Child-tree registry” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C003-T09 · Regression linkage:** Link the “Child-tree registry” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Child-tree registry” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C004 · Integration

**Original checklist item:** Integrate child-tree registry with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Child-tree registry” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C004-T02 · Field mapping:** Map every “Child-tree registry” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Child-tree registry” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C004-T04 · Ownership agreement:** Specify who owns “Child-tree registry” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C004-T05 · Handoff implementation:** Connect “Child-tree registry” through the mapped seam using the real adapter or explicit specification reference; preserve “A child is never managed solely by a stale PID” across the handoff.
- [ ] **UC-M03.06-C004-T06 · Absent-input case:** Omit one required “Child-tree registry” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C004-T07 · Stale-input case:** Supply an outdated “Child-tree registry” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Child-tree registry” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C004-T09 · Valid integration trace:** Run a valid “Child-tree registry” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C004-T10 · Seam review:** Reconcile the “Child-tree registry” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for child-tree registry; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Child-tree registry” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C005-T02 · Expected-result oracle:** Specify the “Child-tree registry” expected result independently of the implementation output; include the property “A child is never managed solely by a stale PID” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C005-T03 · Fixture material:** Create the concrete “Child-tree registry” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C005-T04 · Target preparation:** Prepare the “Child-tree registry” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C005-T05 · Initial-state record:** Record the initial “Child-tree registry” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C005-T06 · Valid-path execution:** Execute the “Child-tree registry” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C005-T07 · Outcome comparison:** Compare every declared “Child-tree registry” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C005-T08 · State and bounds check:** Inspect the “Child-tree registry” ownership/state effects and actual use of “Registry entries and stale-record retention”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C005-T09 · Repeatability check:** Repeat the same “Child-tree registry” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C005-T10 · Positive evidence:** Attach the “Child-tree registry” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C006 · Negative test

**Original checklist item:** Negative case: A PID is reused after the original process exits. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Child-tree registry” source counterexample: “A PID is reused after the original process exits”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Child-tree registry”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C006-T03 · Valid control:** Construct a valid “Child-tree registry” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C006-T04 · Minimal adverse input:** Derive the “Child-tree registry” adverse fixture from the control with the smallest documented change needed to reproduce “A PID is reused after the original process exits”; retain that change as reproducible data.
- [ ] **UC-M03.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Child-tree registry”; require “A child is never managed solely by a stale PID” and forbid a false-success verdict.
- [ ] **UC-M03.06-C006-T06 · Adverse execution:** Exercise the “Child-tree registry” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C006-T07 · Effect inspection:** Inspect “Child-tree registry” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C006-T08 · Refusal versus failure:** Confirm the “Child-tree registry” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C006-T09 · Reset and retention:** Restore only the disposable “Child-tree registry” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C006-T10 · Negative regression:** Register the “Child-tree registry” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C007 · Change / failure test

**Original checklist item:** Exercise child-tree registry when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C007-T01 · Scenario record:** Write the “Child-tree registry” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “A child is never managed solely by a stale PID”.
- [ ] **UC-M03.06-C007-T02 · Baseline capture:** Create a known-valid “Child-tree registry” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C007-T03 · Injection map:** Locate the “Child-tree registry” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Child-tree registry” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C007-T05 · Controlled trigger:** Introduce the controlled “Child-tree registry” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C007-T06 · Intermediate inspection:** Inspect the “Child-tree registry” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Child-tree registry”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Child-tree registry” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C007-T09 · Repeat and compare:** Repeat the selected “Child-tree registry” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C007-T10 · Failure evidence:** Publish the “Child-tree registry” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for registry entries and stale-record retention; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Child-tree registry”: “Registry entries and stale-record retention”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C008-T02 · Measurement method:** Choose how to observe each “Child-tree registry” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Child-tree registry”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Child-tree registry” cases for “Registry entries and stale-record retention”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Child-tree registry” limit; preserve “A child is never managed solely by a stale PID”.
- [ ] **UC-M03.06-C008-T06 · Normal measurement:** Run or review the normal “Child-tree registry” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C008-T07 · At-limit measurement:** Exercise the “Child-tree registry” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C008-T08 · Over-limit measurement:** Exercise the “Child-tree registry” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C008-T09 · Uncovered-scope report:** List the “Child-tree registry” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C008-T10 · Limit evidence:** Publish the selected “Child-tree registry” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for child-tree registry with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C009-T01 · Event inventory:** List the “Child-tree registry” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Child-tree registry” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C009-T03 · Failure mapping:** Map each documented “Child-tree registry” refusal or error to a diagnostic outcome; include “A PID is reused after the original process exits” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C009-T04 · Emission path:** Add the “Child-tree registry” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C009-T05 · Redaction check:** Test “Child-tree registry” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C009-T06 · Output budget:** Set and exercise bounded “Child-tree registry” message size, rate and retention compatible with “Registry entries and stale-record retention”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C009-T07 · Success/refusal fixtures:** Capture “Child-tree registry” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Child-tree registry” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C009-T09 · Operator review:** Read the “Child-tree registry” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C009-T10 · Diagnostic evidence:** Publish redacted “Child-tree registry” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for child-tree registry; label unexecuted checks as untested.

- [ ] **UC-M03.06-C010-T01 · Evidence inventory:** List the “Child-tree registry” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C010-T02 · Artifact references:** Record the exact “Child-tree registry” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C010-T03 · Fixture references:** Attach the “Child-tree registry” fixture IDs, input identities and oracle definition; preserve the source counterexample “A PID is reused after the original process exits” as a distinct evidence case.
- [ ] **UC-M03.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Child-tree registry”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C010-T05 · Environment record:** Record the actual “Child-tree registry” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C010-T06 · Expected versus observed:** Pair every “Child-tree registry” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C010-T07 · Failure and limit records:** Attach “Child-tree registry” change/failure and bounds evidence where required; include uncovered “Registry entries and stale-record retention” and unresolved violations of “A child is never managed solely by a stale PID”.
- [ ] **UC-M03.06-C010-T08 · Evidence hygiene:** Check the “Child-tree registry” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C010-T09 · Reproduction review:** Have the “Child-tree registry” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C010-T10 · Acceptance linkage:** Link the “Child-tree registry” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Launch ownership

**Source delivery:** Publish process ownership before accepting runtime results.

**Source invariant:** Unregistered children cannot publish trusted outcomes.

**Source negative case:** A process emits results before its generation is registered.

**Source bounded quantities:** Launch concurrency and registration deadline.

### UC-M03.06-C011 · Contract

**Original checklist item:** Specify launch ownership inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C011-T01 · Scope statement:** Draft the operation boundary for “Launch ownership” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Launch ownership”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C011-T03 · Output inventory:** List the outputs of “Launch ownership” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Launch ownership”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C011-T05 · Prerequisite contract:** Map “Launch ownership” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Launch ownership”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C011-T07 · Invariant clause:** Add a normative clause for “Launch ownership” that preserves “Unregistered children cannot publish trusted outcomes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Launch ownership”; include the source counterexample “A process emits results before its generation is registered” and the intended safe disposition.
- [ ] **UC-M03.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Launch concurrency and registration deadline” in the “Launch ownership” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C011-T10 · Contract review:** Review the “Launch ownership” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C012 · Delivery

**Original checklist item:** Publish process ownership before accepting runtime results.

- [ ] **UC-M03.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Launch ownership”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C012-T02 · Change plan:** Break the source delivery for “Launch ownership” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C012-T03 · Core artifact:** Create the “Launch ownership” output artifact for this source instruction: Publish process ownership before accepting runtime results.
- [ ] **UC-M03.06-C012-T04 · Concrete realization:** Populate the “Launch ownership” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M03.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Launch ownership” needed to preserve “Unregistered children cannot publish trusted outcomes”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C012-T06 · Dependency connection:** Connect the “Launch ownership” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C012-T07 · Resource behavior:** Account for “Launch concurrency and registration deadline” in “Launch ownership”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C012-T08 · Delivery check:** Run the smallest real “Launch ownership” path and its adverse fixture “A process emits results before its generation is registered”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C012-T09 · Patch review:** Review the “Launch ownership” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C012-T10 · Delivery handoff:** Publish the “Launch ownership” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unregistered children cannot publish trusted outcomes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Launch ownership”; copy its required invariant exactly: “Unregistered children cannot publish trusted outcomes”.
- [ ] **UC-M03.06-C013-T02 · Observable terms:** Define each term in the “Launch ownership” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C013-T03 · Precondition set:** List the preconditions under which “Unregistered children cannot publish trusted outcomes” must hold for “Launch ownership”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C013-T04 · Transition coverage:** Map the “Launch ownership” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Launch ownership”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C013-T06 · Satisfying fixture:** Create a concrete “Launch ownership” case that satisfies “Unregistered children cannot publish trusted outcomes”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C013-T07 · Violating fixture:** Create the source counterexample “A process emits results before its generation is registered” for “Launch ownership”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C013-T08 · Enforcement evidence:** Exercise the “Launch ownership” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C013-T09 · Regression linkage:** Link the “Launch ownership” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Launch ownership” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C014 · Integration

**Original checklist item:** Integrate launch ownership with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Launch ownership” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C014-T02 · Field mapping:** Map every “Launch ownership” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Launch ownership” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C014-T04 · Ownership agreement:** Specify who owns “Launch ownership” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C014-T05 · Handoff implementation:** Connect “Launch ownership” through the mapped seam using the real adapter or explicit specification reference; preserve “Unregistered children cannot publish trusted outcomes” across the handoff.
- [ ] **UC-M03.06-C014-T06 · Absent-input case:** Omit one required “Launch ownership” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C014-T07 · Stale-input case:** Supply an outdated “Launch ownership” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Launch ownership” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C014-T09 · Valid integration trace:** Run a valid “Launch ownership” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C014-T10 · Seam review:** Reconcile the “Launch ownership” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for launch ownership; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Launch ownership” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C015-T02 · Expected-result oracle:** Specify the “Launch ownership” expected result independently of the implementation output; include the property “Unregistered children cannot publish trusted outcomes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C015-T03 · Fixture material:** Create the concrete “Launch ownership” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C015-T04 · Target preparation:** Prepare the “Launch ownership” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C015-T05 · Initial-state record:** Record the initial “Launch ownership” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C015-T06 · Valid-path execution:** Execute the “Launch ownership” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C015-T07 · Outcome comparison:** Compare every declared “Launch ownership” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C015-T08 · State and bounds check:** Inspect the “Launch ownership” ownership/state effects and actual use of “Launch concurrency and registration deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C015-T09 · Repeatability check:** Repeat the same “Launch ownership” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C015-T10 · Positive evidence:** Attach the “Launch ownership” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C016 · Negative test

**Original checklist item:** Negative case: A process emits results before its generation is registered. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Launch ownership” source counterexample: “A process emits results before its generation is registered”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Launch ownership”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C016-T03 · Valid control:** Construct a valid “Launch ownership” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C016-T04 · Minimal adverse input:** Derive the “Launch ownership” adverse fixture from the control with the smallest documented change needed to reproduce “A process emits results before its generation is registered”; retain that change as reproducible data.
- [ ] **UC-M03.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Launch ownership”; require “Unregistered children cannot publish trusted outcomes” and forbid a false-success verdict.
- [ ] **UC-M03.06-C016-T06 · Adverse execution:** Exercise the “Launch ownership” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C016-T07 · Effect inspection:** Inspect “Launch ownership” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C016-T08 · Refusal versus failure:** Confirm the “Launch ownership” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C016-T09 · Reset and retention:** Restore only the disposable “Launch ownership” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C016-T10 · Negative regression:** Register the “Launch ownership” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C017 · Change / failure test

**Original checklist item:** Exercise launch ownership when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C017-T01 · Scenario record:** Write the “Launch ownership” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “Unregistered children cannot publish trusted outcomes”.
- [ ] **UC-M03.06-C017-T02 · Baseline capture:** Create a known-valid “Launch ownership” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C017-T03 · Injection map:** Locate the “Launch ownership” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Launch ownership” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C017-T05 · Controlled trigger:** Introduce the controlled “Launch ownership” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C017-T06 · Intermediate inspection:** Inspect the “Launch ownership” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Launch ownership”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Launch ownership” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C017-T09 · Repeat and compare:** Repeat the selected “Launch ownership” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C017-T10 · Failure evidence:** Publish the “Launch ownership” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for launch concurrency and registration deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Launch ownership”: “Launch concurrency and registration deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C018-T02 · Measurement method:** Choose how to observe each “Launch ownership” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Launch ownership”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Launch ownership” cases for “Launch concurrency and registration deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Launch ownership” limit; preserve “Unregistered children cannot publish trusted outcomes”.
- [ ] **UC-M03.06-C018-T06 · Normal measurement:** Run or review the normal “Launch ownership” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C018-T07 · At-limit measurement:** Exercise the “Launch ownership” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C018-T08 · Over-limit measurement:** Exercise the “Launch ownership” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C018-T09 · Uncovered-scope report:** List the “Launch ownership” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C018-T10 · Limit evidence:** Publish the selected “Launch ownership” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for launch ownership with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C019-T01 · Event inventory:** List the “Launch ownership” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Launch ownership” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C019-T03 · Failure mapping:** Map each documented “Launch ownership” refusal or error to a diagnostic outcome; include “A process emits results before its generation is registered” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C019-T04 · Emission path:** Add the “Launch ownership” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C019-T05 · Redaction check:** Test “Launch ownership” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C019-T06 · Output budget:** Set and exercise bounded “Launch ownership” message size, rate and retention compatible with “Launch concurrency and registration deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C019-T07 · Success/refusal fixtures:** Capture “Launch ownership” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Launch ownership” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C019-T09 · Operator review:** Read the “Launch ownership” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C019-T10 · Diagnostic evidence:** Publish redacted “Launch ownership” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for launch ownership; label unexecuted checks as untested.

- [ ] **UC-M03.06-C020-T01 · Evidence inventory:** List the “Launch ownership” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C020-T02 · Artifact references:** Record the exact “Launch ownership” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C020-T03 · Fixture references:** Attach the “Launch ownership” fixture IDs, input identities and oracle definition; preserve the source counterexample “A process emits results before its generation is registered” as a distinct evidence case.
- [ ] **UC-M03.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Launch ownership”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C020-T05 · Environment record:** Record the actual “Launch ownership” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C020-T06 · Expected versus observed:** Pair every “Launch ownership” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C020-T07 · Failure and limit records:** Attach “Launch ownership” change/failure and bounds evidence where required; include uncovered “Launch concurrency and registration deadline” and unresolved violations of “Unregistered children cannot publish trusted outcomes”.
- [ ] **UC-M03.06-C020-T08 · Evidence hygiene:** Check the “Launch ownership” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C020-T09 · Reproduction review:** Have the “Launch ownership” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C020-T10 · Acceptance linkage:** Link the “Launch ownership” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Execution deadlines

**Source delivery:** Enforce deadlines independently of cooperative guest behavior.

**Source invariant:** A non-terminating workload eventually reaches a definitive disposition.

**Source negative case:** A child ignores guest-level cancellation indefinitely.

**Source bounded quantities:** Deadline range and timeout-check interval.

### UC-M03.06-C021 · Contract

**Original checklist item:** Specify execution deadlines inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C021-T01 · Scope statement:** Draft the operation boundary for “Execution deadlines” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Execution deadlines”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C021-T03 · Output inventory:** List the outputs of “Execution deadlines” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Execution deadlines”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C021-T05 · Prerequisite contract:** Map “Execution deadlines” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Execution deadlines”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C021-T07 · Invariant clause:** Add a normative clause for “Execution deadlines” that preserves “A non-terminating workload eventually reaches a definitive disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Execution deadlines”; include the source counterexample “A child ignores guest-level cancellation indefinitely” and the intended safe disposition.
- [ ] **UC-M03.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Deadline range and timeout-check interval” in the “Execution deadlines” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C021-T10 · Contract review:** Review the “Execution deadlines” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C022 · Delivery

**Original checklist item:** Enforce deadlines independently of cooperative guest behavior.

- [ ] **UC-M03.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Execution deadlines”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C022-T02 · Change plan:** Break the source delivery for “Execution deadlines” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Execution deadlines” that realizes this source instruction: Enforce deadlines independently of cooperative guest behavior.
- [ ] **UC-M03.06-C022-T04 · Concrete realization:** Trace “Execution deadlines” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Execution deadlines” needed to preserve “A non-terminating workload eventually reaches a definitive disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C022-T06 · Dependency connection:** Connect the “Execution deadlines” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C022-T07 · Resource behavior:** Account for “Deadline range and timeout-check interval” in “Execution deadlines”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C022-T08 · Delivery check:** Run the smallest real “Execution deadlines” path and its adverse fixture “A child ignores guest-level cancellation indefinitely”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C022-T09 · Patch review:** Review the “Execution deadlines” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C022-T10 · Delivery handoff:** Publish the “Execution deadlines” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A non-terminating workload eventually reaches a definitive disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Execution deadlines”; copy its required invariant exactly: “A non-terminating workload eventually reaches a definitive disposition”.
- [ ] **UC-M03.06-C023-T02 · Observable terms:** Define each term in the “Execution deadlines” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C023-T03 · Precondition set:** List the preconditions under which “A non-terminating workload eventually reaches a definitive disposition” must hold for “Execution deadlines”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C023-T04 · Transition coverage:** Map the “Execution deadlines” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Execution deadlines”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C023-T06 · Satisfying fixture:** Create a concrete “Execution deadlines” case that satisfies “A non-terminating workload eventually reaches a definitive disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C023-T07 · Violating fixture:** Create the source counterexample “A child ignores guest-level cancellation indefinitely” for “Execution deadlines”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C023-T08 · Enforcement evidence:** Exercise the “Execution deadlines” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C023-T09 · Regression linkage:** Link the “Execution deadlines” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Execution deadlines” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C024 · Integration

**Original checklist item:** Integrate execution deadlines with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Execution deadlines” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C024-T02 · Field mapping:** Map every “Execution deadlines” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Execution deadlines” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C024-T04 · Ownership agreement:** Specify who owns “Execution deadlines” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C024-T05 · Handoff implementation:** Connect “Execution deadlines” through the mapped seam using the real adapter or explicit specification reference; preserve “A non-terminating workload eventually reaches a definitive disposition” across the handoff.
- [ ] **UC-M03.06-C024-T06 · Absent-input case:** Omit one required “Execution deadlines” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C024-T07 · Stale-input case:** Supply an outdated “Execution deadlines” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Execution deadlines” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C024-T09 · Valid integration trace:** Run a valid “Execution deadlines” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C024-T10 · Seam review:** Reconcile the “Execution deadlines” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for execution deadlines; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Execution deadlines” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C025-T02 · Expected-result oracle:** Specify the “Execution deadlines” expected result independently of the implementation output; include the property “A non-terminating workload eventually reaches a definitive disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C025-T03 · Fixture material:** Create the concrete “Execution deadlines” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C025-T04 · Target preparation:** Prepare the “Execution deadlines” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C025-T05 · Initial-state record:** Record the initial “Execution deadlines” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C025-T06 · Valid-path execution:** Execute the “Execution deadlines” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C025-T07 · Outcome comparison:** Compare every declared “Execution deadlines” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C025-T08 · State and bounds check:** Inspect the “Execution deadlines” ownership/state effects and actual use of “Deadline range and timeout-check interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C025-T09 · Repeatability check:** Repeat the same “Execution deadlines” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C025-T10 · Positive evidence:** Attach the “Execution deadlines” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C026 · Negative test

**Original checklist item:** Negative case: A child ignores guest-level cancellation indefinitely. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Execution deadlines” source counterexample: “A child ignores guest-level cancellation indefinitely”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Execution deadlines”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C026-T03 · Valid control:** Construct a valid “Execution deadlines” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C026-T04 · Minimal adverse input:** Derive the “Execution deadlines” adverse fixture from the control with the smallest documented change needed to reproduce “A child ignores guest-level cancellation indefinitely”; retain that change as reproducible data.
- [ ] **UC-M03.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Execution deadlines”; require “A non-terminating workload eventually reaches a definitive disposition” and forbid a false-success verdict.
- [ ] **UC-M03.06-C026-T06 · Adverse execution:** Exercise the “Execution deadlines” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C026-T07 · Effect inspection:** Inspect “Execution deadlines” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C026-T08 · Refusal versus failure:** Confirm the “Execution deadlines” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C026-T09 · Reset and retention:** Restore only the disposable “Execution deadlines” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C026-T10 · Negative regression:** Register the “Execution deadlines” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C027 · Change / failure test

**Original checklist item:** Exercise execution deadlines when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C027-T01 · Scenario record:** Write the “Execution deadlines” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “A non-terminating workload eventually reaches a definitive disposition”.
- [ ] **UC-M03.06-C027-T02 · Baseline capture:** Create a known-valid “Execution deadlines” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C027-T03 · Injection map:** Locate the “Execution deadlines” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Execution deadlines” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C027-T05 · Controlled trigger:** Introduce the controlled “Execution deadlines” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C027-T06 · Intermediate inspection:** Inspect the “Execution deadlines” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Execution deadlines”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Execution deadlines” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C027-T09 · Repeat and compare:** Repeat the selected “Execution deadlines” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C027-T10 · Failure evidence:** Publish the “Execution deadlines” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for deadline range and timeout-check interval; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Execution deadlines”: “Deadline range and timeout-check interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C028-T02 · Measurement method:** Choose how to observe each “Execution deadlines” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Execution deadlines”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Execution deadlines” cases for “Deadline range and timeout-check interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Execution deadlines” limit; preserve “A non-terminating workload eventually reaches a definitive disposition”.
- [ ] **UC-M03.06-C028-T06 · Normal measurement:** Run or review the normal “Execution deadlines” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C028-T07 · At-limit measurement:** Exercise the “Execution deadlines” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C028-T08 · Over-limit measurement:** Exercise the “Execution deadlines” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C028-T09 · Uncovered-scope report:** List the “Execution deadlines” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C028-T10 · Limit evidence:** Publish the selected “Execution deadlines” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for execution deadlines with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C029-T01 · Event inventory:** List the “Execution deadlines” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Execution deadlines” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C029-T03 · Failure mapping:** Map each documented “Execution deadlines” refusal or error to a diagnostic outcome; include “A child ignores guest-level cancellation indefinitely” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C029-T04 · Emission path:** Add the “Execution deadlines” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C029-T05 · Redaction check:** Test “Execution deadlines” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C029-T06 · Output budget:** Set and exercise bounded “Execution deadlines” message size, rate and retention compatible with “Deadline range and timeout-check interval”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C029-T07 · Success/refusal fixtures:** Capture “Execution deadlines” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Execution deadlines” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C029-T09 · Operator review:** Read the “Execution deadlines” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C029-T10 · Diagnostic evidence:** Publish redacted “Execution deadlines” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for execution deadlines; label unexecuted checks as untested.

- [ ] **UC-M03.06-C030-T01 · Evidence inventory:** List the “Execution deadlines” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C030-T02 · Artifact references:** Record the exact “Execution deadlines” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C030-T03 · Fixture references:** Attach the “Execution deadlines” fixture IDs, input identities and oracle definition; preserve the source counterexample “A child ignores guest-level cancellation indefinitely” as a distinct evidence case.
- [ ] **UC-M03.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Execution deadlines”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C030-T05 · Environment record:** Record the actual “Execution deadlines” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C030-T06 · Expected versus observed:** Pair every “Execution deadlines” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C030-T07 · Failure and limit records:** Attach “Execution deadlines” change/failure and bounds evidence where required; include uncovered “Deadline range and timeout-check interval” and unresolved violations of “A non-terminating workload eventually reaches a definitive disposition”.
- [ ] **UC-M03.06-C030-T08 · Evidence hygiene:** Check the “Execution deadlines” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C030-T09 · Reproduction review:** Have the “Execution deadlines” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C030-T10 · Acceptance linkage:** Link the “Execution deadlines” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Bounded stream capture

**Source delivery:** Read stdout and stderr with explicit byte and retention limits.

**Source invariant:** Output collection cannot block cleanup or exhaust resources.

**Source negative case:** A child writes continuously to both output streams.

**Source bounded quantities:** Buffer bytes and retained tail size.

### UC-M03.06-C031 · Contract

**Original checklist item:** Specify bounded stream capture inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C031-T01 · Scope statement:** Draft the operation boundary for “Bounded stream capture” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Bounded stream capture”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C031-T03 · Output inventory:** List the outputs of “Bounded stream capture” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Bounded stream capture”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C031-T05 · Prerequisite contract:** Map “Bounded stream capture” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Bounded stream capture”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C031-T07 · Invariant clause:** Add a normative clause for “Bounded stream capture” that preserves “Output collection cannot block cleanup or exhaust resources”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Bounded stream capture”; include the source counterexample “A child writes continuously to both output streams” and the intended safe disposition.
- [ ] **UC-M03.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Buffer bytes and retained tail size” in the “Bounded stream capture” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C031-T10 · Contract review:** Review the “Bounded stream capture” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C032 · Delivery

**Original checklist item:** Read stdout and stderr with explicit byte and retention limits.

- [ ] **UC-M03.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Bounded stream capture”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C032-T02 · Change plan:** Break the source delivery for “Bounded stream capture” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Bounded stream capture” that realizes this source instruction: Read stdout and stderr with explicit byte and retention limits.
- [ ] **UC-M03.06-C032-T04 · Concrete realization:** Trace “Bounded stream capture” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Bounded stream capture” needed to preserve “Output collection cannot block cleanup or exhaust resources”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C032-T06 · Dependency connection:** Connect the “Bounded stream capture” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C032-T07 · Resource behavior:** Account for “Buffer bytes and retained tail size” in “Bounded stream capture”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C032-T08 · Delivery check:** Run the smallest real “Bounded stream capture” path and its adverse fixture “A child writes continuously to both output streams”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C032-T09 · Patch review:** Review the “Bounded stream capture” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C032-T10 · Delivery handoff:** Publish the “Bounded stream capture” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Output collection cannot block cleanup or exhaust resources. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Bounded stream capture”; copy its required invariant exactly: “Output collection cannot block cleanup or exhaust resources”.
- [ ] **UC-M03.06-C033-T02 · Observable terms:** Define each term in the “Bounded stream capture” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C033-T03 · Precondition set:** List the preconditions under which “Output collection cannot block cleanup or exhaust resources” must hold for “Bounded stream capture”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C033-T04 · Transition coverage:** Map the “Bounded stream capture” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Bounded stream capture”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C033-T06 · Satisfying fixture:** Create a concrete “Bounded stream capture” case that satisfies “Output collection cannot block cleanup or exhaust resources”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C033-T07 · Violating fixture:** Create the source counterexample “A child writes continuously to both output streams” for “Bounded stream capture”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C033-T08 · Enforcement evidence:** Exercise the “Bounded stream capture” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C033-T09 · Regression linkage:** Link the “Bounded stream capture” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Bounded stream capture” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C034 · Integration

**Original checklist item:** Integrate bounded stream capture with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Bounded stream capture” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C034-T02 · Field mapping:** Map every “Bounded stream capture” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Bounded stream capture” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C034-T04 · Ownership agreement:** Specify who owns “Bounded stream capture” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C034-T05 · Handoff implementation:** Connect “Bounded stream capture” through the mapped seam using the real adapter or explicit specification reference; preserve “Output collection cannot block cleanup or exhaust resources” across the handoff.
- [ ] **UC-M03.06-C034-T06 · Absent-input case:** Omit one required “Bounded stream capture” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C034-T07 · Stale-input case:** Supply an outdated “Bounded stream capture” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Bounded stream capture” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C034-T09 · Valid integration trace:** Run a valid “Bounded stream capture” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C034-T10 · Seam review:** Reconcile the “Bounded stream capture” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for bounded stream capture; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Bounded stream capture” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C035-T02 · Expected-result oracle:** Specify the “Bounded stream capture” expected result independently of the implementation output; include the property “Output collection cannot block cleanup or exhaust resources” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C035-T03 · Fixture material:** Create the concrete “Bounded stream capture” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C035-T04 · Target preparation:** Prepare the “Bounded stream capture” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C035-T05 · Initial-state record:** Record the initial “Bounded stream capture” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C035-T06 · Valid-path execution:** Execute the “Bounded stream capture” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C035-T07 · Outcome comparison:** Compare every declared “Bounded stream capture” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C035-T08 · State and bounds check:** Inspect the “Bounded stream capture” ownership/state effects and actual use of “Buffer bytes and retained tail size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C035-T09 · Repeatability check:** Repeat the same “Bounded stream capture” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C035-T10 · Positive evidence:** Attach the “Bounded stream capture” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C036 · Negative test

**Original checklist item:** Negative case: A child writes continuously to both output streams. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Bounded stream capture” source counterexample: “A child writes continuously to both output streams”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Bounded stream capture”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C036-T03 · Valid control:** Construct a valid “Bounded stream capture” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C036-T04 · Minimal adverse input:** Derive the “Bounded stream capture” adverse fixture from the control with the smallest documented change needed to reproduce “A child writes continuously to both output streams”; retain that change as reproducible data.
- [ ] **UC-M03.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Bounded stream capture”; require “Output collection cannot block cleanup or exhaust resources” and forbid a false-success verdict.
- [ ] **UC-M03.06-C036-T06 · Adverse execution:** Exercise the “Bounded stream capture” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C036-T07 · Effect inspection:** Inspect “Bounded stream capture” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C036-T08 · Refusal versus failure:** Confirm the “Bounded stream capture” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C036-T09 · Reset and retention:** Restore only the disposable “Bounded stream capture” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C036-T10 · Negative regression:** Register the “Bounded stream capture” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C037 · Change / failure test

**Original checklist item:** Exercise bounded stream capture when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C037-T01 · Scenario record:** Write the “Bounded stream capture” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “Output collection cannot block cleanup or exhaust resources”.
- [ ] **UC-M03.06-C037-T02 · Baseline capture:** Create a known-valid “Bounded stream capture” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C037-T03 · Injection map:** Locate the “Bounded stream capture” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Bounded stream capture” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C037-T05 · Controlled trigger:** Introduce the controlled “Bounded stream capture” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C037-T06 · Intermediate inspection:** Inspect the “Bounded stream capture” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Bounded stream capture”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Bounded stream capture” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C037-T09 · Repeat and compare:** Repeat the selected “Bounded stream capture” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C037-T10 · Failure evidence:** Publish the “Bounded stream capture” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for buffer bytes and retained tail size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Bounded stream capture”: “Buffer bytes and retained tail size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C038-T02 · Measurement method:** Choose how to observe each “Bounded stream capture” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Bounded stream capture”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Bounded stream capture” cases for “Buffer bytes and retained tail size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Bounded stream capture” limit; preserve “Output collection cannot block cleanup or exhaust resources”.
- [ ] **UC-M03.06-C038-T06 · Normal measurement:** Run or review the normal “Bounded stream capture” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C038-T07 · At-limit measurement:** Exercise the “Bounded stream capture” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C038-T08 · Over-limit measurement:** Exercise the “Bounded stream capture” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C038-T09 · Uncovered-scope report:** List the “Bounded stream capture” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C038-T10 · Limit evidence:** Publish the selected “Bounded stream capture” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for bounded stream capture with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C039-T01 · Event inventory:** List the “Bounded stream capture” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Bounded stream capture” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C039-T03 · Failure mapping:** Map each documented “Bounded stream capture” refusal or error to a diagnostic outcome; include “A child writes continuously to both output streams” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C039-T04 · Emission path:** Add the “Bounded stream capture” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C039-T05 · Redaction check:** Test “Bounded stream capture” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C039-T06 · Output budget:** Set and exercise bounded “Bounded stream capture” message size, rate and retention compatible with “Buffer bytes and retained tail size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C039-T07 · Success/refusal fixtures:** Capture “Bounded stream capture” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Bounded stream capture” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C039-T09 · Operator review:** Read the “Bounded stream capture” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C039-T10 · Diagnostic evidence:** Publish redacted “Bounded stream capture” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for bounded stream capture; label unexecuted checks as untested.

- [ ] **UC-M03.06-C040-T01 · Evidence inventory:** List the “Bounded stream capture” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C040-T02 · Artifact references:** Record the exact “Bounded stream capture” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C040-T03 · Fixture references:** Attach the “Bounded stream capture” fixture IDs, input identities and oracle definition; preserve the source counterexample “A child writes continuously to both output streams” as a distinct evidence case.
- [ ] **UC-M03.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Bounded stream capture”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C040-T05 · Environment record:** Record the actual “Bounded stream capture” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C040-T06 · Expected versus observed:** Pair every “Bounded stream capture” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C040-T07 · Failure and limit records:** Attach “Bounded stream capture” change/failure and bounds evidence where required; include uncovered “Buffer bytes and retained tail size” and unresolved violations of “Output collection cannot block cleanup or exhaust resources”.
- [ ] **UC-M03.06-C040-T08 · Evidence hygiene:** Check the “Bounded stream capture” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C040-T09 · Reproduction review:** Have the “Bounded stream capture” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C040-T10 · Acceptance linkage:** Link the “Bounded stream capture” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Tree-wide termination

**Source delivery:** Terminate the complete owned descendant tree when required.

**Source invariant:** Timeout cleanup leaves no executable descendant.

**Source negative case:** A grandchild survives after its direct parent exits.

**Source bounded quantities:** Descendant depth and termination deadline.

### UC-M03.06-C041 · Contract

**Original checklist item:** Specify tree-wide termination inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C041-T01 · Scope statement:** Draft the operation boundary for “Tree-wide termination” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Tree-wide termination”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C041-T03 · Output inventory:** List the outputs of “Tree-wide termination” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Tree-wide termination”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C041-T05 · Prerequisite contract:** Map “Tree-wide termination” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Tree-wide termination”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C041-T07 · Invariant clause:** Add a normative clause for “Tree-wide termination” that preserves “Timeout cleanup leaves no executable descendant”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Tree-wide termination”; include the source counterexample “A grandchild survives after its direct parent exits” and the intended safe disposition.
- [ ] **UC-M03.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Descendant depth and termination deadline” in the “Tree-wide termination” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C041-T10 · Contract review:** Review the “Tree-wide termination” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C042 · Delivery

**Original checklist item:** Terminate the complete owned descendant tree when required.

- [ ] **UC-M03.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Tree-wide termination”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C042-T02 · Change plan:** Break the source delivery for “Tree-wide termination” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Tree-wide termination” that realizes this source instruction: Terminate the complete owned descendant tree when required.
- [ ] **UC-M03.06-C042-T04 · Concrete realization:** Trace “Tree-wide termination” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Tree-wide termination” needed to preserve “Timeout cleanup leaves no executable descendant”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C042-T06 · Dependency connection:** Connect the “Tree-wide termination” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C042-T07 · Resource behavior:** Account for “Descendant depth and termination deadline” in “Tree-wide termination”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C042-T08 · Delivery check:** Run the smallest real “Tree-wide termination” path and its adverse fixture “A grandchild survives after its direct parent exits”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C042-T09 · Patch review:** Review the “Tree-wide termination” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C042-T10 · Delivery handoff:** Publish the “Tree-wide termination” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Timeout cleanup leaves no executable descendant. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Tree-wide termination”; copy its required invariant exactly: “Timeout cleanup leaves no executable descendant”.
- [ ] **UC-M03.06-C043-T02 · Observable terms:** Define each term in the “Tree-wide termination” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C043-T03 · Precondition set:** List the preconditions under which “Timeout cleanup leaves no executable descendant” must hold for “Tree-wide termination”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C043-T04 · Transition coverage:** Map the “Tree-wide termination” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Tree-wide termination”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C043-T06 · Satisfying fixture:** Create a concrete “Tree-wide termination” case that satisfies “Timeout cleanup leaves no executable descendant”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C043-T07 · Violating fixture:** Create the source counterexample “A grandchild survives after its direct parent exits” for “Tree-wide termination”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C043-T08 · Enforcement evidence:** Exercise the “Tree-wide termination” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C043-T09 · Regression linkage:** Link the “Tree-wide termination” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Tree-wide termination” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C044 · Integration

**Original checklist item:** Integrate tree-wide termination with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Tree-wide termination” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C044-T02 · Field mapping:** Map every “Tree-wide termination” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Tree-wide termination” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C044-T04 · Ownership agreement:** Specify who owns “Tree-wide termination” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C044-T05 · Handoff implementation:** Connect “Tree-wide termination” through the mapped seam using the real adapter or explicit specification reference; preserve “Timeout cleanup leaves no executable descendant” across the handoff.
- [ ] **UC-M03.06-C044-T06 · Absent-input case:** Omit one required “Tree-wide termination” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C044-T07 · Stale-input case:** Supply an outdated “Tree-wide termination” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Tree-wide termination” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C044-T09 · Valid integration trace:** Run a valid “Tree-wide termination” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C044-T10 · Seam review:** Reconcile the “Tree-wide termination” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for tree-wide termination; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Tree-wide termination” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C045-T02 · Expected-result oracle:** Specify the “Tree-wide termination” expected result independently of the implementation output; include the property “Timeout cleanup leaves no executable descendant” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C045-T03 · Fixture material:** Create the concrete “Tree-wide termination” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C045-T04 · Target preparation:** Prepare the “Tree-wide termination” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C045-T05 · Initial-state record:** Record the initial “Tree-wide termination” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C045-T06 · Valid-path execution:** Execute the “Tree-wide termination” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C045-T07 · Outcome comparison:** Compare every declared “Tree-wide termination” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C045-T08 · State and bounds check:** Inspect the “Tree-wide termination” ownership/state effects and actual use of “Descendant depth and termination deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C045-T09 · Repeatability check:** Repeat the same “Tree-wide termination” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C045-T10 · Positive evidence:** Attach the “Tree-wide termination” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C046 · Negative test

**Original checklist item:** Negative case: A grandchild survives after its direct parent exits. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Tree-wide termination” source counterexample: “A grandchild survives after its direct parent exits”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Tree-wide termination”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C046-T03 · Valid control:** Construct a valid “Tree-wide termination” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C046-T04 · Minimal adverse input:** Derive the “Tree-wide termination” adverse fixture from the control with the smallest documented change needed to reproduce “A grandchild survives after its direct parent exits”; retain that change as reproducible data.
- [ ] **UC-M03.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Tree-wide termination”; require “Timeout cleanup leaves no executable descendant” and forbid a false-success verdict.
- [ ] **UC-M03.06-C046-T06 · Adverse execution:** Exercise the “Tree-wide termination” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C046-T07 · Effect inspection:** Inspect “Tree-wide termination” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C046-T08 · Refusal versus failure:** Confirm the “Tree-wide termination” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C046-T09 · Reset and retention:** Restore only the disposable “Tree-wide termination” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C046-T10 · Negative regression:** Register the “Tree-wide termination” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C047 · Change / failure test

**Original checklist item:** Exercise tree-wide termination when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C047-T01 · Scenario record:** Write the “Tree-wide termination” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “Timeout cleanup leaves no executable descendant”.
- [ ] **UC-M03.06-C047-T02 · Baseline capture:** Create a known-valid “Tree-wide termination” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C047-T03 · Injection map:** Locate the “Tree-wide termination” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Tree-wide termination” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C047-T05 · Controlled trigger:** Introduce the controlled “Tree-wide termination” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C047-T06 · Intermediate inspection:** Inspect the “Tree-wide termination” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Tree-wide termination”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Tree-wide termination” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C047-T09 · Repeat and compare:** Repeat the selected “Tree-wide termination” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C047-T10 · Failure evidence:** Publish the “Tree-wide termination” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for descendant depth and termination deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Tree-wide termination”: “Descendant depth and termination deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C048-T02 · Measurement method:** Choose how to observe each “Tree-wide termination” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C048-T03 · Budget decision:** Select justified resource and input limits for “Tree-wide termination”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Tree-wide termination” cases for “Descendant depth and termination deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Tree-wide termination” limit; preserve “Timeout cleanup leaves no executable descendant”.
- [ ] **UC-M03.06-C048-T06 · Normal measurement:** Run or review the normal “Tree-wide termination” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C048-T07 · At-limit measurement:** Exercise the “Tree-wide termination” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C048-T08 · Over-limit measurement:** Exercise the “Tree-wide termination” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C048-T09 · Uncovered-scope report:** List the “Tree-wide termination” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C048-T10 · Limit evidence:** Publish the selected “Tree-wide termination” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for tree-wide termination with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C049-T01 · Event inventory:** List the “Tree-wide termination” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Tree-wide termination” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C049-T03 · Failure mapping:** Map each documented “Tree-wide termination” refusal or error to a diagnostic outcome; include “A grandchild survives after its direct parent exits” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C049-T04 · Emission path:** Add the “Tree-wide termination” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C049-T05 · Redaction check:** Test “Tree-wide termination” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C049-T06 · Output budget:** Set and exercise bounded “Tree-wide termination” message size, rate and retention compatible with “Descendant depth and termination deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C049-T07 · Success/refusal fixtures:** Capture “Tree-wide termination” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Tree-wide termination” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C049-T09 · Operator review:** Read the “Tree-wide termination” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C049-T10 · Diagnostic evidence:** Publish redacted “Tree-wide termination” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for tree-wide termination; label unexecuted checks as untested.

- [ ] **UC-M03.06-C050-T01 · Evidence inventory:** List the “Tree-wide termination” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C050-T02 · Artifact references:** Record the exact “Tree-wide termination” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C050-T03 · Fixture references:** Attach the “Tree-wide termination” fixture IDs, input identities and oracle definition; preserve the source counterexample “A grandchild survives after its direct parent exits” as a distinct evidence case.
- [ ] **UC-M03.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Tree-wide termination”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C050-T05 · Environment record:** Record the actual “Tree-wide termination” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C050-T06 · Expected versus observed:** Pair every “Tree-wide termination” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C050-T07 · Failure and limit records:** Attach “Tree-wide termination” change/failure and bounds evidence where required; include uncovered “Descendant depth and termination deadline” and unresolved violations of “Timeout cleanup leaves no executable descendant”.
- [ ] **UC-M03.06-C050-T08 · Evidence hygiene:** Check the “Tree-wide termination” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C050-T09 · Reproduction review:** Have the “Tree-wide termination” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C050-T10 · Acceptance linkage:** Link the “Tree-wide termination” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Graceful-to-forced escalation

**Source delivery:** Attempt bounded cooperative shutdown before required forced termination.

**Source invariant:** Graceful stop cannot extend beyond its declared maximum.

**Source negative case:** A guest repeatedly acknowledges stop without exiting.

**Source bounded quantities:** Grace period and escalation attempts.

### UC-M03.06-C051 · Contract

**Original checklist item:** Specify graceful-to-forced escalation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C051-T01 · Scope statement:** Draft the operation boundary for “Graceful-to-forced escalation” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Graceful-to-forced escalation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C051-T03 · Output inventory:** List the outputs of “Graceful-to-forced escalation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Graceful-to-forced escalation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C051-T05 · Prerequisite contract:** Map “Graceful-to-forced escalation” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Graceful-to-forced escalation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C051-T07 · Invariant clause:** Add a normative clause for “Graceful-to-forced escalation” that preserves “Graceful stop cannot extend beyond its declared maximum”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Graceful-to-forced escalation”; include the source counterexample “A guest repeatedly acknowledges stop without exiting” and the intended safe disposition.
- [ ] **UC-M03.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Grace period and escalation attempts” in the “Graceful-to-forced escalation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C051-T10 · Contract review:** Review the “Graceful-to-forced escalation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C052 · Delivery

**Original checklist item:** Attempt bounded cooperative shutdown before required forced termination.

- [ ] **UC-M03.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Graceful-to-forced escalation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C052-T02 · Change plan:** Break the source delivery for “Graceful-to-forced escalation” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C052-T03 · Core artifact:** Create the “Graceful-to-forced escalation” fixture or harness for this source instruction: Attempt bounded cooperative shutdown before required forced termination.
- [ ] **UC-M03.06-C052-T04 · Concrete realization:** Connect the “Graceful-to-forced escalation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Graceful-to-forced escalation” needed to preserve “Graceful stop cannot extend beyond its declared maximum”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C052-T06 · Dependency connection:** Connect the “Graceful-to-forced escalation” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C052-T07 · Resource behavior:** Account for “Grace period and escalation attempts” in “Graceful-to-forced escalation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C052-T08 · Delivery check:** Run the smallest real “Graceful-to-forced escalation” path and its adverse fixture “A guest repeatedly acknowledges stop without exiting”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C052-T09 · Patch review:** Review the “Graceful-to-forced escalation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C052-T10 · Delivery handoff:** Publish the “Graceful-to-forced escalation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Graceful stop cannot extend beyond its declared maximum. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Graceful-to-forced escalation”; copy its required invariant exactly: “Graceful stop cannot extend beyond its declared maximum”.
- [ ] **UC-M03.06-C053-T02 · Observable terms:** Define each term in the “Graceful-to-forced escalation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C053-T03 · Precondition set:** List the preconditions under which “Graceful stop cannot extend beyond its declared maximum” must hold for “Graceful-to-forced escalation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C053-T04 · Transition coverage:** Map the “Graceful-to-forced escalation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Graceful-to-forced escalation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C053-T06 · Satisfying fixture:** Create a concrete “Graceful-to-forced escalation” case that satisfies “Graceful stop cannot extend beyond its declared maximum”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C053-T07 · Violating fixture:** Create the source counterexample “A guest repeatedly acknowledges stop without exiting” for “Graceful-to-forced escalation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C053-T08 · Enforcement evidence:** Exercise the “Graceful-to-forced escalation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C053-T09 · Regression linkage:** Link the “Graceful-to-forced escalation” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Graceful-to-forced escalation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C054 · Integration

**Original checklist item:** Integrate graceful-to-forced escalation with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Graceful-to-forced escalation” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C054-T02 · Field mapping:** Map every “Graceful-to-forced escalation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Graceful-to-forced escalation” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C054-T04 · Ownership agreement:** Specify who owns “Graceful-to-forced escalation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C054-T05 · Handoff implementation:** Connect “Graceful-to-forced escalation” through the mapped seam using the real adapter or explicit specification reference; preserve “Graceful stop cannot extend beyond its declared maximum” across the handoff.
- [ ] **UC-M03.06-C054-T06 · Absent-input case:** Omit one required “Graceful-to-forced escalation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C054-T07 · Stale-input case:** Supply an outdated “Graceful-to-forced escalation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Graceful-to-forced escalation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C054-T09 · Valid integration trace:** Run a valid “Graceful-to-forced escalation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C054-T10 · Seam review:** Reconcile the “Graceful-to-forced escalation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for graceful-to-forced escalation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Graceful-to-forced escalation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C055-T02 · Expected-result oracle:** Specify the “Graceful-to-forced escalation” expected result independently of the implementation output; include the property “Graceful stop cannot extend beyond its declared maximum” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C055-T03 · Fixture material:** Create the concrete “Graceful-to-forced escalation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C055-T04 · Target preparation:** Prepare the “Graceful-to-forced escalation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C055-T05 · Initial-state record:** Record the initial “Graceful-to-forced escalation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C055-T06 · Valid-path execution:** Execute the “Graceful-to-forced escalation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C055-T07 · Outcome comparison:** Compare every declared “Graceful-to-forced escalation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C055-T08 · State and bounds check:** Inspect the “Graceful-to-forced escalation” ownership/state effects and actual use of “Grace period and escalation attempts”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C055-T09 · Repeatability check:** Repeat the same “Graceful-to-forced escalation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C055-T10 · Positive evidence:** Attach the “Graceful-to-forced escalation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C056 · Negative test

**Original checklist item:** Negative case: A guest repeatedly acknowledges stop without exiting. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Graceful-to-forced escalation” source counterexample: “A guest repeatedly acknowledges stop without exiting”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Graceful-to-forced escalation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C056-T03 · Valid control:** Construct a valid “Graceful-to-forced escalation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C056-T04 · Minimal adverse input:** Derive the “Graceful-to-forced escalation” adverse fixture from the control with the smallest documented change needed to reproduce “A guest repeatedly acknowledges stop without exiting”; retain that change as reproducible data.
- [ ] **UC-M03.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Graceful-to-forced escalation”; require “Graceful stop cannot extend beyond its declared maximum” and forbid a false-success verdict.
- [ ] **UC-M03.06-C056-T06 · Adverse execution:** Exercise the “Graceful-to-forced escalation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C056-T07 · Effect inspection:** Inspect “Graceful-to-forced escalation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C056-T08 · Refusal versus failure:** Confirm the “Graceful-to-forced escalation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C056-T09 · Reset and retention:** Restore only the disposable “Graceful-to-forced escalation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C056-T10 · Negative regression:** Register the “Graceful-to-forced escalation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C057 · Change / failure test

**Original checklist item:** Exercise graceful-to-forced escalation when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C057-T01 · Scenario record:** Write the “Graceful-to-forced escalation” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “Graceful stop cannot extend beyond its declared maximum”.
- [ ] **UC-M03.06-C057-T02 · Baseline capture:** Create a known-valid “Graceful-to-forced escalation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C057-T03 · Injection map:** Locate the “Graceful-to-forced escalation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Graceful-to-forced escalation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C057-T05 · Controlled trigger:** Introduce the controlled “Graceful-to-forced escalation” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C057-T06 · Intermediate inspection:** Inspect the “Graceful-to-forced escalation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Graceful-to-forced escalation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Graceful-to-forced escalation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C057-T09 · Repeat and compare:** Repeat the selected “Graceful-to-forced escalation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C057-T10 · Failure evidence:** Publish the “Graceful-to-forced escalation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for grace period and escalation attempts; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Graceful-to-forced escalation”: “Grace period and escalation attempts”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C058-T02 · Measurement method:** Choose how to observe each “Graceful-to-forced escalation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C058-T03 · Budget decision:** Select justified resource and input limits for “Graceful-to-forced escalation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Graceful-to-forced escalation” cases for “Grace period and escalation attempts”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Graceful-to-forced escalation” limit; preserve “Graceful stop cannot extend beyond its declared maximum”.
- [ ] **UC-M03.06-C058-T06 · Normal measurement:** Run or review the normal “Graceful-to-forced escalation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C058-T07 · At-limit measurement:** Exercise the “Graceful-to-forced escalation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C058-T08 · Over-limit measurement:** Exercise the “Graceful-to-forced escalation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C058-T09 · Uncovered-scope report:** List the “Graceful-to-forced escalation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C058-T10 · Limit evidence:** Publish the selected “Graceful-to-forced escalation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for graceful-to-forced escalation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C059-T01 · Event inventory:** List the “Graceful-to-forced escalation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Graceful-to-forced escalation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C059-T03 · Failure mapping:** Map each documented “Graceful-to-forced escalation” refusal or error to a diagnostic outcome; include “A guest repeatedly acknowledges stop without exiting” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C059-T04 · Emission path:** Add the “Graceful-to-forced escalation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C059-T05 · Redaction check:** Test “Graceful-to-forced escalation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C059-T06 · Output budget:** Set and exercise bounded “Graceful-to-forced escalation” message size, rate and retention compatible with “Grace period and escalation attempts”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C059-T07 · Success/refusal fixtures:** Capture “Graceful-to-forced escalation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Graceful-to-forced escalation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C059-T09 · Operator review:** Read the “Graceful-to-forced escalation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C059-T10 · Diagnostic evidence:** Publish redacted “Graceful-to-forced escalation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for graceful-to-forced escalation; label unexecuted checks as untested.

- [ ] **UC-M03.06-C060-T01 · Evidence inventory:** List the “Graceful-to-forced escalation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C060-T02 · Artifact references:** Record the exact “Graceful-to-forced escalation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C060-T03 · Fixture references:** Attach the “Graceful-to-forced escalation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest repeatedly acknowledges stop without exiting” as a distinct evidence case.
- [ ] **UC-M03.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Graceful-to-forced escalation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C060-T05 · Environment record:** Record the actual “Graceful-to-forced escalation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C060-T06 · Expected versus observed:** Pair every “Graceful-to-forced escalation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C060-T07 · Failure and limit records:** Attach “Graceful-to-forced escalation” change/failure and bounds evidence where required; include uncovered “Grace period and escalation attempts” and unresolved violations of “Graceful stop cannot extend beyond its declared maximum”.
- [ ] **UC-M03.06-C060-T08 · Evidence hygiene:** Check the “Graceful-to-forced escalation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C060-T09 · Reproduction review:** Have the “Graceful-to-forced escalation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C060-T10 · Acceptance linkage:** Link the “Graceful-to-forced escalation” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Parent-crash handling

**Source delivery:** Define recovery and cleanup when the supervising process terminates.

**Source invariant:** A parent crash cannot leave permanently unowned executable guests.

**Source negative case:** The supervisor is killed while several children run.

**Source bounded quantities:** Recovery scan interval and orphan lifetime.

### UC-M03.06-C061 · Contract

**Original checklist item:** Specify parent-crash handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C061-T01 · Scope statement:** Draft the operation boundary for “Parent-crash handling” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Parent-crash handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C061-T03 · Output inventory:** List the outputs of “Parent-crash handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Parent-crash handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C061-T05 · Prerequisite contract:** Map “Parent-crash handling” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Parent-crash handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C061-T07 · Invariant clause:** Add a normative clause for “Parent-crash handling” that preserves “A parent crash cannot leave permanently unowned executable guests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Parent-crash handling”; include the source counterexample “The supervisor is killed while several children run” and the intended safe disposition.
- [ ] **UC-M03.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recovery scan interval and orphan lifetime” in the “Parent-crash handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C061-T10 · Contract review:** Review the “Parent-crash handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C062 · Delivery

**Original checklist item:** Define recovery and cleanup when the supervising process terminates.

- [ ] **UC-M03.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Parent-crash handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C062-T02 · Change plan:** Break the source delivery for “Parent-crash handling” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C062-T03 · Core artifact:** Create the “Parent-crash handling” model, schema or inventory that realizes this source instruction: Define recovery and cleanup when the supervising process terminates.
- [ ] **UC-M03.06-C062-T04 · Concrete realization:** Populate “Parent-crash handling” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Parent-crash handling” needed to preserve “A parent crash cannot leave permanently unowned executable guests”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C062-T06 · Dependency connection:** Connect the “Parent-crash handling” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C062-T07 · Resource behavior:** Account for “Recovery scan interval and orphan lifetime” in “Parent-crash handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C062-T08 · Delivery check:** Run the smallest real “Parent-crash handling” path and its adverse fixture “The supervisor is killed while several children run”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C062-T09 · Patch review:** Review the “Parent-crash handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C062-T10 · Delivery handoff:** Publish the “Parent-crash handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A parent crash cannot leave permanently unowned executable guests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Parent-crash handling”; copy its required invariant exactly: “A parent crash cannot leave permanently unowned executable guests”.
- [ ] **UC-M03.06-C063-T02 · Observable terms:** Define each term in the “Parent-crash handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C063-T03 · Precondition set:** List the preconditions under which “A parent crash cannot leave permanently unowned executable guests” must hold for “Parent-crash handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C063-T04 · Transition coverage:** Map the “Parent-crash handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Parent-crash handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C063-T06 · Satisfying fixture:** Create a concrete “Parent-crash handling” case that satisfies “A parent crash cannot leave permanently unowned executable guests”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C063-T07 · Violating fixture:** Create the source counterexample “The supervisor is killed while several children run” for “Parent-crash handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C063-T08 · Enforcement evidence:** Exercise the “Parent-crash handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C063-T09 · Regression linkage:** Link the “Parent-crash handling” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Parent-crash handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C064 · Integration

**Original checklist item:** Integrate parent-crash handling with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Parent-crash handling” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C064-T02 · Field mapping:** Map every “Parent-crash handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Parent-crash handling” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C064-T04 · Ownership agreement:** Specify who owns “Parent-crash handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C064-T05 · Handoff implementation:** Connect “Parent-crash handling” through the mapped seam using the real adapter or explicit specification reference; preserve “A parent crash cannot leave permanently unowned executable guests” across the handoff.
- [ ] **UC-M03.06-C064-T06 · Absent-input case:** Omit one required “Parent-crash handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C064-T07 · Stale-input case:** Supply an outdated “Parent-crash handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Parent-crash handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C064-T09 · Valid integration trace:** Run a valid “Parent-crash handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C064-T10 · Seam review:** Reconcile the “Parent-crash handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for parent-crash handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Parent-crash handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C065-T02 · Expected-result oracle:** Specify the “Parent-crash handling” expected result independently of the implementation output; include the property “A parent crash cannot leave permanently unowned executable guests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C065-T03 · Fixture material:** Create the concrete “Parent-crash handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C065-T04 · Target preparation:** Prepare the “Parent-crash handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C065-T05 · Initial-state record:** Record the initial “Parent-crash handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C065-T06 · Valid-path execution:** Execute the “Parent-crash handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C065-T07 · Outcome comparison:** Compare every declared “Parent-crash handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C065-T08 · State and bounds check:** Inspect the “Parent-crash handling” ownership/state effects and actual use of “Recovery scan interval and orphan lifetime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C065-T09 · Repeatability check:** Repeat the same “Parent-crash handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C065-T10 · Positive evidence:** Attach the “Parent-crash handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C066 · Negative test

**Original checklist item:** Negative case: The supervisor is killed while several children run. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Parent-crash handling” source counterexample: “The supervisor is killed while several children run”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Parent-crash handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C066-T03 · Valid control:** Construct a valid “Parent-crash handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C066-T04 · Minimal adverse input:** Derive the “Parent-crash handling” adverse fixture from the control with the smallest documented change needed to reproduce “The supervisor is killed while several children run”; retain that change as reproducible data.
- [ ] **UC-M03.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Parent-crash handling”; require “A parent crash cannot leave permanently unowned executable guests” and forbid a false-success verdict.
- [ ] **UC-M03.06-C066-T06 · Adverse execution:** Exercise the “Parent-crash handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C066-T07 · Effect inspection:** Inspect “Parent-crash handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C066-T08 · Refusal versus failure:** Confirm the “Parent-crash handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C066-T09 · Reset and retention:** Restore only the disposable “Parent-crash handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C066-T10 · Negative regression:** Register the “Parent-crash handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C067 · Change / failure test

**Original checklist item:** Exercise parent-crash handling when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C067-T01 · Scenario record:** Write the “Parent-crash handling” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “A parent crash cannot leave permanently unowned executable guests”.
- [ ] **UC-M03.06-C067-T02 · Baseline capture:** Create a known-valid “Parent-crash handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C067-T03 · Injection map:** Locate the “Parent-crash handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Parent-crash handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C067-T05 · Controlled trigger:** Introduce the controlled “Parent-crash handling” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C067-T06 · Intermediate inspection:** Inspect the “Parent-crash handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Parent-crash handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Parent-crash handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C067-T09 · Repeat and compare:** Repeat the selected “Parent-crash handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C067-T10 · Failure evidence:** Publish the “Parent-crash handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for recovery scan interval and orphan lifetime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Parent-crash handling”: “Recovery scan interval and orphan lifetime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C068-T02 · Measurement method:** Choose how to observe each “Parent-crash handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Parent-crash handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Parent-crash handling” cases for “Recovery scan interval and orphan lifetime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Parent-crash handling” limit; preserve “A parent crash cannot leave permanently unowned executable guests”.
- [ ] **UC-M03.06-C068-T06 · Normal measurement:** Run or review the normal “Parent-crash handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C068-T07 · At-limit measurement:** Exercise the “Parent-crash handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C068-T08 · Over-limit measurement:** Exercise the “Parent-crash handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C068-T09 · Uncovered-scope report:** List the “Parent-crash handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C068-T10 · Limit evidence:** Publish the selected “Parent-crash handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for parent-crash handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C069-T01 · Event inventory:** List the “Parent-crash handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Parent-crash handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C069-T03 · Failure mapping:** Map each documented “Parent-crash handling” refusal or error to a diagnostic outcome; include “The supervisor is killed while several children run” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C069-T04 · Emission path:** Add the “Parent-crash handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C069-T05 · Redaction check:** Test “Parent-crash handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C069-T06 · Output budget:** Set and exercise bounded “Parent-crash handling” message size, rate and retention compatible with “Recovery scan interval and orphan lifetime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C069-T07 · Success/refusal fixtures:** Capture “Parent-crash handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Parent-crash handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C069-T09 · Operator review:** Read the “Parent-crash handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C069-T10 · Diagnostic evidence:** Publish redacted “Parent-crash handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for parent-crash handling; label unexecuted checks as untested.

- [ ] **UC-M03.06-C070-T01 · Evidence inventory:** List the “Parent-crash handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C070-T02 · Artifact references:** Record the exact “Parent-crash handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C070-T03 · Fixture references:** Attach the “Parent-crash handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “The supervisor is killed while several children run” as a distinct evidence case.
- [ ] **UC-M03.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Parent-crash handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C070-T05 · Environment record:** Record the actual “Parent-crash handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C070-T06 · Expected versus observed:** Pair every “Parent-crash handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C070-T07 · Failure and limit records:** Attach “Parent-crash handling” change/failure and bounds evidence where required; include uncovered “Recovery scan interval and orphan lifetime” and unresolved violations of “A parent crash cannot leave permanently unowned executable guests”.
- [ ] **UC-M03.06-C070-T08 · Evidence hygiene:** Check the “Parent-crash handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C070-T09 · Reproduction review:** Have the “Parent-crash handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C070-T10 · Acceptance linkage:** Link the “Parent-crash handling” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Reaping and handle release

**Source delivery:** Reap terminated children and release process handles and stream readers.

**Source invariant:** Completed children do not accumulate zombie or handle resources.

**Source negative case:** Repeated short jobs exhaust process handles.

**Source bounded quantities:** Completed-job count and retained handles.

### UC-M03.06-C071 · Contract

**Original checklist item:** Specify reaping and handle release inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C071-T01 · Scope statement:** Draft the operation boundary for “Reaping and handle release” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reaping and handle release”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C071-T03 · Output inventory:** List the outputs of “Reaping and handle release” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Reaping and handle release”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C071-T05 · Prerequisite contract:** Map “Reaping and handle release” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Reaping and handle release”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C071-T07 · Invariant clause:** Add a normative clause for “Reaping and handle release” that preserves “Completed children do not accumulate zombie or handle resources”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reaping and handle release”; include the source counterexample “Repeated short jobs exhaust process handles” and the intended safe disposition.
- [ ] **UC-M03.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Completed-job count and retained handles” in the “Reaping and handle release” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C071-T10 · Contract review:** Review the “Reaping and handle release” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C072 · Delivery

**Original checklist item:** Reap terminated children and release process handles and stream readers.

- [ ] **UC-M03.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reaping and handle release”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C072-T02 · Change plan:** Break the source delivery for “Reaping and handle release” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Reaping and handle release” that realizes this source instruction: Reap terminated children and release process handles and stream readers.
- [ ] **UC-M03.06-C072-T04 · Concrete realization:** Trace “Reaping and handle release” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reaping and handle release” needed to preserve “Completed children do not accumulate zombie or handle resources”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C072-T06 · Dependency connection:** Connect the “Reaping and handle release” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C072-T07 · Resource behavior:** Account for “Completed-job count and retained handles” in “Reaping and handle release”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C072-T08 · Delivery check:** Run the smallest real “Reaping and handle release” path and its adverse fixture “Repeated short jobs exhaust process handles”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C072-T09 · Patch review:** Review the “Reaping and handle release” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C072-T10 · Delivery handoff:** Publish the “Reaping and handle release” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Completed children do not accumulate zombie or handle resources. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Reaping and handle release”; copy its required invariant exactly: “Completed children do not accumulate zombie or handle resources”.
- [ ] **UC-M03.06-C073-T02 · Observable terms:** Define each term in the “Reaping and handle release” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C073-T03 · Precondition set:** List the preconditions under which “Completed children do not accumulate zombie or handle resources” must hold for “Reaping and handle release”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C073-T04 · Transition coverage:** Map the “Reaping and handle release” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reaping and handle release”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C073-T06 · Satisfying fixture:** Create a concrete “Reaping and handle release” case that satisfies “Completed children do not accumulate zombie or handle resources”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C073-T07 · Violating fixture:** Create the source counterexample “Repeated short jobs exhaust process handles” for “Reaping and handle release”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C073-T08 · Enforcement evidence:** Exercise the “Reaping and handle release” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C073-T09 · Regression linkage:** Link the “Reaping and handle release” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Reaping and handle release” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C074 · Integration

**Original checklist item:** Integrate reaping and handle release with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reaping and handle release” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C074-T02 · Field mapping:** Map every “Reaping and handle release” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Reaping and handle release” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C074-T04 · Ownership agreement:** Specify who owns “Reaping and handle release” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C074-T05 · Handoff implementation:** Connect “Reaping and handle release” through the mapped seam using the real adapter or explicit specification reference; preserve “Completed children do not accumulate zombie or handle resources” across the handoff.
- [ ] **UC-M03.06-C074-T06 · Absent-input case:** Omit one required “Reaping and handle release” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C074-T07 · Stale-input case:** Supply an outdated “Reaping and handle release” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Reaping and handle release” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C074-T09 · Valid integration trace:** Run a valid “Reaping and handle release” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C074-T10 · Seam review:** Reconcile the “Reaping and handle release” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reaping and handle release; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reaping and handle release” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C075-T02 · Expected-result oracle:** Specify the “Reaping and handle release” expected result independently of the implementation output; include the property “Completed children do not accumulate zombie or handle resources” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C075-T03 · Fixture material:** Create the concrete “Reaping and handle release” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C075-T04 · Target preparation:** Prepare the “Reaping and handle release” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C075-T05 · Initial-state record:** Record the initial “Reaping and handle release” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C075-T06 · Valid-path execution:** Execute the “Reaping and handle release” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C075-T07 · Outcome comparison:** Compare every declared “Reaping and handle release” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C075-T08 · State and bounds check:** Inspect the “Reaping and handle release” ownership/state effects and actual use of “Completed-job count and retained handles”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C075-T09 · Repeatability check:** Repeat the same “Reaping and handle release” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C075-T10 · Positive evidence:** Attach the “Reaping and handle release” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C076 · Negative test

**Original checklist item:** Negative case: Repeated short jobs exhaust process handles. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Reaping and handle release” source counterexample: “Repeated short jobs exhaust process handles”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Reaping and handle release”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C076-T03 · Valid control:** Construct a valid “Reaping and handle release” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C076-T04 · Minimal adverse input:** Derive the “Reaping and handle release” adverse fixture from the control with the smallest documented change needed to reproduce “Repeated short jobs exhaust process handles”; retain that change as reproducible data.
- [ ] **UC-M03.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reaping and handle release”; require “Completed children do not accumulate zombie or handle resources” and forbid a false-success verdict.
- [ ] **UC-M03.06-C076-T06 · Adverse execution:** Exercise the “Reaping and handle release” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C076-T07 · Effect inspection:** Inspect “Reaping and handle release” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C076-T08 · Refusal versus failure:** Confirm the “Reaping and handle release” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C076-T09 · Reset and retention:** Restore only the disposable “Reaping and handle release” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C076-T10 · Negative regression:** Register the “Reaping and handle release” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C077 · Change / failure test

**Original checklist item:** Exercise reaping and handle release when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C077-T01 · Scenario record:** Write the “Reaping and handle release” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “Completed children do not accumulate zombie or handle resources”.
- [ ] **UC-M03.06-C077-T02 · Baseline capture:** Create a known-valid “Reaping and handle release” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C077-T03 · Injection map:** Locate the “Reaping and handle release” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Reaping and handle release” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C077-T05 · Controlled trigger:** Introduce the controlled “Reaping and handle release” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C077-T06 · Intermediate inspection:** Inspect the “Reaping and handle release” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reaping and handle release”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Reaping and handle release” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C077-T09 · Repeat and compare:** Repeat the selected “Reaping and handle release” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C077-T10 · Failure evidence:** Publish the “Reaping and handle release” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for completed-job count and retained handles; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Reaping and handle release”: “Completed-job count and retained handles”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C078-T02 · Measurement method:** Choose how to observe each “Reaping and handle release” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C078-T03 · Budget decision:** Select justified resource and input limits for “Reaping and handle release”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reaping and handle release” cases for “Completed-job count and retained handles”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reaping and handle release” limit; preserve “Completed children do not accumulate zombie or handle resources”.
- [ ] **UC-M03.06-C078-T06 · Normal measurement:** Run or review the normal “Reaping and handle release” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C078-T07 · At-limit measurement:** Exercise the “Reaping and handle release” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C078-T08 · Over-limit measurement:** Exercise the “Reaping and handle release” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C078-T09 · Uncovered-scope report:** List the “Reaping and handle release” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C078-T10 · Limit evidence:** Publish the selected “Reaping and handle release” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reaping and handle release with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C079-T01 · Event inventory:** List the “Reaping and handle release” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Reaping and handle release” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C079-T03 · Failure mapping:** Map each documented “Reaping and handle release” refusal or error to a diagnostic outcome; include “Repeated short jobs exhaust process handles” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C079-T04 · Emission path:** Add the “Reaping and handle release” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C079-T05 · Redaction check:** Test “Reaping and handle release” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C079-T06 · Output budget:** Set and exercise bounded “Reaping and handle release” message size, rate and retention compatible with “Completed-job count and retained handles”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C079-T07 · Success/refusal fixtures:** Capture “Reaping and handle release” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reaping and handle release” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C079-T09 · Operator review:** Read the “Reaping and handle release” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C079-T10 · Diagnostic evidence:** Publish redacted “Reaping and handle release” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reaping and handle release; label unexecuted checks as untested.

- [ ] **UC-M03.06-C080-T01 · Evidence inventory:** List the “Reaping and handle release” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C080-T02 · Artifact references:** Record the exact “Reaping and handle release” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C080-T03 · Fixture references:** Attach the “Reaping and handle release” fixture IDs, input identities and oracle definition; preserve the source counterexample “Repeated short jobs exhaust process handles” as a distinct evidence case.
- [ ] **UC-M03.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reaping and handle release”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C080-T05 · Environment record:** Record the actual “Reaping and handle release” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C080-T06 · Expected versus observed:** Pair every “Reaping and handle release” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C080-T07 · Failure and limit records:** Attach “Reaping and handle release” change/failure and bounds evidence where required; include uncovered “Completed-job count and retained handles” and unresolved violations of “Completed children do not accumulate zombie or handle resources”.
- [ ] **UC-M03.06-C080-T08 · Evidence hygiene:** Check the “Reaping and handle release” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C080-T09 · Reproduction review:** Have the “Reaping and handle release” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C080-T10 · Acceptance linkage:** Link the “Reaping and handle release” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Final failure record

**Source delivery:** Persist exit reason, generation and the last bounded diagnostic tail.

**Source invariant:** A timeout or crash remains distinguishable from success after restart.

**Source negative case:** Cleanup overwrites the original failure reason.

**Source bounded quantities:** Final record size and persistence deadline.

### UC-M03.06-C081 · Contract

**Original checklist item:** Specify final failure record inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C081-T01 · Scope statement:** Draft the operation boundary for “Final failure record” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Final failure record”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C081-T03 · Output inventory:** List the outputs of “Final failure record” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Final failure record”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C081-T05 · Prerequisite contract:** Map “Final failure record” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Final failure record”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C081-T07 · Invariant clause:** Add a normative clause for “Final failure record” that preserves “A timeout or crash remains distinguishable from success after restart”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Final failure record”; include the source counterexample “Cleanup overwrites the original failure reason” and the intended safe disposition.
- [ ] **UC-M03.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Final record size and persistence deadline” in the “Final failure record” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C081-T10 · Contract review:** Review the “Final failure record” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C082 · Delivery

**Original checklist item:** Persist exit reason, generation and the last bounded diagnostic tail.

- [ ] **UC-M03.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Final failure record”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C082-T02 · Change plan:** Break the source delivery for “Final failure record” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Final failure record” that realizes this source instruction: Persist exit reason, generation and the last bounded diagnostic tail.
- [ ] **UC-M03.06-C082-T04 · Concrete realization:** Trace “Final failure record” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Final failure record” needed to preserve “A timeout or crash remains distinguishable from success after restart”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C082-T06 · Dependency connection:** Connect the “Final failure record” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C082-T07 · Resource behavior:** Account for “Final record size and persistence deadline” in “Final failure record”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C082-T08 · Delivery check:** Run the smallest real “Final failure record” path and its adverse fixture “Cleanup overwrites the original failure reason”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C082-T09 · Patch review:** Review the “Final failure record” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C082-T10 · Delivery handoff:** Publish the “Final failure record” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A timeout or crash remains distinguishable from success after restart. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Final failure record”; copy its required invariant exactly: “A timeout or crash remains distinguishable from success after restart”.
- [ ] **UC-M03.06-C083-T02 · Observable terms:** Define each term in the “Final failure record” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C083-T03 · Precondition set:** List the preconditions under which “A timeout or crash remains distinguishable from success after restart” must hold for “Final failure record”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C083-T04 · Transition coverage:** Map the “Final failure record” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Final failure record”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C083-T06 · Satisfying fixture:** Create a concrete “Final failure record” case that satisfies “A timeout or crash remains distinguishable from success after restart”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C083-T07 · Violating fixture:** Create the source counterexample “Cleanup overwrites the original failure reason” for “Final failure record”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C083-T08 · Enforcement evidence:** Exercise the “Final failure record” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C083-T09 · Regression linkage:** Link the “Final failure record” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Final failure record” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C084 · Integration

**Original checklist item:** Integrate final failure record with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Final failure record” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C084-T02 · Field mapping:** Map every “Final failure record” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Final failure record” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C084-T04 · Ownership agreement:** Specify who owns “Final failure record” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C084-T05 · Handoff implementation:** Connect “Final failure record” through the mapped seam using the real adapter or explicit specification reference; preserve “A timeout or crash remains distinguishable from success after restart” across the handoff.
- [ ] **UC-M03.06-C084-T06 · Absent-input case:** Omit one required “Final failure record” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C084-T07 · Stale-input case:** Supply an outdated “Final failure record” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Final failure record” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C084-T09 · Valid integration trace:** Run a valid “Final failure record” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C084-T10 · Seam review:** Reconcile the “Final failure record” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for final failure record; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Final failure record” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C085-T02 · Expected-result oracle:** Specify the “Final failure record” expected result independently of the implementation output; include the property “A timeout or crash remains distinguishable from success after restart” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C085-T03 · Fixture material:** Create the concrete “Final failure record” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C085-T04 · Target preparation:** Prepare the “Final failure record” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C085-T05 · Initial-state record:** Record the initial “Final failure record” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C085-T06 · Valid-path execution:** Execute the “Final failure record” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C085-T07 · Outcome comparison:** Compare every declared “Final failure record” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C085-T08 · State and bounds check:** Inspect the “Final failure record” ownership/state effects and actual use of “Final record size and persistence deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C085-T09 · Repeatability check:** Repeat the same “Final failure record” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C085-T10 · Positive evidence:** Attach the “Final failure record” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C086 · Negative test

**Original checklist item:** Negative case: Cleanup overwrites the original failure reason. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Final failure record” source counterexample: “Cleanup overwrites the original failure reason”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Final failure record”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C086-T03 · Valid control:** Construct a valid “Final failure record” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C086-T04 · Minimal adverse input:** Derive the “Final failure record” adverse fixture from the control with the smallest documented change needed to reproduce “Cleanup overwrites the original failure reason”; retain that change as reproducible data.
- [ ] **UC-M03.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Final failure record”; require “A timeout or crash remains distinguishable from success after restart” and forbid a false-success verdict.
- [ ] **UC-M03.06-C086-T06 · Adverse execution:** Exercise the “Final failure record” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C086-T07 · Effect inspection:** Inspect “Final failure record” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C086-T08 · Refusal versus failure:** Confirm the “Final failure record” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C086-T09 · Reset and retention:** Restore only the disposable “Final failure record” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C086-T10 · Negative regression:** Register the “Final failure record” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C087 · Change / failure test

**Original checklist item:** Exercise final failure record when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C087-T01 · Scenario record:** Write the “Final failure record” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “A timeout or crash remains distinguishable from success after restart”.
- [ ] **UC-M03.06-C087-T02 · Baseline capture:** Create a known-valid “Final failure record” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C087-T03 · Injection map:** Locate the “Final failure record” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Final failure record” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C087-T05 · Controlled trigger:** Introduce the controlled “Final failure record” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C087-T06 · Intermediate inspection:** Inspect the “Final failure record” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Final failure record”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Final failure record” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C087-T09 · Repeat and compare:** Repeat the selected “Final failure record” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C087-T10 · Failure evidence:** Publish the “Final failure record” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for final record size and persistence deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Final failure record”: “Final record size and persistence deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C088-T02 · Measurement method:** Choose how to observe each “Final failure record” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Final failure record”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Final failure record” cases for “Final record size and persistence deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Final failure record” limit; preserve “A timeout or crash remains distinguishable from success after restart”.
- [ ] **UC-M03.06-C088-T06 · Normal measurement:** Run or review the normal “Final failure record” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C088-T07 · At-limit measurement:** Exercise the “Final failure record” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C088-T08 · Over-limit measurement:** Exercise the “Final failure record” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C088-T09 · Uncovered-scope report:** List the “Final failure record” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C088-T10 · Limit evidence:** Publish the selected “Final failure record” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for final failure record with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C089-T01 · Event inventory:** List the “Final failure record” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Final failure record” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C089-T03 · Failure mapping:** Map each documented “Final failure record” refusal or error to a diagnostic outcome; include “Cleanup overwrites the original failure reason” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C089-T04 · Emission path:** Add the “Final failure record” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C089-T05 · Redaction check:** Test “Final failure record” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C089-T06 · Output budget:** Set and exercise bounded “Final failure record” message size, rate and retention compatible with “Final record size and persistence deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C089-T07 · Success/refusal fixtures:** Capture “Final failure record” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Final failure record” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C089-T09 · Operator review:** Read the “Final failure record” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C089-T10 · Diagnostic evidence:** Publish redacted “Final failure record” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for final failure record; label unexecuted checks as untested.

- [ ] **UC-M03.06-C090-T01 · Evidence inventory:** List the “Final failure record” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C090-T02 · Artifact references:** Record the exact “Final failure record” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C090-T03 · Fixture references:** Attach the “Final failure record” fixture IDs, input identities and oracle definition; preserve the source counterexample “Cleanup overwrites the original failure reason” as a distinct evidence case.
- [ ] **UC-M03.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Final failure record”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C090-T05 · Environment record:** Record the actual “Final failure record” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C090-T06 · Expected versus observed:** Pair every “Final failure record” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C090-T07 · Failure and limit records:** Attach “Final failure record” change/failure and bounds evidence where required; include uncovered “Final record size and persistence deadline” and unresolved violations of “A timeout or crash remains distinguishable from success after restart”.
- [ ] **UC-M03.06-C090-T08 · Evidence hygiene:** Check the “Final failure record” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C090-T09 · Reproduction review:** Have the “Final failure record” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C090-T10 · Acceptance linkage:** Link the “Final failure record” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Supervisor fault tests

**Source delivery:** Exercise hangs, stream floods, grandchildren and supervisor loss.

**Source invariant:** Each case ends with no executable orphan and a recoverable outcome.

**Source negative case:** A hidden descendant continues work after a timeout pass.

**Source bounded quantities:** Scenario count and maximum test duration.

### UC-M03.06-C091 · Contract

**Original checklist item:** Specify supervisor fault tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.06-C091-T01 · Scope statement:** Draft the operation boundary for “Supervisor fault tests” within Supervisor, watchdog and child-tree cleanup; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Supervisor fault tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.06-C091-T03 · Output inventory:** List the outputs of “Supervisor fault tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Supervisor fault tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.06-C091-T05 · Prerequisite contract:** Map “Supervisor fault tests” to the source component prerequisites (UC-M03.01, UC-M03.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Supervisor fault tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.06-C091-T07 · Invariant clause:** Add a normative clause for “Supervisor fault tests” that preserves “Each case ends with no executable orphan and a recoverable outcome”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Supervisor fault tests”; include the source counterexample “A hidden descendant continues work after a timeout pass” and the intended safe disposition.
- [ ] **UC-M03.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scenario count and maximum test duration” in the “Supervisor fault tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.06-C091-T10 · Contract review:** Review the “Supervisor fault tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.06-C092 · Delivery

**Original checklist item:** Exercise hangs, stream floods, grandchildren and supervisor loss.

- [ ] **UC-M03.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Supervisor fault tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.06-C092-T02 · Change plan:** Break the source delivery for “Supervisor fault tests” into concrete edit targets and reviewable outputs; keep the UC-M03.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.06-C092-T03 · Core artifact:** Create the “Supervisor fault tests” fixture or harness for this source instruction: Exercise hangs, stream floods, grandchildren and supervisor loss.
- [ ] **UC-M03.06-C092-T04 · Concrete realization:** Connect the “Supervisor fault tests” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Supervisor fault tests” needed to preserve “Each case ends with no executable orphan and a recoverable outcome”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.06-C092-T06 · Dependency connection:** Connect the “Supervisor fault tests” implementation to generation-scoped process records, timeout controls and final failure journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.06-C092-T07 · Resource behavior:** Account for “Scenario count and maximum test duration” in “Supervisor fault tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.06-C092-T08 · Delivery check:** Run the smallest real “Supervisor fault tests” path and its adverse fixture “A hidden descendant continues work after a timeout pass”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.06-C092-T09 · Patch review:** Review the “Supervisor fault tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.06-C092-T10 · Delivery handoff:** Publish the “Supervisor fault tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each case ends with no executable orphan and a recoverable outcome. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Supervisor fault tests”; copy its required invariant exactly: “Each case ends with no executable orphan and a recoverable outcome”.
- [ ] **UC-M03.06-C093-T02 · Observable terms:** Define each term in the “Supervisor fault tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.06-C093-T03 · Precondition set:** List the preconditions under which “Each case ends with no executable orphan and a recoverable outcome” must hold for “Supervisor fault tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.06-C093-T04 · Transition coverage:** Map the “Supervisor fault tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Supervisor fault tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.06-C093-T06 · Satisfying fixture:** Create a concrete “Supervisor fault tests” case that satisfies “Each case ends with no executable orphan and a recoverable outcome”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.06-C093-T07 · Violating fixture:** Create the source counterexample “A hidden descendant continues work after a timeout pass” for “Supervisor fault tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.06-C093-T08 · Enforcement evidence:** Exercise the “Supervisor fault tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.06-C093-T09 · Regression linkage:** Link the “Supervisor fault tests” property to changes in generation-scoped process records, timeout controls and final failure journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Supervisor fault tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.06-C094 · Integration

**Original checklist item:** Integrate supervisor fault tests with generation-scoped process records, timeout controls and final failure journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Supervisor fault tests” across generation-scoped process records, timeout controls and final failure journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.06-C094-T02 · Field mapping:** Map every “Supervisor fault tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Supervisor fault tests” (source dependency list: UC-M03.01, UC-M03.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.06-C094-T04 · Ownership agreement:** Specify who owns “Supervisor fault tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.06-C094-T05 · Handoff implementation:** Connect “Supervisor fault tests” through the mapped seam using the real adapter or explicit specification reference; preserve “Each case ends with no executable orphan and a recoverable outcome” across the handoff.
- [ ] **UC-M03.06-C094-T06 · Absent-input case:** Omit one required “Supervisor fault tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.06-C094-T07 · Stale-input case:** Supply an outdated “Supervisor fault tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Supervisor fault tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.06-C094-T09 · Valid integration trace:** Run a valid “Supervisor fault tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.06-C094-T10 · Seam review:** Reconcile the “Supervisor fault tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for supervisor fault tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Supervisor fault tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.06-C095-T02 · Expected-result oracle:** Specify the “Supervisor fault tests” expected result independently of the implementation output; include the property “Each case ends with no executable orphan and a recoverable outcome” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.06-C095-T03 · Fixture material:** Create the concrete “Supervisor fault tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.06-C095-T04 · Target preparation:** Prepare the “Supervisor fault tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.06-C095-T05 · Initial-state record:** Record the initial “Supervisor fault tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.06-C095-T06 · Valid-path execution:** Execute the “Supervisor fault tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.06-C095-T07 · Outcome comparison:** Compare every declared “Supervisor fault tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.06-C095-T08 · State and bounds check:** Inspect the “Supervisor fault tests” ownership/state effects and actual use of “Scenario count and maximum test duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.06-C095-T09 · Repeatability check:** Repeat the same “Supervisor fault tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.06-C095-T10 · Positive evidence:** Attach the “Supervisor fault tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.06-C096 · Negative test

**Original checklist item:** Negative case: A hidden descendant continues work after a timeout pass. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Supervisor fault tests” source counterexample: “A hidden descendant continues work after a timeout pass”; state which precondition or invariant it challenges.
- [ ] **UC-M03.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Supervisor fault tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.06-C096-T03 · Valid control:** Construct a valid “Supervisor fault tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.06-C096-T04 · Minimal adverse input:** Derive the “Supervisor fault tests” adverse fixture from the control with the smallest documented change needed to reproduce “A hidden descendant continues work after a timeout pass”; retain that change as reproducible data.
- [ ] **UC-M03.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Supervisor fault tests”; require “Each case ends with no executable orphan and a recoverable outcome” and forbid a false-success verdict.
- [ ] **UC-M03.06-C096-T06 · Adverse execution:** Exercise the “Supervisor fault tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.06-C096-T07 · Effect inspection:** Inspect “Supervisor fault tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.06-C096-T08 · Refusal versus failure:** Confirm the “Supervisor fault tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.06-C096-T09 · Reset and retention:** Restore only the disposable “Supervisor fault tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.06-C096-T10 · Negative regression:** Register the “Supervisor fault tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.06-C097 · Change / failure test

**Original checklist item:** Exercise supervisor fault tests when the supervisor dies while children and grandchildren are still executing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.06-C097-T01 · Scenario record:** Write the “Supervisor fault tests” change/failure scenario exactly as supplied: the supervisor dies while children and grandchildren are still executing; identify the property that must remain true: “Each case ends with no executable orphan and a recoverable outcome”.
- [ ] **UC-M03.06-C097-T02 · Baseline capture:** Create a known-valid “Supervisor fault tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.06-C097-T03 · Injection map:** Locate the “Supervisor fault tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Supervisor fault tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.06-C097-T05 · Controlled trigger:** Introduce the controlled “Supervisor fault tests” scenario in the disposable fixture: the supervisor dies while children and grandchildren are still executing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.06-C097-T06 · Intermediate inspection:** Inspect the “Supervisor fault tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Supervisor fault tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Supervisor fault tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.06-C097-T09 · Repeat and compare:** Repeat the selected “Supervisor fault tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.06-C097-T10 · Failure evidence:** Publish the “Supervisor fault tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for scenario count and maximum test duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Supervisor fault tests”: “Scenario count and maximum test duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.06-C098-T02 · Measurement method:** Choose how to observe each “Supervisor fault tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Supervisor fault tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Supervisor fault tests” cases for “Scenario count and maximum test duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Supervisor fault tests” limit; preserve “Each case ends with no executable orphan and a recoverable outcome”.
- [ ] **UC-M03.06-C098-T06 · Normal measurement:** Run or review the normal “Supervisor fault tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.06-C098-T07 · At-limit measurement:** Exercise the “Supervisor fault tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.06-C098-T08 · Over-limit measurement:** Exercise the “Supervisor fault tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.06-C098-T09 · Uncovered-scope report:** List the “Supervisor fault tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.06-C098-T10 · Limit evidence:** Publish the selected “Supervisor fault tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for supervisor fault tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.06-C099-T01 · Event inventory:** List the “Supervisor fault tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Supervisor fault tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.06-C099-T03 · Failure mapping:** Map each documented “Supervisor fault tests” refusal or error to a diagnostic outcome; include “A hidden descendant continues work after a timeout pass” and prohibit conversion into a success message.
- [ ] **UC-M03.06-C099-T04 · Emission path:** Add the “Supervisor fault tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.06-C099-T05 · Redaction check:** Test “Supervisor fault tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.06-C099-T06 · Output budget:** Set and exercise bounded “Supervisor fault tests” message size, rate and retention compatible with “Scenario count and maximum test duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.06-C099-T07 · Success/refusal fixtures:** Capture “Supervisor fault tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Supervisor fault tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.06-C099-T09 · Operator review:** Read the “Supervisor fault tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.06-C099-T10 · Diagnostic evidence:** Publish redacted “Supervisor fault tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for supervisor fault tests; label unexecuted checks as untested.

- [ ] **UC-M03.06-C100-T01 · Evidence inventory:** List the “Supervisor fault tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.06-C100-T02 · Artifact references:** Record the exact “Supervisor fault tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.06-C100-T03 · Fixture references:** Attach the “Supervisor fault tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “A hidden descendant continues work after a timeout pass” as a distinct evidence case.
- [ ] **UC-M03.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Supervisor fault tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.06-C100-T05 · Environment record:** Record the actual “Supervisor fault tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.06-C100-T06 · Expected versus observed:** Pair every “Supervisor fault tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.06-C100-T07 · Failure and limit records:** Attach “Supervisor fault tests” change/failure and bounds evidence where required; include uncovered “Scenario count and maximum test duration” and unresolved violations of “Each case ends with no executable orphan and a recoverable outcome”.
- [ ] **UC-M03.06-C100-T08 · Evidence hygiene:** Check the “Supervisor fault tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.06-C100-T09 · Reproduction review:** Have the “Supervisor fault tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.06-C100-T10 · Acceptance linkage:** Link the “Supervisor fault tests” evidence to its parent and UC-M03.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

