# UC-M03.04 — Enforced default-deny networking

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/03.md)

| Field | Preserved source value |
|---|---|
| Workstream | 03. Host isolation and supervision |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.03](../03/UC-M03.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S3], [S4]. |

## Original requirement

Translate NETWORK=deny into absent devices and/or enforced host filtering. Explicitly isolate the host control-plane and metadata endpoints.

**Original acceptance criterion:** A guest traffic probe demonstrates denied egress and lateral access; policy text alone is not evidence.

**Source trace:** Original checklist `UC100/c/03/UC-M03.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 272–282 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Offline device profile

**Source delivery:** Remove guest network devices for the selected offline profile where supported.

**Source invariant:** Offline guests have no implicitly exposed network device.

**Source negative case:** An inherited backend default adds a virtual NIC.

**Source bounded quantities:** Device count and offline-profile variants.

### UC-M03.04-C001 · Contract

**Original checklist item:** Specify offline device profile inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C001-T01 · Scope statement:** Draft the operation boundary for “Offline device profile” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Offline device profile”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C001-T03 · Output inventory:** List the outputs of “Offline device profile” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Offline device profile”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C001-T05 · Prerequisite contract:** Map “Offline device profile” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Offline device profile”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C001-T07 · Invariant clause:** Add a normative clause for “Offline device profile” that preserves “Offline guests have no implicitly exposed network device”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Offline device profile”; include the source counterexample “An inherited backend default adds a virtual NIC” and the intended safe disposition.
- [ ] **UC-M03.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Device count and offline-profile variants” in the “Offline device profile” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C001-T10 · Contract review:** Review the “Offline device profile” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C002 · Delivery

**Original checklist item:** Remove guest network devices for the selected offline profile where supported.

- [ ] **UC-M03.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Offline device profile”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C002-T02 · Change plan:** Break the source delivery for “Offline device profile” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Offline device profile” that realizes this source instruction: Remove guest network devices for the selected offline profile where supported.
- [ ] **UC-M03.04-C002-T04 · Concrete realization:** Trace “Offline device profile” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Offline device profile” needed to preserve “Offline guests have no implicitly exposed network device”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C002-T06 · Dependency connection:** Connect the “Offline device profile” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C002-T07 · Resource behavior:** Account for “Device count and offline-profile variants” in “Offline device profile”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C002-T08 · Delivery check:** Run the smallest real “Offline device profile” path and its adverse fixture “An inherited backend default adds a virtual NIC”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C002-T09 · Patch review:** Review the “Offline device profile” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C002-T10 · Delivery handoff:** Publish the “Offline device profile” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Offline guests have no implicitly exposed network device. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Offline device profile”; copy its required invariant exactly: “Offline guests have no implicitly exposed network device”.
- [ ] **UC-M03.04-C003-T02 · Observable terms:** Define each term in the “Offline device profile” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C003-T03 · Precondition set:** List the preconditions under which “Offline guests have no implicitly exposed network device” must hold for “Offline device profile”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C003-T04 · Transition coverage:** Map the “Offline device profile” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Offline device profile”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C003-T06 · Satisfying fixture:** Create a concrete “Offline device profile” case that satisfies “Offline guests have no implicitly exposed network device”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C003-T07 · Violating fixture:** Create the source counterexample “An inherited backend default adds a virtual NIC” for “Offline device profile”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C003-T08 · Enforcement evidence:** Exercise the “Offline device profile” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C003-T09 · Regression linkage:** Link the “Offline device profile” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Offline device profile” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C004 · Integration

**Original checklist item:** Integrate offline device profile with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Offline device profile” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C004-T02 · Field mapping:** Map every “Offline device profile” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Offline device profile” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C004-T04 · Ownership agreement:** Specify who owns “Offline device profile” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C004-T05 · Handoff implementation:** Connect “Offline device profile” through the mapped seam using the real adapter or explicit specification reference; preserve “Offline guests have no implicitly exposed network device” across the handoff.
- [ ] **UC-M03.04-C004-T06 · Absent-input case:** Omit one required “Offline device profile” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C004-T07 · Stale-input case:** Supply an outdated “Offline device profile” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Offline device profile” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C004-T09 · Valid integration trace:** Run a valid “Offline device profile” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C004-T10 · Seam review:** Reconcile the “Offline device profile” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for offline device profile; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Offline device profile” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C005-T02 · Expected-result oracle:** Specify the “Offline device profile” expected result independently of the implementation output; include the property “Offline guests have no implicitly exposed network device” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C005-T03 · Fixture material:** Create the concrete “Offline device profile” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C005-T04 · Target preparation:** Prepare the “Offline device profile” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C005-T05 · Initial-state record:** Record the initial “Offline device profile” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C005-T06 · Valid-path execution:** Execute the “Offline device profile” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C005-T07 · Outcome comparison:** Compare every declared “Offline device profile” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C005-T08 · State and bounds check:** Inspect the “Offline device profile” ownership/state effects and actual use of “Device count and offline-profile variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C005-T09 · Repeatability check:** Repeat the same “Offline device profile” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C005-T10 · Positive evidence:** Attach the “Offline device profile” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C006 · Negative test

**Original checklist item:** Negative case: An inherited backend default adds a virtual NIC. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Offline device profile” source counterexample: “An inherited backend default adds a virtual NIC”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Offline device profile”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C006-T03 · Valid control:** Construct a valid “Offline device profile” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C006-T04 · Minimal adverse input:** Derive the “Offline device profile” adverse fixture from the control with the smallest documented change needed to reproduce “An inherited backend default adds a virtual NIC”; retain that change as reproducible data.
- [ ] **UC-M03.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Offline device profile”; require “Offline guests have no implicitly exposed network device” and forbid a false-success verdict.
- [ ] **UC-M03.04-C006-T06 · Adverse execution:** Exercise the “Offline device profile” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C006-T07 · Effect inspection:** Inspect “Offline device profile” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C006-T08 · Refusal versus failure:** Confirm the “Offline device profile” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C006-T09 · Reset and retention:** Restore only the disposable “Offline device profile” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C006-T10 · Negative regression:** Register the “Offline device profile” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C007 · Change / failure test

**Original checklist item:** Exercise offline device profile when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C007-T01 · Scenario record:** Write the “Offline device profile” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “Offline guests have no implicitly exposed network device”.
- [ ] **UC-M03.04-C007-T02 · Baseline capture:** Create a known-valid “Offline device profile” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C007-T03 · Injection map:** Locate the “Offline device profile” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Offline device profile” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C007-T05 · Controlled trigger:** Introduce the controlled “Offline device profile” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C007-T06 · Intermediate inspection:** Inspect the “Offline device profile” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Offline device profile”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Offline device profile” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C007-T09 · Repeat and compare:** Repeat the selected “Offline device profile” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C007-T10 · Failure evidence:** Publish the “Offline device profile” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C008 · Bounds

**Original checklist item:** Choose, document and test limits for device count and offline-profile variants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Offline device profile”: “Device count and offline-profile variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C008-T02 · Measurement method:** Choose how to observe each “Offline device profile” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C008-T03 · Budget decision:** Select justified resource and input limits for “Offline device profile”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Offline device profile” cases for “Device count and offline-profile variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Offline device profile” limit; preserve “Offline guests have no implicitly exposed network device”.
- [ ] **UC-M03.04-C008-T06 · Normal measurement:** Run or review the normal “Offline device profile” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C008-T07 · At-limit measurement:** Exercise the “Offline device profile” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C008-T08 · Over-limit measurement:** Exercise the “Offline device profile” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C008-T09 · Uncovered-scope report:** List the “Offline device profile” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C008-T10 · Limit evidence:** Publish the selected “Offline device profile” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for offline device profile with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C009-T01 · Event inventory:** List the “Offline device profile” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Offline device profile” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C009-T03 · Failure mapping:** Map each documented “Offline device profile” refusal or error to a diagnostic outcome; include “An inherited backend default adds a virtual NIC” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C009-T04 · Emission path:** Add the “Offline device profile” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C009-T05 · Redaction check:** Test “Offline device profile” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C009-T06 · Output budget:** Set and exercise bounded “Offline device profile” message size, rate and retention compatible with “Device count and offline-profile variants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C009-T07 · Success/refusal fixtures:** Capture “Offline device profile” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Offline device profile” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C009-T09 · Operator review:** Read the “Offline device profile” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C009-T10 · Diagnostic evidence:** Publish redacted “Offline device profile” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for offline device profile; label unexecuted checks as untested.

- [ ] **UC-M03.04-C010-T01 · Evidence inventory:** List the “Offline device profile” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C010-T02 · Artifact references:** Record the exact “Offline device profile” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C010-T03 · Fixture references:** Attach the “Offline device profile” fixture IDs, input identities and oracle definition; preserve the source counterexample “An inherited backend default adds a virtual NIC” as a distinct evidence case.
- [ ] **UC-M03.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Offline device profile”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C010-T05 · Environment record:** Record the actual “Offline device profile” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C010-T06 · Expected versus observed:** Pair every “Offline device profile” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C010-T07 · Failure and limit records:** Attach “Offline device profile” change/failure and bounds evidence where required; include uncovered “Device count and offline-profile variants” and unresolved violations of “Offline guests have no implicitly exposed network device”.
- [ ] **UC-M03.04-C010-T08 · Evidence hygiene:** Check the “Offline device profile” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C010-T09 · Reproduction review:** Have the “Offline device profile” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C010-T10 · Acceptance linkage:** Link the “Offline device profile” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Host filter configuration

**Source delivery:** Apply explicit host filtering when the selected network topology requires it.

**Source invariant:** Filtering corresponds to the admitted workload policy.

**Source negative case:** A filter rule is installed in the wrong network context.

**Source bounded quantities:** Rule count and update latency.

### UC-M03.04-C011 · Contract

**Original checklist item:** Specify host filter configuration inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C011-T01 · Scope statement:** Draft the operation boundary for “Host filter configuration” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Host filter configuration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C011-T03 · Output inventory:** List the outputs of “Host filter configuration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Host filter configuration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C011-T05 · Prerequisite contract:** Map “Host filter configuration” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Host filter configuration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C011-T07 · Invariant clause:** Add a normative clause for “Host filter configuration” that preserves “Filtering corresponds to the admitted workload policy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Host filter configuration”; include the source counterexample “A filter rule is installed in the wrong network context” and the intended safe disposition.
- [ ] **UC-M03.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Rule count and update latency” in the “Host filter configuration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C011-T10 · Contract review:** Review the “Host filter configuration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C012 · Delivery

**Original checklist item:** Apply explicit host filtering when the selected network topology requires it.

- [ ] **UC-M03.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Host filter configuration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C012-T02 · Change plan:** Break the source delivery for “Host filter configuration” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Host filter configuration” that realizes this source instruction: Apply explicit host filtering when the selected network topology requires it.
- [ ] **UC-M03.04-C012-T04 · Concrete realization:** Trace “Host filter configuration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Host filter configuration” needed to preserve “Filtering corresponds to the admitted workload policy”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C012-T06 · Dependency connection:** Connect the “Host filter configuration” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C012-T07 · Resource behavior:** Account for “Rule count and update latency” in “Host filter configuration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C012-T08 · Delivery check:** Run the smallest real “Host filter configuration” path and its adverse fixture “A filter rule is installed in the wrong network context”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C012-T09 · Patch review:** Review the “Host filter configuration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C012-T10 · Delivery handoff:** Publish the “Host filter configuration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Filtering corresponds to the admitted workload policy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Host filter configuration”; copy its required invariant exactly: “Filtering corresponds to the admitted workload policy”.
- [ ] **UC-M03.04-C013-T02 · Observable terms:** Define each term in the “Host filter configuration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C013-T03 · Precondition set:** List the preconditions under which “Filtering corresponds to the admitted workload policy” must hold for “Host filter configuration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C013-T04 · Transition coverage:** Map the “Host filter configuration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Host filter configuration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C013-T06 · Satisfying fixture:** Create a concrete “Host filter configuration” case that satisfies “Filtering corresponds to the admitted workload policy”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C013-T07 · Violating fixture:** Create the source counterexample “A filter rule is installed in the wrong network context” for “Host filter configuration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C013-T08 · Enforcement evidence:** Exercise the “Host filter configuration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C013-T09 · Regression linkage:** Link the “Host filter configuration” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Host filter configuration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C014 · Integration

**Original checklist item:** Integrate host filter configuration with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Host filter configuration” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C014-T02 · Field mapping:** Map every “Host filter configuration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Host filter configuration” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C014-T04 · Ownership agreement:** Specify who owns “Host filter configuration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C014-T05 · Handoff implementation:** Connect “Host filter configuration” through the mapped seam using the real adapter or explicit specification reference; preserve “Filtering corresponds to the admitted workload policy” across the handoff.
- [ ] **UC-M03.04-C014-T06 · Absent-input case:** Omit one required “Host filter configuration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C014-T07 · Stale-input case:** Supply an outdated “Host filter configuration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Host filter configuration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C014-T09 · Valid integration trace:** Run a valid “Host filter configuration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C014-T10 · Seam review:** Reconcile the “Host filter configuration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for host filter configuration; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Host filter configuration” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C015-T02 · Expected-result oracle:** Specify the “Host filter configuration” expected result independently of the implementation output; include the property “Filtering corresponds to the admitted workload policy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C015-T03 · Fixture material:** Create the concrete “Host filter configuration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C015-T04 · Target preparation:** Prepare the “Host filter configuration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C015-T05 · Initial-state record:** Record the initial “Host filter configuration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C015-T06 · Valid-path execution:** Execute the “Host filter configuration” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C015-T07 · Outcome comparison:** Compare every declared “Host filter configuration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C015-T08 · State and bounds check:** Inspect the “Host filter configuration” ownership/state effects and actual use of “Rule count and update latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C015-T09 · Repeatability check:** Repeat the same “Host filter configuration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C015-T10 · Positive evidence:** Attach the “Host filter configuration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C016 · Negative test

**Original checklist item:** Negative case: A filter rule is installed in the wrong network context. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Host filter configuration” source counterexample: “A filter rule is installed in the wrong network context”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Host filter configuration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C016-T03 · Valid control:** Construct a valid “Host filter configuration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C016-T04 · Minimal adverse input:** Derive the “Host filter configuration” adverse fixture from the control with the smallest documented change needed to reproduce “A filter rule is installed in the wrong network context”; retain that change as reproducible data.
- [ ] **UC-M03.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Host filter configuration”; require “Filtering corresponds to the admitted workload policy” and forbid a false-success verdict.
- [ ] **UC-M03.04-C016-T06 · Adverse execution:** Exercise the “Host filter configuration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C016-T07 · Effect inspection:** Inspect “Host filter configuration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C016-T08 · Refusal versus failure:** Confirm the “Host filter configuration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C016-T09 · Reset and retention:** Restore only the disposable “Host filter configuration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C016-T10 · Negative regression:** Register the “Host filter configuration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C017 · Change / failure test

**Original checklist item:** Exercise host filter configuration when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C017-T01 · Scenario record:** Write the “Host filter configuration” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “Filtering corresponds to the admitted workload policy”.
- [ ] **UC-M03.04-C017-T02 · Baseline capture:** Create a known-valid “Host filter configuration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C017-T03 · Injection map:** Locate the “Host filter configuration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Host filter configuration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C017-T05 · Controlled trigger:** Introduce the controlled “Host filter configuration” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C017-T06 · Intermediate inspection:** Inspect the “Host filter configuration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Host filter configuration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Host filter configuration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C017-T09 · Repeat and compare:** Repeat the selected “Host filter configuration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C017-T10 · Failure evidence:** Publish the “Host filter configuration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C018 · Bounds

**Original checklist item:** Choose, document and test limits for rule count and update latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Host filter configuration”: “Rule count and update latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C018-T02 · Measurement method:** Choose how to observe each “Host filter configuration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C018-T03 · Budget decision:** Select justified resource and input limits for “Host filter configuration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Host filter configuration” cases for “Rule count and update latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Host filter configuration” limit; preserve “Filtering corresponds to the admitted workload policy”.
- [ ] **UC-M03.04-C018-T06 · Normal measurement:** Run or review the normal “Host filter configuration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C018-T07 · At-limit measurement:** Exercise the “Host filter configuration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C018-T08 · Over-limit measurement:** Exercise the “Host filter configuration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C018-T09 · Uncovered-scope report:** List the “Host filter configuration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C018-T10 · Limit evidence:** Publish the selected “Host filter configuration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for host filter configuration with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C019-T01 · Event inventory:** List the “Host filter configuration” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Host filter configuration” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C019-T03 · Failure mapping:** Map each documented “Host filter configuration” refusal or error to a diagnostic outcome; include “A filter rule is installed in the wrong network context” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C019-T04 · Emission path:** Add the “Host filter configuration” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C019-T05 · Redaction check:** Test “Host filter configuration” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C019-T06 · Output budget:** Set and exercise bounded “Host filter configuration” message size, rate and retention compatible with “Rule count and update latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C019-T07 · Success/refusal fixtures:** Capture “Host filter configuration” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Host filter configuration” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C019-T09 · Operator review:** Read the “Host filter configuration” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C019-T10 · Diagnostic evidence:** Publish redacted “Host filter configuration” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for host filter configuration; label unexecuted checks as untested.

- [ ] **UC-M03.04-C020-T01 · Evidence inventory:** List the “Host filter configuration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C020-T02 · Artifact references:** Record the exact “Host filter configuration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C020-T03 · Fixture references:** Attach the “Host filter configuration” fixture IDs, input identities and oracle definition; preserve the source counterexample “A filter rule is installed in the wrong network context” as a distinct evidence case.
- [ ] **UC-M03.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Host filter configuration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C020-T05 · Environment record:** Record the actual “Host filter configuration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C020-T06 · Expected versus observed:** Pair every “Host filter configuration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C020-T07 · Failure and limit records:** Attach “Host filter configuration” change/failure and bounds evidence where required; include uncovered “Rule count and update latency” and unresolved violations of “Filtering corresponds to the admitted workload policy”.
- [ ] **UC-M03.04-C020-T08 · Evidence hygiene:** Check the “Host filter configuration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C020-T09 · Reproduction review:** Have the “Host filter configuration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C020-T10 · Acceptance linkage:** Link the “Host filter configuration” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Control-plane endpoint isolation

**Source delivery:** Prevent guest access to host management endpoints.

**Source invariant:** Guest traffic cannot reach privileged management services.

**Source negative case:** A guest probes a management endpoint on the host.

**Source bounded quantities:** Endpoint count and probe rate.

### UC-M03.04-C021 · Contract

**Original checklist item:** Specify control-plane endpoint isolation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C021-T01 · Scope statement:** Draft the operation boundary for “Control-plane endpoint isolation” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Control-plane endpoint isolation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C021-T03 · Output inventory:** List the outputs of “Control-plane endpoint isolation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Control-plane endpoint isolation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C021-T05 · Prerequisite contract:** Map “Control-plane endpoint isolation” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Control-plane endpoint isolation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C021-T07 · Invariant clause:** Add a normative clause for “Control-plane endpoint isolation” that preserves “Guest traffic cannot reach privileged management services”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Control-plane endpoint isolation”; include the source counterexample “A guest probes a management endpoint on the host” and the intended safe disposition.
- [ ] **UC-M03.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Endpoint count and probe rate” in the “Control-plane endpoint isolation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C021-T10 · Contract review:** Review the “Control-plane endpoint isolation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C022 · Delivery

**Original checklist item:** Prevent guest access to host management endpoints.

- [ ] **UC-M03.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Control-plane endpoint isolation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C022-T02 · Change plan:** Break the source delivery for “Control-plane endpoint isolation” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Control-plane endpoint isolation” that realizes this source instruction: Prevent guest access to host management endpoints.
- [ ] **UC-M03.04-C022-T04 · Concrete realization:** Trace “Control-plane endpoint isolation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Control-plane endpoint isolation” needed to preserve “Guest traffic cannot reach privileged management services”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C022-T06 · Dependency connection:** Connect the “Control-plane endpoint isolation” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C022-T07 · Resource behavior:** Account for “Endpoint count and probe rate” in “Control-plane endpoint isolation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C022-T08 · Delivery check:** Run the smallest real “Control-plane endpoint isolation” path and its adverse fixture “A guest probes a management endpoint on the host”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C022-T09 · Patch review:** Review the “Control-plane endpoint isolation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C022-T10 · Delivery handoff:** Publish the “Control-plane endpoint isolation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Guest traffic cannot reach privileged management services. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Control-plane endpoint isolation”; copy its required invariant exactly: “Guest traffic cannot reach privileged management services”.
- [ ] **UC-M03.04-C023-T02 · Observable terms:** Define each term in the “Control-plane endpoint isolation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C023-T03 · Precondition set:** List the preconditions under which “Guest traffic cannot reach privileged management services” must hold for “Control-plane endpoint isolation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C023-T04 · Transition coverage:** Map the “Control-plane endpoint isolation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Control-plane endpoint isolation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C023-T06 · Satisfying fixture:** Create a concrete “Control-plane endpoint isolation” case that satisfies “Guest traffic cannot reach privileged management services”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C023-T07 · Violating fixture:** Create the source counterexample “A guest probes a management endpoint on the host” for “Control-plane endpoint isolation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C023-T08 · Enforcement evidence:** Exercise the “Control-plane endpoint isolation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C023-T09 · Regression linkage:** Link the “Control-plane endpoint isolation” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Control-plane endpoint isolation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C024 · Integration

**Original checklist item:** Integrate control-plane endpoint isolation with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Control-plane endpoint isolation” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C024-T02 · Field mapping:** Map every “Control-plane endpoint isolation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Control-plane endpoint isolation” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C024-T04 · Ownership agreement:** Specify who owns “Control-plane endpoint isolation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C024-T05 · Handoff implementation:** Connect “Control-plane endpoint isolation” through the mapped seam using the real adapter or explicit specification reference; preserve “Guest traffic cannot reach privileged management services” across the handoff.
- [ ] **UC-M03.04-C024-T06 · Absent-input case:** Omit one required “Control-plane endpoint isolation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C024-T07 · Stale-input case:** Supply an outdated “Control-plane endpoint isolation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Control-plane endpoint isolation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C024-T09 · Valid integration trace:** Run a valid “Control-plane endpoint isolation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C024-T10 · Seam review:** Reconcile the “Control-plane endpoint isolation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for control-plane endpoint isolation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Control-plane endpoint isolation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C025-T02 · Expected-result oracle:** Specify the “Control-plane endpoint isolation” expected result independently of the implementation output; include the property “Guest traffic cannot reach privileged management services” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C025-T03 · Fixture material:** Create the concrete “Control-plane endpoint isolation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C025-T04 · Target preparation:** Prepare the “Control-plane endpoint isolation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C025-T05 · Initial-state record:** Record the initial “Control-plane endpoint isolation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C025-T06 · Valid-path execution:** Execute the “Control-plane endpoint isolation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C025-T07 · Outcome comparison:** Compare every declared “Control-plane endpoint isolation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C025-T08 · State and bounds check:** Inspect the “Control-plane endpoint isolation” ownership/state effects and actual use of “Endpoint count and probe rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C025-T09 · Repeatability check:** Repeat the same “Control-plane endpoint isolation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C025-T10 · Positive evidence:** Attach the “Control-plane endpoint isolation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C026 · Negative test

**Original checklist item:** Negative case: A guest probes a management endpoint on the host. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Control-plane endpoint isolation” source counterexample: “A guest probes a management endpoint on the host”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Control-plane endpoint isolation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C026-T03 · Valid control:** Construct a valid “Control-plane endpoint isolation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C026-T04 · Minimal adverse input:** Derive the “Control-plane endpoint isolation” adverse fixture from the control with the smallest documented change needed to reproduce “A guest probes a management endpoint on the host”; retain that change as reproducible data.
- [ ] **UC-M03.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Control-plane endpoint isolation”; require “Guest traffic cannot reach privileged management services” and forbid a false-success verdict.
- [ ] **UC-M03.04-C026-T06 · Adverse execution:** Exercise the “Control-plane endpoint isolation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C026-T07 · Effect inspection:** Inspect “Control-plane endpoint isolation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C026-T08 · Refusal versus failure:** Confirm the “Control-plane endpoint isolation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C026-T09 · Reset and retention:** Restore only the disposable “Control-plane endpoint isolation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C026-T10 · Negative regression:** Register the “Control-plane endpoint isolation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C027 · Change / failure test

**Original checklist item:** Exercise control-plane endpoint isolation when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C027-T01 · Scenario record:** Write the “Control-plane endpoint isolation” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “Guest traffic cannot reach privileged management services”.
- [ ] **UC-M03.04-C027-T02 · Baseline capture:** Create a known-valid “Control-plane endpoint isolation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C027-T03 · Injection map:** Locate the “Control-plane endpoint isolation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Control-plane endpoint isolation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C027-T05 · Controlled trigger:** Introduce the controlled “Control-plane endpoint isolation” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C027-T06 · Intermediate inspection:** Inspect the “Control-plane endpoint isolation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Control-plane endpoint isolation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Control-plane endpoint isolation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C027-T09 · Repeat and compare:** Repeat the selected “Control-plane endpoint isolation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C027-T10 · Failure evidence:** Publish the “Control-plane endpoint isolation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C028 · Bounds

**Original checklist item:** Choose, document and test limits for endpoint count and probe rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Control-plane endpoint isolation”: “Endpoint count and probe rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C028-T02 · Measurement method:** Choose how to observe each “Control-plane endpoint isolation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C028-T03 · Budget decision:** Select justified resource and input limits for “Control-plane endpoint isolation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Control-plane endpoint isolation” cases for “Endpoint count and probe rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Control-plane endpoint isolation” limit; preserve “Guest traffic cannot reach privileged management services”.
- [ ] **UC-M03.04-C028-T06 · Normal measurement:** Run or review the normal “Control-plane endpoint isolation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C028-T07 · At-limit measurement:** Exercise the “Control-plane endpoint isolation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C028-T08 · Over-limit measurement:** Exercise the “Control-plane endpoint isolation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C028-T09 · Uncovered-scope report:** List the “Control-plane endpoint isolation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C028-T10 · Limit evidence:** Publish the selected “Control-plane endpoint isolation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for control-plane endpoint isolation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C029-T01 · Event inventory:** List the “Control-plane endpoint isolation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Control-plane endpoint isolation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C029-T03 · Failure mapping:** Map each documented “Control-plane endpoint isolation” refusal or error to a diagnostic outcome; include “A guest probes a management endpoint on the host” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C029-T04 · Emission path:** Add the “Control-plane endpoint isolation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C029-T05 · Redaction check:** Test “Control-plane endpoint isolation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C029-T06 · Output budget:** Set and exercise bounded “Control-plane endpoint isolation” message size, rate and retention compatible with “Endpoint count and probe rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C029-T07 · Success/refusal fixtures:** Capture “Control-plane endpoint isolation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Control-plane endpoint isolation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C029-T09 · Operator review:** Read the “Control-plane endpoint isolation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C029-T10 · Diagnostic evidence:** Publish redacted “Control-plane endpoint isolation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for control-plane endpoint isolation; label unexecuted checks as untested.

- [ ] **UC-M03.04-C030-T01 · Evidence inventory:** List the “Control-plane endpoint isolation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C030-T02 · Artifact references:** Record the exact “Control-plane endpoint isolation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C030-T03 · Fixture references:** Attach the “Control-plane endpoint isolation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest probes a management endpoint on the host” as a distinct evidence case.
- [ ] **UC-M03.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Control-plane endpoint isolation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C030-T05 · Environment record:** Record the actual “Control-plane endpoint isolation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C030-T06 · Expected versus observed:** Pair every “Control-plane endpoint isolation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C030-T07 · Failure and limit records:** Attach “Control-plane endpoint isolation” change/failure and bounds evidence where required; include uncovered “Endpoint count and probe rate” and unresolved violations of “Guest traffic cannot reach privileged management services”.
- [ ] **UC-M03.04-C030-T08 · Evidence hygiene:** Check the “Control-plane endpoint isolation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C030-T09 · Reproduction review:** Have the “Control-plane endpoint isolation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C030-T10 · Acceptance linkage:** Link the “Control-plane endpoint isolation” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Metadata endpoint isolation

**Source delivery:** Block host or platform metadata endpoints not explicitly required.

**Source invariant:** A guest cannot retrieve host credentials through metadata services.

**Source negative case:** A guest follows an indirect route to a metadata endpoint.

**Source bounded quantities:** Address ranges and endpoint tests.

### UC-M03.04-C031 · Contract

**Original checklist item:** Specify metadata endpoint isolation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C031-T01 · Scope statement:** Draft the operation boundary for “Metadata endpoint isolation” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Metadata endpoint isolation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C031-T03 · Output inventory:** List the outputs of “Metadata endpoint isolation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Metadata endpoint isolation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C031-T05 · Prerequisite contract:** Map “Metadata endpoint isolation” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Metadata endpoint isolation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C031-T07 · Invariant clause:** Add a normative clause for “Metadata endpoint isolation” that preserves “A guest cannot retrieve host credentials through metadata services”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Metadata endpoint isolation”; include the source counterexample “A guest follows an indirect route to a metadata endpoint” and the intended safe disposition.
- [ ] **UC-M03.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Address ranges and endpoint tests” in the “Metadata endpoint isolation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C031-T10 · Contract review:** Review the “Metadata endpoint isolation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C032 · Delivery

**Original checklist item:** Block host or platform metadata endpoints not explicitly required.

- [ ] **UC-M03.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Metadata endpoint isolation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C032-T02 · Change plan:** Break the source delivery for “Metadata endpoint isolation” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Metadata endpoint isolation” that realizes this source instruction: Block host or platform metadata endpoints not explicitly required.
- [ ] **UC-M03.04-C032-T04 · Concrete realization:** Trace “Metadata endpoint isolation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Metadata endpoint isolation” needed to preserve “A guest cannot retrieve host credentials through metadata services”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C032-T06 · Dependency connection:** Connect the “Metadata endpoint isolation” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C032-T07 · Resource behavior:** Account for “Address ranges and endpoint tests” in “Metadata endpoint isolation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C032-T08 · Delivery check:** Run the smallest real “Metadata endpoint isolation” path and its adverse fixture “A guest follows an indirect route to a metadata endpoint”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C032-T09 · Patch review:** Review the “Metadata endpoint isolation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C032-T10 · Delivery handoff:** Publish the “Metadata endpoint isolation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A guest cannot retrieve host credentials through metadata services. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Metadata endpoint isolation”; copy its required invariant exactly: “A guest cannot retrieve host credentials through metadata services”.
- [ ] **UC-M03.04-C033-T02 · Observable terms:** Define each term in the “Metadata endpoint isolation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C033-T03 · Precondition set:** List the preconditions under which “A guest cannot retrieve host credentials through metadata services” must hold for “Metadata endpoint isolation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C033-T04 · Transition coverage:** Map the “Metadata endpoint isolation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Metadata endpoint isolation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C033-T06 · Satisfying fixture:** Create a concrete “Metadata endpoint isolation” case that satisfies “A guest cannot retrieve host credentials through metadata services”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C033-T07 · Violating fixture:** Create the source counterexample “A guest follows an indirect route to a metadata endpoint” for “Metadata endpoint isolation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C033-T08 · Enforcement evidence:** Exercise the “Metadata endpoint isolation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C033-T09 · Regression linkage:** Link the “Metadata endpoint isolation” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Metadata endpoint isolation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C034 · Integration

**Original checklist item:** Integrate metadata endpoint isolation with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Metadata endpoint isolation” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C034-T02 · Field mapping:** Map every “Metadata endpoint isolation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Metadata endpoint isolation” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C034-T04 · Ownership agreement:** Specify who owns “Metadata endpoint isolation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C034-T05 · Handoff implementation:** Connect “Metadata endpoint isolation” through the mapped seam using the real adapter or explicit specification reference; preserve “A guest cannot retrieve host credentials through metadata services” across the handoff.
- [ ] **UC-M03.04-C034-T06 · Absent-input case:** Omit one required “Metadata endpoint isolation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C034-T07 · Stale-input case:** Supply an outdated “Metadata endpoint isolation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Metadata endpoint isolation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C034-T09 · Valid integration trace:** Run a valid “Metadata endpoint isolation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C034-T10 · Seam review:** Reconcile the “Metadata endpoint isolation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for metadata endpoint isolation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Metadata endpoint isolation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C035-T02 · Expected-result oracle:** Specify the “Metadata endpoint isolation” expected result independently of the implementation output; include the property “A guest cannot retrieve host credentials through metadata services” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C035-T03 · Fixture material:** Create the concrete “Metadata endpoint isolation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C035-T04 · Target preparation:** Prepare the “Metadata endpoint isolation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C035-T05 · Initial-state record:** Record the initial “Metadata endpoint isolation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C035-T06 · Valid-path execution:** Execute the “Metadata endpoint isolation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C035-T07 · Outcome comparison:** Compare every declared “Metadata endpoint isolation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C035-T08 · State and bounds check:** Inspect the “Metadata endpoint isolation” ownership/state effects and actual use of “Address ranges and endpoint tests”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C035-T09 · Repeatability check:** Repeat the same “Metadata endpoint isolation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C035-T10 · Positive evidence:** Attach the “Metadata endpoint isolation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C036 · Negative test

**Original checklist item:** Negative case: A guest follows an indirect route to a metadata endpoint. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Metadata endpoint isolation” source counterexample: “A guest follows an indirect route to a metadata endpoint”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Metadata endpoint isolation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C036-T03 · Valid control:** Construct a valid “Metadata endpoint isolation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C036-T04 · Minimal adverse input:** Derive the “Metadata endpoint isolation” adverse fixture from the control with the smallest documented change needed to reproduce “A guest follows an indirect route to a metadata endpoint”; retain that change as reproducible data.
- [ ] **UC-M03.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Metadata endpoint isolation”; require “A guest cannot retrieve host credentials through metadata services” and forbid a false-success verdict.
- [ ] **UC-M03.04-C036-T06 · Adverse execution:** Exercise the “Metadata endpoint isolation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C036-T07 · Effect inspection:** Inspect “Metadata endpoint isolation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C036-T08 · Refusal versus failure:** Confirm the “Metadata endpoint isolation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C036-T09 · Reset and retention:** Restore only the disposable “Metadata endpoint isolation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C036-T10 · Negative regression:** Register the “Metadata endpoint isolation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C037 · Change / failure test

**Original checklist item:** Exercise metadata endpoint isolation when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C037-T01 · Scenario record:** Write the “Metadata endpoint isolation” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “A guest cannot retrieve host credentials through metadata services”.
- [ ] **UC-M03.04-C037-T02 · Baseline capture:** Create a known-valid “Metadata endpoint isolation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C037-T03 · Injection map:** Locate the “Metadata endpoint isolation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Metadata endpoint isolation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C037-T05 · Controlled trigger:** Introduce the controlled “Metadata endpoint isolation” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C037-T06 · Intermediate inspection:** Inspect the “Metadata endpoint isolation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Metadata endpoint isolation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Metadata endpoint isolation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C037-T09 · Repeat and compare:** Repeat the selected “Metadata endpoint isolation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C037-T10 · Failure evidence:** Publish the “Metadata endpoint isolation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C038 · Bounds

**Original checklist item:** Choose, document and test limits for address ranges and endpoint tests; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Metadata endpoint isolation”: “Address ranges and endpoint tests”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C038-T02 · Measurement method:** Choose how to observe each “Metadata endpoint isolation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C038-T03 · Budget decision:** Select justified resource and input limits for “Metadata endpoint isolation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Metadata endpoint isolation” cases for “Address ranges and endpoint tests”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Metadata endpoint isolation” limit; preserve “A guest cannot retrieve host credentials through metadata services”.
- [ ] **UC-M03.04-C038-T06 · Normal measurement:** Run or review the normal “Metadata endpoint isolation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C038-T07 · At-limit measurement:** Exercise the “Metadata endpoint isolation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C038-T08 · Over-limit measurement:** Exercise the “Metadata endpoint isolation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C038-T09 · Uncovered-scope report:** List the “Metadata endpoint isolation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C038-T10 · Limit evidence:** Publish the selected “Metadata endpoint isolation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for metadata endpoint isolation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C039-T01 · Event inventory:** List the “Metadata endpoint isolation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Metadata endpoint isolation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C039-T03 · Failure mapping:** Map each documented “Metadata endpoint isolation” refusal or error to a diagnostic outcome; include “A guest follows an indirect route to a metadata endpoint” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C039-T04 · Emission path:** Add the “Metadata endpoint isolation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C039-T05 · Redaction check:** Test “Metadata endpoint isolation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C039-T06 · Output budget:** Set and exercise bounded “Metadata endpoint isolation” message size, rate and retention compatible with “Address ranges and endpoint tests”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C039-T07 · Success/refusal fixtures:** Capture “Metadata endpoint isolation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Metadata endpoint isolation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C039-T09 · Operator review:** Read the “Metadata endpoint isolation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C039-T10 · Diagnostic evidence:** Publish redacted “Metadata endpoint isolation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for metadata endpoint isolation; label unexecuted checks as untested.

- [ ] **UC-M03.04-C040-T01 · Evidence inventory:** List the “Metadata endpoint isolation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C040-T02 · Artifact references:** Record the exact “Metadata endpoint isolation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C040-T03 · Fixture references:** Attach the “Metadata endpoint isolation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest follows an indirect route to a metadata endpoint” as a distinct evidence case.
- [ ] **UC-M03.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Metadata endpoint isolation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C040-T05 · Environment record:** Record the actual “Metadata endpoint isolation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C040-T06 · Expected versus observed:** Pair every “Metadata endpoint isolation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C040-T07 · Failure and limit records:** Attach “Metadata endpoint isolation” change/failure and bounds evidence where required; include uncovered “Address ranges and endpoint tests” and unresolved violations of “A guest cannot retrieve host credentials through metadata services”.
- [ ] **UC-M03.04-C040-T08 · Evidence hygiene:** Check the “Metadata endpoint isolation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C040-T09 · Reproduction review:** Have the “Metadata endpoint isolation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C040-T10 · Acceptance linkage:** Link the “Metadata endpoint isolation” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Egress denial

**Source delivery:** Exercise denied outbound traffic for each exposed protocol path.

**Source invariant:** Unapproved egress is denied rather than merely undocumented.

**Source negative case:** A guest reaches an external destination through an overlooked route.

**Source bounded quantities:** Probe traffic and observation window.

### UC-M03.04-C041 · Contract

**Original checklist item:** Specify egress denial inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C041-T01 · Scope statement:** Draft the operation boundary for “Egress denial” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Egress denial”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C041-T03 · Output inventory:** List the outputs of “Egress denial” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Egress denial”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C041-T05 · Prerequisite contract:** Map “Egress denial” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Egress denial”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C041-T07 · Invariant clause:** Add a normative clause for “Egress denial” that preserves “Unapproved egress is denied rather than merely undocumented”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Egress denial”; include the source counterexample “A guest reaches an external destination through an overlooked route” and the intended safe disposition.
- [ ] **UC-M03.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe traffic and observation window” in the “Egress denial” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C041-T10 · Contract review:** Review the “Egress denial” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C042 · Delivery

**Original checklist item:** Exercise denied outbound traffic for each exposed protocol path.

- [ ] **UC-M03.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Egress denial”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C042-T02 · Change plan:** Break the source delivery for “Egress denial” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C042-T03 · Core artifact:** Create the “Egress denial” fixture or harness for this source instruction: Exercise denied outbound traffic for each exposed protocol path.
- [ ] **UC-M03.04-C042-T04 · Concrete realization:** Connect the “Egress denial” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M03.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Egress denial” needed to preserve “Unapproved egress is denied rather than merely undocumented”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C042-T06 · Dependency connection:** Connect the “Egress denial” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C042-T07 · Resource behavior:** Account for “Probe traffic and observation window” in “Egress denial”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C042-T08 · Delivery check:** Run the smallest real “Egress denial” path and its adverse fixture “A guest reaches an external destination through an overlooked route”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C042-T09 · Patch review:** Review the “Egress denial” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C042-T10 · Delivery handoff:** Publish the “Egress denial” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unapproved egress is denied rather than merely undocumented. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Egress denial”; copy its required invariant exactly: “Unapproved egress is denied rather than merely undocumented”.
- [ ] **UC-M03.04-C043-T02 · Observable terms:** Define each term in the “Egress denial” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C043-T03 · Precondition set:** List the preconditions under which “Unapproved egress is denied rather than merely undocumented” must hold for “Egress denial”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C043-T04 · Transition coverage:** Map the “Egress denial” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Egress denial”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C043-T06 · Satisfying fixture:** Create a concrete “Egress denial” case that satisfies “Unapproved egress is denied rather than merely undocumented”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C043-T07 · Violating fixture:** Create the source counterexample “A guest reaches an external destination through an overlooked route” for “Egress denial”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C043-T08 · Enforcement evidence:** Exercise the “Egress denial” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C043-T09 · Regression linkage:** Link the “Egress denial” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Egress denial” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C044 · Integration

**Original checklist item:** Integrate egress denial with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Egress denial” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C044-T02 · Field mapping:** Map every “Egress denial” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Egress denial” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C044-T04 · Ownership agreement:** Specify who owns “Egress denial” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C044-T05 · Handoff implementation:** Connect “Egress denial” through the mapped seam using the real adapter or explicit specification reference; preserve “Unapproved egress is denied rather than merely undocumented” across the handoff.
- [ ] **UC-M03.04-C044-T06 · Absent-input case:** Omit one required “Egress denial” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C044-T07 · Stale-input case:** Supply an outdated “Egress denial” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Egress denial” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C044-T09 · Valid integration trace:** Run a valid “Egress denial” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C044-T10 · Seam review:** Reconcile the “Egress denial” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for egress denial; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Egress denial” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C045-T02 · Expected-result oracle:** Specify the “Egress denial” expected result independently of the implementation output; include the property “Unapproved egress is denied rather than merely undocumented” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C045-T03 · Fixture material:** Create the concrete “Egress denial” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C045-T04 · Target preparation:** Prepare the “Egress denial” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C045-T05 · Initial-state record:** Record the initial “Egress denial” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C045-T06 · Valid-path execution:** Execute the “Egress denial” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C045-T07 · Outcome comparison:** Compare every declared “Egress denial” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C045-T08 · State and bounds check:** Inspect the “Egress denial” ownership/state effects and actual use of “Probe traffic and observation window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C045-T09 · Repeatability check:** Repeat the same “Egress denial” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C045-T10 · Positive evidence:** Attach the “Egress denial” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C046 · Negative test

**Original checklist item:** Negative case: A guest reaches an external destination through an overlooked route. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Egress denial” source counterexample: “A guest reaches an external destination through an overlooked route”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Egress denial”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C046-T03 · Valid control:** Construct a valid “Egress denial” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C046-T04 · Minimal adverse input:** Derive the “Egress denial” adverse fixture from the control with the smallest documented change needed to reproduce “A guest reaches an external destination through an overlooked route”; retain that change as reproducible data.
- [ ] **UC-M03.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Egress denial”; require “Unapproved egress is denied rather than merely undocumented” and forbid a false-success verdict.
- [ ] **UC-M03.04-C046-T06 · Adverse execution:** Exercise the “Egress denial” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C046-T07 · Effect inspection:** Inspect “Egress denial” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C046-T08 · Refusal versus failure:** Confirm the “Egress denial” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C046-T09 · Reset and retention:** Restore only the disposable “Egress denial” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C046-T10 · Negative regression:** Register the “Egress denial” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C047 · Change / failure test

**Original checklist item:** Exercise egress denial when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C047-T01 · Scenario record:** Write the “Egress denial” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “Unapproved egress is denied rather than merely undocumented”.
- [ ] **UC-M03.04-C047-T02 · Baseline capture:** Create a known-valid “Egress denial” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C047-T03 · Injection map:** Locate the “Egress denial” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Egress denial” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C047-T05 · Controlled trigger:** Introduce the controlled “Egress denial” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C047-T06 · Intermediate inspection:** Inspect the “Egress denial” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Egress denial”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Egress denial” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C047-T09 · Repeat and compare:** Repeat the selected “Egress denial” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C047-T10 · Failure evidence:** Publish the “Egress denial” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C048 · Bounds

**Original checklist item:** Choose, document and test limits for probe traffic and observation window; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Egress denial”: “Probe traffic and observation window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C048-T02 · Measurement method:** Choose how to observe each “Egress denial” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C048-T03 · Budget decision:** Select justified resource and input limits for “Egress denial”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Egress denial” cases for “Probe traffic and observation window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Egress denial” limit; preserve “Unapproved egress is denied rather than merely undocumented”.
- [ ] **UC-M03.04-C048-T06 · Normal measurement:** Run or review the normal “Egress denial” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C048-T07 · At-limit measurement:** Exercise the “Egress denial” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C048-T08 · Over-limit measurement:** Exercise the “Egress denial” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C048-T09 · Uncovered-scope report:** List the “Egress denial” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C048-T10 · Limit evidence:** Publish the selected “Egress denial” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for egress denial with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C049-T01 · Event inventory:** List the “Egress denial” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Egress denial” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C049-T03 · Failure mapping:** Map each documented “Egress denial” refusal or error to a diagnostic outcome; include “A guest reaches an external destination through an overlooked route” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C049-T04 · Emission path:** Add the “Egress denial” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C049-T05 · Redaction check:** Test “Egress denial” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C049-T06 · Output budget:** Set and exercise bounded “Egress denial” message size, rate and retention compatible with “Probe traffic and observation window”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C049-T07 · Success/refusal fixtures:** Capture “Egress denial” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Egress denial” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C049-T09 · Operator review:** Read the “Egress denial” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C049-T10 · Diagnostic evidence:** Publish redacted “Egress denial” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for egress denial; label unexecuted checks as untested.

- [ ] **UC-M03.04-C050-T01 · Evidence inventory:** List the “Egress denial” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C050-T02 · Artifact references:** Record the exact “Egress denial” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C050-T03 · Fixture references:** Attach the “Egress denial” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest reaches an external destination through an overlooked route” as a distinct evidence case.
- [ ] **UC-M03.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Egress denial”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C050-T05 · Environment record:** Record the actual “Egress denial” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C050-T06 · Expected versus observed:** Pair every “Egress denial” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C050-T07 · Failure and limit records:** Attach “Egress denial” change/failure and bounds evidence where required; include uncovered “Probe traffic and observation window” and unresolved violations of “Unapproved egress is denied rather than merely undocumented”.
- [ ] **UC-M03.04-C050-T08 · Evidence hygiene:** Check the “Egress denial” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C050-T09 · Reproduction review:** Have the “Egress denial” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C050-T10 · Acceptance linkage:** Link the “Egress denial” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Lateral isolation

**Source delivery:** Prevent one guest from contacting another without an explicit grant.

**Source invariant:** Default policy denies cross-workload traffic.

**Source negative case:** A guest connects to a neighbor using its private address.

**Source bounded quantities:** Peer count and lateral probe matrix.

### UC-M03.04-C051 · Contract

**Original checklist item:** Specify lateral isolation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C051-T01 · Scope statement:** Draft the operation boundary for “Lateral isolation” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Lateral isolation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C051-T03 · Output inventory:** List the outputs of “Lateral isolation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Lateral isolation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C051-T05 · Prerequisite contract:** Map “Lateral isolation” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Lateral isolation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C051-T07 · Invariant clause:** Add a normative clause for “Lateral isolation” that preserves “Default policy denies cross-workload traffic”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Lateral isolation”; include the source counterexample “A guest connects to a neighbor using its private address” and the intended safe disposition.
- [ ] **UC-M03.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Peer count and lateral probe matrix” in the “Lateral isolation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C051-T10 · Contract review:** Review the “Lateral isolation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C052 · Delivery

**Original checklist item:** Prevent one guest from contacting another without an explicit grant.

- [ ] **UC-M03.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Lateral isolation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C052-T02 · Change plan:** Break the source delivery for “Lateral isolation” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Lateral isolation” that realizes this source instruction: Prevent one guest from contacting another without an explicit grant.
- [ ] **UC-M03.04-C052-T04 · Concrete realization:** Trace “Lateral isolation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Lateral isolation” needed to preserve “Default policy denies cross-workload traffic”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C052-T06 · Dependency connection:** Connect the “Lateral isolation” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C052-T07 · Resource behavior:** Account for “Peer count and lateral probe matrix” in “Lateral isolation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C052-T08 · Delivery check:** Run the smallest real “Lateral isolation” path and its adverse fixture “A guest connects to a neighbor using its private address”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C052-T09 · Patch review:** Review the “Lateral isolation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C052-T10 · Delivery handoff:** Publish the “Lateral isolation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Default policy denies cross-workload traffic. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Lateral isolation”; copy its required invariant exactly: “Default policy denies cross-workload traffic”.
- [ ] **UC-M03.04-C053-T02 · Observable terms:** Define each term in the “Lateral isolation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C053-T03 · Precondition set:** List the preconditions under which “Default policy denies cross-workload traffic” must hold for “Lateral isolation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C053-T04 · Transition coverage:** Map the “Lateral isolation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Lateral isolation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C053-T06 · Satisfying fixture:** Create a concrete “Lateral isolation” case that satisfies “Default policy denies cross-workload traffic”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C053-T07 · Violating fixture:** Create the source counterexample “A guest connects to a neighbor using its private address” for “Lateral isolation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C053-T08 · Enforcement evidence:** Exercise the “Lateral isolation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C053-T09 · Regression linkage:** Link the “Lateral isolation” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Lateral isolation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C054 · Integration

**Original checklist item:** Integrate lateral isolation with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Lateral isolation” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C054-T02 · Field mapping:** Map every “Lateral isolation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Lateral isolation” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C054-T04 · Ownership agreement:** Specify who owns “Lateral isolation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C054-T05 · Handoff implementation:** Connect “Lateral isolation” through the mapped seam using the real adapter or explicit specification reference; preserve “Default policy denies cross-workload traffic” across the handoff.
- [ ] **UC-M03.04-C054-T06 · Absent-input case:** Omit one required “Lateral isolation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C054-T07 · Stale-input case:** Supply an outdated “Lateral isolation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Lateral isolation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C054-T09 · Valid integration trace:** Run a valid “Lateral isolation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C054-T10 · Seam review:** Reconcile the “Lateral isolation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for lateral isolation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Lateral isolation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C055-T02 · Expected-result oracle:** Specify the “Lateral isolation” expected result independently of the implementation output; include the property “Default policy denies cross-workload traffic” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C055-T03 · Fixture material:** Create the concrete “Lateral isolation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C055-T04 · Target preparation:** Prepare the “Lateral isolation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C055-T05 · Initial-state record:** Record the initial “Lateral isolation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C055-T06 · Valid-path execution:** Execute the “Lateral isolation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C055-T07 · Outcome comparison:** Compare every declared “Lateral isolation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C055-T08 · State and bounds check:** Inspect the “Lateral isolation” ownership/state effects and actual use of “Peer count and lateral probe matrix”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C055-T09 · Repeatability check:** Repeat the same “Lateral isolation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C055-T10 · Positive evidence:** Attach the “Lateral isolation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C056 · Negative test

**Original checklist item:** Negative case: A guest connects to a neighbor using its private address. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Lateral isolation” source counterexample: “A guest connects to a neighbor using its private address”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Lateral isolation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C056-T03 · Valid control:** Construct a valid “Lateral isolation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C056-T04 · Minimal adverse input:** Derive the “Lateral isolation” adverse fixture from the control with the smallest documented change needed to reproduce “A guest connects to a neighbor using its private address”; retain that change as reproducible data.
- [ ] **UC-M03.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Lateral isolation”; require “Default policy denies cross-workload traffic” and forbid a false-success verdict.
- [ ] **UC-M03.04-C056-T06 · Adverse execution:** Exercise the “Lateral isolation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C056-T07 · Effect inspection:** Inspect “Lateral isolation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C056-T08 · Refusal versus failure:** Confirm the “Lateral isolation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C056-T09 · Reset and retention:** Restore only the disposable “Lateral isolation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C056-T10 · Negative regression:** Register the “Lateral isolation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C057 · Change / failure test

**Original checklist item:** Exercise lateral isolation when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C057-T01 · Scenario record:** Write the “Lateral isolation” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “Default policy denies cross-workload traffic”.
- [ ] **UC-M03.04-C057-T02 · Baseline capture:** Create a known-valid “Lateral isolation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C057-T03 · Injection map:** Locate the “Lateral isolation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Lateral isolation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C057-T05 · Controlled trigger:** Introduce the controlled “Lateral isolation” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C057-T06 · Intermediate inspection:** Inspect the “Lateral isolation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Lateral isolation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Lateral isolation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C057-T09 · Repeat and compare:** Repeat the selected “Lateral isolation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C057-T10 · Failure evidence:** Publish the “Lateral isolation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C058 · Bounds

**Original checklist item:** Choose, document and test limits for peer count and lateral probe matrix; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Lateral isolation”: “Peer count and lateral probe matrix”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C058-T02 · Measurement method:** Choose how to observe each “Lateral isolation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C058-T03 · Budget decision:** Select justified resource and input limits for “Lateral isolation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Lateral isolation” cases for “Peer count and lateral probe matrix”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Lateral isolation” limit; preserve “Default policy denies cross-workload traffic”.
- [ ] **UC-M03.04-C058-T06 · Normal measurement:** Run or review the normal “Lateral isolation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C058-T07 · At-limit measurement:** Exercise the “Lateral isolation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C058-T08 · Over-limit measurement:** Exercise the “Lateral isolation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C058-T09 · Uncovered-scope report:** List the “Lateral isolation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C058-T10 · Limit evidence:** Publish the selected “Lateral isolation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for lateral isolation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C059-T01 · Event inventory:** List the “Lateral isolation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Lateral isolation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C059-T03 · Failure mapping:** Map each documented “Lateral isolation” refusal or error to a diagnostic outcome; include “A guest connects to a neighbor using its private address” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C059-T04 · Emission path:** Add the “Lateral isolation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C059-T05 · Redaction check:** Test “Lateral isolation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C059-T06 · Output budget:** Set and exercise bounded “Lateral isolation” message size, rate and retention compatible with “Peer count and lateral probe matrix”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C059-T07 · Success/refusal fixtures:** Capture “Lateral isolation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Lateral isolation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C059-T09 · Operator review:** Read the “Lateral isolation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C059-T10 · Diagnostic evidence:** Publish redacted “Lateral isolation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for lateral isolation; label unexecuted checks as untested.

- [ ] **UC-M03.04-C060-T01 · Evidence inventory:** List the “Lateral isolation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C060-T02 · Artifact references:** Record the exact “Lateral isolation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C060-T03 · Fixture references:** Attach the “Lateral isolation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest connects to a neighbor using its private address” as a distinct evidence case.
- [ ] **UC-M03.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Lateral isolation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C060-T05 · Environment record:** Record the actual “Lateral isolation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C060-T06 · Expected versus observed:** Pair every “Lateral isolation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C060-T07 · Failure and limit records:** Attach “Lateral isolation” change/failure and bounds evidence where required; include uncovered “Peer count and lateral probe matrix” and unresolved violations of “Default policy denies cross-workload traffic”.
- [ ] **UC-M03.04-C060-T08 · Evidence hygiene:** Check the “Lateral isolation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C060-T09 · Reproduction review:** Have the “Lateral isolation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C060-T10 · Acceptance linkage:** Link the “Lateral isolation” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Policy application ordering

**Source delivery:** Install restrictions before exposing network-capable resources.

**Source invariant:** There is no startup interval with broader connectivity.

**Source negative case:** A guest sends traffic before filters are active.

**Source bounded quantities:** Setup window and policy propagation delay.

### UC-M03.04-C061 · Contract

**Original checklist item:** Specify policy application ordering inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C061-T01 · Scope statement:** Draft the operation boundary for “Policy application ordering” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Policy application ordering”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C061-T03 · Output inventory:** List the outputs of “Policy application ordering” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Policy application ordering”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C061-T05 · Prerequisite contract:** Map “Policy application ordering” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Policy application ordering”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C061-T07 · Invariant clause:** Add a normative clause for “Policy application ordering” that preserves “There is no startup interval with broader connectivity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Policy application ordering”; include the source counterexample “A guest sends traffic before filters are active” and the intended safe disposition.
- [ ] **UC-M03.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Setup window and policy propagation delay” in the “Policy application ordering” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C061-T10 · Contract review:** Review the “Policy application ordering” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C062 · Delivery

**Original checklist item:** Install restrictions before exposing network-capable resources.

- [ ] **UC-M03.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Policy application ordering”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C062-T02 · Change plan:** Break the source delivery for “Policy application ordering” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Policy application ordering” that realizes this source instruction: Install restrictions before exposing network-capable resources.
- [ ] **UC-M03.04-C062-T04 · Concrete realization:** Trace “Policy application ordering” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Policy application ordering” needed to preserve “There is no startup interval with broader connectivity”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C062-T06 · Dependency connection:** Connect the “Policy application ordering” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C062-T07 · Resource behavior:** Account for “Setup window and policy propagation delay” in “Policy application ordering”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C062-T08 · Delivery check:** Run the smallest real “Policy application ordering” path and its adverse fixture “A guest sends traffic before filters are active”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C062-T09 · Patch review:** Review the “Policy application ordering” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C062-T10 · Delivery handoff:** Publish the “Policy application ordering” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: There is no startup interval with broader connectivity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Policy application ordering”; copy its required invariant exactly: “There is no startup interval with broader connectivity”.
- [ ] **UC-M03.04-C063-T02 · Observable terms:** Define each term in the “Policy application ordering” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C063-T03 · Precondition set:** List the preconditions under which “There is no startup interval with broader connectivity” must hold for “Policy application ordering”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C063-T04 · Transition coverage:** Map the “Policy application ordering” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Policy application ordering”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C063-T06 · Satisfying fixture:** Create a concrete “Policy application ordering” case that satisfies “There is no startup interval with broader connectivity”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C063-T07 · Violating fixture:** Create the source counterexample “A guest sends traffic before filters are active” for “Policy application ordering”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C063-T08 · Enforcement evidence:** Exercise the “Policy application ordering” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C063-T09 · Regression linkage:** Link the “Policy application ordering” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Policy application ordering” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C064 · Integration

**Original checklist item:** Integrate policy application ordering with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Policy application ordering” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C064-T02 · Field mapping:** Map every “Policy application ordering” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Policy application ordering” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C064-T04 · Ownership agreement:** Specify who owns “Policy application ordering” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C064-T05 · Handoff implementation:** Connect “Policy application ordering” through the mapped seam using the real adapter or explicit specification reference; preserve “There is no startup interval with broader connectivity” across the handoff.
- [ ] **UC-M03.04-C064-T06 · Absent-input case:** Omit one required “Policy application ordering” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C064-T07 · Stale-input case:** Supply an outdated “Policy application ordering” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Policy application ordering” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C064-T09 · Valid integration trace:** Run a valid “Policy application ordering” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C064-T10 · Seam review:** Reconcile the “Policy application ordering” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for policy application ordering; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Policy application ordering” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C065-T02 · Expected-result oracle:** Specify the “Policy application ordering” expected result independently of the implementation output; include the property “There is no startup interval with broader connectivity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C065-T03 · Fixture material:** Create the concrete “Policy application ordering” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C065-T04 · Target preparation:** Prepare the “Policy application ordering” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C065-T05 · Initial-state record:** Record the initial “Policy application ordering” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C065-T06 · Valid-path execution:** Execute the “Policy application ordering” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C065-T07 · Outcome comparison:** Compare every declared “Policy application ordering” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C065-T08 · State and bounds check:** Inspect the “Policy application ordering” ownership/state effects and actual use of “Setup window and policy propagation delay”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C065-T09 · Repeatability check:** Repeat the same “Policy application ordering” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C065-T10 · Positive evidence:** Attach the “Policy application ordering” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C066 · Negative test

**Original checklist item:** Negative case: A guest sends traffic before filters are active. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Policy application ordering” source counterexample: “A guest sends traffic before filters are active”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Policy application ordering”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C066-T03 · Valid control:** Construct a valid “Policy application ordering” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C066-T04 · Minimal adverse input:** Derive the “Policy application ordering” adverse fixture from the control with the smallest documented change needed to reproduce “A guest sends traffic before filters are active”; retain that change as reproducible data.
- [ ] **UC-M03.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Policy application ordering”; require “There is no startup interval with broader connectivity” and forbid a false-success verdict.
- [ ] **UC-M03.04-C066-T06 · Adverse execution:** Exercise the “Policy application ordering” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C066-T07 · Effect inspection:** Inspect “Policy application ordering” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C066-T08 · Refusal versus failure:** Confirm the “Policy application ordering” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C066-T09 · Reset and retention:** Restore only the disposable “Policy application ordering” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C066-T10 · Negative regression:** Register the “Policy application ordering” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C067 · Change / failure test

**Original checklist item:** Exercise policy application ordering when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C067-T01 · Scenario record:** Write the “Policy application ordering” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “There is no startup interval with broader connectivity”.
- [ ] **UC-M03.04-C067-T02 · Baseline capture:** Create a known-valid “Policy application ordering” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C067-T03 · Injection map:** Locate the “Policy application ordering” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Policy application ordering” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C067-T05 · Controlled trigger:** Introduce the controlled “Policy application ordering” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C067-T06 · Intermediate inspection:** Inspect the “Policy application ordering” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Policy application ordering”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Policy application ordering” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C067-T09 · Repeat and compare:** Repeat the selected “Policy application ordering” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C067-T10 · Failure evidence:** Publish the “Policy application ordering” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C068 · Bounds

**Original checklist item:** Choose, document and test limits for setup window and policy propagation delay; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Policy application ordering”: “Setup window and policy propagation delay”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C068-T02 · Measurement method:** Choose how to observe each “Policy application ordering” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C068-T03 · Budget decision:** Select justified resource and input limits for “Policy application ordering”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Policy application ordering” cases for “Setup window and policy propagation delay”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Policy application ordering” limit; preserve “There is no startup interval with broader connectivity”.
- [ ] **UC-M03.04-C068-T06 · Normal measurement:** Run or review the normal “Policy application ordering” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C068-T07 · At-limit measurement:** Exercise the “Policy application ordering” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C068-T08 · Over-limit measurement:** Exercise the “Policy application ordering” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C068-T09 · Uncovered-scope report:** List the “Policy application ordering” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C068-T10 · Limit evidence:** Publish the selected “Policy application ordering” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for policy application ordering with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C069-T01 · Event inventory:** List the “Policy application ordering” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Policy application ordering” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C069-T03 · Failure mapping:** Map each documented “Policy application ordering” refusal or error to a diagnostic outcome; include “A guest sends traffic before filters are active” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C069-T04 · Emission path:** Add the “Policy application ordering” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C069-T05 · Redaction check:** Test “Policy application ordering” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C069-T06 · Output budget:** Set and exercise bounded “Policy application ordering” message size, rate and retention compatible with “Setup window and policy propagation delay”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C069-T07 · Success/refusal fixtures:** Capture “Policy application ordering” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Policy application ordering” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C069-T09 · Operator review:** Read the “Policy application ordering” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C069-T10 · Diagnostic evidence:** Publish redacted “Policy application ordering” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for policy application ordering; label unexecuted checks as untested.

- [ ] **UC-M03.04-C070-T01 · Evidence inventory:** List the “Policy application ordering” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C070-T02 · Artifact references:** Record the exact “Policy application ordering” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C070-T03 · Fixture references:** Attach the “Policy application ordering” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest sends traffic before filters are active” as a distinct evidence case.
- [ ] **UC-M03.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Policy application ordering”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C070-T05 · Environment record:** Record the actual “Policy application ordering” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C070-T06 · Expected versus observed:** Pair every “Policy application ordering” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C070-T07 · Failure and limit records:** Attach “Policy application ordering” change/failure and bounds evidence where required; include uncovered “Setup window and policy propagation delay” and unresolved violations of “There is no startup interval with broader connectivity”.
- [ ] **UC-M03.04-C070-T08 · Evidence hygiene:** Check the “Policy application ordering” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C070-T09 · Reproduction review:** Have the “Policy application ordering” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C070-T10 · Acceptance linkage:** Link the “Policy application ordering” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Failure and teardown policy

**Source delivery:** Keep restrictions effective through filter failures, guest stop and cleanup.

**Source invariant:** A failed policy update cannot expose broader access.

**Source negative case:** A filter refresh fails after deleting the old rules.

**Source bounded quantities:** Update retries and stale-rule retention.

### UC-M03.04-C071 · Contract

**Original checklist item:** Specify failure and teardown policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C071-T01 · Scope statement:** Draft the operation boundary for “Failure and teardown policy” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure and teardown policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C071-T03 · Output inventory:** List the outputs of “Failure and teardown policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure and teardown policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C071-T05 · Prerequisite contract:** Map “Failure and teardown policy” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Failure and teardown policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C071-T07 · Invariant clause:** Add a normative clause for “Failure and teardown policy” that preserves “A failed policy update cannot expose broader access”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure and teardown policy”; include the source counterexample “A filter refresh fails after deleting the old rules” and the intended safe disposition.
- [ ] **UC-M03.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Update retries and stale-rule retention” in the “Failure and teardown policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C071-T10 · Contract review:** Review the “Failure and teardown policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C072 · Delivery

**Original checklist item:** Keep restrictions effective through filter failures, guest stop and cleanup.

- [ ] **UC-M03.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure and teardown policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C072-T02 · Change plan:** Break the source delivery for “Failure and teardown policy” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Failure and teardown policy” that realizes this source instruction: Keep restrictions effective through filter failures, guest stop and cleanup.
- [ ] **UC-M03.04-C072-T04 · Concrete realization:** Trace “Failure and teardown policy” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure and teardown policy” needed to preserve “A failed policy update cannot expose broader access”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C072-T06 · Dependency connection:** Connect the “Failure and teardown policy” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C072-T07 · Resource behavior:** Account for “Update retries and stale-rule retention” in “Failure and teardown policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C072-T08 · Delivery check:** Run the smallest real “Failure and teardown policy” path and its adverse fixture “A filter refresh fails after deleting the old rules”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C072-T09 · Patch review:** Review the “Failure and teardown policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C072-T10 · Delivery handoff:** Publish the “Failure and teardown policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A failed policy update cannot expose broader access. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Failure and teardown policy”; copy its required invariant exactly: “A failed policy update cannot expose broader access”.
- [ ] **UC-M03.04-C073-T02 · Observable terms:** Define each term in the “Failure and teardown policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C073-T03 · Precondition set:** List the preconditions under which “A failed policy update cannot expose broader access” must hold for “Failure and teardown policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C073-T04 · Transition coverage:** Map the “Failure and teardown policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure and teardown policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C073-T06 · Satisfying fixture:** Create a concrete “Failure and teardown policy” case that satisfies “A failed policy update cannot expose broader access”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C073-T07 · Violating fixture:** Create the source counterexample “A filter refresh fails after deleting the old rules” for “Failure and teardown policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C073-T08 · Enforcement evidence:** Exercise the “Failure and teardown policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C073-T09 · Regression linkage:** Link the “Failure and teardown policy” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Failure and teardown policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C074 · Integration

**Original checklist item:** Integrate failure and teardown policy with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure and teardown policy” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C074-T02 · Field mapping:** Map every “Failure and teardown policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure and teardown policy” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C074-T04 · Ownership agreement:** Specify who owns “Failure and teardown policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C074-T05 · Handoff implementation:** Connect “Failure and teardown policy” through the mapped seam using the real adapter or explicit specification reference; preserve “A failed policy update cannot expose broader access” across the handoff.
- [ ] **UC-M03.04-C074-T06 · Absent-input case:** Omit one required “Failure and teardown policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C074-T07 · Stale-input case:** Supply an outdated “Failure and teardown policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Failure and teardown policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C074-T09 · Valid integration trace:** Run a valid “Failure and teardown policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C074-T10 · Seam review:** Reconcile the “Failure and teardown policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure and teardown policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure and teardown policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C075-T02 · Expected-result oracle:** Specify the “Failure and teardown policy” expected result independently of the implementation output; include the property “A failed policy update cannot expose broader access” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C075-T03 · Fixture material:** Create the concrete “Failure and teardown policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C075-T04 · Target preparation:** Prepare the “Failure and teardown policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C075-T05 · Initial-state record:** Record the initial “Failure and teardown policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C075-T06 · Valid-path execution:** Execute the “Failure and teardown policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C075-T07 · Outcome comparison:** Compare every declared “Failure and teardown policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C075-T08 · State and bounds check:** Inspect the “Failure and teardown policy” ownership/state effects and actual use of “Update retries and stale-rule retention”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C075-T09 · Repeatability check:** Repeat the same “Failure and teardown policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C075-T10 · Positive evidence:** Attach the “Failure and teardown policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C076 · Negative test

**Original checklist item:** Negative case: A filter refresh fails after deleting the old rules. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Failure and teardown policy” source counterexample: “A filter refresh fails after deleting the old rules”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure and teardown policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C076-T03 · Valid control:** Construct a valid “Failure and teardown policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C076-T04 · Minimal adverse input:** Derive the “Failure and teardown policy” adverse fixture from the control with the smallest documented change needed to reproduce “A filter refresh fails after deleting the old rules”; retain that change as reproducible data.
- [ ] **UC-M03.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure and teardown policy”; require “A failed policy update cannot expose broader access” and forbid a false-success verdict.
- [ ] **UC-M03.04-C076-T06 · Adverse execution:** Exercise the “Failure and teardown policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C076-T07 · Effect inspection:** Inspect “Failure and teardown policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C076-T08 · Refusal versus failure:** Confirm the “Failure and teardown policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C076-T09 · Reset and retention:** Restore only the disposable “Failure and teardown policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C076-T10 · Negative regression:** Register the “Failure and teardown policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C077 · Change / failure test

**Original checklist item:** Exercise failure and teardown policy when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C077-T01 · Scenario record:** Write the “Failure and teardown policy” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “A failed policy update cannot expose broader access”.
- [ ] **UC-M03.04-C077-T02 · Baseline capture:** Create a known-valid “Failure and teardown policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C077-T03 · Injection map:** Locate the “Failure and teardown policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Failure and teardown policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C077-T05 · Controlled trigger:** Introduce the controlled “Failure and teardown policy” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C077-T06 · Intermediate inspection:** Inspect the “Failure and teardown policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure and teardown policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure and teardown policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C077-T09 · Repeat and compare:** Repeat the selected “Failure and teardown policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C077-T10 · Failure evidence:** Publish the “Failure and teardown policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C078 · Bounds

**Original checklist item:** Choose, document and test limits for update retries and stale-rule retention; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Failure and teardown policy”: “Update retries and stale-rule retention”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C078-T02 · Measurement method:** Choose how to observe each “Failure and teardown policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C078-T03 · Budget decision:** Select justified resource and input limits for “Failure and teardown policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure and teardown policy” cases for “Update retries and stale-rule retention”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure and teardown policy” limit; preserve “A failed policy update cannot expose broader access”.
- [ ] **UC-M03.04-C078-T06 · Normal measurement:** Run or review the normal “Failure and teardown policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C078-T07 · At-limit measurement:** Exercise the “Failure and teardown policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C078-T08 · Over-limit measurement:** Exercise the “Failure and teardown policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C078-T09 · Uncovered-scope report:** List the “Failure and teardown policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C078-T10 · Limit evidence:** Publish the selected “Failure and teardown policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure and teardown policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C079-T01 · Event inventory:** List the “Failure and teardown policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Failure and teardown policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C079-T03 · Failure mapping:** Map each documented “Failure and teardown policy” refusal or error to a diagnostic outcome; include “A filter refresh fails after deleting the old rules” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C079-T04 · Emission path:** Add the “Failure and teardown policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C079-T05 · Redaction check:** Test “Failure and teardown policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C079-T06 · Output budget:** Set and exercise bounded “Failure and teardown policy” message size, rate and retention compatible with “Update retries and stale-rule retention”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C079-T07 · Success/refusal fixtures:** Capture “Failure and teardown policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure and teardown policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C079-T09 · Operator review:** Read the “Failure and teardown policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C079-T10 · Diagnostic evidence:** Publish redacted “Failure and teardown policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure and teardown policy; label unexecuted checks as untested.

- [ ] **UC-M03.04-C080-T01 · Evidence inventory:** List the “Failure and teardown policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C080-T02 · Artifact references:** Record the exact “Failure and teardown policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C080-T03 · Fixture references:** Attach the “Failure and teardown policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A filter refresh fails after deleting the old rules” as a distinct evidence case.
- [ ] **UC-M03.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure and teardown policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C080-T05 · Environment record:** Record the actual “Failure and teardown policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C080-T06 · Expected versus observed:** Pair every “Failure and teardown policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C080-T07 · Failure and limit records:** Attach “Failure and teardown policy” change/failure and bounds evidence where required; include uncovered “Update retries and stale-rule retention” and unresolved violations of “A failed policy update cannot expose broader access”.
- [ ] **UC-M03.04-C080-T08 · Evidence hygiene:** Check the “Failure and teardown policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C080-T09 · Reproduction review:** Have the “Failure and teardown policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C080-T10 · Acceptance linkage:** Link the “Failure and teardown policy” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Approved-network exceptions

**Source delivery:** Represent each permitted route as an explicit selected-profile grant.

**Source invariant:** A narrow exception cannot enable unrestricted networking.

**Source negative case:** A DNS or transport exception unintentionally permits all destinations.

**Source bounded quantities:** Exception count and permitted endpoint set.

### UC-M03.04-C081 · Contract

**Original checklist item:** Specify approved-network exceptions inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C081-T01 · Scope statement:** Draft the operation boundary for “Approved-network exceptions” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Approved-network exceptions”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C081-T03 · Output inventory:** List the outputs of “Approved-network exceptions” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Approved-network exceptions”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C081-T05 · Prerequisite contract:** Map “Approved-network exceptions” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Approved-network exceptions”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C081-T07 · Invariant clause:** Add a normative clause for “Approved-network exceptions” that preserves “A narrow exception cannot enable unrestricted networking”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Approved-network exceptions”; include the source counterexample “A DNS or transport exception unintentionally permits all destinations” and the intended safe disposition.
- [ ] **UC-M03.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Exception count and permitted endpoint set” in the “Approved-network exceptions” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C081-T10 · Contract review:** Review the “Approved-network exceptions” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C082 · Delivery

**Original checklist item:** Represent each permitted route as an explicit selected-profile grant.

- [ ] **UC-M03.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Approved-network exceptions”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C082-T02 · Change plan:** Break the source delivery for “Approved-network exceptions” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C082-T03 · Core artifact:** Create the “Approved-network exceptions” model, schema or inventory that realizes this source instruction: Represent each permitted route as an explicit selected-profile grant.
- [ ] **UC-M03.04-C082-T04 · Concrete realization:** Populate “Approved-network exceptions” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M03.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Approved-network exceptions” needed to preserve “A narrow exception cannot enable unrestricted networking”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C082-T06 · Dependency connection:** Connect the “Approved-network exceptions” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C082-T07 · Resource behavior:** Account for “Exception count and permitted endpoint set” in “Approved-network exceptions”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C082-T08 · Delivery check:** Run the smallest real “Approved-network exceptions” path and its adverse fixture “A DNS or transport exception unintentionally permits all destinations”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C082-T09 · Patch review:** Review the “Approved-network exceptions” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C082-T10 · Delivery handoff:** Publish the “Approved-network exceptions” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A narrow exception cannot enable unrestricted networking. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Approved-network exceptions”; copy its required invariant exactly: “A narrow exception cannot enable unrestricted networking”.
- [ ] **UC-M03.04-C083-T02 · Observable terms:** Define each term in the “Approved-network exceptions” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C083-T03 · Precondition set:** List the preconditions under which “A narrow exception cannot enable unrestricted networking” must hold for “Approved-network exceptions”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C083-T04 · Transition coverage:** Map the “Approved-network exceptions” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Approved-network exceptions”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C083-T06 · Satisfying fixture:** Create a concrete “Approved-network exceptions” case that satisfies “A narrow exception cannot enable unrestricted networking”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C083-T07 · Violating fixture:** Create the source counterexample “A DNS or transport exception unintentionally permits all destinations” for “Approved-network exceptions”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C083-T08 · Enforcement evidence:** Exercise the “Approved-network exceptions” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C083-T09 · Regression linkage:** Link the “Approved-network exceptions” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Approved-network exceptions” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C084 · Integration

**Original checklist item:** Integrate approved-network exceptions with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Approved-network exceptions” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C084-T02 · Field mapping:** Map every “Approved-network exceptions” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Approved-network exceptions” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C084-T04 · Ownership agreement:** Specify who owns “Approved-network exceptions” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C084-T05 · Handoff implementation:** Connect “Approved-network exceptions” through the mapped seam using the real adapter or explicit specification reference; preserve “A narrow exception cannot enable unrestricted networking” across the handoff.
- [ ] **UC-M03.04-C084-T06 · Absent-input case:** Omit one required “Approved-network exceptions” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C084-T07 · Stale-input case:** Supply an outdated “Approved-network exceptions” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Approved-network exceptions” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C084-T09 · Valid integration trace:** Run a valid “Approved-network exceptions” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C084-T10 · Seam review:** Reconcile the “Approved-network exceptions” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for approved-network exceptions; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Approved-network exceptions” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C085-T02 · Expected-result oracle:** Specify the “Approved-network exceptions” expected result independently of the implementation output; include the property “A narrow exception cannot enable unrestricted networking” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C085-T03 · Fixture material:** Create the concrete “Approved-network exceptions” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C085-T04 · Target preparation:** Prepare the “Approved-network exceptions” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C085-T05 · Initial-state record:** Record the initial “Approved-network exceptions” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C085-T06 · Valid-path execution:** Execute the “Approved-network exceptions” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C085-T07 · Outcome comparison:** Compare every declared “Approved-network exceptions” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C085-T08 · State and bounds check:** Inspect the “Approved-network exceptions” ownership/state effects and actual use of “Exception count and permitted endpoint set”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C085-T09 · Repeatability check:** Repeat the same “Approved-network exceptions” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C085-T10 · Positive evidence:** Attach the “Approved-network exceptions” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C086 · Negative test

**Original checklist item:** Negative case: A DNS or transport exception unintentionally permits all destinations. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Approved-network exceptions” source counterexample: “A DNS or transport exception unintentionally permits all destinations”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Approved-network exceptions”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C086-T03 · Valid control:** Construct a valid “Approved-network exceptions” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C086-T04 · Minimal adverse input:** Derive the “Approved-network exceptions” adverse fixture from the control with the smallest documented change needed to reproduce “A DNS or transport exception unintentionally permits all destinations”; retain that change as reproducible data.
- [ ] **UC-M03.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Approved-network exceptions”; require “A narrow exception cannot enable unrestricted networking” and forbid a false-success verdict.
- [ ] **UC-M03.04-C086-T06 · Adverse execution:** Exercise the “Approved-network exceptions” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C086-T07 · Effect inspection:** Inspect “Approved-network exceptions” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C086-T08 · Refusal versus failure:** Confirm the “Approved-network exceptions” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C086-T09 · Reset and retention:** Restore only the disposable “Approved-network exceptions” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C086-T10 · Negative regression:** Register the “Approved-network exceptions” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C087 · Change / failure test

**Original checklist item:** Exercise approved-network exceptions when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C087-T01 · Scenario record:** Write the “Approved-network exceptions” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “A narrow exception cannot enable unrestricted networking”.
- [ ] **UC-M03.04-C087-T02 · Baseline capture:** Create a known-valid “Approved-network exceptions” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C087-T03 · Injection map:** Locate the “Approved-network exceptions” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Approved-network exceptions” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C087-T05 · Controlled trigger:** Introduce the controlled “Approved-network exceptions” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C087-T06 · Intermediate inspection:** Inspect the “Approved-network exceptions” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Approved-network exceptions”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Approved-network exceptions” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C087-T09 · Repeat and compare:** Repeat the selected “Approved-network exceptions” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C087-T10 · Failure evidence:** Publish the “Approved-network exceptions” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C088 · Bounds

**Original checklist item:** Choose, document and test limits for exception count and permitted endpoint set; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Approved-network exceptions”: “Exception count and permitted endpoint set”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C088-T02 · Measurement method:** Choose how to observe each “Approved-network exceptions” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C088-T03 · Budget decision:** Select justified resource and input limits for “Approved-network exceptions”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Approved-network exceptions” cases for “Exception count and permitted endpoint set”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Approved-network exceptions” limit; preserve “A narrow exception cannot enable unrestricted networking”.
- [ ] **UC-M03.04-C088-T06 · Normal measurement:** Run or review the normal “Approved-network exceptions” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C088-T07 · At-limit measurement:** Exercise the “Approved-network exceptions” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C088-T08 · Over-limit measurement:** Exercise the “Approved-network exceptions” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C088-T09 · Uncovered-scope report:** List the “Approved-network exceptions” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C088-T10 · Limit evidence:** Publish the selected “Approved-network exceptions” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for approved-network exceptions with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C089-T01 · Event inventory:** List the “Approved-network exceptions” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Approved-network exceptions” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C089-T03 · Failure mapping:** Map each documented “Approved-network exceptions” refusal or error to a diagnostic outcome; include “A DNS or transport exception unintentionally permits all destinations” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C089-T04 · Emission path:** Add the “Approved-network exceptions” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C089-T05 · Redaction check:** Test “Approved-network exceptions” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C089-T06 · Output budget:** Set and exercise bounded “Approved-network exceptions” message size, rate and retention compatible with “Exception count and permitted endpoint set”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C089-T07 · Success/refusal fixtures:** Capture “Approved-network exceptions” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Approved-network exceptions” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C089-T09 · Operator review:** Read the “Approved-network exceptions” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C089-T10 · Diagnostic evidence:** Publish redacted “Approved-network exceptions” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for approved-network exceptions; label unexecuted checks as untested.

- [ ] **UC-M03.04-C090-T01 · Evidence inventory:** List the “Approved-network exceptions” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C090-T02 · Artifact references:** Record the exact “Approved-network exceptions” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C090-T03 · Fixture references:** Attach the “Approved-network exceptions” fixture IDs, input identities and oracle definition; preserve the source counterexample “A DNS or transport exception unintentionally permits all destinations” as a distinct evidence case.
- [ ] **UC-M03.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Approved-network exceptions”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C090-T05 · Environment record:** Record the actual “Approved-network exceptions” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C090-T06 · Expected versus observed:** Pair every “Approved-network exceptions” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C090-T07 · Failure and limit records:** Attach “Approved-network exceptions” change/failure and bounds evidence where required; include uncovered “Exception count and permitted endpoint set” and unresolved violations of “A narrow exception cannot enable unrestricted networking”.
- [ ] **UC-M03.04-C090-T08 · Evidence hygiene:** Check the “Approved-network exceptions” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C090-T09 · Reproduction review:** Have the “Approved-network exceptions” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C090-T10 · Acceptance linkage:** Link the “Approved-network exceptions” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Traffic-probe evidence

**Source delivery:** Retain actual connectivity probes and effective device/filter state.

**Source invariant:** NETWORK=deny text alone cannot satisfy the acceptance gate.

**Source negative case:** A release has policy files but no observed denial tests.

**Source bounded quantities:** Probe corpus size and evidence age.

### UC-M03.04-C091 · Contract

**Original checklist item:** Specify traffic-probe evidence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M03.04-C091-T01 · Scope statement:** Draft the operation boundary for “Traffic-probe evidence” within Enforced default-deny networking; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M03.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Traffic-probe evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M03.04-C091-T03 · Output inventory:** List the outputs of “Traffic-probe evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M03.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Traffic-probe evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M03.04-C091-T05 · Prerequisite contract:** Map “Traffic-probe evidence” to the source component prerequisites (UC-M03.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M03.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Traffic-probe evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M03.04-C091-T07 · Invariant clause:** Add a normative clause for “Traffic-probe evidence” that preserves “NETWORK=deny text alone cannot satisfy the acceptance gate”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M03.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Traffic-probe evidence”; include the source counterexample “A release has policy files but no observed denial tests” and the intended safe disposition.
- [ ] **UC-M03.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe corpus size and evidence age” in the “Traffic-probe evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M03.04-C091-T10 · Contract review:** Review the “Traffic-probe evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M03.04-C092 · Delivery

**Original checklist item:** Retain actual connectivity probes and effective device/filter state.

- [ ] **UC-M03.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Traffic-probe evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M03.04-C092-T02 · Change plan:** Break the source delivery for “Traffic-probe evidence” into concrete edit targets and reviewable outputs; keep the UC-M03.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M03.04-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Traffic-probe evidence” that realizes this source instruction: Retain actual connectivity probes and effective device/filter state.
- [ ] **UC-M03.04-C092-T04 · Concrete realization:** Trace “Traffic-probe evidence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M03.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Traffic-probe evidence” needed to preserve “NETWORK=deny text alone cannot satisfy the acceptance gate”; record an enforcement gap where only a model exists.
- [ ] **UC-M03.04-C092-T06 · Dependency connection:** Connect the “Traffic-probe evidence” implementation to guest device setup, host filtering and management endpoint protection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M03.04-C092-T07 · Resource behavior:** Account for “Probe corpus size and evidence age” in “Traffic-probe evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M03.04-C092-T08 · Delivery check:** Run the smallest real “Traffic-probe evidence” path and its adverse fixture “A release has policy files but no observed denial tests”; retain actual output, state effects and final disposition.
- [ ] **UC-M03.04-C092-T09 · Patch review:** Review the “Traffic-probe evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M03.04-C092-T10 · Delivery handoff:** Publish the “Traffic-probe evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M03.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: NETWORK=deny text alone cannot satisfy the acceptance gate. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M03.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Traffic-probe evidence”; copy its required invariant exactly: “NETWORK=deny text alone cannot satisfy the acceptance gate”.
- [ ] **UC-M03.04-C093-T02 · Observable terms:** Define each term in the “Traffic-probe evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M03.04-C093-T03 · Precondition set:** List the preconditions under which “NETWORK=deny text alone cannot satisfy the acceptance gate” must hold for “Traffic-probe evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M03.04-C093-T04 · Transition coverage:** Map the “Traffic-probe evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M03.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Traffic-probe evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M03.04-C093-T06 · Satisfying fixture:** Create a concrete “Traffic-probe evidence” case that satisfies “NETWORK=deny text alone cannot satisfy the acceptance gate”; record its expected observation before running the assertion or review.
- [ ] **UC-M03.04-C093-T07 · Violating fixture:** Create the source counterexample “A release has policy files but no observed denial tests” for “Traffic-probe evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M03.04-C093-T08 · Enforcement evidence:** Exercise the “Traffic-probe evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M03.04-C093-T09 · Regression linkage:** Link the “Traffic-probe evidence” property to changes in guest device setup, host filtering and management endpoint protection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M03.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Traffic-probe evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M03.04-C094 · Integration

**Original checklist item:** Integrate traffic-probe evidence with guest device setup, host filtering and management endpoint protection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M03.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Traffic-probe evidence” across guest device setup, host filtering and management endpoint protection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M03.04-C094-T02 · Field mapping:** Map every “Traffic-probe evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M03.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Traffic-probe evidence” (source dependency list: UC-M03.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M03.04-C094-T04 · Ownership agreement:** Specify who owns “Traffic-probe evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M03.04-C094-T05 · Handoff implementation:** Connect “Traffic-probe evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “NETWORK=deny text alone cannot satisfy the acceptance gate” across the handoff.
- [ ] **UC-M03.04-C094-T06 · Absent-input case:** Omit one required “Traffic-probe evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M03.04-C094-T07 · Stale-input case:** Supply an outdated “Traffic-probe evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M03.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Traffic-probe evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M03.04-C094-T09 · Valid integration trace:** Run a valid “Traffic-probe evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M03.04-C094-T10 · Seam review:** Reconcile the “Traffic-probe evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M03.04-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for traffic-probe evidence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M03.04-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Traffic-probe evidence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M03.04-C095-T02 · Expected-result oracle:** Specify the “Traffic-probe evidence” expected result independently of the implementation output; include the property “NETWORK=deny text alone cannot satisfy the acceptance gate” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M03.04-C095-T03 · Fixture material:** Create the concrete “Traffic-probe evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M03.04-C095-T04 · Target preparation:** Prepare the “Traffic-probe evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M03.04-C095-T05 · Initial-state record:** Record the initial “Traffic-probe evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M03.04-C095-T06 · Valid-path execution:** Execute the “Traffic-probe evidence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M03.04-C095-T07 · Outcome comparison:** Compare every declared “Traffic-probe evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M03.04-C095-T08 · State and bounds check:** Inspect the “Traffic-probe evidence” ownership/state effects and actual use of “Probe corpus size and evidence age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M03.04-C095-T09 · Repeatability check:** Repeat the same “Traffic-probe evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M03.04-C095-T10 · Positive evidence:** Attach the “Traffic-probe evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M03.04-C096 · Negative test

**Original checklist item:** Negative case: A release has policy files but no observed denial tests. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M03.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Traffic-probe evidence” source counterexample: “A release has policy files but no observed denial tests”; state which precondition or invariant it challenges.
- [ ] **UC-M03.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Traffic-probe evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M03.04-C096-T03 · Valid control:** Construct a valid “Traffic-probe evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M03.04-C096-T04 · Minimal adverse input:** Derive the “Traffic-probe evidence” adverse fixture from the control with the smallest documented change needed to reproduce “A release has policy files but no observed denial tests”; retain that change as reproducible data.
- [ ] **UC-M03.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Traffic-probe evidence”; require “NETWORK=deny text alone cannot satisfy the acceptance gate” and forbid a false-success verdict.
- [ ] **UC-M03.04-C096-T06 · Adverse execution:** Exercise the “Traffic-probe evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M03.04-C096-T07 · Effect inspection:** Inspect “Traffic-probe evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M03.04-C096-T08 · Refusal versus failure:** Confirm the “Traffic-probe evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M03.04-C096-T09 · Reset and retention:** Restore only the disposable “Traffic-probe evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M03.04-C096-T10 · Negative regression:** Register the “Traffic-probe evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M03.04-C097 · Change / failure test

**Original checklist item:** Exercise traffic-probe evidence when network policy is refreshed while a guest attempts new traffic; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M03.04-C097-T01 · Scenario record:** Write the “Traffic-probe evidence” change/failure scenario exactly as supplied: network policy is refreshed while a guest attempts new traffic; identify the property that must remain true: “NETWORK=deny text alone cannot satisfy the acceptance gate”.
- [ ] **UC-M03.04-C097-T02 · Baseline capture:** Create a known-valid “Traffic-probe evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M03.04-C097-T03 · Injection map:** Locate the “Traffic-probe evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M03.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Traffic-probe evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M03.04-C097-T05 · Controlled trigger:** Introduce the controlled “Traffic-probe evidence” scenario in the disposable fixture: network policy is refreshed while a guest attempts new traffic; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M03.04-C097-T06 · Intermediate inspection:** Inspect the “Traffic-probe evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M03.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Traffic-probe evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M03.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Traffic-probe evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M03.04-C097-T09 · Repeat and compare:** Repeat the selected “Traffic-probe evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M03.04-C097-T10 · Failure evidence:** Publish the “Traffic-probe evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M03.04-C098 · Bounds

**Original checklist item:** Choose, document and test limits for probe corpus size and evidence age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M03.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Traffic-probe evidence”: “Probe corpus size and evidence age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M03.04-C098-T02 · Measurement method:** Choose how to observe each “Traffic-probe evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M03.04-C098-T03 · Budget decision:** Select justified resource and input limits for “Traffic-probe evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M03.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Traffic-probe evidence” cases for “Probe corpus size and evidence age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M03.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Traffic-probe evidence” limit; preserve “NETWORK=deny text alone cannot satisfy the acceptance gate”.
- [ ] **UC-M03.04-C098-T06 · Normal measurement:** Run or review the normal “Traffic-probe evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M03.04-C098-T07 · At-limit measurement:** Exercise the “Traffic-probe evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M03.04-C098-T08 · Over-limit measurement:** Exercise the “Traffic-probe evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M03.04-C098-T09 · Uncovered-scope report:** List the “Traffic-probe evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M03.04-C098-T10 · Limit evidence:** Publish the selected “Traffic-probe evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M03.04-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for traffic-probe evidence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M03.04-C099-T01 · Event inventory:** List the “Traffic-probe evidence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M03.04-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Traffic-probe evidence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M03.04-C099-T03 · Failure mapping:** Map each documented “Traffic-probe evidence” refusal or error to a diagnostic outcome; include “A release has policy files but no observed denial tests” and prohibit conversion into a success message.
- [ ] **UC-M03.04-C099-T04 · Emission path:** Add the “Traffic-probe evidence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M03.04-C099-T05 · Redaction check:** Test “Traffic-probe evidence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M03.04-C099-T06 · Output budget:** Set and exercise bounded “Traffic-probe evidence” message size, rate and retention compatible with “Probe corpus size and evidence age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M03.04-C099-T07 · Success/refusal fixtures:** Capture “Traffic-probe evidence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M03.04-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Traffic-probe evidence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M03.04-C099-T09 · Operator review:** Read the “Traffic-probe evidence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M03.04-C099-T10 · Diagnostic evidence:** Publish redacted “Traffic-probe evidence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M03.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for traffic-probe evidence; label unexecuted checks as untested.

- [ ] **UC-M03.04-C100-T01 · Evidence inventory:** List the “Traffic-probe evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M03.04-C100-T02 · Artifact references:** Record the exact “Traffic-probe evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M03.04-C100-T03 · Fixture references:** Attach the “Traffic-probe evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A release has policy files but no observed denial tests” as a distinct evidence case.
- [ ] **UC-M03.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Traffic-probe evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M03.04-C100-T05 · Environment record:** Record the actual “Traffic-probe evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M03.04-C100-T06 · Expected versus observed:** Pair every “Traffic-probe evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M03.04-C100-T07 · Failure and limit records:** Attach “Traffic-probe evidence” change/failure and bounds evidence where required; include uncovered “Probe corpus size and evidence age” and unresolved violations of “NETWORK=deny text alone cannot satisfy the acceptance gate”.
- [ ] **UC-M03.04-C100-T08 · Evidence hygiene:** Check the “Traffic-probe evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M03.04-C100-T09 · Reproduction review:** Have the “Traffic-probe evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M03.04-C100-T10 · Acceptance linkage:** Link the “Traffic-probe evidence” evidence to its parent and UC-M03.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

