# UC-M04.05 — Immutable content-addressed image store

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M01.04](../01/UC-M01.04.md), [UC-M04.02](../04/UC-M04.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Address images and dependency blobs by digest, verify reads, publish atomically and separate source from executable outputs.

**Original acceptance criterion:** Interrupted publication exposes no partial image; a modified blob is rejected even when its filename matches.

**Source trace:** Original checklist `UC100/c/04/UC-M04.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 378–388 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Digest namespace

**Source delivery:** Choose explicit digest identifiers for immutable image and dependency objects.

**Source invariant:** An object's identity includes its digest algorithm and content.

**Source negative case:** Two ambiguous digest strings resolve to the same name.

**Source bounded quantities:** Object count and identifier length.

### UC-M04.05-C001 · Contract

**Original checklist item:** Specify digest namespace inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C001-T01 · Scope statement:** Draft the operation boundary for “Digest namespace” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Digest namespace”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C001-T03 · Output inventory:** List the outputs of “Digest namespace” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Digest namespace”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C001-T05 · Prerequisite contract:** Map “Digest namespace” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Digest namespace”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C001-T07 · Invariant clause:** Add a normative clause for “Digest namespace” that preserves “An object's identity includes its digest algorithm and content”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Digest namespace”; include the source counterexample “Two ambiguous digest strings resolve to the same name” and the intended safe disposition.
- [ ] **UC-M04.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Object count and identifier length” in the “Digest namespace” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C001-T10 · Contract review:** Review the “Digest namespace” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C002 · Delivery

**Original checklist item:** Choose explicit digest identifiers for immutable image and dependency objects.

- [ ] **UC-M04.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Digest namespace”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C002-T02 · Change plan:** Break the source delivery for “Digest namespace” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C002-T03 · Core artifact:** Prepare the “Digest namespace” decision record for this source instruction: Choose explicit digest identifiers for immutable image and dependency objects.
- [ ] **UC-M04.05-C002-T04 · Concrete realization:** Evaluate the “Digest namespace” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M04.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Digest namespace” needed to preserve “An object's identity includes its digest algorithm and content”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C002-T06 · Dependency connection:** Connect the “Digest namespace” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C002-T07 · Resource behavior:** Account for “Object count and identifier length” in “Digest namespace”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C002-T08 · Delivery check:** Run the smallest real “Digest namespace” path and its adverse fixture “Two ambiguous digest strings resolve to the same name”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C002-T09 · Patch review:** Review the “Digest namespace” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C002-T10 · Delivery handoff:** Publish the “Digest namespace” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An object's identity includes its digest algorithm and content. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Digest namespace”; copy its required invariant exactly: “An object's identity includes its digest algorithm and content”.
- [ ] **UC-M04.05-C003-T02 · Observable terms:** Define each term in the “Digest namespace” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C003-T03 · Precondition set:** List the preconditions under which “An object's identity includes its digest algorithm and content” must hold for “Digest namespace”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C003-T04 · Transition coverage:** Map the “Digest namespace” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Digest namespace”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C003-T06 · Satisfying fixture:** Create a concrete “Digest namespace” case that satisfies “An object's identity includes its digest algorithm and content”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C003-T07 · Violating fixture:** Create the source counterexample “Two ambiguous digest strings resolve to the same name” for “Digest namespace”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C003-T08 · Enforcement evidence:** Exercise the “Digest namespace” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C003-T09 · Regression linkage:** Link the “Digest namespace” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Digest namespace” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C004 · Integration

**Original checklist item:** Integrate digest namespace with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Digest namespace” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C004-T02 · Field mapping:** Map every “Digest namespace” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Digest namespace” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C004-T04 · Ownership agreement:** Specify who owns “Digest namespace” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C004-T05 · Handoff implementation:** Connect “Digest namespace” through the mapped seam using the real adapter or explicit specification reference; preserve “An object's identity includes its digest algorithm and content” across the handoff.
- [ ] **UC-M04.05-C004-T06 · Absent-input case:** Omit one required “Digest namespace” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C004-T07 · Stale-input case:** Supply an outdated “Digest namespace” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Digest namespace” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C004-T09 · Valid integration trace:** Run a valid “Digest namespace” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C004-T10 · Seam review:** Reconcile the “Digest namespace” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for digest namespace; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Digest namespace” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C005-T02 · Expected-result oracle:** Specify the “Digest namespace” expected result independently of the implementation output; include the property “An object's identity includes its digest algorithm and content” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C005-T03 · Fixture material:** Create the concrete “Digest namespace” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C005-T04 · Target preparation:** Prepare the “Digest namespace” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C005-T05 · Initial-state record:** Record the initial “Digest namespace” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C005-T06 · Valid-path execution:** Execute the “Digest namespace” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C005-T07 · Outcome comparison:** Compare every declared “Digest namespace” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C005-T08 · State and bounds check:** Inspect the “Digest namespace” ownership/state effects and actual use of “Object count and identifier length”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C005-T09 · Repeatability check:** Repeat the same “Digest namespace” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C005-T10 · Positive evidence:** Attach the “Digest namespace” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C006 · Negative test

**Original checklist item:** Negative case: Two ambiguous digest strings resolve to the same name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Digest namespace” source counterexample: “Two ambiguous digest strings resolve to the same name”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Digest namespace”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C006-T03 · Valid control:** Construct a valid “Digest namespace” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C006-T04 · Minimal adverse input:** Derive the “Digest namespace” adverse fixture from the control with the smallest documented change needed to reproduce “Two ambiguous digest strings resolve to the same name”; retain that change as reproducible data.
- [ ] **UC-M04.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Digest namespace”; require “An object's identity includes its digest algorithm and content” and forbid a false-success verdict.
- [ ] **UC-M04.05-C006-T06 · Adverse execution:** Exercise the “Digest namespace” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C006-T07 · Effect inspection:** Inspect “Digest namespace” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C006-T08 · Refusal versus failure:** Confirm the “Digest namespace” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C006-T09 · Reset and retention:** Restore only the disposable “Digest namespace” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C006-T10 · Negative regression:** Register the “Digest namespace” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C007 · Change / failure test

**Original checklist item:** Exercise digest namespace when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C007-T01 · Scenario record:** Write the “Digest namespace” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “An object's identity includes its digest algorithm and content”.
- [ ] **UC-M04.05-C007-T02 · Baseline capture:** Create a known-valid “Digest namespace” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C007-T03 · Injection map:** Locate the “Digest namespace” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Digest namespace” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C007-T05 · Controlled trigger:** Introduce the controlled “Digest namespace” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C007-T06 · Intermediate inspection:** Inspect the “Digest namespace” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Digest namespace”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Digest namespace” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C007-T09 · Repeat and compare:** Repeat the selected “Digest namespace” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C007-T10 · Failure evidence:** Publish the “Digest namespace” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C008 · Bounds

**Original checklist item:** Choose, document and test limits for object count and identifier length; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Digest namespace”: “Object count and identifier length”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C008-T02 · Measurement method:** Choose how to observe each “Digest namespace” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C008-T03 · Budget decision:** Select justified resource and input limits for “Digest namespace”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Digest namespace” cases for “Object count and identifier length”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Digest namespace” limit; preserve “An object's identity includes its digest algorithm and content”.
- [ ] **UC-M04.05-C008-T06 · Normal measurement:** Run or review the normal “Digest namespace” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C008-T07 · At-limit measurement:** Exercise the “Digest namespace” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C008-T08 · Over-limit measurement:** Exercise the “Digest namespace” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C008-T09 · Uncovered-scope report:** List the “Digest namespace” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C008-T10 · Limit evidence:** Publish the selected “Digest namespace” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for digest namespace with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C009-T01 · Event inventory:** List the “Digest namespace” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Digest namespace” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C009-T03 · Failure mapping:** Map each documented “Digest namespace” refusal or error to a diagnostic outcome; include “Two ambiguous digest strings resolve to the same name” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C009-T04 · Emission path:** Add the “Digest namespace” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C009-T05 · Redaction check:** Test “Digest namespace” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C009-T06 · Output budget:** Set and exercise bounded “Digest namespace” message size, rate and retention compatible with “Object count and identifier length”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C009-T07 · Success/refusal fixtures:** Capture “Digest namespace” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Digest namespace” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C009-T09 · Operator review:** Read the “Digest namespace” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C009-T10 · Diagnostic evidence:** Publish redacted “Digest namespace” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for digest namespace; label unexecuted checks as untested.

- [ ] **UC-M04.05-C010-T01 · Evidence inventory:** List the “Digest namespace” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C010-T02 · Artifact references:** Record the exact “Digest namespace” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C010-T03 · Fixture references:** Attach the “Digest namespace” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two ambiguous digest strings resolve to the same name” as a distinct evidence case.
- [ ] **UC-M04.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Digest namespace”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C010-T05 · Environment record:** Record the actual “Digest namespace” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C010-T06 · Expected versus observed:** Pair every “Digest namespace” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C010-T07 · Failure and limit records:** Attach “Digest namespace” change/failure and bounds evidence where required; include uncovered “Object count and identifier length” and unresolved violations of “An object's identity includes its digest algorithm and content”.
- [ ] **UC-M04.05-C010-T08 · Evidence hygiene:** Check the “Digest namespace” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C010-T09 · Reproduction review:** Have the “Digest namespace” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C010-T10 · Acceptance linkage:** Link the “Digest namespace” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Immutable blob writes

**Source delivery:** Write new objects without modifying already published content identities.

**Source invariant:** Published content-addressed objects cannot change in place.

**Source negative case:** A caller overwrites a blob while retaining its digest name.

**Source bounded quantities:** Blob bytes and concurrent writers.

### UC-M04.05-C011 · Contract

**Original checklist item:** Specify immutable blob writes inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C011-T01 · Scope statement:** Draft the operation boundary for “Immutable blob writes” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Immutable blob writes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C011-T03 · Output inventory:** List the outputs of “Immutable blob writes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Immutable blob writes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C011-T05 · Prerequisite contract:** Map “Immutable blob writes” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Immutable blob writes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C011-T07 · Invariant clause:** Add a normative clause for “Immutable blob writes” that preserves “Published content-addressed objects cannot change in place”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Immutable blob writes”; include the source counterexample “A caller overwrites a blob while retaining its digest name” and the intended safe disposition.
- [ ] **UC-M04.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Blob bytes and concurrent writers” in the “Immutable blob writes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C011-T10 · Contract review:** Review the “Immutable blob writes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C012 · Delivery

**Original checklist item:** Write new objects without modifying already published content identities.

- [ ] **UC-M04.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Immutable blob writes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C012-T02 · Change plan:** Break the source delivery for “Immutable blob writes” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Immutable blob writes” that realizes this source instruction: Write new objects without modifying already published content identities.
- [ ] **UC-M04.05-C012-T04 · Concrete realization:** Trace “Immutable blob writes” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Immutable blob writes” needed to preserve “Published content-addressed objects cannot change in place”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C012-T06 · Dependency connection:** Connect the “Immutable blob writes” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C012-T07 · Resource behavior:** Account for “Blob bytes and concurrent writers” in “Immutable blob writes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C012-T08 · Delivery check:** Run the smallest real “Immutable blob writes” path and its adverse fixture “A caller overwrites a blob while retaining its digest name”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C012-T09 · Patch review:** Review the “Immutable blob writes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C012-T10 · Delivery handoff:** Publish the “Immutable blob writes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Published content-addressed objects cannot change in place. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Immutable blob writes”; copy its required invariant exactly: “Published content-addressed objects cannot change in place”.
- [ ] **UC-M04.05-C013-T02 · Observable terms:** Define each term in the “Immutable blob writes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C013-T03 · Precondition set:** List the preconditions under which “Published content-addressed objects cannot change in place” must hold for “Immutable blob writes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C013-T04 · Transition coverage:** Map the “Immutable blob writes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Immutable blob writes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C013-T06 · Satisfying fixture:** Create a concrete “Immutable blob writes” case that satisfies “Published content-addressed objects cannot change in place”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C013-T07 · Violating fixture:** Create the source counterexample “A caller overwrites a blob while retaining its digest name” for “Immutable blob writes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C013-T08 · Enforcement evidence:** Exercise the “Immutable blob writes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C013-T09 · Regression linkage:** Link the “Immutable blob writes” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Immutable blob writes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C014 · Integration

**Original checklist item:** Integrate immutable blob writes with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Immutable blob writes” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C014-T02 · Field mapping:** Map every “Immutable blob writes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Immutable blob writes” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C014-T04 · Ownership agreement:** Specify who owns “Immutable blob writes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C014-T05 · Handoff implementation:** Connect “Immutable blob writes” through the mapped seam using the real adapter or explicit specification reference; preserve “Published content-addressed objects cannot change in place” across the handoff.
- [ ] **UC-M04.05-C014-T06 · Absent-input case:** Omit one required “Immutable blob writes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C014-T07 · Stale-input case:** Supply an outdated “Immutable blob writes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Immutable blob writes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C014-T09 · Valid integration trace:** Run a valid “Immutable blob writes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C014-T10 · Seam review:** Reconcile the “Immutable blob writes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for immutable blob writes; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Immutable blob writes” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C015-T02 · Expected-result oracle:** Specify the “Immutable blob writes” expected result independently of the implementation output; include the property “Published content-addressed objects cannot change in place” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C015-T03 · Fixture material:** Create the concrete “Immutable blob writes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C015-T04 · Target preparation:** Prepare the “Immutable blob writes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C015-T05 · Initial-state record:** Record the initial “Immutable blob writes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C015-T06 · Valid-path execution:** Execute the “Immutable blob writes” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C015-T07 · Outcome comparison:** Compare every declared “Immutable blob writes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C015-T08 · State and bounds check:** Inspect the “Immutable blob writes” ownership/state effects and actual use of “Blob bytes and concurrent writers”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C015-T09 · Repeatability check:** Repeat the same “Immutable blob writes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C015-T10 · Positive evidence:** Attach the “Immutable blob writes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C016 · Negative test

**Original checklist item:** Negative case: A caller overwrites a blob while retaining its digest name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Immutable blob writes” source counterexample: “A caller overwrites a blob while retaining its digest name”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Immutable blob writes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C016-T03 · Valid control:** Construct a valid “Immutable blob writes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C016-T04 · Minimal adverse input:** Derive the “Immutable blob writes” adverse fixture from the control with the smallest documented change needed to reproduce “A caller overwrites a blob while retaining its digest name”; retain that change as reproducible data.
- [ ] **UC-M04.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Immutable blob writes”; require “Published content-addressed objects cannot change in place” and forbid a false-success verdict.
- [ ] **UC-M04.05-C016-T06 · Adverse execution:** Exercise the “Immutable blob writes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C016-T07 · Effect inspection:** Inspect “Immutable blob writes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C016-T08 · Refusal versus failure:** Confirm the “Immutable blob writes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C016-T09 · Reset and retention:** Restore only the disposable “Immutable blob writes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C016-T10 · Negative regression:** Register the “Immutable blob writes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C017 · Change / failure test

**Original checklist item:** Exercise immutable blob writes when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C017-T01 · Scenario record:** Write the “Immutable blob writes” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “Published content-addressed objects cannot change in place”.
- [ ] **UC-M04.05-C017-T02 · Baseline capture:** Create a known-valid “Immutable blob writes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C017-T03 · Injection map:** Locate the “Immutable blob writes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Immutable blob writes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C017-T05 · Controlled trigger:** Introduce the controlled “Immutable blob writes” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C017-T06 · Intermediate inspection:** Inspect the “Immutable blob writes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Immutable blob writes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Immutable blob writes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C017-T09 · Repeat and compare:** Repeat the selected “Immutable blob writes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C017-T10 · Failure evidence:** Publish the “Immutable blob writes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C018 · Bounds

**Original checklist item:** Choose, document and test limits for blob bytes and concurrent writers; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Immutable blob writes”: “Blob bytes and concurrent writers”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C018-T02 · Measurement method:** Choose how to observe each “Immutable blob writes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C018-T03 · Budget decision:** Select justified resource and input limits for “Immutable blob writes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Immutable blob writes” cases for “Blob bytes and concurrent writers”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Immutable blob writes” limit; preserve “Published content-addressed objects cannot change in place”.
- [ ] **UC-M04.05-C018-T06 · Normal measurement:** Run or review the normal “Immutable blob writes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C018-T07 · At-limit measurement:** Exercise the “Immutable blob writes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C018-T08 · Over-limit measurement:** Exercise the “Immutable blob writes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C018-T09 · Uncovered-scope report:** List the “Immutable blob writes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C018-T10 · Limit evidence:** Publish the selected “Immutable blob writes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for immutable blob writes with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C019-T01 · Event inventory:** List the “Immutable blob writes” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Immutable blob writes” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C019-T03 · Failure mapping:** Map each documented “Immutable blob writes” refusal or error to a diagnostic outcome; include “A caller overwrites a blob while retaining its digest name” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C019-T04 · Emission path:** Add the “Immutable blob writes” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C019-T05 · Redaction check:** Test “Immutable blob writes” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C019-T06 · Output budget:** Set and exercise bounded “Immutable blob writes” message size, rate and retention compatible with “Blob bytes and concurrent writers”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C019-T07 · Success/refusal fixtures:** Capture “Immutable blob writes” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Immutable blob writes” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C019-T09 · Operator review:** Read the “Immutable blob writes” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C019-T10 · Diagnostic evidence:** Publish redacted “Immutable blob writes” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for immutable blob writes; label unexecuted checks as untested.

- [ ] **UC-M04.05-C020-T01 · Evidence inventory:** List the “Immutable blob writes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C020-T02 · Artifact references:** Record the exact “Immutable blob writes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C020-T03 · Fixture references:** Attach the “Immutable blob writes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A caller overwrites a blob while retaining its digest name” as a distinct evidence case.
- [ ] **UC-M04.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Immutable blob writes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C020-T05 · Environment record:** Record the actual “Immutable blob writes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C020-T06 · Expected versus observed:** Pair every “Immutable blob writes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C020-T07 · Failure and limit records:** Attach “Immutable blob writes” change/failure and bounds evidence where required; include uncovered “Blob bytes and concurrent writers” and unresolved violations of “Published content-addressed objects cannot change in place”.
- [ ] **UC-M04.05-C020-T08 · Evidence hygiene:** Check the “Immutable blob writes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C020-T09 · Reproduction review:** Have the “Immutable blob writes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C020-T10 · Acceptance linkage:** Link the “Immutable blob writes” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Read-time verification

**Source delivery:** Verify blob content against its declared identity before trusted consumption.

**Source invariant:** A matching filename does not establish matching bytes.

**Source negative case:** A stored image is modified without changing its path.

**Source bounded quantities:** Read bytes and verification latency.

### UC-M04.05-C021 · Contract

**Original checklist item:** Specify read-time verification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C021-T01 · Scope statement:** Draft the operation boundary for “Read-time verification” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Read-time verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C021-T03 · Output inventory:** List the outputs of “Read-time verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Read-time verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C021-T05 · Prerequisite contract:** Map “Read-time verification” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Read-time verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C021-T07 · Invariant clause:** Add a normative clause for “Read-time verification” that preserves “A matching filename does not establish matching bytes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Read-time verification”; include the source counterexample “A stored image is modified without changing its path” and the intended safe disposition.
- [ ] **UC-M04.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Read bytes and verification latency” in the “Read-time verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C021-T10 · Contract review:** Review the “Read-time verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C022 · Delivery

**Original checklist item:** Verify blob content against its declared identity before trusted consumption.

- [ ] **UC-M04.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Read-time verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C022-T02 · Change plan:** Break the source delivery for “Read-time verification” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C022-T03 · Core artifact:** Create the “Read-time verification” fixture or harness for this source instruction: Verify blob content against its declared identity before trusted consumption.
- [ ] **UC-M04.05-C022-T04 · Concrete realization:** Connect the “Read-time verification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Read-time verification” needed to preserve “A matching filename does not establish matching bytes”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C022-T06 · Dependency connection:** Connect the “Read-time verification” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C022-T07 · Resource behavior:** Account for “Read bytes and verification latency” in “Read-time verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C022-T08 · Delivery check:** Run the smallest real “Read-time verification” path and its adverse fixture “A stored image is modified without changing its path”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C022-T09 · Patch review:** Review the “Read-time verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C022-T10 · Delivery handoff:** Publish the “Read-time verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A matching filename does not establish matching bytes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Read-time verification”; copy its required invariant exactly: “A matching filename does not establish matching bytes”.
- [ ] **UC-M04.05-C023-T02 · Observable terms:** Define each term in the “Read-time verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C023-T03 · Precondition set:** List the preconditions under which “A matching filename does not establish matching bytes” must hold for “Read-time verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C023-T04 · Transition coverage:** Map the “Read-time verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Read-time verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C023-T06 · Satisfying fixture:** Create a concrete “Read-time verification” case that satisfies “A matching filename does not establish matching bytes”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C023-T07 · Violating fixture:** Create the source counterexample “A stored image is modified without changing its path” for “Read-time verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C023-T08 · Enforcement evidence:** Exercise the “Read-time verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C023-T09 · Regression linkage:** Link the “Read-time verification” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Read-time verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C024 · Integration

**Original checklist item:** Integrate read-time verification with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Read-time verification” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C024-T02 · Field mapping:** Map every “Read-time verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Read-time verification” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C024-T04 · Ownership agreement:** Specify who owns “Read-time verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C024-T05 · Handoff implementation:** Connect “Read-time verification” through the mapped seam using the real adapter or explicit specification reference; preserve “A matching filename does not establish matching bytes” across the handoff.
- [ ] **UC-M04.05-C024-T06 · Absent-input case:** Omit one required “Read-time verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C024-T07 · Stale-input case:** Supply an outdated “Read-time verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Read-time verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C024-T09 · Valid integration trace:** Run a valid “Read-time verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C024-T10 · Seam review:** Reconcile the “Read-time verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for read-time verification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Read-time verification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C025-T02 · Expected-result oracle:** Specify the “Read-time verification” expected result independently of the implementation output; include the property “A matching filename does not establish matching bytes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C025-T03 · Fixture material:** Create the concrete “Read-time verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C025-T04 · Target preparation:** Prepare the “Read-time verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C025-T05 · Initial-state record:** Record the initial “Read-time verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C025-T06 · Valid-path execution:** Execute the “Read-time verification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C025-T07 · Outcome comparison:** Compare every declared “Read-time verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C025-T08 · State and bounds check:** Inspect the “Read-time verification” ownership/state effects and actual use of “Read bytes and verification latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C025-T09 · Repeatability check:** Repeat the same “Read-time verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C025-T10 · Positive evidence:** Attach the “Read-time verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C026 · Negative test

**Original checklist item:** Negative case: A stored image is modified without changing its path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Read-time verification” source counterexample: “A stored image is modified without changing its path”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Read-time verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C026-T03 · Valid control:** Construct a valid “Read-time verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C026-T04 · Minimal adverse input:** Derive the “Read-time verification” adverse fixture from the control with the smallest documented change needed to reproduce “A stored image is modified without changing its path”; retain that change as reproducible data.
- [ ] **UC-M04.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Read-time verification”; require “A matching filename does not establish matching bytes” and forbid a false-success verdict.
- [ ] **UC-M04.05-C026-T06 · Adverse execution:** Exercise the “Read-time verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C026-T07 · Effect inspection:** Inspect “Read-time verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C026-T08 · Refusal versus failure:** Confirm the “Read-time verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C026-T09 · Reset and retention:** Restore only the disposable “Read-time verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C026-T10 · Negative regression:** Register the “Read-time verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C027 · Change / failure test

**Original checklist item:** Exercise read-time verification when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C027-T01 · Scenario record:** Write the “Read-time verification” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “A matching filename does not establish matching bytes”.
- [ ] **UC-M04.05-C027-T02 · Baseline capture:** Create a known-valid “Read-time verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C027-T03 · Injection map:** Locate the “Read-time verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Read-time verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C027-T05 · Controlled trigger:** Introduce the controlled “Read-time verification” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C027-T06 · Intermediate inspection:** Inspect the “Read-time verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Read-time verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Read-time verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C027-T09 · Repeat and compare:** Repeat the selected “Read-time verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C027-T10 · Failure evidence:** Publish the “Read-time verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C028 · Bounds

**Original checklist item:** Choose, document and test limits for read bytes and verification latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Read-time verification”: “Read bytes and verification latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C028-T02 · Measurement method:** Choose how to observe each “Read-time verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C028-T03 · Budget decision:** Select justified resource and input limits for “Read-time verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Read-time verification” cases for “Read bytes and verification latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Read-time verification” limit; preserve “A matching filename does not establish matching bytes”.
- [ ] **UC-M04.05-C028-T06 · Normal measurement:** Run or review the normal “Read-time verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C028-T07 · At-limit measurement:** Exercise the “Read-time verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C028-T08 · Over-limit measurement:** Exercise the “Read-time verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C028-T09 · Uncovered-scope report:** List the “Read-time verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C028-T10 · Limit evidence:** Publish the selected “Read-time verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for read-time verification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C029-T01 · Event inventory:** List the “Read-time verification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Read-time verification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C029-T03 · Failure mapping:** Map each documented “Read-time verification” refusal or error to a diagnostic outcome; include “A stored image is modified without changing its path” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C029-T04 · Emission path:** Add the “Read-time verification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C029-T05 · Redaction check:** Test “Read-time verification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C029-T06 · Output budget:** Set and exercise bounded “Read-time verification” message size, rate and retention compatible with “Read bytes and verification latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C029-T07 · Success/refusal fixtures:** Capture “Read-time verification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Read-time verification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C029-T09 · Operator review:** Read the “Read-time verification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C029-T10 · Diagnostic evidence:** Publish redacted “Read-time verification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for read-time verification; label unexecuted checks as untested.

- [ ] **UC-M04.05-C030-T01 · Evidence inventory:** List the “Read-time verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C030-T02 · Artifact references:** Record the exact “Read-time verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C030-T03 · Fixture references:** Attach the “Read-time verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stored image is modified without changing its path” as a distinct evidence case.
- [ ] **UC-M04.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Read-time verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C030-T05 · Environment record:** Record the actual “Read-time verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C030-T06 · Expected versus observed:** Pair every “Read-time verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C030-T07 · Failure and limit records:** Attach “Read-time verification” change/failure and bounds evidence where required; include uncovered “Read bytes and verification latency” and unresolved violations of “A matching filename does not establish matching bytes”.
- [ ] **UC-M04.05-C030-T08 · Evidence hygiene:** Check the “Read-time verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C030-T09 · Reproduction review:** Have the “Read-time verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C030-T10 · Acceptance linkage:** Link the “Read-time verification” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Atomic publication

**Source delivery:** Publish a complete verified object only after staging succeeds.

**Source invariant:** Interrupted publication exposes no partial valid object.

**Source negative case:** A process dies halfway through image publication.

**Source bounded quantities:** Staging bytes and publication deadline.

### UC-M04.05-C031 · Contract

**Original checklist item:** Specify atomic publication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C031-T01 · Scope statement:** Draft the operation boundary for “Atomic publication” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Atomic publication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C031-T03 · Output inventory:** List the outputs of “Atomic publication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Atomic publication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C031-T05 · Prerequisite contract:** Map “Atomic publication” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Atomic publication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C031-T07 · Invariant clause:** Add a normative clause for “Atomic publication” that preserves “Interrupted publication exposes no partial valid object”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Atomic publication”; include the source counterexample “A process dies halfway through image publication” and the intended safe disposition.
- [ ] **UC-M04.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Staging bytes and publication deadline” in the “Atomic publication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C031-T10 · Contract review:** Review the “Atomic publication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C032 · Delivery

**Original checklist item:** Publish a complete verified object only after staging succeeds.

- [ ] **UC-M04.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Atomic publication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C032-T02 · Change plan:** Break the source delivery for “Atomic publication” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C032-T03 · Core artifact:** Create the “Atomic publication” output artifact for this source instruction: Publish a complete verified object only after staging succeeds.
- [ ] **UC-M04.05-C032-T04 · Concrete realization:** Populate the “Atomic publication” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M04.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Atomic publication” needed to preserve “Interrupted publication exposes no partial valid object”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C032-T06 · Dependency connection:** Connect the “Atomic publication” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C032-T07 · Resource behavior:** Account for “Staging bytes and publication deadline” in “Atomic publication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C032-T08 · Delivery check:** Run the smallest real “Atomic publication” path and its adverse fixture “A process dies halfway through image publication”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C032-T09 · Patch review:** Review the “Atomic publication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C032-T10 · Delivery handoff:** Publish the “Atomic publication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Interrupted publication exposes no partial valid object. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Atomic publication”; copy its required invariant exactly: “Interrupted publication exposes no partial valid object”.
- [ ] **UC-M04.05-C033-T02 · Observable terms:** Define each term in the “Atomic publication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C033-T03 · Precondition set:** List the preconditions under which “Interrupted publication exposes no partial valid object” must hold for “Atomic publication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C033-T04 · Transition coverage:** Map the “Atomic publication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Atomic publication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C033-T06 · Satisfying fixture:** Create a concrete “Atomic publication” case that satisfies “Interrupted publication exposes no partial valid object”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C033-T07 · Violating fixture:** Create the source counterexample “A process dies halfway through image publication” for “Atomic publication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C033-T08 · Enforcement evidence:** Exercise the “Atomic publication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C033-T09 · Regression linkage:** Link the “Atomic publication” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Atomic publication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C034 · Integration

**Original checklist item:** Integrate atomic publication with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Atomic publication” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C034-T02 · Field mapping:** Map every “Atomic publication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Atomic publication” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C034-T04 · Ownership agreement:** Specify who owns “Atomic publication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C034-T05 · Handoff implementation:** Connect “Atomic publication” through the mapped seam using the real adapter or explicit specification reference; preserve “Interrupted publication exposes no partial valid object” across the handoff.
- [ ] **UC-M04.05-C034-T06 · Absent-input case:** Omit one required “Atomic publication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C034-T07 · Stale-input case:** Supply an outdated “Atomic publication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Atomic publication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C034-T09 · Valid integration trace:** Run a valid “Atomic publication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C034-T10 · Seam review:** Reconcile the “Atomic publication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for atomic publication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Atomic publication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C035-T02 · Expected-result oracle:** Specify the “Atomic publication” expected result independently of the implementation output; include the property “Interrupted publication exposes no partial valid object” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C035-T03 · Fixture material:** Create the concrete “Atomic publication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C035-T04 · Target preparation:** Prepare the “Atomic publication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C035-T05 · Initial-state record:** Record the initial “Atomic publication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C035-T06 · Valid-path execution:** Execute the “Atomic publication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C035-T07 · Outcome comparison:** Compare every declared “Atomic publication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C035-T08 · State and bounds check:** Inspect the “Atomic publication” ownership/state effects and actual use of “Staging bytes and publication deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C035-T09 · Repeatability check:** Repeat the same “Atomic publication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C035-T10 · Positive evidence:** Attach the “Atomic publication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C036 · Negative test

**Original checklist item:** Negative case: A process dies halfway through image publication. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Atomic publication” source counterexample: “A process dies halfway through image publication”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Atomic publication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C036-T03 · Valid control:** Construct a valid “Atomic publication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C036-T04 · Minimal adverse input:** Derive the “Atomic publication” adverse fixture from the control with the smallest documented change needed to reproduce “A process dies halfway through image publication”; retain that change as reproducible data.
- [ ] **UC-M04.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Atomic publication”; require “Interrupted publication exposes no partial valid object” and forbid a false-success verdict.
- [ ] **UC-M04.05-C036-T06 · Adverse execution:** Exercise the “Atomic publication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C036-T07 · Effect inspection:** Inspect “Atomic publication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C036-T08 · Refusal versus failure:** Confirm the “Atomic publication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C036-T09 · Reset and retention:** Restore only the disposable “Atomic publication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C036-T10 · Negative regression:** Register the “Atomic publication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C037 · Change / failure test

**Original checklist item:** Exercise atomic publication when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C037-T01 · Scenario record:** Write the “Atomic publication” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “Interrupted publication exposes no partial valid object”.
- [ ] **UC-M04.05-C037-T02 · Baseline capture:** Create a known-valid “Atomic publication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C037-T03 · Injection map:** Locate the “Atomic publication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Atomic publication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C037-T05 · Controlled trigger:** Introduce the controlled “Atomic publication” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C037-T06 · Intermediate inspection:** Inspect the “Atomic publication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Atomic publication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Atomic publication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C037-T09 · Repeat and compare:** Repeat the selected “Atomic publication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C037-T10 · Failure evidence:** Publish the “Atomic publication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C038 · Bounds

**Original checklist item:** Choose, document and test limits for staging bytes and publication deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Atomic publication”: “Staging bytes and publication deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C038-T02 · Measurement method:** Choose how to observe each “Atomic publication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C038-T03 · Budget decision:** Select justified resource and input limits for “Atomic publication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Atomic publication” cases for “Staging bytes and publication deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Atomic publication” limit; preserve “Interrupted publication exposes no partial valid object”.
- [ ] **UC-M04.05-C038-T06 · Normal measurement:** Run or review the normal “Atomic publication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C038-T07 · At-limit measurement:** Exercise the “Atomic publication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C038-T08 · Over-limit measurement:** Exercise the “Atomic publication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C038-T09 · Uncovered-scope report:** List the “Atomic publication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C038-T10 · Limit evidence:** Publish the selected “Atomic publication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for atomic publication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C039-T01 · Event inventory:** List the “Atomic publication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Atomic publication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C039-T03 · Failure mapping:** Map each documented “Atomic publication” refusal or error to a diagnostic outcome; include “A process dies halfway through image publication” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C039-T04 · Emission path:** Add the “Atomic publication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C039-T05 · Redaction check:** Test “Atomic publication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C039-T06 · Output budget:** Set and exercise bounded “Atomic publication” message size, rate and retention compatible with “Staging bytes and publication deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C039-T07 · Success/refusal fixtures:** Capture “Atomic publication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Atomic publication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C039-T09 · Operator review:** Read the “Atomic publication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C039-T10 · Diagnostic evidence:** Publish redacted “Atomic publication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for atomic publication; label unexecuted checks as untested.

- [ ] **UC-M04.05-C040-T01 · Evidence inventory:** List the “Atomic publication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C040-T02 · Artifact references:** Record the exact “Atomic publication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C040-T03 · Fixture references:** Attach the “Atomic publication” fixture IDs, input identities and oracle definition; preserve the source counterexample “A process dies halfway through image publication” as a distinct evidence case.
- [ ] **UC-M04.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Atomic publication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C040-T05 · Environment record:** Record the actual “Atomic publication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C040-T06 · Expected versus observed:** Pair every “Atomic publication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C040-T07 · Failure and limit records:** Attach “Atomic publication” change/failure and bounds evidence where required; include uncovered “Staging bytes and publication deadline” and unresolved violations of “Interrupted publication exposes no partial valid object”.
- [ ] **UC-M04.05-C040-T08 · Evidence hygiene:** Check the “Atomic publication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C040-T09 · Reproduction review:** Have the “Atomic publication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C040-T10 · Acceptance linkage:** Link the “Atomic publication” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Source/output separation

**Source delivery:** Keep source inputs distinct from executable image outputs in storage policy.

**Source invariant:** Source files cannot be executed merely because they share a storage root.

**Source negative case:** An importer marks a source archive as an admitted executable image.

**Source bounded quantities:** Namespaces and storage roots.

### UC-M04.05-C041 · Contract

**Original checklist item:** Specify source/output separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C041-T01 · Scope statement:** Draft the operation boundary for “Source/output separation” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Source/output separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C041-T03 · Output inventory:** List the outputs of “Source/output separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Source/output separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C041-T05 · Prerequisite contract:** Map “Source/output separation” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Source/output separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C041-T07 · Invariant clause:** Add a normative clause for “Source/output separation” that preserves “Source files cannot be executed merely because they share a storage root”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Source/output separation”; include the source counterexample “An importer marks a source archive as an admitted executable image” and the intended safe disposition.
- [ ] **UC-M04.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Namespaces and storage roots” in the “Source/output separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C041-T10 · Contract review:** Review the “Source/output separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C042 · Delivery

**Original checklist item:** Keep source inputs distinct from executable image outputs in storage policy.

- [ ] **UC-M04.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Source/output separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C042-T02 · Change plan:** Break the source delivery for “Source/output separation” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Source/output separation” that realizes this source instruction: Keep source inputs distinct from executable image outputs in storage policy.
- [ ] **UC-M04.05-C042-T04 · Concrete realization:** Trace “Source/output separation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Source/output separation” needed to preserve “Source files cannot be executed merely because they share a storage root”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C042-T06 · Dependency connection:** Connect the “Source/output separation” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C042-T07 · Resource behavior:** Account for “Namespaces and storage roots” in “Source/output separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C042-T08 · Delivery check:** Run the smallest real “Source/output separation” path and its adverse fixture “An importer marks a source archive as an admitted executable image”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C042-T09 · Patch review:** Review the “Source/output separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C042-T10 · Delivery handoff:** Publish the “Source/output separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Source files cannot be executed merely because they share a storage root. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Source/output separation”; copy its required invariant exactly: “Source files cannot be executed merely because they share a storage root”.
- [ ] **UC-M04.05-C043-T02 · Observable terms:** Define each term in the “Source/output separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C043-T03 · Precondition set:** List the preconditions under which “Source files cannot be executed merely because they share a storage root” must hold for “Source/output separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C043-T04 · Transition coverage:** Map the “Source/output separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Source/output separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C043-T06 · Satisfying fixture:** Create a concrete “Source/output separation” case that satisfies “Source files cannot be executed merely because they share a storage root”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C043-T07 · Violating fixture:** Create the source counterexample “An importer marks a source archive as an admitted executable image” for “Source/output separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C043-T08 · Enforcement evidence:** Exercise the “Source/output separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C043-T09 · Regression linkage:** Link the “Source/output separation” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Source/output separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C044 · Integration

**Original checklist item:** Integrate source/output separation with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Source/output separation” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C044-T02 · Field mapping:** Map every “Source/output separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Source/output separation” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C044-T04 · Ownership agreement:** Specify who owns “Source/output separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C044-T05 · Handoff implementation:** Connect “Source/output separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Source files cannot be executed merely because they share a storage root” across the handoff.
- [ ] **UC-M04.05-C044-T06 · Absent-input case:** Omit one required “Source/output separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C044-T07 · Stale-input case:** Supply an outdated “Source/output separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Source/output separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C044-T09 · Valid integration trace:** Run a valid “Source/output separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C044-T10 · Seam review:** Reconcile the “Source/output separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for source/output separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Source/output separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C045-T02 · Expected-result oracle:** Specify the “Source/output separation” expected result independently of the implementation output; include the property “Source files cannot be executed merely because they share a storage root” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C045-T03 · Fixture material:** Create the concrete “Source/output separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C045-T04 · Target preparation:** Prepare the “Source/output separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C045-T05 · Initial-state record:** Record the initial “Source/output separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C045-T06 · Valid-path execution:** Execute the “Source/output separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C045-T07 · Outcome comparison:** Compare every declared “Source/output separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C045-T08 · State and bounds check:** Inspect the “Source/output separation” ownership/state effects and actual use of “Namespaces and storage roots”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C045-T09 · Repeatability check:** Repeat the same “Source/output separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C045-T10 · Positive evidence:** Attach the “Source/output separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C046 · Negative test

**Original checklist item:** Negative case: An importer marks a source archive as an admitted executable image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Source/output separation” source counterexample: “An importer marks a source archive as an admitted executable image”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Source/output separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C046-T03 · Valid control:** Construct a valid “Source/output separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C046-T04 · Minimal adverse input:** Derive the “Source/output separation” adverse fixture from the control with the smallest documented change needed to reproduce “An importer marks a source archive as an admitted executable image”; retain that change as reproducible data.
- [ ] **UC-M04.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Source/output separation”; require “Source files cannot be executed merely because they share a storage root” and forbid a false-success verdict.
- [ ] **UC-M04.05-C046-T06 · Adverse execution:** Exercise the “Source/output separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C046-T07 · Effect inspection:** Inspect “Source/output separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C046-T08 · Refusal versus failure:** Confirm the “Source/output separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C046-T09 · Reset and retention:** Restore only the disposable “Source/output separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C046-T10 · Negative regression:** Register the “Source/output separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C047 · Change / failure test

**Original checklist item:** Exercise source/output separation when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C047-T01 · Scenario record:** Write the “Source/output separation” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “Source files cannot be executed merely because they share a storage root”.
- [ ] **UC-M04.05-C047-T02 · Baseline capture:** Create a known-valid “Source/output separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C047-T03 · Injection map:** Locate the “Source/output separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Source/output separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C047-T05 · Controlled trigger:** Introduce the controlled “Source/output separation” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C047-T06 · Intermediate inspection:** Inspect the “Source/output separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Source/output separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Source/output separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C047-T09 · Repeat and compare:** Repeat the selected “Source/output separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C047-T10 · Failure evidence:** Publish the “Source/output separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C048 · Bounds

**Original checklist item:** Choose, document and test limits for namespaces and storage roots; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Source/output separation”: “Namespaces and storage roots”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C048-T02 · Measurement method:** Choose how to observe each “Source/output separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C048-T03 · Budget decision:** Select justified resource and input limits for “Source/output separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Source/output separation” cases for “Namespaces and storage roots”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Source/output separation” limit; preserve “Source files cannot be executed merely because they share a storage root”.
- [ ] **UC-M04.05-C048-T06 · Normal measurement:** Run or review the normal “Source/output separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C048-T07 · At-limit measurement:** Exercise the “Source/output separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C048-T08 · Over-limit measurement:** Exercise the “Source/output separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C048-T09 · Uncovered-scope report:** List the “Source/output separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C048-T10 · Limit evidence:** Publish the selected “Source/output separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for source/output separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C049-T01 · Event inventory:** List the “Source/output separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Source/output separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C049-T03 · Failure mapping:** Map each documented “Source/output separation” refusal or error to a diagnostic outcome; include “An importer marks a source archive as an admitted executable image” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C049-T04 · Emission path:** Add the “Source/output separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C049-T05 · Redaction check:** Test “Source/output separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C049-T06 · Output budget:** Set and exercise bounded “Source/output separation” message size, rate and retention compatible with “Namespaces and storage roots”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C049-T07 · Success/refusal fixtures:** Capture “Source/output separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Source/output separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C049-T09 · Operator review:** Read the “Source/output separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C049-T10 · Diagnostic evidence:** Publish redacted “Source/output separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for source/output separation; label unexecuted checks as untested.

- [ ] **UC-M04.05-C050-T01 · Evidence inventory:** List the “Source/output separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C050-T02 · Artifact references:** Record the exact “Source/output separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C050-T03 · Fixture references:** Attach the “Source/output separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “An importer marks a source archive as an admitted executable image” as a distinct evidence case.
- [ ] **UC-M04.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Source/output separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C050-T05 · Environment record:** Record the actual “Source/output separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C050-T06 · Expected versus observed:** Pair every “Source/output separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C050-T07 · Failure and limit records:** Attach “Source/output separation” change/failure and bounds evidence where required; include uncovered “Namespaces and storage roots” and unresolved violations of “Source files cannot be executed merely because they share a storage root”.
- [ ] **UC-M04.05-C050-T08 · Evidence hygiene:** Check the “Source/output separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C050-T09 · Reproduction review:** Have the “Source/output separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C050-T10 · Acceptance linkage:** Link the “Source/output separation” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Concurrent put handling

**Source delivery:** Resolve simultaneous publication of the same digest safely.

**Source invariant:** Duplicate puts converge on identical verified bytes.

**Source negative case:** Two writers publish conflicting content under one claimed digest.

**Source bounded quantities:** Concurrent puts and lock wait.

### UC-M04.05-C051 · Contract

**Original checklist item:** Specify concurrent put handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C051-T01 · Scope statement:** Draft the operation boundary for “Concurrent put handling” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Concurrent put handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C051-T03 · Output inventory:** List the outputs of “Concurrent put handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Concurrent put handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C051-T05 · Prerequisite contract:** Map “Concurrent put handling” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Concurrent put handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C051-T07 · Invariant clause:** Add a normative clause for “Concurrent put handling” that preserves “Duplicate puts converge on identical verified bytes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Concurrent put handling”; include the source counterexample “Two writers publish conflicting content under one claimed digest” and the intended safe disposition.
- [ ] **UC-M04.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent puts and lock wait” in the “Concurrent put handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C051-T10 · Contract review:** Review the “Concurrent put handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C052 · Delivery

**Original checklist item:** Resolve simultaneous publication of the same digest safely.

- [ ] **UC-M04.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Concurrent put handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C052-T02 · Change plan:** Break the source delivery for “Concurrent put handling” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Concurrent put handling” that realizes this source instruction: Resolve simultaneous publication of the same digest safely.
- [ ] **UC-M04.05-C052-T04 · Concrete realization:** Trace “Concurrent put handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Concurrent put handling” needed to preserve “Duplicate puts converge on identical verified bytes”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C052-T06 · Dependency connection:** Connect the “Concurrent put handling” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C052-T07 · Resource behavior:** Account for “Concurrent puts and lock wait” in “Concurrent put handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C052-T08 · Delivery check:** Run the smallest real “Concurrent put handling” path and its adverse fixture “Two writers publish conflicting content under one claimed digest”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C052-T09 · Patch review:** Review the “Concurrent put handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C052-T10 · Delivery handoff:** Publish the “Concurrent put handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Duplicate puts converge on identical verified bytes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Concurrent put handling”; copy its required invariant exactly: “Duplicate puts converge on identical verified bytes”.
- [ ] **UC-M04.05-C053-T02 · Observable terms:** Define each term in the “Concurrent put handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C053-T03 · Precondition set:** List the preconditions under which “Duplicate puts converge on identical verified bytes” must hold for “Concurrent put handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C053-T04 · Transition coverage:** Map the “Concurrent put handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Concurrent put handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C053-T06 · Satisfying fixture:** Create a concrete “Concurrent put handling” case that satisfies “Duplicate puts converge on identical verified bytes”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C053-T07 · Violating fixture:** Create the source counterexample “Two writers publish conflicting content under one claimed digest” for “Concurrent put handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C053-T08 · Enforcement evidence:** Exercise the “Concurrent put handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C053-T09 · Regression linkage:** Link the “Concurrent put handling” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Concurrent put handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C054 · Integration

**Original checklist item:** Integrate concurrent put handling with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Concurrent put handling” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C054-T02 · Field mapping:** Map every “Concurrent put handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Concurrent put handling” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C054-T04 · Ownership agreement:** Specify who owns “Concurrent put handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C054-T05 · Handoff implementation:** Connect “Concurrent put handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Duplicate puts converge on identical verified bytes” across the handoff.
- [ ] **UC-M04.05-C054-T06 · Absent-input case:** Omit one required “Concurrent put handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C054-T07 · Stale-input case:** Supply an outdated “Concurrent put handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Concurrent put handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C054-T09 · Valid integration trace:** Run a valid “Concurrent put handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C054-T10 · Seam review:** Reconcile the “Concurrent put handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for concurrent put handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Concurrent put handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C055-T02 · Expected-result oracle:** Specify the “Concurrent put handling” expected result independently of the implementation output; include the property “Duplicate puts converge on identical verified bytes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C055-T03 · Fixture material:** Create the concrete “Concurrent put handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C055-T04 · Target preparation:** Prepare the “Concurrent put handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C055-T05 · Initial-state record:** Record the initial “Concurrent put handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C055-T06 · Valid-path execution:** Execute the “Concurrent put handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C055-T07 · Outcome comparison:** Compare every declared “Concurrent put handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C055-T08 · State and bounds check:** Inspect the “Concurrent put handling” ownership/state effects and actual use of “Concurrent puts and lock wait”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C055-T09 · Repeatability check:** Repeat the same “Concurrent put handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C055-T10 · Positive evidence:** Attach the “Concurrent put handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C056 · Negative test

**Original checklist item:** Negative case: Two writers publish conflicting content under one claimed digest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Concurrent put handling” source counterexample: “Two writers publish conflicting content under one claimed digest”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Concurrent put handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C056-T03 · Valid control:** Construct a valid “Concurrent put handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C056-T04 · Minimal adverse input:** Derive the “Concurrent put handling” adverse fixture from the control with the smallest documented change needed to reproduce “Two writers publish conflicting content under one claimed digest”; retain that change as reproducible data.
- [ ] **UC-M04.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Concurrent put handling”; require “Duplicate puts converge on identical verified bytes” and forbid a false-success verdict.
- [ ] **UC-M04.05-C056-T06 · Adverse execution:** Exercise the “Concurrent put handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C056-T07 · Effect inspection:** Inspect “Concurrent put handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C056-T08 · Refusal versus failure:** Confirm the “Concurrent put handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C056-T09 · Reset and retention:** Restore only the disposable “Concurrent put handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C056-T10 · Negative regression:** Register the “Concurrent put handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C057 · Change / failure test

**Original checklist item:** Exercise concurrent put handling when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C057-T01 · Scenario record:** Write the “Concurrent put handling” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “Duplicate puts converge on identical verified bytes”.
- [ ] **UC-M04.05-C057-T02 · Baseline capture:** Create a known-valid “Concurrent put handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C057-T03 · Injection map:** Locate the “Concurrent put handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Concurrent put handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C057-T05 · Controlled trigger:** Introduce the controlled “Concurrent put handling” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C057-T06 · Intermediate inspection:** Inspect the “Concurrent put handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Concurrent put handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Concurrent put handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C057-T09 · Repeat and compare:** Repeat the selected “Concurrent put handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C057-T10 · Failure evidence:** Publish the “Concurrent put handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C058 · Bounds

**Original checklist item:** Choose, document and test limits for concurrent puts and lock wait; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Concurrent put handling”: “Concurrent puts and lock wait”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C058-T02 · Measurement method:** Choose how to observe each “Concurrent put handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C058-T03 · Budget decision:** Select justified resource and input limits for “Concurrent put handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Concurrent put handling” cases for “Concurrent puts and lock wait”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Concurrent put handling” limit; preserve “Duplicate puts converge on identical verified bytes”.
- [ ] **UC-M04.05-C058-T06 · Normal measurement:** Run or review the normal “Concurrent put handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C058-T07 · At-limit measurement:** Exercise the “Concurrent put handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C058-T08 · Over-limit measurement:** Exercise the “Concurrent put handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C058-T09 · Uncovered-scope report:** List the “Concurrent put handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C058-T10 · Limit evidence:** Publish the selected “Concurrent put handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for concurrent put handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C059-T01 · Event inventory:** List the “Concurrent put handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Concurrent put handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C059-T03 · Failure mapping:** Map each documented “Concurrent put handling” refusal or error to a diagnostic outcome; include “Two writers publish conflicting content under one claimed digest” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C059-T04 · Emission path:** Add the “Concurrent put handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C059-T05 · Redaction check:** Test “Concurrent put handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C059-T06 · Output budget:** Set and exercise bounded “Concurrent put handling” message size, rate and retention compatible with “Concurrent puts and lock wait”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C059-T07 · Success/refusal fixtures:** Capture “Concurrent put handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Concurrent put handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C059-T09 · Operator review:** Read the “Concurrent put handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C059-T10 · Diagnostic evidence:** Publish redacted “Concurrent put handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for concurrent put handling; label unexecuted checks as untested.

- [ ] **UC-M04.05-C060-T01 · Evidence inventory:** List the “Concurrent put handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C060-T02 · Artifact references:** Record the exact “Concurrent put handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C060-T03 · Fixture references:** Attach the “Concurrent put handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two writers publish conflicting content under one claimed digest” as a distinct evidence case.
- [ ] **UC-M04.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Concurrent put handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C060-T05 · Environment record:** Record the actual “Concurrent put handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C060-T06 · Expected versus observed:** Pair every “Concurrent put handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C060-T07 · Failure and limit records:** Attach “Concurrent put handling” change/failure and bounds evidence where required; include uncovered “Concurrent puts and lock wait” and unresolved violations of “Duplicate puts converge on identical verified bytes”.
- [ ] **UC-M04.05-C060-T08 · Evidence hygiene:** Check the “Concurrent put handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C060-T09 · Reproduction review:** Have the “Concurrent put handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C060-T10 · Acceptance linkage:** Link the “Concurrent put handling” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Metadata references

**Source delivery:** Store typed references linking images to their dependency graph and evidence.

**Source invariant:** Metadata cannot redirect an immutable image identity silently.

**Source negative case:** A manifest points an approved image name at different content.

**Source bounded quantities:** Reference count and lookup depth.

### UC-M04.05-C061 · Contract

**Original checklist item:** Specify metadata references inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C061-T01 · Scope statement:** Draft the operation boundary for “Metadata references” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Metadata references”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C061-T03 · Output inventory:** List the outputs of “Metadata references” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Metadata references”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C061-T05 · Prerequisite contract:** Map “Metadata references” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Metadata references”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C061-T07 · Invariant clause:** Add a normative clause for “Metadata references” that preserves “Metadata cannot redirect an immutable image identity silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Metadata references”; include the source counterexample “A manifest points an approved image name at different content” and the intended safe disposition.
- [ ] **UC-M04.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reference count and lookup depth” in the “Metadata references” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C061-T10 · Contract review:** Review the “Metadata references” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C062 · Delivery

**Original checklist item:** Store typed references linking images to their dependency graph and evidence.

- [ ] **UC-M04.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Metadata references”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C062-T02 · Change plan:** Break the source delivery for “Metadata references” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Metadata references” that realizes this source instruction: Store typed references linking images to their dependency graph and evidence.
- [ ] **UC-M04.05-C062-T04 · Concrete realization:** Trace “Metadata references” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Metadata references” needed to preserve “Metadata cannot redirect an immutable image identity silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C062-T06 · Dependency connection:** Connect the “Metadata references” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C062-T07 · Resource behavior:** Account for “Reference count and lookup depth” in “Metadata references”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C062-T08 · Delivery check:** Run the smallest real “Metadata references” path and its adverse fixture “A manifest points an approved image name at different content”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C062-T09 · Patch review:** Review the “Metadata references” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C062-T10 · Delivery handoff:** Publish the “Metadata references” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Metadata cannot redirect an immutable image identity silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Metadata references”; copy its required invariant exactly: “Metadata cannot redirect an immutable image identity silently”.
- [ ] **UC-M04.05-C063-T02 · Observable terms:** Define each term in the “Metadata references” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C063-T03 · Precondition set:** List the preconditions under which “Metadata cannot redirect an immutable image identity silently” must hold for “Metadata references”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C063-T04 · Transition coverage:** Map the “Metadata references” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Metadata references”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C063-T06 · Satisfying fixture:** Create a concrete “Metadata references” case that satisfies “Metadata cannot redirect an immutable image identity silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C063-T07 · Violating fixture:** Create the source counterexample “A manifest points an approved image name at different content” for “Metadata references”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C063-T08 · Enforcement evidence:** Exercise the “Metadata references” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C063-T09 · Regression linkage:** Link the “Metadata references” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Metadata references” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C064 · Integration

**Original checklist item:** Integrate metadata references with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Metadata references” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C064-T02 · Field mapping:** Map every “Metadata references” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Metadata references” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C064-T04 · Ownership agreement:** Specify who owns “Metadata references” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C064-T05 · Handoff implementation:** Connect “Metadata references” through the mapped seam using the real adapter or explicit specification reference; preserve “Metadata cannot redirect an immutable image identity silently” across the handoff.
- [ ] **UC-M04.05-C064-T06 · Absent-input case:** Omit one required “Metadata references” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C064-T07 · Stale-input case:** Supply an outdated “Metadata references” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Metadata references” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C064-T09 · Valid integration trace:** Run a valid “Metadata references” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C064-T10 · Seam review:** Reconcile the “Metadata references” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for metadata references; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Metadata references” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C065-T02 · Expected-result oracle:** Specify the “Metadata references” expected result independently of the implementation output; include the property “Metadata cannot redirect an immutable image identity silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C065-T03 · Fixture material:** Create the concrete “Metadata references” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C065-T04 · Target preparation:** Prepare the “Metadata references” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C065-T05 · Initial-state record:** Record the initial “Metadata references” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C065-T06 · Valid-path execution:** Execute the “Metadata references” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C065-T07 · Outcome comparison:** Compare every declared “Metadata references” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C065-T08 · State and bounds check:** Inspect the “Metadata references” ownership/state effects and actual use of “Reference count and lookup depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C065-T09 · Repeatability check:** Repeat the same “Metadata references” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C065-T10 · Positive evidence:** Attach the “Metadata references” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C066 · Negative test

**Original checklist item:** Negative case: A manifest points an approved image name at different content. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Metadata references” source counterexample: “A manifest points an approved image name at different content”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Metadata references”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C066-T03 · Valid control:** Construct a valid “Metadata references” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C066-T04 · Minimal adverse input:** Derive the “Metadata references” adverse fixture from the control with the smallest documented change needed to reproduce “A manifest points an approved image name at different content”; retain that change as reproducible data.
- [ ] **UC-M04.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Metadata references”; require “Metadata cannot redirect an immutable image identity silently” and forbid a false-success verdict.
- [ ] **UC-M04.05-C066-T06 · Adverse execution:** Exercise the “Metadata references” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C066-T07 · Effect inspection:** Inspect “Metadata references” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C066-T08 · Refusal versus failure:** Confirm the “Metadata references” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C066-T09 · Reset and retention:** Restore only the disposable “Metadata references” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C066-T10 · Negative regression:** Register the “Metadata references” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C067 · Change / failure test

**Original checklist item:** Exercise metadata references when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C067-T01 · Scenario record:** Write the “Metadata references” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “Metadata cannot redirect an immutable image identity silently”.
- [ ] **UC-M04.05-C067-T02 · Baseline capture:** Create a known-valid “Metadata references” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C067-T03 · Injection map:** Locate the “Metadata references” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Metadata references” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C067-T05 · Controlled trigger:** Introduce the controlled “Metadata references” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C067-T06 · Intermediate inspection:** Inspect the “Metadata references” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Metadata references”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Metadata references” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C067-T09 · Repeat and compare:** Repeat the selected “Metadata references” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C067-T10 · Failure evidence:** Publish the “Metadata references” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C068 · Bounds

**Original checklist item:** Choose, document and test limits for reference count and lookup depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Metadata references”: “Reference count and lookup depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C068-T02 · Measurement method:** Choose how to observe each “Metadata references” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C068-T03 · Budget decision:** Select justified resource and input limits for “Metadata references”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Metadata references” cases for “Reference count and lookup depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Metadata references” limit; preserve “Metadata cannot redirect an immutable image identity silently”.
- [ ] **UC-M04.05-C068-T06 · Normal measurement:** Run or review the normal “Metadata references” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C068-T07 · At-limit measurement:** Exercise the “Metadata references” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C068-T08 · Over-limit measurement:** Exercise the “Metadata references” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C068-T09 · Uncovered-scope report:** List the “Metadata references” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C068-T10 · Limit evidence:** Publish the selected “Metadata references” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for metadata references with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C069-T01 · Event inventory:** List the “Metadata references” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Metadata references” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C069-T03 · Failure mapping:** Map each documented “Metadata references” refusal or error to a diagnostic outcome; include “A manifest points an approved image name at different content” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C069-T04 · Emission path:** Add the “Metadata references” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C069-T05 · Redaction check:** Test “Metadata references” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C069-T06 · Output budget:** Set and exercise bounded “Metadata references” message size, rate and retention compatible with “Reference count and lookup depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C069-T07 · Success/refusal fixtures:** Capture “Metadata references” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Metadata references” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C069-T09 · Operator review:** Read the “Metadata references” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C069-T10 · Diagnostic evidence:** Publish redacted “Metadata references” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for metadata references; label unexecuted checks as untested.

- [ ] **UC-M04.05-C070-T01 · Evidence inventory:** List the “Metadata references” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C070-T02 · Artifact references:** Record the exact “Metadata references” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C070-T03 · Fixture references:** Attach the “Metadata references” fixture IDs, input identities and oracle definition; preserve the source counterexample “A manifest points an approved image name at different content” as a distinct evidence case.
- [ ] **UC-M04.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Metadata references”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C070-T05 · Environment record:** Record the actual “Metadata references” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C070-T06 · Expected versus observed:** Pair every “Metadata references” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C070-T07 · Failure and limit records:** Attach “Metadata references” change/failure and bounds evidence where required; include uncovered “Reference count and lookup depth” and unresolved violations of “Metadata cannot redirect an immutable image identity silently”.
- [ ] **UC-M04.05-C070-T08 · Evidence hygiene:** Check the “Metadata references” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C070-T09 · Reproduction review:** Have the “Metadata references” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C070-T10 · Acceptance linkage:** Link the “Metadata references” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Corruption quarantine

**Source delivery:** Quarantine corrupt or unverifiable objects without treating them as cache hits.

**Source invariant:** A corrupt blob cannot satisfy a required dependency.

**Source negative case:** Verification fails but execution continues from the blob.

**Source bounded quantities:** Quarantine bytes and incident backlog.

### UC-M04.05-C071 · Contract

**Original checklist item:** Specify corruption quarantine inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C071-T01 · Scope statement:** Draft the operation boundary for “Corruption quarantine” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Corruption quarantine”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C071-T03 · Output inventory:** List the outputs of “Corruption quarantine” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Corruption quarantine”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C071-T05 · Prerequisite contract:** Map “Corruption quarantine” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Corruption quarantine”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C071-T07 · Invariant clause:** Add a normative clause for “Corruption quarantine” that preserves “A corrupt blob cannot satisfy a required dependency”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Corruption quarantine”; include the source counterexample “Verification fails but execution continues from the blob” and the intended safe disposition.
- [ ] **UC-M04.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Quarantine bytes and incident backlog” in the “Corruption quarantine” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C071-T10 · Contract review:** Review the “Corruption quarantine” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C072 · Delivery

**Original checklist item:** Quarantine corrupt or unverifiable objects without treating them as cache hits.

- [ ] **UC-M04.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Corruption quarantine”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C072-T02 · Change plan:** Break the source delivery for “Corruption quarantine” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Corruption quarantine” that realizes this source instruction: Quarantine corrupt or unverifiable objects without treating them as cache hits.
- [ ] **UC-M04.05-C072-T04 · Concrete realization:** Trace “Corruption quarantine” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Corruption quarantine” needed to preserve “A corrupt blob cannot satisfy a required dependency”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C072-T06 · Dependency connection:** Connect the “Corruption quarantine” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C072-T07 · Resource behavior:** Account for “Quarantine bytes and incident backlog” in “Corruption quarantine”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C072-T08 · Delivery check:** Run the smallest real “Corruption quarantine” path and its adverse fixture “Verification fails but execution continues from the blob”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C072-T09 · Patch review:** Review the “Corruption quarantine” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C072-T10 · Delivery handoff:** Publish the “Corruption quarantine” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A corrupt blob cannot satisfy a required dependency. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Corruption quarantine”; copy its required invariant exactly: “A corrupt blob cannot satisfy a required dependency”.
- [ ] **UC-M04.05-C073-T02 · Observable terms:** Define each term in the “Corruption quarantine” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C073-T03 · Precondition set:** List the preconditions under which “A corrupt blob cannot satisfy a required dependency” must hold for “Corruption quarantine”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C073-T04 · Transition coverage:** Map the “Corruption quarantine” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Corruption quarantine”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C073-T06 · Satisfying fixture:** Create a concrete “Corruption quarantine” case that satisfies “A corrupt blob cannot satisfy a required dependency”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C073-T07 · Violating fixture:** Create the source counterexample “Verification fails but execution continues from the blob” for “Corruption quarantine”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C073-T08 · Enforcement evidence:** Exercise the “Corruption quarantine” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C073-T09 · Regression linkage:** Link the “Corruption quarantine” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Corruption quarantine” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C074 · Integration

**Original checklist item:** Integrate corruption quarantine with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Corruption quarantine” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C074-T02 · Field mapping:** Map every “Corruption quarantine” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Corruption quarantine” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C074-T04 · Ownership agreement:** Specify who owns “Corruption quarantine” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C074-T05 · Handoff implementation:** Connect “Corruption quarantine” through the mapped seam using the real adapter or explicit specification reference; preserve “A corrupt blob cannot satisfy a required dependency” across the handoff.
- [ ] **UC-M04.05-C074-T06 · Absent-input case:** Omit one required “Corruption quarantine” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C074-T07 · Stale-input case:** Supply an outdated “Corruption quarantine” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Corruption quarantine” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C074-T09 · Valid integration trace:** Run a valid “Corruption quarantine” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C074-T10 · Seam review:** Reconcile the “Corruption quarantine” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for corruption quarantine; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Corruption quarantine” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C075-T02 · Expected-result oracle:** Specify the “Corruption quarantine” expected result independently of the implementation output; include the property “A corrupt blob cannot satisfy a required dependency” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C075-T03 · Fixture material:** Create the concrete “Corruption quarantine” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C075-T04 · Target preparation:** Prepare the “Corruption quarantine” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C075-T05 · Initial-state record:** Record the initial “Corruption quarantine” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C075-T06 · Valid-path execution:** Execute the “Corruption quarantine” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C075-T07 · Outcome comparison:** Compare every declared “Corruption quarantine” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C075-T08 · State and bounds check:** Inspect the “Corruption quarantine” ownership/state effects and actual use of “Quarantine bytes and incident backlog”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C075-T09 · Repeatability check:** Repeat the same “Corruption quarantine” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C075-T10 · Positive evidence:** Attach the “Corruption quarantine” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C076 · Negative test

**Original checklist item:** Negative case: Verification fails but execution continues from the blob. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Corruption quarantine” source counterexample: “Verification fails but execution continues from the blob”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Corruption quarantine”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C076-T03 · Valid control:** Construct a valid “Corruption quarantine” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C076-T04 · Minimal adverse input:** Derive the “Corruption quarantine” adverse fixture from the control with the smallest documented change needed to reproduce “Verification fails but execution continues from the blob”; retain that change as reproducible data.
- [ ] **UC-M04.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Corruption quarantine”; require “A corrupt blob cannot satisfy a required dependency” and forbid a false-success verdict.
- [ ] **UC-M04.05-C076-T06 · Adverse execution:** Exercise the “Corruption quarantine” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C076-T07 · Effect inspection:** Inspect “Corruption quarantine” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C076-T08 · Refusal versus failure:** Confirm the “Corruption quarantine” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C076-T09 · Reset and retention:** Restore only the disposable “Corruption quarantine” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C076-T10 · Negative regression:** Register the “Corruption quarantine” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C077 · Change / failure test

**Original checklist item:** Exercise corruption quarantine when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C077-T01 · Scenario record:** Write the “Corruption quarantine” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “A corrupt blob cannot satisfy a required dependency”.
- [ ] **UC-M04.05-C077-T02 · Baseline capture:** Create a known-valid “Corruption quarantine” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C077-T03 · Injection map:** Locate the “Corruption quarantine” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Corruption quarantine” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C077-T05 · Controlled trigger:** Introduce the controlled “Corruption quarantine” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C077-T06 · Intermediate inspection:** Inspect the “Corruption quarantine” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Corruption quarantine”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Corruption quarantine” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C077-T09 · Repeat and compare:** Repeat the selected “Corruption quarantine” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C077-T10 · Failure evidence:** Publish the “Corruption quarantine” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C078 · Bounds

**Original checklist item:** Choose, document and test limits for quarantine bytes and incident backlog; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Corruption quarantine”: “Quarantine bytes and incident backlog”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C078-T02 · Measurement method:** Choose how to observe each “Corruption quarantine” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C078-T03 · Budget decision:** Select justified resource and input limits for “Corruption quarantine”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Corruption quarantine” cases for “Quarantine bytes and incident backlog”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Corruption quarantine” limit; preserve “A corrupt blob cannot satisfy a required dependency”.
- [ ] **UC-M04.05-C078-T06 · Normal measurement:** Run or review the normal “Corruption quarantine” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C078-T07 · At-limit measurement:** Exercise the “Corruption quarantine” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C078-T08 · Over-limit measurement:** Exercise the “Corruption quarantine” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C078-T09 · Uncovered-scope report:** List the “Corruption quarantine” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C078-T10 · Limit evidence:** Publish the selected “Corruption quarantine” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for corruption quarantine with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C079-T01 · Event inventory:** List the “Corruption quarantine” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Corruption quarantine” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C079-T03 · Failure mapping:** Map each documented “Corruption quarantine” refusal or error to a diagnostic outcome; include “Verification fails but execution continues from the blob” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C079-T04 · Emission path:** Add the “Corruption quarantine” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C079-T05 · Redaction check:** Test “Corruption quarantine” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C079-T06 · Output budget:** Set and exercise bounded “Corruption quarantine” message size, rate and retention compatible with “Quarantine bytes and incident backlog”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C079-T07 · Success/refusal fixtures:** Capture “Corruption quarantine” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Corruption quarantine” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C079-T09 · Operator review:** Read the “Corruption quarantine” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C079-T10 · Diagnostic evidence:** Publish redacted “Corruption quarantine” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for corruption quarantine; label unexecuted checks as untested.

- [ ] **UC-M04.05-C080-T01 · Evidence inventory:** List the “Corruption quarantine” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C080-T02 · Artifact references:** Record the exact “Corruption quarantine” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C080-T03 · Fixture references:** Attach the “Corruption quarantine” fixture IDs, input identities and oracle definition; preserve the source counterexample “Verification fails but execution continues from the blob” as a distinct evidence case.
- [ ] **UC-M04.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Corruption quarantine”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C080-T05 · Environment record:** Record the actual “Corruption quarantine” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C080-T06 · Expected versus observed:** Pair every “Corruption quarantine” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C080-T07 · Failure and limit records:** Attach “Corruption quarantine” change/failure and bounds evidence where required; include uncovered “Quarantine bytes and incident backlog” and unresolved violations of “A corrupt blob cannot satisfy a required dependency”.
- [ ] **UC-M04.05-C080-T08 · Evidence hygiene:** Check the “Corruption quarantine” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C080-T09 · Reproduction review:** Have the “Corruption quarantine” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C080-T10 · Acceptance linkage:** Link the “Corruption quarantine” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Reachability hooks

**Source delivery:** Expose stable object references for retention and garbage-collection decisions.

**Source invariant:** Active image references remain distinguishable from temporary files.

**Source negative case:** Cleanup deletes a newly published referenced object.

**Source bounded quantities:** Reference updates and scan cost.

### UC-M04.05-C081 · Contract

**Original checklist item:** Specify reachability hooks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C081-T01 · Scope statement:** Draft the operation boundary for “Reachability hooks” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reachability hooks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C081-T03 · Output inventory:** List the outputs of “Reachability hooks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Reachability hooks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C081-T05 · Prerequisite contract:** Map “Reachability hooks” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Reachability hooks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C081-T07 · Invariant clause:** Add a normative clause for “Reachability hooks” that preserves “Active image references remain distinguishable from temporary files”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reachability hooks”; include the source counterexample “Cleanup deletes a newly published referenced object” and the intended safe disposition.
- [ ] **UC-M04.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reference updates and scan cost” in the “Reachability hooks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C081-T10 · Contract review:** Review the “Reachability hooks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C082 · Delivery

**Original checklist item:** Expose stable object references for retention and garbage-collection decisions.

- [ ] **UC-M04.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reachability hooks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C082-T02 · Change plan:** Break the source delivery for “Reachability hooks” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Reachability hooks” that realizes this source instruction: Expose stable object references for retention and garbage-collection decisions.
- [ ] **UC-M04.05-C082-T04 · Concrete realization:** Trace “Reachability hooks” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reachability hooks” needed to preserve “Active image references remain distinguishable from temporary files”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C082-T06 · Dependency connection:** Connect the “Reachability hooks” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C082-T07 · Resource behavior:** Account for “Reference updates and scan cost” in “Reachability hooks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C082-T08 · Delivery check:** Run the smallest real “Reachability hooks” path and its adverse fixture “Cleanup deletes a newly published referenced object”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C082-T09 · Patch review:** Review the “Reachability hooks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C082-T10 · Delivery handoff:** Publish the “Reachability hooks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Active image references remain distinguishable from temporary files. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Reachability hooks”; copy its required invariant exactly: “Active image references remain distinguishable from temporary files”.
- [ ] **UC-M04.05-C083-T02 · Observable terms:** Define each term in the “Reachability hooks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C083-T03 · Precondition set:** List the preconditions under which “Active image references remain distinguishable from temporary files” must hold for “Reachability hooks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C083-T04 · Transition coverage:** Map the “Reachability hooks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reachability hooks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C083-T06 · Satisfying fixture:** Create a concrete “Reachability hooks” case that satisfies “Active image references remain distinguishable from temporary files”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C083-T07 · Violating fixture:** Create the source counterexample “Cleanup deletes a newly published referenced object” for “Reachability hooks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C083-T08 · Enforcement evidence:** Exercise the “Reachability hooks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C083-T09 · Regression linkage:** Link the “Reachability hooks” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Reachability hooks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C084 · Integration

**Original checklist item:** Integrate reachability hooks with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reachability hooks” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C084-T02 · Field mapping:** Map every “Reachability hooks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Reachability hooks” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C084-T04 · Ownership agreement:** Specify who owns “Reachability hooks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C084-T05 · Handoff implementation:** Connect “Reachability hooks” through the mapped seam using the real adapter or explicit specification reference; preserve “Active image references remain distinguishable from temporary files” across the handoff.
- [ ] **UC-M04.05-C084-T06 · Absent-input case:** Omit one required “Reachability hooks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C084-T07 · Stale-input case:** Supply an outdated “Reachability hooks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Reachability hooks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C084-T09 · Valid integration trace:** Run a valid “Reachability hooks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C084-T10 · Seam review:** Reconcile the “Reachability hooks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reachability hooks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reachability hooks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C085-T02 · Expected-result oracle:** Specify the “Reachability hooks” expected result independently of the implementation output; include the property “Active image references remain distinguishable from temporary files” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C085-T03 · Fixture material:** Create the concrete “Reachability hooks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C085-T04 · Target preparation:** Prepare the “Reachability hooks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C085-T05 · Initial-state record:** Record the initial “Reachability hooks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C085-T06 · Valid-path execution:** Execute the “Reachability hooks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C085-T07 · Outcome comparison:** Compare every declared “Reachability hooks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C085-T08 · State and bounds check:** Inspect the “Reachability hooks” ownership/state effects and actual use of “Reference updates and scan cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C085-T09 · Repeatability check:** Repeat the same “Reachability hooks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C085-T10 · Positive evidence:** Attach the “Reachability hooks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C086 · Negative test

**Original checklist item:** Negative case: Cleanup deletes a newly published referenced object. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Reachability hooks” source counterexample: “Cleanup deletes a newly published referenced object”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Reachability hooks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C086-T03 · Valid control:** Construct a valid “Reachability hooks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C086-T04 · Minimal adverse input:** Derive the “Reachability hooks” adverse fixture from the control with the smallest documented change needed to reproduce “Cleanup deletes a newly published referenced object”; retain that change as reproducible data.
- [ ] **UC-M04.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reachability hooks”; require “Active image references remain distinguishable from temporary files” and forbid a false-success verdict.
- [ ] **UC-M04.05-C086-T06 · Adverse execution:** Exercise the “Reachability hooks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C086-T07 · Effect inspection:** Inspect “Reachability hooks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C086-T08 · Refusal versus failure:** Confirm the “Reachability hooks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C086-T09 · Reset and retention:** Restore only the disposable “Reachability hooks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C086-T10 · Negative regression:** Register the “Reachability hooks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C087 · Change / failure test

**Original checklist item:** Exercise reachability hooks when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C087-T01 · Scenario record:** Write the “Reachability hooks” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “Active image references remain distinguishable from temporary files”.
- [ ] **UC-M04.05-C087-T02 · Baseline capture:** Create a known-valid “Reachability hooks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C087-T03 · Injection map:** Locate the “Reachability hooks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Reachability hooks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C087-T05 · Controlled trigger:** Introduce the controlled “Reachability hooks” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C087-T06 · Intermediate inspection:** Inspect the “Reachability hooks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reachability hooks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Reachability hooks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C087-T09 · Repeat and compare:** Repeat the selected “Reachability hooks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C087-T10 · Failure evidence:** Publish the “Reachability hooks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C088 · Bounds

**Original checklist item:** Choose, document and test limits for reference updates and scan cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Reachability hooks”: “Reference updates and scan cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C088-T02 · Measurement method:** Choose how to observe each “Reachability hooks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C088-T03 · Budget decision:** Select justified resource and input limits for “Reachability hooks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reachability hooks” cases for “Reference updates and scan cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reachability hooks” limit; preserve “Active image references remain distinguishable from temporary files”.
- [ ] **UC-M04.05-C088-T06 · Normal measurement:** Run or review the normal “Reachability hooks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C088-T07 · At-limit measurement:** Exercise the “Reachability hooks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C088-T08 · Over-limit measurement:** Exercise the “Reachability hooks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C088-T09 · Uncovered-scope report:** List the “Reachability hooks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C088-T10 · Limit evidence:** Publish the selected “Reachability hooks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reachability hooks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C089-T01 · Event inventory:** List the “Reachability hooks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Reachability hooks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C089-T03 · Failure mapping:** Map each documented “Reachability hooks” refusal or error to a diagnostic outcome; include “Cleanup deletes a newly published referenced object” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C089-T04 · Emission path:** Add the “Reachability hooks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C089-T05 · Redaction check:** Test “Reachability hooks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C089-T06 · Output budget:** Set and exercise bounded “Reachability hooks” message size, rate and retention compatible with “Reference updates and scan cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C089-T07 · Success/refusal fixtures:** Capture “Reachability hooks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reachability hooks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C089-T09 · Operator review:** Read the “Reachability hooks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C089-T10 · Diagnostic evidence:** Publish redacted “Reachability hooks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reachability hooks; label unexecuted checks as untested.

- [ ] **UC-M04.05-C090-T01 · Evidence inventory:** List the “Reachability hooks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C090-T02 · Artifact references:** Record the exact “Reachability hooks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C090-T03 · Fixture references:** Attach the “Reachability hooks” fixture IDs, input identities and oracle definition; preserve the source counterexample “Cleanup deletes a newly published referenced object” as a distinct evidence case.
- [ ] **UC-M04.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reachability hooks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C090-T05 · Environment record:** Record the actual “Reachability hooks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C090-T06 · Expected versus observed:** Pair every “Reachability hooks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C090-T07 · Failure and limit records:** Attach “Reachability hooks” change/failure and bounds evidence where required; include uncovered “Reference updates and scan cost” and unresolved violations of “Active image references remain distinguishable from temporary files”.
- [ ] **UC-M04.05-C090-T08 · Evidence hygiene:** Check the “Reachability hooks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C090-T09 · Reproduction review:** Have the “Reachability hooks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C090-T10 · Acceptance linkage:** Link the “Reachability hooks” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Store conformance

**Source delivery:** Test interrupted writes, corruption and duplicate publication with clean readers.

**Source invariant:** Readers see complete verified objects or explicit failure.

**Source negative case:** A reader accepts a partially staged object.

**Source bounded quantities:** Test objects, total bytes and concurrency.

### UC-M04.05-C091 · Contract

**Original checklist item:** Specify store conformance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.05-C091-T01 · Scope statement:** Draft the operation boundary for “Store conformance” within Immutable content-addressed image store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Store conformance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.05-C091-T03 · Output inventory:** List the outputs of “Store conformance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Store conformance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.05-C091-T05 · Prerequisite contract:** Map “Store conformance” to the source component prerequisites (UC-M01.04, UC-M04.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Store conformance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.05-C091-T07 · Invariant clause:** Add a normative clause for “Store conformance” that preserves “Readers see complete verified objects or explicit failure”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Store conformance”; include the source counterexample “A reader accepts a partially staged object” and the intended safe disposition.
- [ ] **UC-M04.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Test objects, total bytes and concurrency” in the “Store conformance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.05-C091-T10 · Contract review:** Review the “Store conformance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.05-C092 · Delivery

**Original checklist item:** Test interrupted writes, corruption and duplicate publication with clean readers.

- [ ] **UC-M04.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Store conformance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.05-C092-T02 · Change plan:** Break the source delivery for “Store conformance” into concrete edit targets and reviewable outputs; keep the UC-M04.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.05-C092-T03 · Core artifact:** Create the “Store conformance” fixture or harness for this source instruction: Test interrupted writes, corruption and duplicate publication with clean readers.
- [ ] **UC-M04.05-C092-T04 · Concrete realization:** Connect the “Store conformance” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Store conformance” needed to preserve “Readers see complete verified objects or explicit failure”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.05-C092-T06 · Dependency connection:** Connect the “Store conformance” implementation to atomic artifact publication, dependency references and verified blob readers; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.05-C092-T07 · Resource behavior:** Account for “Test objects, total bytes and concurrency” in “Store conformance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.05-C092-T08 · Delivery check:** Run the smallest real “Store conformance” path and its adverse fixture “A reader accepts a partially staged object”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.05-C092-T09 · Patch review:** Review the “Store conformance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.05-C092-T10 · Delivery handoff:** Publish the “Store conformance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Readers see complete verified objects or explicit failure. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Store conformance”; copy its required invariant exactly: “Readers see complete verified objects or explicit failure”.
- [ ] **UC-M04.05-C093-T02 · Observable terms:** Define each term in the “Store conformance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.05-C093-T03 · Precondition set:** List the preconditions under which “Readers see complete verified objects or explicit failure” must hold for “Store conformance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.05-C093-T04 · Transition coverage:** Map the “Store conformance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Store conformance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.05-C093-T06 · Satisfying fixture:** Create a concrete “Store conformance” case that satisfies “Readers see complete verified objects or explicit failure”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.05-C093-T07 · Violating fixture:** Create the source counterexample “A reader accepts a partially staged object” for “Store conformance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.05-C093-T08 · Enforcement evidence:** Exercise the “Store conformance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.05-C093-T09 · Regression linkage:** Link the “Store conformance” property to changes in atomic artifact publication, dependency references and verified blob readers; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Store conformance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.05-C094 · Integration

**Original checklist item:** Integrate store conformance with atomic artifact publication, dependency references and verified blob readers; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Store conformance” across atomic artifact publication, dependency references and verified blob readers; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.05-C094-T02 · Field mapping:** Map every “Store conformance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Store conformance” (source dependency list: UC-M01.04, UC-M04.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.05-C094-T04 · Ownership agreement:** Specify who owns “Store conformance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.05-C094-T05 · Handoff implementation:** Connect “Store conformance” through the mapped seam using the real adapter or explicit specification reference; preserve “Readers see complete verified objects or explicit failure” across the handoff.
- [ ] **UC-M04.05-C094-T06 · Absent-input case:** Omit one required “Store conformance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.05-C094-T07 · Stale-input case:** Supply an outdated “Store conformance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Store conformance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.05-C094-T09 · Valid integration trace:** Run a valid “Store conformance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.05-C094-T10 · Seam review:** Reconcile the “Store conformance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.05-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for store conformance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.05-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Store conformance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.05-C095-T02 · Expected-result oracle:** Specify the “Store conformance” expected result independently of the implementation output; include the property “Readers see complete verified objects or explicit failure” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.05-C095-T03 · Fixture material:** Create the concrete “Store conformance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.05-C095-T04 · Target preparation:** Prepare the “Store conformance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.05-C095-T05 · Initial-state record:** Record the initial “Store conformance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.05-C095-T06 · Valid-path execution:** Execute the “Store conformance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.05-C095-T07 · Outcome comparison:** Compare every declared “Store conformance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.05-C095-T08 · State and bounds check:** Inspect the “Store conformance” ownership/state effects and actual use of “Test objects, total bytes and concurrency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.05-C095-T09 · Repeatability check:** Repeat the same “Store conformance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.05-C095-T10 · Positive evidence:** Attach the “Store conformance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.05-C096 · Negative test

**Original checklist item:** Negative case: A reader accepts a partially staged object. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Store conformance” source counterexample: “A reader accepts a partially staged object”; state which precondition or invariant it challenges.
- [ ] **UC-M04.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Store conformance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.05-C096-T03 · Valid control:** Construct a valid “Store conformance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.05-C096-T04 · Minimal adverse input:** Derive the “Store conformance” adverse fixture from the control with the smallest documented change needed to reproduce “A reader accepts a partially staged object”; retain that change as reproducible data.
- [ ] **UC-M04.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Store conformance”; require “Readers see complete verified objects or explicit failure” and forbid a false-success verdict.
- [ ] **UC-M04.05-C096-T06 · Adverse execution:** Exercise the “Store conformance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.05-C096-T07 · Effect inspection:** Inspect “Store conformance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.05-C096-T08 · Refusal versus failure:** Confirm the “Store conformance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.05-C096-T09 · Reset and retention:** Restore only the disposable “Store conformance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.05-C096-T10 · Negative regression:** Register the “Store conformance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.05-C097 · Change / failure test

**Original checklist item:** Exercise store conformance when publication is interrupted while a concurrent reader requests the same object; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.05-C097-T01 · Scenario record:** Write the “Store conformance” change/failure scenario exactly as supplied: publication is interrupted while a concurrent reader requests the same object; identify the property that must remain true: “Readers see complete verified objects or explicit failure”.
- [ ] **UC-M04.05-C097-T02 · Baseline capture:** Create a known-valid “Store conformance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.05-C097-T03 · Injection map:** Locate the “Store conformance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Store conformance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.05-C097-T05 · Controlled trigger:** Introduce the controlled “Store conformance” scenario in the disposable fixture: publication is interrupted while a concurrent reader requests the same object; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.05-C097-T06 · Intermediate inspection:** Inspect the “Store conformance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.05-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Store conformance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Store conformance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.05-C097-T09 · Repeat and compare:** Repeat the selected “Store conformance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.05-C097-T10 · Failure evidence:** Publish the “Store conformance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.05-C098 · Bounds

**Original checklist item:** Choose, document and test limits for test objects, total bytes and concurrency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Store conformance”: “Test objects, total bytes and concurrency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.05-C098-T02 · Measurement method:** Choose how to observe each “Store conformance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.05-C098-T03 · Budget decision:** Select justified resource and input limits for “Store conformance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Store conformance” cases for “Test objects, total bytes and concurrency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Store conformance” limit; preserve “Readers see complete verified objects or explicit failure”.
- [ ] **UC-M04.05-C098-T06 · Normal measurement:** Run or review the normal “Store conformance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.05-C098-T07 · At-limit measurement:** Exercise the “Store conformance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.05-C098-T08 · Over-limit measurement:** Exercise the “Store conformance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.05-C098-T09 · Uncovered-scope report:** List the “Store conformance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.05-C098-T10 · Limit evidence:** Publish the selected “Store conformance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.05-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for store conformance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.05-C099-T01 · Event inventory:** List the “Store conformance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.05-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Store conformance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.05-C099-T03 · Failure mapping:** Map each documented “Store conformance” refusal or error to a diagnostic outcome; include “A reader accepts a partially staged object” and prohibit conversion into a success message.
- [ ] **UC-M04.05-C099-T04 · Emission path:** Add the “Store conformance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.05-C099-T05 · Redaction check:** Test “Store conformance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.05-C099-T06 · Output budget:** Set and exercise bounded “Store conformance” message size, rate and retention compatible with “Test objects, total bytes and concurrency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.05-C099-T07 · Success/refusal fixtures:** Capture “Store conformance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.05-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Store conformance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.05-C099-T09 · Operator review:** Read the “Store conformance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.05-C099-T10 · Diagnostic evidence:** Publish redacted “Store conformance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for store conformance; label unexecuted checks as untested.

- [ ] **UC-M04.05-C100-T01 · Evidence inventory:** List the “Store conformance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.05-C100-T02 · Artifact references:** Record the exact “Store conformance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.05-C100-T03 · Fixture references:** Attach the “Store conformance” fixture IDs, input identities and oracle definition; preserve the source counterexample “A reader accepts a partially staged object” as a distinct evidence case.
- [ ] **UC-M04.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Store conformance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.05-C100-T05 · Environment record:** Record the actual “Store conformance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.05-C100-T06 · Expected versus observed:** Pair every “Store conformance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.05-C100-T07 · Failure and limit records:** Attach “Store conformance” change/failure and bounds evidence where required; include uncovered “Test objects, total bytes and concurrency” and unresolved violations of “Readers see complete verified objects or explicit failure”.
- [ ] **UC-M04.05-C100-T08 · Evidence hygiene:** Check the “Store conformance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.05-C100-T09 · Reproduction review:** Have the “Store conformance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.05-C100-T10 · Acceptance linkage:** Link the “Store conformance” evidence to its parent and UC-M04.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

