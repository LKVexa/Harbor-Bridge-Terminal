# UC-M04.01 — Locked toolchain and dependency closure

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.08](../01/UC-M01.08.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Pin compiler, linker, libraries, engine sources and runtime artifacts with offline-usable checksums and origins.

**Original acceptance criterion:** Build works from an explicit dependency cache without implicit PATH/download substitutions; missing inputs are refused.

**Source trace:** Original checklist `UC100/c/04/UC-M04.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 334–344 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Compiler identity

**Source delivery:** Pin the compiler binary, version, origin and relevant configuration.

**Source invariant:** A build cannot substitute an ambient compiler silently.

**Source negative case:** PATH resolves to an unapproved compiler.

**Source bounded quantities:** Compiler artifact bytes and supported targets.

### UC-M04.01-C001 · Contract

**Original checklist item:** Specify compiler identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C001-T01 · Scope statement:** Draft the operation boundary for “Compiler identity” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Compiler identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C001-T03 · Output inventory:** List the outputs of “Compiler identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Compiler identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C001-T05 · Prerequisite contract:** Map “Compiler identity” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Compiler identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C001-T07 · Invariant clause:** Add a normative clause for “Compiler identity” that preserves “A build cannot substitute an ambient compiler silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Compiler identity”; include the source counterexample “PATH resolves to an unapproved compiler” and the intended safe disposition.
- [ ] **UC-M04.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Compiler artifact bytes and supported targets” in the “Compiler identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C001-T10 · Contract review:** Review the “Compiler identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C002 · Delivery

**Original checklist item:** Pin the compiler binary, version, origin and relevant configuration.

- [ ] **UC-M04.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Compiler identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C002-T02 · Change plan:** Break the source delivery for “Compiler identity” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C002-T03 · Core artifact:** Prepare the “Compiler identity” decision record for this source instruction: Pin the compiler binary, version, origin and relevant configuration.
- [ ] **UC-M04.01-C002-T04 · Concrete realization:** Evaluate the “Compiler identity” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M04.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Compiler identity” needed to preserve “A build cannot substitute an ambient compiler silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C002-T06 · Dependency connection:** Connect the “Compiler identity” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C002-T07 · Resource behavior:** Account for “Compiler artifact bytes and supported targets” in “Compiler identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C002-T08 · Delivery check:** Run the smallest real “Compiler identity” path and its adverse fixture “PATH resolves to an unapproved compiler”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C002-T09 · Patch review:** Review the “Compiler identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C002-T10 · Delivery handoff:** Publish the “Compiler identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A build cannot substitute an ambient compiler silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Compiler identity”; copy its required invariant exactly: “A build cannot substitute an ambient compiler silently”.
- [ ] **UC-M04.01-C003-T02 · Observable terms:** Define each term in the “Compiler identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C003-T03 · Precondition set:** List the preconditions under which “A build cannot substitute an ambient compiler silently” must hold for “Compiler identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C003-T04 · Transition coverage:** Map the “Compiler identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Compiler identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C003-T06 · Satisfying fixture:** Create a concrete “Compiler identity” case that satisfies “A build cannot substitute an ambient compiler silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C003-T07 · Violating fixture:** Create the source counterexample “PATH resolves to an unapproved compiler” for “Compiler identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C003-T08 · Enforcement evidence:** Exercise the “Compiler identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C003-T09 · Regression linkage:** Link the “Compiler identity” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Compiler identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C004 · Integration

**Original checklist item:** Integrate compiler identity with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Compiler identity” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C004-T02 · Field mapping:** Map every “Compiler identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Compiler identity” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C004-T04 · Ownership agreement:** Specify who owns “Compiler identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C004-T05 · Handoff implementation:** Connect “Compiler identity” through the mapped seam using the real adapter or explicit specification reference; preserve “A build cannot substitute an ambient compiler silently” across the handoff.
- [ ] **UC-M04.01-C004-T06 · Absent-input case:** Omit one required “Compiler identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C004-T07 · Stale-input case:** Supply an outdated “Compiler identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Compiler identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C004-T09 · Valid integration trace:** Run a valid “Compiler identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C004-T10 · Seam review:** Reconcile the “Compiler identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for compiler identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Compiler identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C005-T02 · Expected-result oracle:** Specify the “Compiler identity” expected result independently of the implementation output; include the property “A build cannot substitute an ambient compiler silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C005-T03 · Fixture material:** Create the concrete “Compiler identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C005-T04 · Target preparation:** Prepare the “Compiler identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C005-T05 · Initial-state record:** Record the initial “Compiler identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C005-T06 · Valid-path execution:** Execute the “Compiler identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C005-T07 · Outcome comparison:** Compare every declared “Compiler identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C005-T08 · State and bounds check:** Inspect the “Compiler identity” ownership/state effects and actual use of “Compiler artifact bytes and supported targets”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C005-T09 · Repeatability check:** Repeat the same “Compiler identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C005-T10 · Positive evidence:** Attach the “Compiler identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C006 · Negative test

**Original checklist item:** Negative case: PATH resolves to an unapproved compiler. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Compiler identity” source counterexample: “PATH resolves to an unapproved compiler”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Compiler identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C006-T03 · Valid control:** Construct a valid “Compiler identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C006-T04 · Minimal adverse input:** Derive the “Compiler identity” adverse fixture from the control with the smallest documented change needed to reproduce “PATH resolves to an unapproved compiler”; retain that change as reproducible data.
- [ ] **UC-M04.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Compiler identity”; require “A build cannot substitute an ambient compiler silently” and forbid a false-success verdict.
- [ ] **UC-M04.01-C006-T06 · Adverse execution:** Exercise the “Compiler identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C006-T07 · Effect inspection:** Inspect “Compiler identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C006-T08 · Refusal versus failure:** Confirm the “Compiler identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C006-T09 · Reset and retention:** Restore only the disposable “Compiler identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C006-T10 · Negative regression:** Register the “Compiler identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C007 · Change / failure test

**Original checklist item:** Exercise compiler identity when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C007-T01 · Scenario record:** Write the “Compiler identity” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “A build cannot substitute an ambient compiler silently”.
- [ ] **UC-M04.01-C007-T02 · Baseline capture:** Create a known-valid “Compiler identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C007-T03 · Injection map:** Locate the “Compiler identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Compiler identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C007-T05 · Controlled trigger:** Introduce the controlled “Compiler identity” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C007-T06 · Intermediate inspection:** Inspect the “Compiler identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Compiler identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Compiler identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C007-T09 · Repeat and compare:** Repeat the selected “Compiler identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C007-T10 · Failure evidence:** Publish the “Compiler identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for compiler artifact bytes and supported targets; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Compiler identity”: “Compiler artifact bytes and supported targets”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C008-T02 · Measurement method:** Choose how to observe each “Compiler identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Compiler identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Compiler identity” cases for “Compiler artifact bytes and supported targets”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Compiler identity” limit; preserve “A build cannot substitute an ambient compiler silently”.
- [ ] **UC-M04.01-C008-T06 · Normal measurement:** Run or review the normal “Compiler identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C008-T07 · At-limit measurement:** Exercise the “Compiler identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C008-T08 · Over-limit measurement:** Exercise the “Compiler identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C008-T09 · Uncovered-scope report:** List the “Compiler identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C008-T10 · Limit evidence:** Publish the selected “Compiler identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for compiler identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C009-T01 · Event inventory:** List the “Compiler identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Compiler identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C009-T03 · Failure mapping:** Map each documented “Compiler identity” refusal or error to a diagnostic outcome; include “PATH resolves to an unapproved compiler” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C009-T04 · Emission path:** Add the “Compiler identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C009-T05 · Redaction check:** Test “Compiler identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C009-T06 · Output budget:** Set and exercise bounded “Compiler identity” message size, rate and retention compatible with “Compiler artifact bytes and supported targets”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C009-T07 · Success/refusal fixtures:** Capture “Compiler identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Compiler identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C009-T09 · Operator review:** Read the “Compiler identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C009-T10 · Diagnostic evidence:** Publish redacted “Compiler identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for compiler identity; label unexecuted checks as untested.

- [ ] **UC-M04.01-C010-T01 · Evidence inventory:** List the “Compiler identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C010-T02 · Artifact references:** Record the exact “Compiler identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C010-T03 · Fixture references:** Attach the “Compiler identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “PATH resolves to an unapproved compiler” as a distinct evidence case.
- [ ] **UC-M04.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Compiler identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C010-T05 · Environment record:** Record the actual “Compiler identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C010-T06 · Expected versus observed:** Pair every “Compiler identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C010-T07 · Failure and limit records:** Attach “Compiler identity” change/failure and bounds evidence where required; include uncovered “Compiler artifact bytes and supported targets” and unresolved violations of “A build cannot substitute an ambient compiler silently”.
- [ ] **UC-M04.01-C010-T08 · Evidence hygiene:** Check the “Compiler identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C010-T09 · Reproduction review:** Have the “Compiler identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C010-T10 · Acceptance linkage:** Link the “Compiler identity” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Linker identity

**Source delivery:** Pin linker and image-building tools with verified origins.

**Source invariant:** The declared linker is the tool that produces the image.

**Source negative case:** A helper script invokes an unpinned system linker.

**Source bounded quantities:** Tool count and verification time.

### UC-M04.01-C011 · Contract

**Original checklist item:** Specify linker identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C011-T01 · Scope statement:** Draft the operation boundary for “Linker identity” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Linker identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C011-T03 · Output inventory:** List the outputs of “Linker identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Linker identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C011-T05 · Prerequisite contract:** Map “Linker identity” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Linker identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C011-T07 · Invariant clause:** Add a normative clause for “Linker identity” that preserves “The declared linker is the tool that produces the image”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Linker identity”; include the source counterexample “A helper script invokes an unpinned system linker” and the intended safe disposition.
- [ ] **UC-M04.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Tool count and verification time” in the “Linker identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C011-T10 · Contract review:** Review the “Linker identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C012 · Delivery

**Original checklist item:** Pin linker and image-building tools with verified origins.

- [ ] **UC-M04.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Linker identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C012-T02 · Change plan:** Break the source delivery for “Linker identity” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C012-T03 · Core artifact:** Prepare the “Linker identity” decision record for this source instruction: Pin linker and image-building tools with verified origins.
- [ ] **UC-M04.01-C012-T04 · Concrete realization:** Evaluate the “Linker identity” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M04.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Linker identity” needed to preserve “The declared linker is the tool that produces the image”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C012-T06 · Dependency connection:** Connect the “Linker identity” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C012-T07 · Resource behavior:** Account for “Tool count and verification time” in “Linker identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C012-T08 · Delivery check:** Run the smallest real “Linker identity” path and its adverse fixture “A helper script invokes an unpinned system linker”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C012-T09 · Patch review:** Review the “Linker identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C012-T10 · Delivery handoff:** Publish the “Linker identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The declared linker is the tool that produces the image. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Linker identity”; copy its required invariant exactly: “The declared linker is the tool that produces the image”.
- [ ] **UC-M04.01-C013-T02 · Observable terms:** Define each term in the “Linker identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C013-T03 · Precondition set:** List the preconditions under which “The declared linker is the tool that produces the image” must hold for “Linker identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C013-T04 · Transition coverage:** Map the “Linker identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Linker identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C013-T06 · Satisfying fixture:** Create a concrete “Linker identity” case that satisfies “The declared linker is the tool that produces the image”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C013-T07 · Violating fixture:** Create the source counterexample “A helper script invokes an unpinned system linker” for “Linker identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C013-T08 · Enforcement evidence:** Exercise the “Linker identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C013-T09 · Regression linkage:** Link the “Linker identity” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Linker identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C014 · Integration

**Original checklist item:** Integrate linker identity with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Linker identity” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C014-T02 · Field mapping:** Map every “Linker identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Linker identity” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C014-T04 · Ownership agreement:** Specify who owns “Linker identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C014-T05 · Handoff implementation:** Connect “Linker identity” through the mapped seam using the real adapter or explicit specification reference; preserve “The declared linker is the tool that produces the image” across the handoff.
- [ ] **UC-M04.01-C014-T06 · Absent-input case:** Omit one required “Linker identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C014-T07 · Stale-input case:** Supply an outdated “Linker identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Linker identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C014-T09 · Valid integration trace:** Run a valid “Linker identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C014-T10 · Seam review:** Reconcile the “Linker identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for linker identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Linker identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C015-T02 · Expected-result oracle:** Specify the “Linker identity” expected result independently of the implementation output; include the property “The declared linker is the tool that produces the image” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C015-T03 · Fixture material:** Create the concrete “Linker identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C015-T04 · Target preparation:** Prepare the “Linker identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C015-T05 · Initial-state record:** Record the initial “Linker identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C015-T06 · Valid-path execution:** Execute the “Linker identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C015-T07 · Outcome comparison:** Compare every declared “Linker identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C015-T08 · State and bounds check:** Inspect the “Linker identity” ownership/state effects and actual use of “Tool count and verification time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C015-T09 · Repeatability check:** Repeat the same “Linker identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C015-T10 · Positive evidence:** Attach the “Linker identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C016 · Negative test

**Original checklist item:** Negative case: A helper script invokes an unpinned system linker. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Linker identity” source counterexample: “A helper script invokes an unpinned system linker”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Linker identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C016-T03 · Valid control:** Construct a valid “Linker identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C016-T04 · Minimal adverse input:** Derive the “Linker identity” adverse fixture from the control with the smallest documented change needed to reproduce “A helper script invokes an unpinned system linker”; retain that change as reproducible data.
- [ ] **UC-M04.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Linker identity”; require “The declared linker is the tool that produces the image” and forbid a false-success verdict.
- [ ] **UC-M04.01-C016-T06 · Adverse execution:** Exercise the “Linker identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C016-T07 · Effect inspection:** Inspect “Linker identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C016-T08 · Refusal versus failure:** Confirm the “Linker identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C016-T09 · Reset and retention:** Restore only the disposable “Linker identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C016-T10 · Negative regression:** Register the “Linker identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C017 · Change / failure test

**Original checklist item:** Exercise linker identity when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C017-T01 · Scenario record:** Write the “Linker identity” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “The declared linker is the tool that produces the image”.
- [ ] **UC-M04.01-C017-T02 · Baseline capture:** Create a known-valid “Linker identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C017-T03 · Injection map:** Locate the “Linker identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Linker identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C017-T05 · Controlled trigger:** Introduce the controlled “Linker identity” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C017-T06 · Intermediate inspection:** Inspect the “Linker identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Linker identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Linker identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C017-T09 · Repeat and compare:** Repeat the selected “Linker identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C017-T10 · Failure evidence:** Publish the “Linker identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for tool count and verification time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Linker identity”: “Tool count and verification time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C018-T02 · Measurement method:** Choose how to observe each “Linker identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Linker identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Linker identity” cases for “Tool count and verification time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Linker identity” limit; preserve “The declared linker is the tool that produces the image”.
- [ ] **UC-M04.01-C018-T06 · Normal measurement:** Run or review the normal “Linker identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C018-T07 · At-limit measurement:** Exercise the “Linker identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C018-T08 · Over-limit measurement:** Exercise the “Linker identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C018-T09 · Uncovered-scope report:** List the “Linker identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C018-T10 · Limit evidence:** Publish the selected “Linker identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for linker identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C019-T01 · Event inventory:** List the “Linker identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Linker identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C019-T03 · Failure mapping:** Map each documented “Linker identity” refusal or error to a diagnostic outcome; include “A helper script invokes an unpinned system linker” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C019-T04 · Emission path:** Add the “Linker identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C019-T05 · Redaction check:** Test “Linker identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C019-T06 · Output budget:** Set and exercise bounded “Linker identity” message size, rate and retention compatible with “Tool count and verification time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C019-T07 · Success/refusal fixtures:** Capture “Linker identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Linker identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C019-T09 · Operator review:** Read the “Linker identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C019-T10 · Diagnostic evidence:** Publish redacted “Linker identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for linker identity; label unexecuted checks as untested.

- [ ] **UC-M04.01-C020-T01 · Evidence inventory:** List the “Linker identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C020-T02 · Artifact references:** Record the exact “Linker identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C020-T03 · Fixture references:** Attach the “Linker identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A helper script invokes an unpinned system linker” as a distinct evidence case.
- [ ] **UC-M04.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Linker identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C020-T05 · Environment record:** Record the actual “Linker identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C020-T06 · Expected versus observed:** Pair every “Linker identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C020-T07 · Failure and limit records:** Attach “Linker identity” change/failure and bounds evidence where required; include uncovered “Tool count and verification time” and unresolved violations of “The declared linker is the tool that produces the image”.
- [ ] **UC-M04.01-C020-T08 · Evidence hygiene:** Check the “Linker identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C020-T09 · Reproduction review:** Have the “Linker identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C020-T10 · Acceptance linkage:** Link the “Linker identity” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Library closure

**Source delivery:** Inventory all direct and transitive libraries used by the guest.

**Source invariant:** Every linked library belongs to the approved dependency closure.

**Source negative case:** An undeclared library appears during linking.

**Source bounded quantities:** Dependency count and closure traversal depth.

### UC-M04.01-C021 · Contract

**Original checklist item:** Specify library closure inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C021-T01 · Scope statement:** Draft the operation boundary for “Library closure” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Library closure”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C021-T03 · Output inventory:** List the outputs of “Library closure” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Library closure”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C021-T05 · Prerequisite contract:** Map “Library closure” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Library closure”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C021-T07 · Invariant clause:** Add a normative clause for “Library closure” that preserves “Every linked library belongs to the approved dependency closure”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Library closure”; include the source counterexample “An undeclared library appears during linking” and the intended safe disposition.
- [ ] **UC-M04.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Dependency count and closure traversal depth” in the “Library closure” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C021-T10 · Contract review:** Review the “Library closure” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C022 · Delivery

**Original checklist item:** Inventory all direct and transitive libraries used by the guest.

- [ ] **UC-M04.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Library closure”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C022-T02 · Change plan:** Break the source delivery for “Library closure” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C022-T03 · Core artifact:** Create the “Library closure” model, schema or inventory that realizes this source instruction: Inventory all direct and transitive libraries used by the guest.
- [ ] **UC-M04.01-C022-T04 · Concrete realization:** Populate “Library closure” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Library closure” needed to preserve “Every linked library belongs to the approved dependency closure”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C022-T06 · Dependency connection:** Connect the “Library closure” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C022-T07 · Resource behavior:** Account for “Dependency count and closure traversal depth” in “Library closure”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C022-T08 · Delivery check:** Run the smallest real “Library closure” path and its adverse fixture “An undeclared library appears during linking”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C022-T09 · Patch review:** Review the “Library closure” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C022-T10 · Delivery handoff:** Publish the “Library closure” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every linked library belongs to the approved dependency closure. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Library closure”; copy its required invariant exactly: “Every linked library belongs to the approved dependency closure”.
- [ ] **UC-M04.01-C023-T02 · Observable terms:** Define each term in the “Library closure” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C023-T03 · Precondition set:** List the preconditions under which “Every linked library belongs to the approved dependency closure” must hold for “Library closure”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C023-T04 · Transition coverage:** Map the “Library closure” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Library closure”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C023-T06 · Satisfying fixture:** Create a concrete “Library closure” case that satisfies “Every linked library belongs to the approved dependency closure”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C023-T07 · Violating fixture:** Create the source counterexample “An undeclared library appears during linking” for “Library closure”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C023-T08 · Enforcement evidence:** Exercise the “Library closure” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C023-T09 · Regression linkage:** Link the “Library closure” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Library closure” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C024 · Integration

**Original checklist item:** Integrate library closure with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Library closure” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C024-T02 · Field mapping:** Map every “Library closure” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Library closure” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C024-T04 · Ownership agreement:** Specify who owns “Library closure” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C024-T05 · Handoff implementation:** Connect “Library closure” through the mapped seam using the real adapter or explicit specification reference; preserve “Every linked library belongs to the approved dependency closure” across the handoff.
- [ ] **UC-M04.01-C024-T06 · Absent-input case:** Omit one required “Library closure” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C024-T07 · Stale-input case:** Supply an outdated “Library closure” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Library closure” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C024-T09 · Valid integration trace:** Run a valid “Library closure” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C024-T10 · Seam review:** Reconcile the “Library closure” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for library closure; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Library closure” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C025-T02 · Expected-result oracle:** Specify the “Library closure” expected result independently of the implementation output; include the property “Every linked library belongs to the approved dependency closure” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C025-T03 · Fixture material:** Create the concrete “Library closure” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C025-T04 · Target preparation:** Prepare the “Library closure” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C025-T05 · Initial-state record:** Record the initial “Library closure” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C025-T06 · Valid-path execution:** Execute the “Library closure” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C025-T07 · Outcome comparison:** Compare every declared “Library closure” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C025-T08 · State and bounds check:** Inspect the “Library closure” ownership/state effects and actual use of “Dependency count and closure traversal depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C025-T09 · Repeatability check:** Repeat the same “Library closure” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C025-T10 · Positive evidence:** Attach the “Library closure” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C026 · Negative test

**Original checklist item:** Negative case: An undeclared library appears during linking. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Library closure” source counterexample: “An undeclared library appears during linking”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Library closure”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C026-T03 · Valid control:** Construct a valid “Library closure” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C026-T04 · Minimal adverse input:** Derive the “Library closure” adverse fixture from the control with the smallest documented change needed to reproduce “An undeclared library appears during linking”; retain that change as reproducible data.
- [ ] **UC-M04.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Library closure”; require “Every linked library belongs to the approved dependency closure” and forbid a false-success verdict.
- [ ] **UC-M04.01-C026-T06 · Adverse execution:** Exercise the “Library closure” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C026-T07 · Effect inspection:** Inspect “Library closure” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C026-T08 · Refusal versus failure:** Confirm the “Library closure” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C026-T09 · Reset and retention:** Restore only the disposable “Library closure” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C026-T10 · Negative regression:** Register the “Library closure” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C027 · Change / failure test

**Original checklist item:** Exercise library closure when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C027-T01 · Scenario record:** Write the “Library closure” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “Every linked library belongs to the approved dependency closure”.
- [ ] **UC-M04.01-C027-T02 · Baseline capture:** Create a known-valid “Library closure” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C027-T03 · Injection map:** Locate the “Library closure” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Library closure” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C027-T05 · Controlled trigger:** Introduce the controlled “Library closure” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C027-T06 · Intermediate inspection:** Inspect the “Library closure” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Library closure”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Library closure” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C027-T09 · Repeat and compare:** Repeat the selected “Library closure” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C027-T10 · Failure evidence:** Publish the “Library closure” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for dependency count and closure traversal depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Library closure”: “Dependency count and closure traversal depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C028-T02 · Measurement method:** Choose how to observe each “Library closure” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Library closure”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Library closure” cases for “Dependency count and closure traversal depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Library closure” limit; preserve “Every linked library belongs to the approved dependency closure”.
- [ ] **UC-M04.01-C028-T06 · Normal measurement:** Run or review the normal “Library closure” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C028-T07 · At-limit measurement:** Exercise the “Library closure” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C028-T08 · Over-limit measurement:** Exercise the “Library closure” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C028-T09 · Uncovered-scope report:** List the “Library closure” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C028-T10 · Limit evidence:** Publish the selected “Library closure” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for library closure with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C029-T01 · Event inventory:** List the “Library closure” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Library closure” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C029-T03 · Failure mapping:** Map each documented “Library closure” refusal or error to a diagnostic outcome; include “An undeclared library appears during linking” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C029-T04 · Emission path:** Add the “Library closure” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C029-T05 · Redaction check:** Test “Library closure” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C029-T06 · Output budget:** Set and exercise bounded “Library closure” message size, rate and retention compatible with “Dependency count and closure traversal depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C029-T07 · Success/refusal fixtures:** Capture “Library closure” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Library closure” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C029-T09 · Operator review:** Read the “Library closure” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C029-T10 · Diagnostic evidence:** Publish redacted “Library closure” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for library closure; label unexecuted checks as untested.

- [ ] **UC-M04.01-C030-T01 · Evidence inventory:** List the “Library closure” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C030-T02 · Artifact references:** Record the exact “Library closure” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C030-T03 · Fixture references:** Attach the “Library closure” fixture IDs, input identities and oracle definition; preserve the source counterexample “An undeclared library appears during linking” as a distinct evidence case.
- [ ] **UC-M04.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Library closure”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C030-T05 · Environment record:** Record the actual “Library closure” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C030-T06 · Expected versus observed:** Pair every “Library closure” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C030-T07 · Failure and limit records:** Attach “Library closure” change/failure and bounds evidence where required; include uncovered “Dependency count and closure traversal depth” and unresolved violations of “Every linked library belongs to the approved dependency closure”.
- [ ] **UC-M04.01-C030-T08 · Evidence hygiene:** Check the “Library closure” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C030-T09 · Reproduction review:** Have the “Library closure” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C030-T10 · Acceptance linkage:** Link the “Library closure” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Engine source identity

**Source delivery:** Bind engine source files and generated inputs to immutable digests.

**Source invariant:** The built engine corresponds to the approved source inventory.

**Source negative case:** A local engine source edit is hidden by a stale archive pin.

**Source bounded quantities:** Source file count and hashing bytes.

### UC-M04.01-C031 · Contract

**Original checklist item:** Specify engine source identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C031-T01 · Scope statement:** Draft the operation boundary for “Engine source identity” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Engine source identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C031-T03 · Output inventory:** List the outputs of “Engine source identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Engine source identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C031-T05 · Prerequisite contract:** Map “Engine source identity” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Engine source identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C031-T07 · Invariant clause:** Add a normative clause for “Engine source identity” that preserves “The built engine corresponds to the approved source inventory”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Engine source identity”; include the source counterexample “A local engine source edit is hidden by a stale archive pin” and the intended safe disposition.
- [ ] **UC-M04.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Source file count and hashing bytes” in the “Engine source identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C031-T10 · Contract review:** Review the “Engine source identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C032 · Delivery

**Original checklist item:** Bind engine source files and generated inputs to immutable digests.

- [ ] **UC-M04.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Engine source identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C032-T02 · Change plan:** Break the source delivery for “Engine source identity” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Engine source identity” that realizes this source instruction: Bind engine source files and generated inputs to immutable digests.
- [ ] **UC-M04.01-C032-T04 · Concrete realization:** Trace “Engine source identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Engine source identity” needed to preserve “The built engine corresponds to the approved source inventory”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C032-T06 · Dependency connection:** Connect the “Engine source identity” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C032-T07 · Resource behavior:** Account for “Source file count and hashing bytes” in “Engine source identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C032-T08 · Delivery check:** Run the smallest real “Engine source identity” path and its adverse fixture “A local engine source edit is hidden by a stale archive pin”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C032-T09 · Patch review:** Review the “Engine source identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C032-T10 · Delivery handoff:** Publish the “Engine source identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The built engine corresponds to the approved source inventory. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Engine source identity”; copy its required invariant exactly: “The built engine corresponds to the approved source inventory”.
- [ ] **UC-M04.01-C033-T02 · Observable terms:** Define each term in the “Engine source identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C033-T03 · Precondition set:** List the preconditions under which “The built engine corresponds to the approved source inventory” must hold for “Engine source identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C033-T04 · Transition coverage:** Map the “Engine source identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Engine source identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C033-T06 · Satisfying fixture:** Create a concrete “Engine source identity” case that satisfies “The built engine corresponds to the approved source inventory”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C033-T07 · Violating fixture:** Create the source counterexample “A local engine source edit is hidden by a stale archive pin” for “Engine source identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C033-T08 · Enforcement evidence:** Exercise the “Engine source identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C033-T09 · Regression linkage:** Link the “Engine source identity” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Engine source identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C034 · Integration

**Original checklist item:** Integrate engine source identity with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Engine source identity” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C034-T02 · Field mapping:** Map every “Engine source identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Engine source identity” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C034-T04 · Ownership agreement:** Specify who owns “Engine source identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C034-T05 · Handoff implementation:** Connect “Engine source identity” through the mapped seam using the real adapter or explicit specification reference; preserve “The built engine corresponds to the approved source inventory” across the handoff.
- [ ] **UC-M04.01-C034-T06 · Absent-input case:** Omit one required “Engine source identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C034-T07 · Stale-input case:** Supply an outdated “Engine source identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Engine source identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C034-T09 · Valid integration trace:** Run a valid “Engine source identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C034-T10 · Seam review:** Reconcile the “Engine source identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for engine source identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Engine source identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C035-T02 · Expected-result oracle:** Specify the “Engine source identity” expected result independently of the implementation output; include the property “The built engine corresponds to the approved source inventory” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C035-T03 · Fixture material:** Create the concrete “Engine source identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C035-T04 · Target preparation:** Prepare the “Engine source identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C035-T05 · Initial-state record:** Record the initial “Engine source identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C035-T06 · Valid-path execution:** Execute the “Engine source identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C035-T07 · Outcome comparison:** Compare every declared “Engine source identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C035-T08 · State and bounds check:** Inspect the “Engine source identity” ownership/state effects and actual use of “Source file count and hashing bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C035-T09 · Repeatability check:** Repeat the same “Engine source identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C035-T10 · Positive evidence:** Attach the “Engine source identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C036 · Negative test

**Original checklist item:** Negative case: A local engine source edit is hidden by a stale archive pin. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Engine source identity” source counterexample: “A local engine source edit is hidden by a stale archive pin”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Engine source identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C036-T03 · Valid control:** Construct a valid “Engine source identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C036-T04 · Minimal adverse input:** Derive the “Engine source identity” adverse fixture from the control with the smallest documented change needed to reproduce “A local engine source edit is hidden by a stale archive pin”; retain that change as reproducible data.
- [ ] **UC-M04.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Engine source identity”; require “The built engine corresponds to the approved source inventory” and forbid a false-success verdict.
- [ ] **UC-M04.01-C036-T06 · Adverse execution:** Exercise the “Engine source identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C036-T07 · Effect inspection:** Inspect “Engine source identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C036-T08 · Refusal versus failure:** Confirm the “Engine source identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C036-T09 · Reset and retention:** Restore only the disposable “Engine source identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C036-T10 · Negative regression:** Register the “Engine source identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C037 · Change / failure test

**Original checklist item:** Exercise engine source identity when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C037-T01 · Scenario record:** Write the “Engine source identity” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “The built engine corresponds to the approved source inventory”.
- [ ] **UC-M04.01-C037-T02 · Baseline capture:** Create a known-valid “Engine source identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C037-T03 · Injection map:** Locate the “Engine source identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Engine source identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C037-T05 · Controlled trigger:** Introduce the controlled “Engine source identity” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C037-T06 · Intermediate inspection:** Inspect the “Engine source identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Engine source identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Engine source identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C037-T09 · Repeat and compare:** Repeat the selected “Engine source identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C037-T10 · Failure evidence:** Publish the “Engine source identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for source file count and hashing bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Engine source identity”: “Source file count and hashing bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C038-T02 · Measurement method:** Choose how to observe each “Engine source identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Engine source identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Engine source identity” cases for “Source file count and hashing bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Engine source identity” limit; preserve “The built engine corresponds to the approved source inventory”.
- [ ] **UC-M04.01-C038-T06 · Normal measurement:** Run or review the normal “Engine source identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C038-T07 · At-limit measurement:** Exercise the “Engine source identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C038-T08 · Over-limit measurement:** Exercise the “Engine source identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C038-T09 · Uncovered-scope report:** List the “Engine source identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C038-T10 · Limit evidence:** Publish the selected “Engine source identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for engine source identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C039-T01 · Event inventory:** List the “Engine source identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Engine source identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C039-T03 · Failure mapping:** Map each documented “Engine source identity” refusal or error to a diagnostic outcome; include “A local engine source edit is hidden by a stale archive pin” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C039-T04 · Emission path:** Add the “Engine source identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C039-T05 · Redaction check:** Test “Engine source identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C039-T06 · Output budget:** Set and exercise bounded “Engine source identity” message size, rate and retention compatible with “Source file count and hashing bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C039-T07 · Success/refusal fixtures:** Capture “Engine source identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Engine source identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C039-T09 · Operator review:** Read the “Engine source identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C039-T10 · Diagnostic evidence:** Publish redacted “Engine source identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for engine source identity; label unexecuted checks as untested.

- [ ] **UC-M04.01-C040-T01 · Evidence inventory:** List the “Engine source identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C040-T02 · Artifact references:** Record the exact “Engine source identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C040-T03 · Fixture references:** Attach the “Engine source identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A local engine source edit is hidden by a stale archive pin” as a distinct evidence case.
- [ ] **UC-M04.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Engine source identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C040-T05 · Environment record:** Record the actual “Engine source identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C040-T06 · Expected versus observed:** Pair every “Engine source identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C040-T07 · Failure and limit records:** Attach “Engine source identity” change/failure and bounds evidence where required; include uncovered “Source file count and hashing bytes” and unresolved violations of “The built engine corresponds to the approved source inventory”.
- [ ] **UC-M04.01-C040-T08 · Evidence hygiene:** Check the “Engine source identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C040-T09 · Reproduction review:** Have the “Engine source identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C040-T10 · Acceptance linkage:** Link the “Engine source identity” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Runtime artifact identity

**Source delivery:** Pin guest, hull, hold and required host runtime artifacts separately.

**Source invariant:** One verified archive cannot vouch for unrelated mutable runtime files.

**Source negative case:** A cached runtime changes while the source archive stays intact.

**Source bounded quantities:** Runtime artifacts and cache verification cost.

### UC-M04.01-C041 · Contract

**Original checklist item:** Specify runtime artifact identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C041-T01 · Scope statement:** Draft the operation boundary for “Runtime artifact identity” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Runtime artifact identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C041-T03 · Output inventory:** List the outputs of “Runtime artifact identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Runtime artifact identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C041-T05 · Prerequisite contract:** Map “Runtime artifact identity” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Runtime artifact identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C041-T07 · Invariant clause:** Add a normative clause for “Runtime artifact identity” that preserves “One verified archive cannot vouch for unrelated mutable runtime files”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Runtime artifact identity”; include the source counterexample “A cached runtime changes while the source archive stays intact” and the intended safe disposition.
- [ ] **UC-M04.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Runtime artifacts and cache verification cost” in the “Runtime artifact identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C041-T10 · Contract review:** Review the “Runtime artifact identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C042 · Delivery

**Original checklist item:** Pin guest, hull, hold and required host runtime artifacts separately.

- [ ] **UC-M04.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Runtime artifact identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C042-T02 · Change plan:** Break the source delivery for “Runtime artifact identity” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C042-T03 · Core artifact:** Prepare the “Runtime artifact identity” decision record for this source instruction: Pin guest, hull, hold and required host runtime artifacts separately.
- [ ] **UC-M04.01-C042-T04 · Concrete realization:** Evaluate the “Runtime artifact identity” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M04.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Runtime artifact identity” needed to preserve “One verified archive cannot vouch for unrelated mutable runtime files”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C042-T06 · Dependency connection:** Connect the “Runtime artifact identity” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C042-T07 · Resource behavior:** Account for “Runtime artifacts and cache verification cost” in “Runtime artifact identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C042-T08 · Delivery check:** Run the smallest real “Runtime artifact identity” path and its adverse fixture “A cached runtime changes while the source archive stays intact”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C042-T09 · Patch review:** Review the “Runtime artifact identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C042-T10 · Delivery handoff:** Publish the “Runtime artifact identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One verified archive cannot vouch for unrelated mutable runtime files. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Runtime artifact identity”; copy its required invariant exactly: “One verified archive cannot vouch for unrelated mutable runtime files”.
- [ ] **UC-M04.01-C043-T02 · Observable terms:** Define each term in the “Runtime artifact identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C043-T03 · Precondition set:** List the preconditions under which “One verified archive cannot vouch for unrelated mutable runtime files” must hold for “Runtime artifact identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C043-T04 · Transition coverage:** Map the “Runtime artifact identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Runtime artifact identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C043-T06 · Satisfying fixture:** Create a concrete “Runtime artifact identity” case that satisfies “One verified archive cannot vouch for unrelated mutable runtime files”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C043-T07 · Violating fixture:** Create the source counterexample “A cached runtime changes while the source archive stays intact” for “Runtime artifact identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C043-T08 · Enforcement evidence:** Exercise the “Runtime artifact identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C043-T09 · Regression linkage:** Link the “Runtime artifact identity” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Runtime artifact identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C044 · Integration

**Original checklist item:** Integrate runtime artifact identity with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Runtime artifact identity” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C044-T02 · Field mapping:** Map every “Runtime artifact identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Runtime artifact identity” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C044-T04 · Ownership agreement:** Specify who owns “Runtime artifact identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C044-T05 · Handoff implementation:** Connect “Runtime artifact identity” through the mapped seam using the real adapter or explicit specification reference; preserve “One verified archive cannot vouch for unrelated mutable runtime files” across the handoff.
- [ ] **UC-M04.01-C044-T06 · Absent-input case:** Omit one required “Runtime artifact identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C044-T07 · Stale-input case:** Supply an outdated “Runtime artifact identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Runtime artifact identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C044-T09 · Valid integration trace:** Run a valid “Runtime artifact identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C044-T10 · Seam review:** Reconcile the “Runtime artifact identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for runtime artifact identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Runtime artifact identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C045-T02 · Expected-result oracle:** Specify the “Runtime artifact identity” expected result independently of the implementation output; include the property “One verified archive cannot vouch for unrelated mutable runtime files” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C045-T03 · Fixture material:** Create the concrete “Runtime artifact identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C045-T04 · Target preparation:** Prepare the “Runtime artifact identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C045-T05 · Initial-state record:** Record the initial “Runtime artifact identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C045-T06 · Valid-path execution:** Execute the “Runtime artifact identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C045-T07 · Outcome comparison:** Compare every declared “Runtime artifact identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C045-T08 · State and bounds check:** Inspect the “Runtime artifact identity” ownership/state effects and actual use of “Runtime artifacts and cache verification cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C045-T09 · Repeatability check:** Repeat the same “Runtime artifact identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C045-T10 · Positive evidence:** Attach the “Runtime artifact identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C046 · Negative test

**Original checklist item:** Negative case: A cached runtime changes while the source archive stays intact. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Runtime artifact identity” source counterexample: “A cached runtime changes while the source archive stays intact”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Runtime artifact identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C046-T03 · Valid control:** Construct a valid “Runtime artifact identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C046-T04 · Minimal adverse input:** Derive the “Runtime artifact identity” adverse fixture from the control with the smallest documented change needed to reproduce “A cached runtime changes while the source archive stays intact”; retain that change as reproducible data.
- [ ] **UC-M04.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Runtime artifact identity”; require “One verified archive cannot vouch for unrelated mutable runtime files” and forbid a false-success verdict.
- [ ] **UC-M04.01-C046-T06 · Adverse execution:** Exercise the “Runtime artifact identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C046-T07 · Effect inspection:** Inspect “Runtime artifact identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C046-T08 · Refusal versus failure:** Confirm the “Runtime artifact identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C046-T09 · Reset and retention:** Restore only the disposable “Runtime artifact identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C046-T10 · Negative regression:** Register the “Runtime artifact identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C047 · Change / failure test

**Original checklist item:** Exercise runtime artifact identity when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C047-T01 · Scenario record:** Write the “Runtime artifact identity” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “One verified archive cannot vouch for unrelated mutable runtime files”.
- [ ] **UC-M04.01-C047-T02 · Baseline capture:** Create a known-valid “Runtime artifact identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C047-T03 · Injection map:** Locate the “Runtime artifact identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Runtime artifact identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C047-T05 · Controlled trigger:** Introduce the controlled “Runtime artifact identity” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C047-T06 · Intermediate inspection:** Inspect the “Runtime artifact identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Runtime artifact identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Runtime artifact identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C047-T09 · Repeat and compare:** Repeat the selected “Runtime artifact identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C047-T10 · Failure evidence:** Publish the “Runtime artifact identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for runtime artifacts and cache verification cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Runtime artifact identity”: “Runtime artifacts and cache verification cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C048-T02 · Measurement method:** Choose how to observe each “Runtime artifact identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Runtime artifact identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Runtime artifact identity” cases for “Runtime artifacts and cache verification cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Runtime artifact identity” limit; preserve “One verified archive cannot vouch for unrelated mutable runtime files”.
- [ ] **UC-M04.01-C048-T06 · Normal measurement:** Run or review the normal “Runtime artifact identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C048-T07 · At-limit measurement:** Exercise the “Runtime artifact identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C048-T08 · Over-limit measurement:** Exercise the “Runtime artifact identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C048-T09 · Uncovered-scope report:** List the “Runtime artifact identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C048-T10 · Limit evidence:** Publish the selected “Runtime artifact identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for runtime artifact identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C049-T01 · Event inventory:** List the “Runtime artifact identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Runtime artifact identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C049-T03 · Failure mapping:** Map each documented “Runtime artifact identity” refusal or error to a diagnostic outcome; include “A cached runtime changes while the source archive stays intact” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C049-T04 · Emission path:** Add the “Runtime artifact identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C049-T05 · Redaction check:** Test “Runtime artifact identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C049-T06 · Output budget:** Set and exercise bounded “Runtime artifact identity” message size, rate and retention compatible with “Runtime artifacts and cache verification cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C049-T07 · Success/refusal fixtures:** Capture “Runtime artifact identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Runtime artifact identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C049-T09 · Operator review:** Read the “Runtime artifact identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C049-T10 · Diagnostic evidence:** Publish redacted “Runtime artifact identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for runtime artifact identity; label unexecuted checks as untested.

- [ ] **UC-M04.01-C050-T01 · Evidence inventory:** List the “Runtime artifact identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C050-T02 · Artifact references:** Record the exact “Runtime artifact identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C050-T03 · Fixture references:** Attach the “Runtime artifact identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A cached runtime changes while the source archive stays intact” as a distinct evidence case.
- [ ] **UC-M04.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Runtime artifact identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C050-T05 · Environment record:** Record the actual “Runtime artifact identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C050-T06 · Expected versus observed:** Pair every “Runtime artifact identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C050-T07 · Failure and limit records:** Attach “Runtime artifact identity” change/failure and bounds evidence where required; include uncovered “Runtime artifacts and cache verification cost” and unresolved violations of “One verified archive cannot vouch for unrelated mutable runtime files”.
- [ ] **UC-M04.01-C050-T08 · Evidence hygiene:** Check the “Runtime artifact identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C050-T09 · Reproduction review:** Have the “Runtime artifact identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C050-T10 · Acceptance linkage:** Link the “Runtime artifact identity” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Offline dependency cache

**Source delivery:** Provide an explicit cache layout containing every required build input.

**Source invariant:** A complete offline build performs no implicit downloads.

**Source negative case:** A missing header triggers an unnoticed network fetch.

**Source bounded quantities:** Cache bytes and offline-build deadline.

### UC-M04.01-C051 · Contract

**Original checklist item:** Specify offline dependency cache inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C051-T01 · Scope statement:** Draft the operation boundary for “Offline dependency cache” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Offline dependency cache”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C051-T03 · Output inventory:** List the outputs of “Offline dependency cache” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Offline dependency cache”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C051-T05 · Prerequisite contract:** Map “Offline dependency cache” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Offline dependency cache”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C051-T07 · Invariant clause:** Add a normative clause for “Offline dependency cache” that preserves “A complete offline build performs no implicit downloads”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Offline dependency cache”; include the source counterexample “A missing header triggers an unnoticed network fetch” and the intended safe disposition.
- [ ] **UC-M04.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Cache bytes and offline-build deadline” in the “Offline dependency cache” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C051-T10 · Contract review:** Review the “Offline dependency cache” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C052 · Delivery

**Original checklist item:** Provide an explicit cache layout containing every required build input.

- [ ] **UC-M04.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Offline dependency cache”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C052-T02 · Change plan:** Break the source delivery for “Offline dependency cache” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Offline dependency cache” that realizes this source instruction: Provide an explicit cache layout containing every required build input.
- [ ] **UC-M04.01-C052-T04 · Concrete realization:** Trace “Offline dependency cache” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Offline dependency cache” needed to preserve “A complete offline build performs no implicit downloads”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C052-T06 · Dependency connection:** Connect the “Offline dependency cache” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C052-T07 · Resource behavior:** Account for “Cache bytes and offline-build deadline” in “Offline dependency cache”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C052-T08 · Delivery check:** Run the smallest real “Offline dependency cache” path and its adverse fixture “A missing header triggers an unnoticed network fetch”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C052-T09 · Patch review:** Review the “Offline dependency cache” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C052-T10 · Delivery handoff:** Publish the “Offline dependency cache” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A complete offline build performs no implicit downloads. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Offline dependency cache”; copy its required invariant exactly: “A complete offline build performs no implicit downloads”.
- [ ] **UC-M04.01-C053-T02 · Observable terms:** Define each term in the “Offline dependency cache” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C053-T03 · Precondition set:** List the preconditions under which “A complete offline build performs no implicit downloads” must hold for “Offline dependency cache”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C053-T04 · Transition coverage:** Map the “Offline dependency cache” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Offline dependency cache”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C053-T06 · Satisfying fixture:** Create a concrete “Offline dependency cache” case that satisfies “A complete offline build performs no implicit downloads”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C053-T07 · Violating fixture:** Create the source counterexample “A missing header triggers an unnoticed network fetch” for “Offline dependency cache”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C053-T08 · Enforcement evidence:** Exercise the “Offline dependency cache” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C053-T09 · Regression linkage:** Link the “Offline dependency cache” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Offline dependency cache” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C054 · Integration

**Original checklist item:** Integrate offline dependency cache with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Offline dependency cache” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C054-T02 · Field mapping:** Map every “Offline dependency cache” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Offline dependency cache” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C054-T04 · Ownership agreement:** Specify who owns “Offline dependency cache” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C054-T05 · Handoff implementation:** Connect “Offline dependency cache” through the mapped seam using the real adapter or explicit specification reference; preserve “A complete offline build performs no implicit downloads” across the handoff.
- [ ] **UC-M04.01-C054-T06 · Absent-input case:** Omit one required “Offline dependency cache” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C054-T07 · Stale-input case:** Supply an outdated “Offline dependency cache” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Offline dependency cache” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C054-T09 · Valid integration trace:** Run a valid “Offline dependency cache” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C054-T10 · Seam review:** Reconcile the “Offline dependency cache” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for offline dependency cache; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Offline dependency cache” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C055-T02 · Expected-result oracle:** Specify the “Offline dependency cache” expected result independently of the implementation output; include the property “A complete offline build performs no implicit downloads” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C055-T03 · Fixture material:** Create the concrete “Offline dependency cache” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C055-T04 · Target preparation:** Prepare the “Offline dependency cache” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C055-T05 · Initial-state record:** Record the initial “Offline dependency cache” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C055-T06 · Valid-path execution:** Execute the “Offline dependency cache” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C055-T07 · Outcome comparison:** Compare every declared “Offline dependency cache” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C055-T08 · State and bounds check:** Inspect the “Offline dependency cache” ownership/state effects and actual use of “Cache bytes and offline-build deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C055-T09 · Repeatability check:** Repeat the same “Offline dependency cache” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C055-T10 · Positive evidence:** Attach the “Offline dependency cache” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C056 · Negative test

**Original checklist item:** Negative case: A missing header triggers an unnoticed network fetch. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Offline dependency cache” source counterexample: “A missing header triggers an unnoticed network fetch”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Offline dependency cache”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C056-T03 · Valid control:** Construct a valid “Offline dependency cache” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C056-T04 · Minimal adverse input:** Derive the “Offline dependency cache” adverse fixture from the control with the smallest documented change needed to reproduce “A missing header triggers an unnoticed network fetch”; retain that change as reproducible data.
- [ ] **UC-M04.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Offline dependency cache”; require “A complete offline build performs no implicit downloads” and forbid a false-success verdict.
- [ ] **UC-M04.01-C056-T06 · Adverse execution:** Exercise the “Offline dependency cache” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C056-T07 · Effect inspection:** Inspect “Offline dependency cache” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C056-T08 · Refusal versus failure:** Confirm the “Offline dependency cache” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C056-T09 · Reset and retention:** Restore only the disposable “Offline dependency cache” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C056-T10 · Negative regression:** Register the “Offline dependency cache” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C057 · Change / failure test

**Original checklist item:** Exercise offline dependency cache when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C057-T01 · Scenario record:** Write the “Offline dependency cache” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “A complete offline build performs no implicit downloads”.
- [ ] **UC-M04.01-C057-T02 · Baseline capture:** Create a known-valid “Offline dependency cache” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C057-T03 · Injection map:** Locate the “Offline dependency cache” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Offline dependency cache” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C057-T05 · Controlled trigger:** Introduce the controlled “Offline dependency cache” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C057-T06 · Intermediate inspection:** Inspect the “Offline dependency cache” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Offline dependency cache”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Offline dependency cache” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C057-T09 · Repeat and compare:** Repeat the selected “Offline dependency cache” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C057-T10 · Failure evidence:** Publish the “Offline dependency cache” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for cache bytes and offline-build deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Offline dependency cache”: “Cache bytes and offline-build deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C058-T02 · Measurement method:** Choose how to observe each “Offline dependency cache” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Offline dependency cache”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Offline dependency cache” cases for “Cache bytes and offline-build deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Offline dependency cache” limit; preserve “A complete offline build performs no implicit downloads”.
- [ ] **UC-M04.01-C058-T06 · Normal measurement:** Run or review the normal “Offline dependency cache” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C058-T07 · At-limit measurement:** Exercise the “Offline dependency cache” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C058-T08 · Over-limit measurement:** Exercise the “Offline dependency cache” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C058-T09 · Uncovered-scope report:** List the “Offline dependency cache” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C058-T10 · Limit evidence:** Publish the selected “Offline dependency cache” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for offline dependency cache with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C059-T01 · Event inventory:** List the “Offline dependency cache” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Offline dependency cache” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C059-T03 · Failure mapping:** Map each documented “Offline dependency cache” refusal or error to a diagnostic outcome; include “A missing header triggers an unnoticed network fetch” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C059-T04 · Emission path:** Add the “Offline dependency cache” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C059-T05 · Redaction check:** Test “Offline dependency cache” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C059-T06 · Output budget:** Set and exercise bounded “Offline dependency cache” message size, rate and retention compatible with “Cache bytes and offline-build deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C059-T07 · Success/refusal fixtures:** Capture “Offline dependency cache” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Offline dependency cache” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C059-T09 · Operator review:** Read the “Offline dependency cache” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C059-T10 · Diagnostic evidence:** Publish redacted “Offline dependency cache” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for offline dependency cache; label unexecuted checks as untested.

- [ ] **UC-M04.01-C060-T01 · Evidence inventory:** List the “Offline dependency cache” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C060-T02 · Artifact references:** Record the exact “Offline dependency cache” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C060-T03 · Fixture references:** Attach the “Offline dependency cache” fixture IDs, input identities and oracle definition; preserve the source counterexample “A missing header triggers an unnoticed network fetch” as a distinct evidence case.
- [ ] **UC-M04.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Offline dependency cache”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C060-T05 · Environment record:** Record the actual “Offline dependency cache” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C060-T06 · Expected versus observed:** Pair every “Offline dependency cache” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C060-T07 · Failure and limit records:** Attach “Offline dependency cache” change/failure and bounds evidence where required; include uncovered “Cache bytes and offline-build deadline” and unresolved violations of “A complete offline build performs no implicit downloads”.
- [ ] **UC-M04.01-C060-T08 · Evidence hygiene:** Check the “Offline dependency cache” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C060-T09 · Reproduction review:** Have the “Offline dependency cache” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C060-T10 · Acceptance linkage:** Link the “Offline dependency cache” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Origin records

**Source delivery:** Record each dependency's retrieval origin and approved revision.

**Source invariant:** A digest record is accompanied by enough provenance to identify its source.

**Source negative case:** Two same-named packages have ambiguous origins.

**Source bounded quantities:** Origin fields and metadata size.

### UC-M04.01-C061 · Contract

**Original checklist item:** Specify origin records inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C061-T01 · Scope statement:** Draft the operation boundary for “Origin records” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Origin records”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C061-T03 · Output inventory:** List the outputs of “Origin records” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Origin records”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C061-T05 · Prerequisite contract:** Map “Origin records” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Origin records”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C061-T07 · Invariant clause:** Add a normative clause for “Origin records” that preserves “A digest record is accompanied by enough provenance to identify its source”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Origin records”; include the source counterexample “Two same-named packages have ambiguous origins” and the intended safe disposition.
- [ ] **UC-M04.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Origin fields and metadata size” in the “Origin records” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C061-T10 · Contract review:** Review the “Origin records” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C062 · Delivery

**Original checklist item:** Record each dependency's retrieval origin and approved revision.

- [ ] **UC-M04.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Origin records”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C062-T02 · Change plan:** Break the source delivery for “Origin records” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C062-T03 · Core artifact:** Create the “Origin records” model, schema or inventory that realizes this source instruction: Record each dependency's retrieval origin and approved revision.
- [ ] **UC-M04.01-C062-T04 · Concrete realization:** Populate “Origin records” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Origin records” needed to preserve “A digest record is accompanied by enough provenance to identify its source”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C062-T06 · Dependency connection:** Connect the “Origin records” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C062-T07 · Resource behavior:** Account for “Origin fields and metadata size” in “Origin records”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C062-T08 · Delivery check:** Run the smallest real “Origin records” path and its adverse fixture “Two same-named packages have ambiguous origins”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C062-T09 · Patch review:** Review the “Origin records” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C062-T10 · Delivery handoff:** Publish the “Origin records” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A digest record is accompanied by enough provenance to identify its source. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Origin records”; copy its required invariant exactly: “A digest record is accompanied by enough provenance to identify its source”.
- [ ] **UC-M04.01-C063-T02 · Observable terms:** Define each term in the “Origin records” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C063-T03 · Precondition set:** List the preconditions under which “A digest record is accompanied by enough provenance to identify its source” must hold for “Origin records”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C063-T04 · Transition coverage:** Map the “Origin records” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Origin records”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C063-T06 · Satisfying fixture:** Create a concrete “Origin records” case that satisfies “A digest record is accompanied by enough provenance to identify its source”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C063-T07 · Violating fixture:** Create the source counterexample “Two same-named packages have ambiguous origins” for “Origin records”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C063-T08 · Enforcement evidence:** Exercise the “Origin records” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C063-T09 · Regression linkage:** Link the “Origin records” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Origin records” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C064 · Integration

**Original checklist item:** Integrate origin records with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Origin records” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C064-T02 · Field mapping:** Map every “Origin records” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Origin records” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C064-T04 · Ownership agreement:** Specify who owns “Origin records” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C064-T05 · Handoff implementation:** Connect “Origin records” through the mapped seam using the real adapter or explicit specification reference; preserve “A digest record is accompanied by enough provenance to identify its source” across the handoff.
- [ ] **UC-M04.01-C064-T06 · Absent-input case:** Omit one required “Origin records” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C064-T07 · Stale-input case:** Supply an outdated “Origin records” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Origin records” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C064-T09 · Valid integration trace:** Run a valid “Origin records” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C064-T10 · Seam review:** Reconcile the “Origin records” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for origin records; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Origin records” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C065-T02 · Expected-result oracle:** Specify the “Origin records” expected result independently of the implementation output; include the property “A digest record is accompanied by enough provenance to identify its source” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C065-T03 · Fixture material:** Create the concrete “Origin records” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C065-T04 · Target preparation:** Prepare the “Origin records” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C065-T05 · Initial-state record:** Record the initial “Origin records” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C065-T06 · Valid-path execution:** Execute the “Origin records” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C065-T07 · Outcome comparison:** Compare every declared “Origin records” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C065-T08 · State and bounds check:** Inspect the “Origin records” ownership/state effects and actual use of “Origin fields and metadata size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C065-T09 · Repeatability check:** Repeat the same “Origin records” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C065-T10 · Positive evidence:** Attach the “Origin records” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C066 · Negative test

**Original checklist item:** Negative case: Two same-named packages have ambiguous origins. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Origin records” source counterexample: “Two same-named packages have ambiguous origins”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Origin records”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C066-T03 · Valid control:** Construct a valid “Origin records” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C066-T04 · Minimal adverse input:** Derive the “Origin records” adverse fixture from the control with the smallest documented change needed to reproduce “Two same-named packages have ambiguous origins”; retain that change as reproducible data.
- [ ] **UC-M04.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Origin records”; require “A digest record is accompanied by enough provenance to identify its source” and forbid a false-success verdict.
- [ ] **UC-M04.01-C066-T06 · Adverse execution:** Exercise the “Origin records” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C066-T07 · Effect inspection:** Inspect “Origin records” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C066-T08 · Refusal versus failure:** Confirm the “Origin records” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C066-T09 · Reset and retention:** Restore only the disposable “Origin records” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C066-T10 · Negative regression:** Register the “Origin records” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C067 · Change / failure test

**Original checklist item:** Exercise origin records when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C067-T01 · Scenario record:** Write the “Origin records” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “A digest record is accompanied by enough provenance to identify its source”.
- [ ] **UC-M04.01-C067-T02 · Baseline capture:** Create a known-valid “Origin records” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C067-T03 · Injection map:** Locate the “Origin records” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Origin records” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C067-T05 · Controlled trigger:** Introduce the controlled “Origin records” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C067-T06 · Intermediate inspection:** Inspect the “Origin records” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Origin records”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Origin records” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C067-T09 · Repeat and compare:** Repeat the selected “Origin records” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C067-T10 · Failure evidence:** Publish the “Origin records” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for origin fields and metadata size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Origin records”: “Origin fields and metadata size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C068-T02 · Measurement method:** Choose how to observe each “Origin records” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Origin records”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Origin records” cases for “Origin fields and metadata size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Origin records” limit; preserve “A digest record is accompanied by enough provenance to identify its source”.
- [ ] **UC-M04.01-C068-T06 · Normal measurement:** Run or review the normal “Origin records” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C068-T07 · At-limit measurement:** Exercise the “Origin records” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C068-T08 · Over-limit measurement:** Exercise the “Origin records” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C068-T09 · Uncovered-scope report:** List the “Origin records” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C068-T10 · Limit evidence:** Publish the selected “Origin records” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for origin records with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C069-T01 · Event inventory:** List the “Origin records” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Origin records” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C069-T03 · Failure mapping:** Map each documented “Origin records” refusal or error to a diagnostic outcome; include “Two same-named packages have ambiguous origins” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C069-T04 · Emission path:** Add the “Origin records” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C069-T05 · Redaction check:** Test “Origin records” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C069-T06 · Output budget:** Set and exercise bounded “Origin records” message size, rate and retention compatible with “Origin fields and metadata size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C069-T07 · Success/refusal fixtures:** Capture “Origin records” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Origin records” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C069-T09 · Operator review:** Read the “Origin records” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C069-T10 · Diagnostic evidence:** Publish redacted “Origin records” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for origin records; label unexecuted checks as untested.

- [ ] **UC-M04.01-C070-T01 · Evidence inventory:** List the “Origin records” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C070-T02 · Artifact references:** Record the exact “Origin records” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C070-T03 · Fixture references:** Attach the “Origin records” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two same-named packages have ambiguous origins” as a distinct evidence case.
- [ ] **UC-M04.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Origin records”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C070-T05 · Environment record:** Record the actual “Origin records” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C070-T06 · Expected versus observed:** Pair every “Origin records” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C070-T07 · Failure and limit records:** Attach “Origin records” change/failure and bounds evidence where required; include uncovered “Origin fields and metadata size” and unresolved violations of “A digest record is accompanied by enough provenance to identify its source”.
- [ ] **UC-M04.01-C070-T08 · Evidence hygiene:** Check the “Origin records” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C070-T09 · Reproduction review:** Have the “Origin records” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C070-T10 · Acceptance linkage:** Link the “Origin records” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Missing-input refusal

**Source delivery:** Detect absent or unverified inputs before starting executable build steps.

**Source invariant:** Missing prerequisites cannot be replaced without approval.

**Source negative case:** A dependency is absent and the build picks a system substitute.

**Source bounded quantities:** Preflight time and diagnostic count.

### UC-M04.01-C071 · Contract

**Original checklist item:** Specify missing-input refusal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C071-T01 · Scope statement:** Draft the operation boundary for “Missing-input refusal” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Missing-input refusal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C071-T03 · Output inventory:** List the outputs of “Missing-input refusal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Missing-input refusal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C071-T05 · Prerequisite contract:** Map “Missing-input refusal” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Missing-input refusal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C071-T07 · Invariant clause:** Add a normative clause for “Missing-input refusal” that preserves “Missing prerequisites cannot be replaced without approval”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Missing-input refusal”; include the source counterexample “A dependency is absent and the build picks a system substitute” and the intended safe disposition.
- [ ] **UC-M04.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Preflight time and diagnostic count” in the “Missing-input refusal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C071-T10 · Contract review:** Review the “Missing-input refusal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C072 · Delivery

**Original checklist item:** Detect absent or unverified inputs before starting executable build steps.

- [ ] **UC-M04.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Missing-input refusal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C072-T02 · Change plan:** Break the source delivery for “Missing-input refusal” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Missing-input refusal” that realizes this source instruction: Detect absent or unverified inputs before starting executable build steps.
- [ ] **UC-M04.01-C072-T04 · Concrete realization:** Trace “Missing-input refusal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Missing-input refusal” needed to preserve “Missing prerequisites cannot be replaced without approval”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C072-T06 · Dependency connection:** Connect the “Missing-input refusal” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C072-T07 · Resource behavior:** Account for “Preflight time and diagnostic count” in “Missing-input refusal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C072-T08 · Delivery check:** Run the smallest real “Missing-input refusal” path and its adverse fixture “A dependency is absent and the build picks a system substitute”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C072-T09 · Patch review:** Review the “Missing-input refusal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C072-T10 · Delivery handoff:** Publish the “Missing-input refusal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Missing prerequisites cannot be replaced without approval. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Missing-input refusal”; copy its required invariant exactly: “Missing prerequisites cannot be replaced without approval”.
- [ ] **UC-M04.01-C073-T02 · Observable terms:** Define each term in the “Missing-input refusal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C073-T03 · Precondition set:** List the preconditions under which “Missing prerequisites cannot be replaced without approval” must hold for “Missing-input refusal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C073-T04 · Transition coverage:** Map the “Missing-input refusal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Missing-input refusal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C073-T06 · Satisfying fixture:** Create a concrete “Missing-input refusal” case that satisfies “Missing prerequisites cannot be replaced without approval”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C073-T07 · Violating fixture:** Create the source counterexample “A dependency is absent and the build picks a system substitute” for “Missing-input refusal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C073-T08 · Enforcement evidence:** Exercise the “Missing-input refusal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C073-T09 · Regression linkage:** Link the “Missing-input refusal” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Missing-input refusal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C074 · Integration

**Original checklist item:** Integrate missing-input refusal with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Missing-input refusal” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C074-T02 · Field mapping:** Map every “Missing-input refusal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Missing-input refusal” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C074-T04 · Ownership agreement:** Specify who owns “Missing-input refusal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C074-T05 · Handoff implementation:** Connect “Missing-input refusal” through the mapped seam using the real adapter or explicit specification reference; preserve “Missing prerequisites cannot be replaced without approval” across the handoff.
- [ ] **UC-M04.01-C074-T06 · Absent-input case:** Omit one required “Missing-input refusal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C074-T07 · Stale-input case:** Supply an outdated “Missing-input refusal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Missing-input refusal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C074-T09 · Valid integration trace:** Run a valid “Missing-input refusal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C074-T10 · Seam review:** Reconcile the “Missing-input refusal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for missing-input refusal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Missing-input refusal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C075-T02 · Expected-result oracle:** Specify the “Missing-input refusal” expected result independently of the implementation output; include the property “Missing prerequisites cannot be replaced without approval” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C075-T03 · Fixture material:** Create the concrete “Missing-input refusal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C075-T04 · Target preparation:** Prepare the “Missing-input refusal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C075-T05 · Initial-state record:** Record the initial “Missing-input refusal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C075-T06 · Valid-path execution:** Execute the “Missing-input refusal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C075-T07 · Outcome comparison:** Compare every declared “Missing-input refusal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C075-T08 · State and bounds check:** Inspect the “Missing-input refusal” ownership/state effects and actual use of “Preflight time and diagnostic count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C075-T09 · Repeatability check:** Repeat the same “Missing-input refusal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C075-T10 · Positive evidence:** Attach the “Missing-input refusal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C076 · Negative test

**Original checklist item:** Negative case: A dependency is absent and the build picks a system substitute. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Missing-input refusal” source counterexample: “A dependency is absent and the build picks a system substitute”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Missing-input refusal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C076-T03 · Valid control:** Construct a valid “Missing-input refusal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C076-T04 · Minimal adverse input:** Derive the “Missing-input refusal” adverse fixture from the control with the smallest documented change needed to reproduce “A dependency is absent and the build picks a system substitute”; retain that change as reproducible data.
- [ ] **UC-M04.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Missing-input refusal”; require “Missing prerequisites cannot be replaced without approval” and forbid a false-success verdict.
- [ ] **UC-M04.01-C076-T06 · Adverse execution:** Exercise the “Missing-input refusal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C076-T07 · Effect inspection:** Inspect “Missing-input refusal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C076-T08 · Refusal versus failure:** Confirm the “Missing-input refusal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C076-T09 · Reset and retention:** Restore only the disposable “Missing-input refusal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C076-T10 · Negative regression:** Register the “Missing-input refusal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C077 · Change / failure test

**Original checklist item:** Exercise missing-input refusal when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C077-T01 · Scenario record:** Write the “Missing-input refusal” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “Missing prerequisites cannot be replaced without approval”.
- [ ] **UC-M04.01-C077-T02 · Baseline capture:** Create a known-valid “Missing-input refusal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C077-T03 · Injection map:** Locate the “Missing-input refusal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Missing-input refusal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C077-T05 · Controlled trigger:** Introduce the controlled “Missing-input refusal” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C077-T06 · Intermediate inspection:** Inspect the “Missing-input refusal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Missing-input refusal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Missing-input refusal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C077-T09 · Repeat and compare:** Repeat the selected “Missing-input refusal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C077-T10 · Failure evidence:** Publish the “Missing-input refusal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for preflight time and diagnostic count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Missing-input refusal”: “Preflight time and diagnostic count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C078-T02 · Measurement method:** Choose how to observe each “Missing-input refusal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Missing-input refusal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Missing-input refusal” cases for “Preflight time and diagnostic count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Missing-input refusal” limit; preserve “Missing prerequisites cannot be replaced without approval”.
- [ ] **UC-M04.01-C078-T06 · Normal measurement:** Run or review the normal “Missing-input refusal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C078-T07 · At-limit measurement:** Exercise the “Missing-input refusal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C078-T08 · Over-limit measurement:** Exercise the “Missing-input refusal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C078-T09 · Uncovered-scope report:** List the “Missing-input refusal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C078-T10 · Limit evidence:** Publish the selected “Missing-input refusal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for missing-input refusal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C079-T01 · Event inventory:** List the “Missing-input refusal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Missing-input refusal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C079-T03 · Failure mapping:** Map each documented “Missing-input refusal” refusal or error to a diagnostic outcome; include “A dependency is absent and the build picks a system substitute” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C079-T04 · Emission path:** Add the “Missing-input refusal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C079-T05 · Redaction check:** Test “Missing-input refusal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C079-T06 · Output budget:** Set and exercise bounded “Missing-input refusal” message size, rate and retention compatible with “Preflight time and diagnostic count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C079-T07 · Success/refusal fixtures:** Capture “Missing-input refusal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Missing-input refusal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C079-T09 · Operator review:** Read the “Missing-input refusal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C079-T10 · Diagnostic evidence:** Publish redacted “Missing-input refusal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for missing-input refusal; label unexecuted checks as untested.

- [ ] **UC-M04.01-C080-T01 · Evidence inventory:** List the “Missing-input refusal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C080-T02 · Artifact references:** Record the exact “Missing-input refusal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C080-T03 · Fixture references:** Attach the “Missing-input refusal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A dependency is absent and the build picks a system substitute” as a distinct evidence case.
- [ ] **UC-M04.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Missing-input refusal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C080-T05 · Environment record:** Record the actual “Missing-input refusal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C080-T06 · Expected versus observed:** Pair every “Missing-input refusal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C080-T07 · Failure and limit records:** Attach “Missing-input refusal” change/failure and bounds evidence where required; include uncovered “Preflight time and diagnostic count” and unresolved violations of “Missing prerequisites cannot be replaced without approval”.
- [ ] **UC-M04.01-C080-T08 · Evidence hygiene:** Check the “Missing-input refusal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C080-T09 · Reproduction review:** Have the “Missing-input refusal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C080-T10 · Acceptance linkage:** Link the “Missing-input refusal” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Environment resolution

**Source delivery:** Resolve tools from the locked inventory rather than ambient search paths.

**Source invariant:** Environment changes cannot alter dependency selection silently.

**Source negative case:** A user environment variable selects a different library tree.

**Source bounded quantities:** Environment entries and resolution steps.

### UC-M04.01-C081 · Contract

**Original checklist item:** Specify environment resolution inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C081-T01 · Scope statement:** Draft the operation boundary for “Environment resolution” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Environment resolution”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C081-T03 · Output inventory:** List the outputs of “Environment resolution” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Environment resolution”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C081-T05 · Prerequisite contract:** Map “Environment resolution” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Environment resolution”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C081-T07 · Invariant clause:** Add a normative clause for “Environment resolution” that preserves “Environment changes cannot alter dependency selection silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Environment resolution”; include the source counterexample “A user environment variable selects a different library tree” and the intended safe disposition.
- [ ] **UC-M04.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Environment entries and resolution steps” in the “Environment resolution” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C081-T10 · Contract review:** Review the “Environment resolution” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C082 · Delivery

**Original checklist item:** Resolve tools from the locked inventory rather than ambient search paths.

- [ ] **UC-M04.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Environment resolution”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C082-T02 · Change plan:** Break the source delivery for “Environment resolution” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Environment resolution” that realizes this source instruction: Resolve tools from the locked inventory rather than ambient search paths.
- [ ] **UC-M04.01-C082-T04 · Concrete realization:** Trace “Environment resolution” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Environment resolution” needed to preserve “Environment changes cannot alter dependency selection silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C082-T06 · Dependency connection:** Connect the “Environment resolution” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C082-T07 · Resource behavior:** Account for “Environment entries and resolution steps” in “Environment resolution”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C082-T08 · Delivery check:** Run the smallest real “Environment resolution” path and its adverse fixture “A user environment variable selects a different library tree”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C082-T09 · Patch review:** Review the “Environment resolution” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C082-T10 · Delivery handoff:** Publish the “Environment resolution” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Environment changes cannot alter dependency selection silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Environment resolution”; copy its required invariant exactly: “Environment changes cannot alter dependency selection silently”.
- [ ] **UC-M04.01-C083-T02 · Observable terms:** Define each term in the “Environment resolution” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C083-T03 · Precondition set:** List the preconditions under which “Environment changes cannot alter dependency selection silently” must hold for “Environment resolution”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C083-T04 · Transition coverage:** Map the “Environment resolution” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Environment resolution”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C083-T06 · Satisfying fixture:** Create a concrete “Environment resolution” case that satisfies “Environment changes cannot alter dependency selection silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C083-T07 · Violating fixture:** Create the source counterexample “A user environment variable selects a different library tree” for “Environment resolution”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C083-T08 · Enforcement evidence:** Exercise the “Environment resolution” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C083-T09 · Regression linkage:** Link the “Environment resolution” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Environment resolution” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C084 · Integration

**Original checklist item:** Integrate environment resolution with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Environment resolution” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C084-T02 · Field mapping:** Map every “Environment resolution” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Environment resolution” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C084-T04 · Ownership agreement:** Specify who owns “Environment resolution” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C084-T05 · Handoff implementation:** Connect “Environment resolution” through the mapped seam using the real adapter or explicit specification reference; preserve “Environment changes cannot alter dependency selection silently” across the handoff.
- [ ] **UC-M04.01-C084-T06 · Absent-input case:** Omit one required “Environment resolution” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C084-T07 · Stale-input case:** Supply an outdated “Environment resolution” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Environment resolution” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C084-T09 · Valid integration trace:** Run a valid “Environment resolution” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C084-T10 · Seam review:** Reconcile the “Environment resolution” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for environment resolution; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Environment resolution” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C085-T02 · Expected-result oracle:** Specify the “Environment resolution” expected result independently of the implementation output; include the property “Environment changes cannot alter dependency selection silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C085-T03 · Fixture material:** Create the concrete “Environment resolution” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C085-T04 · Target preparation:** Prepare the “Environment resolution” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C085-T05 · Initial-state record:** Record the initial “Environment resolution” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C085-T06 · Valid-path execution:** Execute the “Environment resolution” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C085-T07 · Outcome comparison:** Compare every declared “Environment resolution” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C085-T08 · State and bounds check:** Inspect the “Environment resolution” ownership/state effects and actual use of “Environment entries and resolution steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C085-T09 · Repeatability check:** Repeat the same “Environment resolution” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C085-T10 · Positive evidence:** Attach the “Environment resolution” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C086 · Negative test

**Original checklist item:** Negative case: A user environment variable selects a different library tree. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Environment resolution” source counterexample: “A user environment variable selects a different library tree”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Environment resolution”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C086-T03 · Valid control:** Construct a valid “Environment resolution” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C086-T04 · Minimal adverse input:** Derive the “Environment resolution” adverse fixture from the control with the smallest documented change needed to reproduce “A user environment variable selects a different library tree”; retain that change as reproducible data.
- [ ] **UC-M04.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Environment resolution”; require “Environment changes cannot alter dependency selection silently” and forbid a false-success verdict.
- [ ] **UC-M04.01-C086-T06 · Adverse execution:** Exercise the “Environment resolution” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C086-T07 · Effect inspection:** Inspect “Environment resolution” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C086-T08 · Refusal versus failure:** Confirm the “Environment resolution” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C086-T09 · Reset and retention:** Restore only the disposable “Environment resolution” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C086-T10 · Negative regression:** Register the “Environment resolution” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C087 · Change / failure test

**Original checklist item:** Exercise environment resolution when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C087-T01 · Scenario record:** Write the “Environment resolution” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “Environment changes cannot alter dependency selection silently”.
- [ ] **UC-M04.01-C087-T02 · Baseline capture:** Create a known-valid “Environment resolution” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C087-T03 · Injection map:** Locate the “Environment resolution” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Environment resolution” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C087-T05 · Controlled trigger:** Introduce the controlled “Environment resolution” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C087-T06 · Intermediate inspection:** Inspect the “Environment resolution” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Environment resolution”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Environment resolution” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C087-T09 · Repeat and compare:** Repeat the selected “Environment resolution” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C087-T10 · Failure evidence:** Publish the “Environment resolution” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for environment entries and resolution steps; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Environment resolution”: “Environment entries and resolution steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C088-T02 · Measurement method:** Choose how to observe each “Environment resolution” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Environment resolution”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Environment resolution” cases for “Environment entries and resolution steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Environment resolution” limit; preserve “Environment changes cannot alter dependency selection silently”.
- [ ] **UC-M04.01-C088-T06 · Normal measurement:** Run or review the normal “Environment resolution” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C088-T07 · At-limit measurement:** Exercise the “Environment resolution” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C088-T08 · Over-limit measurement:** Exercise the “Environment resolution” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C088-T09 · Uncovered-scope report:** List the “Environment resolution” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C088-T10 · Limit evidence:** Publish the selected “Environment resolution” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for environment resolution with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C089-T01 · Event inventory:** List the “Environment resolution” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Environment resolution” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C089-T03 · Failure mapping:** Map each documented “Environment resolution” refusal or error to a diagnostic outcome; include “A user environment variable selects a different library tree” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C089-T04 · Emission path:** Add the “Environment resolution” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C089-T05 · Redaction check:** Test “Environment resolution” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C089-T06 · Output budget:** Set and exercise bounded “Environment resolution” message size, rate and retention compatible with “Environment entries and resolution steps”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C089-T07 · Success/refusal fixtures:** Capture “Environment resolution” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Environment resolution” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C089-T09 · Operator review:** Read the “Environment resolution” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C089-T10 · Diagnostic evidence:** Publish redacted “Environment resolution” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for environment resolution; label unexecuted checks as untested.

- [ ] **UC-M04.01-C090-T01 · Evidence inventory:** List the “Environment resolution” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C090-T02 · Artifact references:** Record the exact “Environment resolution” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C090-T03 · Fixture references:** Attach the “Environment resolution” fixture IDs, input identities and oracle definition; preserve the source counterexample “A user environment variable selects a different library tree” as a distinct evidence case.
- [ ] **UC-M04.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Environment resolution”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C090-T05 · Environment record:** Record the actual “Environment resolution” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C090-T06 · Expected versus observed:** Pair every “Environment resolution” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C090-T07 · Failure and limit records:** Attach “Environment resolution” change/failure and bounds evidence where required; include uncovered “Environment entries and resolution steps” and unresolved violations of “Environment changes cannot alter dependency selection silently”.
- [ ] **UC-M04.01-C090-T08 · Evidence hygiene:** Check the “Environment resolution” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C090-T09 · Reproduction review:** Have the “Environment resolution” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C090-T10 · Acceptance linkage:** Link the “Environment resolution” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Closure verification

**Source delivery:** Reconcile observed compiler and linker inputs against the declared closure.

**Source invariant:** Every observed build input is approved or blocks the build.

**Source negative case:** A build reads an undeclared generated file.

**Source bounded quantities:** Observed input records and reconciliation memory.

### UC-M04.01-C091 · Contract

**Original checklist item:** Specify closure verification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.01-C091-T01 · Scope statement:** Draft the operation boundary for “Closure verification” within Locked toolchain and dependency closure; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Closure verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.01-C091-T03 · Output inventory:** List the outputs of “Closure verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Closure verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.01-C091-T05 · Prerequisite contract:** Map “Closure verification” to the source component prerequisites (UC-M01.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Closure verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.01-C091-T07 · Invariant clause:** Add a normative clause for “Closure verification” that preserves “Every observed build input is approved or blocks the build”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Closure verification”; include the source counterexample “A build reads an undeclared generated file” and the intended safe disposition.
- [ ] **UC-M04.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Observed input records and reconciliation memory” in the “Closure verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.01-C091-T10 · Contract review:** Review the “Closure verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.01-C092 · Delivery

**Original checklist item:** Reconcile observed compiler and linker inputs against the declared closure.

- [ ] **UC-M04.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Closure verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.01-C092-T02 · Change plan:** Break the source delivery for “Closure verification” into concrete edit targets and reviewable outputs; keep the UC-M04.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.01-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Closure verification” that realizes this source instruction: Reconcile observed compiler and linker inputs against the declared closure.
- [ ] **UC-M04.01-C092-T04 · Concrete realization:** Trace “Closure verification” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Closure verification” needed to preserve “Every observed build input is approved or blocks the build”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.01-C092-T06 · Dependency connection:** Connect the “Closure verification” implementation to source/dependency graph, offline cache and actual compiler/linker input resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.01-C092-T07 · Resource behavior:** Account for “Observed input records and reconciliation memory” in “Closure verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.01-C092-T08 · Delivery check:** Run the smallest real “Closure verification” path and its adverse fixture “A build reads an undeclared generated file”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.01-C092-T09 · Patch review:** Review the “Closure verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.01-C092-T10 · Delivery handoff:** Publish the “Closure verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every observed build input is approved or blocks the build. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Closure verification”; copy its required invariant exactly: “Every observed build input is approved or blocks the build”.
- [ ] **UC-M04.01-C093-T02 · Observable terms:** Define each term in the “Closure verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.01-C093-T03 · Precondition set:** List the preconditions under which “Every observed build input is approved or blocks the build” must hold for “Closure verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.01-C093-T04 · Transition coverage:** Map the “Closure verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Closure verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.01-C093-T06 · Satisfying fixture:** Create a concrete “Closure verification” case that satisfies “Every observed build input is approved or blocks the build”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.01-C093-T07 · Violating fixture:** Create the source counterexample “A build reads an undeclared generated file” for “Closure verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.01-C093-T08 · Enforcement evidence:** Exercise the “Closure verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.01-C093-T09 · Regression linkage:** Link the “Closure verification” property to changes in source/dependency graph, offline cache and actual compiler/linker input resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Closure verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.01-C094 · Integration

**Original checklist item:** Integrate closure verification with source/dependency graph, offline cache and actual compiler/linker input resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Closure verification” across source/dependency graph, offline cache and actual compiler/linker input resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.01-C094-T02 · Field mapping:** Map every “Closure verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Closure verification” (source dependency list: UC-M01.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.01-C094-T04 · Ownership agreement:** Specify who owns “Closure verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.01-C094-T05 · Handoff implementation:** Connect “Closure verification” through the mapped seam using the real adapter or explicit specification reference; preserve “Every observed build input is approved or blocks the build” across the handoff.
- [ ] **UC-M04.01-C094-T06 · Absent-input case:** Omit one required “Closure verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.01-C094-T07 · Stale-input case:** Supply an outdated “Closure verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Closure verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.01-C094-T09 · Valid integration trace:** Run a valid “Closure verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.01-C094-T10 · Seam review:** Reconcile the “Closure verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for closure verification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Closure verification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.01-C095-T02 · Expected-result oracle:** Specify the “Closure verification” expected result independently of the implementation output; include the property “Every observed build input is approved or blocks the build” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.01-C095-T03 · Fixture material:** Create the concrete “Closure verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.01-C095-T04 · Target preparation:** Prepare the “Closure verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.01-C095-T05 · Initial-state record:** Record the initial “Closure verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.01-C095-T06 · Valid-path execution:** Execute the “Closure verification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.01-C095-T07 · Outcome comparison:** Compare every declared “Closure verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.01-C095-T08 · State and bounds check:** Inspect the “Closure verification” ownership/state effects and actual use of “Observed input records and reconciliation memory”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.01-C095-T09 · Repeatability check:** Repeat the same “Closure verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.01-C095-T10 · Positive evidence:** Attach the “Closure verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.01-C096 · Negative test

**Original checklist item:** Negative case: A build reads an undeclared generated file. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Closure verification” source counterexample: “A build reads an undeclared generated file”; state which precondition or invariant it challenges.
- [ ] **UC-M04.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Closure verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.01-C096-T03 · Valid control:** Construct a valid “Closure verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.01-C096-T04 · Minimal adverse input:** Derive the “Closure verification” adverse fixture from the control with the smallest documented change needed to reproduce “A build reads an undeclared generated file”; retain that change as reproducible data.
- [ ] **UC-M04.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Closure verification”; require “Every observed build input is approved or blocks the build” and forbid a false-success verdict.
- [ ] **UC-M04.01-C096-T06 · Adverse execution:** Exercise the “Closure verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.01-C096-T07 · Effect inspection:** Inspect “Closure verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.01-C096-T08 · Refusal versus failure:** Confirm the “Closure verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.01-C096-T09 · Reset and retention:** Restore only the disposable “Closure verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.01-C096-T10 · Negative regression:** Register the “Closure verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.01-C097 · Change / failure test

**Original checklist item:** Exercise closure verification when a locked input is absent while an unapproved ambient substitute is available; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.01-C097-T01 · Scenario record:** Write the “Closure verification” change/failure scenario exactly as supplied: a locked input is absent while an unapproved ambient substitute is available; identify the property that must remain true: “Every observed build input is approved or blocks the build”.
- [ ] **UC-M04.01-C097-T02 · Baseline capture:** Create a known-valid “Closure verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.01-C097-T03 · Injection map:** Locate the “Closure verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Closure verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.01-C097-T05 · Controlled trigger:** Introduce the controlled “Closure verification” scenario in the disposable fixture: a locked input is absent while an unapproved ambient substitute is available; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.01-C097-T06 · Intermediate inspection:** Inspect the “Closure verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Closure verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Closure verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.01-C097-T09 · Repeat and compare:** Repeat the selected “Closure verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.01-C097-T10 · Failure evidence:** Publish the “Closure verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for observed input records and reconciliation memory; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Closure verification”: “Observed input records and reconciliation memory”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.01-C098-T02 · Measurement method:** Choose how to observe each “Closure verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.01-C098-T03 · Budget decision:** Select justified resource and input limits for “Closure verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Closure verification” cases for “Observed input records and reconciliation memory”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Closure verification” limit; preserve “Every observed build input is approved or blocks the build”.
- [ ] **UC-M04.01-C098-T06 · Normal measurement:** Run or review the normal “Closure verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.01-C098-T07 · At-limit measurement:** Exercise the “Closure verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.01-C098-T08 · Over-limit measurement:** Exercise the “Closure verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.01-C098-T09 · Uncovered-scope report:** List the “Closure verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.01-C098-T10 · Limit evidence:** Publish the selected “Closure verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for closure verification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.01-C099-T01 · Event inventory:** List the “Closure verification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Closure verification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.01-C099-T03 · Failure mapping:** Map each documented “Closure verification” refusal or error to a diagnostic outcome; include “A build reads an undeclared generated file” and prohibit conversion into a success message.
- [ ] **UC-M04.01-C099-T04 · Emission path:** Add the “Closure verification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.01-C099-T05 · Redaction check:** Test “Closure verification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.01-C099-T06 · Output budget:** Set and exercise bounded “Closure verification” message size, rate and retention compatible with “Observed input records and reconciliation memory”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.01-C099-T07 · Success/refusal fixtures:** Capture “Closure verification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Closure verification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.01-C099-T09 · Operator review:** Read the “Closure verification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.01-C099-T10 · Diagnostic evidence:** Publish redacted “Closure verification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for closure verification; label unexecuted checks as untested.

- [ ] **UC-M04.01-C100-T01 · Evidence inventory:** List the “Closure verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.01-C100-T02 · Artifact references:** Record the exact “Closure verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.01-C100-T03 · Fixture references:** Attach the “Closure verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build reads an undeclared generated file” as a distinct evidence case.
- [ ] **UC-M04.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Closure verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.01-C100-T05 · Environment record:** Record the actual “Closure verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.01-C100-T06 · Expected versus observed:** Pair every “Closure verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.01-C100-T07 · Failure and limit records:** Attach “Closure verification” change/failure and bounds evidence where required; include uncovered “Observed input records and reconciliation memory” and unresolved violations of “Every observed build input is approved or blocks the build”.
- [ ] **UC-M04.01-C100-T08 · Evidence hygiene:** Check the “Closure verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.01-C100-T09 · Reproduction review:** Have the “Closure verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.01-C100-T10 · Acceptance linkage:** Link the “Closure verification” evidence to its parent and UC-M04.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

