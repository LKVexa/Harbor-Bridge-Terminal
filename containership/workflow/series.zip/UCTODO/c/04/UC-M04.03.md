# UC-M04.03 — Sandboxed build workers

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.03](../03/UC-M03.03.md), [UC-M03.05](../03/UC-M03.05.md), [UC-M04.01](../04/UC-M04.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Treat compilers, build hooks and imported project tooling as untrusted execution with disposable roots and quotas.

**Original acceptance criterion:** A hostile build cannot read operator secrets, contact unapproved endpoints or persist outside its workspace.

**Source trace:** Original checklist `UC100/c/04/UC-M04.03.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 356–366 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Disposable build roots

**Source delivery:** Create isolated workspaces for each build with explicit owned outputs.

**Source invariant:** Build writes cannot escape the disposable workspace.

**Source negative case:** A build hook writes into the operator's home directory.

**Source bounded quantities:** Workspace bytes and concurrent builders.

### UC-M04.03-C001 · Contract

**Original checklist item:** Specify disposable build roots inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C001-T01 · Scope statement:** Draft the operation boundary for “Disposable build roots” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Disposable build roots”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C001-T03 · Output inventory:** List the outputs of “Disposable build roots” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Disposable build roots”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C001-T05 · Prerequisite contract:** Map “Disposable build roots” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C001-T06 · Authority map:** Identify who may produce, change and consume “Disposable build roots”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C001-T07 · Invariant clause:** Add a normative clause for “Disposable build roots” that preserves “Build writes cannot escape the disposable workspace”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Disposable build roots”; include the source counterexample “A build hook writes into the operator's home directory” and the intended safe disposition.
- [ ] **UC-M04.03-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Workspace bytes and concurrent builders” in the “Disposable build roots” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C001-T10 · Contract review:** Review the “Disposable build roots” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C002 · Delivery

**Original checklist item:** Create isolated workspaces for each build with explicit owned outputs.

- [ ] **UC-M04.03-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Disposable build roots”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C002-T02 · Change plan:** Break the source delivery for “Disposable build roots” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Disposable build roots” that realizes this source instruction: Create isolated workspaces for each build with explicit owned outputs.
- [ ] **UC-M04.03-C002-T04 · Concrete realization:** Trace “Disposable build roots” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Disposable build roots” needed to preserve “Build writes cannot escape the disposable workspace”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C002-T06 · Dependency connection:** Connect the “Disposable build roots” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C002-T07 · Resource behavior:** Account for “Workspace bytes and concurrent builders” in “Disposable build roots”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C002-T08 · Delivery check:** Run the smallest real “Disposable build roots” path and its adverse fixture “A build hook writes into the operator's home directory”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C002-T09 · Patch review:** Review the “Disposable build roots” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C002-T10 · Delivery handoff:** Publish the “Disposable build roots” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Build writes cannot escape the disposable workspace. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C003-T01 · Named property:** Create a stable property/check name under this parent for “Disposable build roots”; copy its required invariant exactly: “Build writes cannot escape the disposable workspace”.
- [ ] **UC-M04.03-C003-T02 · Observable terms:** Define each term in the “Disposable build roots” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C003-T03 · Precondition set:** List the preconditions under which “Build writes cannot escape the disposable workspace” must hold for “Disposable build roots”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C003-T04 · Transition coverage:** Map the “Disposable build roots” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Disposable build roots”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C003-T06 · Satisfying fixture:** Create a concrete “Disposable build roots” case that satisfies “Build writes cannot escape the disposable workspace”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C003-T07 · Violating fixture:** Create the source counterexample “A build hook writes into the operator's home directory” for “Disposable build roots”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C003-T08 · Enforcement evidence:** Exercise the “Disposable build roots” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C003-T09 · Regression linkage:** Link the “Disposable build roots” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C003-T10 · Property disposition:** Compare the satisfying and violating “Disposable build roots” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C004 · Integration

**Original checklist item:** Integrate disposable build roots with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Disposable build roots” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C004-T02 · Field mapping:** Map every “Disposable build roots” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Disposable build roots” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C004-T04 · Ownership agreement:** Specify who owns “Disposable build roots” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C004-T05 · Handoff implementation:** Connect “Disposable build roots” through the mapped seam using the real adapter or explicit specification reference; preserve “Build writes cannot escape the disposable workspace” across the handoff.
- [ ] **UC-M04.03-C004-T06 · Absent-input case:** Omit one required “Disposable build roots” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C004-T07 · Stale-input case:** Supply an outdated “Disposable build roots” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C004-T08 · Incompatible-input case:** Supply an incompatible “Disposable build roots” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C004-T09 · Valid integration trace:** Run a valid “Disposable build roots” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C004-T10 · Seam review:** Reconcile the “Disposable build roots” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for disposable build roots; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Disposable build roots” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C005-T02 · Expected-result oracle:** Specify the “Disposable build roots” expected result independently of the implementation output; include the property “Build writes cannot escape the disposable workspace” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C005-T03 · Fixture material:** Create the concrete “Disposable build roots” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C005-T04 · Target preparation:** Prepare the “Disposable build roots” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C005-T05 · Initial-state record:** Record the initial “Disposable build roots” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C005-T06 · Valid-path execution:** Execute the “Disposable build roots” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C005-T07 · Outcome comparison:** Compare every declared “Disposable build roots” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C005-T08 · State and bounds check:** Inspect the “Disposable build roots” ownership/state effects and actual use of “Workspace bytes and concurrent builders”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C005-T09 · Repeatability check:** Repeat the same “Disposable build roots” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C005-T10 · Positive evidence:** Attach the “Disposable build roots” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C006 · Negative test

**Original checklist item:** Negative case: A build hook writes into the operator's home directory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C006-T01 · Adverse-case definition:** Create a test record for the exact “Disposable build roots” source counterexample: “A build hook writes into the operator's home directory”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Disposable build roots”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C006-T03 · Valid control:** Construct a valid “Disposable build roots” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C006-T04 · Minimal adverse input:** Derive the “Disposable build roots” adverse fixture from the control with the smallest documented change needed to reproduce “A build hook writes into the operator's home directory”; retain that change as reproducible data.
- [ ] **UC-M04.03-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Disposable build roots”; require “Build writes cannot escape the disposable workspace” and forbid a false-success verdict.
- [ ] **UC-M04.03-C006-T06 · Adverse execution:** Exercise the “Disposable build roots” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C006-T07 · Effect inspection:** Inspect “Disposable build roots” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C006-T08 · Refusal versus failure:** Confirm the “Disposable build roots” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C006-T09 · Reset and retention:** Restore only the disposable “Disposable build roots” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C006-T10 · Negative regression:** Register the “Disposable build roots” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C007 · Change / failure test

**Original checklist item:** Exercise disposable build roots when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C007-T01 · Scenario record:** Write the “Disposable build roots” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “Build writes cannot escape the disposable workspace”.
- [ ] **UC-M04.03-C007-T02 · Baseline capture:** Create a known-valid “Disposable build roots” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C007-T03 · Injection map:** Locate the “Disposable build roots” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Disposable build roots” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C007-T05 · Controlled trigger:** Introduce the controlled “Disposable build roots” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C007-T06 · Intermediate inspection:** Inspect the “Disposable build roots” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Disposable build roots”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Disposable build roots” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C007-T09 · Repeat and compare:** Repeat the selected “Disposable build roots” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C007-T10 · Failure evidence:** Publish the “Disposable build roots” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C008 · Bounds

**Original checklist item:** Choose, document and test limits for workspace bytes and concurrent builders; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C008-T01 · Quantity inventory:** Create a measurement inventory for “Disposable build roots”: “Workspace bytes and concurrent builders”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C008-T02 · Measurement method:** Choose how to observe each “Disposable build roots” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C008-T03 · Budget decision:** Select justified resource and input limits for “Disposable build roots”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Disposable build roots” cases for “Workspace bytes and concurrent builders”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Disposable build roots” limit; preserve “Build writes cannot escape the disposable workspace”.
- [ ] **UC-M04.03-C008-T06 · Normal measurement:** Run or review the normal “Disposable build roots” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C008-T07 · At-limit measurement:** Exercise the “Disposable build roots” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C008-T08 · Over-limit measurement:** Exercise the “Disposable build roots” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C008-T09 · Uncovered-scope report:** List the “Disposable build roots” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C008-T10 · Limit evidence:** Publish the selected “Disposable build roots” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for disposable build roots with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C009-T01 · Event inventory:** List the “Disposable build roots” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Disposable build roots” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C009-T03 · Failure mapping:** Map each documented “Disposable build roots” refusal or error to a diagnostic outcome; include “A build hook writes into the operator's home directory” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C009-T04 · Emission path:** Add the “Disposable build roots” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C009-T05 · Redaction check:** Test “Disposable build roots” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C009-T06 · Output budget:** Set and exercise bounded “Disposable build roots” message size, rate and retention compatible with “Workspace bytes and concurrent builders”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C009-T07 · Success/refusal fixtures:** Capture “Disposable build roots” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Disposable build roots” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C009-T09 · Operator review:** Read the “Disposable build roots” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C009-T10 · Diagnostic evidence:** Publish redacted “Disposable build roots” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for disposable build roots; label unexecuted checks as untested.

- [ ] **UC-M04.03-C010-T01 · Evidence inventory:** List the “Disposable build roots” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C010-T02 · Artifact references:** Record the exact “Disposable build roots” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C010-T03 · Fixture references:** Attach the “Disposable build roots” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build hook writes into the operator's home directory” as a distinct evidence case.
- [ ] **UC-M04.03-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Disposable build roots”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C010-T05 · Environment record:** Record the actual “Disposable build roots” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C010-T06 · Expected versus observed:** Pair every “Disposable build roots” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C010-T07 · Failure and limit records:** Attach “Disposable build roots” change/failure and bounds evidence where required; include uncovered “Workspace bytes and concurrent builders” and unresolved violations of “Build writes cannot escape the disposable workspace”.
- [ ] **UC-M04.03-C010-T08 · Evidence hygiene:** Check the “Disposable build roots” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C010-T09 · Reproduction review:** Have the “Disposable build roots” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C010-T10 · Acceptance linkage:** Link the “Disposable build roots” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Builder identity

**Source delivery:** Run compilers and hooks under the selected restricted execution identity.

**Source invariant:** Imported build tooling does not inherit operator authority.

**Source negative case:** A build script executes with unrestricted operator credentials.

**Source bounded quantities:** Builder identities and effective privileges.

### UC-M04.03-C011 · Contract

**Original checklist item:** Specify builder identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C011-T01 · Scope statement:** Draft the operation boundary for “Builder identity” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Builder identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C011-T03 · Output inventory:** List the outputs of “Builder identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Builder identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C011-T05 · Prerequisite contract:** Map “Builder identity” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C011-T06 · Authority map:** Identify who may produce, change and consume “Builder identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C011-T07 · Invariant clause:** Add a normative clause for “Builder identity” that preserves “Imported build tooling does not inherit operator authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Builder identity”; include the source counterexample “A build script executes with unrestricted operator credentials” and the intended safe disposition.
- [ ] **UC-M04.03-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Builder identities and effective privileges” in the “Builder identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C011-T10 · Contract review:** Review the “Builder identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C012 · Delivery

**Original checklist item:** Run compilers and hooks under the selected restricted execution identity.

- [ ] **UC-M04.03-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Builder identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C012-T02 · Change plan:** Break the source delivery for “Builder identity” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C012-T03 · Core artifact:** Create the “Builder identity” fixture or harness for this source instruction: Run compilers and hooks under the selected restricted execution identity.
- [ ] **UC-M04.03-C012-T04 · Concrete realization:** Connect the “Builder identity” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.03-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Builder identity” needed to preserve “Imported build tooling does not inherit operator authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C012-T06 · Dependency connection:** Connect the “Builder identity” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C012-T07 · Resource behavior:** Account for “Builder identities and effective privileges” in “Builder identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C012-T08 · Delivery check:** Run the smallest real “Builder identity” path and its adverse fixture “A build script executes with unrestricted operator credentials”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C012-T09 · Patch review:** Review the “Builder identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C012-T10 · Delivery handoff:** Publish the “Builder identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Imported build tooling does not inherit operator authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C013-T01 · Named property:** Create a stable property/check name under this parent for “Builder identity”; copy its required invariant exactly: “Imported build tooling does not inherit operator authority”.
- [ ] **UC-M04.03-C013-T02 · Observable terms:** Define each term in the “Builder identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C013-T03 · Precondition set:** List the preconditions under which “Imported build tooling does not inherit operator authority” must hold for “Builder identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C013-T04 · Transition coverage:** Map the “Builder identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Builder identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C013-T06 · Satisfying fixture:** Create a concrete “Builder identity” case that satisfies “Imported build tooling does not inherit operator authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C013-T07 · Violating fixture:** Create the source counterexample “A build script executes with unrestricted operator credentials” for “Builder identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C013-T08 · Enforcement evidence:** Exercise the “Builder identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C013-T09 · Regression linkage:** Link the “Builder identity” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C013-T10 · Property disposition:** Compare the satisfying and violating “Builder identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C014 · Integration

**Original checklist item:** Integrate builder identity with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Builder identity” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C014-T02 · Field mapping:** Map every “Builder identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Builder identity” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C014-T04 · Ownership agreement:** Specify who owns “Builder identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C014-T05 · Handoff implementation:** Connect “Builder identity” through the mapped seam using the real adapter or explicit specification reference; preserve “Imported build tooling does not inherit operator authority” across the handoff.
- [ ] **UC-M04.03-C014-T06 · Absent-input case:** Omit one required “Builder identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C014-T07 · Stale-input case:** Supply an outdated “Builder identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C014-T08 · Incompatible-input case:** Supply an incompatible “Builder identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C014-T09 · Valid integration trace:** Run a valid “Builder identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C014-T10 · Seam review:** Reconcile the “Builder identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for builder identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Builder identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C015-T02 · Expected-result oracle:** Specify the “Builder identity” expected result independently of the implementation output; include the property “Imported build tooling does not inherit operator authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C015-T03 · Fixture material:** Create the concrete “Builder identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C015-T04 · Target preparation:** Prepare the “Builder identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C015-T05 · Initial-state record:** Record the initial “Builder identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C015-T06 · Valid-path execution:** Execute the “Builder identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C015-T07 · Outcome comparison:** Compare every declared “Builder identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C015-T08 · State and bounds check:** Inspect the “Builder identity” ownership/state effects and actual use of “Builder identities and effective privileges”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C015-T09 · Repeatability check:** Repeat the same “Builder identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C015-T10 · Positive evidence:** Attach the “Builder identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C016 · Negative test

**Original checklist item:** Negative case: A build script executes with unrestricted operator credentials. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C016-T01 · Adverse-case definition:** Create a test record for the exact “Builder identity” source counterexample: “A build script executes with unrestricted operator credentials”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Builder identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C016-T03 · Valid control:** Construct a valid “Builder identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C016-T04 · Minimal adverse input:** Derive the “Builder identity” adverse fixture from the control with the smallest documented change needed to reproduce “A build script executes with unrestricted operator credentials”; retain that change as reproducible data.
- [ ] **UC-M04.03-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Builder identity”; require “Imported build tooling does not inherit operator authority” and forbid a false-success verdict.
- [ ] **UC-M04.03-C016-T06 · Adverse execution:** Exercise the “Builder identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C016-T07 · Effect inspection:** Inspect “Builder identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C016-T08 · Refusal versus failure:** Confirm the “Builder identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C016-T09 · Reset and retention:** Restore only the disposable “Builder identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C016-T10 · Negative regression:** Register the “Builder identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C017 · Change / failure test

**Original checklist item:** Exercise builder identity when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C017-T01 · Scenario record:** Write the “Builder identity” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “Imported build tooling does not inherit operator authority”.
- [ ] **UC-M04.03-C017-T02 · Baseline capture:** Create a known-valid “Builder identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C017-T03 · Injection map:** Locate the “Builder identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Builder identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C017-T05 · Controlled trigger:** Introduce the controlled “Builder identity” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C017-T06 · Intermediate inspection:** Inspect the “Builder identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Builder identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Builder identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C017-T09 · Repeat and compare:** Repeat the selected “Builder identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C017-T10 · Failure evidence:** Publish the “Builder identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C018 · Bounds

**Original checklist item:** Choose, document and test limits for builder identities and effective privileges; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C018-T01 · Quantity inventory:** Create a measurement inventory for “Builder identity”: “Builder identities and effective privileges”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C018-T02 · Measurement method:** Choose how to observe each “Builder identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C018-T03 · Budget decision:** Select justified resource and input limits for “Builder identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Builder identity” cases for “Builder identities and effective privileges”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Builder identity” limit; preserve “Imported build tooling does not inherit operator authority”.
- [ ] **UC-M04.03-C018-T06 · Normal measurement:** Run or review the normal “Builder identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C018-T07 · At-limit measurement:** Exercise the “Builder identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C018-T08 · Over-limit measurement:** Exercise the “Builder identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C018-T09 · Uncovered-scope report:** List the “Builder identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C018-T10 · Limit evidence:** Publish the selected “Builder identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for builder identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C019-T01 · Event inventory:** List the “Builder identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Builder identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C019-T03 · Failure mapping:** Map each documented “Builder identity” refusal or error to a diagnostic outcome; include “A build script executes with unrestricted operator credentials” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C019-T04 · Emission path:** Add the “Builder identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C019-T05 · Redaction check:** Test “Builder identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C019-T06 · Output budget:** Set and exercise bounded “Builder identity” message size, rate and retention compatible with “Builder identities and effective privileges”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C019-T07 · Success/refusal fixtures:** Capture “Builder identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Builder identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C019-T09 · Operator review:** Read the “Builder identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C019-T10 · Diagnostic evidence:** Publish redacted “Builder identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for builder identity; label unexecuted checks as untested.

- [ ] **UC-M04.03-C020-T01 · Evidence inventory:** List the “Builder identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C020-T02 · Artifact references:** Record the exact “Builder identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C020-T03 · Fixture references:** Attach the “Builder identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build script executes with unrestricted operator credentials” as a distinct evidence case.
- [ ] **UC-M04.03-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Builder identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C020-T05 · Environment record:** Record the actual “Builder identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C020-T06 · Expected versus observed:** Pair every “Builder identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C020-T07 · Failure and limit records:** Attach “Builder identity” change/failure and bounds evidence where required; include uncovered “Builder identities and effective privileges” and unresolved violations of “Imported build tooling does not inherit operator authority”.
- [ ] **UC-M04.03-C020-T08 · Evidence hygiene:** Check the “Builder identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C020-T09 · Reproduction review:** Have the “Builder identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C020-T10 · Acceptance linkage:** Link the “Builder identity” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Secret exclusion

**Source delivery:** Remove operator credentials from environment, files and mounted inputs.

**Source invariant:** Untrusted builds cannot read operator secrets.

**Source negative case:** A hostile hook searches inherited environment variables for credentials.

**Source bounded quantities:** Exposed environment bytes and mounted paths.

### UC-M04.03-C021 · Contract

**Original checklist item:** Specify secret exclusion inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C021-T01 · Scope statement:** Draft the operation boundary for “Secret exclusion” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Secret exclusion”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C021-T03 · Output inventory:** List the outputs of “Secret exclusion” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Secret exclusion”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C021-T05 · Prerequisite contract:** Map “Secret exclusion” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C021-T06 · Authority map:** Identify who may produce, change and consume “Secret exclusion”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C021-T07 · Invariant clause:** Add a normative clause for “Secret exclusion” that preserves “Untrusted builds cannot read operator secrets”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Secret exclusion”; include the source counterexample “A hostile hook searches inherited environment variables for credentials” and the intended safe disposition.
- [ ] **UC-M04.03-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Exposed environment bytes and mounted paths” in the “Secret exclusion” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C021-T10 · Contract review:** Review the “Secret exclusion” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C022 · Delivery

**Original checklist item:** Remove operator credentials from environment, files and mounted inputs.

- [ ] **UC-M04.03-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Secret exclusion”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C022-T02 · Change plan:** Break the source delivery for “Secret exclusion” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Secret exclusion” that realizes this source instruction: Remove operator credentials from environment, files and mounted inputs.
- [ ] **UC-M04.03-C022-T04 · Concrete realization:** Trace “Secret exclusion” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Secret exclusion” needed to preserve “Untrusted builds cannot read operator secrets”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C022-T06 · Dependency connection:** Connect the “Secret exclusion” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C022-T07 · Resource behavior:** Account for “Exposed environment bytes and mounted paths” in “Secret exclusion”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C022-T08 · Delivery check:** Run the smallest real “Secret exclusion” path and its adverse fixture “A hostile hook searches inherited environment variables for credentials”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C022-T09 · Patch review:** Review the “Secret exclusion” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C022-T10 · Delivery handoff:** Publish the “Secret exclusion” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Untrusted builds cannot read operator secrets. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C023-T01 · Named property:** Create a stable property/check name under this parent for “Secret exclusion”; copy its required invariant exactly: “Untrusted builds cannot read operator secrets”.
- [ ] **UC-M04.03-C023-T02 · Observable terms:** Define each term in the “Secret exclusion” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C023-T03 · Precondition set:** List the preconditions under which “Untrusted builds cannot read operator secrets” must hold for “Secret exclusion”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C023-T04 · Transition coverage:** Map the “Secret exclusion” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Secret exclusion”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C023-T06 · Satisfying fixture:** Create a concrete “Secret exclusion” case that satisfies “Untrusted builds cannot read operator secrets”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C023-T07 · Violating fixture:** Create the source counterexample “A hostile hook searches inherited environment variables for credentials” for “Secret exclusion”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C023-T08 · Enforcement evidence:** Exercise the “Secret exclusion” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C023-T09 · Regression linkage:** Link the “Secret exclusion” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C023-T10 · Property disposition:** Compare the satisfying and violating “Secret exclusion” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C024 · Integration

**Original checklist item:** Integrate secret exclusion with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Secret exclusion” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C024-T02 · Field mapping:** Map every “Secret exclusion” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Secret exclusion” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C024-T04 · Ownership agreement:** Specify who owns “Secret exclusion” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C024-T05 · Handoff implementation:** Connect “Secret exclusion” through the mapped seam using the real adapter or explicit specification reference; preserve “Untrusted builds cannot read operator secrets” across the handoff.
- [ ] **UC-M04.03-C024-T06 · Absent-input case:** Omit one required “Secret exclusion” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C024-T07 · Stale-input case:** Supply an outdated “Secret exclusion” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C024-T08 · Incompatible-input case:** Supply an incompatible “Secret exclusion” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C024-T09 · Valid integration trace:** Run a valid “Secret exclusion” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C024-T10 · Seam review:** Reconcile the “Secret exclusion” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for secret exclusion; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Secret exclusion” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C025-T02 · Expected-result oracle:** Specify the “Secret exclusion” expected result independently of the implementation output; include the property “Untrusted builds cannot read operator secrets” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C025-T03 · Fixture material:** Create the concrete “Secret exclusion” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C025-T04 · Target preparation:** Prepare the “Secret exclusion” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C025-T05 · Initial-state record:** Record the initial “Secret exclusion” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C025-T06 · Valid-path execution:** Execute the “Secret exclusion” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C025-T07 · Outcome comparison:** Compare every declared “Secret exclusion” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C025-T08 · State and bounds check:** Inspect the “Secret exclusion” ownership/state effects and actual use of “Exposed environment bytes and mounted paths”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C025-T09 · Repeatability check:** Repeat the same “Secret exclusion” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C025-T10 · Positive evidence:** Attach the “Secret exclusion” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C026 · Negative test

**Original checklist item:** Negative case: A hostile hook searches inherited environment variables for credentials. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C026-T01 · Adverse-case definition:** Create a test record for the exact “Secret exclusion” source counterexample: “A hostile hook searches inherited environment variables for credentials”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Secret exclusion”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C026-T03 · Valid control:** Construct a valid “Secret exclusion” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C026-T04 · Minimal adverse input:** Derive the “Secret exclusion” adverse fixture from the control with the smallest documented change needed to reproduce “A hostile hook searches inherited environment variables for credentials”; retain that change as reproducible data.
- [ ] **UC-M04.03-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Secret exclusion”; require “Untrusted builds cannot read operator secrets” and forbid a false-success verdict.
- [ ] **UC-M04.03-C026-T06 · Adverse execution:** Exercise the “Secret exclusion” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C026-T07 · Effect inspection:** Inspect “Secret exclusion” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C026-T08 · Refusal versus failure:** Confirm the “Secret exclusion” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C026-T09 · Reset and retention:** Restore only the disposable “Secret exclusion” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C026-T10 · Negative regression:** Register the “Secret exclusion” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C027 · Change / failure test

**Original checklist item:** Exercise secret exclusion when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C027-T01 · Scenario record:** Write the “Secret exclusion” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “Untrusted builds cannot read operator secrets”.
- [ ] **UC-M04.03-C027-T02 · Baseline capture:** Create a known-valid “Secret exclusion” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C027-T03 · Injection map:** Locate the “Secret exclusion” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Secret exclusion” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C027-T05 · Controlled trigger:** Introduce the controlled “Secret exclusion” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C027-T06 · Intermediate inspection:** Inspect the “Secret exclusion” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Secret exclusion”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Secret exclusion” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C027-T09 · Repeat and compare:** Repeat the selected “Secret exclusion” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C027-T10 · Failure evidence:** Publish the “Secret exclusion” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C028 · Bounds

**Original checklist item:** Choose, document and test limits for exposed environment bytes and mounted paths; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C028-T01 · Quantity inventory:** Create a measurement inventory for “Secret exclusion”: “Exposed environment bytes and mounted paths”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C028-T02 · Measurement method:** Choose how to observe each “Secret exclusion” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C028-T03 · Budget decision:** Select justified resource and input limits for “Secret exclusion”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Secret exclusion” cases for “Exposed environment bytes and mounted paths”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Secret exclusion” limit; preserve “Untrusted builds cannot read operator secrets”.
- [ ] **UC-M04.03-C028-T06 · Normal measurement:** Run or review the normal “Secret exclusion” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C028-T07 · At-limit measurement:** Exercise the “Secret exclusion” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C028-T08 · Over-limit measurement:** Exercise the “Secret exclusion” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C028-T09 · Uncovered-scope report:** List the “Secret exclusion” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C028-T10 · Limit evidence:** Publish the selected “Secret exclusion” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for secret exclusion with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C029-T01 · Event inventory:** List the “Secret exclusion” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Secret exclusion” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C029-T03 · Failure mapping:** Map each documented “Secret exclusion” refusal or error to a diagnostic outcome; include “A hostile hook searches inherited environment variables for credentials” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C029-T04 · Emission path:** Add the “Secret exclusion” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C029-T05 · Redaction check:** Test “Secret exclusion” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C029-T06 · Output budget:** Set and exercise bounded “Secret exclusion” message size, rate and retention compatible with “Exposed environment bytes and mounted paths”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C029-T07 · Success/refusal fixtures:** Capture “Secret exclusion” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Secret exclusion” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C029-T09 · Operator review:** Read the “Secret exclusion” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C029-T10 · Diagnostic evidence:** Publish redacted “Secret exclusion” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for secret exclusion; label unexecuted checks as untested.

- [ ] **UC-M04.03-C030-T01 · Evidence inventory:** List the “Secret exclusion” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C030-T02 · Artifact references:** Record the exact “Secret exclusion” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C030-T03 · Fixture references:** Attach the “Secret exclusion” fixture IDs, input identities and oracle definition; preserve the source counterexample “A hostile hook searches inherited environment variables for credentials” as a distinct evidence case.
- [ ] **UC-M04.03-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Secret exclusion”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C030-T05 · Environment record:** Record the actual “Secret exclusion” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C030-T06 · Expected versus observed:** Pair every “Secret exclusion” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C030-T07 · Failure and limit records:** Attach “Secret exclusion” change/failure and bounds evidence where required; include uncovered “Exposed environment bytes and mounted paths” and unresolved violations of “Untrusted builds cannot read operator secrets”.
- [ ] **UC-M04.03-C030-T08 · Evidence hygiene:** Check the “Secret exclusion” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C030-T09 · Reproduction review:** Have the “Secret exclusion” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C030-T10 · Acceptance linkage:** Link the “Secret exclusion” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Network restrictions

**Source delivery:** Apply the selected approved-endpoint or offline policy to build workers.

**Source invariant:** Build tools cannot contact unapproved endpoints.

**Source negative case:** A dependency hook attempts an external network connection.

**Source bounded quantities:** Allowed endpoints and traffic budget.

### UC-M04.03-C031 · Contract

**Original checklist item:** Specify network restrictions inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C031-T01 · Scope statement:** Draft the operation boundary for “Network restrictions” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Network restrictions”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C031-T03 · Output inventory:** List the outputs of “Network restrictions” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Network restrictions”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C031-T05 · Prerequisite contract:** Map “Network restrictions” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C031-T06 · Authority map:** Identify who may produce, change and consume “Network restrictions”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C031-T07 · Invariant clause:** Add a normative clause for “Network restrictions” that preserves “Build tools cannot contact unapproved endpoints”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Network restrictions”; include the source counterexample “A dependency hook attempts an external network connection” and the intended safe disposition.
- [ ] **UC-M04.03-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Allowed endpoints and traffic budget” in the “Network restrictions” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C031-T10 · Contract review:** Review the “Network restrictions” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C032 · Delivery

**Original checklist item:** Apply the selected approved-endpoint or offline policy to build workers.

- [ ] **UC-M04.03-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Network restrictions”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C032-T02 · Change plan:** Break the source delivery for “Network restrictions” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Network restrictions” that realizes this source instruction: Apply the selected approved-endpoint or offline policy to build workers.
- [ ] **UC-M04.03-C032-T04 · Concrete realization:** Trace “Network restrictions” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Network restrictions” needed to preserve “Build tools cannot contact unapproved endpoints”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C032-T06 · Dependency connection:** Connect the “Network restrictions” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C032-T07 · Resource behavior:** Account for “Allowed endpoints and traffic budget” in “Network restrictions”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C032-T08 · Delivery check:** Run the smallest real “Network restrictions” path and its adverse fixture “A dependency hook attempts an external network connection”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C032-T09 · Patch review:** Review the “Network restrictions” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C032-T10 · Delivery handoff:** Publish the “Network restrictions” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Build tools cannot contact unapproved endpoints. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C033-T01 · Named property:** Create a stable property/check name under this parent for “Network restrictions”; copy its required invariant exactly: “Build tools cannot contact unapproved endpoints”.
- [ ] **UC-M04.03-C033-T02 · Observable terms:** Define each term in the “Network restrictions” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C033-T03 · Precondition set:** List the preconditions under which “Build tools cannot contact unapproved endpoints” must hold for “Network restrictions”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C033-T04 · Transition coverage:** Map the “Network restrictions” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Network restrictions”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C033-T06 · Satisfying fixture:** Create a concrete “Network restrictions” case that satisfies “Build tools cannot contact unapproved endpoints”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C033-T07 · Violating fixture:** Create the source counterexample “A dependency hook attempts an external network connection” for “Network restrictions”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C033-T08 · Enforcement evidence:** Exercise the “Network restrictions” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C033-T09 · Regression linkage:** Link the “Network restrictions” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C033-T10 · Property disposition:** Compare the satisfying and violating “Network restrictions” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C034 · Integration

**Original checklist item:** Integrate network restrictions with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Network restrictions” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C034-T02 · Field mapping:** Map every “Network restrictions” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Network restrictions” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C034-T04 · Ownership agreement:** Specify who owns “Network restrictions” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C034-T05 · Handoff implementation:** Connect “Network restrictions” through the mapped seam using the real adapter or explicit specification reference; preserve “Build tools cannot contact unapproved endpoints” across the handoff.
- [ ] **UC-M04.03-C034-T06 · Absent-input case:** Omit one required “Network restrictions” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C034-T07 · Stale-input case:** Supply an outdated “Network restrictions” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C034-T08 · Incompatible-input case:** Supply an incompatible “Network restrictions” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C034-T09 · Valid integration trace:** Run a valid “Network restrictions” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C034-T10 · Seam review:** Reconcile the “Network restrictions” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for network restrictions; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Network restrictions” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C035-T02 · Expected-result oracle:** Specify the “Network restrictions” expected result independently of the implementation output; include the property “Build tools cannot contact unapproved endpoints” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C035-T03 · Fixture material:** Create the concrete “Network restrictions” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C035-T04 · Target preparation:** Prepare the “Network restrictions” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C035-T05 · Initial-state record:** Record the initial “Network restrictions” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C035-T06 · Valid-path execution:** Execute the “Network restrictions” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C035-T07 · Outcome comparison:** Compare every declared “Network restrictions” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C035-T08 · State and bounds check:** Inspect the “Network restrictions” ownership/state effects and actual use of “Allowed endpoints and traffic budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C035-T09 · Repeatability check:** Repeat the same “Network restrictions” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C035-T10 · Positive evidence:** Attach the “Network restrictions” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C036 · Negative test

**Original checklist item:** Negative case: A dependency hook attempts an external network connection. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C036-T01 · Adverse-case definition:** Create a test record for the exact “Network restrictions” source counterexample: “A dependency hook attempts an external network connection”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Network restrictions”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C036-T03 · Valid control:** Construct a valid “Network restrictions” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C036-T04 · Minimal adverse input:** Derive the “Network restrictions” adverse fixture from the control with the smallest documented change needed to reproduce “A dependency hook attempts an external network connection”; retain that change as reproducible data.
- [ ] **UC-M04.03-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Network restrictions”; require “Build tools cannot contact unapproved endpoints” and forbid a false-success verdict.
- [ ] **UC-M04.03-C036-T06 · Adverse execution:** Exercise the “Network restrictions” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C036-T07 · Effect inspection:** Inspect “Network restrictions” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C036-T08 · Refusal versus failure:** Confirm the “Network restrictions” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C036-T09 · Reset and retention:** Restore only the disposable “Network restrictions” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C036-T10 · Negative regression:** Register the “Network restrictions” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C037 · Change / failure test

**Original checklist item:** Exercise network restrictions when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C037-T01 · Scenario record:** Write the “Network restrictions” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “Build tools cannot contact unapproved endpoints”.
- [ ] **UC-M04.03-C037-T02 · Baseline capture:** Create a known-valid “Network restrictions” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C037-T03 · Injection map:** Locate the “Network restrictions” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Network restrictions” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C037-T05 · Controlled trigger:** Introduce the controlled “Network restrictions” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C037-T06 · Intermediate inspection:** Inspect the “Network restrictions” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Network restrictions”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Network restrictions” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C037-T09 · Repeat and compare:** Repeat the selected “Network restrictions” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C037-T10 · Failure evidence:** Publish the “Network restrictions” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C038 · Bounds

**Original checklist item:** Choose, document and test limits for allowed endpoints and traffic budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C038-T01 · Quantity inventory:** Create a measurement inventory for “Network restrictions”: “Allowed endpoints and traffic budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C038-T02 · Measurement method:** Choose how to observe each “Network restrictions” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C038-T03 · Budget decision:** Select justified resource and input limits for “Network restrictions”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Network restrictions” cases for “Allowed endpoints and traffic budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Network restrictions” limit; preserve “Build tools cannot contact unapproved endpoints”.
- [ ] **UC-M04.03-C038-T06 · Normal measurement:** Run or review the normal “Network restrictions” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C038-T07 · At-limit measurement:** Exercise the “Network restrictions” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C038-T08 · Over-limit measurement:** Exercise the “Network restrictions” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C038-T09 · Uncovered-scope report:** List the “Network restrictions” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C038-T10 · Limit evidence:** Publish the selected “Network restrictions” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for network restrictions with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C039-T01 · Event inventory:** List the “Network restrictions” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Network restrictions” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C039-T03 · Failure mapping:** Map each documented “Network restrictions” refusal or error to a diagnostic outcome; include “A dependency hook attempts an external network connection” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C039-T04 · Emission path:** Add the “Network restrictions” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C039-T05 · Redaction check:** Test “Network restrictions” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C039-T06 · Output budget:** Set and exercise bounded “Network restrictions” message size, rate and retention compatible with “Allowed endpoints and traffic budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C039-T07 · Success/refusal fixtures:** Capture “Network restrictions” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Network restrictions” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C039-T09 · Operator review:** Read the “Network restrictions” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C039-T10 · Diagnostic evidence:** Publish redacted “Network restrictions” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for network restrictions; label unexecuted checks as untested.

- [ ] **UC-M04.03-C040-T01 · Evidence inventory:** List the “Network restrictions” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C040-T02 · Artifact references:** Record the exact “Network restrictions” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C040-T03 · Fixture references:** Attach the “Network restrictions” fixture IDs, input identities and oracle definition; preserve the source counterexample “A dependency hook attempts an external network connection” as a distinct evidence case.
- [ ] **UC-M04.03-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Network restrictions”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C040-T05 · Environment record:** Record the actual “Network restrictions” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C040-T06 · Expected versus observed:** Pair every “Network restrictions” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C040-T07 · Failure and limit records:** Attach “Network restrictions” change/failure and bounds evidence where required; include uncovered “Allowed endpoints and traffic budget” and unresolved violations of “Build tools cannot contact unapproved endpoints”.
- [ ] **UC-M04.03-C040-T08 · Evidence hygiene:** Check the “Network restrictions” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C040-T09 · Reproduction review:** Have the “Network restrictions” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C040-T10 · Acceptance linkage:** Link the “Network restrictions” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Read-only input mounts

**Source delivery:** Expose approved input artifacts without granting mutation of shared originals.

**Source invariant:** One build cannot modify another build's dependency inputs.

**Source negative case:** A compiler hook rewrites a shared cached library.

**Source bounded quantities:** Mounted artifacts and open handles.

### UC-M04.03-C041 · Contract

**Original checklist item:** Specify read-only input mounts inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C041-T01 · Scope statement:** Draft the operation boundary for “Read-only input mounts” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Read-only input mounts”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C041-T03 · Output inventory:** List the outputs of “Read-only input mounts” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Read-only input mounts”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C041-T05 · Prerequisite contract:** Map “Read-only input mounts” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C041-T06 · Authority map:** Identify who may produce, change and consume “Read-only input mounts”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C041-T07 · Invariant clause:** Add a normative clause for “Read-only input mounts” that preserves “One build cannot modify another build's dependency inputs”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Read-only input mounts”; include the source counterexample “A compiler hook rewrites a shared cached library” and the intended safe disposition.
- [ ] **UC-M04.03-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Mounted artifacts and open handles” in the “Read-only input mounts” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C041-T10 · Contract review:** Review the “Read-only input mounts” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C042 · Delivery

**Original checklist item:** Expose approved input artifacts without granting mutation of shared originals.

- [ ] **UC-M04.03-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Read-only input mounts”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C042-T02 · Change plan:** Break the source delivery for “Read-only input mounts” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Read-only input mounts” that realizes this source instruction: Expose approved input artifacts without granting mutation of shared originals.
- [ ] **UC-M04.03-C042-T04 · Concrete realization:** Trace “Read-only input mounts” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Read-only input mounts” needed to preserve “One build cannot modify another build's dependency inputs”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C042-T06 · Dependency connection:** Connect the “Read-only input mounts” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C042-T07 · Resource behavior:** Account for “Mounted artifacts and open handles” in “Read-only input mounts”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C042-T08 · Delivery check:** Run the smallest real “Read-only input mounts” path and its adverse fixture “A compiler hook rewrites a shared cached library”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C042-T09 · Patch review:** Review the “Read-only input mounts” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C042-T10 · Delivery handoff:** Publish the “Read-only input mounts” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One build cannot modify another build's dependency inputs. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C043-T01 · Named property:** Create a stable property/check name under this parent for “Read-only input mounts”; copy its required invariant exactly: “One build cannot modify another build's dependency inputs”.
- [ ] **UC-M04.03-C043-T02 · Observable terms:** Define each term in the “Read-only input mounts” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C043-T03 · Precondition set:** List the preconditions under which “One build cannot modify another build's dependency inputs” must hold for “Read-only input mounts”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C043-T04 · Transition coverage:** Map the “Read-only input mounts” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Read-only input mounts”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C043-T06 · Satisfying fixture:** Create a concrete “Read-only input mounts” case that satisfies “One build cannot modify another build's dependency inputs”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C043-T07 · Violating fixture:** Create the source counterexample “A compiler hook rewrites a shared cached library” for “Read-only input mounts”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C043-T08 · Enforcement evidence:** Exercise the “Read-only input mounts” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C043-T09 · Regression linkage:** Link the “Read-only input mounts” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C043-T10 · Property disposition:** Compare the satisfying and violating “Read-only input mounts” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C044 · Integration

**Original checklist item:** Integrate read-only input mounts with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Read-only input mounts” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C044-T02 · Field mapping:** Map every “Read-only input mounts” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Read-only input mounts” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C044-T04 · Ownership agreement:** Specify who owns “Read-only input mounts” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C044-T05 · Handoff implementation:** Connect “Read-only input mounts” through the mapped seam using the real adapter or explicit specification reference; preserve “One build cannot modify another build's dependency inputs” across the handoff.
- [ ] **UC-M04.03-C044-T06 · Absent-input case:** Omit one required “Read-only input mounts” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C044-T07 · Stale-input case:** Supply an outdated “Read-only input mounts” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C044-T08 · Incompatible-input case:** Supply an incompatible “Read-only input mounts” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C044-T09 · Valid integration trace:** Run a valid “Read-only input mounts” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C044-T10 · Seam review:** Reconcile the “Read-only input mounts” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for read-only input mounts; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Read-only input mounts” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C045-T02 · Expected-result oracle:** Specify the “Read-only input mounts” expected result independently of the implementation output; include the property “One build cannot modify another build's dependency inputs” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C045-T03 · Fixture material:** Create the concrete “Read-only input mounts” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C045-T04 · Target preparation:** Prepare the “Read-only input mounts” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C045-T05 · Initial-state record:** Record the initial “Read-only input mounts” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C045-T06 · Valid-path execution:** Execute the “Read-only input mounts” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C045-T07 · Outcome comparison:** Compare every declared “Read-only input mounts” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C045-T08 · State and bounds check:** Inspect the “Read-only input mounts” ownership/state effects and actual use of “Mounted artifacts and open handles”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C045-T09 · Repeatability check:** Repeat the same “Read-only input mounts” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C045-T10 · Positive evidence:** Attach the “Read-only input mounts” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C046 · Negative test

**Original checklist item:** Negative case: A compiler hook rewrites a shared cached library. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C046-T01 · Adverse-case definition:** Create a test record for the exact “Read-only input mounts” source counterexample: “A compiler hook rewrites a shared cached library”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Read-only input mounts”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C046-T03 · Valid control:** Construct a valid “Read-only input mounts” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C046-T04 · Minimal adverse input:** Derive the “Read-only input mounts” adverse fixture from the control with the smallest documented change needed to reproduce “A compiler hook rewrites a shared cached library”; retain that change as reproducible data.
- [ ] **UC-M04.03-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Read-only input mounts”; require “One build cannot modify another build's dependency inputs” and forbid a false-success verdict.
- [ ] **UC-M04.03-C046-T06 · Adverse execution:** Exercise the “Read-only input mounts” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C046-T07 · Effect inspection:** Inspect “Read-only input mounts” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C046-T08 · Refusal versus failure:** Confirm the “Read-only input mounts” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C046-T09 · Reset and retention:** Restore only the disposable “Read-only input mounts” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C046-T10 · Negative regression:** Register the “Read-only input mounts” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C047 · Change / failure test

**Original checklist item:** Exercise read-only input mounts when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C047-T01 · Scenario record:** Write the “Read-only input mounts” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “One build cannot modify another build's dependency inputs”.
- [ ] **UC-M04.03-C047-T02 · Baseline capture:** Create a known-valid “Read-only input mounts” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C047-T03 · Injection map:** Locate the “Read-only input mounts” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Read-only input mounts” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C047-T05 · Controlled trigger:** Introduce the controlled “Read-only input mounts” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C047-T06 · Intermediate inspection:** Inspect the “Read-only input mounts” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Read-only input mounts”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Read-only input mounts” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C047-T09 · Repeat and compare:** Repeat the selected “Read-only input mounts” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C047-T10 · Failure evidence:** Publish the “Read-only input mounts” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C048 · Bounds

**Original checklist item:** Choose, document and test limits for mounted artifacts and open handles; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C048-T01 · Quantity inventory:** Create a measurement inventory for “Read-only input mounts”: “Mounted artifacts and open handles”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C048-T02 · Measurement method:** Choose how to observe each “Read-only input mounts” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C048-T03 · Budget decision:** Select justified resource and input limits for “Read-only input mounts”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Read-only input mounts” cases for “Mounted artifacts and open handles”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Read-only input mounts” limit; preserve “One build cannot modify another build's dependency inputs”.
- [ ] **UC-M04.03-C048-T06 · Normal measurement:** Run or review the normal “Read-only input mounts” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C048-T07 · At-limit measurement:** Exercise the “Read-only input mounts” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C048-T08 · Over-limit measurement:** Exercise the “Read-only input mounts” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C048-T09 · Uncovered-scope report:** List the “Read-only input mounts” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C048-T10 · Limit evidence:** Publish the selected “Read-only input mounts” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for read-only input mounts with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C049-T01 · Event inventory:** List the “Read-only input mounts” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Read-only input mounts” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C049-T03 · Failure mapping:** Map each documented “Read-only input mounts” refusal or error to a diagnostic outcome; include “A compiler hook rewrites a shared cached library” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C049-T04 · Emission path:** Add the “Read-only input mounts” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C049-T05 · Redaction check:** Test “Read-only input mounts” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C049-T06 · Output budget:** Set and exercise bounded “Read-only input mounts” message size, rate and retention compatible with “Mounted artifacts and open handles”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C049-T07 · Success/refusal fixtures:** Capture “Read-only input mounts” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Read-only input mounts” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C049-T09 · Operator review:** Read the “Read-only input mounts” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C049-T10 · Diagnostic evidence:** Publish redacted “Read-only input mounts” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for read-only input mounts; label unexecuted checks as untested.

- [ ] **UC-M04.03-C050-T01 · Evidence inventory:** List the “Read-only input mounts” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C050-T02 · Artifact references:** Record the exact “Read-only input mounts” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C050-T03 · Fixture references:** Attach the “Read-only input mounts” fixture IDs, input identities and oracle definition; preserve the source counterexample “A compiler hook rewrites a shared cached library” as a distinct evidence case.
- [ ] **UC-M04.03-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Read-only input mounts”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C050-T05 · Environment record:** Record the actual “Read-only input mounts” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C050-T06 · Expected versus observed:** Pair every “Read-only input mounts” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C050-T07 · Failure and limit records:** Attach “Read-only input mounts” change/failure and bounds evidence where required; include uncovered “Mounted artifacts and open handles” and unresolved violations of “One build cannot modify another build's dependency inputs”.
- [ ] **UC-M04.03-C050-T08 · Evidence hygiene:** Check the “Read-only input mounts” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C050-T09 · Reproduction review:** Have the “Read-only input mounts” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C050-T10 · Acceptance linkage:** Link the “Read-only input mounts” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Build resource quotas

**Source delivery:** Apply CPU, memory, I/O, process and log limits to the whole build tree.

**Source invariant:** Compiler descendants remain inside the build budget.

**Source negative case:** A hook spawns children outside its quota group.

**Source bounded quantities:** Aggregate memory, processes and I/O.

### UC-M04.03-C051 · Contract

**Original checklist item:** Specify build resource quotas inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C051-T01 · Scope statement:** Draft the operation boundary for “Build resource quotas” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Build resource quotas”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C051-T03 · Output inventory:** List the outputs of “Build resource quotas” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Build resource quotas”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C051-T05 · Prerequisite contract:** Map “Build resource quotas” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C051-T06 · Authority map:** Identify who may produce, change and consume “Build resource quotas”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C051-T07 · Invariant clause:** Add a normative clause for “Build resource quotas” that preserves “Compiler descendants remain inside the build budget”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Build resource quotas”; include the source counterexample “A hook spawns children outside its quota group” and the intended safe disposition.
- [ ] **UC-M04.03-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Aggregate memory, processes and I/O” in the “Build resource quotas” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C051-T10 · Contract review:** Review the “Build resource quotas” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C052 · Delivery

**Original checklist item:** Apply CPU, memory, I/O, process and log limits to the whole build tree.

- [ ] **UC-M04.03-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Build resource quotas”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C052-T02 · Change plan:** Break the source delivery for “Build resource quotas” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Build resource quotas” that realizes this source instruction: Apply CPU, memory, I/O, process and log limits to the whole build tree.
- [ ] **UC-M04.03-C052-T04 · Concrete realization:** Trace “Build resource quotas” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Build resource quotas” needed to preserve “Compiler descendants remain inside the build budget”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C052-T06 · Dependency connection:** Connect the “Build resource quotas” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C052-T07 · Resource behavior:** Account for “Aggregate memory, processes and I/O” in “Build resource quotas”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C052-T08 · Delivery check:** Run the smallest real “Build resource quotas” path and its adverse fixture “A hook spawns children outside its quota group”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C052-T09 · Patch review:** Review the “Build resource quotas” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C052-T10 · Delivery handoff:** Publish the “Build resource quotas” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Compiler descendants remain inside the build budget. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C053-T01 · Named property:** Create a stable property/check name under this parent for “Build resource quotas”; copy its required invariant exactly: “Compiler descendants remain inside the build budget”.
- [ ] **UC-M04.03-C053-T02 · Observable terms:** Define each term in the “Build resource quotas” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C053-T03 · Precondition set:** List the preconditions under which “Compiler descendants remain inside the build budget” must hold for “Build resource quotas”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C053-T04 · Transition coverage:** Map the “Build resource quotas” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Build resource quotas”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C053-T06 · Satisfying fixture:** Create a concrete “Build resource quotas” case that satisfies “Compiler descendants remain inside the build budget”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C053-T07 · Violating fixture:** Create the source counterexample “A hook spawns children outside its quota group” for “Build resource quotas”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C053-T08 · Enforcement evidence:** Exercise the “Build resource quotas” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C053-T09 · Regression linkage:** Link the “Build resource quotas” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C053-T10 · Property disposition:** Compare the satisfying and violating “Build resource quotas” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C054 · Integration

**Original checklist item:** Integrate build resource quotas with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Build resource quotas” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C054-T02 · Field mapping:** Map every “Build resource quotas” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Build resource quotas” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C054-T04 · Ownership agreement:** Specify who owns “Build resource quotas” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C054-T05 · Handoff implementation:** Connect “Build resource quotas” through the mapped seam using the real adapter or explicit specification reference; preserve “Compiler descendants remain inside the build budget” across the handoff.
- [ ] **UC-M04.03-C054-T06 · Absent-input case:** Omit one required “Build resource quotas” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C054-T07 · Stale-input case:** Supply an outdated “Build resource quotas” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C054-T08 · Incompatible-input case:** Supply an incompatible “Build resource quotas” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C054-T09 · Valid integration trace:** Run a valid “Build resource quotas” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C054-T10 · Seam review:** Reconcile the “Build resource quotas” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for build resource quotas; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Build resource quotas” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C055-T02 · Expected-result oracle:** Specify the “Build resource quotas” expected result independently of the implementation output; include the property “Compiler descendants remain inside the build budget” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C055-T03 · Fixture material:** Create the concrete “Build resource quotas” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C055-T04 · Target preparation:** Prepare the “Build resource quotas” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C055-T05 · Initial-state record:** Record the initial “Build resource quotas” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C055-T06 · Valid-path execution:** Execute the “Build resource quotas” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C055-T07 · Outcome comparison:** Compare every declared “Build resource quotas” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C055-T08 · State and bounds check:** Inspect the “Build resource quotas” ownership/state effects and actual use of “Aggregate memory, processes and I/O”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C055-T09 · Repeatability check:** Repeat the same “Build resource quotas” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C055-T10 · Positive evidence:** Attach the “Build resource quotas” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C056 · Negative test

**Original checklist item:** Negative case: A hook spawns children outside its quota group. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C056-T01 · Adverse-case definition:** Create a test record for the exact “Build resource quotas” source counterexample: “A hook spawns children outside its quota group”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Build resource quotas”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C056-T03 · Valid control:** Construct a valid “Build resource quotas” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C056-T04 · Minimal adverse input:** Derive the “Build resource quotas” adverse fixture from the control with the smallest documented change needed to reproduce “A hook spawns children outside its quota group”; retain that change as reproducible data.
- [ ] **UC-M04.03-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Build resource quotas”; require “Compiler descendants remain inside the build budget” and forbid a false-success verdict.
- [ ] **UC-M04.03-C056-T06 · Adverse execution:** Exercise the “Build resource quotas” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C056-T07 · Effect inspection:** Inspect “Build resource quotas” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C056-T08 · Refusal versus failure:** Confirm the “Build resource quotas” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C056-T09 · Reset and retention:** Restore only the disposable “Build resource quotas” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C056-T10 · Negative regression:** Register the “Build resource quotas” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C057 · Change / failure test

**Original checklist item:** Exercise build resource quotas when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C057-T01 · Scenario record:** Write the “Build resource quotas” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “Compiler descendants remain inside the build budget”.
- [ ] **UC-M04.03-C057-T02 · Baseline capture:** Create a known-valid “Build resource quotas” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C057-T03 · Injection map:** Locate the “Build resource quotas” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Build resource quotas” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C057-T05 · Controlled trigger:** Introduce the controlled “Build resource quotas” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C057-T06 · Intermediate inspection:** Inspect the “Build resource quotas” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Build resource quotas”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Build resource quotas” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C057-T09 · Repeat and compare:** Repeat the selected “Build resource quotas” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C057-T10 · Failure evidence:** Publish the “Build resource quotas” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C058 · Bounds

**Original checklist item:** Choose, document and test limits for aggregate memory, processes and I/O; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C058-T01 · Quantity inventory:** Create a measurement inventory for “Build resource quotas”: “Aggregate memory, processes and I/O”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C058-T02 · Measurement method:** Choose how to observe each “Build resource quotas” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C058-T03 · Budget decision:** Select justified resource and input limits for “Build resource quotas”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Build resource quotas” cases for “Aggregate memory, processes and I/O”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Build resource quotas” limit; preserve “Compiler descendants remain inside the build budget”.
- [ ] **UC-M04.03-C058-T06 · Normal measurement:** Run or review the normal “Build resource quotas” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C058-T07 · At-limit measurement:** Exercise the “Build resource quotas” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C058-T08 · Over-limit measurement:** Exercise the “Build resource quotas” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C058-T09 · Uncovered-scope report:** List the “Build resource quotas” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C058-T10 · Limit evidence:** Publish the selected “Build resource quotas” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for build resource quotas with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C059-T01 · Event inventory:** List the “Build resource quotas” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Build resource quotas” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C059-T03 · Failure mapping:** Map each documented “Build resource quotas” refusal or error to a diagnostic outcome; include “A hook spawns children outside its quota group” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C059-T04 · Emission path:** Add the “Build resource quotas” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C059-T05 · Redaction check:** Test “Build resource quotas” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C059-T06 · Output budget:** Set and exercise bounded “Build resource quotas” message size, rate and retention compatible with “Aggregate memory, processes and I/O”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C059-T07 · Success/refusal fixtures:** Capture “Build resource quotas” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Build resource quotas” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C059-T09 · Operator review:** Read the “Build resource quotas” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C059-T10 · Diagnostic evidence:** Publish redacted “Build resource quotas” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for build resource quotas; label unexecuted checks as untested.

- [ ] **UC-M04.03-C060-T01 · Evidence inventory:** List the “Build resource quotas” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C060-T02 · Artifact references:** Record the exact “Build resource quotas” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C060-T03 · Fixture references:** Attach the “Build resource quotas” fixture IDs, input identities and oracle definition; preserve the source counterexample “A hook spawns children outside its quota group” as a distinct evidence case.
- [ ] **UC-M04.03-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Build resource quotas”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C060-T05 · Environment record:** Record the actual “Build resource quotas” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C060-T06 · Expected versus observed:** Pair every “Build resource quotas” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C060-T07 · Failure and limit records:** Attach “Build resource quotas” change/failure and bounds evidence where required; include uncovered “Aggregate memory, processes and I/O” and unresolved violations of “Compiler descendants remain inside the build budget”.
- [ ] **UC-M04.03-C060-T08 · Evidence hygiene:** Check the “Build resource quotas” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C060-T09 · Reproduction review:** Have the “Build resource quotas” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C060-T10 · Acceptance linkage:** Link the “Build resource quotas” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Output admission

**Source delivery:** Validate declared build outputs before moving them into trusted stores.

**Source invariant:** A successful compiler exit does not automatically trust every produced file.

**Source negative case:** A build output contains an unexpected executable or unsafe path.

**Source bounded quantities:** Output count and total bytes.

### UC-M04.03-C061 · Contract

**Original checklist item:** Specify output admission inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C061-T01 · Scope statement:** Draft the operation boundary for “Output admission” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Output admission”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C061-T03 · Output inventory:** List the outputs of “Output admission” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Output admission”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C061-T05 · Prerequisite contract:** Map “Output admission” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C061-T06 · Authority map:** Identify who may produce, change and consume “Output admission”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C061-T07 · Invariant clause:** Add a normative clause for “Output admission” that preserves “A successful compiler exit does not automatically trust every produced file”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Output admission”; include the source counterexample “A build output contains an unexpected executable or unsafe path” and the intended safe disposition.
- [ ] **UC-M04.03-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Output count and total bytes” in the “Output admission” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C061-T10 · Contract review:** Review the “Output admission” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C062 · Delivery

**Original checklist item:** Validate declared build outputs before moving them into trusted stores.

- [ ] **UC-M04.03-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Output admission”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C062-T02 · Change plan:** Break the source delivery for “Output admission” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Output admission” that realizes this source instruction: Validate declared build outputs before moving them into trusted stores.
- [ ] **UC-M04.03-C062-T04 · Concrete realization:** Trace “Output admission” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Output admission” needed to preserve “A successful compiler exit does not automatically trust every produced file”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C062-T06 · Dependency connection:** Connect the “Output admission” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C062-T07 · Resource behavior:** Account for “Output count and total bytes” in “Output admission”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C062-T08 · Delivery check:** Run the smallest real “Output admission” path and its adverse fixture “A build output contains an unexpected executable or unsafe path”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C062-T09 · Patch review:** Review the “Output admission” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C062-T10 · Delivery handoff:** Publish the “Output admission” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A successful compiler exit does not automatically trust every produced file. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C063-T01 · Named property:** Create a stable property/check name under this parent for “Output admission”; copy its required invariant exactly: “A successful compiler exit does not automatically trust every produced file”.
- [ ] **UC-M04.03-C063-T02 · Observable terms:** Define each term in the “Output admission” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C063-T03 · Precondition set:** List the preconditions under which “A successful compiler exit does not automatically trust every produced file” must hold for “Output admission”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C063-T04 · Transition coverage:** Map the “Output admission” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Output admission”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C063-T06 · Satisfying fixture:** Create a concrete “Output admission” case that satisfies “A successful compiler exit does not automatically trust every produced file”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C063-T07 · Violating fixture:** Create the source counterexample “A build output contains an unexpected executable or unsafe path” for “Output admission”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C063-T08 · Enforcement evidence:** Exercise the “Output admission” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C063-T09 · Regression linkage:** Link the “Output admission” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C063-T10 · Property disposition:** Compare the satisfying and violating “Output admission” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C064 · Integration

**Original checklist item:** Integrate output admission with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Output admission” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C064-T02 · Field mapping:** Map every “Output admission” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Output admission” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C064-T04 · Ownership agreement:** Specify who owns “Output admission” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C064-T05 · Handoff implementation:** Connect “Output admission” through the mapped seam using the real adapter or explicit specification reference; preserve “A successful compiler exit does not automatically trust every produced file” across the handoff.
- [ ] **UC-M04.03-C064-T06 · Absent-input case:** Omit one required “Output admission” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C064-T07 · Stale-input case:** Supply an outdated “Output admission” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C064-T08 · Incompatible-input case:** Supply an incompatible “Output admission” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C064-T09 · Valid integration trace:** Run a valid “Output admission” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C064-T10 · Seam review:** Reconcile the “Output admission” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for output admission; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Output admission” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C065-T02 · Expected-result oracle:** Specify the “Output admission” expected result independently of the implementation output; include the property “A successful compiler exit does not automatically trust every produced file” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C065-T03 · Fixture material:** Create the concrete “Output admission” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C065-T04 · Target preparation:** Prepare the “Output admission” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C065-T05 · Initial-state record:** Record the initial “Output admission” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C065-T06 · Valid-path execution:** Execute the “Output admission” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C065-T07 · Outcome comparison:** Compare every declared “Output admission” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C065-T08 · State and bounds check:** Inspect the “Output admission” ownership/state effects and actual use of “Output count and total bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C065-T09 · Repeatability check:** Repeat the same “Output admission” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C065-T10 · Positive evidence:** Attach the “Output admission” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C066 · Negative test

**Original checklist item:** Negative case: A build output contains an unexpected executable or unsafe path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C066-T01 · Adverse-case definition:** Create a test record for the exact “Output admission” source counterexample: “A build output contains an unexpected executable or unsafe path”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Output admission”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C066-T03 · Valid control:** Construct a valid “Output admission” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C066-T04 · Minimal adverse input:** Derive the “Output admission” adverse fixture from the control with the smallest documented change needed to reproduce “A build output contains an unexpected executable or unsafe path”; retain that change as reproducible data.
- [ ] **UC-M04.03-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Output admission”; require “A successful compiler exit does not automatically trust every produced file” and forbid a false-success verdict.
- [ ] **UC-M04.03-C066-T06 · Adverse execution:** Exercise the “Output admission” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C066-T07 · Effect inspection:** Inspect “Output admission” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C066-T08 · Refusal versus failure:** Confirm the “Output admission” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C066-T09 · Reset and retention:** Restore only the disposable “Output admission” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C066-T10 · Negative regression:** Register the “Output admission” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C067 · Change / failure test

**Original checklist item:** Exercise output admission when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C067-T01 · Scenario record:** Write the “Output admission” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “A successful compiler exit does not automatically trust every produced file”.
- [ ] **UC-M04.03-C067-T02 · Baseline capture:** Create a known-valid “Output admission” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C067-T03 · Injection map:** Locate the “Output admission” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Output admission” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C067-T05 · Controlled trigger:** Introduce the controlled “Output admission” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C067-T06 · Intermediate inspection:** Inspect the “Output admission” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Output admission”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Output admission” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C067-T09 · Repeat and compare:** Repeat the selected “Output admission” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C067-T10 · Failure evidence:** Publish the “Output admission” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C068 · Bounds

**Original checklist item:** Choose, document and test limits for output count and total bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C068-T01 · Quantity inventory:** Create a measurement inventory for “Output admission”: “Output count and total bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C068-T02 · Measurement method:** Choose how to observe each “Output admission” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C068-T03 · Budget decision:** Select justified resource and input limits for “Output admission”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Output admission” cases for “Output count and total bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Output admission” limit; preserve “A successful compiler exit does not automatically trust every produced file”.
- [ ] **UC-M04.03-C068-T06 · Normal measurement:** Run or review the normal “Output admission” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C068-T07 · At-limit measurement:** Exercise the “Output admission” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C068-T08 · Over-limit measurement:** Exercise the “Output admission” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C068-T09 · Uncovered-scope report:** List the “Output admission” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C068-T10 · Limit evidence:** Publish the selected “Output admission” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for output admission with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C069-T01 · Event inventory:** List the “Output admission” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Output admission” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C069-T03 · Failure mapping:** Map each documented “Output admission” refusal or error to a diagnostic outcome; include “A build output contains an unexpected executable or unsafe path” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C069-T04 · Emission path:** Add the “Output admission” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C069-T05 · Redaction check:** Test “Output admission” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C069-T06 · Output budget:** Set and exercise bounded “Output admission” message size, rate and retention compatible with “Output count and total bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C069-T07 · Success/refusal fixtures:** Capture “Output admission” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Output admission” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C069-T09 · Operator review:** Read the “Output admission” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C069-T10 · Diagnostic evidence:** Publish redacted “Output admission” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for output admission; label unexecuted checks as untested.

- [ ] **UC-M04.03-C070-T01 · Evidence inventory:** List the “Output admission” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C070-T02 · Artifact references:** Record the exact “Output admission” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C070-T03 · Fixture references:** Attach the “Output admission” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build output contains an unexpected executable or unsafe path” as a distinct evidence case.
- [ ] **UC-M04.03-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Output admission”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C070-T05 · Environment record:** Record the actual “Output admission” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C070-T06 · Expected versus observed:** Pair every “Output admission” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C070-T07 · Failure and limit records:** Attach “Output admission” change/failure and bounds evidence where required; include uncovered “Output count and total bytes” and unresolved violations of “A successful compiler exit does not automatically trust every produced file”.
- [ ] **UC-M04.03-C070-T08 · Evidence hygiene:** Check the “Output admission” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C070-T09 · Reproduction review:** Have the “Output admission” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C070-T10 · Acceptance linkage:** Link the “Output admission” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Cancellation and timeout

**Source delivery:** Terminate the full build tree when canceled or timed out.

**Source invariant:** Canceled builds cannot continue writing shared outputs.

**Source negative case:** A grandchild compiler survives its canceled parent.

**Source bounded quantities:** Build deadline and cleanup time.

### UC-M04.03-C071 · Contract

**Original checklist item:** Specify cancellation and timeout inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C071-T01 · Scope statement:** Draft the operation boundary for “Cancellation and timeout” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cancellation and timeout”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C071-T03 · Output inventory:** List the outputs of “Cancellation and timeout” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Cancellation and timeout”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C071-T05 · Prerequisite contract:** Map “Cancellation and timeout” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C071-T06 · Authority map:** Identify who may produce, change and consume “Cancellation and timeout”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C071-T07 · Invariant clause:** Add a normative clause for “Cancellation and timeout” that preserves “Canceled builds cannot continue writing shared outputs”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cancellation and timeout”; include the source counterexample “A grandchild compiler survives its canceled parent” and the intended safe disposition.
- [ ] **UC-M04.03-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Build deadline and cleanup time” in the “Cancellation and timeout” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C071-T10 · Contract review:** Review the “Cancellation and timeout” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C072 · Delivery

**Original checklist item:** Terminate the full build tree when canceled or timed out.

- [ ] **UC-M04.03-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cancellation and timeout”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C072-T02 · Change plan:** Break the source delivery for “Cancellation and timeout” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Cancellation and timeout” that realizes this source instruction: Terminate the full build tree when canceled or timed out.
- [ ] **UC-M04.03-C072-T04 · Concrete realization:** Trace “Cancellation and timeout” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cancellation and timeout” needed to preserve “Canceled builds cannot continue writing shared outputs”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C072-T06 · Dependency connection:** Connect the “Cancellation and timeout” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C072-T07 · Resource behavior:** Account for “Build deadline and cleanup time” in “Cancellation and timeout”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C072-T08 · Delivery check:** Run the smallest real “Cancellation and timeout” path and its adverse fixture “A grandchild compiler survives its canceled parent”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C072-T09 · Patch review:** Review the “Cancellation and timeout” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C072-T10 · Delivery handoff:** Publish the “Cancellation and timeout” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Canceled builds cannot continue writing shared outputs. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C073-T01 · Named property:** Create a stable property/check name under this parent for “Cancellation and timeout”; copy its required invariant exactly: “Canceled builds cannot continue writing shared outputs”.
- [ ] **UC-M04.03-C073-T02 · Observable terms:** Define each term in the “Cancellation and timeout” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C073-T03 · Precondition set:** List the preconditions under which “Canceled builds cannot continue writing shared outputs” must hold for “Cancellation and timeout”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C073-T04 · Transition coverage:** Map the “Cancellation and timeout” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cancellation and timeout”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C073-T06 · Satisfying fixture:** Create a concrete “Cancellation and timeout” case that satisfies “Canceled builds cannot continue writing shared outputs”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C073-T07 · Violating fixture:** Create the source counterexample “A grandchild compiler survives its canceled parent” for “Cancellation and timeout”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C073-T08 · Enforcement evidence:** Exercise the “Cancellation and timeout” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C073-T09 · Regression linkage:** Link the “Cancellation and timeout” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C073-T10 · Property disposition:** Compare the satisfying and violating “Cancellation and timeout” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C074 · Integration

**Original checklist item:** Integrate cancellation and timeout with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cancellation and timeout” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C074-T02 · Field mapping:** Map every “Cancellation and timeout” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Cancellation and timeout” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C074-T04 · Ownership agreement:** Specify who owns “Cancellation and timeout” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C074-T05 · Handoff implementation:** Connect “Cancellation and timeout” through the mapped seam using the real adapter or explicit specification reference; preserve “Canceled builds cannot continue writing shared outputs” across the handoff.
- [ ] **UC-M04.03-C074-T06 · Absent-input case:** Omit one required “Cancellation and timeout” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C074-T07 · Stale-input case:** Supply an outdated “Cancellation and timeout” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C074-T08 · Incompatible-input case:** Supply an incompatible “Cancellation and timeout” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C074-T09 · Valid integration trace:** Run a valid “Cancellation and timeout” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C074-T10 · Seam review:** Reconcile the “Cancellation and timeout” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cancellation and timeout; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cancellation and timeout” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C075-T02 · Expected-result oracle:** Specify the “Cancellation and timeout” expected result independently of the implementation output; include the property “Canceled builds cannot continue writing shared outputs” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C075-T03 · Fixture material:** Create the concrete “Cancellation and timeout” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C075-T04 · Target preparation:** Prepare the “Cancellation and timeout” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C075-T05 · Initial-state record:** Record the initial “Cancellation and timeout” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C075-T06 · Valid-path execution:** Execute the “Cancellation and timeout” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C075-T07 · Outcome comparison:** Compare every declared “Cancellation and timeout” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C075-T08 · State and bounds check:** Inspect the “Cancellation and timeout” ownership/state effects and actual use of “Build deadline and cleanup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C075-T09 · Repeatability check:** Repeat the same “Cancellation and timeout” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C075-T10 · Positive evidence:** Attach the “Cancellation and timeout” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C076 · Negative test

**Original checklist item:** Negative case: A grandchild compiler survives its canceled parent. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C076-T01 · Adverse-case definition:** Create a test record for the exact “Cancellation and timeout” source counterexample: “A grandchild compiler survives its canceled parent”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Cancellation and timeout”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C076-T03 · Valid control:** Construct a valid “Cancellation and timeout” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C076-T04 · Minimal adverse input:** Derive the “Cancellation and timeout” adverse fixture from the control with the smallest documented change needed to reproduce “A grandchild compiler survives its canceled parent”; retain that change as reproducible data.
- [ ] **UC-M04.03-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cancellation and timeout”; require “Canceled builds cannot continue writing shared outputs” and forbid a false-success verdict.
- [ ] **UC-M04.03-C076-T06 · Adverse execution:** Exercise the “Cancellation and timeout” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C076-T07 · Effect inspection:** Inspect “Cancellation and timeout” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C076-T08 · Refusal versus failure:** Confirm the “Cancellation and timeout” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C076-T09 · Reset and retention:** Restore only the disposable “Cancellation and timeout” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C076-T10 · Negative regression:** Register the “Cancellation and timeout” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C077 · Change / failure test

**Original checklist item:** Exercise cancellation and timeout when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C077-T01 · Scenario record:** Write the “Cancellation and timeout” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “Canceled builds cannot continue writing shared outputs”.
- [ ] **UC-M04.03-C077-T02 · Baseline capture:** Create a known-valid “Cancellation and timeout” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C077-T03 · Injection map:** Locate the “Cancellation and timeout” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Cancellation and timeout” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C077-T05 · Controlled trigger:** Introduce the controlled “Cancellation and timeout” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C077-T06 · Intermediate inspection:** Inspect the “Cancellation and timeout” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cancellation and timeout”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Cancellation and timeout” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C077-T09 · Repeat and compare:** Repeat the selected “Cancellation and timeout” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C077-T10 · Failure evidence:** Publish the “Cancellation and timeout” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C078 · Bounds

**Original checklist item:** Choose, document and test limits for build deadline and cleanup time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C078-T01 · Quantity inventory:** Create a measurement inventory for “Cancellation and timeout”: “Build deadline and cleanup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C078-T02 · Measurement method:** Choose how to observe each “Cancellation and timeout” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C078-T03 · Budget decision:** Select justified resource and input limits for “Cancellation and timeout”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cancellation and timeout” cases for “Build deadline and cleanup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cancellation and timeout” limit; preserve “Canceled builds cannot continue writing shared outputs”.
- [ ] **UC-M04.03-C078-T06 · Normal measurement:** Run or review the normal “Cancellation and timeout” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C078-T07 · At-limit measurement:** Exercise the “Cancellation and timeout” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C078-T08 · Over-limit measurement:** Exercise the “Cancellation and timeout” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C078-T09 · Uncovered-scope report:** List the “Cancellation and timeout” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C078-T10 · Limit evidence:** Publish the selected “Cancellation and timeout” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cancellation and timeout with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C079-T01 · Event inventory:** List the “Cancellation and timeout” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Cancellation and timeout” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C079-T03 · Failure mapping:** Map each documented “Cancellation and timeout” refusal or error to a diagnostic outcome; include “A grandchild compiler survives its canceled parent” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C079-T04 · Emission path:** Add the “Cancellation and timeout” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C079-T05 · Redaction check:** Test “Cancellation and timeout” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C079-T06 · Output budget:** Set and exercise bounded “Cancellation and timeout” message size, rate and retention compatible with “Build deadline and cleanup time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C079-T07 · Success/refusal fixtures:** Capture “Cancellation and timeout” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cancellation and timeout” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C079-T09 · Operator review:** Read the “Cancellation and timeout” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C079-T10 · Diagnostic evidence:** Publish redacted “Cancellation and timeout” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cancellation and timeout; label unexecuted checks as untested.

- [ ] **UC-M04.03-C080-T01 · Evidence inventory:** List the “Cancellation and timeout” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C080-T02 · Artifact references:** Record the exact “Cancellation and timeout” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C080-T03 · Fixture references:** Attach the “Cancellation and timeout” fixture IDs, input identities and oracle definition; preserve the source counterexample “A grandchild compiler survives its canceled parent” as a distinct evidence case.
- [ ] **UC-M04.03-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cancellation and timeout”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C080-T05 · Environment record:** Record the actual “Cancellation and timeout” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C080-T06 · Expected versus observed:** Pair every “Cancellation and timeout” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C080-T07 · Failure and limit records:** Attach “Cancellation and timeout” change/failure and bounds evidence where required; include uncovered “Build deadline and cleanup time” and unresolved violations of “Canceled builds cannot continue writing shared outputs”.
- [ ] **UC-M04.03-C080-T08 · Evidence hygiene:** Check the “Cancellation and timeout” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C080-T09 · Reproduction review:** Have the “Cancellation and timeout” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C080-T10 · Acceptance linkage:** Link the “Cancellation and timeout” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Workspace disposal

**Source delivery:** Remove or quarantine disposable roots according to evidence-retention policy.

**Source invariant:** Build leftovers cannot become implicit inputs to later builds.

**Source negative case:** A later build consumes a previous failed build's temporary object.

**Source bounded quantities:** Retained workspace bytes and retention count.

### UC-M04.03-C081 · Contract

**Original checklist item:** Specify workspace disposal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C081-T01 · Scope statement:** Draft the operation boundary for “Workspace disposal” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Workspace disposal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C081-T03 · Output inventory:** List the outputs of “Workspace disposal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Workspace disposal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C081-T05 · Prerequisite contract:** Map “Workspace disposal” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C081-T06 · Authority map:** Identify who may produce, change and consume “Workspace disposal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C081-T07 · Invariant clause:** Add a normative clause for “Workspace disposal” that preserves “Build leftovers cannot become implicit inputs to later builds”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Workspace disposal”; include the source counterexample “A later build consumes a previous failed build's temporary object” and the intended safe disposition.
- [ ] **UC-M04.03-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained workspace bytes and retention count” in the “Workspace disposal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C081-T10 · Contract review:** Review the “Workspace disposal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C082 · Delivery

**Original checklist item:** Remove or quarantine disposable roots according to evidence-retention policy.

- [ ] **UC-M04.03-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Workspace disposal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C082-T02 · Change plan:** Break the source delivery for “Workspace disposal” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Workspace disposal” that realizes this source instruction: Remove or quarantine disposable roots according to evidence-retention policy.
- [ ] **UC-M04.03-C082-T04 · Concrete realization:** Trace “Workspace disposal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.03-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Workspace disposal” needed to preserve “Build leftovers cannot become implicit inputs to later builds”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C082-T06 · Dependency connection:** Connect the “Workspace disposal” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C082-T07 · Resource behavior:** Account for “Retained workspace bytes and retention count” in “Workspace disposal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C082-T08 · Delivery check:** Run the smallest real “Workspace disposal” path and its adverse fixture “A later build consumes a previous failed build's temporary object”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C082-T09 · Patch review:** Review the “Workspace disposal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C082-T10 · Delivery handoff:** Publish the “Workspace disposal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Build leftovers cannot become implicit inputs to later builds. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C083-T01 · Named property:** Create a stable property/check name under this parent for “Workspace disposal”; copy its required invariant exactly: “Build leftovers cannot become implicit inputs to later builds”.
- [ ] **UC-M04.03-C083-T02 · Observable terms:** Define each term in the “Workspace disposal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C083-T03 · Precondition set:** List the preconditions under which “Build leftovers cannot become implicit inputs to later builds” must hold for “Workspace disposal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C083-T04 · Transition coverage:** Map the “Workspace disposal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Workspace disposal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C083-T06 · Satisfying fixture:** Create a concrete “Workspace disposal” case that satisfies “Build leftovers cannot become implicit inputs to later builds”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C083-T07 · Violating fixture:** Create the source counterexample “A later build consumes a previous failed build's temporary object” for “Workspace disposal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C083-T08 · Enforcement evidence:** Exercise the “Workspace disposal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C083-T09 · Regression linkage:** Link the “Workspace disposal” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C083-T10 · Property disposition:** Compare the satisfying and violating “Workspace disposal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C084 · Integration

**Original checklist item:** Integrate workspace disposal with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Workspace disposal” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C084-T02 · Field mapping:** Map every “Workspace disposal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Workspace disposal” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C084-T04 · Ownership agreement:** Specify who owns “Workspace disposal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C084-T05 · Handoff implementation:** Connect “Workspace disposal” through the mapped seam using the real adapter or explicit specification reference; preserve “Build leftovers cannot become implicit inputs to later builds” across the handoff.
- [ ] **UC-M04.03-C084-T06 · Absent-input case:** Omit one required “Workspace disposal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C084-T07 · Stale-input case:** Supply an outdated “Workspace disposal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C084-T08 · Incompatible-input case:** Supply an incompatible “Workspace disposal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C084-T09 · Valid integration trace:** Run a valid “Workspace disposal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C084-T10 · Seam review:** Reconcile the “Workspace disposal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for workspace disposal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Workspace disposal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C085-T02 · Expected-result oracle:** Specify the “Workspace disposal” expected result independently of the implementation output; include the property “Build leftovers cannot become implicit inputs to later builds” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C085-T03 · Fixture material:** Create the concrete “Workspace disposal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C085-T04 · Target preparation:** Prepare the “Workspace disposal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C085-T05 · Initial-state record:** Record the initial “Workspace disposal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C085-T06 · Valid-path execution:** Execute the “Workspace disposal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C085-T07 · Outcome comparison:** Compare every declared “Workspace disposal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C085-T08 · State and bounds check:** Inspect the “Workspace disposal” ownership/state effects and actual use of “Retained workspace bytes and retention count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C085-T09 · Repeatability check:** Repeat the same “Workspace disposal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C085-T10 · Positive evidence:** Attach the “Workspace disposal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C086 · Negative test

**Original checklist item:** Negative case: A later build consumes a previous failed build's temporary object. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C086-T01 · Adverse-case definition:** Create a test record for the exact “Workspace disposal” source counterexample: “A later build consumes a previous failed build's temporary object”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Workspace disposal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C086-T03 · Valid control:** Construct a valid “Workspace disposal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C086-T04 · Minimal adverse input:** Derive the “Workspace disposal” adverse fixture from the control with the smallest documented change needed to reproduce “A later build consumes a previous failed build's temporary object”; retain that change as reproducible data.
- [ ] **UC-M04.03-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Workspace disposal”; require “Build leftovers cannot become implicit inputs to later builds” and forbid a false-success verdict.
- [ ] **UC-M04.03-C086-T06 · Adverse execution:** Exercise the “Workspace disposal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C086-T07 · Effect inspection:** Inspect “Workspace disposal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C086-T08 · Refusal versus failure:** Confirm the “Workspace disposal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C086-T09 · Reset and retention:** Restore only the disposable “Workspace disposal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C086-T10 · Negative regression:** Register the “Workspace disposal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C087 · Change / failure test

**Original checklist item:** Exercise workspace disposal when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C087-T01 · Scenario record:** Write the “Workspace disposal” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “Build leftovers cannot become implicit inputs to later builds”.
- [ ] **UC-M04.03-C087-T02 · Baseline capture:** Create a known-valid “Workspace disposal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C087-T03 · Injection map:** Locate the “Workspace disposal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Workspace disposal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C087-T05 · Controlled trigger:** Introduce the controlled “Workspace disposal” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C087-T06 · Intermediate inspection:** Inspect the “Workspace disposal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Workspace disposal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Workspace disposal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C087-T09 · Repeat and compare:** Repeat the selected “Workspace disposal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C087-T10 · Failure evidence:** Publish the “Workspace disposal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C088 · Bounds

**Original checklist item:** Choose, document and test limits for retained workspace bytes and retention count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C088-T01 · Quantity inventory:** Create a measurement inventory for “Workspace disposal”: “Retained workspace bytes and retention count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C088-T02 · Measurement method:** Choose how to observe each “Workspace disposal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C088-T03 · Budget decision:** Select justified resource and input limits for “Workspace disposal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Workspace disposal” cases for “Retained workspace bytes and retention count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Workspace disposal” limit; preserve “Build leftovers cannot become implicit inputs to later builds”.
- [ ] **UC-M04.03-C088-T06 · Normal measurement:** Run or review the normal “Workspace disposal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C088-T07 · At-limit measurement:** Exercise the “Workspace disposal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C088-T08 · Over-limit measurement:** Exercise the “Workspace disposal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C088-T09 · Uncovered-scope report:** List the “Workspace disposal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C088-T10 · Limit evidence:** Publish the selected “Workspace disposal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for workspace disposal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C089-T01 · Event inventory:** List the “Workspace disposal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Workspace disposal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C089-T03 · Failure mapping:** Map each documented “Workspace disposal” refusal or error to a diagnostic outcome; include “A later build consumes a previous failed build's temporary object” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C089-T04 · Emission path:** Add the “Workspace disposal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C089-T05 · Redaction check:** Test “Workspace disposal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C089-T06 · Output budget:** Set and exercise bounded “Workspace disposal” message size, rate and retention compatible with “Retained workspace bytes and retention count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C089-T07 · Success/refusal fixtures:** Capture “Workspace disposal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Workspace disposal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C089-T09 · Operator review:** Read the “Workspace disposal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C089-T10 · Diagnostic evidence:** Publish redacted “Workspace disposal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for workspace disposal; label unexecuted checks as untested.

- [ ] **UC-M04.03-C090-T01 · Evidence inventory:** List the “Workspace disposal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C090-T02 · Artifact references:** Record the exact “Workspace disposal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C090-T03 · Fixture references:** Attach the “Workspace disposal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A later build consumes a previous failed build's temporary object” as a distinct evidence case.
- [ ] **UC-M04.03-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Workspace disposal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C090-T05 · Environment record:** Record the actual “Workspace disposal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C090-T06 · Expected versus observed:** Pair every “Workspace disposal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C090-T07 · Failure and limit records:** Attach “Workspace disposal” change/failure and bounds evidence where required; include uncovered “Retained workspace bytes and retention count” and unresolved violations of “Build leftovers cannot become implicit inputs to later builds”.
- [ ] **UC-M04.03-C090-T08 · Evidence hygiene:** Check the “Workspace disposal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C090-T09 · Reproduction review:** Have the “Workspace disposal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C090-T10 · Acceptance linkage:** Link the “Workspace disposal” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Hostile-build qualification

**Source delivery:** Exercise forbidden reads, network access, persistence and resource floods.

**Source invariant:** The sandbox blocks observed attacks within the declared threat model.

**Source negative case:** A malicious build changes a file outside its disposable root.

**Source bounded quantities:** Attack fixture count and qualification duration.

### UC-M04.03-C091 · Contract

**Original checklist item:** Specify hostile-build qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.03-C091-T01 · Scope statement:** Draft the operation boundary for “Hostile-build qualification” within Sandboxed build workers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.03-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Hostile-build qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.03-C091-T03 · Output inventory:** List the outputs of “Hostile-build qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.03-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Hostile-build qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.03-C091-T05 · Prerequisite contract:** Map “Hostile-build qualification” to the source component prerequisites (UC-M03.03, UC-M03.05, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.03-C091-T06 · Authority map:** Identify who may produce, change and consume “Hostile-build qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.03-C091-T07 · Invariant clause:** Add a normative clause for “Hostile-build qualification” that preserves “The sandbox blocks observed attacks within the declared threat model”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.03-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Hostile-build qualification”; include the source counterexample “A malicious build changes a file outside its disposable root” and the intended safe disposition.
- [ ] **UC-M04.03-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Attack fixture count and qualification duration” in the “Hostile-build qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.03-C091-T10 · Contract review:** Review the “Hostile-build qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.03-C092 · Delivery

**Original checklist item:** Exercise forbidden reads, network access, persistence and resource floods.

- [ ] **UC-M04.03-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Hostile-build qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.03-C092-T02 · Change plan:** Break the source delivery for “Hostile-build qualification” into concrete edit targets and reviewable outputs; keep the UC-M04.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.03-C092-T03 · Core artifact:** Create the “Hostile-build qualification” fixture or harness for this source instruction: Exercise forbidden reads, network access, persistence and resource floods.
- [ ] **UC-M04.03-C092-T04 · Concrete realization:** Connect the “Hostile-build qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.03-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Hostile-build qualification” needed to preserve “The sandbox blocks observed attacks within the declared threat model”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.03-C092-T06 · Dependency connection:** Connect the “Hostile-build qualification” implementation to restricted workers, approved build inputs and image-output admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.03-C092-T07 · Resource behavior:** Account for “Attack fixture count and qualification duration” in “Hostile-build qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.03-C092-T08 · Delivery check:** Run the smallest real “Hostile-build qualification” path and its adverse fixture “A malicious build changes a file outside its disposable root”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.03-C092-T09 · Patch review:** Review the “Hostile-build qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.03-C092-T10 · Delivery handoff:** Publish the “Hostile-build qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.03-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The sandbox blocks observed attacks within the declared threat model. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.03-C093-T01 · Named property:** Create a stable property/check name under this parent for “Hostile-build qualification”; copy its required invariant exactly: “The sandbox blocks observed attacks within the declared threat model”.
- [ ] **UC-M04.03-C093-T02 · Observable terms:** Define each term in the “Hostile-build qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.03-C093-T03 · Precondition set:** List the preconditions under which “The sandbox blocks observed attacks within the declared threat model” must hold for “Hostile-build qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.03-C093-T04 · Transition coverage:** Map the “Hostile-build qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.03-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Hostile-build qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.03-C093-T06 · Satisfying fixture:** Create a concrete “Hostile-build qualification” case that satisfies “The sandbox blocks observed attacks within the declared threat model”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.03-C093-T07 · Violating fixture:** Create the source counterexample “A malicious build changes a file outside its disposable root” for “Hostile-build qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.03-C093-T08 · Enforcement evidence:** Exercise the “Hostile-build qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.03-C093-T09 · Regression linkage:** Link the “Hostile-build qualification” property to changes in restricted workers, approved build inputs and image-output admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.03-C093-T10 · Property disposition:** Compare the satisfying and violating “Hostile-build qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.03-C094 · Integration

**Original checklist item:** Integrate hostile-build qualification with restricted workers, approved build inputs and image-output admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.03-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Hostile-build qualification” across restricted workers, approved build inputs and image-output admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.03-C094-T02 · Field mapping:** Map every “Hostile-build qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.03-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Hostile-build qualification” (source dependency list: UC-M03.03, UC-M03.05, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.03-C094-T04 · Ownership agreement:** Specify who owns “Hostile-build qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.03-C094-T05 · Handoff implementation:** Connect “Hostile-build qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “The sandbox blocks observed attacks within the declared threat model” across the handoff.
- [ ] **UC-M04.03-C094-T06 · Absent-input case:** Omit one required “Hostile-build qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.03-C094-T07 · Stale-input case:** Supply an outdated “Hostile-build qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.03-C094-T08 · Incompatible-input case:** Supply an incompatible “Hostile-build qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.03-C094-T09 · Valid integration trace:** Run a valid “Hostile-build qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.03-C094-T10 · Seam review:** Reconcile the “Hostile-build qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.03-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for hostile-build qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.03-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Hostile-build qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.03-C095-T02 · Expected-result oracle:** Specify the “Hostile-build qualification” expected result independently of the implementation output; include the property “The sandbox blocks observed attacks within the declared threat model” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.03-C095-T03 · Fixture material:** Create the concrete “Hostile-build qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.03-C095-T04 · Target preparation:** Prepare the “Hostile-build qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.03-C095-T05 · Initial-state record:** Record the initial “Hostile-build qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.03-C095-T06 · Valid-path execution:** Execute the “Hostile-build qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.03-C095-T07 · Outcome comparison:** Compare every declared “Hostile-build qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.03-C095-T08 · State and bounds check:** Inspect the “Hostile-build qualification” ownership/state effects and actual use of “Attack fixture count and qualification duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.03-C095-T09 · Repeatability check:** Repeat the same “Hostile-build qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.03-C095-T10 · Positive evidence:** Attach the “Hostile-build qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.03-C096 · Negative test

**Original checklist item:** Negative case: A malicious build changes a file outside its disposable root. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.03-C096-T01 · Adverse-case definition:** Create a test record for the exact “Hostile-build qualification” source counterexample: “A malicious build changes a file outside its disposable root”; state which precondition or invariant it challenges.
- [ ] **UC-M04.03-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Hostile-build qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.03-C096-T03 · Valid control:** Construct a valid “Hostile-build qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.03-C096-T04 · Minimal adverse input:** Derive the “Hostile-build qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A malicious build changes a file outside its disposable root”; retain that change as reproducible data.
- [ ] **UC-M04.03-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Hostile-build qualification”; require “The sandbox blocks observed attacks within the declared threat model” and forbid a false-success verdict.
- [ ] **UC-M04.03-C096-T06 · Adverse execution:** Exercise the “Hostile-build qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.03-C096-T07 · Effect inspection:** Inspect “Hostile-build qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.03-C096-T08 · Refusal versus failure:** Confirm the “Hostile-build qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.03-C096-T09 · Reset and retention:** Restore only the disposable “Hostile-build qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.03-C096-T10 · Negative regression:** Register the “Hostile-build qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.03-C097 · Change / failure test

**Original checklist item:** Exercise hostile-build qualification when a build is canceled while a descendant hook is still writing output; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.03-C097-T01 · Scenario record:** Write the “Hostile-build qualification” change/failure scenario exactly as supplied: a build is canceled while a descendant hook is still writing output; identify the property that must remain true: “The sandbox blocks observed attacks within the declared threat model”.
- [ ] **UC-M04.03-C097-T02 · Baseline capture:** Create a known-valid “Hostile-build qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.03-C097-T03 · Injection map:** Locate the “Hostile-build qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.03-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Hostile-build qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.03-C097-T05 · Controlled trigger:** Introduce the controlled “Hostile-build qualification” scenario in the disposable fixture: a build is canceled while a descendant hook is still writing output; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.03-C097-T06 · Intermediate inspection:** Inspect the “Hostile-build qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.03-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Hostile-build qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.03-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Hostile-build qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.03-C097-T09 · Repeat and compare:** Repeat the selected “Hostile-build qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.03-C097-T10 · Failure evidence:** Publish the “Hostile-build qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.03-C098 · Bounds

**Original checklist item:** Choose, document and test limits for attack fixture count and qualification duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.03-C098-T01 · Quantity inventory:** Create a measurement inventory for “Hostile-build qualification”: “Attack fixture count and qualification duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.03-C098-T02 · Measurement method:** Choose how to observe each “Hostile-build qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.03-C098-T03 · Budget decision:** Select justified resource and input limits for “Hostile-build qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.03-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Hostile-build qualification” cases for “Attack fixture count and qualification duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.03-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Hostile-build qualification” limit; preserve “The sandbox blocks observed attacks within the declared threat model”.
- [ ] **UC-M04.03-C098-T06 · Normal measurement:** Run or review the normal “Hostile-build qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.03-C098-T07 · At-limit measurement:** Exercise the “Hostile-build qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.03-C098-T08 · Over-limit measurement:** Exercise the “Hostile-build qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.03-C098-T09 · Uncovered-scope report:** List the “Hostile-build qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.03-C098-T10 · Limit evidence:** Publish the selected “Hostile-build qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.03-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for hostile-build qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.03-C099-T01 · Event inventory:** List the “Hostile-build qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.03-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Hostile-build qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.03-C099-T03 · Failure mapping:** Map each documented “Hostile-build qualification” refusal or error to a diagnostic outcome; include “A malicious build changes a file outside its disposable root” and prohibit conversion into a success message.
- [ ] **UC-M04.03-C099-T04 · Emission path:** Add the “Hostile-build qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.03-C099-T05 · Redaction check:** Test “Hostile-build qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.03-C099-T06 · Output budget:** Set and exercise bounded “Hostile-build qualification” message size, rate and retention compatible with “Attack fixture count and qualification duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.03-C099-T07 · Success/refusal fixtures:** Capture “Hostile-build qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.03-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Hostile-build qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.03-C099-T09 · Operator review:** Read the “Hostile-build qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.03-C099-T10 · Diagnostic evidence:** Publish redacted “Hostile-build qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.03-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for hostile-build qualification; label unexecuted checks as untested.

- [ ] **UC-M04.03-C100-T01 · Evidence inventory:** List the “Hostile-build qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.03-C100-T02 · Artifact references:** Record the exact “Hostile-build qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.03-C100-T03 · Fixture references:** Attach the “Hostile-build qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A malicious build changes a file outside its disposable root” as a distinct evidence case.
- [ ] **UC-M04.03-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Hostile-build qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.03-C100-T05 · Environment record:** Record the actual “Hostile-build qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.03-C100-T06 · Expected versus observed:** Pair every “Hostile-build qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.03-C100-T07 · Failure and limit records:** Attach “Hostile-build qualification” change/failure and bounds evidence where required; include uncovered “Attack fixture count and qualification duration” and unresolved violations of “The sandbox blocks observed attacks within the declared threat model”.
- [ ] **UC-M04.03-C100-T08 · Evidence hygiene:** Check the “Hostile-build qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.03-C100-T09 · Reproduction review:** Have the “Hostile-build qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.03-C100-T10 · Acceptance linkage:** Link the “Hostile-build qualification” evidence to its parent and UC-M04.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

