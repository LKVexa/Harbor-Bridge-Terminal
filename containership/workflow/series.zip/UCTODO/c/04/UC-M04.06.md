# UC-M04.06 — Software bill of materials and license inventory

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P1 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M04.01](../04/UC-M04.01.md), [UC-M04.05](../04/UC-M04.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Produce machine-readable component/version/source/license records for the guest, host, bundled hull and hold.

**Original acceptance criterion:** Every linked or shipped runtime dependency maps to a source/version/license and a reviewable provenance record.

**Source trace:** Original checklist `UC100/c/04/UC-M04.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 389–399 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Inventory schema

**Source delivery:** Define machine-readable component, version, source, license and provenance fields.

**Source invariant:** Every shipped dependency has an identifiable inventory record.

**Source negative case:** A record lists only a product name without version or origin.

**Source bounded quantities:** Record count and metadata bytes.

### UC-M04.06-C001 · Contract

**Original checklist item:** Specify inventory schema inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C001-T01 · Scope statement:** Draft the operation boundary for “Inventory schema” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Inventory schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C001-T03 · Output inventory:** List the outputs of “Inventory schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Inventory schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C001-T05 · Prerequisite contract:** Map “Inventory schema” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Inventory schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C001-T07 · Invariant clause:** Add a normative clause for “Inventory schema” that preserves “Every shipped dependency has an identifiable inventory record”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Inventory schema”; include the source counterexample “A record lists only a product name without version or origin” and the intended safe disposition.
- [ ] **UC-M04.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Record count and metadata bytes” in the “Inventory schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C001-T10 · Contract review:** Review the “Inventory schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C002 · Delivery

**Original checklist item:** Define machine-readable component, version, source, license and provenance fields.

- [ ] **UC-M04.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Inventory schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C002-T02 · Change plan:** Break the source delivery for “Inventory schema” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C002-T03 · Core artifact:** Create the “Inventory schema” model, schema or inventory that realizes this source instruction: Define machine-readable component, version, source, license and provenance fields.
- [ ] **UC-M04.06-C002-T04 · Concrete realization:** Populate “Inventory schema” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Inventory schema” needed to preserve “Every shipped dependency has an identifiable inventory record”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C002-T06 · Dependency connection:** Connect the “Inventory schema” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C002-T07 · Resource behavior:** Account for “Record count and metadata bytes” in “Inventory schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C002-T08 · Delivery check:** Run the smallest real “Inventory schema” path and its adverse fixture “A record lists only a product name without version or origin”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C002-T09 · Patch review:** Review the “Inventory schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C002-T10 · Delivery handoff:** Publish the “Inventory schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every shipped dependency has an identifiable inventory record. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Inventory schema”; copy its required invariant exactly: “Every shipped dependency has an identifiable inventory record”.
- [ ] **UC-M04.06-C003-T02 · Observable terms:** Define each term in the “Inventory schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C003-T03 · Precondition set:** List the preconditions under which “Every shipped dependency has an identifiable inventory record” must hold for “Inventory schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C003-T04 · Transition coverage:** Map the “Inventory schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Inventory schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C003-T06 · Satisfying fixture:** Create a concrete “Inventory schema” case that satisfies “Every shipped dependency has an identifiable inventory record”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C003-T07 · Violating fixture:** Create the source counterexample “A record lists only a product name without version or origin” for “Inventory schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C003-T08 · Enforcement evidence:** Exercise the “Inventory schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C003-T09 · Regression linkage:** Link the “Inventory schema” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Inventory schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C004 · Integration

**Original checklist item:** Integrate inventory schema with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Inventory schema” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C004-T02 · Field mapping:** Map every “Inventory schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Inventory schema” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C004-T04 · Ownership agreement:** Specify who owns “Inventory schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C004-T05 · Handoff implementation:** Connect “Inventory schema” through the mapped seam using the real adapter or explicit specification reference; preserve “Every shipped dependency has an identifiable inventory record” across the handoff.
- [ ] **UC-M04.06-C004-T06 · Absent-input case:** Omit one required “Inventory schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C004-T07 · Stale-input case:** Supply an outdated “Inventory schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Inventory schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C004-T09 · Valid integration trace:** Run a valid “Inventory schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C004-T10 · Seam review:** Reconcile the “Inventory schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for inventory schema; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Inventory schema” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C005-T02 · Expected-result oracle:** Specify the “Inventory schema” expected result independently of the implementation output; include the property “Every shipped dependency has an identifiable inventory record” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C005-T03 · Fixture material:** Create the concrete “Inventory schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C005-T04 · Target preparation:** Prepare the “Inventory schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C005-T05 · Initial-state record:** Record the initial “Inventory schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C005-T06 · Valid-path execution:** Execute the “Inventory schema” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C005-T07 · Outcome comparison:** Compare every declared “Inventory schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C005-T08 · State and bounds check:** Inspect the “Inventory schema” ownership/state effects and actual use of “Record count and metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C005-T09 · Repeatability check:** Repeat the same “Inventory schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C005-T10 · Positive evidence:** Attach the “Inventory schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C006 · Negative test

**Original checklist item:** Negative case: A record lists only a product name without version or origin. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Inventory schema” source counterexample: “A record lists only a product name without version or origin”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Inventory schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C006-T03 · Valid control:** Construct a valid “Inventory schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C006-T04 · Minimal adverse input:** Derive the “Inventory schema” adverse fixture from the control with the smallest documented change needed to reproduce “A record lists only a product name without version or origin”; retain that change as reproducible data.
- [ ] **UC-M04.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Inventory schema”; require “Every shipped dependency has an identifiable inventory record” and forbid a false-success verdict.
- [ ] **UC-M04.06-C006-T06 · Adverse execution:** Exercise the “Inventory schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C006-T07 · Effect inspection:** Inspect “Inventory schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C006-T08 · Refusal versus failure:** Confirm the “Inventory schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C006-T09 · Reset and retention:** Restore only the disposable “Inventory schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C006-T10 · Negative regression:** Register the “Inventory schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C007 · Change / failure test

**Original checklist item:** Exercise inventory schema when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C007-T01 · Scenario record:** Write the “Inventory schema” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “Every shipped dependency has an identifiable inventory record”.
- [ ] **UC-M04.06-C007-T02 · Baseline capture:** Create a known-valid “Inventory schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C007-T03 · Injection map:** Locate the “Inventory schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Inventory schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C007-T05 · Controlled trigger:** Introduce the controlled “Inventory schema” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C007-T06 · Intermediate inspection:** Inspect the “Inventory schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Inventory schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Inventory schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C007-T09 · Repeat and compare:** Repeat the selected “Inventory schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C007-T10 · Failure evidence:** Publish the “Inventory schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for record count and metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Inventory schema”: “Record count and metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C008-T02 · Measurement method:** Choose how to observe each “Inventory schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Inventory schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Inventory schema” cases for “Record count and metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Inventory schema” limit; preserve “Every shipped dependency has an identifiable inventory record”.
- [ ] **UC-M04.06-C008-T06 · Normal measurement:** Run or review the normal “Inventory schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C008-T07 · At-limit measurement:** Exercise the “Inventory schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C008-T08 · Over-limit measurement:** Exercise the “Inventory schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C008-T09 · Uncovered-scope report:** List the “Inventory schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C008-T10 · Limit evidence:** Publish the selected “Inventory schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for inventory schema with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C009-T01 · Event inventory:** List the “Inventory schema” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Inventory schema” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C009-T03 · Failure mapping:** Map each documented “Inventory schema” refusal or error to a diagnostic outcome; include “A record lists only a product name without version or origin” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C009-T04 · Emission path:** Add the “Inventory schema” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C009-T05 · Redaction check:** Test “Inventory schema” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C009-T06 · Output budget:** Set and exercise bounded “Inventory schema” message size, rate and retention compatible with “Record count and metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C009-T07 · Success/refusal fixtures:** Capture “Inventory schema” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Inventory schema” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C009-T09 · Operator review:** Read the “Inventory schema” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C009-T10 · Diagnostic evidence:** Publish redacted “Inventory schema” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for inventory schema; label unexecuted checks as untested.

- [ ] **UC-M04.06-C010-T01 · Evidence inventory:** List the “Inventory schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C010-T02 · Artifact references:** Record the exact “Inventory schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C010-T03 · Fixture references:** Attach the “Inventory schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “A record lists only a product name without version or origin” as a distinct evidence case.
- [ ] **UC-M04.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Inventory schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C010-T05 · Environment record:** Record the actual “Inventory schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C010-T06 · Expected versus observed:** Pair every “Inventory schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C010-T07 · Failure and limit records:** Attach “Inventory schema” change/failure and bounds evidence where required; include uncovered “Record count and metadata bytes” and unresolved violations of “Every shipped dependency has an identifiable inventory record”.
- [ ] **UC-M04.06-C010-T08 · Evidence hygiene:** Check the “Inventory schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C010-T09 · Reproduction review:** Have the “Inventory schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C010-T10 · Acceptance linkage:** Link the “Inventory schema” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Guest dependency inventory

**Source delivery:** Enumerate libraries and runtime code actually linked into the guest image.

**Source invariant:** The inventory describes linked contents rather than only declared intentions.

**Source negative case:** A transitive linked library is absent from the inventory.

**Source bounded quantities:** Linked components and symbol-analysis cost.

### UC-M04.06-C011 · Contract

**Original checklist item:** Specify guest dependency inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C011-T01 · Scope statement:** Draft the operation boundary for “Guest dependency inventory” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Guest dependency inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C011-T03 · Output inventory:** List the outputs of “Guest dependency inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Guest dependency inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C011-T05 · Prerequisite contract:** Map “Guest dependency inventory” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Guest dependency inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C011-T07 · Invariant clause:** Add a normative clause for “Guest dependency inventory” that preserves “The inventory describes linked contents rather than only declared intentions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Guest dependency inventory”; include the source counterexample “A transitive linked library is absent from the inventory” and the intended safe disposition.
- [ ] **UC-M04.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Linked components and symbol-analysis cost” in the “Guest dependency inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C011-T10 · Contract review:** Review the “Guest dependency inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C012 · Delivery

**Original checklist item:** Enumerate libraries and runtime code actually linked into the guest image.

- [ ] **UC-M04.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Guest dependency inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C012-T02 · Change plan:** Break the source delivery for “Guest dependency inventory” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C012-T03 · Core artifact:** Create the “Guest dependency inventory” model, schema or inventory that realizes this source instruction: Enumerate libraries and runtime code actually linked into the guest image.
- [ ] **UC-M04.06-C012-T04 · Concrete realization:** Populate “Guest dependency inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Guest dependency inventory” needed to preserve “The inventory describes linked contents rather than only declared intentions”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C012-T06 · Dependency connection:** Connect the “Guest dependency inventory” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C012-T07 · Resource behavior:** Account for “Linked components and symbol-analysis cost” in “Guest dependency inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C012-T08 · Delivery check:** Run the smallest real “Guest dependency inventory” path and its adverse fixture “A transitive linked library is absent from the inventory”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C012-T09 · Patch review:** Review the “Guest dependency inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C012-T10 · Delivery handoff:** Publish the “Guest dependency inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The inventory describes linked contents rather than only declared intentions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Guest dependency inventory”; copy its required invariant exactly: “The inventory describes linked contents rather than only declared intentions”.
- [ ] **UC-M04.06-C013-T02 · Observable terms:** Define each term in the “Guest dependency inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C013-T03 · Precondition set:** List the preconditions under which “The inventory describes linked contents rather than only declared intentions” must hold for “Guest dependency inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C013-T04 · Transition coverage:** Map the “Guest dependency inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Guest dependency inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C013-T06 · Satisfying fixture:** Create a concrete “Guest dependency inventory” case that satisfies “The inventory describes linked contents rather than only declared intentions”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C013-T07 · Violating fixture:** Create the source counterexample “A transitive linked library is absent from the inventory” for “Guest dependency inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C013-T08 · Enforcement evidence:** Exercise the “Guest dependency inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C013-T09 · Regression linkage:** Link the “Guest dependency inventory” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Guest dependency inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C014 · Integration

**Original checklist item:** Integrate guest dependency inventory with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Guest dependency inventory” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C014-T02 · Field mapping:** Map every “Guest dependency inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Guest dependency inventory” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C014-T04 · Ownership agreement:** Specify who owns “Guest dependency inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C014-T05 · Handoff implementation:** Connect “Guest dependency inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “The inventory describes linked contents rather than only declared intentions” across the handoff.
- [ ] **UC-M04.06-C014-T06 · Absent-input case:** Omit one required “Guest dependency inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C014-T07 · Stale-input case:** Supply an outdated “Guest dependency inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Guest dependency inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C014-T09 · Valid integration trace:** Run a valid “Guest dependency inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C014-T10 · Seam review:** Reconcile the “Guest dependency inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for guest dependency inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Guest dependency inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C015-T02 · Expected-result oracle:** Specify the “Guest dependency inventory” expected result independently of the implementation output; include the property “The inventory describes linked contents rather than only declared intentions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C015-T03 · Fixture material:** Create the concrete “Guest dependency inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C015-T04 · Target preparation:** Prepare the “Guest dependency inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C015-T05 · Initial-state record:** Record the initial “Guest dependency inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C015-T06 · Valid-path execution:** Execute the “Guest dependency inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C015-T07 · Outcome comparison:** Compare every declared “Guest dependency inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C015-T08 · State and bounds check:** Inspect the “Guest dependency inventory” ownership/state effects and actual use of “Linked components and symbol-analysis cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C015-T09 · Repeatability check:** Repeat the same “Guest dependency inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C015-T10 · Positive evidence:** Attach the “Guest dependency inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C016 · Negative test

**Original checklist item:** Negative case: A transitive linked library is absent from the inventory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Guest dependency inventory” source counterexample: “A transitive linked library is absent from the inventory”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Guest dependency inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C016-T03 · Valid control:** Construct a valid “Guest dependency inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C016-T04 · Minimal adverse input:** Derive the “Guest dependency inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A transitive linked library is absent from the inventory”; retain that change as reproducible data.
- [ ] **UC-M04.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Guest dependency inventory”; require “The inventory describes linked contents rather than only declared intentions” and forbid a false-success verdict.
- [ ] **UC-M04.06-C016-T06 · Adverse execution:** Exercise the “Guest dependency inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C016-T07 · Effect inspection:** Inspect “Guest dependency inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C016-T08 · Refusal versus failure:** Confirm the “Guest dependency inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C016-T09 · Reset and retention:** Restore only the disposable “Guest dependency inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C016-T10 · Negative regression:** Register the “Guest dependency inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C017 · Change / failure test

**Original checklist item:** Exercise guest dependency inventory when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C017-T01 · Scenario record:** Write the “Guest dependency inventory” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “The inventory describes linked contents rather than only declared intentions”.
- [ ] **UC-M04.06-C017-T02 · Baseline capture:** Create a known-valid “Guest dependency inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C017-T03 · Injection map:** Locate the “Guest dependency inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Guest dependency inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C017-T05 · Controlled trigger:** Introduce the controlled “Guest dependency inventory” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C017-T06 · Intermediate inspection:** Inspect the “Guest dependency inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Guest dependency inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Guest dependency inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C017-T09 · Repeat and compare:** Repeat the selected “Guest dependency inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C017-T10 · Failure evidence:** Publish the “Guest dependency inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for linked components and symbol-analysis cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Guest dependency inventory”: “Linked components and symbol-analysis cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C018-T02 · Measurement method:** Choose how to observe each “Guest dependency inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Guest dependency inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Guest dependency inventory” cases for “Linked components and symbol-analysis cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Guest dependency inventory” limit; preserve “The inventory describes linked contents rather than only declared intentions”.
- [ ] **UC-M04.06-C018-T06 · Normal measurement:** Run or review the normal “Guest dependency inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C018-T07 · At-limit measurement:** Exercise the “Guest dependency inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C018-T08 · Over-limit measurement:** Exercise the “Guest dependency inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C018-T09 · Uncovered-scope report:** List the “Guest dependency inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C018-T10 · Limit evidence:** Publish the selected “Guest dependency inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for guest dependency inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C019-T01 · Event inventory:** List the “Guest dependency inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Guest dependency inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C019-T03 · Failure mapping:** Map each documented “Guest dependency inventory” refusal or error to a diagnostic outcome; include “A transitive linked library is absent from the inventory” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C019-T04 · Emission path:** Add the “Guest dependency inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C019-T05 · Redaction check:** Test “Guest dependency inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C019-T06 · Output budget:** Set and exercise bounded “Guest dependency inventory” message size, rate and retention compatible with “Linked components and symbol-analysis cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C019-T07 · Success/refusal fixtures:** Capture “Guest dependency inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Guest dependency inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C019-T09 · Operator review:** Read the “Guest dependency inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C019-T10 · Diagnostic evidence:** Publish redacted “Guest dependency inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for guest dependency inventory; label unexecuted checks as untested.

- [ ] **UC-M04.06-C020-T01 · Evidence inventory:** List the “Guest dependency inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C020-T02 · Artifact references:** Record the exact “Guest dependency inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C020-T03 · Fixture references:** Attach the “Guest dependency inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A transitive linked library is absent from the inventory” as a distinct evidence case.
- [ ] **UC-M04.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Guest dependency inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C020-T05 · Environment record:** Record the actual “Guest dependency inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C020-T06 · Expected versus observed:** Pair every “Guest dependency inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C020-T07 · Failure and limit records:** Attach “Guest dependency inventory” change/failure and bounds evidence where required; include uncovered “Linked components and symbol-analysis cost” and unresolved violations of “The inventory describes linked contents rather than only declared intentions”.
- [ ] **UC-M04.06-C020-T08 · Evidence hygiene:** Check the “Guest dependency inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C020-T09 · Reproduction review:** Have the “Guest dependency inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C020-T10 · Acceptance linkage:** Link the “Guest dependency inventory” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Host dependency inventory

**Source delivery:** Inventory host management libraries, native tools and bundled launch dependencies.

**Source invariant:** Host-side shipped dependencies are not omitted from the release inventory.

**Source negative case:** A bundled helper executable lacks a component record.

**Source bounded quantities:** Host artifacts and scan bytes.

### UC-M04.06-C021 · Contract

**Original checklist item:** Specify host dependency inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C021-T01 · Scope statement:** Draft the operation boundary for “Host dependency inventory” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Host dependency inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C021-T03 · Output inventory:** List the outputs of “Host dependency inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Host dependency inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C021-T05 · Prerequisite contract:** Map “Host dependency inventory” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Host dependency inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C021-T07 · Invariant clause:** Add a normative clause for “Host dependency inventory” that preserves “Host-side shipped dependencies are not omitted from the release inventory”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Host dependency inventory”; include the source counterexample “A bundled helper executable lacks a component record” and the intended safe disposition.
- [ ] **UC-M04.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Host artifacts and scan bytes” in the “Host dependency inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C021-T10 · Contract review:** Review the “Host dependency inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C022 · Delivery

**Original checklist item:** Inventory host management libraries, native tools and bundled launch dependencies.

- [ ] **UC-M04.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Host dependency inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C022-T02 · Change plan:** Break the source delivery for “Host dependency inventory” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C022-T03 · Core artifact:** Create the “Host dependency inventory” model, schema or inventory that realizes this source instruction: Inventory host management libraries, native tools and bundled launch dependencies.
- [ ] **UC-M04.06-C022-T04 · Concrete realization:** Populate “Host dependency inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Host dependency inventory” needed to preserve “Host-side shipped dependencies are not omitted from the release inventory”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C022-T06 · Dependency connection:** Connect the “Host dependency inventory” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C022-T07 · Resource behavior:** Account for “Host artifacts and scan bytes” in “Host dependency inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C022-T08 · Delivery check:** Run the smallest real “Host dependency inventory” path and its adverse fixture “A bundled helper executable lacks a component record”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C022-T09 · Patch review:** Review the “Host dependency inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C022-T10 · Delivery handoff:** Publish the “Host dependency inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Host-side shipped dependencies are not omitted from the release inventory. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Host dependency inventory”; copy its required invariant exactly: “Host-side shipped dependencies are not omitted from the release inventory”.
- [ ] **UC-M04.06-C023-T02 · Observable terms:** Define each term in the “Host dependency inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C023-T03 · Precondition set:** List the preconditions under which “Host-side shipped dependencies are not omitted from the release inventory” must hold for “Host dependency inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C023-T04 · Transition coverage:** Map the “Host dependency inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Host dependency inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C023-T06 · Satisfying fixture:** Create a concrete “Host dependency inventory” case that satisfies “Host-side shipped dependencies are not omitted from the release inventory”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C023-T07 · Violating fixture:** Create the source counterexample “A bundled helper executable lacks a component record” for “Host dependency inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C023-T08 · Enforcement evidence:** Exercise the “Host dependency inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C023-T09 · Regression linkage:** Link the “Host dependency inventory” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Host dependency inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C024 · Integration

**Original checklist item:** Integrate host dependency inventory with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Host dependency inventory” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C024-T02 · Field mapping:** Map every “Host dependency inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Host dependency inventory” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C024-T04 · Ownership agreement:** Specify who owns “Host dependency inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C024-T05 · Handoff implementation:** Connect “Host dependency inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Host-side shipped dependencies are not omitted from the release inventory” across the handoff.
- [ ] **UC-M04.06-C024-T06 · Absent-input case:** Omit one required “Host dependency inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C024-T07 · Stale-input case:** Supply an outdated “Host dependency inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Host dependency inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C024-T09 · Valid integration trace:** Run a valid “Host dependency inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C024-T10 · Seam review:** Reconcile the “Host dependency inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for host dependency inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Host dependency inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C025-T02 · Expected-result oracle:** Specify the “Host dependency inventory” expected result independently of the implementation output; include the property “Host-side shipped dependencies are not omitted from the release inventory” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C025-T03 · Fixture material:** Create the concrete “Host dependency inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C025-T04 · Target preparation:** Prepare the “Host dependency inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C025-T05 · Initial-state record:** Record the initial “Host dependency inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C025-T06 · Valid-path execution:** Execute the “Host dependency inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C025-T07 · Outcome comparison:** Compare every declared “Host dependency inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C025-T08 · State and bounds check:** Inspect the “Host dependency inventory” ownership/state effects and actual use of “Host artifacts and scan bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C025-T09 · Repeatability check:** Repeat the same “Host dependency inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C025-T10 · Positive evidence:** Attach the “Host dependency inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C026 · Negative test

**Original checklist item:** Negative case: A bundled helper executable lacks a component record. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Host dependency inventory” source counterexample: “A bundled helper executable lacks a component record”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Host dependency inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C026-T03 · Valid control:** Construct a valid “Host dependency inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C026-T04 · Minimal adverse input:** Derive the “Host dependency inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A bundled helper executable lacks a component record”; retain that change as reproducible data.
- [ ] **UC-M04.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Host dependency inventory”; require “Host-side shipped dependencies are not omitted from the release inventory” and forbid a false-success verdict.
- [ ] **UC-M04.06-C026-T06 · Adverse execution:** Exercise the “Host dependency inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C026-T07 · Effect inspection:** Inspect “Host dependency inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C026-T08 · Refusal versus failure:** Confirm the “Host dependency inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C026-T09 · Reset and retention:** Restore only the disposable “Host dependency inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C026-T10 · Negative regression:** Register the “Host dependency inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C027 · Change / failure test

**Original checklist item:** Exercise host dependency inventory when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C027-T01 · Scenario record:** Write the “Host dependency inventory” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “Host-side shipped dependencies are not omitted from the release inventory”.
- [ ] **UC-M04.06-C027-T02 · Baseline capture:** Create a known-valid “Host dependency inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C027-T03 · Injection map:** Locate the “Host dependency inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Host dependency inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C027-T05 · Controlled trigger:** Introduce the controlled “Host dependency inventory” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C027-T06 · Intermediate inspection:** Inspect the “Host dependency inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Host dependency inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Host dependency inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C027-T09 · Repeat and compare:** Repeat the selected “Host dependency inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C027-T10 · Failure evidence:** Publish the “Host dependency inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for host artifacts and scan bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Host dependency inventory”: “Host artifacts and scan bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C028-T02 · Measurement method:** Choose how to observe each “Host dependency inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Host dependency inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Host dependency inventory” cases for “Host artifacts and scan bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Host dependency inventory” limit; preserve “Host-side shipped dependencies are not omitted from the release inventory”.
- [ ] **UC-M04.06-C028-T06 · Normal measurement:** Run or review the normal “Host dependency inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C028-T07 · At-limit measurement:** Exercise the “Host dependency inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C028-T08 · Over-limit measurement:** Exercise the “Host dependency inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C028-T09 · Uncovered-scope report:** List the “Host dependency inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C028-T10 · Limit evidence:** Publish the selected “Host dependency inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for host dependency inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C029-T01 · Event inventory:** List the “Host dependency inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Host dependency inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C029-T03 · Failure mapping:** Map each documented “Host dependency inventory” refusal or error to a diagnostic outcome; include “A bundled helper executable lacks a component record” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C029-T04 · Emission path:** Add the “Host dependency inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C029-T05 · Redaction check:** Test “Host dependency inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C029-T06 · Output budget:** Set and exercise bounded “Host dependency inventory” message size, rate and retention compatible with “Host artifacts and scan bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C029-T07 · Success/refusal fixtures:** Capture “Host dependency inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Host dependency inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C029-T09 · Operator review:** Read the “Host dependency inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C029-T10 · Diagnostic evidence:** Publish redacted “Host dependency inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for host dependency inventory; label unexecuted checks as untested.

- [ ] **UC-M04.06-C030-T01 · Evidence inventory:** List the “Host dependency inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C030-T02 · Artifact references:** Record the exact “Host dependency inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C030-T03 · Fixture references:** Attach the “Host dependency inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A bundled helper executable lacks a component record” as a distinct evidence case.
- [ ] **UC-M04.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Host dependency inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C030-T05 · Environment record:** Record the actual “Host dependency inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C030-T06 · Expected versus observed:** Pair every “Host dependency inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C030-T07 · Failure and limit records:** Attach “Host dependency inventory” change/failure and bounds evidence where required; include uncovered “Host artifacts and scan bytes” and unresolved violations of “Host-side shipped dependencies are not omitted from the release inventory”.
- [ ] **UC-M04.06-C030-T08 · Evidence hygiene:** Check the “Host dependency inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C030-T09 · Reproduction review:** Have the “Host dependency inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C030-T10 · Acceptance linkage:** Link the “Host dependency inventory” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Hull and hold inventory

**Source delivery:** Record shipped hull and hold artifacts with their distinct identities.

**Source invariant:** Bundled payloads remain traceable to their actual source versions.

**Source negative case:** Different hold payloads are merged under one vague entry.

**Source bounded quantities:** Nested artifacts and archive traversal depth.

### UC-M04.06-C031 · Contract

**Original checklist item:** Specify hull and hold inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C031-T01 · Scope statement:** Draft the operation boundary for “Hull and hold inventory” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Hull and hold inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C031-T03 · Output inventory:** List the outputs of “Hull and hold inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Hull and hold inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C031-T05 · Prerequisite contract:** Map “Hull and hold inventory” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Hull and hold inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C031-T07 · Invariant clause:** Add a normative clause for “Hull and hold inventory” that preserves “Bundled payloads remain traceable to their actual source versions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Hull and hold inventory”; include the source counterexample “Different hold payloads are merged under one vague entry” and the intended safe disposition.
- [ ] **UC-M04.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Nested artifacts and archive traversal depth” in the “Hull and hold inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C031-T10 · Contract review:** Review the “Hull and hold inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C032 · Delivery

**Original checklist item:** Record shipped hull and hold artifacts with their distinct identities.

- [ ] **UC-M04.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Hull and hold inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C032-T02 · Change plan:** Break the source delivery for “Hull and hold inventory” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C032-T03 · Core artifact:** Create the “Hull and hold inventory” model, schema or inventory that realizes this source instruction: Record shipped hull and hold artifacts with their distinct identities.
- [ ] **UC-M04.06-C032-T04 · Concrete realization:** Populate “Hull and hold inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Hull and hold inventory” needed to preserve “Bundled payloads remain traceable to their actual source versions”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C032-T06 · Dependency connection:** Connect the “Hull and hold inventory” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C032-T07 · Resource behavior:** Account for “Nested artifacts and archive traversal depth” in “Hull and hold inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C032-T08 · Delivery check:** Run the smallest real “Hull and hold inventory” path and its adverse fixture “Different hold payloads are merged under one vague entry”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C032-T09 · Patch review:** Review the “Hull and hold inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C032-T10 · Delivery handoff:** Publish the “Hull and hold inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Bundled payloads remain traceable to their actual source versions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Hull and hold inventory”; copy its required invariant exactly: “Bundled payloads remain traceable to their actual source versions”.
- [ ] **UC-M04.06-C033-T02 · Observable terms:** Define each term in the “Hull and hold inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C033-T03 · Precondition set:** List the preconditions under which “Bundled payloads remain traceable to their actual source versions” must hold for “Hull and hold inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C033-T04 · Transition coverage:** Map the “Hull and hold inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Hull and hold inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C033-T06 · Satisfying fixture:** Create a concrete “Hull and hold inventory” case that satisfies “Bundled payloads remain traceable to their actual source versions”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C033-T07 · Violating fixture:** Create the source counterexample “Different hold payloads are merged under one vague entry” for “Hull and hold inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C033-T08 · Enforcement evidence:** Exercise the “Hull and hold inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C033-T09 · Regression linkage:** Link the “Hull and hold inventory” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Hull and hold inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C034 · Integration

**Original checklist item:** Integrate hull and hold inventory with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Hull and hold inventory” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C034-T02 · Field mapping:** Map every “Hull and hold inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Hull and hold inventory” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C034-T04 · Ownership agreement:** Specify who owns “Hull and hold inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C034-T05 · Handoff implementation:** Connect “Hull and hold inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Bundled payloads remain traceable to their actual source versions” across the handoff.
- [ ] **UC-M04.06-C034-T06 · Absent-input case:** Omit one required “Hull and hold inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C034-T07 · Stale-input case:** Supply an outdated “Hull and hold inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Hull and hold inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C034-T09 · Valid integration trace:** Run a valid “Hull and hold inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C034-T10 · Seam review:** Reconcile the “Hull and hold inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for hull and hold inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Hull and hold inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C035-T02 · Expected-result oracle:** Specify the “Hull and hold inventory” expected result independently of the implementation output; include the property “Bundled payloads remain traceable to their actual source versions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C035-T03 · Fixture material:** Create the concrete “Hull and hold inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C035-T04 · Target preparation:** Prepare the “Hull and hold inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C035-T05 · Initial-state record:** Record the initial “Hull and hold inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C035-T06 · Valid-path execution:** Execute the “Hull and hold inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C035-T07 · Outcome comparison:** Compare every declared “Hull and hold inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C035-T08 · State and bounds check:** Inspect the “Hull and hold inventory” ownership/state effects and actual use of “Nested artifacts and archive traversal depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C035-T09 · Repeatability check:** Repeat the same “Hull and hold inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C035-T10 · Positive evidence:** Attach the “Hull and hold inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C036 · Negative test

**Original checklist item:** Negative case: Different hold payloads are merged under one vague entry. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Hull and hold inventory” source counterexample: “Different hold payloads are merged under one vague entry”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Hull and hold inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C036-T03 · Valid control:** Construct a valid “Hull and hold inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C036-T04 · Minimal adverse input:** Derive the “Hull and hold inventory” adverse fixture from the control with the smallest documented change needed to reproduce “Different hold payloads are merged under one vague entry”; retain that change as reproducible data.
- [ ] **UC-M04.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Hull and hold inventory”; require “Bundled payloads remain traceable to their actual source versions” and forbid a false-success verdict.
- [ ] **UC-M04.06-C036-T06 · Adverse execution:** Exercise the “Hull and hold inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C036-T07 · Effect inspection:** Inspect “Hull and hold inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C036-T08 · Refusal versus failure:** Confirm the “Hull and hold inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C036-T09 · Reset and retention:** Restore only the disposable “Hull and hold inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C036-T10 · Negative regression:** Register the “Hull and hold inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C037 · Change / failure test

**Original checklist item:** Exercise hull and hold inventory when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C037-T01 · Scenario record:** Write the “Hull and hold inventory” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “Bundled payloads remain traceable to their actual source versions”.
- [ ] **UC-M04.06-C037-T02 · Baseline capture:** Create a known-valid “Hull and hold inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C037-T03 · Injection map:** Locate the “Hull and hold inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Hull and hold inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C037-T05 · Controlled trigger:** Introduce the controlled “Hull and hold inventory” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C037-T06 · Intermediate inspection:** Inspect the “Hull and hold inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Hull and hold inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Hull and hold inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C037-T09 · Repeat and compare:** Repeat the selected “Hull and hold inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C037-T10 · Failure evidence:** Publish the “Hull and hold inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for nested artifacts and archive traversal depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Hull and hold inventory”: “Nested artifacts and archive traversal depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C038-T02 · Measurement method:** Choose how to observe each “Hull and hold inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Hull and hold inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Hull and hold inventory” cases for “Nested artifacts and archive traversal depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Hull and hold inventory” limit; preserve “Bundled payloads remain traceable to their actual source versions”.
- [ ] **UC-M04.06-C038-T06 · Normal measurement:** Run or review the normal “Hull and hold inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C038-T07 · At-limit measurement:** Exercise the “Hull and hold inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C038-T08 · Over-limit measurement:** Exercise the “Hull and hold inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C038-T09 · Uncovered-scope report:** List the “Hull and hold inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C038-T10 · Limit evidence:** Publish the selected “Hull and hold inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for hull and hold inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C039-T01 · Event inventory:** List the “Hull and hold inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Hull and hold inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C039-T03 · Failure mapping:** Map each documented “Hull and hold inventory” refusal or error to a diagnostic outcome; include “Different hold payloads are merged under one vague entry” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C039-T04 · Emission path:** Add the “Hull and hold inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C039-T05 · Redaction check:** Test “Hull and hold inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C039-T06 · Output budget:** Set and exercise bounded “Hull and hold inventory” message size, rate and retention compatible with “Nested artifacts and archive traversal depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C039-T07 · Success/refusal fixtures:** Capture “Hull and hold inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Hull and hold inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C039-T09 · Operator review:** Read the “Hull and hold inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C039-T10 · Diagnostic evidence:** Publish redacted “Hull and hold inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for hull and hold inventory; label unexecuted checks as untested.

- [ ] **UC-M04.06-C040-T01 · Evidence inventory:** List the “Hull and hold inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C040-T02 · Artifact references:** Record the exact “Hull and hold inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C040-T03 · Fixture references:** Attach the “Hull and hold inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “Different hold payloads are merged under one vague entry” as a distinct evidence case.
- [ ] **UC-M04.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Hull and hold inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C040-T05 · Environment record:** Record the actual “Hull and hold inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C040-T06 · Expected versus observed:** Pair every “Hull and hold inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C040-T07 · Failure and limit records:** Attach “Hull and hold inventory” change/failure and bounds evidence where required; include uncovered “Nested artifacts and archive traversal depth” and unresolved violations of “Bundled payloads remain traceable to their actual source versions”.
- [ ] **UC-M04.06-C040-T08 · Evidence hygiene:** Check the “Hull and hold inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C040-T09 · Reproduction review:** Have the “Hull and hold inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C040-T10 · Acceptance linkage:** Link the “Hull and hold inventory” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Source provenance mapping

**Source delivery:** Associate each dependency record with its source or distribution origin.

**Source invariant:** An operator can identify where an included component came from.

**Source negative case:** An artifact has a digest but no reviewable source relationship.

**Source bounded quantities:** Source links and provenance chain depth.

### UC-M04.06-C041 · Contract

**Original checklist item:** Specify source provenance mapping inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C041-T01 · Scope statement:** Draft the operation boundary for “Source provenance mapping” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Source provenance mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C041-T03 · Output inventory:** List the outputs of “Source provenance mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Source provenance mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C041-T05 · Prerequisite contract:** Map “Source provenance mapping” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Source provenance mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C041-T07 · Invariant clause:** Add a normative clause for “Source provenance mapping” that preserves “An operator can identify where an included component came from”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Source provenance mapping”; include the source counterexample “An artifact has a digest but no reviewable source relationship” and the intended safe disposition.
- [ ] **UC-M04.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Source links and provenance chain depth” in the “Source provenance mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C041-T10 · Contract review:** Review the “Source provenance mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C042 · Delivery

**Original checklist item:** Associate each dependency record with its source or distribution origin.

- [ ] **UC-M04.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Source provenance mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C042-T02 · Change plan:** Break the source delivery for “Source provenance mapping” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Source provenance mapping” that realizes this source instruction: Associate each dependency record with its source or distribution origin.
- [ ] **UC-M04.06-C042-T04 · Concrete realization:** Trace “Source provenance mapping” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Source provenance mapping” needed to preserve “An operator can identify where an included component came from”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C042-T06 · Dependency connection:** Connect the “Source provenance mapping” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C042-T07 · Resource behavior:** Account for “Source links and provenance chain depth” in “Source provenance mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C042-T08 · Delivery check:** Run the smallest real “Source provenance mapping” path and its adverse fixture “An artifact has a digest but no reviewable source relationship”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C042-T09 · Patch review:** Review the “Source provenance mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C042-T10 · Delivery handoff:** Publish the “Source provenance mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An operator can identify where an included component came from. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Source provenance mapping”; copy its required invariant exactly: “An operator can identify where an included component came from”.
- [ ] **UC-M04.06-C043-T02 · Observable terms:** Define each term in the “Source provenance mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C043-T03 · Precondition set:** List the preconditions under which “An operator can identify where an included component came from” must hold for “Source provenance mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C043-T04 · Transition coverage:** Map the “Source provenance mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Source provenance mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C043-T06 · Satisfying fixture:** Create a concrete “Source provenance mapping” case that satisfies “An operator can identify where an included component came from”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C043-T07 · Violating fixture:** Create the source counterexample “An artifact has a digest but no reviewable source relationship” for “Source provenance mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C043-T08 · Enforcement evidence:** Exercise the “Source provenance mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C043-T09 · Regression linkage:** Link the “Source provenance mapping” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Source provenance mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C044 · Integration

**Original checklist item:** Integrate source provenance mapping with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Source provenance mapping” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C044-T02 · Field mapping:** Map every “Source provenance mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Source provenance mapping” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C044-T04 · Ownership agreement:** Specify who owns “Source provenance mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C044-T05 · Handoff implementation:** Connect “Source provenance mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “An operator can identify where an included component came from” across the handoff.
- [ ] **UC-M04.06-C044-T06 · Absent-input case:** Omit one required “Source provenance mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C044-T07 · Stale-input case:** Supply an outdated “Source provenance mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Source provenance mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C044-T09 · Valid integration trace:** Run a valid “Source provenance mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C044-T10 · Seam review:** Reconcile the “Source provenance mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for source provenance mapping; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Source provenance mapping” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C045-T02 · Expected-result oracle:** Specify the “Source provenance mapping” expected result independently of the implementation output; include the property “An operator can identify where an included component came from” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C045-T03 · Fixture material:** Create the concrete “Source provenance mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C045-T04 · Target preparation:** Prepare the “Source provenance mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C045-T05 · Initial-state record:** Record the initial “Source provenance mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C045-T06 · Valid-path execution:** Execute the “Source provenance mapping” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C045-T07 · Outcome comparison:** Compare every declared “Source provenance mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C045-T08 · State and bounds check:** Inspect the “Source provenance mapping” ownership/state effects and actual use of “Source links and provenance chain depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C045-T09 · Repeatability check:** Repeat the same “Source provenance mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C045-T10 · Positive evidence:** Attach the “Source provenance mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C046 · Negative test

**Original checklist item:** Negative case: An artifact has a digest but no reviewable source relationship. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Source provenance mapping” source counterexample: “An artifact has a digest but no reviewable source relationship”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Source provenance mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C046-T03 · Valid control:** Construct a valid “Source provenance mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C046-T04 · Minimal adverse input:** Derive the “Source provenance mapping” adverse fixture from the control with the smallest documented change needed to reproduce “An artifact has a digest but no reviewable source relationship”; retain that change as reproducible data.
- [ ] **UC-M04.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Source provenance mapping”; require “An operator can identify where an included component came from” and forbid a false-success verdict.
- [ ] **UC-M04.06-C046-T06 · Adverse execution:** Exercise the “Source provenance mapping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C046-T07 · Effect inspection:** Inspect “Source provenance mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C046-T08 · Refusal versus failure:** Confirm the “Source provenance mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C046-T09 · Reset and retention:** Restore only the disposable “Source provenance mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C046-T10 · Negative regression:** Register the “Source provenance mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C047 · Change / failure test

**Original checklist item:** Exercise source provenance mapping when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C047-T01 · Scenario record:** Write the “Source provenance mapping” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “An operator can identify where an included component came from”.
- [ ] **UC-M04.06-C047-T02 · Baseline capture:** Create a known-valid “Source provenance mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C047-T03 · Injection map:** Locate the “Source provenance mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Source provenance mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C047-T05 · Controlled trigger:** Introduce the controlled “Source provenance mapping” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C047-T06 · Intermediate inspection:** Inspect the “Source provenance mapping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Source provenance mapping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Source provenance mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C047-T09 · Repeat and compare:** Repeat the selected “Source provenance mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C047-T10 · Failure evidence:** Publish the “Source provenance mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for source links and provenance chain depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Source provenance mapping”: “Source links and provenance chain depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C048-T02 · Measurement method:** Choose how to observe each “Source provenance mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C048-T03 · Budget decision:** Select justified resource and input limits for “Source provenance mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Source provenance mapping” cases for “Source links and provenance chain depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Source provenance mapping” limit; preserve “An operator can identify where an included component came from”.
- [ ] **UC-M04.06-C048-T06 · Normal measurement:** Run or review the normal “Source provenance mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C048-T07 · At-limit measurement:** Exercise the “Source provenance mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C048-T08 · Over-limit measurement:** Exercise the “Source provenance mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C048-T09 · Uncovered-scope report:** List the “Source provenance mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C048-T10 · Limit evidence:** Publish the selected “Source provenance mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for source provenance mapping with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C049-T01 · Event inventory:** List the “Source provenance mapping” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Source provenance mapping” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C049-T03 · Failure mapping:** Map each documented “Source provenance mapping” refusal or error to a diagnostic outcome; include “An artifact has a digest but no reviewable source relationship” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C049-T04 · Emission path:** Add the “Source provenance mapping” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C049-T05 · Redaction check:** Test “Source provenance mapping” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C049-T06 · Output budget:** Set and exercise bounded “Source provenance mapping” message size, rate and retention compatible with “Source links and provenance chain depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C049-T07 · Success/refusal fixtures:** Capture “Source provenance mapping” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Source provenance mapping” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C049-T09 · Operator review:** Read the “Source provenance mapping” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C049-T10 · Diagnostic evidence:** Publish redacted “Source provenance mapping” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for source provenance mapping; label unexecuted checks as untested.

- [ ] **UC-M04.06-C050-T01 · Evidence inventory:** List the “Source provenance mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C050-T02 · Artifact references:** Record the exact “Source provenance mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C050-T03 · Fixture references:** Attach the “Source provenance mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “An artifact has a digest but no reviewable source relationship” as a distinct evidence case.
- [ ] **UC-M04.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Source provenance mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C050-T05 · Environment record:** Record the actual “Source provenance mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C050-T06 · Expected versus observed:** Pair every “Source provenance mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C050-T07 · Failure and limit records:** Attach “Source provenance mapping” change/failure and bounds evidence where required; include uncovered “Source links and provenance chain depth” and unresolved violations of “An operator can identify where an included component came from”.
- [ ] **UC-M04.06-C050-T08 · Evidence hygiene:** Check the “Source provenance mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C050-T09 · Reproduction review:** Have the “Source provenance mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C050-T10 · Acceptance linkage:** Link the “Source provenance mapping” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. License evidence collection

**Source delivery:** Collect the license texts or documented license statements supplied with dependencies.

**Source invariant:** Unknown licensing remains an explicit review gap rather than an invented conclusion.

**Source negative case:** A dependency is assigned a license without source evidence.

**Source bounded quantities:** License files and retained evidence bytes.

### UC-M04.06-C051 · Contract

**Original checklist item:** Specify license evidence collection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C051-T01 · Scope statement:** Draft the operation boundary for “License evidence collection” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “License evidence collection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C051-T03 · Output inventory:** List the outputs of “License evidence collection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “License evidence collection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C051-T05 · Prerequisite contract:** Map “License evidence collection” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C051-T06 · Authority map:** Identify who may produce, change and consume “License evidence collection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C051-T07 · Invariant clause:** Add a normative clause for “License evidence collection” that preserves “Unknown licensing remains an explicit review gap rather than an invented conclusion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “License evidence collection”; include the source counterexample “A dependency is assigned a license without source evidence” and the intended safe disposition.
- [ ] **UC-M04.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “License files and retained evidence bytes” in the “License evidence collection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C051-T10 · Contract review:** Review the “License evidence collection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C052 · Delivery

**Original checklist item:** Collect the license texts or documented license statements supplied with dependencies.

- [ ] **UC-M04.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “License evidence collection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C052-T02 · Change plan:** Break the source delivery for “License evidence collection” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C052-T03 · Core artifact:** Create the “License evidence collection” output artifact for this source instruction: Collect the license texts or documented license statements supplied with dependencies.
- [ ] **UC-M04.06-C052-T04 · Concrete realization:** Populate the “License evidence collection” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M04.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “License evidence collection” needed to preserve “Unknown licensing remains an explicit review gap rather than an invented conclusion”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C052-T06 · Dependency connection:** Connect the “License evidence collection” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C052-T07 · Resource behavior:** Account for “License files and retained evidence bytes” in “License evidence collection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C052-T08 · Delivery check:** Run the smallest real “License evidence collection” path and its adverse fixture “A dependency is assigned a license without source evidence”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C052-T09 · Patch review:** Review the “License evidence collection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C052-T10 · Delivery handoff:** Publish the “License evidence collection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown licensing remains an explicit review gap rather than an invented conclusion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “License evidence collection”; copy its required invariant exactly: “Unknown licensing remains an explicit review gap rather than an invented conclusion”.
- [ ] **UC-M04.06-C053-T02 · Observable terms:** Define each term in the “License evidence collection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C053-T03 · Precondition set:** List the preconditions under which “Unknown licensing remains an explicit review gap rather than an invented conclusion” must hold for “License evidence collection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C053-T04 · Transition coverage:** Map the “License evidence collection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “License evidence collection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C053-T06 · Satisfying fixture:** Create a concrete “License evidence collection” case that satisfies “Unknown licensing remains an explicit review gap rather than an invented conclusion”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C053-T07 · Violating fixture:** Create the source counterexample “A dependency is assigned a license without source evidence” for “License evidence collection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C053-T08 · Enforcement evidence:** Exercise the “License evidence collection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C053-T09 · Regression linkage:** Link the “License evidence collection” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C053-T10 · Property disposition:** Compare the satisfying and violating “License evidence collection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C054 · Integration

**Original checklist item:** Integrate license evidence collection with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “License evidence collection” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C054-T02 · Field mapping:** Map every “License evidence collection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “License evidence collection” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C054-T04 · Ownership agreement:** Specify who owns “License evidence collection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C054-T05 · Handoff implementation:** Connect “License evidence collection” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown licensing remains an explicit review gap rather than an invented conclusion” across the handoff.
- [ ] **UC-M04.06-C054-T06 · Absent-input case:** Omit one required “License evidence collection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C054-T07 · Stale-input case:** Supply an outdated “License evidence collection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C054-T08 · Incompatible-input case:** Supply an incompatible “License evidence collection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C054-T09 · Valid integration trace:** Run a valid “License evidence collection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C054-T10 · Seam review:** Reconcile the “License evidence collection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for license evidence collection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “License evidence collection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C055-T02 · Expected-result oracle:** Specify the “License evidence collection” expected result independently of the implementation output; include the property “Unknown licensing remains an explicit review gap rather than an invented conclusion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C055-T03 · Fixture material:** Create the concrete “License evidence collection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C055-T04 · Target preparation:** Prepare the “License evidence collection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C055-T05 · Initial-state record:** Record the initial “License evidence collection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C055-T06 · Valid-path execution:** Execute the “License evidence collection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C055-T07 · Outcome comparison:** Compare every declared “License evidence collection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C055-T08 · State and bounds check:** Inspect the “License evidence collection” ownership/state effects and actual use of “License files and retained evidence bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C055-T09 · Repeatability check:** Repeat the same “License evidence collection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C055-T10 · Positive evidence:** Attach the “License evidence collection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C056 · Negative test

**Original checklist item:** Negative case: A dependency is assigned a license without source evidence. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “License evidence collection” source counterexample: “A dependency is assigned a license without source evidence”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “License evidence collection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C056-T03 · Valid control:** Construct a valid “License evidence collection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C056-T04 · Minimal adverse input:** Derive the “License evidence collection” adverse fixture from the control with the smallest documented change needed to reproduce “A dependency is assigned a license without source evidence”; retain that change as reproducible data.
- [ ] **UC-M04.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “License evidence collection”; require “Unknown licensing remains an explicit review gap rather than an invented conclusion” and forbid a false-success verdict.
- [ ] **UC-M04.06-C056-T06 · Adverse execution:** Exercise the “License evidence collection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C056-T07 · Effect inspection:** Inspect “License evidence collection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C056-T08 · Refusal versus failure:** Confirm the “License evidence collection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C056-T09 · Reset and retention:** Restore only the disposable “License evidence collection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C056-T10 · Negative regression:** Register the “License evidence collection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C057 · Change / failure test

**Original checklist item:** Exercise license evidence collection when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C057-T01 · Scenario record:** Write the “License evidence collection” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “Unknown licensing remains an explicit review gap rather than an invented conclusion”.
- [ ] **UC-M04.06-C057-T02 · Baseline capture:** Create a known-valid “License evidence collection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C057-T03 · Injection map:** Locate the “License evidence collection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “License evidence collection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C057-T05 · Controlled trigger:** Introduce the controlled “License evidence collection” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C057-T06 · Intermediate inspection:** Inspect the “License evidence collection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “License evidence collection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “License evidence collection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C057-T09 · Repeat and compare:** Repeat the selected “License evidence collection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C057-T10 · Failure evidence:** Publish the “License evidence collection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for license files and retained evidence bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “License evidence collection”: “License files and retained evidence bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C058-T02 · Measurement method:** Choose how to observe each “License evidence collection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C058-T03 · Budget decision:** Select justified resource and input limits for “License evidence collection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “License evidence collection” cases for “License files and retained evidence bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “License evidence collection” limit; preserve “Unknown licensing remains an explicit review gap rather than an invented conclusion”.
- [ ] **UC-M04.06-C058-T06 · Normal measurement:** Run or review the normal “License evidence collection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C058-T07 · At-limit measurement:** Exercise the “License evidence collection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C058-T08 · Over-limit measurement:** Exercise the “License evidence collection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C058-T09 · Uncovered-scope report:** List the “License evidence collection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C058-T10 · Limit evidence:** Publish the selected “License evidence collection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for license evidence collection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C059-T01 · Event inventory:** List the “License evidence collection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “License evidence collection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C059-T03 · Failure mapping:** Map each documented “License evidence collection” refusal or error to a diagnostic outcome; include “A dependency is assigned a license without source evidence” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C059-T04 · Emission path:** Add the “License evidence collection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C059-T05 · Redaction check:** Test “License evidence collection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C059-T06 · Output budget:** Set and exercise bounded “License evidence collection” message size, rate and retention compatible with “License files and retained evidence bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C059-T07 · Success/refusal fixtures:** Capture “License evidence collection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “License evidence collection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C059-T09 · Operator review:** Read the “License evidence collection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C059-T10 · Diagnostic evidence:** Publish redacted “License evidence collection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for license evidence collection; label unexecuted checks as untested.

- [ ] **UC-M04.06-C060-T01 · Evidence inventory:** List the “License evidence collection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C060-T02 · Artifact references:** Record the exact “License evidence collection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C060-T03 · Fixture references:** Attach the “License evidence collection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A dependency is assigned a license without source evidence” as a distinct evidence case.
- [ ] **UC-M04.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “License evidence collection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C060-T05 · Environment record:** Record the actual “License evidence collection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C060-T06 · Expected versus observed:** Pair every “License evidence collection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C060-T07 · Failure and limit records:** Attach “License evidence collection” change/failure and bounds evidence where required; include uncovered “License files and retained evidence bytes” and unresolved violations of “Unknown licensing remains an explicit review gap rather than an invented conclusion”.
- [ ] **UC-M04.06-C060-T08 · Evidence hygiene:** Check the “License evidence collection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C060-T09 · Reproduction review:** Have the “License evidence collection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C060-T10 · Acceptance linkage:** Link the “License evidence collection” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Generated artifact mapping

**Source delivery:** Map built executables and guest images back to contributing component records.

**Source invariant:** A generated binary retains its dependency inventory relationships.

**Source negative case:** A rebuilt image is detached from its library inventory.

**Source bounded quantities:** Artifact-to-component edges and graph size.

### UC-M04.06-C061 · Contract

**Original checklist item:** Specify generated artifact mapping inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C061-T01 · Scope statement:** Draft the operation boundary for “Generated artifact mapping” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Generated artifact mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C061-T03 · Output inventory:** List the outputs of “Generated artifact mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Generated artifact mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C061-T05 · Prerequisite contract:** Map “Generated artifact mapping” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Generated artifact mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C061-T07 · Invariant clause:** Add a normative clause for “Generated artifact mapping” that preserves “A generated binary retains its dependency inventory relationships”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Generated artifact mapping”; include the source counterexample “A rebuilt image is detached from its library inventory” and the intended safe disposition.
- [ ] **UC-M04.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Artifact-to-component edges and graph size” in the “Generated artifact mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C061-T10 · Contract review:** Review the “Generated artifact mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C062 · Delivery

**Original checklist item:** Map built executables and guest images back to contributing component records.

- [ ] **UC-M04.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Generated artifact mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C062-T02 · Change plan:** Break the source delivery for “Generated artifact mapping” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C062-T03 · Core artifact:** Create the “Generated artifact mapping” model, schema or inventory that realizes this source instruction: Map built executables and guest images back to contributing component records.
- [ ] **UC-M04.06-C062-T04 · Concrete realization:** Populate “Generated artifact mapping” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Generated artifact mapping” needed to preserve “A generated binary retains its dependency inventory relationships”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C062-T06 · Dependency connection:** Connect the “Generated artifact mapping” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C062-T07 · Resource behavior:** Account for “Artifact-to-component edges and graph size” in “Generated artifact mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C062-T08 · Delivery check:** Run the smallest real “Generated artifact mapping” path and its adverse fixture “A rebuilt image is detached from its library inventory”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C062-T09 · Patch review:** Review the “Generated artifact mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C062-T10 · Delivery handoff:** Publish the “Generated artifact mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A generated binary retains its dependency inventory relationships. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Generated artifact mapping”; copy its required invariant exactly: “A generated binary retains its dependency inventory relationships”.
- [ ] **UC-M04.06-C063-T02 · Observable terms:** Define each term in the “Generated artifact mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C063-T03 · Precondition set:** List the preconditions under which “A generated binary retains its dependency inventory relationships” must hold for “Generated artifact mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C063-T04 · Transition coverage:** Map the “Generated artifact mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Generated artifact mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C063-T06 · Satisfying fixture:** Create a concrete “Generated artifact mapping” case that satisfies “A generated binary retains its dependency inventory relationships”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C063-T07 · Violating fixture:** Create the source counterexample “A rebuilt image is detached from its library inventory” for “Generated artifact mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C063-T08 · Enforcement evidence:** Exercise the “Generated artifact mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C063-T09 · Regression linkage:** Link the “Generated artifact mapping” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Generated artifact mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C064 · Integration

**Original checklist item:** Integrate generated artifact mapping with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Generated artifact mapping” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C064-T02 · Field mapping:** Map every “Generated artifact mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Generated artifact mapping” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C064-T04 · Ownership agreement:** Specify who owns “Generated artifact mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C064-T05 · Handoff implementation:** Connect “Generated artifact mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “A generated binary retains its dependency inventory relationships” across the handoff.
- [ ] **UC-M04.06-C064-T06 · Absent-input case:** Omit one required “Generated artifact mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C064-T07 · Stale-input case:** Supply an outdated “Generated artifact mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Generated artifact mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C064-T09 · Valid integration trace:** Run a valid “Generated artifact mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C064-T10 · Seam review:** Reconcile the “Generated artifact mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for generated artifact mapping; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Generated artifact mapping” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C065-T02 · Expected-result oracle:** Specify the “Generated artifact mapping” expected result independently of the implementation output; include the property “A generated binary retains its dependency inventory relationships” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C065-T03 · Fixture material:** Create the concrete “Generated artifact mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C065-T04 · Target preparation:** Prepare the “Generated artifact mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C065-T05 · Initial-state record:** Record the initial “Generated artifact mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C065-T06 · Valid-path execution:** Execute the “Generated artifact mapping” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C065-T07 · Outcome comparison:** Compare every declared “Generated artifact mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C065-T08 · State and bounds check:** Inspect the “Generated artifact mapping” ownership/state effects and actual use of “Artifact-to-component edges and graph size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C065-T09 · Repeatability check:** Repeat the same “Generated artifact mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C065-T10 · Positive evidence:** Attach the “Generated artifact mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C066 · Negative test

**Original checklist item:** Negative case: A rebuilt image is detached from its library inventory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Generated artifact mapping” source counterexample: “A rebuilt image is detached from its library inventory”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Generated artifact mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C066-T03 · Valid control:** Construct a valid “Generated artifact mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C066-T04 · Minimal adverse input:** Derive the “Generated artifact mapping” adverse fixture from the control with the smallest documented change needed to reproduce “A rebuilt image is detached from its library inventory”; retain that change as reproducible data.
- [ ] **UC-M04.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Generated artifact mapping”; require “A generated binary retains its dependency inventory relationships” and forbid a false-success verdict.
- [ ] **UC-M04.06-C066-T06 · Adverse execution:** Exercise the “Generated artifact mapping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C066-T07 · Effect inspection:** Inspect “Generated artifact mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C066-T08 · Refusal versus failure:** Confirm the “Generated artifact mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C066-T09 · Reset and retention:** Restore only the disposable “Generated artifact mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C066-T10 · Negative regression:** Register the “Generated artifact mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C067 · Change / failure test

**Original checklist item:** Exercise generated artifact mapping when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C067-T01 · Scenario record:** Write the “Generated artifact mapping” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “A generated binary retains its dependency inventory relationships”.
- [ ] **UC-M04.06-C067-T02 · Baseline capture:** Create a known-valid “Generated artifact mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C067-T03 · Injection map:** Locate the “Generated artifact mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Generated artifact mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C067-T05 · Controlled trigger:** Introduce the controlled “Generated artifact mapping” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C067-T06 · Intermediate inspection:** Inspect the “Generated artifact mapping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Generated artifact mapping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Generated artifact mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C067-T09 · Repeat and compare:** Repeat the selected “Generated artifact mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C067-T10 · Failure evidence:** Publish the “Generated artifact mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for artifact-to-component edges and graph size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Generated artifact mapping”: “Artifact-to-component edges and graph size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C068-T02 · Measurement method:** Choose how to observe each “Generated artifact mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Generated artifact mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Generated artifact mapping” cases for “Artifact-to-component edges and graph size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Generated artifact mapping” limit; preserve “A generated binary retains its dependency inventory relationships”.
- [ ] **UC-M04.06-C068-T06 · Normal measurement:** Run or review the normal “Generated artifact mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C068-T07 · At-limit measurement:** Exercise the “Generated artifact mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C068-T08 · Over-limit measurement:** Exercise the “Generated artifact mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C068-T09 · Uncovered-scope report:** List the “Generated artifact mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C068-T10 · Limit evidence:** Publish the selected “Generated artifact mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for generated artifact mapping with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C069-T01 · Event inventory:** List the “Generated artifact mapping” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Generated artifact mapping” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C069-T03 · Failure mapping:** Map each documented “Generated artifact mapping” refusal or error to a diagnostic outcome; include “A rebuilt image is detached from its library inventory” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C069-T04 · Emission path:** Add the “Generated artifact mapping” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C069-T05 · Redaction check:** Test “Generated artifact mapping” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C069-T06 · Output budget:** Set and exercise bounded “Generated artifact mapping” message size, rate and retention compatible with “Artifact-to-component edges and graph size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C069-T07 · Success/refusal fixtures:** Capture “Generated artifact mapping” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Generated artifact mapping” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C069-T09 · Operator review:** Read the “Generated artifact mapping” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C069-T10 · Diagnostic evidence:** Publish redacted “Generated artifact mapping” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for generated artifact mapping; label unexecuted checks as untested.

- [ ] **UC-M04.06-C070-T01 · Evidence inventory:** List the “Generated artifact mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C070-T02 · Artifact references:** Record the exact “Generated artifact mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C070-T03 · Fixture references:** Attach the “Generated artifact mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “A rebuilt image is detached from its library inventory” as a distinct evidence case.
- [ ] **UC-M04.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Generated artifact mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C070-T05 · Environment record:** Record the actual “Generated artifact mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C070-T06 · Expected versus observed:** Pair every “Generated artifact mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C070-T07 · Failure and limit records:** Attach “Generated artifact mapping” change/failure and bounds evidence where required; include uncovered “Artifact-to-component edges and graph size” and unresolved violations of “A generated binary retains its dependency inventory relationships”.
- [ ] **UC-M04.06-C070-T08 · Evidence hygiene:** Check the “Generated artifact mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C070-T09 · Reproduction review:** Have the “Generated artifact mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C070-T10 · Acceptance linkage:** Link the “Generated artifact mapping” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Inventory completeness checks

**Source delivery:** Reconcile shipped files and linked dependencies against inventory coverage.

**Source invariant:** Every shipped runtime dependency is accounted for or explicitly blocked.

**Source negative case:** An extra binary appears in packaging after inventory generation.

**Source bounded quantities:** Packaged files and comparison runtime.

### UC-M04.06-C071 · Contract

**Original checklist item:** Specify inventory completeness checks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C071-T01 · Scope statement:** Draft the operation boundary for “Inventory completeness checks” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Inventory completeness checks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C071-T03 · Output inventory:** List the outputs of “Inventory completeness checks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Inventory completeness checks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C071-T05 · Prerequisite contract:** Map “Inventory completeness checks” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Inventory completeness checks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C071-T07 · Invariant clause:** Add a normative clause for “Inventory completeness checks” that preserves “Every shipped runtime dependency is accounted for or explicitly blocked”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Inventory completeness checks”; include the source counterexample “An extra binary appears in packaging after inventory generation” and the intended safe disposition.
- [ ] **UC-M04.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Packaged files and comparison runtime” in the “Inventory completeness checks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C071-T10 · Contract review:** Review the “Inventory completeness checks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C072 · Delivery

**Original checklist item:** Reconcile shipped files and linked dependencies against inventory coverage.

- [ ] **UC-M04.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Inventory completeness checks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C072-T02 · Change plan:** Break the source delivery for “Inventory completeness checks” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Inventory completeness checks” that realizes this source instruction: Reconcile shipped files and linked dependencies against inventory coverage.
- [ ] **UC-M04.06-C072-T04 · Concrete realization:** Trace “Inventory completeness checks” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Inventory completeness checks” needed to preserve “Every shipped runtime dependency is accounted for or explicitly blocked”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C072-T06 · Dependency connection:** Connect the “Inventory completeness checks” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C072-T07 · Resource behavior:** Account for “Packaged files and comparison runtime” in “Inventory completeness checks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C072-T08 · Delivery check:** Run the smallest real “Inventory completeness checks” path and its adverse fixture “An extra binary appears in packaging after inventory generation”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C072-T09 · Patch review:** Review the “Inventory completeness checks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C072-T10 · Delivery handoff:** Publish the “Inventory completeness checks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every shipped runtime dependency is accounted for or explicitly blocked. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Inventory completeness checks”; copy its required invariant exactly: “Every shipped runtime dependency is accounted for or explicitly blocked”.
- [ ] **UC-M04.06-C073-T02 · Observable terms:** Define each term in the “Inventory completeness checks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C073-T03 · Precondition set:** List the preconditions under which “Every shipped runtime dependency is accounted for or explicitly blocked” must hold for “Inventory completeness checks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C073-T04 · Transition coverage:** Map the “Inventory completeness checks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Inventory completeness checks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C073-T06 · Satisfying fixture:** Create a concrete “Inventory completeness checks” case that satisfies “Every shipped runtime dependency is accounted for or explicitly blocked”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C073-T07 · Violating fixture:** Create the source counterexample “An extra binary appears in packaging after inventory generation” for “Inventory completeness checks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C073-T08 · Enforcement evidence:** Exercise the “Inventory completeness checks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C073-T09 · Regression linkage:** Link the “Inventory completeness checks” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Inventory completeness checks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C074 · Integration

**Original checklist item:** Integrate inventory completeness checks with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Inventory completeness checks” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C074-T02 · Field mapping:** Map every “Inventory completeness checks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Inventory completeness checks” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C074-T04 · Ownership agreement:** Specify who owns “Inventory completeness checks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C074-T05 · Handoff implementation:** Connect “Inventory completeness checks” through the mapped seam using the real adapter or explicit specification reference; preserve “Every shipped runtime dependency is accounted for or explicitly blocked” across the handoff.
- [ ] **UC-M04.06-C074-T06 · Absent-input case:** Omit one required “Inventory completeness checks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C074-T07 · Stale-input case:** Supply an outdated “Inventory completeness checks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Inventory completeness checks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C074-T09 · Valid integration trace:** Run a valid “Inventory completeness checks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C074-T10 · Seam review:** Reconcile the “Inventory completeness checks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for inventory completeness checks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Inventory completeness checks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C075-T02 · Expected-result oracle:** Specify the “Inventory completeness checks” expected result independently of the implementation output; include the property “Every shipped runtime dependency is accounted for or explicitly blocked” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C075-T03 · Fixture material:** Create the concrete “Inventory completeness checks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C075-T04 · Target preparation:** Prepare the “Inventory completeness checks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C075-T05 · Initial-state record:** Record the initial “Inventory completeness checks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C075-T06 · Valid-path execution:** Execute the “Inventory completeness checks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C075-T07 · Outcome comparison:** Compare every declared “Inventory completeness checks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C075-T08 · State and bounds check:** Inspect the “Inventory completeness checks” ownership/state effects and actual use of “Packaged files and comparison runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C075-T09 · Repeatability check:** Repeat the same “Inventory completeness checks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C075-T10 · Positive evidence:** Attach the “Inventory completeness checks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C076 · Negative test

**Original checklist item:** Negative case: An extra binary appears in packaging after inventory generation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Inventory completeness checks” source counterexample: “An extra binary appears in packaging after inventory generation”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Inventory completeness checks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C076-T03 · Valid control:** Construct a valid “Inventory completeness checks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C076-T04 · Minimal adverse input:** Derive the “Inventory completeness checks” adverse fixture from the control with the smallest documented change needed to reproduce “An extra binary appears in packaging after inventory generation”; retain that change as reproducible data.
- [ ] **UC-M04.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Inventory completeness checks”; require “Every shipped runtime dependency is accounted for or explicitly blocked” and forbid a false-success verdict.
- [ ] **UC-M04.06-C076-T06 · Adverse execution:** Exercise the “Inventory completeness checks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C076-T07 · Effect inspection:** Inspect “Inventory completeness checks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C076-T08 · Refusal versus failure:** Confirm the “Inventory completeness checks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C076-T09 · Reset and retention:** Restore only the disposable “Inventory completeness checks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C076-T10 · Negative regression:** Register the “Inventory completeness checks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C077 · Change / failure test

**Original checklist item:** Exercise inventory completeness checks when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C077-T01 · Scenario record:** Write the “Inventory completeness checks” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “Every shipped runtime dependency is accounted for or explicitly blocked”.
- [ ] **UC-M04.06-C077-T02 · Baseline capture:** Create a known-valid “Inventory completeness checks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C077-T03 · Injection map:** Locate the “Inventory completeness checks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Inventory completeness checks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C077-T05 · Controlled trigger:** Introduce the controlled “Inventory completeness checks” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C077-T06 · Intermediate inspection:** Inspect the “Inventory completeness checks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Inventory completeness checks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Inventory completeness checks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C077-T09 · Repeat and compare:** Repeat the selected “Inventory completeness checks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C077-T10 · Failure evidence:** Publish the “Inventory completeness checks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for packaged files and comparison runtime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Inventory completeness checks”: “Packaged files and comparison runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C078-T02 · Measurement method:** Choose how to observe each “Inventory completeness checks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C078-T03 · Budget decision:** Select justified resource and input limits for “Inventory completeness checks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Inventory completeness checks” cases for “Packaged files and comparison runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Inventory completeness checks” limit; preserve “Every shipped runtime dependency is accounted for or explicitly blocked”.
- [ ] **UC-M04.06-C078-T06 · Normal measurement:** Run or review the normal “Inventory completeness checks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C078-T07 · At-limit measurement:** Exercise the “Inventory completeness checks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C078-T08 · Over-limit measurement:** Exercise the “Inventory completeness checks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C078-T09 · Uncovered-scope report:** List the “Inventory completeness checks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C078-T10 · Limit evidence:** Publish the selected “Inventory completeness checks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for inventory completeness checks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C079-T01 · Event inventory:** List the “Inventory completeness checks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Inventory completeness checks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C079-T03 · Failure mapping:** Map each documented “Inventory completeness checks” refusal or error to a diagnostic outcome; include “An extra binary appears in packaging after inventory generation” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C079-T04 · Emission path:** Add the “Inventory completeness checks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C079-T05 · Redaction check:** Test “Inventory completeness checks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C079-T06 · Output budget:** Set and exercise bounded “Inventory completeness checks” message size, rate and retention compatible with “Packaged files and comparison runtime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C079-T07 · Success/refusal fixtures:** Capture “Inventory completeness checks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Inventory completeness checks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C079-T09 · Operator review:** Read the “Inventory completeness checks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C079-T10 · Diagnostic evidence:** Publish redacted “Inventory completeness checks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for inventory completeness checks; label unexecuted checks as untested.

- [ ] **UC-M04.06-C080-T01 · Evidence inventory:** List the “Inventory completeness checks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C080-T02 · Artifact references:** Record the exact “Inventory completeness checks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C080-T03 · Fixture references:** Attach the “Inventory completeness checks” fixture IDs, input identities and oracle definition; preserve the source counterexample “An extra binary appears in packaging after inventory generation” as a distinct evidence case.
- [ ] **UC-M04.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Inventory completeness checks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C080-T05 · Environment record:** Record the actual “Inventory completeness checks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C080-T06 · Expected versus observed:** Pair every “Inventory completeness checks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C080-T07 · Failure and limit records:** Attach “Inventory completeness checks” change/failure and bounds evidence where required; include uncovered “Packaged files and comparison runtime” and unresolved violations of “Every shipped runtime dependency is accounted for or explicitly blocked”.
- [ ] **UC-M04.06-C080-T08 · Evidence hygiene:** Check the “Inventory completeness checks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C080-T09 · Reproduction review:** Have the “Inventory completeness checks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C080-T10 · Acceptance linkage:** Link the “Inventory completeness checks” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Review workflow

**Source delivery:** Provide review states and recorded exceptions for unresolved provenance or license fields.

**Source invariant:** Unreviewed gaps cannot appear as completed inventory approval.

**Source negative case:** A missing source record is silently marked reviewed.

**Source bounded quantities:** Review backlog and unresolved exceptions.

### UC-M04.06-C081 · Contract

**Original checklist item:** Specify review workflow inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C081-T01 · Scope statement:** Draft the operation boundary for “Review workflow” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Review workflow”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C081-T03 · Output inventory:** List the outputs of “Review workflow” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Review workflow”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C081-T05 · Prerequisite contract:** Map “Review workflow” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Review workflow”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C081-T07 · Invariant clause:** Add a normative clause for “Review workflow” that preserves “Unreviewed gaps cannot appear as completed inventory approval”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Review workflow”; include the source counterexample “A missing source record is silently marked reviewed” and the intended safe disposition.
- [ ] **UC-M04.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Review backlog and unresolved exceptions” in the “Review workflow” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C081-T10 · Contract review:** Review the “Review workflow” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C082 · Delivery

**Original checklist item:** Provide review states and recorded exceptions for unresolved provenance or license fields.

- [ ] **UC-M04.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Review workflow”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C082-T02 · Change plan:** Break the source delivery for “Review workflow” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Review workflow” that realizes this source instruction: Provide review states and recorded exceptions for unresolved provenance or license fields.
- [ ] **UC-M04.06-C082-T04 · Concrete realization:** Trace “Review workflow” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Review workflow” needed to preserve “Unreviewed gaps cannot appear as completed inventory approval”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C082-T06 · Dependency connection:** Connect the “Review workflow” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C082-T07 · Resource behavior:** Account for “Review backlog and unresolved exceptions” in “Review workflow”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C082-T08 · Delivery check:** Run the smallest real “Review workflow” path and its adverse fixture “A missing source record is silently marked reviewed”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C082-T09 · Patch review:** Review the “Review workflow” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C082-T10 · Delivery handoff:** Publish the “Review workflow” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unreviewed gaps cannot appear as completed inventory approval. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Review workflow”; copy its required invariant exactly: “Unreviewed gaps cannot appear as completed inventory approval”.
- [ ] **UC-M04.06-C083-T02 · Observable terms:** Define each term in the “Review workflow” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C083-T03 · Precondition set:** List the preconditions under which “Unreviewed gaps cannot appear as completed inventory approval” must hold for “Review workflow”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C083-T04 · Transition coverage:** Map the “Review workflow” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Review workflow”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C083-T06 · Satisfying fixture:** Create a concrete “Review workflow” case that satisfies “Unreviewed gaps cannot appear as completed inventory approval”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C083-T07 · Violating fixture:** Create the source counterexample “A missing source record is silently marked reviewed” for “Review workflow”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C083-T08 · Enforcement evidence:** Exercise the “Review workflow” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C083-T09 · Regression linkage:** Link the “Review workflow” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Review workflow” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C084 · Integration

**Original checklist item:** Integrate review workflow with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Review workflow” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C084-T02 · Field mapping:** Map every “Review workflow” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Review workflow” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C084-T04 · Ownership agreement:** Specify who owns “Review workflow” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C084-T05 · Handoff implementation:** Connect “Review workflow” through the mapped seam using the real adapter or explicit specification reference; preserve “Unreviewed gaps cannot appear as completed inventory approval” across the handoff.
- [ ] **UC-M04.06-C084-T06 · Absent-input case:** Omit one required “Review workflow” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C084-T07 · Stale-input case:** Supply an outdated “Review workflow” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Review workflow” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C084-T09 · Valid integration trace:** Run a valid “Review workflow” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C084-T10 · Seam review:** Reconcile the “Review workflow” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for review workflow; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Review workflow” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C085-T02 · Expected-result oracle:** Specify the “Review workflow” expected result independently of the implementation output; include the property “Unreviewed gaps cannot appear as completed inventory approval” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C085-T03 · Fixture material:** Create the concrete “Review workflow” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C085-T04 · Target preparation:** Prepare the “Review workflow” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C085-T05 · Initial-state record:** Record the initial “Review workflow” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C085-T06 · Valid-path execution:** Execute the “Review workflow” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C085-T07 · Outcome comparison:** Compare every declared “Review workflow” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C085-T08 · State and bounds check:** Inspect the “Review workflow” ownership/state effects and actual use of “Review backlog and unresolved exceptions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C085-T09 · Repeatability check:** Repeat the same “Review workflow” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C085-T10 · Positive evidence:** Attach the “Review workflow” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C086 · Negative test

**Original checklist item:** Negative case: A missing source record is silently marked reviewed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Review workflow” source counterexample: “A missing source record is silently marked reviewed”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Review workflow”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C086-T03 · Valid control:** Construct a valid “Review workflow” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C086-T04 · Minimal adverse input:** Derive the “Review workflow” adverse fixture from the control with the smallest documented change needed to reproduce “A missing source record is silently marked reviewed”; retain that change as reproducible data.
- [ ] **UC-M04.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Review workflow”; require “Unreviewed gaps cannot appear as completed inventory approval” and forbid a false-success verdict.
- [ ] **UC-M04.06-C086-T06 · Adverse execution:** Exercise the “Review workflow” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C086-T07 · Effect inspection:** Inspect “Review workflow” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C086-T08 · Refusal versus failure:** Confirm the “Review workflow” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C086-T09 · Reset and retention:** Restore only the disposable “Review workflow” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C086-T10 · Negative regression:** Register the “Review workflow” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C087 · Change / failure test

**Original checklist item:** Exercise review workflow when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C087-T01 · Scenario record:** Write the “Review workflow” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “Unreviewed gaps cannot appear as completed inventory approval”.
- [ ] **UC-M04.06-C087-T02 · Baseline capture:** Create a known-valid “Review workflow” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C087-T03 · Injection map:** Locate the “Review workflow” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Review workflow” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C087-T05 · Controlled trigger:** Introduce the controlled “Review workflow” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C087-T06 · Intermediate inspection:** Inspect the “Review workflow” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Review workflow”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Review workflow” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C087-T09 · Repeat and compare:** Repeat the selected “Review workflow” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C087-T10 · Failure evidence:** Publish the “Review workflow” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for review backlog and unresolved exceptions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Review workflow”: “Review backlog and unresolved exceptions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C088-T02 · Measurement method:** Choose how to observe each “Review workflow” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Review workflow”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Review workflow” cases for “Review backlog and unresolved exceptions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Review workflow” limit; preserve “Unreviewed gaps cannot appear as completed inventory approval”.
- [ ] **UC-M04.06-C088-T06 · Normal measurement:** Run or review the normal “Review workflow” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C088-T07 · At-limit measurement:** Exercise the “Review workflow” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C088-T08 · Over-limit measurement:** Exercise the “Review workflow” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C088-T09 · Uncovered-scope report:** List the “Review workflow” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C088-T10 · Limit evidence:** Publish the selected “Review workflow” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for review workflow with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C089-T01 · Event inventory:** List the “Review workflow” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Review workflow” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C089-T03 · Failure mapping:** Map each documented “Review workflow” refusal or error to a diagnostic outcome; include “A missing source record is silently marked reviewed” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C089-T04 · Emission path:** Add the “Review workflow” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C089-T05 · Redaction check:** Test “Review workflow” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C089-T06 · Output budget:** Set and exercise bounded “Review workflow” message size, rate and retention compatible with “Review backlog and unresolved exceptions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C089-T07 · Success/refusal fixtures:** Capture “Review workflow” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Review workflow” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C089-T09 · Operator review:** Read the “Review workflow” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C089-T10 · Diagnostic evidence:** Publish redacted “Review workflow” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for review workflow; label unexecuted checks as untested.

- [ ] **UC-M04.06-C090-T01 · Evidence inventory:** List the “Review workflow” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C090-T02 · Artifact references:** Record the exact “Review workflow” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C090-T03 · Fixture references:** Attach the “Review workflow” fixture IDs, input identities and oracle definition; preserve the source counterexample “A missing source record is silently marked reviewed” as a distinct evidence case.
- [ ] **UC-M04.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Review workflow”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C090-T05 · Environment record:** Record the actual “Review workflow” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C090-T06 · Expected versus observed:** Pair every “Review workflow” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C090-T07 · Failure and limit records:** Attach “Review workflow” change/failure and bounds evidence where required; include uncovered “Review backlog and unresolved exceptions” and unresolved violations of “Unreviewed gaps cannot appear as completed inventory approval”.
- [ ] **UC-M04.06-C090-T08 · Evidence hygiene:** Check the “Review workflow” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C090-T09 · Reproduction review:** Have the “Review workflow” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C090-T10 · Acceptance linkage:** Link the “Review workflow” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Inventory export and binding

**Source delivery:** Attach the inventory digest to the exact released image and host package.

**Source invariant:** An inventory for one build cannot approve another build implicitly.

**Source negative case:** A package changes while retaining an old inventory digest.

**Source bounded quantities:** Export size and compatibility versions.

### UC-M04.06-C091 · Contract

**Original checklist item:** Specify inventory export and binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.06-C091-T01 · Scope statement:** Draft the operation boundary for “Inventory export and binding” within Software bill of materials and license inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Inventory export and binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.06-C091-T03 · Output inventory:** List the outputs of “Inventory export and binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Inventory export and binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.06-C091-T05 · Prerequisite contract:** Map “Inventory export and binding” to the source component prerequisites (UC-M04.01, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Inventory export and binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.06-C091-T07 · Invariant clause:** Add a normative clause for “Inventory export and binding” that preserves “An inventory for one build cannot approve another build implicitly”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Inventory export and binding”; include the source counterexample “A package changes while retaining an old inventory digest” and the intended safe disposition.
- [ ] **UC-M04.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Export size and compatibility versions” in the “Inventory export and binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.06-C091-T10 · Contract review:** Review the “Inventory export and binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.06-C092 · Delivery

**Original checklist item:** Attach the inventory digest to the exact released image and host package.

- [ ] **UC-M04.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Inventory export and binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.06-C092-T02 · Change plan:** Break the source delivery for “Inventory export and binding” into concrete edit targets and reviewable outputs; keep the UC-M04.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.06-C092-T03 · Core artifact:** Create the “Inventory export and binding” output artifact for this source instruction: Attach the inventory digest to the exact released image and host package.
- [ ] **UC-M04.06-C092-T04 · Concrete realization:** Populate the “Inventory export and binding” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M04.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Inventory export and binding” needed to preserve “An inventory for one build cannot approve another build implicitly”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.06-C092-T06 · Dependency connection:** Connect the “Inventory export and binding” implementation to observed shipped/linked artifacts, component records and provenance evidence; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.06-C092-T07 · Resource behavior:** Account for “Export size and compatibility versions” in “Inventory export and binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.06-C092-T08 · Delivery check:** Run the smallest real “Inventory export and binding” path and its adverse fixture “A package changes while retaining an old inventory digest”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.06-C092-T09 · Patch review:** Review the “Inventory export and binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.06-C092-T10 · Delivery handoff:** Publish the “Inventory export and binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An inventory for one build cannot approve another build implicitly. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Inventory export and binding”; copy its required invariant exactly: “An inventory for one build cannot approve another build implicitly”.
- [ ] **UC-M04.06-C093-T02 · Observable terms:** Define each term in the “Inventory export and binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.06-C093-T03 · Precondition set:** List the preconditions under which “An inventory for one build cannot approve another build implicitly” must hold for “Inventory export and binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.06-C093-T04 · Transition coverage:** Map the “Inventory export and binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Inventory export and binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.06-C093-T06 · Satisfying fixture:** Create a concrete “Inventory export and binding” case that satisfies “An inventory for one build cannot approve another build implicitly”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.06-C093-T07 · Violating fixture:** Create the source counterexample “A package changes while retaining an old inventory digest” for “Inventory export and binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.06-C093-T08 · Enforcement evidence:** Exercise the “Inventory export and binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.06-C093-T09 · Regression linkage:** Link the “Inventory export and binding” property to changes in observed shipped/linked artifacts, component records and provenance evidence; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Inventory export and binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.06-C094 · Integration

**Original checklist item:** Integrate inventory export and binding with observed shipped/linked artifacts, component records and provenance evidence; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Inventory export and binding” across observed shipped/linked artifacts, component records and provenance evidence; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.06-C094-T02 · Field mapping:** Map every “Inventory export and binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Inventory export and binding” (source dependency list: UC-M04.01, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.06-C094-T04 · Ownership agreement:** Specify who owns “Inventory export and binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.06-C094-T05 · Handoff implementation:** Connect “Inventory export and binding” through the mapped seam using the real adapter or explicit specification reference; preserve “An inventory for one build cannot approve another build implicitly” across the handoff.
- [ ] **UC-M04.06-C094-T06 · Absent-input case:** Omit one required “Inventory export and binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.06-C094-T07 · Stale-input case:** Supply an outdated “Inventory export and binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Inventory export and binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.06-C094-T09 · Valid integration trace:** Run a valid “Inventory export and binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.06-C094-T10 · Seam review:** Reconcile the “Inventory export and binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for inventory export and binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Inventory export and binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.06-C095-T02 · Expected-result oracle:** Specify the “Inventory export and binding” expected result independently of the implementation output; include the property “An inventory for one build cannot approve another build implicitly” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.06-C095-T03 · Fixture material:** Create the concrete “Inventory export and binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.06-C095-T04 · Target preparation:** Prepare the “Inventory export and binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.06-C095-T05 · Initial-state record:** Record the initial “Inventory export and binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.06-C095-T06 · Valid-path execution:** Execute the “Inventory export and binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.06-C095-T07 · Outcome comparison:** Compare every declared “Inventory export and binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.06-C095-T08 · State and bounds check:** Inspect the “Inventory export and binding” ownership/state effects and actual use of “Export size and compatibility versions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.06-C095-T09 · Repeatability check:** Repeat the same “Inventory export and binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.06-C095-T10 · Positive evidence:** Attach the “Inventory export and binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.06-C096 · Negative test

**Original checklist item:** Negative case: A package changes while retaining an old inventory digest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Inventory export and binding” source counterexample: “A package changes while retaining an old inventory digest”; state which precondition or invariant it challenges.
- [ ] **UC-M04.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Inventory export and binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.06-C096-T03 · Valid control:** Construct a valid “Inventory export and binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.06-C096-T04 · Minimal adverse input:** Derive the “Inventory export and binding” adverse fixture from the control with the smallest documented change needed to reproduce “A package changes while retaining an old inventory digest”; retain that change as reproducible data.
- [ ] **UC-M04.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Inventory export and binding”; require “An inventory for one build cannot approve another build implicitly” and forbid a false-success verdict.
- [ ] **UC-M04.06-C096-T06 · Adverse execution:** Exercise the “Inventory export and binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.06-C096-T07 · Effect inspection:** Inspect “Inventory export and binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.06-C096-T08 · Refusal versus failure:** Confirm the “Inventory export and binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.06-C096-T09 · Reset and retention:** Restore only the disposable “Inventory export and binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.06-C096-T10 · Negative regression:** Register the “Inventory export and binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.06-C097 · Change / failure test

**Original checklist item:** Exercise inventory export and binding when a transitive dependency changes during a rebuild or packaging update; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.06-C097-T01 · Scenario record:** Write the “Inventory export and binding” change/failure scenario exactly as supplied: a transitive dependency changes during a rebuild or packaging update; identify the property that must remain true: “An inventory for one build cannot approve another build implicitly”.
- [ ] **UC-M04.06-C097-T02 · Baseline capture:** Create a known-valid “Inventory export and binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.06-C097-T03 · Injection map:** Locate the “Inventory export and binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Inventory export and binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.06-C097-T05 · Controlled trigger:** Introduce the controlled “Inventory export and binding” scenario in the disposable fixture: a transitive dependency changes during a rebuild or packaging update; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.06-C097-T06 · Intermediate inspection:** Inspect the “Inventory export and binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Inventory export and binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Inventory export and binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.06-C097-T09 · Repeat and compare:** Repeat the selected “Inventory export and binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.06-C097-T10 · Failure evidence:** Publish the “Inventory export and binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for export size and compatibility versions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Inventory export and binding”: “Export size and compatibility versions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.06-C098-T02 · Measurement method:** Choose how to observe each “Inventory export and binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Inventory export and binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Inventory export and binding” cases for “Export size and compatibility versions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Inventory export and binding” limit; preserve “An inventory for one build cannot approve another build implicitly”.
- [ ] **UC-M04.06-C098-T06 · Normal measurement:** Run or review the normal “Inventory export and binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.06-C098-T07 · At-limit measurement:** Exercise the “Inventory export and binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.06-C098-T08 · Over-limit measurement:** Exercise the “Inventory export and binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.06-C098-T09 · Uncovered-scope report:** List the “Inventory export and binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.06-C098-T10 · Limit evidence:** Publish the selected “Inventory export and binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for inventory export and binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.06-C099-T01 · Event inventory:** List the “Inventory export and binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Inventory export and binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.06-C099-T03 · Failure mapping:** Map each documented “Inventory export and binding” refusal or error to a diagnostic outcome; include “A package changes while retaining an old inventory digest” and prohibit conversion into a success message.
- [ ] **UC-M04.06-C099-T04 · Emission path:** Add the “Inventory export and binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.06-C099-T05 · Redaction check:** Test “Inventory export and binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.06-C099-T06 · Output budget:** Set and exercise bounded “Inventory export and binding” message size, rate and retention compatible with “Export size and compatibility versions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.06-C099-T07 · Success/refusal fixtures:** Capture “Inventory export and binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Inventory export and binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.06-C099-T09 · Operator review:** Read the “Inventory export and binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.06-C099-T10 · Diagnostic evidence:** Publish redacted “Inventory export and binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for inventory export and binding; label unexecuted checks as untested.

- [ ] **UC-M04.06-C100-T01 · Evidence inventory:** List the “Inventory export and binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.06-C100-T02 · Artifact references:** Record the exact “Inventory export and binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.06-C100-T03 · Fixture references:** Attach the “Inventory export and binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A package changes while retaining an old inventory digest” as a distinct evidence case.
- [ ] **UC-M04.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Inventory export and binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.06-C100-T05 · Environment record:** Record the actual “Inventory export and binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.06-C100-T06 · Expected versus observed:** Pair every “Inventory export and binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.06-C100-T07 · Failure and limit records:** Attach “Inventory export and binding” change/failure and bounds evidence where required; include uncovered “Export size and compatibility versions” and unresolved violations of “An inventory for one build cannot approve another build implicitly”.
- [ ] **UC-M04.06-C100-T08 · Evidence hygiene:** Check the “Inventory export and binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.06-C100-T09 · Reproduction review:** Have the “Inventory export and binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.06-C100-T10 · Acceptance linkage:** Link the “Inventory export and binding” evidence to its parent and UC-M04.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

