# UC-M04.02 — Hermetic and reproducible build recipe

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M04.01](../04/UC-M04.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Normalize timestamps, environment, source paths and generated metadata while separating nondeterministic build evidence.

**Original acceptance criterion:** Two isolated clean builders produce matching declared image digests or a precisely documented reproducibility boundary.

**Source trace:** Original checklist `UC100/c/04/UC-M04.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 345–355 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Build recipe schema

**Source delivery:** Version an explicit recipe containing commands, inputs, target and outputs.

**Source invariant:** The build procedure is not dependent on undocumented manual steps.

**Source negative case:** A clean builder requires an unrecorded preparation command.

**Source bounded quantities:** Recipe bytes and step count.

### UC-M04.02-C001 · Contract

**Original checklist item:** Specify build recipe schema inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C001-T01 · Scope statement:** Draft the operation boundary for “Build recipe schema” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Build recipe schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C001-T03 · Output inventory:** List the outputs of “Build recipe schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Build recipe schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C001-T05 · Prerequisite contract:** Map “Build recipe schema” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Build recipe schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C001-T07 · Invariant clause:** Add a normative clause for “Build recipe schema” that preserves “The build procedure is not dependent on undocumented manual steps”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Build recipe schema”; include the source counterexample “A clean builder requires an unrecorded preparation command” and the intended safe disposition.
- [ ] **UC-M04.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recipe bytes and step count” in the “Build recipe schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C001-T10 · Contract review:** Review the “Build recipe schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C002 · Delivery

**Original checklist item:** Version an explicit recipe containing commands, inputs, target and outputs.

- [ ] **UC-M04.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Build recipe schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C002-T02 · Change plan:** Break the source delivery for “Build recipe schema” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Build recipe schema” that realizes this source instruction: Version an explicit recipe containing commands, inputs, target and outputs.
- [ ] **UC-M04.02-C002-T04 · Concrete realization:** Trace “Build recipe schema” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Build recipe schema” needed to preserve “The build procedure is not dependent on undocumented manual steps”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C002-T06 · Dependency connection:** Connect the “Build recipe schema” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C002-T07 · Resource behavior:** Account for “Recipe bytes and step count” in “Build recipe schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C002-T08 · Delivery check:** Run the smallest real “Build recipe schema” path and its adverse fixture “A clean builder requires an unrecorded preparation command”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C002-T09 · Patch review:** Review the “Build recipe schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C002-T10 · Delivery handoff:** Publish the “Build recipe schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The build procedure is not dependent on undocumented manual steps. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Build recipe schema”; copy its required invariant exactly: “The build procedure is not dependent on undocumented manual steps”.
- [ ] **UC-M04.02-C003-T02 · Observable terms:** Define each term in the “Build recipe schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C003-T03 · Precondition set:** List the preconditions under which “The build procedure is not dependent on undocumented manual steps” must hold for “Build recipe schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C003-T04 · Transition coverage:** Map the “Build recipe schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Build recipe schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C003-T06 · Satisfying fixture:** Create a concrete “Build recipe schema” case that satisfies “The build procedure is not dependent on undocumented manual steps”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C003-T07 · Violating fixture:** Create the source counterexample “A clean builder requires an unrecorded preparation command” for “Build recipe schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C003-T08 · Enforcement evidence:** Exercise the “Build recipe schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C003-T09 · Regression linkage:** Link the “Build recipe schema” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Build recipe schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C004 · Integration

**Original checklist item:** Integrate build recipe schema with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Build recipe schema” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C004-T02 · Field mapping:** Map every “Build recipe schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Build recipe schema” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C004-T04 · Ownership agreement:** Specify who owns “Build recipe schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C004-T05 · Handoff implementation:** Connect “Build recipe schema” through the mapped seam using the real adapter or explicit specification reference; preserve “The build procedure is not dependent on undocumented manual steps” across the handoff.
- [ ] **UC-M04.02-C004-T06 · Absent-input case:** Omit one required “Build recipe schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C004-T07 · Stale-input case:** Supply an outdated “Build recipe schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Build recipe schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C004-T09 · Valid integration trace:** Run a valid “Build recipe schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C004-T10 · Seam review:** Reconcile the “Build recipe schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for build recipe schema; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Build recipe schema” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C005-T02 · Expected-result oracle:** Specify the “Build recipe schema” expected result independently of the implementation output; include the property “The build procedure is not dependent on undocumented manual steps” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C005-T03 · Fixture material:** Create the concrete “Build recipe schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C005-T04 · Target preparation:** Prepare the “Build recipe schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C005-T05 · Initial-state record:** Record the initial “Build recipe schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C005-T06 · Valid-path execution:** Execute the “Build recipe schema” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C005-T07 · Outcome comparison:** Compare every declared “Build recipe schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C005-T08 · State and bounds check:** Inspect the “Build recipe schema” ownership/state effects and actual use of “Recipe bytes and step count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C005-T09 · Repeatability check:** Repeat the same “Build recipe schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C005-T10 · Positive evidence:** Attach the “Build recipe schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C006 · Negative test

**Original checklist item:** Negative case: A clean builder requires an unrecorded preparation command. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Build recipe schema” source counterexample: “A clean builder requires an unrecorded preparation command”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Build recipe schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C006-T03 · Valid control:** Construct a valid “Build recipe schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C006-T04 · Minimal adverse input:** Derive the “Build recipe schema” adverse fixture from the control with the smallest documented change needed to reproduce “A clean builder requires an unrecorded preparation command”; retain that change as reproducible data.
- [ ] **UC-M04.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Build recipe schema”; require “The build procedure is not dependent on undocumented manual steps” and forbid a false-success verdict.
- [ ] **UC-M04.02-C006-T06 · Adverse execution:** Exercise the “Build recipe schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C006-T07 · Effect inspection:** Inspect “Build recipe schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C006-T08 · Refusal versus failure:** Confirm the “Build recipe schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C006-T09 · Reset and retention:** Restore only the disposable “Build recipe schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C006-T10 · Negative regression:** Register the “Build recipe schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C007 · Change / failure test

**Original checklist item:** Exercise build recipe schema when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C007-T01 · Scenario record:** Write the “Build recipe schema” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “The build procedure is not dependent on undocumented manual steps”.
- [ ] **UC-M04.02-C007-T02 · Baseline capture:** Create a known-valid “Build recipe schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C007-T03 · Injection map:** Locate the “Build recipe schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Build recipe schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C007-T05 · Controlled trigger:** Introduce the controlled “Build recipe schema” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C007-T06 · Intermediate inspection:** Inspect the “Build recipe schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Build recipe schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Build recipe schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C007-T09 · Repeat and compare:** Repeat the selected “Build recipe schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C007-T10 · Failure evidence:** Publish the “Build recipe schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for recipe bytes and step count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Build recipe schema”: “Recipe bytes and step count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C008-T02 · Measurement method:** Choose how to observe each “Build recipe schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C008-T03 · Budget decision:** Select justified resource and input limits for “Build recipe schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Build recipe schema” cases for “Recipe bytes and step count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Build recipe schema” limit; preserve “The build procedure is not dependent on undocumented manual steps”.
- [ ] **UC-M04.02-C008-T06 · Normal measurement:** Run or review the normal “Build recipe schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C008-T07 · At-limit measurement:** Exercise the “Build recipe schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C008-T08 · Over-limit measurement:** Exercise the “Build recipe schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C008-T09 · Uncovered-scope report:** List the “Build recipe schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C008-T10 · Limit evidence:** Publish the selected “Build recipe schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for build recipe schema with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C009-T01 · Event inventory:** List the “Build recipe schema” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Build recipe schema” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C009-T03 · Failure mapping:** Map each documented “Build recipe schema” refusal or error to a diagnostic outcome; include “A clean builder requires an unrecorded preparation command” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C009-T04 · Emission path:** Add the “Build recipe schema” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C009-T05 · Redaction check:** Test “Build recipe schema” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C009-T06 · Output budget:** Set and exercise bounded “Build recipe schema” message size, rate and retention compatible with “Recipe bytes and step count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C009-T07 · Success/refusal fixtures:** Capture “Build recipe schema” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Build recipe schema” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C009-T09 · Operator review:** Read the “Build recipe schema” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C009-T10 · Diagnostic evidence:** Publish redacted “Build recipe schema” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for build recipe schema; label unexecuted checks as untested.

- [ ] **UC-M04.02-C010-T01 · Evidence inventory:** List the “Build recipe schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C010-T02 · Artifact references:** Record the exact “Build recipe schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C010-T03 · Fixture references:** Attach the “Build recipe schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “A clean builder requires an unrecorded preparation command” as a distinct evidence case.
- [ ] **UC-M04.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Build recipe schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C010-T05 · Environment record:** Record the actual “Build recipe schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C010-T06 · Expected versus observed:** Pair every “Build recipe schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C010-T07 · Failure and limit records:** Attach “Build recipe schema” change/failure and bounds evidence where required; include uncovered “Recipe bytes and step count” and unresolved violations of “The build procedure is not dependent on undocumented manual steps”.
- [ ] **UC-M04.02-C010-T08 · Evidence hygiene:** Check the “Build recipe schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C010-T09 · Reproduction review:** Have the “Build recipe schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C010-T10 · Acceptance linkage:** Link the “Build recipe schema” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Timestamp normalization

**Source delivery:** Define reproducible timestamps for generated and packaged build artifacts.

**Source invariant:** Declared reproducible outputs do not inherit uncontrolled wall time.

**Source negative case:** Identical builds differ only because creation timestamps changed.

**Source bounded quantities:** Timestamp-bearing fields and fixture count.

### UC-M04.02-C011 · Contract

**Original checklist item:** Specify timestamp normalization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C011-T01 · Scope statement:** Draft the operation boundary for “Timestamp normalization” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Timestamp normalization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C011-T03 · Output inventory:** List the outputs of “Timestamp normalization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Timestamp normalization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C011-T05 · Prerequisite contract:** Map “Timestamp normalization” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Timestamp normalization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C011-T07 · Invariant clause:** Add a normative clause for “Timestamp normalization” that preserves “Declared reproducible outputs do not inherit uncontrolled wall time”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Timestamp normalization”; include the source counterexample “Identical builds differ only because creation timestamps changed” and the intended safe disposition.
- [ ] **UC-M04.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Timestamp-bearing fields and fixture count” in the “Timestamp normalization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C011-T10 · Contract review:** Review the “Timestamp normalization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C012 · Delivery

**Original checklist item:** Define reproducible timestamps for generated and packaged build artifacts.

- [ ] **UC-M04.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Timestamp normalization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C012-T02 · Change plan:** Break the source delivery for “Timestamp normalization” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C012-T03 · Core artifact:** Create the “Timestamp normalization” model, schema or inventory that realizes this source instruction: Define reproducible timestamps for generated and packaged build artifacts.
- [ ] **UC-M04.02-C012-T04 · Concrete realization:** Populate “Timestamp normalization” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Timestamp normalization” needed to preserve “Declared reproducible outputs do not inherit uncontrolled wall time”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C012-T06 · Dependency connection:** Connect the “Timestamp normalization” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C012-T07 · Resource behavior:** Account for “Timestamp-bearing fields and fixture count” in “Timestamp normalization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C012-T08 · Delivery check:** Run the smallest real “Timestamp normalization” path and its adverse fixture “Identical builds differ only because creation timestamps changed”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C012-T09 · Patch review:** Review the “Timestamp normalization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C012-T10 · Delivery handoff:** Publish the “Timestamp normalization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Declared reproducible outputs do not inherit uncontrolled wall time. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Timestamp normalization”; copy its required invariant exactly: “Declared reproducible outputs do not inherit uncontrolled wall time”.
- [ ] **UC-M04.02-C013-T02 · Observable terms:** Define each term in the “Timestamp normalization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C013-T03 · Precondition set:** List the preconditions under which “Declared reproducible outputs do not inherit uncontrolled wall time” must hold for “Timestamp normalization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C013-T04 · Transition coverage:** Map the “Timestamp normalization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Timestamp normalization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C013-T06 · Satisfying fixture:** Create a concrete “Timestamp normalization” case that satisfies “Declared reproducible outputs do not inherit uncontrolled wall time”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C013-T07 · Violating fixture:** Create the source counterexample “Identical builds differ only because creation timestamps changed” for “Timestamp normalization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C013-T08 · Enforcement evidence:** Exercise the “Timestamp normalization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C013-T09 · Regression linkage:** Link the “Timestamp normalization” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Timestamp normalization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C014 · Integration

**Original checklist item:** Integrate timestamp normalization with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Timestamp normalization” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C014-T02 · Field mapping:** Map every “Timestamp normalization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Timestamp normalization” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C014-T04 · Ownership agreement:** Specify who owns “Timestamp normalization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C014-T05 · Handoff implementation:** Connect “Timestamp normalization” through the mapped seam using the real adapter or explicit specification reference; preserve “Declared reproducible outputs do not inherit uncontrolled wall time” across the handoff.
- [ ] **UC-M04.02-C014-T06 · Absent-input case:** Omit one required “Timestamp normalization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C014-T07 · Stale-input case:** Supply an outdated “Timestamp normalization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Timestamp normalization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C014-T09 · Valid integration trace:** Run a valid “Timestamp normalization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C014-T10 · Seam review:** Reconcile the “Timestamp normalization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for timestamp normalization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Timestamp normalization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C015-T02 · Expected-result oracle:** Specify the “Timestamp normalization” expected result independently of the implementation output; include the property “Declared reproducible outputs do not inherit uncontrolled wall time” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C015-T03 · Fixture material:** Create the concrete “Timestamp normalization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C015-T04 · Target preparation:** Prepare the “Timestamp normalization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C015-T05 · Initial-state record:** Record the initial “Timestamp normalization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C015-T06 · Valid-path execution:** Execute the “Timestamp normalization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C015-T07 · Outcome comparison:** Compare every declared “Timestamp normalization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C015-T08 · State and bounds check:** Inspect the “Timestamp normalization” ownership/state effects and actual use of “Timestamp-bearing fields and fixture count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C015-T09 · Repeatability check:** Repeat the same “Timestamp normalization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C015-T10 · Positive evidence:** Attach the “Timestamp normalization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C016 · Negative test

**Original checklist item:** Negative case: Identical builds differ only because creation timestamps changed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Timestamp normalization” source counterexample: “Identical builds differ only because creation timestamps changed”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Timestamp normalization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C016-T03 · Valid control:** Construct a valid “Timestamp normalization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C016-T04 · Minimal adverse input:** Derive the “Timestamp normalization” adverse fixture from the control with the smallest documented change needed to reproduce “Identical builds differ only because creation timestamps changed”; retain that change as reproducible data.
- [ ] **UC-M04.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Timestamp normalization”; require “Declared reproducible outputs do not inherit uncontrolled wall time” and forbid a false-success verdict.
- [ ] **UC-M04.02-C016-T06 · Adverse execution:** Exercise the “Timestamp normalization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C016-T07 · Effect inspection:** Inspect “Timestamp normalization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C016-T08 · Refusal versus failure:** Confirm the “Timestamp normalization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C016-T09 · Reset and retention:** Restore only the disposable “Timestamp normalization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C016-T10 · Negative regression:** Register the “Timestamp normalization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C017 · Change / failure test

**Original checklist item:** Exercise timestamp normalization when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C017-T01 · Scenario record:** Write the “Timestamp normalization” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “Declared reproducible outputs do not inherit uncontrolled wall time”.
- [ ] **UC-M04.02-C017-T02 · Baseline capture:** Create a known-valid “Timestamp normalization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C017-T03 · Injection map:** Locate the “Timestamp normalization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Timestamp normalization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C017-T05 · Controlled trigger:** Introduce the controlled “Timestamp normalization” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C017-T06 · Intermediate inspection:** Inspect the “Timestamp normalization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Timestamp normalization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Timestamp normalization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C017-T09 · Repeat and compare:** Repeat the selected “Timestamp normalization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C017-T10 · Failure evidence:** Publish the “Timestamp normalization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for timestamp-bearing fields and fixture count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Timestamp normalization”: “Timestamp-bearing fields and fixture count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C018-T02 · Measurement method:** Choose how to observe each “Timestamp normalization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C018-T03 · Budget decision:** Select justified resource and input limits for “Timestamp normalization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Timestamp normalization” cases for “Timestamp-bearing fields and fixture count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Timestamp normalization” limit; preserve “Declared reproducible outputs do not inherit uncontrolled wall time”.
- [ ] **UC-M04.02-C018-T06 · Normal measurement:** Run or review the normal “Timestamp normalization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C018-T07 · At-limit measurement:** Exercise the “Timestamp normalization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C018-T08 · Over-limit measurement:** Exercise the “Timestamp normalization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C018-T09 · Uncovered-scope report:** List the “Timestamp normalization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C018-T10 · Limit evidence:** Publish the selected “Timestamp normalization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for timestamp normalization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C019-T01 · Event inventory:** List the “Timestamp normalization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Timestamp normalization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C019-T03 · Failure mapping:** Map each documented “Timestamp normalization” refusal or error to a diagnostic outcome; include “Identical builds differ only because creation timestamps changed” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C019-T04 · Emission path:** Add the “Timestamp normalization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C019-T05 · Redaction check:** Test “Timestamp normalization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C019-T06 · Output budget:** Set and exercise bounded “Timestamp normalization” message size, rate and retention compatible with “Timestamp-bearing fields and fixture count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C019-T07 · Success/refusal fixtures:** Capture “Timestamp normalization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Timestamp normalization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C019-T09 · Operator review:** Read the “Timestamp normalization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C019-T10 · Diagnostic evidence:** Publish redacted “Timestamp normalization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for timestamp normalization; label unexecuted checks as untested.

- [ ] **UC-M04.02-C020-T01 · Evidence inventory:** List the “Timestamp normalization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C020-T02 · Artifact references:** Record the exact “Timestamp normalization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C020-T03 · Fixture references:** Attach the “Timestamp normalization” fixture IDs, input identities and oracle definition; preserve the source counterexample “Identical builds differ only because creation timestamps changed” as a distinct evidence case.
- [ ] **UC-M04.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Timestamp normalization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C020-T05 · Environment record:** Record the actual “Timestamp normalization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C020-T06 · Expected versus observed:** Pair every “Timestamp normalization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C020-T07 · Failure and limit records:** Attach “Timestamp normalization” change/failure and bounds evidence where required; include uncovered “Timestamp-bearing fields and fixture count” and unresolved violations of “Declared reproducible outputs do not inherit uncontrolled wall time”.
- [ ] **UC-M04.02-C020-T08 · Evidence hygiene:** Check the “Timestamp normalization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C020-T09 · Reproduction review:** Have the “Timestamp normalization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C020-T10 · Acceptance linkage:** Link the “Timestamp normalization” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Environment normalization

**Source delivery:** Allowlist build environment variables and deterministic locale settings.

**Source invariant:** Undeclared ambient environment cannot alter the image.

**Source negative case:** Different locale settings change generated image content.

**Source bounded quantities:** Environment bytes and tested variations.

### UC-M04.02-C021 · Contract

**Original checklist item:** Specify environment normalization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C021-T01 · Scope statement:** Draft the operation boundary for “Environment normalization” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Environment normalization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C021-T03 · Output inventory:** List the outputs of “Environment normalization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Environment normalization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C021-T05 · Prerequisite contract:** Map “Environment normalization” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Environment normalization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C021-T07 · Invariant clause:** Add a normative clause for “Environment normalization” that preserves “Undeclared ambient environment cannot alter the image”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Environment normalization”; include the source counterexample “Different locale settings change generated image content” and the intended safe disposition.
- [ ] **UC-M04.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Environment bytes and tested variations” in the “Environment normalization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C021-T10 · Contract review:** Review the “Environment normalization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C022 · Delivery

**Original checklist item:** Allowlist build environment variables and deterministic locale settings.

- [ ] **UC-M04.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Environment normalization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C022-T02 · Change plan:** Break the source delivery for “Environment normalization” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Environment normalization” that realizes this source instruction: Allowlist build environment variables and deterministic locale settings.
- [ ] **UC-M04.02-C022-T04 · Concrete realization:** Trace “Environment normalization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Environment normalization” needed to preserve “Undeclared ambient environment cannot alter the image”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C022-T06 · Dependency connection:** Connect the “Environment normalization” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C022-T07 · Resource behavior:** Account for “Environment bytes and tested variations” in “Environment normalization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C022-T08 · Delivery check:** Run the smallest real “Environment normalization” path and its adverse fixture “Different locale settings change generated image content”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C022-T09 · Patch review:** Review the “Environment normalization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C022-T10 · Delivery handoff:** Publish the “Environment normalization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Undeclared ambient environment cannot alter the image. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Environment normalization”; copy its required invariant exactly: “Undeclared ambient environment cannot alter the image”.
- [ ] **UC-M04.02-C023-T02 · Observable terms:** Define each term in the “Environment normalization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C023-T03 · Precondition set:** List the preconditions under which “Undeclared ambient environment cannot alter the image” must hold for “Environment normalization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C023-T04 · Transition coverage:** Map the “Environment normalization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Environment normalization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C023-T06 · Satisfying fixture:** Create a concrete “Environment normalization” case that satisfies “Undeclared ambient environment cannot alter the image”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C023-T07 · Violating fixture:** Create the source counterexample “Different locale settings change generated image content” for “Environment normalization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C023-T08 · Enforcement evidence:** Exercise the “Environment normalization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C023-T09 · Regression linkage:** Link the “Environment normalization” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Environment normalization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C024 · Integration

**Original checklist item:** Integrate environment normalization with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Environment normalization” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C024-T02 · Field mapping:** Map every “Environment normalization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Environment normalization” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C024-T04 · Ownership agreement:** Specify who owns “Environment normalization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C024-T05 · Handoff implementation:** Connect “Environment normalization” through the mapped seam using the real adapter or explicit specification reference; preserve “Undeclared ambient environment cannot alter the image” across the handoff.
- [ ] **UC-M04.02-C024-T06 · Absent-input case:** Omit one required “Environment normalization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C024-T07 · Stale-input case:** Supply an outdated “Environment normalization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Environment normalization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C024-T09 · Valid integration trace:** Run a valid “Environment normalization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C024-T10 · Seam review:** Reconcile the “Environment normalization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for environment normalization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Environment normalization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C025-T02 · Expected-result oracle:** Specify the “Environment normalization” expected result independently of the implementation output; include the property “Undeclared ambient environment cannot alter the image” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C025-T03 · Fixture material:** Create the concrete “Environment normalization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C025-T04 · Target preparation:** Prepare the “Environment normalization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C025-T05 · Initial-state record:** Record the initial “Environment normalization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C025-T06 · Valid-path execution:** Execute the “Environment normalization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C025-T07 · Outcome comparison:** Compare every declared “Environment normalization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C025-T08 · State and bounds check:** Inspect the “Environment normalization” ownership/state effects and actual use of “Environment bytes and tested variations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C025-T09 · Repeatability check:** Repeat the same “Environment normalization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C025-T10 · Positive evidence:** Attach the “Environment normalization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C026 · Negative test

**Original checklist item:** Negative case: Different locale settings change generated image content. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Environment normalization” source counterexample: “Different locale settings change generated image content”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Environment normalization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C026-T03 · Valid control:** Construct a valid “Environment normalization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C026-T04 · Minimal adverse input:** Derive the “Environment normalization” adverse fixture from the control with the smallest documented change needed to reproduce “Different locale settings change generated image content”; retain that change as reproducible data.
- [ ] **UC-M04.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Environment normalization”; require “Undeclared ambient environment cannot alter the image” and forbid a false-success verdict.
- [ ] **UC-M04.02-C026-T06 · Adverse execution:** Exercise the “Environment normalization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C026-T07 · Effect inspection:** Inspect “Environment normalization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C026-T08 · Refusal versus failure:** Confirm the “Environment normalization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C026-T09 · Reset and retention:** Restore only the disposable “Environment normalization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C026-T10 · Negative regression:** Register the “Environment normalization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C027 · Change / failure test

**Original checklist item:** Exercise environment normalization when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C027-T01 · Scenario record:** Write the “Environment normalization” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “Undeclared ambient environment cannot alter the image”.
- [ ] **UC-M04.02-C027-T02 · Baseline capture:** Create a known-valid “Environment normalization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C027-T03 · Injection map:** Locate the “Environment normalization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Environment normalization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C027-T05 · Controlled trigger:** Introduce the controlled “Environment normalization” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C027-T06 · Intermediate inspection:** Inspect the “Environment normalization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Environment normalization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Environment normalization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C027-T09 · Repeat and compare:** Repeat the selected “Environment normalization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C027-T10 · Failure evidence:** Publish the “Environment normalization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for environment bytes and tested variations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Environment normalization”: “Environment bytes and tested variations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C028-T02 · Measurement method:** Choose how to observe each “Environment normalization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Environment normalization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Environment normalization” cases for “Environment bytes and tested variations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Environment normalization” limit; preserve “Undeclared ambient environment cannot alter the image”.
- [ ] **UC-M04.02-C028-T06 · Normal measurement:** Run or review the normal “Environment normalization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C028-T07 · At-limit measurement:** Exercise the “Environment normalization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C028-T08 · Over-limit measurement:** Exercise the “Environment normalization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C028-T09 · Uncovered-scope report:** List the “Environment normalization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C028-T10 · Limit evidence:** Publish the selected “Environment normalization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for environment normalization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C029-T01 · Event inventory:** List the “Environment normalization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Environment normalization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C029-T03 · Failure mapping:** Map each documented “Environment normalization” refusal or error to a diagnostic outcome; include “Different locale settings change generated image content” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C029-T04 · Emission path:** Add the “Environment normalization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C029-T05 · Redaction check:** Test “Environment normalization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C029-T06 · Output budget:** Set and exercise bounded “Environment normalization” message size, rate and retention compatible with “Environment bytes and tested variations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C029-T07 · Success/refusal fixtures:** Capture “Environment normalization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Environment normalization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C029-T09 · Operator review:** Read the “Environment normalization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C029-T10 · Diagnostic evidence:** Publish redacted “Environment normalization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for environment normalization; label unexecuted checks as untested.

- [ ] **UC-M04.02-C030-T01 · Evidence inventory:** List the “Environment normalization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C030-T02 · Artifact references:** Record the exact “Environment normalization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C030-T03 · Fixture references:** Attach the “Environment normalization” fixture IDs, input identities and oracle definition; preserve the source counterexample “Different locale settings change generated image content” as a distinct evidence case.
- [ ] **UC-M04.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Environment normalization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C030-T05 · Environment record:** Record the actual “Environment normalization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C030-T06 · Expected versus observed:** Pair every “Environment normalization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C030-T07 · Failure and limit records:** Attach “Environment normalization” change/failure and bounds evidence where required; include uncovered “Environment bytes and tested variations” and unresolved violations of “Undeclared ambient environment cannot alter the image”.
- [ ] **UC-M04.02-C030-T08 · Evidence hygiene:** Check the “Environment normalization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C030-T09 · Reproduction review:** Have the “Environment normalization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C030-T10 · Acceptance linkage:** Link the “Environment normalization” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Source-path normalization

**Source delivery:** Remove or explicitly account for host-specific absolute paths in declared outputs.

**Source invariant:** Path differences do not silently invalidate reproducibility claims.

**Source negative case:** Two builders embed their distinct workspace paths in the image.

**Source bounded quantities:** Path length and supported root variants.

### UC-M04.02-C031 · Contract

**Original checklist item:** Specify source-path normalization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C031-T01 · Scope statement:** Draft the operation boundary for “Source-path normalization” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Source-path normalization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C031-T03 · Output inventory:** List the outputs of “Source-path normalization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Source-path normalization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C031-T05 · Prerequisite contract:** Map “Source-path normalization” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Source-path normalization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C031-T07 · Invariant clause:** Add a normative clause for “Source-path normalization” that preserves “Path differences do not silently invalidate reproducibility claims”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Source-path normalization”; include the source counterexample “Two builders embed their distinct workspace paths in the image” and the intended safe disposition.
- [ ] **UC-M04.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Path length and supported root variants” in the “Source-path normalization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C031-T10 · Contract review:** Review the “Source-path normalization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C032 · Delivery

**Original checklist item:** Remove or explicitly account for host-specific absolute paths in declared outputs.

- [ ] **UC-M04.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Source-path normalization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C032-T02 · Change plan:** Break the source delivery for “Source-path normalization” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Source-path normalization” that realizes this source instruction: Remove or explicitly account for host-specific absolute paths in declared outputs.
- [ ] **UC-M04.02-C032-T04 · Concrete realization:** Trace “Source-path normalization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Source-path normalization” needed to preserve “Path differences do not silently invalidate reproducibility claims”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C032-T06 · Dependency connection:** Connect the “Source-path normalization” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C032-T07 · Resource behavior:** Account for “Path length and supported root variants” in “Source-path normalization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C032-T08 · Delivery check:** Run the smallest real “Source-path normalization” path and its adverse fixture “Two builders embed their distinct workspace paths in the image”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C032-T09 · Patch review:** Review the “Source-path normalization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C032-T10 · Delivery handoff:** Publish the “Source-path normalization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Path differences do not silently invalidate reproducibility claims. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Source-path normalization”; copy its required invariant exactly: “Path differences do not silently invalidate reproducibility claims”.
- [ ] **UC-M04.02-C033-T02 · Observable terms:** Define each term in the “Source-path normalization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C033-T03 · Precondition set:** List the preconditions under which “Path differences do not silently invalidate reproducibility claims” must hold for “Source-path normalization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C033-T04 · Transition coverage:** Map the “Source-path normalization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Source-path normalization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C033-T06 · Satisfying fixture:** Create a concrete “Source-path normalization” case that satisfies “Path differences do not silently invalidate reproducibility claims”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C033-T07 · Violating fixture:** Create the source counterexample “Two builders embed their distinct workspace paths in the image” for “Source-path normalization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C033-T08 · Enforcement evidence:** Exercise the “Source-path normalization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C033-T09 · Regression linkage:** Link the “Source-path normalization” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Source-path normalization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C034 · Integration

**Original checklist item:** Integrate source-path normalization with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Source-path normalization” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C034-T02 · Field mapping:** Map every “Source-path normalization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Source-path normalization” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C034-T04 · Ownership agreement:** Specify who owns “Source-path normalization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C034-T05 · Handoff implementation:** Connect “Source-path normalization” through the mapped seam using the real adapter or explicit specification reference; preserve “Path differences do not silently invalidate reproducibility claims” across the handoff.
- [ ] **UC-M04.02-C034-T06 · Absent-input case:** Omit one required “Source-path normalization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C034-T07 · Stale-input case:** Supply an outdated “Source-path normalization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Source-path normalization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C034-T09 · Valid integration trace:** Run a valid “Source-path normalization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C034-T10 · Seam review:** Reconcile the “Source-path normalization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for source-path normalization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Source-path normalization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C035-T02 · Expected-result oracle:** Specify the “Source-path normalization” expected result independently of the implementation output; include the property “Path differences do not silently invalidate reproducibility claims” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C035-T03 · Fixture material:** Create the concrete “Source-path normalization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C035-T04 · Target preparation:** Prepare the “Source-path normalization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C035-T05 · Initial-state record:** Record the initial “Source-path normalization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C035-T06 · Valid-path execution:** Execute the “Source-path normalization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C035-T07 · Outcome comparison:** Compare every declared “Source-path normalization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C035-T08 · State and bounds check:** Inspect the “Source-path normalization” ownership/state effects and actual use of “Path length and supported root variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C035-T09 · Repeatability check:** Repeat the same “Source-path normalization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C035-T10 · Positive evidence:** Attach the “Source-path normalization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C036 · Negative test

**Original checklist item:** Negative case: Two builders embed their distinct workspace paths in the image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Source-path normalization” source counterexample: “Two builders embed their distinct workspace paths in the image”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Source-path normalization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C036-T03 · Valid control:** Construct a valid “Source-path normalization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C036-T04 · Minimal adverse input:** Derive the “Source-path normalization” adverse fixture from the control with the smallest documented change needed to reproduce “Two builders embed their distinct workspace paths in the image”; retain that change as reproducible data.
- [ ] **UC-M04.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Source-path normalization”; require “Path differences do not silently invalidate reproducibility claims” and forbid a false-success verdict.
- [ ] **UC-M04.02-C036-T06 · Adverse execution:** Exercise the “Source-path normalization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C036-T07 · Effect inspection:** Inspect “Source-path normalization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C036-T08 · Refusal versus failure:** Confirm the “Source-path normalization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C036-T09 · Reset and retention:** Restore only the disposable “Source-path normalization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C036-T10 · Negative regression:** Register the “Source-path normalization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C037 · Change / failure test

**Original checklist item:** Exercise source-path normalization when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C037-T01 · Scenario record:** Write the “Source-path normalization” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “Path differences do not silently invalidate reproducibility claims”.
- [ ] **UC-M04.02-C037-T02 · Baseline capture:** Create a known-valid “Source-path normalization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C037-T03 · Injection map:** Locate the “Source-path normalization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Source-path normalization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C037-T05 · Controlled trigger:** Introduce the controlled “Source-path normalization” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C037-T06 · Intermediate inspection:** Inspect the “Source-path normalization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Source-path normalization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Source-path normalization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C037-T09 · Repeat and compare:** Repeat the selected “Source-path normalization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C037-T10 · Failure evidence:** Publish the “Source-path normalization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for path length and supported root variants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Source-path normalization”: “Path length and supported root variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C038-T02 · Measurement method:** Choose how to observe each “Source-path normalization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C038-T03 · Budget decision:** Select justified resource and input limits for “Source-path normalization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Source-path normalization” cases for “Path length and supported root variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Source-path normalization” limit; preserve “Path differences do not silently invalidate reproducibility claims”.
- [ ] **UC-M04.02-C038-T06 · Normal measurement:** Run or review the normal “Source-path normalization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C038-T07 · At-limit measurement:** Exercise the “Source-path normalization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C038-T08 · Over-limit measurement:** Exercise the “Source-path normalization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C038-T09 · Uncovered-scope report:** List the “Source-path normalization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C038-T10 · Limit evidence:** Publish the selected “Source-path normalization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for source-path normalization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C039-T01 · Event inventory:** List the “Source-path normalization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Source-path normalization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C039-T03 · Failure mapping:** Map each documented “Source-path normalization” refusal or error to a diagnostic outcome; include “Two builders embed their distinct workspace paths in the image” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C039-T04 · Emission path:** Add the “Source-path normalization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C039-T05 · Redaction check:** Test “Source-path normalization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C039-T06 · Output budget:** Set and exercise bounded “Source-path normalization” message size, rate and retention compatible with “Path length and supported root variants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C039-T07 · Success/refusal fixtures:** Capture “Source-path normalization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Source-path normalization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C039-T09 · Operator review:** Read the “Source-path normalization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C039-T10 · Diagnostic evidence:** Publish redacted “Source-path normalization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for source-path normalization; label unexecuted checks as untested.

- [ ] **UC-M04.02-C040-T01 · Evidence inventory:** List the “Source-path normalization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C040-T02 · Artifact references:** Record the exact “Source-path normalization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C040-T03 · Fixture references:** Attach the “Source-path normalization” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two builders embed their distinct workspace paths in the image” as a distinct evidence case.
- [ ] **UC-M04.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Source-path normalization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C040-T05 · Environment record:** Record the actual “Source-path normalization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C040-T06 · Expected versus observed:** Pair every “Source-path normalization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C040-T07 · Failure and limit records:** Attach “Source-path normalization” change/failure and bounds evidence where required; include uncovered “Path length and supported root variants” and unresolved violations of “Path differences do not silently invalidate reproducibility claims”.
- [ ] **UC-M04.02-C040-T08 · Evidence hygiene:** Check the “Source-path normalization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C040-T09 · Reproduction review:** Have the “Source-path normalization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C040-T10 · Acceptance linkage:** Link the “Source-path normalization” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Generated metadata normalization

**Source delivery:** Canonicalize generated identifiers and metadata included in the image.

**Source invariant:** Equivalent inputs produce identical declared metadata.

**Source negative case:** Iteration order changes generated configuration bytes.

**Source bounded quantities:** Metadata bytes and ordering complexity.

### UC-M04.02-C041 · Contract

**Original checklist item:** Specify generated metadata normalization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C041-T01 · Scope statement:** Draft the operation boundary for “Generated metadata normalization” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Generated metadata normalization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C041-T03 · Output inventory:** List the outputs of “Generated metadata normalization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Generated metadata normalization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C041-T05 · Prerequisite contract:** Map “Generated metadata normalization” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Generated metadata normalization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C041-T07 · Invariant clause:** Add a normative clause for “Generated metadata normalization” that preserves “Equivalent inputs produce identical declared metadata”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Generated metadata normalization”; include the source counterexample “Iteration order changes generated configuration bytes” and the intended safe disposition.
- [ ] **UC-M04.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Metadata bytes and ordering complexity” in the “Generated metadata normalization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C041-T10 · Contract review:** Review the “Generated metadata normalization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C042 · Delivery

**Original checklist item:** Canonicalize generated identifiers and metadata included in the image.

- [ ] **UC-M04.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Generated metadata normalization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C042-T02 · Change plan:** Break the source delivery for “Generated metadata normalization” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Generated metadata normalization” that realizes this source instruction: Canonicalize generated identifiers and metadata included in the image.
- [ ] **UC-M04.02-C042-T04 · Concrete realization:** Trace “Generated metadata normalization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Generated metadata normalization” needed to preserve “Equivalent inputs produce identical declared metadata”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C042-T06 · Dependency connection:** Connect the “Generated metadata normalization” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C042-T07 · Resource behavior:** Account for “Metadata bytes and ordering complexity” in “Generated metadata normalization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C042-T08 · Delivery check:** Run the smallest real “Generated metadata normalization” path and its adverse fixture “Iteration order changes generated configuration bytes”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C042-T09 · Patch review:** Review the “Generated metadata normalization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C042-T10 · Delivery handoff:** Publish the “Generated metadata normalization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Equivalent inputs produce identical declared metadata. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Generated metadata normalization”; copy its required invariant exactly: “Equivalent inputs produce identical declared metadata”.
- [ ] **UC-M04.02-C043-T02 · Observable terms:** Define each term in the “Generated metadata normalization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C043-T03 · Precondition set:** List the preconditions under which “Equivalent inputs produce identical declared metadata” must hold for “Generated metadata normalization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C043-T04 · Transition coverage:** Map the “Generated metadata normalization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Generated metadata normalization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C043-T06 · Satisfying fixture:** Create a concrete “Generated metadata normalization” case that satisfies “Equivalent inputs produce identical declared metadata”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C043-T07 · Violating fixture:** Create the source counterexample “Iteration order changes generated configuration bytes” for “Generated metadata normalization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C043-T08 · Enforcement evidence:** Exercise the “Generated metadata normalization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C043-T09 · Regression linkage:** Link the “Generated metadata normalization” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Generated metadata normalization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C044 · Integration

**Original checklist item:** Integrate generated metadata normalization with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Generated metadata normalization” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C044-T02 · Field mapping:** Map every “Generated metadata normalization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Generated metadata normalization” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C044-T04 · Ownership agreement:** Specify who owns “Generated metadata normalization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C044-T05 · Handoff implementation:** Connect “Generated metadata normalization” through the mapped seam using the real adapter or explicit specification reference; preserve “Equivalent inputs produce identical declared metadata” across the handoff.
- [ ] **UC-M04.02-C044-T06 · Absent-input case:** Omit one required “Generated metadata normalization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C044-T07 · Stale-input case:** Supply an outdated “Generated metadata normalization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Generated metadata normalization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C044-T09 · Valid integration trace:** Run a valid “Generated metadata normalization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C044-T10 · Seam review:** Reconcile the “Generated metadata normalization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for generated metadata normalization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Generated metadata normalization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C045-T02 · Expected-result oracle:** Specify the “Generated metadata normalization” expected result independently of the implementation output; include the property “Equivalent inputs produce identical declared metadata” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C045-T03 · Fixture material:** Create the concrete “Generated metadata normalization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C045-T04 · Target preparation:** Prepare the “Generated metadata normalization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C045-T05 · Initial-state record:** Record the initial “Generated metadata normalization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C045-T06 · Valid-path execution:** Execute the “Generated metadata normalization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C045-T07 · Outcome comparison:** Compare every declared “Generated metadata normalization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C045-T08 · State and bounds check:** Inspect the “Generated metadata normalization” ownership/state effects and actual use of “Metadata bytes and ordering complexity”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C045-T09 · Repeatability check:** Repeat the same “Generated metadata normalization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C045-T10 · Positive evidence:** Attach the “Generated metadata normalization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C046 · Negative test

**Original checklist item:** Negative case: Iteration order changes generated configuration bytes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Generated metadata normalization” source counterexample: “Iteration order changes generated configuration bytes”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Generated metadata normalization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C046-T03 · Valid control:** Construct a valid “Generated metadata normalization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C046-T04 · Minimal adverse input:** Derive the “Generated metadata normalization” adverse fixture from the control with the smallest documented change needed to reproduce “Iteration order changes generated configuration bytes”; retain that change as reproducible data.
- [ ] **UC-M04.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Generated metadata normalization”; require “Equivalent inputs produce identical declared metadata” and forbid a false-success verdict.
- [ ] **UC-M04.02-C046-T06 · Adverse execution:** Exercise the “Generated metadata normalization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C046-T07 · Effect inspection:** Inspect “Generated metadata normalization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C046-T08 · Refusal versus failure:** Confirm the “Generated metadata normalization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C046-T09 · Reset and retention:** Restore only the disposable “Generated metadata normalization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C046-T10 · Negative regression:** Register the “Generated metadata normalization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C047 · Change / failure test

**Original checklist item:** Exercise generated metadata normalization when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C047-T01 · Scenario record:** Write the “Generated metadata normalization” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “Equivalent inputs produce identical declared metadata”.
- [ ] **UC-M04.02-C047-T02 · Baseline capture:** Create a known-valid “Generated metadata normalization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C047-T03 · Injection map:** Locate the “Generated metadata normalization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Generated metadata normalization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C047-T05 · Controlled trigger:** Introduce the controlled “Generated metadata normalization” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C047-T06 · Intermediate inspection:** Inspect the “Generated metadata normalization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Generated metadata normalization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Generated metadata normalization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C047-T09 · Repeat and compare:** Repeat the selected “Generated metadata normalization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C047-T10 · Failure evidence:** Publish the “Generated metadata normalization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for metadata bytes and ordering complexity; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Generated metadata normalization”: “Metadata bytes and ordering complexity”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C048-T02 · Measurement method:** Choose how to observe each “Generated metadata normalization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C048-T03 · Budget decision:** Select justified resource and input limits for “Generated metadata normalization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Generated metadata normalization” cases for “Metadata bytes and ordering complexity”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Generated metadata normalization” limit; preserve “Equivalent inputs produce identical declared metadata”.
- [ ] **UC-M04.02-C048-T06 · Normal measurement:** Run or review the normal “Generated metadata normalization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C048-T07 · At-limit measurement:** Exercise the “Generated metadata normalization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C048-T08 · Over-limit measurement:** Exercise the “Generated metadata normalization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C048-T09 · Uncovered-scope report:** List the “Generated metadata normalization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C048-T10 · Limit evidence:** Publish the selected “Generated metadata normalization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for generated metadata normalization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C049-T01 · Event inventory:** List the “Generated metadata normalization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Generated metadata normalization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C049-T03 · Failure mapping:** Map each documented “Generated metadata normalization” refusal or error to a diagnostic outcome; include “Iteration order changes generated configuration bytes” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C049-T04 · Emission path:** Add the “Generated metadata normalization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C049-T05 · Redaction check:** Test “Generated metadata normalization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C049-T06 · Output budget:** Set and exercise bounded “Generated metadata normalization” message size, rate and retention compatible with “Metadata bytes and ordering complexity”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C049-T07 · Success/refusal fixtures:** Capture “Generated metadata normalization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Generated metadata normalization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C049-T09 · Operator review:** Read the “Generated metadata normalization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C049-T10 · Diagnostic evidence:** Publish redacted “Generated metadata normalization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for generated metadata normalization; label unexecuted checks as untested.

- [ ] **UC-M04.02-C050-T01 · Evidence inventory:** List the “Generated metadata normalization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C050-T02 · Artifact references:** Record the exact “Generated metadata normalization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C050-T03 · Fixture references:** Attach the “Generated metadata normalization” fixture IDs, input identities and oracle definition; preserve the source counterexample “Iteration order changes generated configuration bytes” as a distinct evidence case.
- [ ] **UC-M04.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Generated metadata normalization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C050-T05 · Environment record:** Record the actual “Generated metadata normalization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C050-T06 · Expected versus observed:** Pair every “Generated metadata normalization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C050-T07 · Failure and limit records:** Attach “Generated metadata normalization” change/failure and bounds evidence where required; include uncovered “Metadata bytes and ordering complexity” and unresolved violations of “Equivalent inputs produce identical declared metadata”.
- [ ] **UC-M04.02-C050-T08 · Evidence hygiene:** Check the “Generated metadata normalization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C050-T09 · Reproduction review:** Have the “Generated metadata normalization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C050-T10 · Acceptance linkage:** Link the “Generated metadata normalization” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Nondeterministic evidence separation

**Source delivery:** Store timestamps and host observations outside reproducible image content.

**Source invariant:** Evidence collection does not change the declared image digest.

**Source negative case:** A test timestamp is embedded into an otherwise reproducible image.

**Source bounded quantities:** Evidence bytes and image metadata boundaries.

### UC-M04.02-C051 · Contract

**Original checklist item:** Specify nondeterministic evidence separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C051-T01 · Scope statement:** Draft the operation boundary for “Nondeterministic evidence separation” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Nondeterministic evidence separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C051-T03 · Output inventory:** List the outputs of “Nondeterministic evidence separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Nondeterministic evidence separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C051-T05 · Prerequisite contract:** Map “Nondeterministic evidence separation” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Nondeterministic evidence separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C051-T07 · Invariant clause:** Add a normative clause for “Nondeterministic evidence separation” that preserves “Evidence collection does not change the declared image digest”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Nondeterministic evidence separation”; include the source counterexample “A test timestamp is embedded into an otherwise reproducible image” and the intended safe disposition.
- [ ] **UC-M04.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence bytes and image metadata boundaries” in the “Nondeterministic evidence separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C051-T10 · Contract review:** Review the “Nondeterministic evidence separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C052 · Delivery

**Original checklist item:** Store timestamps and host observations outside reproducible image content.

- [ ] **UC-M04.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Nondeterministic evidence separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C052-T02 · Change plan:** Break the source delivery for “Nondeterministic evidence separation” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Nondeterministic evidence separation” that realizes this source instruction: Store timestamps and host observations outside reproducible image content.
- [ ] **UC-M04.02-C052-T04 · Concrete realization:** Trace “Nondeterministic evidence separation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Nondeterministic evidence separation” needed to preserve “Evidence collection does not change the declared image digest”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C052-T06 · Dependency connection:** Connect the “Nondeterministic evidence separation” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C052-T07 · Resource behavior:** Account for “Evidence bytes and image metadata boundaries” in “Nondeterministic evidence separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C052-T08 · Delivery check:** Run the smallest real “Nondeterministic evidence separation” path and its adverse fixture “A test timestamp is embedded into an otherwise reproducible image”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C052-T09 · Patch review:** Review the “Nondeterministic evidence separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C052-T10 · Delivery handoff:** Publish the “Nondeterministic evidence separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Evidence collection does not change the declared image digest. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Nondeterministic evidence separation”; copy its required invariant exactly: “Evidence collection does not change the declared image digest”.
- [ ] **UC-M04.02-C053-T02 · Observable terms:** Define each term in the “Nondeterministic evidence separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C053-T03 · Precondition set:** List the preconditions under which “Evidence collection does not change the declared image digest” must hold for “Nondeterministic evidence separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C053-T04 · Transition coverage:** Map the “Nondeterministic evidence separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Nondeterministic evidence separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C053-T06 · Satisfying fixture:** Create a concrete “Nondeterministic evidence separation” case that satisfies “Evidence collection does not change the declared image digest”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C053-T07 · Violating fixture:** Create the source counterexample “A test timestamp is embedded into an otherwise reproducible image” for “Nondeterministic evidence separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C053-T08 · Enforcement evidence:** Exercise the “Nondeterministic evidence separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C053-T09 · Regression linkage:** Link the “Nondeterministic evidence separation” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Nondeterministic evidence separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C054 · Integration

**Original checklist item:** Integrate nondeterministic evidence separation with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Nondeterministic evidence separation” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C054-T02 · Field mapping:** Map every “Nondeterministic evidence separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Nondeterministic evidence separation” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C054-T04 · Ownership agreement:** Specify who owns “Nondeterministic evidence separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C054-T05 · Handoff implementation:** Connect “Nondeterministic evidence separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Evidence collection does not change the declared image digest” across the handoff.
- [ ] **UC-M04.02-C054-T06 · Absent-input case:** Omit one required “Nondeterministic evidence separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C054-T07 · Stale-input case:** Supply an outdated “Nondeterministic evidence separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Nondeterministic evidence separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C054-T09 · Valid integration trace:** Run a valid “Nondeterministic evidence separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C054-T10 · Seam review:** Reconcile the “Nondeterministic evidence separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for nondeterministic evidence separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Nondeterministic evidence separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C055-T02 · Expected-result oracle:** Specify the “Nondeterministic evidence separation” expected result independently of the implementation output; include the property “Evidence collection does not change the declared image digest” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C055-T03 · Fixture material:** Create the concrete “Nondeterministic evidence separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C055-T04 · Target preparation:** Prepare the “Nondeterministic evidence separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C055-T05 · Initial-state record:** Record the initial “Nondeterministic evidence separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C055-T06 · Valid-path execution:** Execute the “Nondeterministic evidence separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C055-T07 · Outcome comparison:** Compare every declared “Nondeterministic evidence separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C055-T08 · State and bounds check:** Inspect the “Nondeterministic evidence separation” ownership/state effects and actual use of “Evidence bytes and image metadata boundaries”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C055-T09 · Repeatability check:** Repeat the same “Nondeterministic evidence separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C055-T10 · Positive evidence:** Attach the “Nondeterministic evidence separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C056 · Negative test

**Original checklist item:** Negative case: A test timestamp is embedded into an otherwise reproducible image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Nondeterministic evidence separation” source counterexample: “A test timestamp is embedded into an otherwise reproducible image”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Nondeterministic evidence separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C056-T03 · Valid control:** Construct a valid “Nondeterministic evidence separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C056-T04 · Minimal adverse input:** Derive the “Nondeterministic evidence separation” adverse fixture from the control with the smallest documented change needed to reproduce “A test timestamp is embedded into an otherwise reproducible image”; retain that change as reproducible data.
- [ ] **UC-M04.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Nondeterministic evidence separation”; require “Evidence collection does not change the declared image digest” and forbid a false-success verdict.
- [ ] **UC-M04.02-C056-T06 · Adverse execution:** Exercise the “Nondeterministic evidence separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C056-T07 · Effect inspection:** Inspect “Nondeterministic evidence separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C056-T08 · Refusal versus failure:** Confirm the “Nondeterministic evidence separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C056-T09 · Reset and retention:** Restore only the disposable “Nondeterministic evidence separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C056-T10 · Negative regression:** Register the “Nondeterministic evidence separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C057 · Change / failure test

**Original checklist item:** Exercise nondeterministic evidence separation when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C057-T01 · Scenario record:** Write the “Nondeterministic evidence separation” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “Evidence collection does not change the declared image digest”.
- [ ] **UC-M04.02-C057-T02 · Baseline capture:** Create a known-valid “Nondeterministic evidence separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C057-T03 · Injection map:** Locate the “Nondeterministic evidence separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Nondeterministic evidence separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C057-T05 · Controlled trigger:** Introduce the controlled “Nondeterministic evidence separation” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C057-T06 · Intermediate inspection:** Inspect the “Nondeterministic evidence separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Nondeterministic evidence separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Nondeterministic evidence separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C057-T09 · Repeat and compare:** Repeat the selected “Nondeterministic evidence separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C057-T10 · Failure evidence:** Publish the “Nondeterministic evidence separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for evidence bytes and image metadata boundaries; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Nondeterministic evidence separation”: “Evidence bytes and image metadata boundaries”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C058-T02 · Measurement method:** Choose how to observe each “Nondeterministic evidence separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Nondeterministic evidence separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Nondeterministic evidence separation” cases for “Evidence bytes and image metadata boundaries”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Nondeterministic evidence separation” limit; preserve “Evidence collection does not change the declared image digest”.
- [ ] **UC-M04.02-C058-T06 · Normal measurement:** Run or review the normal “Nondeterministic evidence separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C058-T07 · At-limit measurement:** Exercise the “Nondeterministic evidence separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C058-T08 · Over-limit measurement:** Exercise the “Nondeterministic evidence separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C058-T09 · Uncovered-scope report:** List the “Nondeterministic evidence separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C058-T10 · Limit evidence:** Publish the selected “Nondeterministic evidence separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for nondeterministic evidence separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C059-T01 · Event inventory:** List the “Nondeterministic evidence separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Nondeterministic evidence separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C059-T03 · Failure mapping:** Map each documented “Nondeterministic evidence separation” refusal or error to a diagnostic outcome; include “A test timestamp is embedded into an otherwise reproducible image” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C059-T04 · Emission path:** Add the “Nondeterministic evidence separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C059-T05 · Redaction check:** Test “Nondeterministic evidence separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C059-T06 · Output budget:** Set and exercise bounded “Nondeterministic evidence separation” message size, rate and retention compatible with “Evidence bytes and image metadata boundaries”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C059-T07 · Success/refusal fixtures:** Capture “Nondeterministic evidence separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Nondeterministic evidence separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C059-T09 · Operator review:** Read the “Nondeterministic evidence separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C059-T10 · Diagnostic evidence:** Publish redacted “Nondeterministic evidence separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for nondeterministic evidence separation; label unexecuted checks as untested.

- [ ] **UC-M04.02-C060-T01 · Evidence inventory:** List the “Nondeterministic evidence separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C060-T02 · Artifact references:** Record the exact “Nondeterministic evidence separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C060-T03 · Fixture references:** Attach the “Nondeterministic evidence separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test timestamp is embedded into an otherwise reproducible image” as a distinct evidence case.
- [ ] **UC-M04.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Nondeterministic evidence separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C060-T05 · Environment record:** Record the actual “Nondeterministic evidence separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C060-T06 · Expected versus observed:** Pair every “Nondeterministic evidence separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C060-T07 · Failure and limit records:** Attach “Nondeterministic evidence separation” change/failure and bounds evidence where required; include uncovered “Evidence bytes and image metadata boundaries” and unresolved violations of “Evidence collection does not change the declared image digest”.
- [ ] **UC-M04.02-C060-T08 · Evidence hygiene:** Check the “Nondeterministic evidence separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C060-T09 · Reproduction review:** Have the “Nondeterministic evidence separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C060-T10 · Acceptance linkage:** Link the “Nondeterministic evidence separation” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Clean builder setup

**Source delivery:** Construct isolated builders without undeclared caches or user state.

**Source invariant:** A clean build uses only the locked dependency set.

**Source negative case:** A warm cache supplies a missing undeclared dependency.

**Source bounded quantities:** Builder disk, memory and initialization time.

### UC-M04.02-C061 · Contract

**Original checklist item:** Specify clean builder setup inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C061-T01 · Scope statement:** Draft the operation boundary for “Clean builder setup” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clean builder setup”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C061-T03 · Output inventory:** List the outputs of “Clean builder setup” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Clean builder setup”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C061-T05 · Prerequisite contract:** Map “Clean builder setup” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Clean builder setup”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C061-T07 · Invariant clause:** Add a normative clause for “Clean builder setup” that preserves “A clean build uses only the locked dependency set”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clean builder setup”; include the source counterexample “A warm cache supplies a missing undeclared dependency” and the intended safe disposition.
- [ ] **UC-M04.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Builder disk, memory and initialization time” in the “Clean builder setup” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C061-T10 · Contract review:** Review the “Clean builder setup” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C062 · Delivery

**Original checklist item:** Construct isolated builders without undeclared caches or user state.

- [ ] **UC-M04.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clean builder setup”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C062-T02 · Change plan:** Break the source delivery for “Clean builder setup” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Clean builder setup” that realizes this source instruction: Construct isolated builders without undeclared caches or user state.
- [ ] **UC-M04.02-C062-T04 · Concrete realization:** Trace “Clean builder setup” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clean builder setup” needed to preserve “A clean build uses only the locked dependency set”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C062-T06 · Dependency connection:** Connect the “Clean builder setup” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C062-T07 · Resource behavior:** Account for “Builder disk, memory and initialization time” in “Clean builder setup”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C062-T08 · Delivery check:** Run the smallest real “Clean builder setup” path and its adverse fixture “A warm cache supplies a missing undeclared dependency”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C062-T09 · Patch review:** Review the “Clean builder setup” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C062-T10 · Delivery handoff:** Publish the “Clean builder setup” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A clean build uses only the locked dependency set. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Clean builder setup”; copy its required invariant exactly: “A clean build uses only the locked dependency set”.
- [ ] **UC-M04.02-C063-T02 · Observable terms:** Define each term in the “Clean builder setup” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C063-T03 · Precondition set:** List the preconditions under which “A clean build uses only the locked dependency set” must hold for “Clean builder setup”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C063-T04 · Transition coverage:** Map the “Clean builder setup” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clean builder setup”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C063-T06 · Satisfying fixture:** Create a concrete “Clean builder setup” case that satisfies “A clean build uses only the locked dependency set”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C063-T07 · Violating fixture:** Create the source counterexample “A warm cache supplies a missing undeclared dependency” for “Clean builder setup”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C063-T08 · Enforcement evidence:** Exercise the “Clean builder setup” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C063-T09 · Regression linkage:** Link the “Clean builder setup” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Clean builder setup” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C064 · Integration

**Original checklist item:** Integrate clean builder setup with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clean builder setup” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C064-T02 · Field mapping:** Map every “Clean builder setup” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Clean builder setup” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C064-T04 · Ownership agreement:** Specify who owns “Clean builder setup” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C064-T05 · Handoff implementation:** Connect “Clean builder setup” through the mapped seam using the real adapter or explicit specification reference; preserve “A clean build uses only the locked dependency set” across the handoff.
- [ ] **UC-M04.02-C064-T06 · Absent-input case:** Omit one required “Clean builder setup” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C064-T07 · Stale-input case:** Supply an outdated “Clean builder setup” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Clean builder setup” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C064-T09 · Valid integration trace:** Run a valid “Clean builder setup” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C064-T10 · Seam review:** Reconcile the “Clean builder setup” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clean builder setup; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clean builder setup” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C065-T02 · Expected-result oracle:** Specify the “Clean builder setup” expected result independently of the implementation output; include the property “A clean build uses only the locked dependency set” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C065-T03 · Fixture material:** Create the concrete “Clean builder setup” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C065-T04 · Target preparation:** Prepare the “Clean builder setup” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C065-T05 · Initial-state record:** Record the initial “Clean builder setup” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C065-T06 · Valid-path execution:** Execute the “Clean builder setup” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C065-T07 · Outcome comparison:** Compare every declared “Clean builder setup” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C065-T08 · State and bounds check:** Inspect the “Clean builder setup” ownership/state effects and actual use of “Builder disk, memory and initialization time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C065-T09 · Repeatability check:** Repeat the same “Clean builder setup” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C065-T10 · Positive evidence:** Attach the “Clean builder setup” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C066 · Negative test

**Original checklist item:** Negative case: A warm cache supplies a missing undeclared dependency. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Clean builder setup” source counterexample: “A warm cache supplies a missing undeclared dependency”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Clean builder setup”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C066-T03 · Valid control:** Construct a valid “Clean builder setup” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C066-T04 · Minimal adverse input:** Derive the “Clean builder setup” adverse fixture from the control with the smallest documented change needed to reproduce “A warm cache supplies a missing undeclared dependency”; retain that change as reproducible data.
- [ ] **UC-M04.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clean builder setup”; require “A clean build uses only the locked dependency set” and forbid a false-success verdict.
- [ ] **UC-M04.02-C066-T06 · Adverse execution:** Exercise the “Clean builder setup” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C066-T07 · Effect inspection:** Inspect “Clean builder setup” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C066-T08 · Refusal versus failure:** Confirm the “Clean builder setup” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C066-T09 · Reset and retention:** Restore only the disposable “Clean builder setup” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C066-T10 · Negative regression:** Register the “Clean builder setup” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C067 · Change / failure test

**Original checklist item:** Exercise clean builder setup when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C067-T01 · Scenario record:** Write the “Clean builder setup” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “A clean build uses only the locked dependency set”.
- [ ] **UC-M04.02-C067-T02 · Baseline capture:** Create a known-valid “Clean builder setup” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C067-T03 · Injection map:** Locate the “Clean builder setup” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Clean builder setup” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C067-T05 · Controlled trigger:** Introduce the controlled “Clean builder setup” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C067-T06 · Intermediate inspection:** Inspect the “Clean builder setup” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clean builder setup”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Clean builder setup” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C067-T09 · Repeat and compare:** Repeat the selected “Clean builder setup” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C067-T10 · Failure evidence:** Publish the “Clean builder setup” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for builder disk, memory and initialization time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Clean builder setup”: “Builder disk, memory and initialization time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C068-T02 · Measurement method:** Choose how to observe each “Clean builder setup” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Clean builder setup”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clean builder setup” cases for “Builder disk, memory and initialization time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clean builder setup” limit; preserve “A clean build uses only the locked dependency set”.
- [ ] **UC-M04.02-C068-T06 · Normal measurement:** Run or review the normal “Clean builder setup” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C068-T07 · At-limit measurement:** Exercise the “Clean builder setup” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C068-T08 · Over-limit measurement:** Exercise the “Clean builder setup” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C068-T09 · Uncovered-scope report:** List the “Clean builder setup” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C068-T10 · Limit evidence:** Publish the selected “Clean builder setup” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clean builder setup with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C069-T01 · Event inventory:** List the “Clean builder setup” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Clean builder setup” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C069-T03 · Failure mapping:** Map each documented “Clean builder setup” refusal or error to a diagnostic outcome; include “A warm cache supplies a missing undeclared dependency” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C069-T04 · Emission path:** Add the “Clean builder setup” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C069-T05 · Redaction check:** Test “Clean builder setup” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C069-T06 · Output budget:** Set and exercise bounded “Clean builder setup” message size, rate and retention compatible with “Builder disk, memory and initialization time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C069-T07 · Success/refusal fixtures:** Capture “Clean builder setup” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clean builder setup” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C069-T09 · Operator review:** Read the “Clean builder setup” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C069-T10 · Diagnostic evidence:** Publish redacted “Clean builder setup” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clean builder setup; label unexecuted checks as untested.

- [ ] **UC-M04.02-C070-T01 · Evidence inventory:** List the “Clean builder setup” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C070-T02 · Artifact references:** Record the exact “Clean builder setup” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C070-T03 · Fixture references:** Attach the “Clean builder setup” fixture IDs, input identities and oracle definition; preserve the source counterexample “A warm cache supplies a missing undeclared dependency” as a distinct evidence case.
- [ ] **UC-M04.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clean builder setup”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C070-T05 · Environment record:** Record the actual “Clean builder setup” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C070-T06 · Expected versus observed:** Pair every “Clean builder setup” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C070-T07 · Failure and limit records:** Attach “Clean builder setup” change/failure and bounds evidence where required; include uncovered “Builder disk, memory and initialization time” and unresolved violations of “A clean build uses only the locked dependency set”.
- [ ] **UC-M04.02-C070-T08 · Evidence hygiene:** Check the “Clean builder setup” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C070-T09 · Reproduction review:** Have the “Clean builder setup” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C070-T10 · Acceptance linkage:** Link the “Clean builder setup” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Dual-build comparison

**Source delivery:** Run two independent clean builds and compare declared artifact digests.

**Source invariant:** Matching input claims are backed by observed output comparison.

**Source negative case:** Builds differ but the pipeline reports reproducibility passed.

**Source bounded quantities:** Build repetitions and comparison bytes.

### UC-M04.02-C071 · Contract

**Original checklist item:** Specify dual-build comparison inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C071-T01 · Scope statement:** Draft the operation boundary for “Dual-build comparison” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Dual-build comparison”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C071-T03 · Output inventory:** List the outputs of “Dual-build comparison” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Dual-build comparison”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C071-T05 · Prerequisite contract:** Map “Dual-build comparison” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Dual-build comparison”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C071-T07 · Invariant clause:** Add a normative clause for “Dual-build comparison” that preserves “Matching input claims are backed by observed output comparison”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Dual-build comparison”; include the source counterexample “Builds differ but the pipeline reports reproducibility passed” and the intended safe disposition.
- [ ] **UC-M04.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Build repetitions and comparison bytes” in the “Dual-build comparison” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C071-T10 · Contract review:** Review the “Dual-build comparison” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C072 · Delivery

**Original checklist item:** Run two independent clean builds and compare declared artifact digests.

- [ ] **UC-M04.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Dual-build comparison”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C072-T02 · Change plan:** Break the source delivery for “Dual-build comparison” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C072-T03 · Core artifact:** Create the “Dual-build comparison” fixture or harness for this source instruction: Run two independent clean builds and compare declared artifact digests.
- [ ] **UC-M04.02-C072-T04 · Concrete realization:** Connect the “Dual-build comparison” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Dual-build comparison” needed to preserve “Matching input claims are backed by observed output comparison”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C072-T06 · Dependency connection:** Connect the “Dual-build comparison” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C072-T07 · Resource behavior:** Account for “Build repetitions and comparison bytes” in “Dual-build comparison”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C072-T08 · Delivery check:** Run the smallest real “Dual-build comparison” path and its adverse fixture “Builds differ but the pipeline reports reproducibility passed”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C072-T09 · Patch review:** Review the “Dual-build comparison” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C072-T10 · Delivery handoff:** Publish the “Dual-build comparison” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Matching input claims are backed by observed output comparison. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Dual-build comparison”; copy its required invariant exactly: “Matching input claims are backed by observed output comparison”.
- [ ] **UC-M04.02-C073-T02 · Observable terms:** Define each term in the “Dual-build comparison” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C073-T03 · Precondition set:** List the preconditions under which “Matching input claims are backed by observed output comparison” must hold for “Dual-build comparison”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C073-T04 · Transition coverage:** Map the “Dual-build comparison” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Dual-build comparison”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C073-T06 · Satisfying fixture:** Create a concrete “Dual-build comparison” case that satisfies “Matching input claims are backed by observed output comparison”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C073-T07 · Violating fixture:** Create the source counterexample “Builds differ but the pipeline reports reproducibility passed” for “Dual-build comparison”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C073-T08 · Enforcement evidence:** Exercise the “Dual-build comparison” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C073-T09 · Regression linkage:** Link the “Dual-build comparison” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Dual-build comparison” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C074 · Integration

**Original checklist item:** Integrate dual-build comparison with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Dual-build comparison” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C074-T02 · Field mapping:** Map every “Dual-build comparison” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Dual-build comparison” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C074-T04 · Ownership agreement:** Specify who owns “Dual-build comparison” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C074-T05 · Handoff implementation:** Connect “Dual-build comparison” through the mapped seam using the real adapter or explicit specification reference; preserve “Matching input claims are backed by observed output comparison” across the handoff.
- [ ] **UC-M04.02-C074-T06 · Absent-input case:** Omit one required “Dual-build comparison” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C074-T07 · Stale-input case:** Supply an outdated “Dual-build comparison” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Dual-build comparison” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C074-T09 · Valid integration trace:** Run a valid “Dual-build comparison” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C074-T10 · Seam review:** Reconcile the “Dual-build comparison” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for dual-build comparison; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Dual-build comparison” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C075-T02 · Expected-result oracle:** Specify the “Dual-build comparison” expected result independently of the implementation output; include the property “Matching input claims are backed by observed output comparison” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C075-T03 · Fixture material:** Create the concrete “Dual-build comparison” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C075-T04 · Target preparation:** Prepare the “Dual-build comparison” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C075-T05 · Initial-state record:** Record the initial “Dual-build comparison” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C075-T06 · Valid-path execution:** Execute the “Dual-build comparison” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C075-T07 · Outcome comparison:** Compare every declared “Dual-build comparison” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C075-T08 · State and bounds check:** Inspect the “Dual-build comparison” ownership/state effects and actual use of “Build repetitions and comparison bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C075-T09 · Repeatability check:** Repeat the same “Dual-build comparison” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C075-T10 · Positive evidence:** Attach the “Dual-build comparison” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C076 · Negative test

**Original checklist item:** Negative case: Builds differ but the pipeline reports reproducibility passed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Dual-build comparison” source counterexample: “Builds differ but the pipeline reports reproducibility passed”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Dual-build comparison”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C076-T03 · Valid control:** Construct a valid “Dual-build comparison” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C076-T04 · Minimal adverse input:** Derive the “Dual-build comparison” adverse fixture from the control with the smallest documented change needed to reproduce “Builds differ but the pipeline reports reproducibility passed”; retain that change as reproducible data.
- [ ] **UC-M04.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Dual-build comparison”; require “Matching input claims are backed by observed output comparison” and forbid a false-success verdict.
- [ ] **UC-M04.02-C076-T06 · Adverse execution:** Exercise the “Dual-build comparison” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C076-T07 · Effect inspection:** Inspect “Dual-build comparison” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C076-T08 · Refusal versus failure:** Confirm the “Dual-build comparison” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C076-T09 · Reset and retention:** Restore only the disposable “Dual-build comparison” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C076-T10 · Negative regression:** Register the “Dual-build comparison” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C077 · Change / failure test

**Original checklist item:** Exercise dual-build comparison when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C077-T01 · Scenario record:** Write the “Dual-build comparison” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “Matching input claims are backed by observed output comparison”.
- [ ] **UC-M04.02-C077-T02 · Baseline capture:** Create a known-valid “Dual-build comparison” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C077-T03 · Injection map:** Locate the “Dual-build comparison” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Dual-build comparison” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C077-T05 · Controlled trigger:** Introduce the controlled “Dual-build comparison” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C077-T06 · Intermediate inspection:** Inspect the “Dual-build comparison” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Dual-build comparison”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Dual-build comparison” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C077-T09 · Repeat and compare:** Repeat the selected “Dual-build comparison” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C077-T10 · Failure evidence:** Publish the “Dual-build comparison” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for build repetitions and comparison bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Dual-build comparison”: “Build repetitions and comparison bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C078-T02 · Measurement method:** Choose how to observe each “Dual-build comparison” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Dual-build comparison”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Dual-build comparison” cases for “Build repetitions and comparison bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Dual-build comparison” limit; preserve “Matching input claims are backed by observed output comparison”.
- [ ] **UC-M04.02-C078-T06 · Normal measurement:** Run or review the normal “Dual-build comparison” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C078-T07 · At-limit measurement:** Exercise the “Dual-build comparison” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C078-T08 · Over-limit measurement:** Exercise the “Dual-build comparison” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C078-T09 · Uncovered-scope report:** List the “Dual-build comparison” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C078-T10 · Limit evidence:** Publish the selected “Dual-build comparison” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for dual-build comparison with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C079-T01 · Event inventory:** List the “Dual-build comparison” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Dual-build comparison” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C079-T03 · Failure mapping:** Map each documented “Dual-build comparison” refusal or error to a diagnostic outcome; include “Builds differ but the pipeline reports reproducibility passed” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C079-T04 · Emission path:** Add the “Dual-build comparison” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C079-T05 · Redaction check:** Test “Dual-build comparison” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C079-T06 · Output budget:** Set and exercise bounded “Dual-build comparison” message size, rate and retention compatible with “Build repetitions and comparison bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C079-T07 · Success/refusal fixtures:** Capture “Dual-build comparison” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Dual-build comparison” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C079-T09 · Operator review:** Read the “Dual-build comparison” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C079-T10 · Diagnostic evidence:** Publish redacted “Dual-build comparison” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for dual-build comparison; label unexecuted checks as untested.

- [ ] **UC-M04.02-C080-T01 · Evidence inventory:** List the “Dual-build comparison” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C080-T02 · Artifact references:** Record the exact “Dual-build comparison” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C080-T03 · Fixture references:** Attach the “Dual-build comparison” fixture IDs, input identities and oracle definition; preserve the source counterexample “Builds differ but the pipeline reports reproducibility passed” as a distinct evidence case.
- [ ] **UC-M04.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Dual-build comparison”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C080-T05 · Environment record:** Record the actual “Dual-build comparison” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C080-T06 · Expected versus observed:** Pair every “Dual-build comparison” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C080-T07 · Failure and limit records:** Attach “Dual-build comparison” change/failure and bounds evidence where required; include uncovered “Build repetitions and comparison bytes” and unresolved violations of “Matching input claims are backed by observed output comparison”.
- [ ] **UC-M04.02-C080-T08 · Evidence hygiene:** Check the “Dual-build comparison” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C080-T09 · Reproduction review:** Have the “Dual-build comparison” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C080-T10 · Acceptance linkage:** Link the “Dual-build comparison” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Difference analysis

**Source delivery:** Retain structured differences when declared outputs do not match.

**Source invariant:** A mismatch is explained or remains an explicit blocker.

**Source negative case:** A difference is dismissed without identifying its source.

**Source bounded quantities:** Diff output size and analysis budget.

### UC-M04.02-C081 · Contract

**Original checklist item:** Specify difference analysis inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C081-T01 · Scope statement:** Draft the operation boundary for “Difference analysis” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Difference analysis”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C081-T03 · Output inventory:** List the outputs of “Difference analysis” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Difference analysis”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C081-T05 · Prerequisite contract:** Map “Difference analysis” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Difference analysis”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C081-T07 · Invariant clause:** Add a normative clause for “Difference analysis” that preserves “A mismatch is explained or remains an explicit blocker”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Difference analysis”; include the source counterexample “A difference is dismissed without identifying its source” and the intended safe disposition.
- [ ] **UC-M04.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Diff output size and analysis budget” in the “Difference analysis” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C081-T10 · Contract review:** Review the “Difference analysis” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C082 · Delivery

**Original checklist item:** Retain structured differences when declared outputs do not match.

- [ ] **UC-M04.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Difference analysis”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C082-T02 · Change plan:** Break the source delivery for “Difference analysis” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Difference analysis” that realizes this source instruction: Retain structured differences when declared outputs do not match.
- [ ] **UC-M04.02-C082-T04 · Concrete realization:** Trace “Difference analysis” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Difference analysis” needed to preserve “A mismatch is explained or remains an explicit blocker”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C082-T06 · Dependency connection:** Connect the “Difference analysis” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C082-T07 · Resource behavior:** Account for “Diff output size and analysis budget” in “Difference analysis”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C082-T08 · Delivery check:** Run the smallest real “Difference analysis” path and its adverse fixture “A difference is dismissed without identifying its source”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C082-T09 · Patch review:** Review the “Difference analysis” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C082-T10 · Delivery handoff:** Publish the “Difference analysis” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A mismatch is explained or remains an explicit blocker. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Difference analysis”; copy its required invariant exactly: “A mismatch is explained or remains an explicit blocker”.
- [ ] **UC-M04.02-C083-T02 · Observable terms:** Define each term in the “Difference analysis” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C083-T03 · Precondition set:** List the preconditions under which “A mismatch is explained or remains an explicit blocker” must hold for “Difference analysis”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C083-T04 · Transition coverage:** Map the “Difference analysis” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Difference analysis”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C083-T06 · Satisfying fixture:** Create a concrete “Difference analysis” case that satisfies “A mismatch is explained or remains an explicit blocker”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C083-T07 · Violating fixture:** Create the source counterexample “A difference is dismissed without identifying its source” for “Difference analysis”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C083-T08 · Enforcement evidence:** Exercise the “Difference analysis” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C083-T09 · Regression linkage:** Link the “Difference analysis” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Difference analysis” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C084 · Integration

**Original checklist item:** Integrate difference analysis with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Difference analysis” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C084-T02 · Field mapping:** Map every “Difference analysis” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Difference analysis” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C084-T04 · Ownership agreement:** Specify who owns “Difference analysis” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C084-T05 · Handoff implementation:** Connect “Difference analysis” through the mapped seam using the real adapter or explicit specification reference; preserve “A mismatch is explained or remains an explicit blocker” across the handoff.
- [ ] **UC-M04.02-C084-T06 · Absent-input case:** Omit one required “Difference analysis” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C084-T07 · Stale-input case:** Supply an outdated “Difference analysis” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Difference analysis” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C084-T09 · Valid integration trace:** Run a valid “Difference analysis” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C084-T10 · Seam review:** Reconcile the “Difference analysis” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for difference analysis; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Difference analysis” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C085-T02 · Expected-result oracle:** Specify the “Difference analysis” expected result independently of the implementation output; include the property “A mismatch is explained or remains an explicit blocker” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C085-T03 · Fixture material:** Create the concrete “Difference analysis” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C085-T04 · Target preparation:** Prepare the “Difference analysis” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C085-T05 · Initial-state record:** Record the initial “Difference analysis” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C085-T06 · Valid-path execution:** Execute the “Difference analysis” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C085-T07 · Outcome comparison:** Compare every declared “Difference analysis” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C085-T08 · State and bounds check:** Inspect the “Difference analysis” ownership/state effects and actual use of “Diff output size and analysis budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C085-T09 · Repeatability check:** Repeat the same “Difference analysis” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C085-T10 · Positive evidence:** Attach the “Difference analysis” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C086 · Negative test

**Original checklist item:** Negative case: A difference is dismissed without identifying its source. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Difference analysis” source counterexample: “A difference is dismissed without identifying its source”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Difference analysis”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C086-T03 · Valid control:** Construct a valid “Difference analysis” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C086-T04 · Minimal adverse input:** Derive the “Difference analysis” adverse fixture from the control with the smallest documented change needed to reproduce “A difference is dismissed without identifying its source”; retain that change as reproducible data.
- [ ] **UC-M04.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Difference analysis”; require “A mismatch is explained or remains an explicit blocker” and forbid a false-success verdict.
- [ ] **UC-M04.02-C086-T06 · Adverse execution:** Exercise the “Difference analysis” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C086-T07 · Effect inspection:** Inspect “Difference analysis” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C086-T08 · Refusal versus failure:** Confirm the “Difference analysis” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C086-T09 · Reset and retention:** Restore only the disposable “Difference analysis” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C086-T10 · Negative regression:** Register the “Difference analysis” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C087 · Change / failure test

**Original checklist item:** Exercise difference analysis when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C087-T01 · Scenario record:** Write the “Difference analysis” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “A mismatch is explained or remains an explicit blocker”.
- [ ] **UC-M04.02-C087-T02 · Baseline capture:** Create a known-valid “Difference analysis” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C087-T03 · Injection map:** Locate the “Difference analysis” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Difference analysis” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C087-T05 · Controlled trigger:** Introduce the controlled “Difference analysis” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C087-T06 · Intermediate inspection:** Inspect the “Difference analysis” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Difference analysis”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Difference analysis” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C087-T09 · Repeat and compare:** Repeat the selected “Difference analysis” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C087-T10 · Failure evidence:** Publish the “Difference analysis” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for diff output size and analysis budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Difference analysis”: “Diff output size and analysis budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C088-T02 · Measurement method:** Choose how to observe each “Difference analysis” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Difference analysis”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Difference analysis” cases for “Diff output size and analysis budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Difference analysis” limit; preserve “A mismatch is explained or remains an explicit blocker”.
- [ ] **UC-M04.02-C088-T06 · Normal measurement:** Run or review the normal “Difference analysis” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C088-T07 · At-limit measurement:** Exercise the “Difference analysis” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C088-T08 · Over-limit measurement:** Exercise the “Difference analysis” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C088-T09 · Uncovered-scope report:** List the “Difference analysis” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C088-T10 · Limit evidence:** Publish the selected “Difference analysis” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for difference analysis with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C089-T01 · Event inventory:** List the “Difference analysis” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Difference analysis” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C089-T03 · Failure mapping:** Map each documented “Difference analysis” refusal or error to a diagnostic outcome; include “A difference is dismissed without identifying its source” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C089-T04 · Emission path:** Add the “Difference analysis” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C089-T05 · Redaction check:** Test “Difference analysis” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C089-T06 · Output budget:** Set and exercise bounded “Difference analysis” message size, rate and retention compatible with “Diff output size and analysis budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C089-T07 · Success/refusal fixtures:** Capture “Difference analysis” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Difference analysis” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C089-T09 · Operator review:** Read the “Difference analysis” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C089-T10 · Diagnostic evidence:** Publish redacted “Difference analysis” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for difference analysis; label unexecuted checks as untested.

- [ ] **UC-M04.02-C090-T01 · Evidence inventory:** List the “Difference analysis” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C090-T02 · Artifact references:** Record the exact “Difference analysis” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C090-T03 · Fixture references:** Attach the “Difference analysis” fixture IDs, input identities and oracle definition; preserve the source counterexample “A difference is dismissed without identifying its source” as a distinct evidence case.
- [ ] **UC-M04.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Difference analysis”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C090-T05 · Environment record:** Record the actual “Difference analysis” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C090-T06 · Expected versus observed:** Pair every “Difference analysis” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C090-T07 · Failure and limit records:** Attach “Difference analysis” change/failure and bounds evidence where required; include uncovered “Diff output size and analysis budget” and unresolved violations of “A mismatch is explained or remains an explicit blocker”.
- [ ] **UC-M04.02-C090-T08 · Evidence hygiene:** Check the “Difference analysis” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C090-T09 · Reproduction review:** Have the “Difference analysis” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C090-T10 · Acceptance linkage:** Link the “Difference analysis” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Reproducibility boundary

**Source delivery:** Publish which artifacts and environments the reproducibility claim covers.

**Source invariant:** A limited reproducibility result is not presented as universal.

**Source negative case:** One target's success is generalized to all host architectures.

**Source bounded quantities:** Qualified targets and evidence freshness.

### UC-M04.02-C091 · Contract

**Original checklist item:** Specify reproducibility boundary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.02-C091-T01 · Scope statement:** Draft the operation boundary for “Reproducibility boundary” within Hermetic and reproducible build recipe; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reproducibility boundary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.02-C091-T03 · Output inventory:** List the outputs of “Reproducibility boundary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Reproducibility boundary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.02-C091-T05 · Prerequisite contract:** Map “Reproducibility boundary” to the source component prerequisites (UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Reproducibility boundary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.02-C091-T07 · Invariant clause:** Add a normative clause for “Reproducibility boundary” that preserves “A limited reproducibility result is not presented as universal”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reproducibility boundary”; include the source counterexample “One target's success is generalized to all host architectures” and the intended safe disposition.
- [ ] **UC-M04.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Qualified targets and evidence freshness” in the “Reproducibility boundary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.02-C091-T10 · Contract review:** Review the “Reproducibility boundary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.02-C092 · Delivery

**Original checklist item:** Publish which artifacts and environments the reproducibility claim covers.

- [ ] **UC-M04.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reproducibility boundary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.02-C092-T02 · Change plan:** Break the source delivery for “Reproducibility boundary” into concrete edit targets and reviewable outputs; keep the UC-M04.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.02-C092-T03 · Core artifact:** Create the “Reproducibility boundary” output artifact for this source instruction: Publish which artifacts and environments the reproducibility claim covers.
- [ ] **UC-M04.02-C092-T04 · Concrete realization:** Populate the “Reproducibility boundary” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M04.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reproducibility boundary” needed to preserve “A limited reproducibility result is not presented as universal”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.02-C092-T06 · Dependency connection:** Connect the “Reproducibility boundary” implementation to normalized build recipes, isolated builders and image digest comparison; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.02-C092-T07 · Resource behavior:** Account for “Qualified targets and evidence freshness” in “Reproducibility boundary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.02-C092-T08 · Delivery check:** Run the smallest real “Reproducibility boundary” path and its adverse fixture “One target's success is generalized to all host architectures”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.02-C092-T09 · Patch review:** Review the “Reproducibility boundary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.02-C092-T10 · Delivery handoff:** Publish the “Reproducibility boundary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A limited reproducibility result is not presented as universal. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Reproducibility boundary”; copy its required invariant exactly: “A limited reproducibility result is not presented as universal”.
- [ ] **UC-M04.02-C093-T02 · Observable terms:** Define each term in the “Reproducibility boundary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.02-C093-T03 · Precondition set:** List the preconditions under which “A limited reproducibility result is not presented as universal” must hold for “Reproducibility boundary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.02-C093-T04 · Transition coverage:** Map the “Reproducibility boundary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reproducibility boundary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.02-C093-T06 · Satisfying fixture:** Create a concrete “Reproducibility boundary” case that satisfies “A limited reproducibility result is not presented as universal”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.02-C093-T07 · Violating fixture:** Create the source counterexample “One target's success is generalized to all host architectures” for “Reproducibility boundary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.02-C093-T08 · Enforcement evidence:** Exercise the “Reproducibility boundary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.02-C093-T09 · Regression linkage:** Link the “Reproducibility boundary” property to changes in normalized build recipes, isolated builders and image digest comparison; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Reproducibility boundary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.02-C094 · Integration

**Original checklist item:** Integrate reproducibility boundary with normalized build recipes, isolated builders and image digest comparison; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reproducibility boundary” across normalized build recipes, isolated builders and image digest comparison; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.02-C094-T02 · Field mapping:** Map every “Reproducibility boundary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Reproducibility boundary” (source dependency list: UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.02-C094-T04 · Ownership agreement:** Specify who owns “Reproducibility boundary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.02-C094-T05 · Handoff implementation:** Connect “Reproducibility boundary” through the mapped seam using the real adapter or explicit specification reference; preserve “A limited reproducibility result is not presented as universal” across the handoff.
- [ ] **UC-M04.02-C094-T06 · Absent-input case:** Omit one required “Reproducibility boundary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.02-C094-T07 · Stale-input case:** Supply an outdated “Reproducibility boundary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Reproducibility boundary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.02-C094-T09 · Valid integration trace:** Run a valid “Reproducibility boundary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.02-C094-T10 · Seam review:** Reconcile the “Reproducibility boundary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reproducibility boundary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reproducibility boundary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.02-C095-T02 · Expected-result oracle:** Specify the “Reproducibility boundary” expected result independently of the implementation output; include the property “A limited reproducibility result is not presented as universal” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.02-C095-T03 · Fixture material:** Create the concrete “Reproducibility boundary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.02-C095-T04 · Target preparation:** Prepare the “Reproducibility boundary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.02-C095-T05 · Initial-state record:** Record the initial “Reproducibility boundary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.02-C095-T06 · Valid-path execution:** Execute the “Reproducibility boundary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.02-C095-T07 · Outcome comparison:** Compare every declared “Reproducibility boundary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.02-C095-T08 · State and bounds check:** Inspect the “Reproducibility boundary” ownership/state effects and actual use of “Qualified targets and evidence freshness”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.02-C095-T09 · Repeatability check:** Repeat the same “Reproducibility boundary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.02-C095-T10 · Positive evidence:** Attach the “Reproducibility boundary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.02-C096 · Negative test

**Original checklist item:** Negative case: One target's success is generalized to all host architectures. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Reproducibility boundary” source counterexample: “One target's success is generalized to all host architectures”; state which precondition or invariant it challenges.
- [ ] **UC-M04.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Reproducibility boundary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.02-C096-T03 · Valid control:** Construct a valid “Reproducibility boundary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.02-C096-T04 · Minimal adverse input:** Derive the “Reproducibility boundary” adverse fixture from the control with the smallest documented change needed to reproduce “One target's success is generalized to all host architectures”; retain that change as reproducible data.
- [ ] **UC-M04.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reproducibility boundary”; require “A limited reproducibility result is not presented as universal” and forbid a false-success verdict.
- [ ] **UC-M04.02-C096-T06 · Adverse execution:** Exercise the “Reproducibility boundary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.02-C096-T07 · Effect inspection:** Inspect “Reproducibility boundary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.02-C096-T08 · Refusal versus failure:** Confirm the “Reproducibility boundary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.02-C096-T09 · Reset and retention:** Restore only the disposable “Reproducibility boundary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.02-C096-T10 · Negative regression:** Register the “Reproducibility boundary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.02-C097 · Change / failure test

**Original checklist item:** Exercise reproducibility boundary when a second clean builder uses a different workspace path or ambient environment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.02-C097-T01 · Scenario record:** Write the “Reproducibility boundary” change/failure scenario exactly as supplied: a second clean builder uses a different workspace path or ambient environment; identify the property that must remain true: “A limited reproducibility result is not presented as universal”.
- [ ] **UC-M04.02-C097-T02 · Baseline capture:** Create a known-valid “Reproducibility boundary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.02-C097-T03 · Injection map:** Locate the “Reproducibility boundary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Reproducibility boundary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.02-C097-T05 · Controlled trigger:** Introduce the controlled “Reproducibility boundary” scenario in the disposable fixture: a second clean builder uses a different workspace path or ambient environment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.02-C097-T06 · Intermediate inspection:** Inspect the “Reproducibility boundary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reproducibility boundary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Reproducibility boundary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.02-C097-T09 · Repeat and compare:** Repeat the selected “Reproducibility boundary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.02-C097-T10 · Failure evidence:** Publish the “Reproducibility boundary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for qualified targets and evidence freshness; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Reproducibility boundary”: “Qualified targets and evidence freshness”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.02-C098-T02 · Measurement method:** Choose how to observe each “Reproducibility boundary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Reproducibility boundary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reproducibility boundary” cases for “Qualified targets and evidence freshness”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reproducibility boundary” limit; preserve “A limited reproducibility result is not presented as universal”.
- [ ] **UC-M04.02-C098-T06 · Normal measurement:** Run or review the normal “Reproducibility boundary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.02-C098-T07 · At-limit measurement:** Exercise the “Reproducibility boundary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.02-C098-T08 · Over-limit measurement:** Exercise the “Reproducibility boundary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.02-C098-T09 · Uncovered-scope report:** List the “Reproducibility boundary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.02-C098-T10 · Limit evidence:** Publish the selected “Reproducibility boundary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reproducibility boundary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.02-C099-T01 · Event inventory:** List the “Reproducibility boundary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Reproducibility boundary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.02-C099-T03 · Failure mapping:** Map each documented “Reproducibility boundary” refusal or error to a diagnostic outcome; include “One target's success is generalized to all host architectures” and prohibit conversion into a success message.
- [ ] **UC-M04.02-C099-T04 · Emission path:** Add the “Reproducibility boundary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.02-C099-T05 · Redaction check:** Test “Reproducibility boundary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.02-C099-T06 · Output budget:** Set and exercise bounded “Reproducibility boundary” message size, rate and retention compatible with “Qualified targets and evidence freshness”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.02-C099-T07 · Success/refusal fixtures:** Capture “Reproducibility boundary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reproducibility boundary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.02-C099-T09 · Operator review:** Read the “Reproducibility boundary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.02-C099-T10 · Diagnostic evidence:** Publish redacted “Reproducibility boundary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reproducibility boundary; label unexecuted checks as untested.

- [ ] **UC-M04.02-C100-T01 · Evidence inventory:** List the “Reproducibility boundary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.02-C100-T02 · Artifact references:** Record the exact “Reproducibility boundary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.02-C100-T03 · Fixture references:** Attach the “Reproducibility boundary” fixture IDs, input identities and oracle definition; preserve the source counterexample “One target's success is generalized to all host architectures” as a distinct evidence case.
- [ ] **UC-M04.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reproducibility boundary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.02-C100-T05 · Environment record:** Record the actual “Reproducibility boundary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.02-C100-T06 · Expected versus observed:** Pair every “Reproducibility boundary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.02-C100-T07 · Failure and limit records:** Attach “Reproducibility boundary” change/failure and bounds evidence where required; include uncovered “Qualified targets and evidence freshness” and unresolved violations of “A limited reproducibility result is not presented as universal”.
- [ ] **UC-M04.02-C100-T08 · Evidence hygiene:** Check the “Reproducibility boundary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.02-C100-T09 · Reproduction review:** Have the “Reproducibility boundary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.02-C100-T10 · Acceptance linkage:** Link the “Reproducibility boundary” evidence to its parent and UC-M04.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

