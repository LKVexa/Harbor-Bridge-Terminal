# UC-M04.04 — Semantic translation validation

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.07](../01/UC-M01.07.md), [UC-M02.08](../02/UC-M02.08.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Compare source semantics, intermediate representation and native results across supported dialects; bound lowering sizes and arithmetic.

**Original acceptance criterion:** Generated and hand-written semantic test programs agree under edge cases; unsupported features are refused explicitly.

**Source trace:** Original checklist `UC100/c/04/UC-M04.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 367–377 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Source semantic fixtures

**Source delivery:** Create reference programs for supported dialect features and edge cases.

**Source invariant:** Source correctness is assessed against defined observable behavior.

**Source negative case:** Only trivial programs are used to approve a dialect.

**Source bounded quantities:** Program count and supported feature coverage.

### UC-M04.04-C001 · Contract

**Original checklist item:** Define the qualification objective for source semantic fixtures, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C001-T01 · Scope statement:** Write the qualification question for “Source semantic fixtures”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Source semantic fixtures”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C001-T03 · Output inventory:** List the outputs of “Source semantic fixtures” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Source semantic fixtures”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C001-T05 · Prerequisite contract:** Map “Source semantic fixtures” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Source semantic fixtures”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C001-T07 · Invariant clause:** Add a normative clause for “Source semantic fixtures” that preserves “Source correctness is assessed against defined observable behavior”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Source semantic fixtures”; include the source counterexample “Only trivial programs are used to approve a dialect” and the intended safe disposition.
- [ ] **UC-M04.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Program count and supported feature coverage” in the “Source semantic fixtures” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C001-T10 · Contract review:** Review the “Source semantic fixtures” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C002 · Delivery

**Original checklist item:** Create reference programs for supported dialect features and edge cases.

- [ ] **UC-M04.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Source semantic fixtures”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C002-T02 · Change plan:** Break the source delivery for “Source semantic fixtures” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Source semantic fixtures” that realizes this source instruction: Create reference programs for supported dialect features and edge cases.
- [ ] **UC-M04.04-C002-T04 · Concrete realization:** Trace “Source semantic fixtures” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Source semantic fixtures” needed to preserve “Source correctness is assessed against defined observable behavior”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C002-T06 · Dependency connection:** Connect the “Source semantic fixtures” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C002-T07 · Resource behavior:** Account for “Program count and supported feature coverage” in “Source semantic fixtures”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Source semantic fixtures”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C002-T09 · Patch review:** Review the “Source semantic fixtures” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C002-T10 · Delivery handoff:** Publish the “Source semantic fixtures” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Source correctness is assessed against defined observable behavior. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Source semantic fixtures”; copy its required invariant exactly: “Source correctness is assessed against defined observable behavior”.
- [ ] **UC-M04.04-C003-T02 · Observable terms:** Define each term in the “Source semantic fixtures” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C003-T03 · Precondition set:** List the preconditions under which “Source correctness is assessed against defined observable behavior” must hold for “Source semantic fixtures”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C003-T04 · Transition coverage:** Map the “Source semantic fixtures” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Source semantic fixtures”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C003-T06 · Satisfying fixture:** Create a concrete “Source semantic fixtures” case that satisfies “Source correctness is assessed against defined observable behavior”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C003-T07 · Violating fixture:** Create the source counterexample “Only trivial programs are used to approve a dialect” for “Source semantic fixtures”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C003-T08 · Enforcement evidence:** Exercise the “Source semantic fixtures” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C003-T09 · Regression linkage:** Link the “Source semantic fixtures” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Source semantic fixtures” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C004 · Integration

**Original checklist item:** Integrate source semantic fixtures with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Source semantic fixtures” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C004-T02 · Field mapping:** Map every “Source semantic fixtures” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Source semantic fixtures” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C004-T04 · Ownership agreement:** Specify who owns “Source semantic fixtures” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C004-T05 · Handoff implementation:** Connect “Source semantic fixtures” through the mapped seam using the real adapter or explicit specification reference; preserve “Source correctness is assessed against defined observable behavior” across the handoff.
- [ ] **UC-M04.04-C004-T06 · Absent-input case:** Omit one required “Source semantic fixtures” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C004-T07 · Stale-input case:** Supply an outdated “Source semantic fixtures” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Source semantic fixtures” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C004-T09 · Valid integration trace:** Run a valid “Source semantic fixtures” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C004-T10 · Seam review:** Reconcile the “Source semantic fixtures” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for source semantic fixtures; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Source semantic fixtures”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C005-T02 · Expected-result oracle:** Specify the “Source semantic fixtures” expected result independently of the implementation output; include the property “Source correctness is assessed against defined observable behavior” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C005-T03 · Fixture material:** Create the concrete “Source semantic fixtures” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C005-T04 · Target preparation:** Prepare the “Source semantic fixtures” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C005-T05 · Initial-state record:** Record the initial “Source semantic fixtures” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C005-T06 · Valid-path execution:** Run the “Source semantic fixtures” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C005-T07 · Outcome comparison:** Compare every declared “Source semantic fixtures” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C005-T08 · State and bounds check:** Inspect the “Source semantic fixtures” ownership/state effects and actual use of “Program count and supported feature coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C005-T09 · Repeatability check:** Repeat the same “Source semantic fixtures” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C005-T10 · Positive evidence:** Attach the “Source semantic fixtures” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C006 · Negative test

**Original checklist item:** Negative case: Only trivial programs are used to approve a dialect. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Source semantic fixtures” source counterexample: “Only trivial programs are used to approve a dialect”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Source semantic fixtures”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C006-T03 · Valid control:** Construct a valid “Source semantic fixtures” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C006-T04 · Minimal adverse input:** Derive the “Source semantic fixtures” adverse fixture from the control with the smallest documented change needed to reproduce “Only trivial programs are used to approve a dialect”; retain that change as reproducible data.
- [ ] **UC-M04.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Source semantic fixtures”; require “Source correctness is assessed against defined observable behavior” and forbid a false-success verdict.
- [ ] **UC-M04.04-C006-T06 · Adverse execution:** Exercise the “Source semantic fixtures” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C006-T07 · Effect inspection:** Inspect “Source semantic fixtures” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C006-T08 · Refusal versus failure:** Confirm the “Source semantic fixtures” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C006-T09 · Reset and retention:** Restore only the disposable “Source semantic fixtures” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C006-T10 · Negative regression:** Register the “Source semantic fixtures” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C007 · Change / failure test

**Original checklist item:** Exercise source semantic fixtures when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C007-T01 · Scenario record:** Write the “Source semantic fixtures” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Source correctness is assessed against defined observable behavior”.
- [ ] **UC-M04.04-C007-T02 · Baseline capture:** Create a known-valid “Source semantic fixtures” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C007-T03 · Injection map:** Locate the “Source semantic fixtures” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Source semantic fixtures” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C007-T05 · Controlled trigger:** Introduce the controlled “Source semantic fixtures” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C007-T06 · Intermediate inspection:** Inspect the “Source semantic fixtures” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Source semantic fixtures”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Source semantic fixtures” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C007-T09 · Repeat and compare:** Repeat the selected “Source semantic fixtures” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C007-T10 · Failure evidence:** Publish the “Source semantic fixtures” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for program count and supported feature coverage; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Source semantic fixtures”: “Program count and supported feature coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C008-T02 · Measurement method:** Choose how to observe each “Source semantic fixtures” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Source semantic fixtures”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Source semantic fixtures” cases for “Program count and supported feature coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Source semantic fixtures” limit; preserve “Source correctness is assessed against defined observable behavior”.
- [ ] **UC-M04.04-C008-T06 · Normal measurement:** Run or review the normal “Source semantic fixtures” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C008-T07 · At-limit measurement:** Exercise the “Source semantic fixtures” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C008-T08 · Over-limit measurement:** Exercise the “Source semantic fixtures” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C008-T09 · Uncovered-scope report:** List the “Source semantic fixtures” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C008-T10 · Limit evidence:** Publish the selected “Source semantic fixtures” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C009 · Diagnostics / review

**Original checklist item:** Report source semantic fixtures results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C009-T01 · Result inventory:** Enumerate the required “Source semantic fixtures” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Source semantic fixtures”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Source semantic fixtures” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C009-T04 · Observation capture:** Capture bounded raw “Source semantic fixtures” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C009-T05 · Aggregation rules:** Implement the “Source semantic fixtures” count/reduction rule so failures and missing measurements cannot disappear; preserve “Source correctness is assessed against defined observable behavior”.
- [ ] **UC-M04.04-C009-T06 · Failure visibility:** Feed a failing “Source semantic fixtures” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C009-T07 · Missing-result visibility:** Withhold a required “Source semantic fixtures” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C009-T08 · Bounds and redaction:** Check “Source semantic fixtures” report size and retention against “Program count and supported feature coverage”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C009-T09 · Report reconciliation:** Reconcile the “Source semantic fixtures” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C009-T10 · Qualification handoff:** Publish the “Source semantic fixtures” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for source semantic fixtures; label unexecuted checks as untested.

- [ ] **UC-M04.04-C010-T01 · Evidence inventory:** List the “Source semantic fixtures” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C010-T02 · Artifact references:** Record the exact “Source semantic fixtures” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C010-T03 · Fixture references:** Attach the “Source semantic fixtures” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only trivial programs are used to approve a dialect” as a distinct evidence case.
- [ ] **UC-M04.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Source semantic fixtures”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C010-T05 · Environment record:** Record the actual “Source semantic fixtures” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C010-T06 · Expected versus observed:** Pair every “Source semantic fixtures” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C010-T07 · Failure and limit records:** Attach “Source semantic fixtures” change/failure and bounds evidence where required; include uncovered “Program count and supported feature coverage” and unresolved violations of “Source correctness is assessed against defined observable behavior”.
- [ ] **UC-M04.04-C010-T08 · Evidence hygiene:** Check the “Source semantic fixtures” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C010-T09 · Reproduction review:** Have the “Source semantic fixtures” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C010-T10 · Acceptance linkage:** Link the “Source semantic fixtures” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Intermediate representation contract

**Source delivery:** Define typed lowering outputs with explicit arithmetic and control-flow semantics.

**Source invariant:** Lowering preserves the source's declared semantics.

**Source negative case:** A branch condition changes meaning in the intermediate form.

**Source bounded quantities:** IR node count and nesting depth.

### UC-M04.04-C011 · Contract

**Original checklist item:** Define the qualification objective for intermediate representation contract, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C011-T01 · Scope statement:** Write the qualification question for “Intermediate representation contract”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Intermediate representation contract”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C011-T03 · Output inventory:** List the outputs of “Intermediate representation contract” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Intermediate representation contract”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C011-T05 · Prerequisite contract:** Map “Intermediate representation contract” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Intermediate representation contract”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C011-T07 · Invariant clause:** Add a normative clause for “Intermediate representation contract” that preserves “Lowering preserves the source's declared semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Intermediate representation contract”; include the source counterexample “A branch condition changes meaning in the intermediate form” and the intended safe disposition.
- [ ] **UC-M04.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “IR node count and nesting depth” in the “Intermediate representation contract” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C011-T10 · Contract review:** Review the “Intermediate representation contract” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C012 · Delivery

**Original checklist item:** Define typed lowering outputs with explicit arithmetic and control-flow semantics.

- [ ] **UC-M04.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Intermediate representation contract”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C012-T02 · Change plan:** Break the source delivery for “Intermediate representation contract” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C012-T03 · Core artifact:** Create the “Intermediate representation contract” model, schema or inventory that realizes this source instruction: Define typed lowering outputs with explicit arithmetic and control-flow semantics.
- [ ] **UC-M04.04-C012-T04 · Concrete realization:** Populate “Intermediate representation contract” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Intermediate representation contract” needed to preserve “Lowering preserves the source's declared semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C012-T06 · Dependency connection:** Connect the “Intermediate representation contract” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C012-T07 · Resource behavior:** Account for “IR node count and nesting depth” in “Intermediate representation contract”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Intermediate representation contract”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C012-T09 · Patch review:** Review the “Intermediate representation contract” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C012-T10 · Delivery handoff:** Publish the “Intermediate representation contract” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Lowering preserves the source's declared semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Intermediate representation contract”; copy its required invariant exactly: “Lowering preserves the source's declared semantics”.
- [ ] **UC-M04.04-C013-T02 · Observable terms:** Define each term in the “Intermediate representation contract” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C013-T03 · Precondition set:** List the preconditions under which “Lowering preserves the source's declared semantics” must hold for “Intermediate representation contract”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C013-T04 · Transition coverage:** Map the “Intermediate representation contract” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Intermediate representation contract”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C013-T06 · Satisfying fixture:** Create a concrete “Intermediate representation contract” case that satisfies “Lowering preserves the source's declared semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C013-T07 · Violating fixture:** Create the source counterexample “A branch condition changes meaning in the intermediate form” for “Intermediate representation contract”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C013-T08 · Enforcement evidence:** Exercise the “Intermediate representation contract” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C013-T09 · Regression linkage:** Link the “Intermediate representation contract” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Intermediate representation contract” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C014 · Integration

**Original checklist item:** Integrate intermediate representation contract with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Intermediate representation contract” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C014-T02 · Field mapping:** Map every “Intermediate representation contract” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Intermediate representation contract” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C014-T04 · Ownership agreement:** Specify who owns “Intermediate representation contract” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C014-T05 · Handoff implementation:** Connect “Intermediate representation contract” through the mapped seam using the real adapter or explicit specification reference; preserve “Lowering preserves the source's declared semantics” across the handoff.
- [ ] **UC-M04.04-C014-T06 · Absent-input case:** Omit one required “Intermediate representation contract” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C014-T07 · Stale-input case:** Supply an outdated “Intermediate representation contract” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Intermediate representation contract” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C014-T09 · Valid integration trace:** Run a valid “Intermediate representation contract” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C014-T10 · Seam review:** Reconcile the “Intermediate representation contract” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for intermediate representation contract; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Intermediate representation contract”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C015-T02 · Expected-result oracle:** Specify the “Intermediate representation contract” expected result independently of the implementation output; include the property “Lowering preserves the source's declared semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C015-T03 · Fixture material:** Create the concrete “Intermediate representation contract” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C015-T04 · Target preparation:** Prepare the “Intermediate representation contract” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C015-T05 · Initial-state record:** Record the initial “Intermediate representation contract” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C015-T06 · Valid-path execution:** Run the “Intermediate representation contract” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C015-T07 · Outcome comparison:** Compare every declared “Intermediate representation contract” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C015-T08 · State and bounds check:** Inspect the “Intermediate representation contract” ownership/state effects and actual use of “IR node count and nesting depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C015-T09 · Repeatability check:** Repeat the same “Intermediate representation contract” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C015-T10 · Positive evidence:** Attach the “Intermediate representation contract” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C016 · Negative test

**Original checklist item:** Negative case: A branch condition changes meaning in the intermediate form. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Intermediate representation contract” source counterexample: “A branch condition changes meaning in the intermediate form”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Intermediate representation contract”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C016-T03 · Valid control:** Construct a valid “Intermediate representation contract” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C016-T04 · Minimal adverse input:** Derive the “Intermediate representation contract” adverse fixture from the control with the smallest documented change needed to reproduce “A branch condition changes meaning in the intermediate form”; retain that change as reproducible data.
- [ ] **UC-M04.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Intermediate representation contract”; require “Lowering preserves the source's declared semantics” and forbid a false-success verdict.
- [ ] **UC-M04.04-C016-T06 · Adverse execution:** Exercise the “Intermediate representation contract” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C016-T07 · Effect inspection:** Inspect “Intermediate representation contract” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C016-T08 · Refusal versus failure:** Confirm the “Intermediate representation contract” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C016-T09 · Reset and retention:** Restore only the disposable “Intermediate representation contract” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C016-T10 · Negative regression:** Register the “Intermediate representation contract” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C017 · Change / failure test

**Original checklist item:** Exercise intermediate representation contract when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C017-T01 · Scenario record:** Write the “Intermediate representation contract” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Lowering preserves the source's declared semantics”.
- [ ] **UC-M04.04-C017-T02 · Baseline capture:** Create a known-valid “Intermediate representation contract” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C017-T03 · Injection map:** Locate the “Intermediate representation contract” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Intermediate representation contract” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C017-T05 · Controlled trigger:** Introduce the controlled “Intermediate representation contract” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C017-T06 · Intermediate inspection:** Inspect the “Intermediate representation contract” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Intermediate representation contract”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Intermediate representation contract” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C017-T09 · Repeat and compare:** Repeat the selected “Intermediate representation contract” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C017-T10 · Failure evidence:** Publish the “Intermediate representation contract” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for IR node count and nesting depth; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Intermediate representation contract”: “IR node count and nesting depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C018-T02 · Measurement method:** Choose how to observe each “Intermediate representation contract” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Intermediate representation contract”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Intermediate representation contract” cases for “IR node count and nesting depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Intermediate representation contract” limit; preserve “Lowering preserves the source's declared semantics”.
- [ ] **UC-M04.04-C018-T06 · Normal measurement:** Run or review the normal “Intermediate representation contract” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C018-T07 · At-limit measurement:** Exercise the “Intermediate representation contract” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C018-T08 · Over-limit measurement:** Exercise the “Intermediate representation contract” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C018-T09 · Uncovered-scope report:** List the “Intermediate representation contract” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C018-T10 · Limit evidence:** Publish the selected “Intermediate representation contract” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C019 · Diagnostics / review

**Original checklist item:** Report intermediate representation contract results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C019-T01 · Result inventory:** Enumerate the required “Intermediate representation contract” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Intermediate representation contract”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Intermediate representation contract” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C019-T04 · Observation capture:** Capture bounded raw “Intermediate representation contract” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C019-T05 · Aggregation rules:** Implement the “Intermediate representation contract” count/reduction rule so failures and missing measurements cannot disappear; preserve “Lowering preserves the source's declared semantics”.
- [ ] **UC-M04.04-C019-T06 · Failure visibility:** Feed a failing “Intermediate representation contract” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C019-T07 · Missing-result visibility:** Withhold a required “Intermediate representation contract” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C019-T08 · Bounds and redaction:** Check “Intermediate representation contract” report size and retention against “IR node count and nesting depth”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C019-T09 · Report reconciliation:** Reconcile the “Intermediate representation contract” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C019-T10 · Qualification handoff:** Publish the “Intermediate representation contract” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for intermediate representation contract; label unexecuted checks as untested.

- [ ] **UC-M04.04-C020-T01 · Evidence inventory:** List the “Intermediate representation contract” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C020-T02 · Artifact references:** Record the exact “Intermediate representation contract” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C020-T03 · Fixture references:** Attach the “Intermediate representation contract” fixture IDs, input identities and oracle definition; preserve the source counterexample “A branch condition changes meaning in the intermediate form” as a distinct evidence case.
- [ ] **UC-M04.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Intermediate representation contract”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C020-T05 · Environment record:** Record the actual “Intermediate representation contract” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C020-T06 · Expected versus observed:** Pair every “Intermediate representation contract” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C020-T07 · Failure and limit records:** Attach “Intermediate representation contract” change/failure and bounds evidence where required; include uncovered “IR node count and nesting depth” and unresolved violations of “Lowering preserves the source's declared semantics”.
- [ ] **UC-M04.04-C020-T08 · Evidence hygiene:** Check the “Intermediate representation contract” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C020-T09 · Reproduction review:** Have the “Intermediate representation contract” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C020-T10 · Acceptance linkage:** Link the “Intermediate representation contract” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Native result comparison

**Source delivery:** Compare native execution output with the independent source oracle.

**Source invariant:** A matching metadata witness does not replace native output comparison.

**Source negative case:** Native output is wrong while the witness remains unchanged.

**Source bounded quantities:** Output bytes and execution time.

### UC-M04.04-C021 · Contract

**Original checklist item:** Define the qualification objective for native result comparison, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C021-T01 · Scope statement:** Write the qualification question for “Native result comparison”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native result comparison”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C021-T03 · Output inventory:** List the outputs of “Native result comparison” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Native result comparison”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C021-T05 · Prerequisite contract:** Map “Native result comparison” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Native result comparison”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C021-T07 · Invariant clause:** Add a normative clause for “Native result comparison” that preserves “A matching metadata witness does not replace native output comparison”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native result comparison”; include the source counterexample “Native output is wrong while the witness remains unchanged” and the intended safe disposition.
- [ ] **UC-M04.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Output bytes and execution time” in the “Native result comparison” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C021-T10 · Contract review:** Review the “Native result comparison” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C022 · Delivery

**Original checklist item:** Compare native execution output with the independent source oracle.

- [ ] **UC-M04.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native result comparison”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C022-T02 · Change plan:** Break the source delivery for “Native result comparison” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C022-T03 · Core artifact:** Create the “Native result comparison” fixture or harness for this source instruction: Compare native execution output with the independent source oracle.
- [ ] **UC-M04.04-C022-T04 · Concrete realization:** Connect the “Native result comparison” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native result comparison” needed to preserve “A matching metadata witness does not replace native output comparison”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C022-T06 · Dependency connection:** Connect the “Native result comparison” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C022-T07 · Resource behavior:** Account for “Output bytes and execution time” in “Native result comparison”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native result comparison”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C022-T09 · Patch review:** Review the “Native result comparison” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C022-T10 · Delivery handoff:** Publish the “Native result comparison” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A matching metadata witness does not replace native output comparison. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Native result comparison”; copy its required invariant exactly: “A matching metadata witness does not replace native output comparison”.
- [ ] **UC-M04.04-C023-T02 · Observable terms:** Define each term in the “Native result comparison” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C023-T03 · Precondition set:** List the preconditions under which “A matching metadata witness does not replace native output comparison” must hold for “Native result comparison”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C023-T04 · Transition coverage:** Map the “Native result comparison” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native result comparison”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C023-T06 · Satisfying fixture:** Create a concrete “Native result comparison” case that satisfies “A matching metadata witness does not replace native output comparison”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C023-T07 · Violating fixture:** Create the source counterexample “Native output is wrong while the witness remains unchanged” for “Native result comparison”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C023-T08 · Enforcement evidence:** Exercise the “Native result comparison” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C023-T09 · Regression linkage:** Link the “Native result comparison” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Native result comparison” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C024 · Integration

**Original checklist item:** Integrate native result comparison with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native result comparison” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C024-T02 · Field mapping:** Map every “Native result comparison” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Native result comparison” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C024-T04 · Ownership agreement:** Specify who owns “Native result comparison” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C024-T05 · Handoff implementation:** Connect “Native result comparison” through the mapped seam using the real adapter or explicit specification reference; preserve “A matching metadata witness does not replace native output comparison” across the handoff.
- [ ] **UC-M04.04-C024-T06 · Absent-input case:** Omit one required “Native result comparison” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C024-T07 · Stale-input case:** Supply an outdated “Native result comparison” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Native result comparison” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C024-T09 · Valid integration trace:** Run a valid “Native result comparison” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C024-T10 · Seam review:** Reconcile the “Native result comparison” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for native result comparison; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Native result comparison”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C025-T02 · Expected-result oracle:** Specify the “Native result comparison” expected result independently of the implementation output; include the property “A matching metadata witness does not replace native output comparison” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C025-T03 · Fixture material:** Create the concrete “Native result comparison” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C025-T04 · Target preparation:** Prepare the “Native result comparison” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C025-T05 · Initial-state record:** Record the initial “Native result comparison” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C025-T06 · Valid-path execution:** Run the “Native result comparison” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C025-T07 · Outcome comparison:** Compare every declared “Native result comparison” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C025-T08 · State and bounds check:** Inspect the “Native result comparison” ownership/state effects and actual use of “Output bytes and execution time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C025-T09 · Repeatability check:** Repeat the same “Native result comparison” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C025-T10 · Positive evidence:** Attach the “Native result comparison” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C026 · Negative test

**Original checklist item:** Negative case: Native output is wrong while the witness remains unchanged. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Native result comparison” source counterexample: “Native output is wrong while the witness remains unchanged”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Native result comparison”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C026-T03 · Valid control:** Construct a valid “Native result comparison” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C026-T04 · Minimal adverse input:** Derive the “Native result comparison” adverse fixture from the control with the smallest documented change needed to reproduce “Native output is wrong while the witness remains unchanged”; retain that change as reproducible data.
- [ ] **UC-M04.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native result comparison”; require “A matching metadata witness does not replace native output comparison” and forbid a false-success verdict.
- [ ] **UC-M04.04-C026-T06 · Adverse execution:** Exercise the “Native result comparison” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C026-T07 · Effect inspection:** Inspect “Native result comparison” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C026-T08 · Refusal versus failure:** Confirm the “Native result comparison” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C026-T09 · Reset and retention:** Restore only the disposable “Native result comparison” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C026-T10 · Negative regression:** Register the “Native result comparison” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C027 · Change / failure test

**Original checklist item:** Exercise native result comparison when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C027-T01 · Scenario record:** Write the “Native result comparison” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “A matching metadata witness does not replace native output comparison”.
- [ ] **UC-M04.04-C027-T02 · Baseline capture:** Create a known-valid “Native result comparison” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C027-T03 · Injection map:** Locate the “Native result comparison” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Native result comparison” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C027-T05 · Controlled trigger:** Introduce the controlled “Native result comparison” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C027-T06 · Intermediate inspection:** Inspect the “Native result comparison” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native result comparison”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Native result comparison” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C027-T09 · Repeat and compare:** Repeat the selected “Native result comparison” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C027-T10 · Failure evidence:** Publish the “Native result comparison” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for output bytes and execution time; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Native result comparison”: “Output bytes and execution time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C028-T02 · Measurement method:** Choose how to observe each “Native result comparison” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native result comparison”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native result comparison” cases for “Output bytes and execution time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native result comparison” limit; preserve “A matching metadata witness does not replace native output comparison”.
- [ ] **UC-M04.04-C028-T06 · Normal measurement:** Run or review the normal “Native result comparison” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C028-T07 · At-limit measurement:** Exercise the “Native result comparison” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C028-T08 · Over-limit measurement:** Exercise the “Native result comparison” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C028-T09 · Uncovered-scope report:** List the “Native result comparison” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C028-T10 · Limit evidence:** Publish the selected “Native result comparison” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C029 · Diagnostics / review

**Original checklist item:** Report native result comparison results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C029-T01 · Result inventory:** Enumerate the required “Native result comparison” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native result comparison”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native result comparison” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C029-T04 · Observation capture:** Capture bounded raw “Native result comparison” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C029-T05 · Aggregation rules:** Implement the “Native result comparison” count/reduction rule so failures and missing measurements cannot disappear; preserve “A matching metadata witness does not replace native output comparison”.
- [ ] **UC-M04.04-C029-T06 · Failure visibility:** Feed a failing “Native result comparison” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C029-T07 · Missing-result visibility:** Withhold a required “Native result comparison” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C029-T08 · Bounds and redaction:** Check “Native result comparison” report size and retention against “Output bytes and execution time”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C029-T09 · Report reconciliation:** Reconcile the “Native result comparison” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C029-T10 · Qualification handoff:** Publish the “Native result comparison” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native result comparison; label unexecuted checks as untested.

- [ ] **UC-M04.04-C030-T01 · Evidence inventory:** List the “Native result comparison” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C030-T02 · Artifact references:** Record the exact “Native result comparison” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C030-T03 · Fixture references:** Attach the “Native result comparison” fixture IDs, input identities and oracle definition; preserve the source counterexample “Native output is wrong while the witness remains unchanged” as a distinct evidence case.
- [ ] **UC-M04.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native result comparison”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C030-T05 · Environment record:** Record the actual “Native result comparison” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C030-T06 · Expected versus observed:** Pair every “Native result comparison” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C030-T07 · Failure and limit records:** Attach “Native result comparison” change/failure and bounds evidence where required; include uncovered “Output bytes and execution time” and unresolved violations of “A matching metadata witness does not replace native output comparison”.
- [ ] **UC-M04.04-C030-T08 · Evidence hygiene:** Check the “Native result comparison” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C030-T09 · Reproduction review:** Have the “Native result comparison” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C030-T10 · Acceptance linkage:** Link the “Native result comparison” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Arithmetic boundary suite

**Source delivery:** Test signedness, overflow and supported numeric conversions at boundaries.

**Source invariant:** Arithmetic behavior is consistent across supported representations.

**Source negative case:** A maximum-width integer wraps differently after lowering.

**Source bounded quantities:** Numeric ranges and generated cases.

### UC-M04.04-C031 · Contract

**Original checklist item:** Define the qualification objective for arithmetic boundary suite, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C031-T01 · Scope statement:** Write the qualification question for “Arithmetic boundary suite”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Arithmetic boundary suite”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C031-T03 · Output inventory:** List the outputs of “Arithmetic boundary suite” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Arithmetic boundary suite”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C031-T05 · Prerequisite contract:** Map “Arithmetic boundary suite” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Arithmetic boundary suite”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C031-T07 · Invariant clause:** Add a normative clause for “Arithmetic boundary suite” that preserves “Arithmetic behavior is consistent across supported representations”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Arithmetic boundary suite”; include the source counterexample “A maximum-width integer wraps differently after lowering” and the intended safe disposition.
- [ ] **UC-M04.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Numeric ranges and generated cases” in the “Arithmetic boundary suite” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C031-T10 · Contract review:** Review the “Arithmetic boundary suite” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C032 · Delivery

**Original checklist item:** Test signedness, overflow and supported numeric conversions at boundaries.

- [ ] **UC-M04.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Arithmetic boundary suite”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C032-T02 · Change plan:** Break the source delivery for “Arithmetic boundary suite” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C032-T03 · Core artifact:** Create the “Arithmetic boundary suite” fixture or harness for this source instruction: Test signedness, overflow and supported numeric conversions at boundaries.
- [ ] **UC-M04.04-C032-T04 · Concrete realization:** Connect the “Arithmetic boundary suite” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Arithmetic boundary suite” needed to preserve “Arithmetic behavior is consistent across supported representations”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C032-T06 · Dependency connection:** Connect the “Arithmetic boundary suite” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C032-T07 · Resource behavior:** Account for “Numeric ranges and generated cases” in “Arithmetic boundary suite”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Arithmetic boundary suite”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C032-T09 · Patch review:** Review the “Arithmetic boundary suite” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C032-T10 · Delivery handoff:** Publish the “Arithmetic boundary suite” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Arithmetic behavior is consistent across supported representations. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Arithmetic boundary suite”; copy its required invariant exactly: “Arithmetic behavior is consistent across supported representations”.
- [ ] **UC-M04.04-C033-T02 · Observable terms:** Define each term in the “Arithmetic boundary suite” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C033-T03 · Precondition set:** List the preconditions under which “Arithmetic behavior is consistent across supported representations” must hold for “Arithmetic boundary suite”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C033-T04 · Transition coverage:** Map the “Arithmetic boundary suite” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Arithmetic boundary suite”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C033-T06 · Satisfying fixture:** Create a concrete “Arithmetic boundary suite” case that satisfies “Arithmetic behavior is consistent across supported representations”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C033-T07 · Violating fixture:** Create the source counterexample “A maximum-width integer wraps differently after lowering” for “Arithmetic boundary suite”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C033-T08 · Enforcement evidence:** Exercise the “Arithmetic boundary suite” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C033-T09 · Regression linkage:** Link the “Arithmetic boundary suite” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Arithmetic boundary suite” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C034 · Integration

**Original checklist item:** Integrate arithmetic boundary suite with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Arithmetic boundary suite” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C034-T02 · Field mapping:** Map every “Arithmetic boundary suite” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Arithmetic boundary suite” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C034-T04 · Ownership agreement:** Specify who owns “Arithmetic boundary suite” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C034-T05 · Handoff implementation:** Connect “Arithmetic boundary suite” through the mapped seam using the real adapter or explicit specification reference; preserve “Arithmetic behavior is consistent across supported representations” across the handoff.
- [ ] **UC-M04.04-C034-T06 · Absent-input case:** Omit one required “Arithmetic boundary suite” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C034-T07 · Stale-input case:** Supply an outdated “Arithmetic boundary suite” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Arithmetic boundary suite” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C034-T09 · Valid integration trace:** Run a valid “Arithmetic boundary suite” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C034-T10 · Seam review:** Reconcile the “Arithmetic boundary suite” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for arithmetic boundary suite; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Arithmetic boundary suite”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C035-T02 · Expected-result oracle:** Specify the “Arithmetic boundary suite” expected result independently of the implementation output; include the property “Arithmetic behavior is consistent across supported representations” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C035-T03 · Fixture material:** Create the concrete “Arithmetic boundary suite” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C035-T04 · Target preparation:** Prepare the “Arithmetic boundary suite” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C035-T05 · Initial-state record:** Record the initial “Arithmetic boundary suite” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C035-T06 · Valid-path execution:** Run the “Arithmetic boundary suite” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C035-T07 · Outcome comparison:** Compare every declared “Arithmetic boundary suite” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C035-T08 · State and bounds check:** Inspect the “Arithmetic boundary suite” ownership/state effects and actual use of “Numeric ranges and generated cases”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C035-T09 · Repeatability check:** Repeat the same “Arithmetic boundary suite” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C035-T10 · Positive evidence:** Attach the “Arithmetic boundary suite” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C036 · Negative test

**Original checklist item:** Negative case: A maximum-width integer wraps differently after lowering. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Arithmetic boundary suite” source counterexample: “A maximum-width integer wraps differently after lowering”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Arithmetic boundary suite”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C036-T03 · Valid control:** Construct a valid “Arithmetic boundary suite” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C036-T04 · Minimal adverse input:** Derive the “Arithmetic boundary suite” adverse fixture from the control with the smallest documented change needed to reproduce “A maximum-width integer wraps differently after lowering”; retain that change as reproducible data.
- [ ] **UC-M04.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Arithmetic boundary suite”; require “Arithmetic behavior is consistent across supported representations” and forbid a false-success verdict.
- [ ] **UC-M04.04-C036-T06 · Adverse execution:** Exercise the “Arithmetic boundary suite” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C036-T07 · Effect inspection:** Inspect “Arithmetic boundary suite” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C036-T08 · Refusal versus failure:** Confirm the “Arithmetic boundary suite” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C036-T09 · Reset and retention:** Restore only the disposable “Arithmetic boundary suite” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C036-T10 · Negative regression:** Register the “Arithmetic boundary suite” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C037 · Change / failure test

**Original checklist item:** Exercise arithmetic boundary suite when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C037-T01 · Scenario record:** Write the “Arithmetic boundary suite” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Arithmetic behavior is consistent across supported representations”.
- [ ] **UC-M04.04-C037-T02 · Baseline capture:** Create a known-valid “Arithmetic boundary suite” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C037-T03 · Injection map:** Locate the “Arithmetic boundary suite” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Arithmetic boundary suite” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C037-T05 · Controlled trigger:** Introduce the controlled “Arithmetic boundary suite” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C037-T06 · Intermediate inspection:** Inspect the “Arithmetic boundary suite” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Arithmetic boundary suite”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Arithmetic boundary suite” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C037-T09 · Repeat and compare:** Repeat the selected “Arithmetic boundary suite” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C037-T10 · Failure evidence:** Publish the “Arithmetic boundary suite” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for numeric ranges and generated cases; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Arithmetic boundary suite”: “Numeric ranges and generated cases”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C038-T02 · Measurement method:** Choose how to observe each “Arithmetic boundary suite” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Arithmetic boundary suite”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Arithmetic boundary suite” cases for “Numeric ranges and generated cases”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Arithmetic boundary suite” limit; preserve “Arithmetic behavior is consistent across supported representations”.
- [ ] **UC-M04.04-C038-T06 · Normal measurement:** Run or review the normal “Arithmetic boundary suite” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C038-T07 · At-limit measurement:** Exercise the “Arithmetic boundary suite” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C038-T08 · Over-limit measurement:** Exercise the “Arithmetic boundary suite” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C038-T09 · Uncovered-scope report:** List the “Arithmetic boundary suite” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C038-T10 · Limit evidence:** Publish the selected “Arithmetic boundary suite” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C039 · Diagnostics / review

**Original checklist item:** Report arithmetic boundary suite results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C039-T01 · Result inventory:** Enumerate the required “Arithmetic boundary suite” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Arithmetic boundary suite”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Arithmetic boundary suite” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C039-T04 · Observation capture:** Capture bounded raw “Arithmetic boundary suite” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C039-T05 · Aggregation rules:** Implement the “Arithmetic boundary suite” count/reduction rule so failures and missing measurements cannot disappear; preserve “Arithmetic behavior is consistent across supported representations”.
- [ ] **UC-M04.04-C039-T06 · Failure visibility:** Feed a failing “Arithmetic boundary suite” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C039-T07 · Missing-result visibility:** Withhold a required “Arithmetic boundary suite” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C039-T08 · Bounds and redaction:** Check “Arithmetic boundary suite” report size and retention against “Numeric ranges and generated cases”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C039-T09 · Report reconciliation:** Reconcile the “Arithmetic boundary suite” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C039-T10 · Qualification handoff:** Publish the “Arithmetic boundary suite” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for arithmetic boundary suite; label unexecuted checks as untested.

- [ ] **UC-M04.04-C040-T01 · Evidence inventory:** List the “Arithmetic boundary suite” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C040-T02 · Artifact references:** Record the exact “Arithmetic boundary suite” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C040-T03 · Fixture references:** Attach the “Arithmetic boundary suite” fixture IDs, input identities and oracle definition; preserve the source counterexample “A maximum-width integer wraps differently after lowering” as a distinct evidence case.
- [ ] **UC-M04.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Arithmetic boundary suite”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C040-T05 · Environment record:** Record the actual “Arithmetic boundary suite” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C040-T06 · Expected versus observed:** Pair every “Arithmetic boundary suite” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C040-T07 · Failure and limit records:** Attach “Arithmetic boundary suite” change/failure and bounds evidence where required; include uncovered “Numeric ranges and generated cases” and unresolved violations of “Arithmetic behavior is consistent across supported representations”.
- [ ] **UC-M04.04-C040-T08 · Evidence hygiene:** Check the “Arithmetic boundary suite” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C040-T09 · Reproduction review:** Have the “Arithmetic boundary suite” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C040-T10 · Acceptance linkage:** Link the “Arithmetic boundary suite” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Control-flow validation

**Source delivery:** Check branches, loops and termination behavior through translation.

**Source invariant:** Unsupported control flow is refused rather than approximated silently.

**Source negative case:** A loop is dropped by a simplified lowering path.

**Source bounded quantities:** Control-flow graph size and execution steps.

### UC-M04.04-C041 · Contract

**Original checklist item:** Define the qualification objective for control-flow validation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C041-T01 · Scope statement:** Write the qualification question for “Control-flow validation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Control-flow validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C041-T03 · Output inventory:** List the outputs of “Control-flow validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Control-flow validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C041-T05 · Prerequisite contract:** Map “Control-flow validation” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Control-flow validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C041-T07 · Invariant clause:** Add a normative clause for “Control-flow validation” that preserves “Unsupported control flow is refused rather than approximated silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Control-flow validation”; include the source counterexample “A loop is dropped by a simplified lowering path” and the intended safe disposition.
- [ ] **UC-M04.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Control-flow graph size and execution steps” in the “Control-flow validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C041-T10 · Contract review:** Review the “Control-flow validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C042 · Delivery

**Original checklist item:** Check branches, loops and termination behavior through translation.

- [ ] **UC-M04.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Control-flow validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C042-T02 · Change plan:** Break the source delivery for “Control-flow validation” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C042-T03 · Core artifact:** Create the “Control-flow validation” fixture or harness for this source instruction: Check branches, loops and termination behavior through translation.
- [ ] **UC-M04.04-C042-T04 · Concrete realization:** Connect the “Control-flow validation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Control-flow validation” needed to preserve “Unsupported control flow is refused rather than approximated silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C042-T06 · Dependency connection:** Connect the “Control-flow validation” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C042-T07 · Resource behavior:** Account for “Control-flow graph size and execution steps” in “Control-flow validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Control-flow validation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C042-T09 · Patch review:** Review the “Control-flow validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C042-T10 · Delivery handoff:** Publish the “Control-flow validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported control flow is refused rather than approximated silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Control-flow validation”; copy its required invariant exactly: “Unsupported control flow is refused rather than approximated silently”.
- [ ] **UC-M04.04-C043-T02 · Observable terms:** Define each term in the “Control-flow validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C043-T03 · Precondition set:** List the preconditions under which “Unsupported control flow is refused rather than approximated silently” must hold for “Control-flow validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C043-T04 · Transition coverage:** Map the “Control-flow validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Control-flow validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C043-T06 · Satisfying fixture:** Create a concrete “Control-flow validation” case that satisfies “Unsupported control flow is refused rather than approximated silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C043-T07 · Violating fixture:** Create the source counterexample “A loop is dropped by a simplified lowering path” for “Control-flow validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C043-T08 · Enforcement evidence:** Exercise the “Control-flow validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C043-T09 · Regression linkage:** Link the “Control-flow validation” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Control-flow validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C044 · Integration

**Original checklist item:** Integrate control-flow validation with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Control-flow validation” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C044-T02 · Field mapping:** Map every “Control-flow validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Control-flow validation” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C044-T04 · Ownership agreement:** Specify who owns “Control-flow validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C044-T05 · Handoff implementation:** Connect “Control-flow validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported control flow is refused rather than approximated silently” across the handoff.
- [ ] **UC-M04.04-C044-T06 · Absent-input case:** Omit one required “Control-flow validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C044-T07 · Stale-input case:** Supply an outdated “Control-flow validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Control-flow validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C044-T09 · Valid integration trace:** Run a valid “Control-flow validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C044-T10 · Seam review:** Reconcile the “Control-flow validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for control-flow validation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Control-flow validation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C045-T02 · Expected-result oracle:** Specify the “Control-flow validation” expected result independently of the implementation output; include the property “Unsupported control flow is refused rather than approximated silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C045-T03 · Fixture material:** Create the concrete “Control-flow validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C045-T04 · Target preparation:** Prepare the “Control-flow validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C045-T05 · Initial-state record:** Record the initial “Control-flow validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C045-T06 · Valid-path execution:** Run the “Control-flow validation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C045-T07 · Outcome comparison:** Compare every declared “Control-flow validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C045-T08 · State and bounds check:** Inspect the “Control-flow validation” ownership/state effects and actual use of “Control-flow graph size and execution steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C045-T09 · Repeatability check:** Repeat the same “Control-flow validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C045-T10 · Positive evidence:** Attach the “Control-flow validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C046 · Negative test

**Original checklist item:** Negative case: A loop is dropped by a simplified lowering path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Control-flow validation” source counterexample: “A loop is dropped by a simplified lowering path”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Control-flow validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C046-T03 · Valid control:** Construct a valid “Control-flow validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C046-T04 · Minimal adverse input:** Derive the “Control-flow validation” adverse fixture from the control with the smallest documented change needed to reproduce “A loop is dropped by a simplified lowering path”; retain that change as reproducible data.
- [ ] **UC-M04.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Control-flow validation”; require “Unsupported control flow is refused rather than approximated silently” and forbid a false-success verdict.
- [ ] **UC-M04.04-C046-T06 · Adverse execution:** Exercise the “Control-flow validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C046-T07 · Effect inspection:** Inspect “Control-flow validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C046-T08 · Refusal versus failure:** Confirm the “Control-flow validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C046-T09 · Reset and retention:** Restore only the disposable “Control-flow validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C046-T10 · Negative regression:** Register the “Control-flow validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C047 · Change / failure test

**Original checklist item:** Exercise control-flow validation when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C047-T01 · Scenario record:** Write the “Control-flow validation” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Unsupported control flow is refused rather than approximated silently”.
- [ ] **UC-M04.04-C047-T02 · Baseline capture:** Create a known-valid “Control-flow validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C047-T03 · Injection map:** Locate the “Control-flow validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Control-flow validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C047-T05 · Controlled trigger:** Introduce the controlled “Control-flow validation” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C047-T06 · Intermediate inspection:** Inspect the “Control-flow validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Control-flow validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Control-flow validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C047-T09 · Repeat and compare:** Repeat the selected “Control-flow validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C047-T10 · Failure evidence:** Publish the “Control-flow validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for control-flow graph size and execution steps; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Control-flow validation”: “Control-flow graph size and execution steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C048-T02 · Measurement method:** Choose how to observe each “Control-flow validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Control-flow validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Control-flow validation” cases for “Control-flow graph size and execution steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Control-flow validation” limit; preserve “Unsupported control flow is refused rather than approximated silently”.
- [ ] **UC-M04.04-C048-T06 · Normal measurement:** Run or review the normal “Control-flow validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C048-T07 · At-limit measurement:** Exercise the “Control-flow validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C048-T08 · Over-limit measurement:** Exercise the “Control-flow validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C048-T09 · Uncovered-scope report:** List the “Control-flow validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C048-T10 · Limit evidence:** Publish the selected “Control-flow validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C049 · Diagnostics / review

**Original checklist item:** Report control-flow validation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C049-T01 · Result inventory:** Enumerate the required “Control-flow validation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Control-flow validation”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Control-flow validation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C049-T04 · Observation capture:** Capture bounded raw “Control-flow validation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C049-T05 · Aggregation rules:** Implement the “Control-flow validation” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unsupported control flow is refused rather than approximated silently”.
- [ ] **UC-M04.04-C049-T06 · Failure visibility:** Feed a failing “Control-flow validation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C049-T07 · Missing-result visibility:** Withhold a required “Control-flow validation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C049-T08 · Bounds and redaction:** Check “Control-flow validation” report size and retention against “Control-flow graph size and execution steps”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C049-T09 · Report reconciliation:** Reconcile the “Control-flow validation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C049-T10 · Qualification handoff:** Publish the “Control-flow validation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for control-flow validation; label unexecuted checks as untested.

- [ ] **UC-M04.04-C050-T01 · Evidence inventory:** List the “Control-flow validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C050-T02 · Artifact references:** Record the exact “Control-flow validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C050-T03 · Fixture references:** Attach the “Control-flow validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A loop is dropped by a simplified lowering path” as a distinct evidence case.
- [ ] **UC-M04.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Control-flow validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C050-T05 · Environment record:** Record the actual “Control-flow validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C050-T06 · Expected versus observed:** Pair every “Control-flow validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C050-T07 · Failure and limit records:** Attach “Control-flow validation” change/failure and bounds evidence where required; include uncovered “Control-flow graph size and execution steps” and unresolved violations of “Unsupported control flow is refused rather than approximated silently”.
- [ ] **UC-M04.04-C050-T08 · Evidence hygiene:** Check the “Control-flow validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C050-T09 · Reproduction review:** Have the “Control-flow validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C050-T10 · Acceptance linkage:** Link the “Control-flow validation” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Unsupported-feature refusal

**Source delivery:** Identify and reject source features outside the supported translation profile.

**Source invariant:** Unsupported input cannot produce a misleading successful translation.

**Source negative case:** A parser ignores an unfamiliar language construct.

**Source bounded quantities:** Feature diagnostics and input bytes.

### UC-M04.04-C051 · Contract

**Original checklist item:** Define the qualification objective for unsupported-feature refusal, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C051-T01 · Scope statement:** Write the qualification question for “Unsupported-feature refusal”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Unsupported-feature refusal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C051-T03 · Output inventory:** List the outputs of “Unsupported-feature refusal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Unsupported-feature refusal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C051-T05 · Prerequisite contract:** Map “Unsupported-feature refusal” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Unsupported-feature refusal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C051-T07 · Invariant clause:** Add a normative clause for “Unsupported-feature refusal” that preserves “Unsupported input cannot produce a misleading successful translation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Unsupported-feature refusal”; include the source counterexample “A parser ignores an unfamiliar language construct” and the intended safe disposition.
- [ ] **UC-M04.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Feature diagnostics and input bytes” in the “Unsupported-feature refusal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C051-T10 · Contract review:** Review the “Unsupported-feature refusal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C052 · Delivery

**Original checklist item:** Identify and reject source features outside the supported translation profile.

- [ ] **UC-M04.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Unsupported-feature refusal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C052-T02 · Change plan:** Break the source delivery for “Unsupported-feature refusal” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C052-T03 · Core artifact:** Create the “Unsupported-feature refusal” model, schema or inventory that realizes this source instruction: Identify and reject source features outside the supported translation profile.
- [ ] **UC-M04.04-C052-T04 · Concrete realization:** Populate “Unsupported-feature refusal” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Unsupported-feature refusal” needed to preserve “Unsupported input cannot produce a misleading successful translation”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C052-T06 · Dependency connection:** Connect the “Unsupported-feature refusal” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C052-T07 · Resource behavior:** Account for “Feature diagnostics and input bytes” in “Unsupported-feature refusal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Unsupported-feature refusal”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C052-T09 · Patch review:** Review the “Unsupported-feature refusal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C052-T10 · Delivery handoff:** Publish the “Unsupported-feature refusal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported input cannot produce a misleading successful translation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Unsupported-feature refusal”; copy its required invariant exactly: “Unsupported input cannot produce a misleading successful translation”.
- [ ] **UC-M04.04-C053-T02 · Observable terms:** Define each term in the “Unsupported-feature refusal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C053-T03 · Precondition set:** List the preconditions under which “Unsupported input cannot produce a misleading successful translation” must hold for “Unsupported-feature refusal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C053-T04 · Transition coverage:** Map the “Unsupported-feature refusal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Unsupported-feature refusal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C053-T06 · Satisfying fixture:** Create a concrete “Unsupported-feature refusal” case that satisfies “Unsupported input cannot produce a misleading successful translation”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C053-T07 · Violating fixture:** Create the source counterexample “A parser ignores an unfamiliar language construct” for “Unsupported-feature refusal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C053-T08 · Enforcement evidence:** Exercise the “Unsupported-feature refusal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C053-T09 · Regression linkage:** Link the “Unsupported-feature refusal” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Unsupported-feature refusal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C054 · Integration

**Original checklist item:** Integrate unsupported-feature refusal with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Unsupported-feature refusal” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C054-T02 · Field mapping:** Map every “Unsupported-feature refusal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Unsupported-feature refusal” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C054-T04 · Ownership agreement:** Specify who owns “Unsupported-feature refusal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C054-T05 · Handoff implementation:** Connect “Unsupported-feature refusal” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported input cannot produce a misleading successful translation” across the handoff.
- [ ] **UC-M04.04-C054-T06 · Absent-input case:** Omit one required “Unsupported-feature refusal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C054-T07 · Stale-input case:** Supply an outdated “Unsupported-feature refusal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Unsupported-feature refusal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C054-T09 · Valid integration trace:** Run a valid “Unsupported-feature refusal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C054-T10 · Seam review:** Reconcile the “Unsupported-feature refusal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for unsupported-feature refusal; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Unsupported-feature refusal”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C055-T02 · Expected-result oracle:** Specify the “Unsupported-feature refusal” expected result independently of the implementation output; include the property “Unsupported input cannot produce a misleading successful translation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C055-T03 · Fixture material:** Create the concrete “Unsupported-feature refusal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C055-T04 · Target preparation:** Prepare the “Unsupported-feature refusal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C055-T05 · Initial-state record:** Record the initial “Unsupported-feature refusal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C055-T06 · Valid-path execution:** Run the “Unsupported-feature refusal” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C055-T07 · Outcome comparison:** Compare every declared “Unsupported-feature refusal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C055-T08 · State and bounds check:** Inspect the “Unsupported-feature refusal” ownership/state effects and actual use of “Feature diagnostics and input bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C055-T09 · Repeatability check:** Repeat the same “Unsupported-feature refusal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C055-T10 · Positive evidence:** Attach the “Unsupported-feature refusal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C056 · Negative test

**Original checklist item:** Negative case: A parser ignores an unfamiliar language construct. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Unsupported-feature refusal” source counterexample: “A parser ignores an unfamiliar language construct”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Unsupported-feature refusal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C056-T03 · Valid control:** Construct a valid “Unsupported-feature refusal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C056-T04 · Minimal adverse input:** Derive the “Unsupported-feature refusal” adverse fixture from the control with the smallest documented change needed to reproduce “A parser ignores an unfamiliar language construct”; retain that change as reproducible data.
- [ ] **UC-M04.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Unsupported-feature refusal”; require “Unsupported input cannot produce a misleading successful translation” and forbid a false-success verdict.
- [ ] **UC-M04.04-C056-T06 · Adverse execution:** Exercise the “Unsupported-feature refusal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C056-T07 · Effect inspection:** Inspect “Unsupported-feature refusal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C056-T08 · Refusal versus failure:** Confirm the “Unsupported-feature refusal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C056-T09 · Reset and retention:** Restore only the disposable “Unsupported-feature refusal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C056-T10 · Negative regression:** Register the “Unsupported-feature refusal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C057 · Change / failure test

**Original checklist item:** Exercise unsupported-feature refusal when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C057-T01 · Scenario record:** Write the “Unsupported-feature refusal” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Unsupported input cannot produce a misleading successful translation”.
- [ ] **UC-M04.04-C057-T02 · Baseline capture:** Create a known-valid “Unsupported-feature refusal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C057-T03 · Injection map:** Locate the “Unsupported-feature refusal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Unsupported-feature refusal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C057-T05 · Controlled trigger:** Introduce the controlled “Unsupported-feature refusal” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C057-T06 · Intermediate inspection:** Inspect the “Unsupported-feature refusal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Unsupported-feature refusal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Unsupported-feature refusal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C057-T09 · Repeat and compare:** Repeat the selected “Unsupported-feature refusal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C057-T10 · Failure evidence:** Publish the “Unsupported-feature refusal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for feature diagnostics and input bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Unsupported-feature refusal”: “Feature diagnostics and input bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C058-T02 · Measurement method:** Choose how to observe each “Unsupported-feature refusal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Unsupported-feature refusal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Unsupported-feature refusal” cases for “Feature diagnostics and input bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Unsupported-feature refusal” limit; preserve “Unsupported input cannot produce a misleading successful translation”.
- [ ] **UC-M04.04-C058-T06 · Normal measurement:** Run or review the normal “Unsupported-feature refusal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C058-T07 · At-limit measurement:** Exercise the “Unsupported-feature refusal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C058-T08 · Over-limit measurement:** Exercise the “Unsupported-feature refusal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C058-T09 · Uncovered-scope report:** List the “Unsupported-feature refusal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C058-T10 · Limit evidence:** Publish the selected “Unsupported-feature refusal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C059 · Diagnostics / review

**Original checklist item:** Report unsupported-feature refusal results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C059-T01 · Result inventory:** Enumerate the required “Unsupported-feature refusal” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Unsupported-feature refusal”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Unsupported-feature refusal” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C059-T04 · Observation capture:** Capture bounded raw “Unsupported-feature refusal” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C059-T05 · Aggregation rules:** Implement the “Unsupported-feature refusal” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unsupported input cannot produce a misleading successful translation”.
- [ ] **UC-M04.04-C059-T06 · Failure visibility:** Feed a failing “Unsupported-feature refusal” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C059-T07 · Missing-result visibility:** Withhold a required “Unsupported-feature refusal” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C059-T08 · Bounds and redaction:** Check “Unsupported-feature refusal” report size and retention against “Feature diagnostics and input bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C059-T09 · Report reconciliation:** Reconcile the “Unsupported-feature refusal” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C059-T10 · Qualification handoff:** Publish the “Unsupported-feature refusal” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for unsupported-feature refusal; label unexecuted checks as untested.

- [ ] **UC-M04.04-C060-T01 · Evidence inventory:** List the “Unsupported-feature refusal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C060-T02 · Artifact references:** Record the exact “Unsupported-feature refusal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C060-T03 · Fixture references:** Attach the “Unsupported-feature refusal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A parser ignores an unfamiliar language construct” as a distinct evidence case.
- [ ] **UC-M04.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Unsupported-feature refusal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C060-T05 · Environment record:** Record the actual “Unsupported-feature refusal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C060-T06 · Expected versus observed:** Pair every “Unsupported-feature refusal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C060-T07 · Failure and limit records:** Attach “Unsupported-feature refusal” change/failure and bounds evidence where required; include uncovered “Feature diagnostics and input bytes” and unresolved violations of “Unsupported input cannot produce a misleading successful translation”.
- [ ] **UC-M04.04-C060-T08 · Evidence hygiene:** Check the “Unsupported-feature refusal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C060-T09 · Reproduction review:** Have the “Unsupported-feature refusal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C060-T10 · Acceptance linkage:** Link the “Unsupported-feature refusal” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Lowering expansion limits

**Source delivery:** Bound generated code and metadata expansion from compact source input.

**Source invariant:** Small source input cannot create unbounded generated artifacts.

**Source negative case:** A compact repeated construct explodes into enormous native code.

**Source bounded quantities:** Expansion ratio and generated bytes.

### UC-M04.04-C061 · Contract

**Original checklist item:** Define the qualification objective for lowering expansion limits, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C061-T01 · Scope statement:** Write the qualification question for “Lowering expansion limits”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Lowering expansion limits”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C061-T03 · Output inventory:** List the outputs of “Lowering expansion limits” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Lowering expansion limits”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C061-T05 · Prerequisite contract:** Map “Lowering expansion limits” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Lowering expansion limits”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C061-T07 · Invariant clause:** Add a normative clause for “Lowering expansion limits” that preserves “Small source input cannot create unbounded generated artifacts”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Lowering expansion limits”; include the source counterexample “A compact repeated construct explodes into enormous native code” and the intended safe disposition.
- [ ] **UC-M04.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Expansion ratio and generated bytes” in the “Lowering expansion limits” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C061-T10 · Contract review:** Review the “Lowering expansion limits” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C062 · Delivery

**Original checklist item:** Bound generated code and metadata expansion from compact source input.

- [ ] **UC-M04.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Lowering expansion limits”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C062-T02 · Change plan:** Break the source delivery for “Lowering expansion limits” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Lowering expansion limits” that realizes this source instruction: Bound generated code and metadata expansion from compact source input.
- [ ] **UC-M04.04-C062-T04 · Concrete realization:** Trace “Lowering expansion limits” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Lowering expansion limits” needed to preserve “Small source input cannot create unbounded generated artifacts”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C062-T06 · Dependency connection:** Connect the “Lowering expansion limits” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C062-T07 · Resource behavior:** Account for “Expansion ratio and generated bytes” in “Lowering expansion limits”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Lowering expansion limits”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C062-T09 · Patch review:** Review the “Lowering expansion limits” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C062-T10 · Delivery handoff:** Publish the “Lowering expansion limits” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Small source input cannot create unbounded generated artifacts. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Lowering expansion limits”; copy its required invariant exactly: “Small source input cannot create unbounded generated artifacts”.
- [ ] **UC-M04.04-C063-T02 · Observable terms:** Define each term in the “Lowering expansion limits” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C063-T03 · Precondition set:** List the preconditions under which “Small source input cannot create unbounded generated artifacts” must hold for “Lowering expansion limits”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C063-T04 · Transition coverage:** Map the “Lowering expansion limits” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Lowering expansion limits”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C063-T06 · Satisfying fixture:** Create a concrete “Lowering expansion limits” case that satisfies “Small source input cannot create unbounded generated artifacts”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C063-T07 · Violating fixture:** Create the source counterexample “A compact repeated construct explodes into enormous native code” for “Lowering expansion limits”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C063-T08 · Enforcement evidence:** Exercise the “Lowering expansion limits” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C063-T09 · Regression linkage:** Link the “Lowering expansion limits” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Lowering expansion limits” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C064 · Integration

**Original checklist item:** Integrate lowering expansion limits with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Lowering expansion limits” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C064-T02 · Field mapping:** Map every “Lowering expansion limits” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Lowering expansion limits” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C064-T04 · Ownership agreement:** Specify who owns “Lowering expansion limits” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C064-T05 · Handoff implementation:** Connect “Lowering expansion limits” through the mapped seam using the real adapter or explicit specification reference; preserve “Small source input cannot create unbounded generated artifacts” across the handoff.
- [ ] **UC-M04.04-C064-T06 · Absent-input case:** Omit one required “Lowering expansion limits” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C064-T07 · Stale-input case:** Supply an outdated “Lowering expansion limits” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Lowering expansion limits” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C064-T09 · Valid integration trace:** Run a valid “Lowering expansion limits” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C064-T10 · Seam review:** Reconcile the “Lowering expansion limits” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for lowering expansion limits; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Lowering expansion limits”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C065-T02 · Expected-result oracle:** Specify the “Lowering expansion limits” expected result independently of the implementation output; include the property “Small source input cannot create unbounded generated artifacts” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C065-T03 · Fixture material:** Create the concrete “Lowering expansion limits” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C065-T04 · Target preparation:** Prepare the “Lowering expansion limits” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C065-T05 · Initial-state record:** Record the initial “Lowering expansion limits” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C065-T06 · Valid-path execution:** Run the “Lowering expansion limits” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C065-T07 · Outcome comparison:** Compare every declared “Lowering expansion limits” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C065-T08 · State and bounds check:** Inspect the “Lowering expansion limits” ownership/state effects and actual use of “Expansion ratio and generated bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C065-T09 · Repeatability check:** Repeat the same “Lowering expansion limits” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C065-T10 · Positive evidence:** Attach the “Lowering expansion limits” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C066 · Negative test

**Original checklist item:** Negative case: A compact repeated construct explodes into enormous native code. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Lowering expansion limits” source counterexample: “A compact repeated construct explodes into enormous native code”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Lowering expansion limits”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C066-T03 · Valid control:** Construct a valid “Lowering expansion limits” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C066-T04 · Minimal adverse input:** Derive the “Lowering expansion limits” adverse fixture from the control with the smallest documented change needed to reproduce “A compact repeated construct explodes into enormous native code”; retain that change as reproducible data.
- [ ] **UC-M04.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Lowering expansion limits”; require “Small source input cannot create unbounded generated artifacts” and forbid a false-success verdict.
- [ ] **UC-M04.04-C066-T06 · Adverse execution:** Exercise the “Lowering expansion limits” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C066-T07 · Effect inspection:** Inspect “Lowering expansion limits” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C066-T08 · Refusal versus failure:** Confirm the “Lowering expansion limits” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C066-T09 · Reset and retention:** Restore only the disposable “Lowering expansion limits” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C066-T10 · Negative regression:** Register the “Lowering expansion limits” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C067 · Change / failure test

**Original checklist item:** Exercise lowering expansion limits when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C067-T01 · Scenario record:** Write the “Lowering expansion limits” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Small source input cannot create unbounded generated artifacts”.
- [ ] **UC-M04.04-C067-T02 · Baseline capture:** Create a known-valid “Lowering expansion limits” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C067-T03 · Injection map:** Locate the “Lowering expansion limits” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Lowering expansion limits” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C067-T05 · Controlled trigger:** Introduce the controlled “Lowering expansion limits” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C067-T06 · Intermediate inspection:** Inspect the “Lowering expansion limits” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Lowering expansion limits”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Lowering expansion limits” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C067-T09 · Repeat and compare:** Repeat the selected “Lowering expansion limits” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C067-T10 · Failure evidence:** Publish the “Lowering expansion limits” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for expansion ratio and generated bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Lowering expansion limits”: “Expansion ratio and generated bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C068-T02 · Measurement method:** Choose how to observe each “Lowering expansion limits” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Lowering expansion limits”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Lowering expansion limits” cases for “Expansion ratio and generated bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Lowering expansion limits” limit; preserve “Small source input cannot create unbounded generated artifacts”.
- [ ] **UC-M04.04-C068-T06 · Normal measurement:** Run or review the normal “Lowering expansion limits” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C068-T07 · At-limit measurement:** Exercise the “Lowering expansion limits” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C068-T08 · Over-limit measurement:** Exercise the “Lowering expansion limits” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C068-T09 · Uncovered-scope report:** List the “Lowering expansion limits” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C068-T10 · Limit evidence:** Publish the selected “Lowering expansion limits” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C069 · Diagnostics / review

**Original checklist item:** Report lowering expansion limits results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C069-T01 · Result inventory:** Enumerate the required “Lowering expansion limits” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Lowering expansion limits”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Lowering expansion limits” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C069-T04 · Observation capture:** Capture bounded raw “Lowering expansion limits” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C069-T05 · Aggregation rules:** Implement the “Lowering expansion limits” count/reduction rule so failures and missing measurements cannot disappear; preserve “Small source input cannot create unbounded generated artifacts”.
- [ ] **UC-M04.04-C069-T06 · Failure visibility:** Feed a failing “Lowering expansion limits” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C069-T07 · Missing-result visibility:** Withhold a required “Lowering expansion limits” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C069-T08 · Bounds and redaction:** Check “Lowering expansion limits” report size and retention against “Expansion ratio and generated bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C069-T09 · Report reconciliation:** Reconcile the “Lowering expansion limits” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C069-T10 · Qualification handoff:** Publish the “Lowering expansion limits” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for lowering expansion limits; label unexecuted checks as untested.

- [ ] **UC-M04.04-C070-T01 · Evidence inventory:** List the “Lowering expansion limits” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C070-T02 · Artifact references:** Record the exact “Lowering expansion limits” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C070-T03 · Fixture references:** Attach the “Lowering expansion limits” fixture IDs, input identities and oracle definition; preserve the source counterexample “A compact repeated construct explodes into enormous native code” as a distinct evidence case.
- [ ] **UC-M04.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Lowering expansion limits”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C070-T05 · Environment record:** Record the actual “Lowering expansion limits” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C070-T06 · Expected versus observed:** Pair every “Lowering expansion limits” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C070-T07 · Failure and limit records:** Attach “Lowering expansion limits” change/failure and bounds evidence where required; include uncovered “Expansion ratio and generated bytes” and unresolved violations of “Small source input cannot create unbounded generated artifacts”.
- [ ] **UC-M04.04-C070-T08 · Evidence hygiene:** Check the “Lowering expansion limits” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C070-T09 · Reproduction review:** Have the “Lowering expansion limits” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C070-T10 · Acceptance linkage:** Link the “Lowering expansion limits” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Differential test harness

**Source delivery:** Run source, intermediate and native paths on the same identified inputs.

**Source invariant:** All compared results refer to the same program and input identity.

**Source negative case:** Different inputs are accidentally used in the compared runs.

**Source bounded quantities:** Parallel test count and fixture storage.

### UC-M04.04-C071 · Contract

**Original checklist item:** Define the qualification objective for differential test harness, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C071-T01 · Scope statement:** Write the qualification question for “Differential test harness”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Differential test harness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C071-T03 · Output inventory:** List the outputs of “Differential test harness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Differential test harness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C071-T05 · Prerequisite contract:** Map “Differential test harness” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Differential test harness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C071-T07 · Invariant clause:** Add a normative clause for “Differential test harness” that preserves “All compared results refer to the same program and input identity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Differential test harness”; include the source counterexample “Different inputs are accidentally used in the compared runs” and the intended safe disposition.
- [ ] **UC-M04.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Parallel test count and fixture storage” in the “Differential test harness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C071-T10 · Contract review:** Review the “Differential test harness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C072 · Delivery

**Original checklist item:** Run source, intermediate and native paths on the same identified inputs.

- [ ] **UC-M04.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Differential test harness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C072-T02 · Change plan:** Break the source delivery for “Differential test harness” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C072-T03 · Core artifact:** Create the “Differential test harness” fixture or harness for this source instruction: Run source, intermediate and native paths on the same identified inputs.
- [ ] **UC-M04.04-C072-T04 · Concrete realization:** Connect the “Differential test harness” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Differential test harness” needed to preserve “All compared results refer to the same program and input identity”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C072-T06 · Dependency connection:** Connect the “Differential test harness” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C072-T07 · Resource behavior:** Account for “Parallel test count and fixture storage” in “Differential test harness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Differential test harness”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C072-T09 · Patch review:** Review the “Differential test harness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C072-T10 · Delivery handoff:** Publish the “Differential test harness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: All compared results refer to the same program and input identity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Differential test harness”; copy its required invariant exactly: “All compared results refer to the same program and input identity”.
- [ ] **UC-M04.04-C073-T02 · Observable terms:** Define each term in the “Differential test harness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C073-T03 · Precondition set:** List the preconditions under which “All compared results refer to the same program and input identity” must hold for “Differential test harness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C073-T04 · Transition coverage:** Map the “Differential test harness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Differential test harness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C073-T06 · Satisfying fixture:** Create a concrete “Differential test harness” case that satisfies “All compared results refer to the same program and input identity”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C073-T07 · Violating fixture:** Create the source counterexample “Different inputs are accidentally used in the compared runs” for “Differential test harness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C073-T08 · Enforcement evidence:** Exercise the “Differential test harness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C073-T09 · Regression linkage:** Link the “Differential test harness” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Differential test harness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C074 · Integration

**Original checklist item:** Integrate differential test harness with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Differential test harness” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C074-T02 · Field mapping:** Map every “Differential test harness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Differential test harness” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C074-T04 · Ownership agreement:** Specify who owns “Differential test harness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C074-T05 · Handoff implementation:** Connect “Differential test harness” through the mapped seam using the real adapter or explicit specification reference; preserve “All compared results refer to the same program and input identity” across the handoff.
- [ ] **UC-M04.04-C074-T06 · Absent-input case:** Omit one required “Differential test harness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C074-T07 · Stale-input case:** Supply an outdated “Differential test harness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Differential test harness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C074-T09 · Valid integration trace:** Run a valid “Differential test harness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C074-T10 · Seam review:** Reconcile the “Differential test harness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for differential test harness; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Differential test harness”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C075-T02 · Expected-result oracle:** Specify the “Differential test harness” expected result independently of the implementation output; include the property “All compared results refer to the same program and input identity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C075-T03 · Fixture material:** Create the concrete “Differential test harness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C075-T04 · Target preparation:** Prepare the “Differential test harness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C075-T05 · Initial-state record:** Record the initial “Differential test harness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C075-T06 · Valid-path execution:** Run the “Differential test harness” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C075-T07 · Outcome comparison:** Compare every declared “Differential test harness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C075-T08 · State and bounds check:** Inspect the “Differential test harness” ownership/state effects and actual use of “Parallel test count and fixture storage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C075-T09 · Repeatability check:** Repeat the same “Differential test harness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C075-T10 · Positive evidence:** Attach the “Differential test harness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C076 · Negative test

**Original checklist item:** Negative case: Different inputs are accidentally used in the compared runs. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Differential test harness” source counterexample: “Different inputs are accidentally used in the compared runs”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Differential test harness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C076-T03 · Valid control:** Construct a valid “Differential test harness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C076-T04 · Minimal adverse input:** Derive the “Differential test harness” adverse fixture from the control with the smallest documented change needed to reproduce “Different inputs are accidentally used in the compared runs”; retain that change as reproducible data.
- [ ] **UC-M04.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Differential test harness”; require “All compared results refer to the same program and input identity” and forbid a false-success verdict.
- [ ] **UC-M04.04-C076-T06 · Adverse execution:** Exercise the “Differential test harness” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C076-T07 · Effect inspection:** Inspect “Differential test harness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C076-T08 · Refusal versus failure:** Confirm the “Differential test harness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C076-T09 · Reset and retention:** Restore only the disposable “Differential test harness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C076-T10 · Negative regression:** Register the “Differential test harness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C077 · Change / failure test

**Original checklist item:** Exercise differential test harness when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C077-T01 · Scenario record:** Write the “Differential test harness” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “All compared results refer to the same program and input identity”.
- [ ] **UC-M04.04-C077-T02 · Baseline capture:** Create a known-valid “Differential test harness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C077-T03 · Injection map:** Locate the “Differential test harness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Differential test harness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C077-T05 · Controlled trigger:** Introduce the controlled “Differential test harness” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C077-T06 · Intermediate inspection:** Inspect the “Differential test harness” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Differential test harness”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Differential test harness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C077-T09 · Repeat and compare:** Repeat the selected “Differential test harness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C077-T10 · Failure evidence:** Publish the “Differential test harness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for parallel test count and fixture storage; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Differential test harness”: “Parallel test count and fixture storage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C078-T02 · Measurement method:** Choose how to observe each “Differential test harness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Differential test harness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Differential test harness” cases for “Parallel test count and fixture storage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Differential test harness” limit; preserve “All compared results refer to the same program and input identity”.
- [ ] **UC-M04.04-C078-T06 · Normal measurement:** Run or review the normal “Differential test harness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C078-T07 · At-limit measurement:** Exercise the “Differential test harness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C078-T08 · Over-limit measurement:** Exercise the “Differential test harness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C078-T09 · Uncovered-scope report:** List the “Differential test harness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C078-T10 · Limit evidence:** Publish the selected “Differential test harness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C079 · Diagnostics / review

**Original checklist item:** Report differential test harness results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C079-T01 · Result inventory:** Enumerate the required “Differential test harness” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Differential test harness”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Differential test harness” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C079-T04 · Observation capture:** Capture bounded raw “Differential test harness” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C079-T05 · Aggregation rules:** Implement the “Differential test harness” count/reduction rule so failures and missing measurements cannot disappear; preserve “All compared results refer to the same program and input identity”.
- [ ] **UC-M04.04-C079-T06 · Failure visibility:** Feed a failing “Differential test harness” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C079-T07 · Missing-result visibility:** Withhold a required “Differential test harness” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C079-T08 · Bounds and redaction:** Check “Differential test harness” report size and retention against “Parallel test count and fixture storage”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C079-T09 · Report reconciliation:** Reconcile the “Differential test harness” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C079-T10 · Qualification handoff:** Publish the “Differential test harness” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for differential test harness; label unexecuted checks as untested.

- [ ] **UC-M04.04-C080-T01 · Evidence inventory:** List the “Differential test harness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C080-T02 · Artifact references:** Record the exact “Differential test harness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C080-T03 · Fixture references:** Attach the “Differential test harness” fixture IDs, input identities and oracle definition; preserve the source counterexample “Different inputs are accidentally used in the compared runs” as a distinct evidence case.
- [ ] **UC-M04.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Differential test harness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C080-T05 · Environment record:** Record the actual “Differential test harness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C080-T06 · Expected versus observed:** Pair every “Differential test harness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C080-T07 · Failure and limit records:** Attach “Differential test harness” change/failure and bounds evidence where required; include uncovered “Parallel test count and fixture storage” and unresolved violations of “All compared results refer to the same program and input identity”.
- [ ] **UC-M04.04-C080-T08 · Evidence hygiene:** Check the “Differential test harness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C080-T09 · Reproduction review:** Have the “Differential test harness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C080-T10 · Acceptance linkage:** Link the “Differential test harness” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Guest-target validation

**Source delivery:** Repeat required semantic cases on the selected actual guest target.

**Source invariant:** Host-only semantic tests do not qualify guest behavior.

**Source negative case:** A host executable's result is reused as the guest verdict.

**Source bounded quantities:** Target matrix and guest run budget.

### UC-M04.04-C081 · Contract

**Original checklist item:** Define the qualification objective for guest-target validation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C081-T01 · Scope statement:** Write the qualification question for “Guest-target validation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Guest-target validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C081-T03 · Output inventory:** List the outputs of “Guest-target validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Guest-target validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C081-T05 · Prerequisite contract:** Map “Guest-target validation” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Guest-target validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C081-T07 · Invariant clause:** Add a normative clause for “Guest-target validation” that preserves “Host-only semantic tests do not qualify guest behavior”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Guest-target validation”; include the source counterexample “A host executable's result is reused as the guest verdict” and the intended safe disposition.
- [ ] **UC-M04.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Target matrix and guest run budget” in the “Guest-target validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C081-T10 · Contract review:** Review the “Guest-target validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C082 · Delivery

**Original checklist item:** Repeat required semantic cases on the selected actual guest target.

- [ ] **UC-M04.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Guest-target validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C082-T02 · Change plan:** Break the source delivery for “Guest-target validation” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Guest-target validation” that realizes this source instruction: Repeat required semantic cases on the selected actual guest target.
- [ ] **UC-M04.04-C082-T04 · Concrete realization:** Trace “Guest-target validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Guest-target validation” needed to preserve “Host-only semantic tests do not qualify guest behavior”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C082-T06 · Dependency connection:** Connect the “Guest-target validation” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C082-T07 · Resource behavior:** Account for “Target matrix and guest run budget” in “Guest-target validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Guest-target validation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C082-T09 · Patch review:** Review the “Guest-target validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C082-T10 · Delivery handoff:** Publish the “Guest-target validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Host-only semantic tests do not qualify guest behavior. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Guest-target validation”; copy its required invariant exactly: “Host-only semantic tests do not qualify guest behavior”.
- [ ] **UC-M04.04-C083-T02 · Observable terms:** Define each term in the “Guest-target validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C083-T03 · Precondition set:** List the preconditions under which “Host-only semantic tests do not qualify guest behavior” must hold for “Guest-target validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C083-T04 · Transition coverage:** Map the “Guest-target validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Guest-target validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C083-T06 · Satisfying fixture:** Create a concrete “Guest-target validation” case that satisfies “Host-only semantic tests do not qualify guest behavior”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C083-T07 · Violating fixture:** Create the source counterexample “A host executable's result is reused as the guest verdict” for “Guest-target validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C083-T08 · Enforcement evidence:** Exercise the “Guest-target validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C083-T09 · Regression linkage:** Link the “Guest-target validation” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Guest-target validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C084 · Integration

**Original checklist item:** Integrate guest-target validation with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Guest-target validation” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C084-T02 · Field mapping:** Map every “Guest-target validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Guest-target validation” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C084-T04 · Ownership agreement:** Specify who owns “Guest-target validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C084-T05 · Handoff implementation:** Connect “Guest-target validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Host-only semantic tests do not qualify guest behavior” across the handoff.
- [ ] **UC-M04.04-C084-T06 · Absent-input case:** Omit one required “Guest-target validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C084-T07 · Stale-input case:** Supply an outdated “Guest-target validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Guest-target validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C084-T09 · Valid integration trace:** Run a valid “Guest-target validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C084-T10 · Seam review:** Reconcile the “Guest-target validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for guest-target validation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Guest-target validation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C085-T02 · Expected-result oracle:** Specify the “Guest-target validation” expected result independently of the implementation output; include the property “Host-only semantic tests do not qualify guest behavior” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C085-T03 · Fixture material:** Create the concrete “Guest-target validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C085-T04 · Target preparation:** Prepare the “Guest-target validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C085-T05 · Initial-state record:** Record the initial “Guest-target validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C085-T06 · Valid-path execution:** Run the “Guest-target validation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C085-T07 · Outcome comparison:** Compare every declared “Guest-target validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C085-T08 · State and bounds check:** Inspect the “Guest-target validation” ownership/state effects and actual use of “Target matrix and guest run budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C085-T09 · Repeatability check:** Repeat the same “Guest-target validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C085-T10 · Positive evidence:** Attach the “Guest-target validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C086 · Negative test

**Original checklist item:** Negative case: A host executable's result is reused as the guest verdict. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Guest-target validation” source counterexample: “A host executable's result is reused as the guest verdict”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Guest-target validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C086-T03 · Valid control:** Construct a valid “Guest-target validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C086-T04 · Minimal adverse input:** Derive the “Guest-target validation” adverse fixture from the control with the smallest documented change needed to reproduce “A host executable's result is reused as the guest verdict”; retain that change as reproducible data.
- [ ] **UC-M04.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Guest-target validation”; require “Host-only semantic tests do not qualify guest behavior” and forbid a false-success verdict.
- [ ] **UC-M04.04-C086-T06 · Adverse execution:** Exercise the “Guest-target validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C086-T07 · Effect inspection:** Inspect “Guest-target validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C086-T08 · Refusal versus failure:** Confirm the “Guest-target validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C086-T09 · Reset and retention:** Restore only the disposable “Guest-target validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C086-T10 · Negative regression:** Register the “Guest-target validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C087 · Change / failure test

**Original checklist item:** Exercise guest-target validation when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C087-T01 · Scenario record:** Write the “Guest-target validation” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Host-only semantic tests do not qualify guest behavior”.
- [ ] **UC-M04.04-C087-T02 · Baseline capture:** Create a known-valid “Guest-target validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C087-T03 · Injection map:** Locate the “Guest-target validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Guest-target validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C087-T05 · Controlled trigger:** Introduce the controlled “Guest-target validation” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C087-T06 · Intermediate inspection:** Inspect the “Guest-target validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Guest-target validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Guest-target validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C087-T09 · Repeat and compare:** Repeat the selected “Guest-target validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C087-T10 · Failure evidence:** Publish the “Guest-target validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for target matrix and guest run budget; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Guest-target validation”: “Target matrix and guest run budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C088-T02 · Measurement method:** Choose how to observe each “Guest-target validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Guest-target validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Guest-target validation” cases for “Target matrix and guest run budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Guest-target validation” limit; preserve “Host-only semantic tests do not qualify guest behavior”.
- [ ] **UC-M04.04-C088-T06 · Normal measurement:** Run or review the normal “Guest-target validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C088-T07 · At-limit measurement:** Exercise the “Guest-target validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C088-T08 · Over-limit measurement:** Exercise the “Guest-target validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C088-T09 · Uncovered-scope report:** List the “Guest-target validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C088-T10 · Limit evidence:** Publish the selected “Guest-target validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C089 · Diagnostics / review

**Original checklist item:** Report guest-target validation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C089-T01 · Result inventory:** Enumerate the required “Guest-target validation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Guest-target validation”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Guest-target validation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C089-T04 · Observation capture:** Capture bounded raw “Guest-target validation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C089-T05 · Aggregation rules:** Implement the “Guest-target validation” count/reduction rule so failures and missing measurements cannot disappear; preserve “Host-only semantic tests do not qualify guest behavior”.
- [ ] **UC-M04.04-C089-T06 · Failure visibility:** Feed a failing “Guest-target validation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C089-T07 · Missing-result visibility:** Withhold a required “Guest-target validation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C089-T08 · Bounds and redaction:** Check “Guest-target validation” report size and retention against “Target matrix and guest run budget”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C089-T09 · Report reconciliation:** Reconcile the “Guest-target validation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C089-T10 · Qualification handoff:** Publish the “Guest-target validation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for guest-target validation; label unexecuted checks as untested.

- [ ] **UC-M04.04-C090-T01 · Evidence inventory:** List the “Guest-target validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C090-T02 · Artifact references:** Record the exact “Guest-target validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C090-T03 · Fixture references:** Attach the “Guest-target validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host executable's result is reused as the guest verdict” as a distinct evidence case.
- [ ] **UC-M04.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Guest-target validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C090-T05 · Environment record:** Record the actual “Guest-target validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C090-T06 · Expected versus observed:** Pair every “Guest-target validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C090-T07 · Failure and limit records:** Attach “Guest-target validation” change/failure and bounds evidence where required; include uncovered “Target matrix and guest run budget” and unresolved violations of “Host-only semantic tests do not qualify guest behavior”.
- [ ] **UC-M04.04-C090-T08 · Evidence hygiene:** Check the “Guest-target validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C090-T09 · Reproduction review:** Have the “Guest-target validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C090-T10 · Acceptance linkage:** Link the “Guest-target validation” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Translation evidence

**Source delivery:** Bind compiler identity, source, IR and native observations in one record.

**Source invariant:** Changed translation inputs invalidate their previous semantic evidence.

**Source negative case:** A compiler upgrade leaves old translation approval current.

**Source bounded quantities:** Evidence bytes and dependency fan-out.

### UC-M04.04-C091 · Contract

**Original checklist item:** Define the qualification objective for translation evidence, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M04.04-C091-T01 · Scope statement:** Write the qualification question for “Translation evidence”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M04.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Translation evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.04-C091-T03 · Output inventory:** List the outputs of “Translation evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Translation evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.04-C091-T05 · Prerequisite contract:** Map “Translation evidence” to the source component prerequisites (UC-M01.07, UC-M02.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Translation evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.04-C091-T07 · Invariant clause:** Add a normative clause for “Translation evidence” that preserves “Changed translation inputs invalidate their previous semantic evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Translation evidence”; include the source counterexample “A compiler upgrade leaves old translation approval current” and the intended safe disposition.
- [ ] **UC-M04.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence bytes and dependency fan-out” in the “Translation evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.04-C091-T10 · Contract review:** Review the “Translation evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.04-C092 · Delivery

**Original checklist item:** Bind compiler identity, source, IR and native observations in one record.

- [ ] **UC-M04.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Translation evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.04-C092-T02 · Change plan:** Break the source delivery for “Translation evidence” into concrete edit targets and reviewable outputs; keep the UC-M04.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.04-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Translation evidence” that realizes this source instruction: Bind compiler identity, source, IR and native observations in one record.
- [ ] **UC-M04.04-C092-T04 · Concrete realization:** Trace “Translation evidence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Translation evidence” needed to preserve “Changed translation inputs invalidate their previous semantic evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.04-C092-T06 · Dependency connection:** Connect the “Translation evidence” qualification artifact to source oracles, intermediate representations and actual native/guest execution; record the target identity and what the harness actually exercises.
- [ ] **UC-M04.04-C092-T07 · Resource behavior:** Account for “Evidence bytes and dependency fan-out” in “Translation evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.04-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Translation evidence”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M04.04-C092-T09 · Patch review:** Review the “Translation evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.04-C092-T10 · Delivery handoff:** Publish the “Translation evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Changed translation inputs invalidate their previous semantic evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Translation evidence”; copy its required invariant exactly: “Changed translation inputs invalidate their previous semantic evidence”.
- [ ] **UC-M04.04-C093-T02 · Observable terms:** Define each term in the “Translation evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.04-C093-T03 · Precondition set:** List the preconditions under which “Changed translation inputs invalidate their previous semantic evidence” must hold for “Translation evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.04-C093-T04 · Transition coverage:** Map the “Translation evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Translation evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.04-C093-T06 · Satisfying fixture:** Create a concrete “Translation evidence” case that satisfies “Changed translation inputs invalidate their previous semantic evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.04-C093-T07 · Violating fixture:** Create the source counterexample “A compiler upgrade leaves old translation approval current” for “Translation evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.04-C093-T08 · Enforcement evidence:** Exercise the “Translation evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.04-C093-T09 · Regression linkage:** Link the “Translation evidence” property to changes in source oracles, intermediate representations and actual native/guest execution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Translation evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.04-C094 · Integration

**Original checklist item:** Integrate translation evidence with source oracles, intermediate representations and actual native/guest execution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Translation evidence” across source oracles, intermediate representations and actual native/guest execution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.04-C094-T02 · Field mapping:** Map every “Translation evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Translation evidence” (source dependency list: UC-M01.07, UC-M02.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.04-C094-T04 · Ownership agreement:** Specify who owns “Translation evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.04-C094-T05 · Handoff implementation:** Connect “Translation evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “Changed translation inputs invalidate their previous semantic evidence” across the handoff.
- [ ] **UC-M04.04-C094-T06 · Absent-input case:** Omit one required “Translation evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.04-C094-T07 · Stale-input case:** Supply an outdated “Translation evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Translation evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.04-C094-T09 · Valid integration trace:** Run a valid “Translation evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.04-C094-T10 · Seam review:** Reconcile the “Translation evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.04-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for translation evidence; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M04.04-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Translation evidence”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M04.04-C095-T02 · Expected-result oracle:** Specify the “Translation evidence” expected result independently of the implementation output; include the property “Changed translation inputs invalidate their previous semantic evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.04-C095-T03 · Fixture material:** Create the concrete “Translation evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.04-C095-T04 · Target preparation:** Prepare the “Translation evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.04-C095-T05 · Initial-state record:** Record the initial “Translation evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.04-C095-T06 · Valid-path execution:** Run the “Translation evidence” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M04.04-C095-T07 · Outcome comparison:** Compare every declared “Translation evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.04-C095-T08 · State and bounds check:** Inspect the “Translation evidence” ownership/state effects and actual use of “Evidence bytes and dependency fan-out”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.04-C095-T09 · Repeatability check:** Repeat the same “Translation evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.04-C095-T10 · Positive evidence:** Attach the “Translation evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.04-C096 · Negative test

**Original checklist item:** Negative case: A compiler upgrade leaves old translation approval current. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Translation evidence” source counterexample: “A compiler upgrade leaves old translation approval current”; state which precondition or invariant it challenges.
- [ ] **UC-M04.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Translation evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.04-C096-T03 · Valid control:** Construct a valid “Translation evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.04-C096-T04 · Minimal adverse input:** Derive the “Translation evidence” adverse fixture from the control with the smallest documented change needed to reproduce “A compiler upgrade leaves old translation approval current”; retain that change as reproducible data.
- [ ] **UC-M04.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Translation evidence”; require “Changed translation inputs invalidate their previous semantic evidence” and forbid a false-success verdict.
- [ ] **UC-M04.04-C096-T06 · Adverse execution:** Exercise the “Translation evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.04-C096-T07 · Effect inspection:** Inspect “Translation evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.04-C096-T08 · Refusal versus failure:** Confirm the “Translation evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.04-C096-T09 · Reset and retention:** Restore only the disposable “Translation evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.04-C096-T10 · Negative regression:** Register the “Translation evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.04-C097 · Change / failure test

**Original checklist item:** Exercise translation evidence when a compiler change leaves old semantic fixtures and evidence in the cache; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.04-C097-T01 · Scenario record:** Write the “Translation evidence” change/failure scenario exactly as supplied: a compiler change leaves old semantic fixtures and evidence in the cache; identify the property that must remain true: “Changed translation inputs invalidate their previous semantic evidence”.
- [ ] **UC-M04.04-C097-T02 · Baseline capture:** Create a known-valid “Translation evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.04-C097-T03 · Injection map:** Locate the “Translation evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Translation evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.04-C097-T05 · Controlled trigger:** Introduce the controlled “Translation evidence” scenario in the disposable fixture: a compiler change leaves old semantic fixtures and evidence in the cache; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.04-C097-T06 · Intermediate inspection:** Inspect the “Translation evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Translation evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Translation evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.04-C097-T09 · Repeat and compare:** Repeat the selected “Translation evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.04-C097-T10 · Failure evidence:** Publish the “Translation evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.04-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for evidence bytes and dependency fan-out; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M04.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Translation evidence”: “Evidence bytes and dependency fan-out”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.04-C098-T02 · Measurement method:** Choose how to observe each “Translation evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.04-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Translation evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Translation evidence” cases for “Evidence bytes and dependency fan-out”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Translation evidence” limit; preserve “Changed translation inputs invalidate their previous semantic evidence”.
- [ ] **UC-M04.04-C098-T06 · Normal measurement:** Run or review the normal “Translation evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.04-C098-T07 · At-limit measurement:** Exercise the “Translation evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.04-C098-T08 · Over-limit measurement:** Exercise the “Translation evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.04-C098-T09 · Uncovered-scope report:** List the “Translation evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.04-C098-T10 · Limit evidence:** Publish the selected “Translation evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.04-C099 · Diagnostics / review

**Original checklist item:** Report translation evidence results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M04.04-C099-T01 · Result inventory:** Enumerate the required “Translation evidence” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M04.04-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Translation evidence”; document how incomplete cases block relevant claims.
- [ ] **UC-M04.04-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Translation evidence” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M04.04-C099-T04 · Observation capture:** Capture bounded raw “Translation evidence” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M04.04-C099-T05 · Aggregation rules:** Implement the “Translation evidence” count/reduction rule so failures and missing measurements cannot disappear; preserve “Changed translation inputs invalidate their previous semantic evidence”.
- [ ] **UC-M04.04-C099-T06 · Failure visibility:** Feed a failing “Translation evidence” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M04.04-C099-T07 · Missing-result visibility:** Withhold a required “Translation evidence” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M04.04-C099-T08 · Bounds and redaction:** Check “Translation evidence” report size and retention against “Evidence bytes and dependency fan-out”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M04.04-C099-T09 · Report reconciliation:** Reconcile the “Translation evidence” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M04.04-C099-T10 · Qualification handoff:** Publish the “Translation evidence” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M04.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for translation evidence; label unexecuted checks as untested.

- [ ] **UC-M04.04-C100-T01 · Evidence inventory:** List the “Translation evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.04-C100-T02 · Artifact references:** Record the exact “Translation evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.04-C100-T03 · Fixture references:** Attach the “Translation evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A compiler upgrade leaves old translation approval current” as a distinct evidence case.
- [ ] **UC-M04.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Translation evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.04-C100-T05 · Environment record:** Record the actual “Translation evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.04-C100-T06 · Expected versus observed:** Pair every “Translation evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.04-C100-T07 · Failure and limit records:** Attach “Translation evidence” change/failure and bounds evidence where required; include uncovered “Evidence bytes and dependency fan-out” and unresolved violations of “Changed translation inputs invalidate their previous semantic evidence”.
- [ ] **UC-M04.04-C100-T08 · Evidence hygiene:** Check the “Translation evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.04-C100-T09 · Reproduction review:** Have the “Translation evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.04-C100-T10 · Acceptance linkage:** Link the “Translation evidence” evidence to its parent and UC-M04.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

