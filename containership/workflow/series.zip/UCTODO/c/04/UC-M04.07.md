# UC-M04.07 — Build provenance attestations

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M04.02](../04/UC-M04.02.md), [UC-M04.05](../04/UC-M04.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Bind image digest to inputs, build recipe, builder identity and observed tests; use SLSA concepts without claiming an unassessed level.

**Original acceptance criterion:** An independent verifier reconstructs the build relationship and rejects altered subjects or unknown builders.

**Source trace:** Original checklist `UC100/c/04/UC-M04.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 400–410 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Attestation statement schema

**Source delivery:** Define a statement binding subjects, inputs, recipe, builder and observed tests.

**Source invariant:** Each statement has explicit subject identities and semantics.

**Source negative case:** An attestation omits the image it claims to describe.

**Source bounded quantities:** Statement bytes and subject count.

### UC-M04.07-C001 · Contract

**Original checklist item:** Specify attestation statement schema inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C001-T01 · Scope statement:** Draft the operation boundary for “Attestation statement schema” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Attestation statement schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C001-T03 · Output inventory:** List the outputs of “Attestation statement schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Attestation statement schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C001-T05 · Prerequisite contract:** Map “Attestation statement schema” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Attestation statement schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C001-T07 · Invariant clause:** Add a normative clause for “Attestation statement schema” that preserves “Each statement has explicit subject identities and semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Attestation statement schema”; include the source counterexample “An attestation omits the image it claims to describe” and the intended safe disposition.
- [ ] **UC-M04.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Statement bytes and subject count” in the “Attestation statement schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C001-T10 · Contract review:** Review the “Attestation statement schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C002 · Delivery

**Original checklist item:** Define a statement binding subjects, inputs, recipe, builder and observed tests.

- [ ] **UC-M04.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Attestation statement schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C002-T02 · Change plan:** Break the source delivery for “Attestation statement schema” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C002-T03 · Core artifact:** Create the “Attestation statement schema” model, schema or inventory that realizes this source instruction: Define a statement binding subjects, inputs, recipe, builder and observed tests.
- [ ] **UC-M04.07-C002-T04 · Concrete realization:** Populate “Attestation statement schema” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Attestation statement schema” needed to preserve “Each statement has explicit subject identities and semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C002-T06 · Dependency connection:** Connect the “Attestation statement schema” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C002-T07 · Resource behavior:** Account for “Statement bytes and subject count” in “Attestation statement schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C002-T08 · Delivery check:** Run the smallest real “Attestation statement schema” path and its adverse fixture “An attestation omits the image it claims to describe”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C002-T09 · Patch review:** Review the “Attestation statement schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C002-T10 · Delivery handoff:** Publish the “Attestation statement schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each statement has explicit subject identities and semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Attestation statement schema”; copy its required invariant exactly: “Each statement has explicit subject identities and semantics”.
- [ ] **UC-M04.07-C003-T02 · Observable terms:** Define each term in the “Attestation statement schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C003-T03 · Precondition set:** List the preconditions under which “Each statement has explicit subject identities and semantics” must hold for “Attestation statement schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C003-T04 · Transition coverage:** Map the “Attestation statement schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Attestation statement schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C003-T06 · Satisfying fixture:** Create a concrete “Attestation statement schema” case that satisfies “Each statement has explicit subject identities and semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C003-T07 · Violating fixture:** Create the source counterexample “An attestation omits the image it claims to describe” for “Attestation statement schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C003-T08 · Enforcement evidence:** Exercise the “Attestation statement schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C003-T09 · Regression linkage:** Link the “Attestation statement schema” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Attestation statement schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C004 · Integration

**Original checklist item:** Integrate attestation statement schema with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Attestation statement schema” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C004-T02 · Field mapping:** Map every “Attestation statement schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Attestation statement schema” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C004-T04 · Ownership agreement:** Specify who owns “Attestation statement schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C004-T05 · Handoff implementation:** Connect “Attestation statement schema” through the mapped seam using the real adapter or explicit specification reference; preserve “Each statement has explicit subject identities and semantics” across the handoff.
- [ ] **UC-M04.07-C004-T06 · Absent-input case:** Omit one required “Attestation statement schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C004-T07 · Stale-input case:** Supply an outdated “Attestation statement schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Attestation statement schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C004-T09 · Valid integration trace:** Run a valid “Attestation statement schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C004-T10 · Seam review:** Reconcile the “Attestation statement schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for attestation statement schema; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Attestation statement schema” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C005-T02 · Expected-result oracle:** Specify the “Attestation statement schema” expected result independently of the implementation output; include the property “Each statement has explicit subject identities and semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C005-T03 · Fixture material:** Create the concrete “Attestation statement schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C005-T04 · Target preparation:** Prepare the “Attestation statement schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C005-T05 · Initial-state record:** Record the initial “Attestation statement schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C005-T06 · Valid-path execution:** Execute the “Attestation statement schema” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C005-T07 · Outcome comparison:** Compare every declared “Attestation statement schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C005-T08 · State and bounds check:** Inspect the “Attestation statement schema” ownership/state effects and actual use of “Statement bytes and subject count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C005-T09 · Repeatability check:** Repeat the same “Attestation statement schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C005-T10 · Positive evidence:** Attach the “Attestation statement schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C006 · Negative test

**Original checklist item:** Negative case: An attestation omits the image it claims to describe. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Attestation statement schema” source counterexample: “An attestation omits the image it claims to describe”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Attestation statement schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C006-T03 · Valid control:** Construct a valid “Attestation statement schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C006-T04 · Minimal adverse input:** Derive the “Attestation statement schema” adverse fixture from the control with the smallest documented change needed to reproduce “An attestation omits the image it claims to describe”; retain that change as reproducible data.
- [ ] **UC-M04.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Attestation statement schema”; require “Each statement has explicit subject identities and semantics” and forbid a false-success verdict.
- [ ] **UC-M04.07-C006-T06 · Adverse execution:** Exercise the “Attestation statement schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C006-T07 · Effect inspection:** Inspect “Attestation statement schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C006-T08 · Refusal versus failure:** Confirm the “Attestation statement schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C006-T09 · Reset and retention:** Restore only the disposable “Attestation statement schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C006-T10 · Negative regression:** Register the “Attestation statement schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C007 · Change / failure test

**Original checklist item:** Exercise attestation statement schema when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C007-T01 · Scenario record:** Write the “Attestation statement schema” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “Each statement has explicit subject identities and semantics”.
- [ ] **UC-M04.07-C007-T02 · Baseline capture:** Create a known-valid “Attestation statement schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C007-T03 · Injection map:** Locate the “Attestation statement schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Attestation statement schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C007-T05 · Controlled trigger:** Introduce the controlled “Attestation statement schema” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C007-T06 · Intermediate inspection:** Inspect the “Attestation statement schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Attestation statement schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Attestation statement schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C007-T09 · Repeat and compare:** Repeat the selected “Attestation statement schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C007-T10 · Failure evidence:** Publish the “Attestation statement schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for statement bytes and subject count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Attestation statement schema”: “Statement bytes and subject count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C008-T02 · Measurement method:** Choose how to observe each “Attestation statement schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Attestation statement schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Attestation statement schema” cases for “Statement bytes and subject count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Attestation statement schema” limit; preserve “Each statement has explicit subject identities and semantics”.
- [ ] **UC-M04.07-C008-T06 · Normal measurement:** Run or review the normal “Attestation statement schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C008-T07 · At-limit measurement:** Exercise the “Attestation statement schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C008-T08 · Over-limit measurement:** Exercise the “Attestation statement schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C008-T09 · Uncovered-scope report:** List the “Attestation statement schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C008-T10 · Limit evidence:** Publish the selected “Attestation statement schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for attestation statement schema with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C009-T01 · Event inventory:** List the “Attestation statement schema” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Attestation statement schema” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C009-T03 · Failure mapping:** Map each documented “Attestation statement schema” refusal or error to a diagnostic outcome; include “An attestation omits the image it claims to describe” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C009-T04 · Emission path:** Add the “Attestation statement schema” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C009-T05 · Redaction check:** Test “Attestation statement schema” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C009-T06 · Output budget:** Set and exercise bounded “Attestation statement schema” message size, rate and retention compatible with “Statement bytes and subject count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C009-T07 · Success/refusal fixtures:** Capture “Attestation statement schema” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Attestation statement schema” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C009-T09 · Operator review:** Read the “Attestation statement schema” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C009-T10 · Diagnostic evidence:** Publish redacted “Attestation statement schema” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for attestation statement schema; label unexecuted checks as untested.

- [ ] **UC-M04.07-C010-T01 · Evidence inventory:** List the “Attestation statement schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C010-T02 · Artifact references:** Record the exact “Attestation statement schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C010-T03 · Fixture references:** Attach the “Attestation statement schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “An attestation omits the image it claims to describe” as a distinct evidence case.
- [ ] **UC-M04.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Attestation statement schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C010-T05 · Environment record:** Record the actual “Attestation statement schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C010-T06 · Expected versus observed:** Pair every “Attestation statement schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C010-T07 · Failure and limit records:** Attach “Attestation statement schema” change/failure and bounds evidence where required; include uncovered “Statement bytes and subject count” and unresolved violations of “Each statement has explicit subject identities and semantics”.
- [ ] **UC-M04.07-C010-T08 · Evidence hygiene:** Check the “Attestation statement schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C010-T09 · Reproduction review:** Have the “Attestation statement schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C010-T10 · Acceptance linkage:** Link the “Attestation statement schema” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Input material identities

**Source delivery:** Record the exact source and dependency identities used by the build.

**Source invariant:** Declared build relationships are reconstructable from materials.

**Source negative case:** A changed compiler is not reflected in build materials.

**Source bounded quantities:** Material count and metadata depth.

### UC-M04.07-C011 · Contract

**Original checklist item:** Specify input material identities inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C011-T01 · Scope statement:** Draft the operation boundary for “Input material identities” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Input material identities”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C011-T03 · Output inventory:** List the outputs of “Input material identities” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Input material identities”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C011-T05 · Prerequisite contract:** Map “Input material identities” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Input material identities”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C011-T07 · Invariant clause:** Add a normative clause for “Input material identities” that preserves “Declared build relationships are reconstructable from materials”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Input material identities”; include the source counterexample “A changed compiler is not reflected in build materials” and the intended safe disposition.
- [ ] **UC-M04.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Material count and metadata depth” in the “Input material identities” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C011-T10 · Contract review:** Review the “Input material identities” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C012 · Delivery

**Original checklist item:** Record the exact source and dependency identities used by the build.

- [ ] **UC-M04.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Input material identities”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C012-T02 · Change plan:** Break the source delivery for “Input material identities” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C012-T03 · Core artifact:** Create the “Input material identities” model, schema or inventory that realizes this source instruction: Record the exact source and dependency identities used by the build.
- [ ] **UC-M04.07-C012-T04 · Concrete realization:** Populate “Input material identities” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Input material identities” needed to preserve “Declared build relationships are reconstructable from materials”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C012-T06 · Dependency connection:** Connect the “Input material identities” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C012-T07 · Resource behavior:** Account for “Material count and metadata depth” in “Input material identities”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C012-T08 · Delivery check:** Run the smallest real “Input material identities” path and its adverse fixture “A changed compiler is not reflected in build materials”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C012-T09 · Patch review:** Review the “Input material identities” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C012-T10 · Delivery handoff:** Publish the “Input material identities” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Declared build relationships are reconstructable from materials. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Input material identities”; copy its required invariant exactly: “Declared build relationships are reconstructable from materials”.
- [ ] **UC-M04.07-C013-T02 · Observable terms:** Define each term in the “Input material identities” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C013-T03 · Precondition set:** List the preconditions under which “Declared build relationships are reconstructable from materials” must hold for “Input material identities”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C013-T04 · Transition coverage:** Map the “Input material identities” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Input material identities”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C013-T06 · Satisfying fixture:** Create a concrete “Input material identities” case that satisfies “Declared build relationships are reconstructable from materials”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C013-T07 · Violating fixture:** Create the source counterexample “A changed compiler is not reflected in build materials” for “Input material identities”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C013-T08 · Enforcement evidence:** Exercise the “Input material identities” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C013-T09 · Regression linkage:** Link the “Input material identities” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Input material identities” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C014 · Integration

**Original checklist item:** Integrate input material identities with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Input material identities” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C014-T02 · Field mapping:** Map every “Input material identities” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Input material identities” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C014-T04 · Ownership agreement:** Specify who owns “Input material identities” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C014-T05 · Handoff implementation:** Connect “Input material identities” through the mapped seam using the real adapter or explicit specification reference; preserve “Declared build relationships are reconstructable from materials” across the handoff.
- [ ] **UC-M04.07-C014-T06 · Absent-input case:** Omit one required “Input material identities” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C014-T07 · Stale-input case:** Supply an outdated “Input material identities” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Input material identities” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C014-T09 · Valid integration trace:** Run a valid “Input material identities” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C014-T10 · Seam review:** Reconcile the “Input material identities” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for input material identities; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Input material identities” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C015-T02 · Expected-result oracle:** Specify the “Input material identities” expected result independently of the implementation output; include the property “Declared build relationships are reconstructable from materials” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C015-T03 · Fixture material:** Create the concrete “Input material identities” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C015-T04 · Target preparation:** Prepare the “Input material identities” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C015-T05 · Initial-state record:** Record the initial “Input material identities” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C015-T06 · Valid-path execution:** Execute the “Input material identities” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C015-T07 · Outcome comparison:** Compare every declared “Input material identities” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C015-T08 · State and bounds check:** Inspect the “Input material identities” ownership/state effects and actual use of “Material count and metadata depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C015-T09 · Repeatability check:** Repeat the same “Input material identities” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C015-T10 · Positive evidence:** Attach the “Input material identities” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C016 · Negative test

**Original checklist item:** Negative case: A changed compiler is not reflected in build materials. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Input material identities” source counterexample: “A changed compiler is not reflected in build materials”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Input material identities”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C016-T03 · Valid control:** Construct a valid “Input material identities” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C016-T04 · Minimal adverse input:** Derive the “Input material identities” adverse fixture from the control with the smallest documented change needed to reproduce “A changed compiler is not reflected in build materials”; retain that change as reproducible data.
- [ ] **UC-M04.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Input material identities”; require “Declared build relationships are reconstructable from materials” and forbid a false-success verdict.
- [ ] **UC-M04.07-C016-T06 · Adverse execution:** Exercise the “Input material identities” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C016-T07 · Effect inspection:** Inspect “Input material identities” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C016-T08 · Refusal versus failure:** Confirm the “Input material identities” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C016-T09 · Reset and retention:** Restore only the disposable “Input material identities” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C016-T10 · Negative regression:** Register the “Input material identities” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C017 · Change / failure test

**Original checklist item:** Exercise input material identities when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C017-T01 · Scenario record:** Write the “Input material identities” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “Declared build relationships are reconstructable from materials”.
- [ ] **UC-M04.07-C017-T02 · Baseline capture:** Create a known-valid “Input material identities” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C017-T03 · Injection map:** Locate the “Input material identities” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Input material identities” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C017-T05 · Controlled trigger:** Introduce the controlled “Input material identities” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C017-T06 · Intermediate inspection:** Inspect the “Input material identities” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Input material identities”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Input material identities” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C017-T09 · Repeat and compare:** Repeat the selected “Input material identities” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C017-T10 · Failure evidence:** Publish the “Input material identities” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for material count and metadata depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Input material identities”: “Material count and metadata depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C018-T02 · Measurement method:** Choose how to observe each “Input material identities” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Input material identities”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Input material identities” cases for “Material count and metadata depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Input material identities” limit; preserve “Declared build relationships are reconstructable from materials”.
- [ ] **UC-M04.07-C018-T06 · Normal measurement:** Run or review the normal “Input material identities” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C018-T07 · At-limit measurement:** Exercise the “Input material identities” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C018-T08 · Over-limit measurement:** Exercise the “Input material identities” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C018-T09 · Uncovered-scope report:** List the “Input material identities” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C018-T10 · Limit evidence:** Publish the selected “Input material identities” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for input material identities with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C019-T01 · Event inventory:** List the “Input material identities” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Input material identities” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C019-T03 · Failure mapping:** Map each documented “Input material identities” refusal or error to a diagnostic outcome; include “A changed compiler is not reflected in build materials” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C019-T04 · Emission path:** Add the “Input material identities” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C019-T05 · Redaction check:** Test “Input material identities” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C019-T06 · Output budget:** Set and exercise bounded “Input material identities” message size, rate and retention compatible with “Material count and metadata depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C019-T07 · Success/refusal fixtures:** Capture “Input material identities” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Input material identities” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C019-T09 · Operator review:** Read the “Input material identities” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C019-T10 · Diagnostic evidence:** Publish redacted “Input material identities” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for input material identities; label unexecuted checks as untested.

- [ ] **UC-M04.07-C020-T01 · Evidence inventory:** List the “Input material identities” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C020-T02 · Artifact references:** Record the exact “Input material identities” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C020-T03 · Fixture references:** Attach the “Input material identities” fixture IDs, input identities and oracle definition; preserve the source counterexample “A changed compiler is not reflected in build materials” as a distinct evidence case.
- [ ] **UC-M04.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Input material identities”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C020-T05 · Environment record:** Record the actual “Input material identities” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C020-T06 · Expected versus observed:** Pair every “Input material identities” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C020-T07 · Failure and limit records:** Attach “Input material identities” change/failure and bounds evidence where required; include uncovered “Material count and metadata depth” and unresolved violations of “Declared build relationships are reconstructable from materials”.
- [ ] **UC-M04.07-C020-T08 · Evidence hygiene:** Check the “Input material identities” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C020-T09 · Reproduction review:** Have the “Input material identities” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C020-T10 · Acceptance linkage:** Link the “Input material identities” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Recipe binding

**Source delivery:** Bind the build recipe and target configuration to the produced image.

**Source invariant:** The recipe identity cannot change without invalidating its provenance.

**Source negative case:** A different recipe is substituted after signing.

**Source bounded quantities:** Recipe bytes and target variants.

### UC-M04.07-C021 · Contract

**Original checklist item:** Specify recipe binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C021-T01 · Scope statement:** Draft the operation boundary for “Recipe binding” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recipe binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C021-T03 · Output inventory:** List the outputs of “Recipe binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Recipe binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C021-T05 · Prerequisite contract:** Map “Recipe binding” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Recipe binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C021-T07 · Invariant clause:** Add a normative clause for “Recipe binding” that preserves “The recipe identity cannot change without invalidating its provenance”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recipe binding”; include the source counterexample “A different recipe is substituted after signing” and the intended safe disposition.
- [ ] **UC-M04.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recipe bytes and target variants” in the “Recipe binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C021-T10 · Contract review:** Review the “Recipe binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C022 · Delivery

**Original checklist item:** Bind the build recipe and target configuration to the produced image.

- [ ] **UC-M04.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recipe binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C022-T02 · Change plan:** Break the source delivery for “Recipe binding” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Recipe binding” that realizes this source instruction: Bind the build recipe and target configuration to the produced image.
- [ ] **UC-M04.07-C022-T04 · Concrete realization:** Trace “Recipe binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recipe binding” needed to preserve “The recipe identity cannot change without invalidating its provenance”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C022-T06 · Dependency connection:** Connect the “Recipe binding” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C022-T07 · Resource behavior:** Account for “Recipe bytes and target variants” in “Recipe binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C022-T08 · Delivery check:** Run the smallest real “Recipe binding” path and its adverse fixture “A different recipe is substituted after signing”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C022-T09 · Patch review:** Review the “Recipe binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C022-T10 · Delivery handoff:** Publish the “Recipe binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The recipe identity cannot change without invalidating its provenance. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Recipe binding”; copy its required invariant exactly: “The recipe identity cannot change without invalidating its provenance”.
- [ ] **UC-M04.07-C023-T02 · Observable terms:** Define each term in the “Recipe binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C023-T03 · Precondition set:** List the preconditions under which “The recipe identity cannot change without invalidating its provenance” must hold for “Recipe binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C023-T04 · Transition coverage:** Map the “Recipe binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recipe binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C023-T06 · Satisfying fixture:** Create a concrete “Recipe binding” case that satisfies “The recipe identity cannot change without invalidating its provenance”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C023-T07 · Violating fixture:** Create the source counterexample “A different recipe is substituted after signing” for “Recipe binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C023-T08 · Enforcement evidence:** Exercise the “Recipe binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C023-T09 · Regression linkage:** Link the “Recipe binding” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Recipe binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C024 · Integration

**Original checklist item:** Integrate recipe binding with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recipe binding” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C024-T02 · Field mapping:** Map every “Recipe binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Recipe binding” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C024-T04 · Ownership agreement:** Specify who owns “Recipe binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C024-T05 · Handoff implementation:** Connect “Recipe binding” through the mapped seam using the real adapter or explicit specification reference; preserve “The recipe identity cannot change without invalidating its provenance” across the handoff.
- [ ] **UC-M04.07-C024-T06 · Absent-input case:** Omit one required “Recipe binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C024-T07 · Stale-input case:** Supply an outdated “Recipe binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Recipe binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C024-T09 · Valid integration trace:** Run a valid “Recipe binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C024-T10 · Seam review:** Reconcile the “Recipe binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for recipe binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Recipe binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C025-T02 · Expected-result oracle:** Specify the “Recipe binding” expected result independently of the implementation output; include the property “The recipe identity cannot change without invalidating its provenance” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C025-T03 · Fixture material:** Create the concrete “Recipe binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C025-T04 · Target preparation:** Prepare the “Recipe binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C025-T05 · Initial-state record:** Record the initial “Recipe binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C025-T06 · Valid-path execution:** Execute the “Recipe binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C025-T07 · Outcome comparison:** Compare every declared “Recipe binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C025-T08 · State and bounds check:** Inspect the “Recipe binding” ownership/state effects and actual use of “Recipe bytes and target variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C025-T09 · Repeatability check:** Repeat the same “Recipe binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C025-T10 · Positive evidence:** Attach the “Recipe binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C026 · Negative test

**Original checklist item:** Negative case: A different recipe is substituted after signing. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Recipe binding” source counterexample: “A different recipe is substituted after signing”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Recipe binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C026-T03 · Valid control:** Construct a valid “Recipe binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C026-T04 · Minimal adverse input:** Derive the “Recipe binding” adverse fixture from the control with the smallest documented change needed to reproduce “A different recipe is substituted after signing”; retain that change as reproducible data.
- [ ] **UC-M04.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recipe binding”; require “The recipe identity cannot change without invalidating its provenance” and forbid a false-success verdict.
- [ ] **UC-M04.07-C026-T06 · Adverse execution:** Exercise the “Recipe binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C026-T07 · Effect inspection:** Inspect “Recipe binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C026-T08 · Refusal versus failure:** Confirm the “Recipe binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C026-T09 · Reset and retention:** Restore only the disposable “Recipe binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C026-T10 · Negative regression:** Register the “Recipe binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C027 · Change / failure test

**Original checklist item:** Exercise recipe binding when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C027-T01 · Scenario record:** Write the “Recipe binding” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “The recipe identity cannot change without invalidating its provenance”.
- [ ] **UC-M04.07-C027-T02 · Baseline capture:** Create a known-valid “Recipe binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C027-T03 · Injection map:** Locate the “Recipe binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Recipe binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C027-T05 · Controlled trigger:** Introduce the controlled “Recipe binding” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C027-T06 · Intermediate inspection:** Inspect the “Recipe binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recipe binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Recipe binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C027-T09 · Repeat and compare:** Repeat the selected “Recipe binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C027-T10 · Failure evidence:** Publish the “Recipe binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for recipe bytes and target variants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Recipe binding”: “Recipe bytes and target variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C028-T02 · Measurement method:** Choose how to observe each “Recipe binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Recipe binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recipe binding” cases for “Recipe bytes and target variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recipe binding” limit; preserve “The recipe identity cannot change without invalidating its provenance”.
- [ ] **UC-M04.07-C028-T06 · Normal measurement:** Run or review the normal “Recipe binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C028-T07 · At-limit measurement:** Exercise the “Recipe binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C028-T08 · Over-limit measurement:** Exercise the “Recipe binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C028-T09 · Uncovered-scope report:** List the “Recipe binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C028-T10 · Limit evidence:** Publish the selected “Recipe binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for recipe binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C029-T01 · Event inventory:** List the “Recipe binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Recipe binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C029-T03 · Failure mapping:** Map each documented “Recipe binding” refusal or error to a diagnostic outcome; include “A different recipe is substituted after signing” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C029-T04 · Emission path:** Add the “Recipe binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C029-T05 · Redaction check:** Test “Recipe binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C029-T06 · Output budget:** Set and exercise bounded “Recipe binding” message size, rate and retention compatible with “Recipe bytes and target variants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C029-T07 · Success/refusal fixtures:** Capture “Recipe binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Recipe binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C029-T09 · Operator review:** Read the “Recipe binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C029-T10 · Diagnostic evidence:** Publish redacted “Recipe binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recipe binding; label unexecuted checks as untested.

- [ ] **UC-M04.07-C030-T01 · Evidence inventory:** List the “Recipe binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C030-T02 · Artifact references:** Record the exact “Recipe binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C030-T03 · Fixture references:** Attach the “Recipe binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A different recipe is substituted after signing” as a distinct evidence case.
- [ ] **UC-M04.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recipe binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C030-T05 · Environment record:** Record the actual “Recipe binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C030-T06 · Expected versus observed:** Pair every “Recipe binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C030-T07 · Failure and limit records:** Attach “Recipe binding” change/failure and bounds evidence where required; include uncovered “Recipe bytes and target variants” and unresolved violations of “The recipe identity cannot change without invalidating its provenance”.
- [ ] **UC-M04.07-C030-T08 · Evidence hygiene:** Check the “Recipe binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C030-T09 · Reproduction review:** Have the “Recipe binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C030-T10 · Acceptance linkage:** Link the “Recipe binding” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Builder identity

**Source delivery:** Identify the builder and its approved authority independently of cargo.

**Source invariant:** An unknown builder cannot authorize itself through its output.

**Source negative case:** An attacker supplies a self-declared trusted builder name.

**Source bounded quantities:** Builder identities and trust lookup cost.

### UC-M04.07-C031 · Contract

**Original checklist item:** Specify builder identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C031-T01 · Scope statement:** Draft the operation boundary for “Builder identity” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Builder identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C031-T03 · Output inventory:** List the outputs of “Builder identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Builder identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C031-T05 · Prerequisite contract:** Map “Builder identity” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Builder identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C031-T07 · Invariant clause:** Add a normative clause for “Builder identity” that preserves “An unknown builder cannot authorize itself through its output”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Builder identity”; include the source counterexample “An attacker supplies a self-declared trusted builder name” and the intended safe disposition.
- [ ] **UC-M04.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Builder identities and trust lookup cost” in the “Builder identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C031-T10 · Contract review:** Review the “Builder identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C032 · Delivery

**Original checklist item:** Identify the builder and its approved authority independently of cargo.

- [ ] **UC-M04.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Builder identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C032-T02 · Change plan:** Break the source delivery for “Builder identity” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C032-T03 · Core artifact:** Create the “Builder identity” model, schema or inventory that realizes this source instruction: Identify the builder and its approved authority independently of cargo.
- [ ] **UC-M04.07-C032-T04 · Concrete realization:** Populate “Builder identity” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Builder identity” needed to preserve “An unknown builder cannot authorize itself through its output”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C032-T06 · Dependency connection:** Connect the “Builder identity” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C032-T07 · Resource behavior:** Account for “Builder identities and trust lookup cost” in “Builder identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C032-T08 · Delivery check:** Run the smallest real “Builder identity” path and its adverse fixture “An attacker supplies a self-declared trusted builder name”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C032-T09 · Patch review:** Review the “Builder identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C032-T10 · Delivery handoff:** Publish the “Builder identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An unknown builder cannot authorize itself through its output. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Builder identity”; copy its required invariant exactly: “An unknown builder cannot authorize itself through its output”.
- [ ] **UC-M04.07-C033-T02 · Observable terms:** Define each term in the “Builder identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C033-T03 · Precondition set:** List the preconditions under which “An unknown builder cannot authorize itself through its output” must hold for “Builder identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C033-T04 · Transition coverage:** Map the “Builder identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Builder identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C033-T06 · Satisfying fixture:** Create a concrete “Builder identity” case that satisfies “An unknown builder cannot authorize itself through its output”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C033-T07 · Violating fixture:** Create the source counterexample “An attacker supplies a self-declared trusted builder name” for “Builder identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C033-T08 · Enforcement evidence:** Exercise the “Builder identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C033-T09 · Regression linkage:** Link the “Builder identity” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Builder identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C034 · Integration

**Original checklist item:** Integrate builder identity with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Builder identity” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C034-T02 · Field mapping:** Map every “Builder identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Builder identity” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C034-T04 · Ownership agreement:** Specify who owns “Builder identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C034-T05 · Handoff implementation:** Connect “Builder identity” through the mapped seam using the real adapter or explicit specification reference; preserve “An unknown builder cannot authorize itself through its output” across the handoff.
- [ ] **UC-M04.07-C034-T06 · Absent-input case:** Omit one required “Builder identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C034-T07 · Stale-input case:** Supply an outdated “Builder identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Builder identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C034-T09 · Valid integration trace:** Run a valid “Builder identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C034-T10 · Seam review:** Reconcile the “Builder identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for builder identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Builder identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C035-T02 · Expected-result oracle:** Specify the “Builder identity” expected result independently of the implementation output; include the property “An unknown builder cannot authorize itself through its output” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C035-T03 · Fixture material:** Create the concrete “Builder identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C035-T04 · Target preparation:** Prepare the “Builder identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C035-T05 · Initial-state record:** Record the initial “Builder identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C035-T06 · Valid-path execution:** Execute the “Builder identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C035-T07 · Outcome comparison:** Compare every declared “Builder identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C035-T08 · State and bounds check:** Inspect the “Builder identity” ownership/state effects and actual use of “Builder identities and trust lookup cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C035-T09 · Repeatability check:** Repeat the same “Builder identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C035-T10 · Positive evidence:** Attach the “Builder identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C036 · Negative test

**Original checklist item:** Negative case: An attacker supplies a self-declared trusted builder name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Builder identity” source counterexample: “An attacker supplies a self-declared trusted builder name”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Builder identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C036-T03 · Valid control:** Construct a valid “Builder identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C036-T04 · Minimal adverse input:** Derive the “Builder identity” adverse fixture from the control with the smallest documented change needed to reproduce “An attacker supplies a self-declared trusted builder name”; retain that change as reproducible data.
- [ ] **UC-M04.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Builder identity”; require “An unknown builder cannot authorize itself through its output” and forbid a false-success verdict.
- [ ] **UC-M04.07-C036-T06 · Adverse execution:** Exercise the “Builder identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C036-T07 · Effect inspection:** Inspect “Builder identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C036-T08 · Refusal versus failure:** Confirm the “Builder identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C036-T09 · Reset and retention:** Restore only the disposable “Builder identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C036-T10 · Negative regression:** Register the “Builder identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C037 · Change / failure test

**Original checklist item:** Exercise builder identity when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C037-T01 · Scenario record:** Write the “Builder identity” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “An unknown builder cannot authorize itself through its output”.
- [ ] **UC-M04.07-C037-T02 · Baseline capture:** Create a known-valid “Builder identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C037-T03 · Injection map:** Locate the “Builder identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Builder identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C037-T05 · Controlled trigger:** Introduce the controlled “Builder identity” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C037-T06 · Intermediate inspection:** Inspect the “Builder identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Builder identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Builder identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C037-T09 · Repeat and compare:** Repeat the selected “Builder identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C037-T10 · Failure evidence:** Publish the “Builder identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for builder identities and trust lookup cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Builder identity”: “Builder identities and trust lookup cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C038-T02 · Measurement method:** Choose how to observe each “Builder identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Builder identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Builder identity” cases for “Builder identities and trust lookup cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Builder identity” limit; preserve “An unknown builder cannot authorize itself through its output”.
- [ ] **UC-M04.07-C038-T06 · Normal measurement:** Run or review the normal “Builder identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C038-T07 · At-limit measurement:** Exercise the “Builder identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C038-T08 · Over-limit measurement:** Exercise the “Builder identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C038-T09 · Uncovered-scope report:** List the “Builder identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C038-T10 · Limit evidence:** Publish the selected “Builder identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for builder identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C039-T01 · Event inventory:** List the “Builder identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Builder identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C039-T03 · Failure mapping:** Map each documented “Builder identity” refusal or error to a diagnostic outcome; include “An attacker supplies a self-declared trusted builder name” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C039-T04 · Emission path:** Add the “Builder identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C039-T05 · Redaction check:** Test “Builder identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C039-T06 · Output budget:** Set and exercise bounded “Builder identity” message size, rate and retention compatible with “Builder identities and trust lookup cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C039-T07 · Success/refusal fixtures:** Capture “Builder identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Builder identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C039-T09 · Operator review:** Read the “Builder identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C039-T10 · Diagnostic evidence:** Publish redacted “Builder identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for builder identity; label unexecuted checks as untested.

- [ ] **UC-M04.07-C040-T01 · Evidence inventory:** List the “Builder identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C040-T02 · Artifact references:** Record the exact “Builder identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C040-T03 · Fixture references:** Attach the “Builder identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “An attacker supplies a self-declared trusted builder name” as a distinct evidence case.
- [ ] **UC-M04.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Builder identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C040-T05 · Environment record:** Record the actual “Builder identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C040-T06 · Expected versus observed:** Pair every “Builder identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C040-T07 · Failure and limit records:** Attach “Builder identity” change/failure and bounds evidence where required; include uncovered “Builder identities and trust lookup cost” and unresolved violations of “An unknown builder cannot authorize itself through its output”.
- [ ] **UC-M04.07-C040-T08 · Evidence hygiene:** Check the “Builder identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C040-T09 · Reproduction review:** Have the “Builder identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C040-T10 · Acceptance linkage:** Link the “Builder identity” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Observed test recording

**Source delivery:** Record executed tests, outcomes and skips without inventing coverage.

**Source invariant:** A provenance record distinguishes observed tests from intended tests.

**Source negative case:** An unexecuted test appears as passed in the statement.

**Source bounded quantities:** Test records and evidence bytes.

### UC-M04.07-C041 · Contract

**Original checklist item:** Specify observed test recording inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C041-T01 · Scope statement:** Draft the operation boundary for “Observed test recording” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Observed test recording”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C041-T03 · Output inventory:** List the outputs of “Observed test recording” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Observed test recording”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C041-T05 · Prerequisite contract:** Map “Observed test recording” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Observed test recording”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C041-T07 · Invariant clause:** Add a normative clause for “Observed test recording” that preserves “A provenance record distinguishes observed tests from intended tests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Observed test recording”; include the source counterexample “An unexecuted test appears as passed in the statement” and the intended safe disposition.
- [ ] **UC-M04.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Test records and evidence bytes” in the “Observed test recording” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C041-T10 · Contract review:** Review the “Observed test recording” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C042 · Delivery

**Original checklist item:** Record executed tests, outcomes and skips without inventing coverage.

- [ ] **UC-M04.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Observed test recording”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C042-T02 · Change plan:** Break the source delivery for “Observed test recording” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C042-T03 · Core artifact:** Create the “Observed test recording” model, schema or inventory that realizes this source instruction: Record executed tests, outcomes and skips without inventing coverage.
- [ ] **UC-M04.07-C042-T04 · Concrete realization:** Populate “Observed test recording” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Observed test recording” needed to preserve “A provenance record distinguishes observed tests from intended tests”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C042-T06 · Dependency connection:** Connect the “Observed test recording” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C042-T07 · Resource behavior:** Account for “Test records and evidence bytes” in “Observed test recording”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C042-T08 · Delivery check:** Run the smallest real “Observed test recording” path and its adverse fixture “An unexecuted test appears as passed in the statement”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C042-T09 · Patch review:** Review the “Observed test recording” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C042-T10 · Delivery handoff:** Publish the “Observed test recording” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A provenance record distinguishes observed tests from intended tests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Observed test recording”; copy its required invariant exactly: “A provenance record distinguishes observed tests from intended tests”.
- [ ] **UC-M04.07-C043-T02 · Observable terms:** Define each term in the “Observed test recording” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C043-T03 · Precondition set:** List the preconditions under which “A provenance record distinguishes observed tests from intended tests” must hold for “Observed test recording”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C043-T04 · Transition coverage:** Map the “Observed test recording” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Observed test recording”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C043-T06 · Satisfying fixture:** Create a concrete “Observed test recording” case that satisfies “A provenance record distinguishes observed tests from intended tests”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C043-T07 · Violating fixture:** Create the source counterexample “An unexecuted test appears as passed in the statement” for “Observed test recording”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C043-T08 · Enforcement evidence:** Exercise the “Observed test recording” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C043-T09 · Regression linkage:** Link the “Observed test recording” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Observed test recording” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C044 · Integration

**Original checklist item:** Integrate observed test recording with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Observed test recording” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C044-T02 · Field mapping:** Map every “Observed test recording” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Observed test recording” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C044-T04 · Ownership agreement:** Specify who owns “Observed test recording” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C044-T05 · Handoff implementation:** Connect “Observed test recording” through the mapped seam using the real adapter or explicit specification reference; preserve “A provenance record distinguishes observed tests from intended tests” across the handoff.
- [ ] **UC-M04.07-C044-T06 · Absent-input case:** Omit one required “Observed test recording” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C044-T07 · Stale-input case:** Supply an outdated “Observed test recording” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Observed test recording” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C044-T09 · Valid integration trace:** Run a valid “Observed test recording” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C044-T10 · Seam review:** Reconcile the “Observed test recording” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for observed test recording; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Observed test recording” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C045-T02 · Expected-result oracle:** Specify the “Observed test recording” expected result independently of the implementation output; include the property “A provenance record distinguishes observed tests from intended tests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C045-T03 · Fixture material:** Create the concrete “Observed test recording” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C045-T04 · Target preparation:** Prepare the “Observed test recording” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C045-T05 · Initial-state record:** Record the initial “Observed test recording” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C045-T06 · Valid-path execution:** Execute the “Observed test recording” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C045-T07 · Outcome comparison:** Compare every declared “Observed test recording” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C045-T08 · State and bounds check:** Inspect the “Observed test recording” ownership/state effects and actual use of “Test records and evidence bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C045-T09 · Repeatability check:** Repeat the same “Observed test recording” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C045-T10 · Positive evidence:** Attach the “Observed test recording” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C046 · Negative test

**Original checklist item:** Negative case: An unexecuted test appears as passed in the statement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Observed test recording” source counterexample: “An unexecuted test appears as passed in the statement”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Observed test recording”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C046-T03 · Valid control:** Construct a valid “Observed test recording” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C046-T04 · Minimal adverse input:** Derive the “Observed test recording” adverse fixture from the control with the smallest documented change needed to reproduce “An unexecuted test appears as passed in the statement”; retain that change as reproducible data.
- [ ] **UC-M04.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Observed test recording”; require “A provenance record distinguishes observed tests from intended tests” and forbid a false-success verdict.
- [ ] **UC-M04.07-C046-T06 · Adverse execution:** Exercise the “Observed test recording” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C046-T07 · Effect inspection:** Inspect “Observed test recording” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C046-T08 · Refusal versus failure:** Confirm the “Observed test recording” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C046-T09 · Reset and retention:** Restore only the disposable “Observed test recording” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C046-T10 · Negative regression:** Register the “Observed test recording” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C047 · Change / failure test

**Original checklist item:** Exercise observed test recording when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C047-T01 · Scenario record:** Write the “Observed test recording” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “A provenance record distinguishes observed tests from intended tests”.
- [ ] **UC-M04.07-C047-T02 · Baseline capture:** Create a known-valid “Observed test recording” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C047-T03 · Injection map:** Locate the “Observed test recording” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Observed test recording” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C047-T05 · Controlled trigger:** Introduce the controlled “Observed test recording” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C047-T06 · Intermediate inspection:** Inspect the “Observed test recording” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Observed test recording”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Observed test recording” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C047-T09 · Repeat and compare:** Repeat the selected “Observed test recording” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C047-T10 · Failure evidence:** Publish the “Observed test recording” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for test records and evidence bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Observed test recording”: “Test records and evidence bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C048-T02 · Measurement method:** Choose how to observe each “Observed test recording” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Observed test recording”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Observed test recording” cases for “Test records and evidence bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Observed test recording” limit; preserve “A provenance record distinguishes observed tests from intended tests”.
- [ ] **UC-M04.07-C048-T06 · Normal measurement:** Run or review the normal “Observed test recording” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C048-T07 · At-limit measurement:** Exercise the “Observed test recording” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C048-T08 · Over-limit measurement:** Exercise the “Observed test recording” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C048-T09 · Uncovered-scope report:** List the “Observed test recording” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C048-T10 · Limit evidence:** Publish the selected “Observed test recording” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for observed test recording with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C049-T01 · Event inventory:** List the “Observed test recording” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Observed test recording” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C049-T03 · Failure mapping:** Map each documented “Observed test recording” refusal or error to a diagnostic outcome; include “An unexecuted test appears as passed in the statement” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C049-T04 · Emission path:** Add the “Observed test recording” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C049-T05 · Redaction check:** Test “Observed test recording” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C049-T06 · Output budget:** Set and exercise bounded “Observed test recording” message size, rate and retention compatible with “Test records and evidence bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C049-T07 · Success/refusal fixtures:** Capture “Observed test recording” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Observed test recording” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C049-T09 · Operator review:** Read the “Observed test recording” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C049-T10 · Diagnostic evidence:** Publish redacted “Observed test recording” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for observed test recording; label unexecuted checks as untested.

- [ ] **UC-M04.07-C050-T01 · Evidence inventory:** List the “Observed test recording” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C050-T02 · Artifact references:** Record the exact “Observed test recording” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C050-T03 · Fixture references:** Attach the “Observed test recording” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unexecuted test appears as passed in the statement” as a distinct evidence case.
- [ ] **UC-M04.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Observed test recording”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C050-T05 · Environment record:** Record the actual “Observed test recording” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C050-T06 · Expected versus observed:** Pair every “Observed test recording” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C050-T07 · Failure and limit records:** Attach “Observed test recording” change/failure and bounds evidence where required; include uncovered “Test records and evidence bytes” and unresolved violations of “A provenance record distinguishes observed tests from intended tests”.
- [ ] **UC-M04.07-C050-T08 · Evidence hygiene:** Check the “Observed test recording” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C050-T09 · Reproduction review:** Have the “Observed test recording” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C050-T10 · Acceptance linkage:** Link the “Observed test recording” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Subject digest verification

**Source delivery:** Verify that the attested subject matches the image presented for admission.

**Source invariant:** An altered image cannot reuse an intact attestation.

**Source negative case:** One byte changes in the attested image.

**Source bounded quantities:** Image bytes and verification time.

### UC-M04.07-C051 · Contract

**Original checklist item:** Specify subject digest verification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C051-T01 · Scope statement:** Draft the operation boundary for “Subject digest verification” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Subject digest verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C051-T03 · Output inventory:** List the outputs of “Subject digest verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Subject digest verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C051-T05 · Prerequisite contract:** Map “Subject digest verification” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Subject digest verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C051-T07 · Invariant clause:** Add a normative clause for “Subject digest verification” that preserves “An altered image cannot reuse an intact attestation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Subject digest verification”; include the source counterexample “One byte changes in the attested image” and the intended safe disposition.
- [ ] **UC-M04.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Image bytes and verification time” in the “Subject digest verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C051-T10 · Contract review:** Review the “Subject digest verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C052 · Delivery

**Original checklist item:** Verify that the attested subject matches the image presented for admission.

- [ ] **UC-M04.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Subject digest verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C052-T02 · Change plan:** Break the source delivery for “Subject digest verification” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C052-T03 · Core artifact:** Create the “Subject digest verification” fixture or harness for this source instruction: Verify that the attested subject matches the image presented for admission.
- [ ] **UC-M04.07-C052-T04 · Concrete realization:** Connect the “Subject digest verification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Subject digest verification” needed to preserve “An altered image cannot reuse an intact attestation”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C052-T06 · Dependency connection:** Connect the “Subject digest verification” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C052-T07 · Resource behavior:** Account for “Image bytes and verification time” in “Subject digest verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C052-T08 · Delivery check:** Run the smallest real “Subject digest verification” path and its adverse fixture “One byte changes in the attested image”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C052-T09 · Patch review:** Review the “Subject digest verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C052-T10 · Delivery handoff:** Publish the “Subject digest verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An altered image cannot reuse an intact attestation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Subject digest verification”; copy its required invariant exactly: “An altered image cannot reuse an intact attestation”.
- [ ] **UC-M04.07-C053-T02 · Observable terms:** Define each term in the “Subject digest verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C053-T03 · Precondition set:** List the preconditions under which “An altered image cannot reuse an intact attestation” must hold for “Subject digest verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C053-T04 · Transition coverage:** Map the “Subject digest verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Subject digest verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C053-T06 · Satisfying fixture:** Create a concrete “Subject digest verification” case that satisfies “An altered image cannot reuse an intact attestation”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C053-T07 · Violating fixture:** Create the source counterexample “One byte changes in the attested image” for “Subject digest verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C053-T08 · Enforcement evidence:** Exercise the “Subject digest verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C053-T09 · Regression linkage:** Link the “Subject digest verification” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Subject digest verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C054 · Integration

**Original checklist item:** Integrate subject digest verification with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Subject digest verification” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C054-T02 · Field mapping:** Map every “Subject digest verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Subject digest verification” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C054-T04 · Ownership agreement:** Specify who owns “Subject digest verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C054-T05 · Handoff implementation:** Connect “Subject digest verification” through the mapped seam using the real adapter or explicit specification reference; preserve “An altered image cannot reuse an intact attestation” across the handoff.
- [ ] **UC-M04.07-C054-T06 · Absent-input case:** Omit one required “Subject digest verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C054-T07 · Stale-input case:** Supply an outdated “Subject digest verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Subject digest verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C054-T09 · Valid integration trace:** Run a valid “Subject digest verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C054-T10 · Seam review:** Reconcile the “Subject digest verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for subject digest verification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Subject digest verification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C055-T02 · Expected-result oracle:** Specify the “Subject digest verification” expected result independently of the implementation output; include the property “An altered image cannot reuse an intact attestation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C055-T03 · Fixture material:** Create the concrete “Subject digest verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C055-T04 · Target preparation:** Prepare the “Subject digest verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C055-T05 · Initial-state record:** Record the initial “Subject digest verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C055-T06 · Valid-path execution:** Execute the “Subject digest verification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C055-T07 · Outcome comparison:** Compare every declared “Subject digest verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C055-T08 · State and bounds check:** Inspect the “Subject digest verification” ownership/state effects and actual use of “Image bytes and verification time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C055-T09 · Repeatability check:** Repeat the same “Subject digest verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C055-T10 · Positive evidence:** Attach the “Subject digest verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C056 · Negative test

**Original checklist item:** Negative case: One byte changes in the attested image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Subject digest verification” source counterexample: “One byte changes in the attested image”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Subject digest verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C056-T03 · Valid control:** Construct a valid “Subject digest verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C056-T04 · Minimal adverse input:** Derive the “Subject digest verification” adverse fixture from the control with the smallest documented change needed to reproduce “One byte changes in the attested image”; retain that change as reproducible data.
- [ ] **UC-M04.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Subject digest verification”; require “An altered image cannot reuse an intact attestation” and forbid a false-success verdict.
- [ ] **UC-M04.07-C056-T06 · Adverse execution:** Exercise the “Subject digest verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C056-T07 · Effect inspection:** Inspect “Subject digest verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C056-T08 · Refusal versus failure:** Confirm the “Subject digest verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C056-T09 · Reset and retention:** Restore only the disposable “Subject digest verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C056-T10 · Negative regression:** Register the “Subject digest verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C057 · Change / failure test

**Original checklist item:** Exercise subject digest verification when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C057-T01 · Scenario record:** Write the “Subject digest verification” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “An altered image cannot reuse an intact attestation”.
- [ ] **UC-M04.07-C057-T02 · Baseline capture:** Create a known-valid “Subject digest verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C057-T03 · Injection map:** Locate the “Subject digest verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Subject digest verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C057-T05 · Controlled trigger:** Introduce the controlled “Subject digest verification” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C057-T06 · Intermediate inspection:** Inspect the “Subject digest verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Subject digest verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Subject digest verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C057-T09 · Repeat and compare:** Repeat the selected “Subject digest verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C057-T10 · Failure evidence:** Publish the “Subject digest verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for image bytes and verification time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Subject digest verification”: “Image bytes and verification time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C058-T02 · Measurement method:** Choose how to observe each “Subject digest verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C058-T03 · Budget decision:** Select justified resource and input limits for “Subject digest verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Subject digest verification” cases for “Image bytes and verification time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Subject digest verification” limit; preserve “An altered image cannot reuse an intact attestation”.
- [ ] **UC-M04.07-C058-T06 · Normal measurement:** Run or review the normal “Subject digest verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C058-T07 · At-limit measurement:** Exercise the “Subject digest verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C058-T08 · Over-limit measurement:** Exercise the “Subject digest verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C058-T09 · Uncovered-scope report:** List the “Subject digest verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C058-T10 · Limit evidence:** Publish the selected “Subject digest verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for subject digest verification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C059-T01 · Event inventory:** List the “Subject digest verification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Subject digest verification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C059-T03 · Failure mapping:** Map each documented “Subject digest verification” refusal or error to a diagnostic outcome; include “One byte changes in the attested image” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C059-T04 · Emission path:** Add the “Subject digest verification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C059-T05 · Redaction check:** Test “Subject digest verification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C059-T06 · Output budget:** Set and exercise bounded “Subject digest verification” message size, rate and retention compatible with “Image bytes and verification time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C059-T07 · Success/refusal fixtures:** Capture “Subject digest verification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Subject digest verification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C059-T09 · Operator review:** Read the “Subject digest verification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C059-T10 · Diagnostic evidence:** Publish redacted “Subject digest verification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for subject digest verification; label unexecuted checks as untested.

- [ ] **UC-M04.07-C060-T01 · Evidence inventory:** List the “Subject digest verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C060-T02 · Artifact references:** Record the exact “Subject digest verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C060-T03 · Fixture references:** Attach the “Subject digest verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “One byte changes in the attested image” as a distinct evidence case.
- [ ] **UC-M04.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Subject digest verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C060-T05 · Environment record:** Record the actual “Subject digest verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C060-T06 · Expected versus observed:** Pair every “Subject digest verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C060-T07 · Failure and limit records:** Attach “Subject digest verification” change/failure and bounds evidence where required; include uncovered “Image bytes and verification time” and unresolved violations of “An altered image cannot reuse an intact attestation”.
- [ ] **UC-M04.07-C060-T08 · Evidence hygiene:** Check the “Subject digest verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C060-T09 · Reproduction review:** Have the “Subject digest verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C060-T10 · Acceptance linkage:** Link the “Subject digest verification” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Statement authentication

**Source delivery:** Authenticate statements using the selected approved trust policy.

**Source invariant:** Statement integrity alone does not establish an authorized builder.

**Source negative case:** A well-formed statement is signed by an unapproved key.

**Source bounded quantities:** Signatures and verification budget.

### UC-M04.07-C061 · Contract

**Original checklist item:** Specify statement authentication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C061-T01 · Scope statement:** Draft the operation boundary for “Statement authentication” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Statement authentication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C061-T03 · Output inventory:** List the outputs of “Statement authentication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Statement authentication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C061-T05 · Prerequisite contract:** Map “Statement authentication” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Statement authentication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C061-T07 · Invariant clause:** Add a normative clause for “Statement authentication” that preserves “Statement integrity alone does not establish an authorized builder”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Statement authentication”; include the source counterexample “A well-formed statement is signed by an unapproved key” and the intended safe disposition.
- [ ] **UC-M04.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Signatures and verification budget” in the “Statement authentication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C061-T10 · Contract review:** Review the “Statement authentication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C062 · Delivery

**Original checklist item:** Authenticate statements using the selected approved trust policy.

- [ ] **UC-M04.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Statement authentication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C062-T02 · Change plan:** Break the source delivery for “Statement authentication” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Statement authentication” that realizes this source instruction: Authenticate statements using the selected approved trust policy.
- [ ] **UC-M04.07-C062-T04 · Concrete realization:** Trace “Statement authentication” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Statement authentication” needed to preserve “Statement integrity alone does not establish an authorized builder”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C062-T06 · Dependency connection:** Connect the “Statement authentication” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C062-T07 · Resource behavior:** Account for “Signatures and verification budget” in “Statement authentication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C062-T08 · Delivery check:** Run the smallest real “Statement authentication” path and its adverse fixture “A well-formed statement is signed by an unapproved key”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C062-T09 · Patch review:** Review the “Statement authentication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C062-T10 · Delivery handoff:** Publish the “Statement authentication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Statement integrity alone does not establish an authorized builder. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Statement authentication”; copy its required invariant exactly: “Statement integrity alone does not establish an authorized builder”.
- [ ] **UC-M04.07-C063-T02 · Observable terms:** Define each term in the “Statement authentication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C063-T03 · Precondition set:** List the preconditions under which “Statement integrity alone does not establish an authorized builder” must hold for “Statement authentication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C063-T04 · Transition coverage:** Map the “Statement authentication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Statement authentication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C063-T06 · Satisfying fixture:** Create a concrete “Statement authentication” case that satisfies “Statement integrity alone does not establish an authorized builder”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C063-T07 · Violating fixture:** Create the source counterexample “A well-formed statement is signed by an unapproved key” for “Statement authentication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C063-T08 · Enforcement evidence:** Exercise the “Statement authentication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C063-T09 · Regression linkage:** Link the “Statement authentication” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Statement authentication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C064 · Integration

**Original checklist item:** Integrate statement authentication with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Statement authentication” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C064-T02 · Field mapping:** Map every “Statement authentication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Statement authentication” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C064-T04 · Ownership agreement:** Specify who owns “Statement authentication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C064-T05 · Handoff implementation:** Connect “Statement authentication” through the mapped seam using the real adapter or explicit specification reference; preserve “Statement integrity alone does not establish an authorized builder” across the handoff.
- [ ] **UC-M04.07-C064-T06 · Absent-input case:** Omit one required “Statement authentication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C064-T07 · Stale-input case:** Supply an outdated “Statement authentication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Statement authentication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C064-T09 · Valid integration trace:** Run a valid “Statement authentication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C064-T10 · Seam review:** Reconcile the “Statement authentication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for statement authentication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Statement authentication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C065-T02 · Expected-result oracle:** Specify the “Statement authentication” expected result independently of the implementation output; include the property “Statement integrity alone does not establish an authorized builder” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C065-T03 · Fixture material:** Create the concrete “Statement authentication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C065-T04 · Target preparation:** Prepare the “Statement authentication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C065-T05 · Initial-state record:** Record the initial “Statement authentication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C065-T06 · Valid-path execution:** Execute the “Statement authentication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C065-T07 · Outcome comparison:** Compare every declared “Statement authentication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C065-T08 · State and bounds check:** Inspect the “Statement authentication” ownership/state effects and actual use of “Signatures and verification budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C065-T09 · Repeatability check:** Repeat the same “Statement authentication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C065-T10 · Positive evidence:** Attach the “Statement authentication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C066 · Negative test

**Original checklist item:** Negative case: A well-formed statement is signed by an unapproved key. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Statement authentication” source counterexample: “A well-formed statement is signed by an unapproved key”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Statement authentication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C066-T03 · Valid control:** Construct a valid “Statement authentication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C066-T04 · Minimal adverse input:** Derive the “Statement authentication” adverse fixture from the control with the smallest documented change needed to reproduce “A well-formed statement is signed by an unapproved key”; retain that change as reproducible data.
- [ ] **UC-M04.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Statement authentication”; require “Statement integrity alone does not establish an authorized builder” and forbid a false-success verdict.
- [ ] **UC-M04.07-C066-T06 · Adverse execution:** Exercise the “Statement authentication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C066-T07 · Effect inspection:** Inspect “Statement authentication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C066-T08 · Refusal versus failure:** Confirm the “Statement authentication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C066-T09 · Reset and retention:** Restore only the disposable “Statement authentication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C066-T10 · Negative regression:** Register the “Statement authentication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C067 · Change / failure test

**Original checklist item:** Exercise statement authentication when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C067-T01 · Scenario record:** Write the “Statement authentication” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “Statement integrity alone does not establish an authorized builder”.
- [ ] **UC-M04.07-C067-T02 · Baseline capture:** Create a known-valid “Statement authentication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C067-T03 · Injection map:** Locate the “Statement authentication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Statement authentication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C067-T05 · Controlled trigger:** Introduce the controlled “Statement authentication” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C067-T06 · Intermediate inspection:** Inspect the “Statement authentication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Statement authentication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Statement authentication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C067-T09 · Repeat and compare:** Repeat the selected “Statement authentication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C067-T10 · Failure evidence:** Publish the “Statement authentication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for signatures and verification budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Statement authentication”: “Signatures and verification budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C068-T02 · Measurement method:** Choose how to observe each “Statement authentication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Statement authentication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Statement authentication” cases for “Signatures and verification budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Statement authentication” limit; preserve “Statement integrity alone does not establish an authorized builder”.
- [ ] **UC-M04.07-C068-T06 · Normal measurement:** Run or review the normal “Statement authentication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C068-T07 · At-limit measurement:** Exercise the “Statement authentication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C068-T08 · Over-limit measurement:** Exercise the “Statement authentication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C068-T09 · Uncovered-scope report:** List the “Statement authentication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C068-T10 · Limit evidence:** Publish the selected “Statement authentication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for statement authentication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C069-T01 · Event inventory:** List the “Statement authentication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Statement authentication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C069-T03 · Failure mapping:** Map each documented “Statement authentication” refusal or error to a diagnostic outcome; include “A well-formed statement is signed by an unapproved key” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C069-T04 · Emission path:** Add the “Statement authentication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C069-T05 · Redaction check:** Test “Statement authentication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C069-T06 · Output budget:** Set and exercise bounded “Statement authentication” message size, rate and retention compatible with “Signatures and verification budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C069-T07 · Success/refusal fixtures:** Capture “Statement authentication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Statement authentication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C069-T09 · Operator review:** Read the “Statement authentication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C069-T10 · Diagnostic evidence:** Publish redacted “Statement authentication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for statement authentication; label unexecuted checks as untested.

- [ ] **UC-M04.07-C070-T01 · Evidence inventory:** List the “Statement authentication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C070-T02 · Artifact references:** Record the exact “Statement authentication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C070-T03 · Fixture references:** Attach the “Statement authentication” fixture IDs, input identities and oracle definition; preserve the source counterexample “A well-formed statement is signed by an unapproved key” as a distinct evidence case.
- [ ] **UC-M04.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Statement authentication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C070-T05 · Environment record:** Record the actual “Statement authentication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C070-T06 · Expected versus observed:** Pair every “Statement authentication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C070-T07 · Failure and limit records:** Attach “Statement authentication” change/failure and bounds evidence where required; include uncovered “Signatures and verification budget” and unresolved violations of “Statement integrity alone does not establish an authorized builder”.
- [ ] **UC-M04.07-C070-T08 · Evidence hygiene:** Check the “Statement authentication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C070-T09 · Reproduction review:** Have the “Statement authentication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C070-T10 · Acceptance linkage:** Link the “Statement authentication” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Independent verifier

**Source delivery:** Implement a verifier separate from the producer's success report.

**Source invariant:** The verifier rejects altered subjects, missing materials and unknown builders.

**Source negative case:** The producer's own pass flag bypasses verification.

**Source bounded quantities:** Statement count and reconstruction depth.

### UC-M04.07-C071 · Contract

**Original checklist item:** Specify independent verifier inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C071-T01 · Scope statement:** Draft the operation boundary for “Independent verifier” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Independent verifier”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C071-T03 · Output inventory:** List the outputs of “Independent verifier” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Independent verifier”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C071-T05 · Prerequisite contract:** Map “Independent verifier” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Independent verifier”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C071-T07 · Invariant clause:** Add a normative clause for “Independent verifier” that preserves “The verifier rejects altered subjects, missing materials and unknown builders”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Independent verifier”; include the source counterexample “The producer's own pass flag bypasses verification” and the intended safe disposition.
- [ ] **UC-M04.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Statement count and reconstruction depth” in the “Independent verifier” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C071-T10 · Contract review:** Review the “Independent verifier” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C072 · Delivery

**Original checklist item:** Implement a verifier separate from the producer's success report.

- [ ] **UC-M04.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Independent verifier”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C072-T02 · Change plan:** Break the source delivery for “Independent verifier” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Independent verifier” that realizes this source instruction: Implement a verifier separate from the producer's success report.
- [ ] **UC-M04.07-C072-T04 · Concrete realization:** Trace “Independent verifier” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Independent verifier” needed to preserve “The verifier rejects altered subjects, missing materials and unknown builders”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C072-T06 · Dependency connection:** Connect the “Independent verifier” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C072-T07 · Resource behavior:** Account for “Statement count and reconstruction depth” in “Independent verifier”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C072-T08 · Delivery check:** Run the smallest real “Independent verifier” path and its adverse fixture “The producer's own pass flag bypasses verification”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C072-T09 · Patch review:** Review the “Independent verifier” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C072-T10 · Delivery handoff:** Publish the “Independent verifier” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The verifier rejects altered subjects, missing materials and unknown builders. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Independent verifier”; copy its required invariant exactly: “The verifier rejects altered subjects, missing materials and unknown builders”.
- [ ] **UC-M04.07-C073-T02 · Observable terms:** Define each term in the “Independent verifier” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C073-T03 · Precondition set:** List the preconditions under which “The verifier rejects altered subjects, missing materials and unknown builders” must hold for “Independent verifier”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C073-T04 · Transition coverage:** Map the “Independent verifier” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Independent verifier”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C073-T06 · Satisfying fixture:** Create a concrete “Independent verifier” case that satisfies “The verifier rejects altered subjects, missing materials and unknown builders”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C073-T07 · Violating fixture:** Create the source counterexample “The producer's own pass flag bypasses verification” for “Independent verifier”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C073-T08 · Enforcement evidence:** Exercise the “Independent verifier” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C073-T09 · Regression linkage:** Link the “Independent verifier” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Independent verifier” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C074 · Integration

**Original checklist item:** Integrate independent verifier with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Independent verifier” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C074-T02 · Field mapping:** Map every “Independent verifier” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Independent verifier” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C074-T04 · Ownership agreement:** Specify who owns “Independent verifier” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C074-T05 · Handoff implementation:** Connect “Independent verifier” through the mapped seam using the real adapter or explicit specification reference; preserve “The verifier rejects altered subjects, missing materials and unknown builders” across the handoff.
- [ ] **UC-M04.07-C074-T06 · Absent-input case:** Omit one required “Independent verifier” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C074-T07 · Stale-input case:** Supply an outdated “Independent verifier” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Independent verifier” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C074-T09 · Valid integration trace:** Run a valid “Independent verifier” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C074-T10 · Seam review:** Reconcile the “Independent verifier” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for independent verifier; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Independent verifier” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C075-T02 · Expected-result oracle:** Specify the “Independent verifier” expected result independently of the implementation output; include the property “The verifier rejects altered subjects, missing materials and unknown builders” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C075-T03 · Fixture material:** Create the concrete “Independent verifier” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C075-T04 · Target preparation:** Prepare the “Independent verifier” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C075-T05 · Initial-state record:** Record the initial “Independent verifier” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C075-T06 · Valid-path execution:** Execute the “Independent verifier” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C075-T07 · Outcome comparison:** Compare every declared “Independent verifier” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C075-T08 · State and bounds check:** Inspect the “Independent verifier” ownership/state effects and actual use of “Statement count and reconstruction depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C075-T09 · Repeatability check:** Repeat the same “Independent verifier” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C075-T10 · Positive evidence:** Attach the “Independent verifier” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C076 · Negative test

**Original checklist item:** Negative case: The producer's own pass flag bypasses verification. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Independent verifier” source counterexample: “The producer's own pass flag bypasses verification”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Independent verifier”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C076-T03 · Valid control:** Construct a valid “Independent verifier” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C076-T04 · Minimal adverse input:** Derive the “Independent verifier” adverse fixture from the control with the smallest documented change needed to reproduce “The producer's own pass flag bypasses verification”; retain that change as reproducible data.
- [ ] **UC-M04.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Independent verifier”; require “The verifier rejects altered subjects, missing materials and unknown builders” and forbid a false-success verdict.
- [ ] **UC-M04.07-C076-T06 · Adverse execution:** Exercise the “Independent verifier” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C076-T07 · Effect inspection:** Inspect “Independent verifier” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C076-T08 · Refusal versus failure:** Confirm the “Independent verifier” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C076-T09 · Reset and retention:** Restore only the disposable “Independent verifier” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C076-T10 · Negative regression:** Register the “Independent verifier” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C077 · Change / failure test

**Original checklist item:** Exercise independent verifier when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C077-T01 · Scenario record:** Write the “Independent verifier” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “The verifier rejects altered subjects, missing materials and unknown builders”.
- [ ] **UC-M04.07-C077-T02 · Baseline capture:** Create a known-valid “Independent verifier” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C077-T03 · Injection map:** Locate the “Independent verifier” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Independent verifier” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C077-T05 · Controlled trigger:** Introduce the controlled “Independent verifier” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C077-T06 · Intermediate inspection:** Inspect the “Independent verifier” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Independent verifier”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Independent verifier” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C077-T09 · Repeat and compare:** Repeat the selected “Independent verifier” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C077-T10 · Failure evidence:** Publish the “Independent verifier” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for statement count and reconstruction depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Independent verifier”: “Statement count and reconstruction depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C078-T02 · Measurement method:** Choose how to observe each “Independent verifier” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Independent verifier”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Independent verifier” cases for “Statement count and reconstruction depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Independent verifier” limit; preserve “The verifier rejects altered subjects, missing materials and unknown builders”.
- [ ] **UC-M04.07-C078-T06 · Normal measurement:** Run or review the normal “Independent verifier” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C078-T07 · At-limit measurement:** Exercise the “Independent verifier” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C078-T08 · Over-limit measurement:** Exercise the “Independent verifier” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C078-T09 · Uncovered-scope report:** List the “Independent verifier” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C078-T10 · Limit evidence:** Publish the selected “Independent verifier” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for independent verifier with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C079-T01 · Event inventory:** List the “Independent verifier” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Independent verifier” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C079-T03 · Failure mapping:** Map each documented “Independent verifier” refusal or error to a diagnostic outcome; include “The producer's own pass flag bypasses verification” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C079-T04 · Emission path:** Add the “Independent verifier” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C079-T05 · Redaction check:** Test “Independent verifier” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C079-T06 · Output budget:** Set and exercise bounded “Independent verifier” message size, rate and retention compatible with “Statement count and reconstruction depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C079-T07 · Success/refusal fixtures:** Capture “Independent verifier” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Independent verifier” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C079-T09 · Operator review:** Read the “Independent verifier” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C079-T10 · Diagnostic evidence:** Publish redacted “Independent verifier” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for independent verifier; label unexecuted checks as untested.

- [ ] **UC-M04.07-C080-T01 · Evidence inventory:** List the “Independent verifier” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C080-T02 · Artifact references:** Record the exact “Independent verifier” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C080-T03 · Fixture references:** Attach the “Independent verifier” fixture IDs, input identities and oracle definition; preserve the source counterexample “The producer's own pass flag bypasses verification” as a distinct evidence case.
- [ ] **UC-M04.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Independent verifier”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C080-T05 · Environment record:** Record the actual “Independent verifier” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C080-T06 · Expected versus observed:** Pair every “Independent verifier” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C080-T07 · Failure and limit records:** Attach “Independent verifier” change/failure and bounds evidence where required; include uncovered “Statement count and reconstruction depth” and unresolved violations of “The verifier rejects altered subjects, missing materials and unknown builders”.
- [ ] **UC-M04.07-C080-T08 · Evidence hygiene:** Check the “Independent verifier” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C080-T09 · Reproduction review:** Have the “Independent verifier” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C080-T10 · Acceptance linkage:** Link the “Independent verifier” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Assurance claim boundaries

**Source delivery:** Describe adopted provenance concepts without claiming an unassessed assurance level.

**Source invariant:** Evidence scope determines the claim rather than a framework label.

**Source negative case:** A release claims a standards level without its required assessment.

**Source bounded quantities:** Claim count and review frequency.

### UC-M04.07-C081 · Contract

**Original checklist item:** Specify assurance claim boundaries inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C081-T01 · Scope statement:** Draft the operation boundary for “Assurance claim boundaries” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Assurance claim boundaries”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C081-T03 · Output inventory:** List the outputs of “Assurance claim boundaries” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Assurance claim boundaries”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C081-T05 · Prerequisite contract:** Map “Assurance claim boundaries” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Assurance claim boundaries”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C081-T07 · Invariant clause:** Add a normative clause for “Assurance claim boundaries” that preserves “Evidence scope determines the claim rather than a framework label”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Assurance claim boundaries”; include the source counterexample “A release claims a standards level without its required assessment” and the intended safe disposition.
- [ ] **UC-M04.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Claim count and review frequency” in the “Assurance claim boundaries” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C081-T10 · Contract review:** Review the “Assurance claim boundaries” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C082 · Delivery

**Original checklist item:** Describe adopted provenance concepts without claiming an unassessed assurance level.

- [ ] **UC-M04.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Assurance claim boundaries”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C082-T02 · Change plan:** Break the source delivery for “Assurance claim boundaries” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C082-T03 · Core artifact:** Create the “Assurance claim boundaries” model, schema or inventory that realizes this source instruction: Describe adopted provenance concepts without claiming an unassessed assurance level.
- [ ] **UC-M04.07-C082-T04 · Concrete realization:** Populate “Assurance claim boundaries” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M04.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Assurance claim boundaries” needed to preserve “Evidence scope determines the claim rather than a framework label”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C082-T06 · Dependency connection:** Connect the “Assurance claim boundaries” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C082-T07 · Resource behavior:** Account for “Claim count and review frequency” in “Assurance claim boundaries”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C082-T08 · Delivery check:** Run the smallest real “Assurance claim boundaries” path and its adverse fixture “A release claims a standards level without its required assessment”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C082-T09 · Patch review:** Review the “Assurance claim boundaries” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C082-T10 · Delivery handoff:** Publish the “Assurance claim boundaries” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Evidence scope determines the claim rather than a framework label. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Assurance claim boundaries”; copy its required invariant exactly: “Evidence scope determines the claim rather than a framework label”.
- [ ] **UC-M04.07-C083-T02 · Observable terms:** Define each term in the “Assurance claim boundaries” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C083-T03 · Precondition set:** List the preconditions under which “Evidence scope determines the claim rather than a framework label” must hold for “Assurance claim boundaries”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C083-T04 · Transition coverage:** Map the “Assurance claim boundaries” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Assurance claim boundaries”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C083-T06 · Satisfying fixture:** Create a concrete “Assurance claim boundaries” case that satisfies “Evidence scope determines the claim rather than a framework label”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C083-T07 · Violating fixture:** Create the source counterexample “A release claims a standards level without its required assessment” for “Assurance claim boundaries”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C083-T08 · Enforcement evidence:** Exercise the “Assurance claim boundaries” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C083-T09 · Regression linkage:** Link the “Assurance claim boundaries” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Assurance claim boundaries” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C084 · Integration

**Original checklist item:** Integrate assurance claim boundaries with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Assurance claim boundaries” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C084-T02 · Field mapping:** Map every “Assurance claim boundaries” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Assurance claim boundaries” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C084-T04 · Ownership agreement:** Specify who owns “Assurance claim boundaries” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C084-T05 · Handoff implementation:** Connect “Assurance claim boundaries” through the mapped seam using the real adapter or explicit specification reference; preserve “Evidence scope determines the claim rather than a framework label” across the handoff.
- [ ] **UC-M04.07-C084-T06 · Absent-input case:** Omit one required “Assurance claim boundaries” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C084-T07 · Stale-input case:** Supply an outdated “Assurance claim boundaries” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Assurance claim boundaries” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C084-T09 · Valid integration trace:** Run a valid “Assurance claim boundaries” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C084-T10 · Seam review:** Reconcile the “Assurance claim boundaries” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for assurance claim boundaries; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Assurance claim boundaries” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C085-T02 · Expected-result oracle:** Specify the “Assurance claim boundaries” expected result independently of the implementation output; include the property “Evidence scope determines the claim rather than a framework label” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C085-T03 · Fixture material:** Create the concrete “Assurance claim boundaries” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C085-T04 · Target preparation:** Prepare the “Assurance claim boundaries” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C085-T05 · Initial-state record:** Record the initial “Assurance claim boundaries” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C085-T06 · Valid-path execution:** Execute the “Assurance claim boundaries” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C085-T07 · Outcome comparison:** Compare every declared “Assurance claim boundaries” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C085-T08 · State and bounds check:** Inspect the “Assurance claim boundaries” ownership/state effects and actual use of “Claim count and review frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C085-T09 · Repeatability check:** Repeat the same “Assurance claim boundaries” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C085-T10 · Positive evidence:** Attach the “Assurance claim boundaries” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C086 · Negative test

**Original checklist item:** Negative case: A release claims a standards level without its required assessment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Assurance claim boundaries” source counterexample: “A release claims a standards level without its required assessment”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Assurance claim boundaries”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C086-T03 · Valid control:** Construct a valid “Assurance claim boundaries” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C086-T04 · Minimal adverse input:** Derive the “Assurance claim boundaries” adverse fixture from the control with the smallest documented change needed to reproduce “A release claims a standards level without its required assessment”; retain that change as reproducible data.
- [ ] **UC-M04.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Assurance claim boundaries”; require “Evidence scope determines the claim rather than a framework label” and forbid a false-success verdict.
- [ ] **UC-M04.07-C086-T06 · Adverse execution:** Exercise the “Assurance claim boundaries” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C086-T07 · Effect inspection:** Inspect “Assurance claim boundaries” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C086-T08 · Refusal versus failure:** Confirm the “Assurance claim boundaries” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C086-T09 · Reset and retention:** Restore only the disposable “Assurance claim boundaries” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C086-T10 · Negative regression:** Register the “Assurance claim boundaries” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C087 · Change / failure test

**Original checklist item:** Exercise assurance claim boundaries when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C087-T01 · Scenario record:** Write the “Assurance claim boundaries” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “Evidence scope determines the claim rather than a framework label”.
- [ ] **UC-M04.07-C087-T02 · Baseline capture:** Create a known-valid “Assurance claim boundaries” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C087-T03 · Injection map:** Locate the “Assurance claim boundaries” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Assurance claim boundaries” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C087-T05 · Controlled trigger:** Introduce the controlled “Assurance claim boundaries” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C087-T06 · Intermediate inspection:** Inspect the “Assurance claim boundaries” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Assurance claim boundaries”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Assurance claim boundaries” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C087-T09 · Repeat and compare:** Repeat the selected “Assurance claim boundaries” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C087-T10 · Failure evidence:** Publish the “Assurance claim boundaries” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for claim count and review frequency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Assurance claim boundaries”: “Claim count and review frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C088-T02 · Measurement method:** Choose how to observe each “Assurance claim boundaries” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C088-T03 · Budget decision:** Select justified resource and input limits for “Assurance claim boundaries”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Assurance claim boundaries” cases for “Claim count and review frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Assurance claim boundaries” limit; preserve “Evidence scope determines the claim rather than a framework label”.
- [ ] **UC-M04.07-C088-T06 · Normal measurement:** Run or review the normal “Assurance claim boundaries” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C088-T07 · At-limit measurement:** Exercise the “Assurance claim boundaries” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C088-T08 · Over-limit measurement:** Exercise the “Assurance claim boundaries” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C088-T09 · Uncovered-scope report:** List the “Assurance claim boundaries” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C088-T10 · Limit evidence:** Publish the selected “Assurance claim boundaries” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for assurance claim boundaries with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C089-T01 · Event inventory:** List the “Assurance claim boundaries” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Assurance claim boundaries” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C089-T03 · Failure mapping:** Map each documented “Assurance claim boundaries” refusal or error to a diagnostic outcome; include “A release claims a standards level without its required assessment” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C089-T04 · Emission path:** Add the “Assurance claim boundaries” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C089-T05 · Redaction check:** Test “Assurance claim boundaries” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C089-T06 · Output budget:** Set and exercise bounded “Assurance claim boundaries” message size, rate and retention compatible with “Claim count and review frequency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C089-T07 · Success/refusal fixtures:** Capture “Assurance claim boundaries” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Assurance claim boundaries” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C089-T09 · Operator review:** Read the “Assurance claim boundaries” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C089-T10 · Diagnostic evidence:** Publish redacted “Assurance claim boundaries” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for assurance claim boundaries; label unexecuted checks as untested.

- [ ] **UC-M04.07-C090-T01 · Evidence inventory:** List the “Assurance claim boundaries” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C090-T02 · Artifact references:** Record the exact “Assurance claim boundaries” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C090-T03 · Fixture references:** Attach the “Assurance claim boundaries” fixture IDs, input identities and oracle definition; preserve the source counterexample “A release claims a standards level without its required assessment” as a distinct evidence case.
- [ ] **UC-M04.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Assurance claim boundaries”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C090-T05 · Environment record:** Record the actual “Assurance claim boundaries” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C090-T06 · Expected versus observed:** Pair every “Assurance claim boundaries” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C090-T07 · Failure and limit records:** Attach “Assurance claim boundaries” change/failure and bounds evidence where required; include uncovered “Claim count and review frequency” and unresolved violations of “Evidence scope determines the claim rather than a framework label”.
- [ ] **UC-M04.07-C090-T08 · Evidence hygiene:** Check the “Assurance claim boundaries” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C090-T09 · Reproduction review:** Have the “Assurance claim boundaries” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C090-T10 · Acceptance linkage:** Link the “Assurance claim boundaries” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Provenance retention

**Source delivery:** Retain immutable provenance and verification results with release identities.

**Source invariant:** Old provenance remains attributable to its original build.

**Source negative case:** A mutable workspace edit rewrites historical build relationships.

**Source bounded quantities:** Retained statements and storage budget.

### UC-M04.07-C091 · Contract

**Original checklist item:** Specify provenance retention inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.07-C091-T01 · Scope statement:** Draft the operation boundary for “Provenance retention” within Build provenance attestations; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Provenance retention”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.07-C091-T03 · Output inventory:** List the outputs of “Provenance retention” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Provenance retention”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.07-C091-T05 · Prerequisite contract:** Map “Provenance retention” to the source component prerequisites (UC-M04.02, UC-M04.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Provenance retention”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.07-C091-T07 · Invariant clause:** Add a normative clause for “Provenance retention” that preserves “Old provenance remains attributable to its original build”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Provenance retention”; include the source counterexample “A mutable workspace edit rewrites historical build relationships” and the intended safe disposition.
- [ ] **UC-M04.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained statements and storage budget” in the “Provenance retention” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.07-C091-T10 · Contract review:** Review the “Provenance retention” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.07-C092 · Delivery

**Original checklist item:** Retain immutable provenance and verification results with release identities.

- [ ] **UC-M04.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Provenance retention”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.07-C092-T02 · Change plan:** Break the source delivery for “Provenance retention” into concrete edit targets and reviewable outputs; keep the UC-M04.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.07-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Provenance retention” that realizes this source instruction: Retain immutable provenance and verification results with release identities.
- [ ] **UC-M04.07-C092-T04 · Concrete realization:** Trace “Provenance retention” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Provenance retention” needed to preserve “Old provenance remains attributable to its original build”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.07-C092-T06 · Dependency connection:** Connect the “Provenance retention” implementation to the build graph, builder identity, statement authentication and independent verification; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.07-C092-T07 · Resource behavior:** Account for “Retained statements and storage budget” in “Provenance retention”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.07-C092-T08 · Delivery check:** Run the smallest real “Provenance retention” path and its adverse fixture “A mutable workspace edit rewrites historical build relationships”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.07-C092-T09 · Patch review:** Review the “Provenance retention” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.07-C092-T10 · Delivery handoff:** Publish the “Provenance retention” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Old provenance remains attributable to its original build. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Provenance retention”; copy its required invariant exactly: “Old provenance remains attributable to its original build”.
- [ ] **UC-M04.07-C093-T02 · Observable terms:** Define each term in the “Provenance retention” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.07-C093-T03 · Precondition set:** List the preconditions under which “Old provenance remains attributable to its original build” must hold for “Provenance retention”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.07-C093-T04 · Transition coverage:** Map the “Provenance retention” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Provenance retention”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.07-C093-T06 · Satisfying fixture:** Create a concrete “Provenance retention” case that satisfies “Old provenance remains attributable to its original build”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.07-C093-T07 · Violating fixture:** Create the source counterexample “A mutable workspace edit rewrites historical build relationships” for “Provenance retention”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.07-C093-T08 · Enforcement evidence:** Exercise the “Provenance retention” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.07-C093-T09 · Regression linkage:** Link the “Provenance retention” property to changes in the build graph, builder identity, statement authentication and independent verification; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Provenance retention” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.07-C094 · Integration

**Original checklist item:** Integrate provenance retention with the build graph, builder identity, statement authentication and independent verification; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Provenance retention” across the build graph, builder identity, statement authentication and independent verification; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.07-C094-T02 · Field mapping:** Map every “Provenance retention” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Provenance retention” (source dependency list: UC-M04.02, UC-M04.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.07-C094-T04 · Ownership agreement:** Specify who owns “Provenance retention” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.07-C094-T05 · Handoff implementation:** Connect “Provenance retention” through the mapped seam using the real adapter or explicit specification reference; preserve “Old provenance remains attributable to its original build” across the handoff.
- [ ] **UC-M04.07-C094-T06 · Absent-input case:** Omit one required “Provenance retention” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.07-C094-T07 · Stale-input case:** Supply an outdated “Provenance retention” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Provenance retention” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.07-C094-T09 · Valid integration trace:** Run a valid “Provenance retention” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.07-C094-T10 · Seam review:** Reconcile the “Provenance retention” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for provenance retention; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Provenance retention” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.07-C095-T02 · Expected-result oracle:** Specify the “Provenance retention” expected result independently of the implementation output; include the property “Old provenance remains attributable to its original build” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.07-C095-T03 · Fixture material:** Create the concrete “Provenance retention” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.07-C095-T04 · Target preparation:** Prepare the “Provenance retention” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.07-C095-T05 · Initial-state record:** Record the initial “Provenance retention” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.07-C095-T06 · Valid-path execution:** Execute the “Provenance retention” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.07-C095-T07 · Outcome comparison:** Compare every declared “Provenance retention” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.07-C095-T08 · State and bounds check:** Inspect the “Provenance retention” ownership/state effects and actual use of “Retained statements and storage budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.07-C095-T09 · Repeatability check:** Repeat the same “Provenance retention” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.07-C095-T10 · Positive evidence:** Attach the “Provenance retention” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.07-C096 · Negative test

**Original checklist item:** Negative case: A mutable workspace edit rewrites historical build relationships. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Provenance retention” source counterexample: “A mutable workspace edit rewrites historical build relationships”; state which precondition or invariant it challenges.
- [ ] **UC-M04.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Provenance retention”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.07-C096-T03 · Valid control:** Construct a valid “Provenance retention” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.07-C096-T04 · Minimal adverse input:** Derive the “Provenance retention” adverse fixture from the control with the smallest documented change needed to reproduce “A mutable workspace edit rewrites historical build relationships”; retain that change as reproducible data.
- [ ] **UC-M04.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Provenance retention”; require “Old provenance remains attributable to its original build” and forbid a false-success verdict.
- [ ] **UC-M04.07-C096-T06 · Adverse execution:** Exercise the “Provenance retention” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.07-C096-T07 · Effect inspection:** Inspect “Provenance retention” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.07-C096-T08 · Refusal versus failure:** Confirm the “Provenance retention” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.07-C096-T09 · Reset and retention:** Restore only the disposable “Provenance retention” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.07-C096-T10 · Negative regression:** Register the “Provenance retention” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.07-C097 · Change / failure test

**Original checklist item:** Exercise provenance retention when a subject or build input changes after an attestation was produced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.07-C097-T01 · Scenario record:** Write the “Provenance retention” change/failure scenario exactly as supplied: a subject or build input changes after an attestation was produced; identify the property that must remain true: “Old provenance remains attributable to its original build”.
- [ ] **UC-M04.07-C097-T02 · Baseline capture:** Create a known-valid “Provenance retention” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.07-C097-T03 · Injection map:** Locate the “Provenance retention” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Provenance retention” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.07-C097-T05 · Controlled trigger:** Introduce the controlled “Provenance retention” scenario in the disposable fixture: a subject or build input changes after an attestation was produced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.07-C097-T06 · Intermediate inspection:** Inspect the “Provenance retention” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Provenance retention”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Provenance retention” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.07-C097-T09 · Repeat and compare:** Repeat the selected “Provenance retention” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.07-C097-T10 · Failure evidence:** Publish the “Provenance retention” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for retained statements and storage budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Provenance retention”: “Retained statements and storage budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.07-C098-T02 · Measurement method:** Choose how to observe each “Provenance retention” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Provenance retention”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Provenance retention” cases for “Retained statements and storage budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Provenance retention” limit; preserve “Old provenance remains attributable to its original build”.
- [ ] **UC-M04.07-C098-T06 · Normal measurement:** Run or review the normal “Provenance retention” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.07-C098-T07 · At-limit measurement:** Exercise the “Provenance retention” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.07-C098-T08 · Over-limit measurement:** Exercise the “Provenance retention” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.07-C098-T09 · Uncovered-scope report:** List the “Provenance retention” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.07-C098-T10 · Limit evidence:** Publish the selected “Provenance retention” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for provenance retention with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.07-C099-T01 · Event inventory:** List the “Provenance retention” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Provenance retention” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.07-C099-T03 · Failure mapping:** Map each documented “Provenance retention” refusal or error to a diagnostic outcome; include “A mutable workspace edit rewrites historical build relationships” and prohibit conversion into a success message.
- [ ] **UC-M04.07-C099-T04 · Emission path:** Add the “Provenance retention” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.07-C099-T05 · Redaction check:** Test “Provenance retention” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.07-C099-T06 · Output budget:** Set and exercise bounded “Provenance retention” message size, rate and retention compatible with “Retained statements and storage budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.07-C099-T07 · Success/refusal fixtures:** Capture “Provenance retention” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Provenance retention” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.07-C099-T09 · Operator review:** Read the “Provenance retention” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.07-C099-T10 · Diagnostic evidence:** Publish redacted “Provenance retention” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for provenance retention; label unexecuted checks as untested.

- [ ] **UC-M04.07-C100-T01 · Evidence inventory:** List the “Provenance retention” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.07-C100-T02 · Artifact references:** Record the exact “Provenance retention” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.07-C100-T03 · Fixture references:** Attach the “Provenance retention” fixture IDs, input identities and oracle definition; preserve the source counterexample “A mutable workspace edit rewrites historical build relationships” as a distinct evidence case.
- [ ] **UC-M04.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Provenance retention”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.07-C100-T05 · Environment record:** Record the actual “Provenance retention” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.07-C100-T06 · Expected versus observed:** Pair every “Provenance retention” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.07-C100-T07 · Failure and limit records:** Attach “Provenance retention” change/failure and bounds evidence where required; include uncovered “Retained statements and storage budget” and unresolved violations of “Old provenance remains attributable to its original build”.
- [ ] **UC-M04.07-C100-T08 · Evidence hygiene:** Check the “Provenance retention” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.07-C100-T09 · Reproduction review:** Have the “Provenance retention” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.07-C100-T10 · Acceptance linkage:** Link the “Provenance retention” evidence to its parent and UC-M04.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

