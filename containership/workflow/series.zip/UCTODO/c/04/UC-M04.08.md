# UC-M04.08 — Authenticated image admission

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/04.md)

| Field | Preserved source value |
|---|---|
| Workstream | 04. Build and artifact production |
| Milestone | B |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M04.05](../04/UC-M04.05.md), [UC-M04.07](../04/UC-M04.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S5], [S7]. |

## Original requirement

Verify release signatures against operator-established trust roots before build, mount or execution; disable implicit trust enrollment for untrusted cargo.

**Original acceptance criterion:** An intact but self-signed or unapproved image is rejected; signature policy failure never becomes a checksum-only pass.

**Source trace:** Original checklist `UC100/c/04/UC-M04.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 411–422 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Operator trust roots

**Source delivery:** Load approved release trust anchors from operator-controlled configuration.

**Source invariant:** Untrusted cargo cannot enroll its own authority.

**Source negative case:** An image includes a key and marks it automatically trusted.

**Source bounded quantities:** Trust roots and configuration bytes.

### UC-M04.08-C001 · Contract

**Original checklist item:** Specify operator trust roots inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C001-T01 · Scope statement:** Draft the operation boundary for “Operator trust roots” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Operator trust roots”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C001-T03 · Output inventory:** List the outputs of “Operator trust roots” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Operator trust roots”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C001-T05 · Prerequisite contract:** Map “Operator trust roots” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C001-T06 · Authority map:** Identify who may produce, change and consume “Operator trust roots”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C001-T07 · Invariant clause:** Add a normative clause for “Operator trust roots” that preserves “Untrusted cargo cannot enroll its own authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Operator trust roots”; include the source counterexample “An image includes a key and marks it automatically trusted” and the intended safe disposition.
- [ ] **UC-M04.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trust roots and configuration bytes” in the “Operator trust roots” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C001-T10 · Contract review:** Review the “Operator trust roots” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C002 · Delivery

**Original checklist item:** Load approved release trust anchors from operator-controlled configuration.

- [ ] **UC-M04.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Operator trust roots”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C002-T02 · Change plan:** Break the source delivery for “Operator trust roots” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Operator trust roots” that realizes this source instruction: Load approved release trust anchors from operator-controlled configuration.
- [ ] **UC-M04.08-C002-T04 · Concrete realization:** Trace “Operator trust roots” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Operator trust roots” needed to preserve “Untrusted cargo cannot enroll its own authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C002-T06 · Dependency connection:** Connect the “Operator trust roots” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C002-T07 · Resource behavior:** Account for “Trust roots and configuration bytes” in “Operator trust roots”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C002-T08 · Delivery check:** Run the smallest real “Operator trust roots” path and its adverse fixture “An image includes a key and marks it automatically trusted”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C002-T09 · Patch review:** Review the “Operator trust roots” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C002-T10 · Delivery handoff:** Publish the “Operator trust roots” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Untrusted cargo cannot enroll its own authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “Operator trust roots”; copy its required invariant exactly: “Untrusted cargo cannot enroll its own authority”.
- [ ] **UC-M04.08-C003-T02 · Observable terms:** Define each term in the “Operator trust roots” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C003-T03 · Precondition set:** List the preconditions under which “Untrusted cargo cannot enroll its own authority” must hold for “Operator trust roots”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C003-T04 · Transition coverage:** Map the “Operator trust roots” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Operator trust roots”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C003-T06 · Satisfying fixture:** Create a concrete “Operator trust roots” case that satisfies “Untrusted cargo cannot enroll its own authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C003-T07 · Violating fixture:** Create the source counterexample “An image includes a key and marks it automatically trusted” for “Operator trust roots”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C003-T08 · Enforcement evidence:** Exercise the “Operator trust roots” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C003-T09 · Regression linkage:** Link the “Operator trust roots” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C003-T10 · Property disposition:** Compare the satisfying and violating “Operator trust roots” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C004 · Integration

**Original checklist item:** Integrate operator trust roots with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Operator trust roots” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C004-T02 · Field mapping:** Map every “Operator trust roots” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Operator trust roots” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C004-T04 · Ownership agreement:** Specify who owns “Operator trust roots” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C004-T05 · Handoff implementation:** Connect “Operator trust roots” through the mapped seam using the real adapter or explicit specification reference; preserve “Untrusted cargo cannot enroll its own authority” across the handoff.
- [ ] **UC-M04.08-C004-T06 · Absent-input case:** Omit one required “Operator trust roots” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C004-T07 · Stale-input case:** Supply an outdated “Operator trust roots” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C004-T08 · Incompatible-input case:** Supply an incompatible “Operator trust roots” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C004-T09 · Valid integration trace:** Run a valid “Operator trust roots” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C004-T10 · Seam review:** Reconcile the “Operator trust roots” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for operator trust roots; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Operator trust roots” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C005-T02 · Expected-result oracle:** Specify the “Operator trust roots” expected result independently of the implementation output; include the property “Untrusted cargo cannot enroll its own authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C005-T03 · Fixture material:** Create the concrete “Operator trust roots” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C005-T04 · Target preparation:** Prepare the “Operator trust roots” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C005-T05 · Initial-state record:** Record the initial “Operator trust roots” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C005-T06 · Valid-path execution:** Execute the “Operator trust roots” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C005-T07 · Outcome comparison:** Compare every declared “Operator trust roots” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C005-T08 · State and bounds check:** Inspect the “Operator trust roots” ownership/state effects and actual use of “Trust roots and configuration bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C005-T09 · Repeatability check:** Repeat the same “Operator trust roots” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C005-T10 · Positive evidence:** Attach the “Operator trust roots” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C006 · Negative test

**Original checklist item:** Negative case: An image includes a key and marks it automatically trusted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “Operator trust roots” source counterexample: “An image includes a key and marks it automatically trusted”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Operator trust roots”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C006-T03 · Valid control:** Construct a valid “Operator trust roots” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C006-T04 · Minimal adverse input:** Derive the “Operator trust roots” adverse fixture from the control with the smallest documented change needed to reproduce “An image includes a key and marks it automatically trusted”; retain that change as reproducible data.
- [ ] **UC-M04.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Operator trust roots”; require “Untrusted cargo cannot enroll its own authority” and forbid a false-success verdict.
- [ ] **UC-M04.08-C006-T06 · Adverse execution:** Exercise the “Operator trust roots” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C006-T07 · Effect inspection:** Inspect “Operator trust roots” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C006-T08 · Refusal versus failure:** Confirm the “Operator trust roots” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C006-T09 · Reset and retention:** Restore only the disposable “Operator trust roots” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C006-T10 · Negative regression:** Register the “Operator trust roots” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C007 · Change / failure test

**Original checklist item:** Exercise operator trust roots when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C007-T01 · Scenario record:** Write the “Operator trust roots” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “Untrusted cargo cannot enroll its own authority”.
- [ ] **UC-M04.08-C007-T02 · Baseline capture:** Create a known-valid “Operator trust roots” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C007-T03 · Injection map:** Locate the “Operator trust roots” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Operator trust roots” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C007-T05 · Controlled trigger:** Introduce the controlled “Operator trust roots” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C007-T06 · Intermediate inspection:** Inspect the “Operator trust roots” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Operator trust roots”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Operator trust roots” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C007-T09 · Repeat and compare:** Repeat the selected “Operator trust roots” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C007-T10 · Failure evidence:** Publish the “Operator trust roots” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C008 · Bounds

**Original checklist item:** Choose, document and test limits for trust roots and configuration bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “Operator trust roots”: “Trust roots and configuration bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C008-T02 · Measurement method:** Choose how to observe each “Operator trust roots” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C008-T03 · Budget decision:** Select justified resource and input limits for “Operator trust roots”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Operator trust roots” cases for “Trust roots and configuration bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Operator trust roots” limit; preserve “Untrusted cargo cannot enroll its own authority”.
- [ ] **UC-M04.08-C008-T06 · Normal measurement:** Run or review the normal “Operator trust roots” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C008-T07 · At-limit measurement:** Exercise the “Operator trust roots” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C008-T08 · Over-limit measurement:** Exercise the “Operator trust roots” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C008-T09 · Uncovered-scope report:** List the “Operator trust roots” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C008-T10 · Limit evidence:** Publish the selected “Operator trust roots” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for operator trust roots with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C009-T01 · Event inventory:** List the “Operator trust roots” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Operator trust roots” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C009-T03 · Failure mapping:** Map each documented “Operator trust roots” refusal or error to a diagnostic outcome; include “An image includes a key and marks it automatically trusted” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C009-T04 · Emission path:** Add the “Operator trust roots” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C009-T05 · Redaction check:** Test “Operator trust roots” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C009-T06 · Output budget:** Set and exercise bounded “Operator trust roots” message size, rate and retention compatible with “Trust roots and configuration bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C009-T07 · Success/refusal fixtures:** Capture “Operator trust roots” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Operator trust roots” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C009-T09 · Operator review:** Read the “Operator trust roots” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C009-T10 · Diagnostic evidence:** Publish redacted “Operator trust roots” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for operator trust roots; label unexecuted checks as untested.

- [ ] **UC-M04.08-C010-T01 · Evidence inventory:** List the “Operator trust roots” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C010-T02 · Artifact references:** Record the exact “Operator trust roots” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C010-T03 · Fixture references:** Attach the “Operator trust roots” fixture IDs, input identities and oracle definition; preserve the source counterexample “An image includes a key and marks it automatically trusted” as a distinct evidence case.
- [ ] **UC-M04.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Operator trust roots”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C010-T05 · Environment record:** Record the actual “Operator trust roots” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C010-T06 · Expected versus observed:** Pair every “Operator trust roots” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C010-T07 · Failure and limit records:** Attach “Operator trust roots” change/failure and bounds evidence where required; include uncovered “Trust roots and configuration bytes” and unresolved violations of “Untrusted cargo cannot enroll its own authority”.
- [ ] **UC-M04.08-C010-T08 · Evidence hygiene:** Check the “Operator trust roots” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C010-T09 · Reproduction review:** Have the “Operator trust roots” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C010-T10 · Acceptance linkage:** Link the “Operator trust roots” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Signature subject binding

**Source delivery:** Verify signatures over the exact image and declared metadata identities.

**Source invariant:** A valid signature for another subject cannot admit this image.

**Source negative case:** A signature is copied from a different approved image.

**Source bounded quantities:** Signed subjects and image bytes.

### UC-M04.08-C011 · Contract

**Original checklist item:** Specify signature subject binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C011-T01 · Scope statement:** Draft the operation boundary for “Signature subject binding” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Signature subject binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C011-T03 · Output inventory:** List the outputs of “Signature subject binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Signature subject binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C011-T05 · Prerequisite contract:** Map “Signature subject binding” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Signature subject binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C011-T07 · Invariant clause:** Add a normative clause for “Signature subject binding” that preserves “A valid signature for another subject cannot admit this image”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Signature subject binding”; include the source counterexample “A signature is copied from a different approved image” and the intended safe disposition.
- [ ] **UC-M04.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Signed subjects and image bytes” in the “Signature subject binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C011-T10 · Contract review:** Review the “Signature subject binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C012 · Delivery

**Original checklist item:** Verify signatures over the exact image and declared metadata identities.

- [ ] **UC-M04.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Signature subject binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C012-T02 · Change plan:** Break the source delivery for “Signature subject binding” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C012-T03 · Core artifact:** Create the “Signature subject binding” fixture or harness for this source instruction: Verify signatures over the exact image and declared metadata identities.
- [ ] **UC-M04.08-C012-T04 · Concrete realization:** Connect the “Signature subject binding” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Signature subject binding” needed to preserve “A valid signature for another subject cannot admit this image”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C012-T06 · Dependency connection:** Connect the “Signature subject binding” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C012-T07 · Resource behavior:** Account for “Signed subjects and image bytes” in “Signature subject binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C012-T08 · Delivery check:** Run the smallest real “Signature subject binding” path and its adverse fixture “A signature is copied from a different approved image”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C012-T09 · Patch review:** Review the “Signature subject binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C012-T10 · Delivery handoff:** Publish the “Signature subject binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A valid signature for another subject cannot admit this image. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Signature subject binding”; copy its required invariant exactly: “A valid signature for another subject cannot admit this image”.
- [ ] **UC-M04.08-C013-T02 · Observable terms:** Define each term in the “Signature subject binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C013-T03 · Precondition set:** List the preconditions under which “A valid signature for another subject cannot admit this image” must hold for “Signature subject binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C013-T04 · Transition coverage:** Map the “Signature subject binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Signature subject binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C013-T06 · Satisfying fixture:** Create a concrete “Signature subject binding” case that satisfies “A valid signature for another subject cannot admit this image”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C013-T07 · Violating fixture:** Create the source counterexample “A signature is copied from a different approved image” for “Signature subject binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C013-T08 · Enforcement evidence:** Exercise the “Signature subject binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C013-T09 · Regression linkage:** Link the “Signature subject binding” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Signature subject binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C014 · Integration

**Original checklist item:** Integrate signature subject binding with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Signature subject binding” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C014-T02 · Field mapping:** Map every “Signature subject binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Signature subject binding” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C014-T04 · Ownership agreement:** Specify who owns “Signature subject binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C014-T05 · Handoff implementation:** Connect “Signature subject binding” through the mapped seam using the real adapter or explicit specification reference; preserve “A valid signature for another subject cannot admit this image” across the handoff.
- [ ] **UC-M04.08-C014-T06 · Absent-input case:** Omit one required “Signature subject binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C014-T07 · Stale-input case:** Supply an outdated “Signature subject binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Signature subject binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C014-T09 · Valid integration trace:** Run a valid “Signature subject binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C014-T10 · Seam review:** Reconcile the “Signature subject binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for signature subject binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Signature subject binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C015-T02 · Expected-result oracle:** Specify the “Signature subject binding” expected result independently of the implementation output; include the property “A valid signature for another subject cannot admit this image” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C015-T03 · Fixture material:** Create the concrete “Signature subject binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C015-T04 · Target preparation:** Prepare the “Signature subject binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C015-T05 · Initial-state record:** Record the initial “Signature subject binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C015-T06 · Valid-path execution:** Execute the “Signature subject binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C015-T07 · Outcome comparison:** Compare every declared “Signature subject binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C015-T08 · State and bounds check:** Inspect the “Signature subject binding” ownership/state effects and actual use of “Signed subjects and image bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C015-T09 · Repeatability check:** Repeat the same “Signature subject binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C015-T10 · Positive evidence:** Attach the “Signature subject binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C016 · Negative test

**Original checklist item:** Negative case: A signature is copied from a different approved image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Signature subject binding” source counterexample: “A signature is copied from a different approved image”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Signature subject binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C016-T03 · Valid control:** Construct a valid “Signature subject binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C016-T04 · Minimal adverse input:** Derive the “Signature subject binding” adverse fixture from the control with the smallest documented change needed to reproduce “A signature is copied from a different approved image”; retain that change as reproducible data.
- [ ] **UC-M04.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Signature subject binding”; require “A valid signature for another subject cannot admit this image” and forbid a false-success verdict.
- [ ] **UC-M04.08-C016-T06 · Adverse execution:** Exercise the “Signature subject binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C016-T07 · Effect inspection:** Inspect “Signature subject binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C016-T08 · Refusal versus failure:** Confirm the “Signature subject binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C016-T09 · Reset and retention:** Restore only the disposable “Signature subject binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C016-T10 · Negative regression:** Register the “Signature subject binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C017 · Change / failure test

**Original checklist item:** Exercise signature subject binding when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C017-T01 · Scenario record:** Write the “Signature subject binding” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “A valid signature for another subject cannot admit this image”.
- [ ] **UC-M04.08-C017-T02 · Baseline capture:** Create a known-valid “Signature subject binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C017-T03 · Injection map:** Locate the “Signature subject binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Signature subject binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C017-T05 · Controlled trigger:** Introduce the controlled “Signature subject binding” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C017-T06 · Intermediate inspection:** Inspect the “Signature subject binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Signature subject binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Signature subject binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C017-T09 · Repeat and compare:** Repeat the selected “Signature subject binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C017-T10 · Failure evidence:** Publish the “Signature subject binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C018 · Bounds

**Original checklist item:** Choose, document and test limits for signed subjects and image bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Signature subject binding”: “Signed subjects and image bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C018-T02 · Measurement method:** Choose how to observe each “Signature subject binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C018-T03 · Budget decision:** Select justified resource and input limits for “Signature subject binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Signature subject binding” cases for “Signed subjects and image bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Signature subject binding” limit; preserve “A valid signature for another subject cannot admit this image”.
- [ ] **UC-M04.08-C018-T06 · Normal measurement:** Run or review the normal “Signature subject binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C018-T07 · At-limit measurement:** Exercise the “Signature subject binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C018-T08 · Over-limit measurement:** Exercise the “Signature subject binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C018-T09 · Uncovered-scope report:** List the “Signature subject binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C018-T10 · Limit evidence:** Publish the selected “Signature subject binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for signature subject binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C019-T01 · Event inventory:** List the “Signature subject binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Signature subject binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C019-T03 · Failure mapping:** Map each documented “Signature subject binding” refusal or error to a diagnostic outcome; include “A signature is copied from a different approved image” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C019-T04 · Emission path:** Add the “Signature subject binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C019-T05 · Redaction check:** Test “Signature subject binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C019-T06 · Output budget:** Set and exercise bounded “Signature subject binding” message size, rate and retention compatible with “Signed subjects and image bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C019-T07 · Success/refusal fixtures:** Capture “Signature subject binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Signature subject binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C019-T09 · Operator review:** Read the “Signature subject binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C019-T10 · Diagnostic evidence:** Publish redacted “Signature subject binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for signature subject binding; label unexecuted checks as untested.

- [ ] **UC-M04.08-C020-T01 · Evidence inventory:** List the “Signature subject binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C020-T02 · Artifact references:** Record the exact “Signature subject binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C020-T03 · Fixture references:** Attach the “Signature subject binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A signature is copied from a different approved image” as a distinct evidence case.
- [ ] **UC-M04.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Signature subject binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C020-T05 · Environment record:** Record the actual “Signature subject binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C020-T06 · Expected versus observed:** Pair every “Signature subject binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C020-T07 · Failure and limit records:** Attach “Signature subject binding” change/failure and bounds evidence where required; include uncovered “Signed subjects and image bytes” and unresolved violations of “A valid signature for another subject cannot admit this image”.
- [ ] **UC-M04.08-C020-T08 · Evidence hygiene:** Check the “Signature subject binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C020-T09 · Reproduction review:** Have the “Signature subject binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C020-T10 · Acceptance linkage:** Link the “Signature subject binding” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Signer authorization

**Source delivery:** Check signer role and scope in addition to cryptographic validity.

**Source invariant:** A valid but unauthorized signer cannot admit an image.

**Source negative case:** A development-only key signs a production admission artifact.

**Source bounded quantities:** Signer count and policy lookup time.

### UC-M04.08-C021 · Contract

**Original checklist item:** Specify signer authorization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C021-T01 · Scope statement:** Draft the operation boundary for “Signer authorization” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Signer authorization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C021-T03 · Output inventory:** List the outputs of “Signer authorization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Signer authorization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C021-T05 · Prerequisite contract:** Map “Signer authorization” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Signer authorization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C021-T07 · Invariant clause:** Add a normative clause for “Signer authorization” that preserves “A valid but unauthorized signer cannot admit an image”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Signer authorization”; include the source counterexample “A development-only key signs a production admission artifact” and the intended safe disposition.
- [ ] **UC-M04.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Signer count and policy lookup time” in the “Signer authorization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C021-T10 · Contract review:** Review the “Signer authorization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C022 · Delivery

**Original checklist item:** Check signer role and scope in addition to cryptographic validity.

- [ ] **UC-M04.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Signer authorization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C022-T02 · Change plan:** Break the source delivery for “Signer authorization” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C022-T03 · Core artifact:** Create the “Signer authorization” fixture or harness for this source instruction: Check signer role and scope in addition to cryptographic validity.
- [ ] **UC-M04.08-C022-T04 · Concrete realization:** Connect the “Signer authorization” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Signer authorization” needed to preserve “A valid but unauthorized signer cannot admit an image”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C022-T06 · Dependency connection:** Connect the “Signer authorization” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C022-T07 · Resource behavior:** Account for “Signer count and policy lookup time” in “Signer authorization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C022-T08 · Delivery check:** Run the smallest real “Signer authorization” path and its adverse fixture “A development-only key signs a production admission artifact”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C022-T09 · Patch review:** Review the “Signer authorization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C022-T10 · Delivery handoff:** Publish the “Signer authorization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A valid but unauthorized signer cannot admit an image. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Signer authorization”; copy its required invariant exactly: “A valid but unauthorized signer cannot admit an image”.
- [ ] **UC-M04.08-C023-T02 · Observable terms:** Define each term in the “Signer authorization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C023-T03 · Precondition set:** List the preconditions under which “A valid but unauthorized signer cannot admit an image” must hold for “Signer authorization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C023-T04 · Transition coverage:** Map the “Signer authorization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Signer authorization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C023-T06 · Satisfying fixture:** Create a concrete “Signer authorization” case that satisfies “A valid but unauthorized signer cannot admit an image”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C023-T07 · Violating fixture:** Create the source counterexample “A development-only key signs a production admission artifact” for “Signer authorization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C023-T08 · Enforcement evidence:** Exercise the “Signer authorization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C023-T09 · Regression linkage:** Link the “Signer authorization” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Signer authorization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C024 · Integration

**Original checklist item:** Integrate signer authorization with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Signer authorization” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C024-T02 · Field mapping:** Map every “Signer authorization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Signer authorization” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C024-T04 · Ownership agreement:** Specify who owns “Signer authorization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C024-T05 · Handoff implementation:** Connect “Signer authorization” through the mapped seam using the real adapter or explicit specification reference; preserve “A valid but unauthorized signer cannot admit an image” across the handoff.
- [ ] **UC-M04.08-C024-T06 · Absent-input case:** Omit one required “Signer authorization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C024-T07 · Stale-input case:** Supply an outdated “Signer authorization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Signer authorization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C024-T09 · Valid integration trace:** Run a valid “Signer authorization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C024-T10 · Seam review:** Reconcile the “Signer authorization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for signer authorization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Signer authorization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C025-T02 · Expected-result oracle:** Specify the “Signer authorization” expected result independently of the implementation output; include the property “A valid but unauthorized signer cannot admit an image” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C025-T03 · Fixture material:** Create the concrete “Signer authorization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C025-T04 · Target preparation:** Prepare the “Signer authorization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C025-T05 · Initial-state record:** Record the initial “Signer authorization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C025-T06 · Valid-path execution:** Execute the “Signer authorization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C025-T07 · Outcome comparison:** Compare every declared “Signer authorization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C025-T08 · State and bounds check:** Inspect the “Signer authorization” ownership/state effects and actual use of “Signer count and policy lookup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C025-T09 · Repeatability check:** Repeat the same “Signer authorization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C025-T10 · Positive evidence:** Attach the “Signer authorization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C026 · Negative test

**Original checklist item:** Negative case: A development-only key signs a production admission artifact. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Signer authorization” source counterexample: “A development-only key signs a production admission artifact”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Signer authorization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C026-T03 · Valid control:** Construct a valid “Signer authorization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C026-T04 · Minimal adverse input:** Derive the “Signer authorization” adverse fixture from the control with the smallest documented change needed to reproduce “A development-only key signs a production admission artifact”; retain that change as reproducible data.
- [ ] **UC-M04.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Signer authorization”; require “A valid but unauthorized signer cannot admit an image” and forbid a false-success verdict.
- [ ] **UC-M04.08-C026-T06 · Adverse execution:** Exercise the “Signer authorization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C026-T07 · Effect inspection:** Inspect “Signer authorization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C026-T08 · Refusal versus failure:** Confirm the “Signer authorization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C026-T09 · Reset and retention:** Restore only the disposable “Signer authorization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C026-T10 · Negative regression:** Register the “Signer authorization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C027 · Change / failure test

**Original checklist item:** Exercise signer authorization when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C027-T01 · Scenario record:** Write the “Signer authorization” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “A valid but unauthorized signer cannot admit an image”.
- [ ] **UC-M04.08-C027-T02 · Baseline capture:** Create a known-valid “Signer authorization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C027-T03 · Injection map:** Locate the “Signer authorization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Signer authorization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C027-T05 · Controlled trigger:** Introduce the controlled “Signer authorization” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C027-T06 · Intermediate inspection:** Inspect the “Signer authorization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Signer authorization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Signer authorization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C027-T09 · Repeat and compare:** Repeat the selected “Signer authorization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C027-T10 · Failure evidence:** Publish the “Signer authorization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C028 · Bounds

**Original checklist item:** Choose, document and test limits for signer count and policy lookup time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Signer authorization”: “Signer count and policy lookup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C028-T02 · Measurement method:** Choose how to observe each “Signer authorization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C028-T03 · Budget decision:** Select justified resource and input limits for “Signer authorization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Signer authorization” cases for “Signer count and policy lookup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Signer authorization” limit; preserve “A valid but unauthorized signer cannot admit an image”.
- [ ] **UC-M04.08-C028-T06 · Normal measurement:** Run or review the normal “Signer authorization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C028-T07 · At-limit measurement:** Exercise the “Signer authorization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C028-T08 · Over-limit measurement:** Exercise the “Signer authorization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C028-T09 · Uncovered-scope report:** List the “Signer authorization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C028-T10 · Limit evidence:** Publish the selected “Signer authorization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for signer authorization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C029-T01 · Event inventory:** List the “Signer authorization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Signer authorization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C029-T03 · Failure mapping:** Map each documented “Signer authorization” refusal or error to a diagnostic outcome; include “A development-only key signs a production admission artifact” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C029-T04 · Emission path:** Add the “Signer authorization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C029-T05 · Redaction check:** Test “Signer authorization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C029-T06 · Output budget:** Set and exercise bounded “Signer authorization” message size, rate and retention compatible with “Signer count and policy lookup time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C029-T07 · Success/refusal fixtures:** Capture “Signer authorization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Signer authorization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C029-T09 · Operator review:** Read the “Signer authorization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C029-T10 · Diagnostic evidence:** Publish redacted “Signer authorization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for signer authorization; label unexecuted checks as untested.

- [ ] **UC-M04.08-C030-T01 · Evidence inventory:** List the “Signer authorization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C030-T02 · Artifact references:** Record the exact “Signer authorization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C030-T03 · Fixture references:** Attach the “Signer authorization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A development-only key signs a production admission artifact” as a distinct evidence case.
- [ ] **UC-M04.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Signer authorization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C030-T05 · Environment record:** Record the actual “Signer authorization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C030-T06 · Expected versus observed:** Pair every “Signer authorization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C030-T07 · Failure and limit records:** Attach “Signer authorization” change/failure and bounds evidence where required; include uncovered “Signer count and policy lookup time” and unresolved violations of “A valid but unauthorized signer cannot admit an image”.
- [ ] **UC-M04.08-C030-T08 · Evidence hygiene:** Check the “Signer authorization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C030-T09 · Reproduction review:** Have the “Signer authorization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C030-T10 · Acceptance linkage:** Link the “Signer authorization” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Admission timing

**Source delivery:** Complete authentication before build hooks, mounts or execution begin.

**Source invariant:** Rejected images trigger no executable action.

**Source negative case:** A build hook executes before its image signature is checked.

**Source bounded quantities:** Pre-admission operations and validation deadline.

### UC-M04.08-C031 · Contract

**Original checklist item:** Specify admission timing inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C031-T01 · Scope statement:** Draft the operation boundary for “Admission timing” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Admission timing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C031-T03 · Output inventory:** List the outputs of “Admission timing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Admission timing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C031-T05 · Prerequisite contract:** Map “Admission timing” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Admission timing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C031-T07 · Invariant clause:** Add a normative clause for “Admission timing” that preserves “Rejected images trigger no executable action”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Admission timing”; include the source counterexample “A build hook executes before its image signature is checked” and the intended safe disposition.
- [ ] **UC-M04.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pre-admission operations and validation deadline” in the “Admission timing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C031-T10 · Contract review:** Review the “Admission timing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C032 · Delivery

**Original checklist item:** Complete authentication before build hooks, mounts or execution begin.

- [ ] **UC-M04.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Admission timing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C032-T02 · Change plan:** Break the source delivery for “Admission timing” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Admission timing” that realizes this source instruction: Complete authentication before build hooks, mounts or execution begin.
- [ ] **UC-M04.08-C032-T04 · Concrete realization:** Trace “Admission timing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Admission timing” needed to preserve “Rejected images trigger no executable action”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C032-T06 · Dependency connection:** Connect the “Admission timing” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C032-T07 · Resource behavior:** Account for “Pre-admission operations and validation deadline” in “Admission timing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C032-T08 · Delivery check:** Run the smallest real “Admission timing” path and its adverse fixture “A build hook executes before its image signature is checked”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C032-T09 · Patch review:** Review the “Admission timing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C032-T10 · Delivery handoff:** Publish the “Admission timing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rejected images trigger no executable action. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Admission timing”; copy its required invariant exactly: “Rejected images trigger no executable action”.
- [ ] **UC-M04.08-C033-T02 · Observable terms:** Define each term in the “Admission timing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C033-T03 · Precondition set:** List the preconditions under which “Rejected images trigger no executable action” must hold for “Admission timing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C033-T04 · Transition coverage:** Map the “Admission timing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Admission timing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C033-T06 · Satisfying fixture:** Create a concrete “Admission timing” case that satisfies “Rejected images trigger no executable action”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C033-T07 · Violating fixture:** Create the source counterexample “A build hook executes before its image signature is checked” for “Admission timing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C033-T08 · Enforcement evidence:** Exercise the “Admission timing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C033-T09 · Regression linkage:** Link the “Admission timing” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Admission timing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C034 · Integration

**Original checklist item:** Integrate admission timing with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Admission timing” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C034-T02 · Field mapping:** Map every “Admission timing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Admission timing” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C034-T04 · Ownership agreement:** Specify who owns “Admission timing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C034-T05 · Handoff implementation:** Connect “Admission timing” through the mapped seam using the real adapter or explicit specification reference; preserve “Rejected images trigger no executable action” across the handoff.
- [ ] **UC-M04.08-C034-T06 · Absent-input case:** Omit one required “Admission timing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C034-T07 · Stale-input case:** Supply an outdated “Admission timing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Admission timing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C034-T09 · Valid integration trace:** Run a valid “Admission timing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C034-T10 · Seam review:** Reconcile the “Admission timing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for admission timing; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Admission timing” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C035-T02 · Expected-result oracle:** Specify the “Admission timing” expected result independently of the implementation output; include the property “Rejected images trigger no executable action” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C035-T03 · Fixture material:** Create the concrete “Admission timing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C035-T04 · Target preparation:** Prepare the “Admission timing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C035-T05 · Initial-state record:** Record the initial “Admission timing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C035-T06 · Valid-path execution:** Execute the “Admission timing” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C035-T07 · Outcome comparison:** Compare every declared “Admission timing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C035-T08 · State and bounds check:** Inspect the “Admission timing” ownership/state effects and actual use of “Pre-admission operations and validation deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C035-T09 · Repeatability check:** Repeat the same “Admission timing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C035-T10 · Positive evidence:** Attach the “Admission timing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C036 · Negative test

**Original checklist item:** Negative case: A build hook executes before its image signature is checked. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Admission timing” source counterexample: “A build hook executes before its image signature is checked”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Admission timing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C036-T03 · Valid control:** Construct a valid “Admission timing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C036-T04 · Minimal adverse input:** Derive the “Admission timing” adverse fixture from the control with the smallest documented change needed to reproduce “A build hook executes before its image signature is checked”; retain that change as reproducible data.
- [ ] **UC-M04.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Admission timing”; require “Rejected images trigger no executable action” and forbid a false-success verdict.
- [ ] **UC-M04.08-C036-T06 · Adverse execution:** Exercise the “Admission timing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C036-T07 · Effect inspection:** Inspect “Admission timing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C036-T08 · Refusal versus failure:** Confirm the “Admission timing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C036-T09 · Reset and retention:** Restore only the disposable “Admission timing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C036-T10 · Negative regression:** Register the “Admission timing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C037 · Change / failure test

**Original checklist item:** Exercise admission timing when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C037-T01 · Scenario record:** Write the “Admission timing” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “Rejected images trigger no executable action”.
- [ ] **UC-M04.08-C037-T02 · Baseline capture:** Create a known-valid “Admission timing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C037-T03 · Injection map:** Locate the “Admission timing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Admission timing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C037-T05 · Controlled trigger:** Introduce the controlled “Admission timing” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C037-T06 · Intermediate inspection:** Inspect the “Admission timing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Admission timing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Admission timing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C037-T09 · Repeat and compare:** Repeat the selected “Admission timing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C037-T10 · Failure evidence:** Publish the “Admission timing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C038 · Bounds

**Original checklist item:** Choose, document and test limits for pre-admission operations and validation deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Admission timing”: “Pre-admission operations and validation deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C038-T02 · Measurement method:** Choose how to observe each “Admission timing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C038-T03 · Budget decision:** Select justified resource and input limits for “Admission timing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Admission timing” cases for “Pre-admission operations and validation deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Admission timing” limit; preserve “Rejected images trigger no executable action”.
- [ ] **UC-M04.08-C038-T06 · Normal measurement:** Run or review the normal “Admission timing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C038-T07 · At-limit measurement:** Exercise the “Admission timing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C038-T08 · Over-limit measurement:** Exercise the “Admission timing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C038-T09 · Uncovered-scope report:** List the “Admission timing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C038-T10 · Limit evidence:** Publish the selected “Admission timing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for admission timing with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C039-T01 · Event inventory:** List the “Admission timing” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Admission timing” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C039-T03 · Failure mapping:** Map each documented “Admission timing” refusal or error to a diagnostic outcome; include “A build hook executes before its image signature is checked” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C039-T04 · Emission path:** Add the “Admission timing” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C039-T05 · Redaction check:** Test “Admission timing” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C039-T06 · Output budget:** Set and exercise bounded “Admission timing” message size, rate and retention compatible with “Pre-admission operations and validation deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C039-T07 · Success/refusal fixtures:** Capture “Admission timing” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Admission timing” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C039-T09 · Operator review:** Read the “Admission timing” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C039-T10 · Diagnostic evidence:** Publish redacted “Admission timing” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for admission timing; label unexecuted checks as untested.

- [ ] **UC-M04.08-C040-T01 · Evidence inventory:** List the “Admission timing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C040-T02 · Artifact references:** Record the exact “Admission timing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C040-T03 · Fixture references:** Attach the “Admission timing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build hook executes before its image signature is checked” as a distinct evidence case.
- [ ] **UC-M04.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Admission timing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C040-T05 · Environment record:** Record the actual “Admission timing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C040-T06 · Expected versus observed:** Pair every “Admission timing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C040-T07 · Failure and limit records:** Attach “Admission timing” change/failure and bounds evidence where required; include uncovered “Pre-admission operations and validation deadline” and unresolved violations of “Rejected images trigger no executable action”.
- [ ] **UC-M04.08-C040-T08 · Evidence hygiene:** Check the “Admission timing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C040-T09 · Reproduction review:** Have the “Admission timing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C040-T10 · Acceptance linkage:** Link the “Admission timing” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Untrusted enrollment refusal

**Source delivery:** Disable implicit key enrollment from image or archive contents.

**Source invariant:** Cargo author identity cannot redefine operator trust.

**Source negative case:** A self-signed image asks to add its signer to trusted roots.

**Source bounded quantities:** Enrollment requests and rejected metadata size.

### UC-M04.08-C041 · Contract

**Original checklist item:** Specify untrusted enrollment refusal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C041-T01 · Scope statement:** Draft the operation boundary for “Untrusted enrollment refusal” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Untrusted enrollment refusal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C041-T03 · Output inventory:** List the outputs of “Untrusted enrollment refusal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Untrusted enrollment refusal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C041-T05 · Prerequisite contract:** Map “Untrusted enrollment refusal” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Untrusted enrollment refusal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C041-T07 · Invariant clause:** Add a normative clause for “Untrusted enrollment refusal” that preserves “Cargo author identity cannot redefine operator trust”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Untrusted enrollment refusal”; include the source counterexample “A self-signed image asks to add its signer to trusted roots” and the intended safe disposition.
- [ ] **UC-M04.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Enrollment requests and rejected metadata size” in the “Untrusted enrollment refusal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C041-T10 · Contract review:** Review the “Untrusted enrollment refusal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C042 · Delivery

**Original checklist item:** Disable implicit key enrollment from image or archive contents.

- [ ] **UC-M04.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Untrusted enrollment refusal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C042-T02 · Change plan:** Break the source delivery for “Untrusted enrollment refusal” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Untrusted enrollment refusal” that realizes this source instruction: Disable implicit key enrollment from image or archive contents.
- [ ] **UC-M04.08-C042-T04 · Concrete realization:** Trace “Untrusted enrollment refusal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Untrusted enrollment refusal” needed to preserve “Cargo author identity cannot redefine operator trust”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C042-T06 · Dependency connection:** Connect the “Untrusted enrollment refusal” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C042-T07 · Resource behavior:** Account for “Enrollment requests and rejected metadata size” in “Untrusted enrollment refusal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C042-T08 · Delivery check:** Run the smallest real “Untrusted enrollment refusal” path and its adverse fixture “A self-signed image asks to add its signer to trusted roots”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C042-T09 · Patch review:** Review the “Untrusted enrollment refusal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C042-T10 · Delivery handoff:** Publish the “Untrusted enrollment refusal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Cargo author identity cannot redefine operator trust. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Untrusted enrollment refusal”; copy its required invariant exactly: “Cargo author identity cannot redefine operator trust”.
- [ ] **UC-M04.08-C043-T02 · Observable terms:** Define each term in the “Untrusted enrollment refusal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C043-T03 · Precondition set:** List the preconditions under which “Cargo author identity cannot redefine operator trust” must hold for “Untrusted enrollment refusal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C043-T04 · Transition coverage:** Map the “Untrusted enrollment refusal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Untrusted enrollment refusal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C043-T06 · Satisfying fixture:** Create a concrete “Untrusted enrollment refusal” case that satisfies “Cargo author identity cannot redefine operator trust”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C043-T07 · Violating fixture:** Create the source counterexample “A self-signed image asks to add its signer to trusted roots” for “Untrusted enrollment refusal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C043-T08 · Enforcement evidence:** Exercise the “Untrusted enrollment refusal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C043-T09 · Regression linkage:** Link the “Untrusted enrollment refusal” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Untrusted enrollment refusal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C044 · Integration

**Original checklist item:** Integrate untrusted enrollment refusal with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Untrusted enrollment refusal” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C044-T02 · Field mapping:** Map every “Untrusted enrollment refusal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Untrusted enrollment refusal” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C044-T04 · Ownership agreement:** Specify who owns “Untrusted enrollment refusal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C044-T05 · Handoff implementation:** Connect “Untrusted enrollment refusal” through the mapped seam using the real adapter or explicit specification reference; preserve “Cargo author identity cannot redefine operator trust” across the handoff.
- [ ] **UC-M04.08-C044-T06 · Absent-input case:** Omit one required “Untrusted enrollment refusal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C044-T07 · Stale-input case:** Supply an outdated “Untrusted enrollment refusal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Untrusted enrollment refusal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C044-T09 · Valid integration trace:** Run a valid “Untrusted enrollment refusal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C044-T10 · Seam review:** Reconcile the “Untrusted enrollment refusal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for untrusted enrollment refusal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Untrusted enrollment refusal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C045-T02 · Expected-result oracle:** Specify the “Untrusted enrollment refusal” expected result independently of the implementation output; include the property “Cargo author identity cannot redefine operator trust” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C045-T03 · Fixture material:** Create the concrete “Untrusted enrollment refusal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C045-T04 · Target preparation:** Prepare the “Untrusted enrollment refusal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C045-T05 · Initial-state record:** Record the initial “Untrusted enrollment refusal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C045-T06 · Valid-path execution:** Execute the “Untrusted enrollment refusal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C045-T07 · Outcome comparison:** Compare every declared “Untrusted enrollment refusal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C045-T08 · State and bounds check:** Inspect the “Untrusted enrollment refusal” ownership/state effects and actual use of “Enrollment requests and rejected metadata size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C045-T09 · Repeatability check:** Repeat the same “Untrusted enrollment refusal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C045-T10 · Positive evidence:** Attach the “Untrusted enrollment refusal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C046 · Negative test

**Original checklist item:** Negative case: A self-signed image asks to add its signer to trusted roots. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Untrusted enrollment refusal” source counterexample: “A self-signed image asks to add its signer to trusted roots”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Untrusted enrollment refusal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C046-T03 · Valid control:** Construct a valid “Untrusted enrollment refusal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C046-T04 · Minimal adverse input:** Derive the “Untrusted enrollment refusal” adverse fixture from the control with the smallest documented change needed to reproduce “A self-signed image asks to add its signer to trusted roots”; retain that change as reproducible data.
- [ ] **UC-M04.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Untrusted enrollment refusal”; require “Cargo author identity cannot redefine operator trust” and forbid a false-success verdict.
- [ ] **UC-M04.08-C046-T06 · Adverse execution:** Exercise the “Untrusted enrollment refusal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C046-T07 · Effect inspection:** Inspect “Untrusted enrollment refusal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C046-T08 · Refusal versus failure:** Confirm the “Untrusted enrollment refusal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C046-T09 · Reset and retention:** Restore only the disposable “Untrusted enrollment refusal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C046-T10 · Negative regression:** Register the “Untrusted enrollment refusal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C047 · Change / failure test

**Original checklist item:** Exercise untrusted enrollment refusal when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C047-T01 · Scenario record:** Write the “Untrusted enrollment refusal” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “Cargo author identity cannot redefine operator trust”.
- [ ] **UC-M04.08-C047-T02 · Baseline capture:** Create a known-valid “Untrusted enrollment refusal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C047-T03 · Injection map:** Locate the “Untrusted enrollment refusal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Untrusted enrollment refusal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C047-T05 · Controlled trigger:** Introduce the controlled “Untrusted enrollment refusal” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C047-T06 · Intermediate inspection:** Inspect the “Untrusted enrollment refusal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Untrusted enrollment refusal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Untrusted enrollment refusal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C047-T09 · Repeat and compare:** Repeat the selected “Untrusted enrollment refusal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C047-T10 · Failure evidence:** Publish the “Untrusted enrollment refusal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C048 · Bounds

**Original checklist item:** Choose, document and test limits for enrollment requests and rejected metadata size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Untrusted enrollment refusal”: “Enrollment requests and rejected metadata size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C048-T02 · Measurement method:** Choose how to observe each “Untrusted enrollment refusal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C048-T03 · Budget decision:** Select justified resource and input limits for “Untrusted enrollment refusal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Untrusted enrollment refusal” cases for “Enrollment requests and rejected metadata size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Untrusted enrollment refusal” limit; preserve “Cargo author identity cannot redefine operator trust”.
- [ ] **UC-M04.08-C048-T06 · Normal measurement:** Run or review the normal “Untrusted enrollment refusal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C048-T07 · At-limit measurement:** Exercise the “Untrusted enrollment refusal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C048-T08 · Over-limit measurement:** Exercise the “Untrusted enrollment refusal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C048-T09 · Uncovered-scope report:** List the “Untrusted enrollment refusal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C048-T10 · Limit evidence:** Publish the selected “Untrusted enrollment refusal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for untrusted enrollment refusal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C049-T01 · Event inventory:** List the “Untrusted enrollment refusal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Untrusted enrollment refusal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C049-T03 · Failure mapping:** Map each documented “Untrusted enrollment refusal” refusal or error to a diagnostic outcome; include “A self-signed image asks to add its signer to trusted roots” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C049-T04 · Emission path:** Add the “Untrusted enrollment refusal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C049-T05 · Redaction check:** Test “Untrusted enrollment refusal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C049-T06 · Output budget:** Set and exercise bounded “Untrusted enrollment refusal” message size, rate and retention compatible with “Enrollment requests and rejected metadata size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C049-T07 · Success/refusal fixtures:** Capture “Untrusted enrollment refusal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Untrusted enrollment refusal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C049-T09 · Operator review:** Read the “Untrusted enrollment refusal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C049-T10 · Diagnostic evidence:** Publish redacted “Untrusted enrollment refusal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for untrusted enrollment refusal; label unexecuted checks as untested.

- [ ] **UC-M04.08-C050-T01 · Evidence inventory:** List the “Untrusted enrollment refusal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C050-T02 · Artifact references:** Record the exact “Untrusted enrollment refusal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C050-T03 · Fixture references:** Attach the “Untrusted enrollment refusal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A self-signed image asks to add its signer to trusted roots” as a distinct evidence case.
- [ ] **UC-M04.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Untrusted enrollment refusal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C050-T05 · Environment record:** Record the actual “Untrusted enrollment refusal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C050-T06 · Expected versus observed:** Pair every “Untrusted enrollment refusal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C050-T07 · Failure and limit records:** Attach “Untrusted enrollment refusal” change/failure and bounds evidence where required; include uncovered “Enrollment requests and rejected metadata size” and unresolved violations of “Cargo author identity cannot redefine operator trust”.
- [ ] **UC-M04.08-C050-T08 · Evidence hygiene:** Check the “Untrusted enrollment refusal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C050-T09 · Reproduction review:** Have the “Untrusted enrollment refusal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C050-T10 · Acceptance linkage:** Link the “Untrusted enrollment refusal” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Provenance policy checks

**Source delivery:** Require the selected provenance fields and approved builders at admission.

**Source invariant:** A signature cannot substitute for missing required build evidence.

**Source negative case:** An approved key signs an image with absent required provenance.

**Source bounded quantities:** Required fields and provenance graph depth.

### UC-M04.08-C051 · Contract

**Original checklist item:** Specify provenance policy checks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C051-T01 · Scope statement:** Draft the operation boundary for “Provenance policy checks” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Provenance policy checks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C051-T03 · Output inventory:** List the outputs of “Provenance policy checks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Provenance policy checks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C051-T05 · Prerequisite contract:** Map “Provenance policy checks” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Provenance policy checks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C051-T07 · Invariant clause:** Add a normative clause for “Provenance policy checks” that preserves “A signature cannot substitute for missing required build evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Provenance policy checks”; include the source counterexample “An approved key signs an image with absent required provenance” and the intended safe disposition.
- [ ] **UC-M04.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Required fields and provenance graph depth” in the “Provenance policy checks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C051-T10 · Contract review:** Review the “Provenance policy checks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C052 · Delivery

**Original checklist item:** Require the selected provenance fields and approved builders at admission.

- [ ] **UC-M04.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Provenance policy checks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C052-T02 · Change plan:** Break the source delivery for “Provenance policy checks” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Provenance policy checks” that realizes this source instruction: Require the selected provenance fields and approved builders at admission.
- [ ] **UC-M04.08-C052-T04 · Concrete realization:** Trace “Provenance policy checks” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Provenance policy checks” needed to preserve “A signature cannot substitute for missing required build evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C052-T06 · Dependency connection:** Connect the “Provenance policy checks” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C052-T07 · Resource behavior:** Account for “Required fields and provenance graph depth” in “Provenance policy checks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C052-T08 · Delivery check:** Run the smallest real “Provenance policy checks” path and its adverse fixture “An approved key signs an image with absent required provenance”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C052-T09 · Patch review:** Review the “Provenance policy checks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C052-T10 · Delivery handoff:** Publish the “Provenance policy checks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A signature cannot substitute for missing required build evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Provenance policy checks”; copy its required invariant exactly: “A signature cannot substitute for missing required build evidence”.
- [ ] **UC-M04.08-C053-T02 · Observable terms:** Define each term in the “Provenance policy checks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C053-T03 · Precondition set:** List the preconditions under which “A signature cannot substitute for missing required build evidence” must hold for “Provenance policy checks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C053-T04 · Transition coverage:** Map the “Provenance policy checks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Provenance policy checks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C053-T06 · Satisfying fixture:** Create a concrete “Provenance policy checks” case that satisfies “A signature cannot substitute for missing required build evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C053-T07 · Violating fixture:** Create the source counterexample “An approved key signs an image with absent required provenance” for “Provenance policy checks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C053-T08 · Enforcement evidence:** Exercise the “Provenance policy checks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C053-T09 · Regression linkage:** Link the “Provenance policy checks” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Provenance policy checks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C054 · Integration

**Original checklist item:** Integrate provenance policy checks with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Provenance policy checks” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C054-T02 · Field mapping:** Map every “Provenance policy checks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Provenance policy checks” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C054-T04 · Ownership agreement:** Specify who owns “Provenance policy checks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C054-T05 · Handoff implementation:** Connect “Provenance policy checks” through the mapped seam using the real adapter or explicit specification reference; preserve “A signature cannot substitute for missing required build evidence” across the handoff.
- [ ] **UC-M04.08-C054-T06 · Absent-input case:** Omit one required “Provenance policy checks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C054-T07 · Stale-input case:** Supply an outdated “Provenance policy checks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Provenance policy checks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C054-T09 · Valid integration trace:** Run a valid “Provenance policy checks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C054-T10 · Seam review:** Reconcile the “Provenance policy checks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for provenance policy checks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Provenance policy checks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C055-T02 · Expected-result oracle:** Specify the “Provenance policy checks” expected result independently of the implementation output; include the property “A signature cannot substitute for missing required build evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C055-T03 · Fixture material:** Create the concrete “Provenance policy checks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C055-T04 · Target preparation:** Prepare the “Provenance policy checks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C055-T05 · Initial-state record:** Record the initial “Provenance policy checks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C055-T06 · Valid-path execution:** Execute the “Provenance policy checks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C055-T07 · Outcome comparison:** Compare every declared “Provenance policy checks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C055-T08 · State and bounds check:** Inspect the “Provenance policy checks” ownership/state effects and actual use of “Required fields and provenance graph depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C055-T09 · Repeatability check:** Repeat the same “Provenance policy checks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C055-T10 · Positive evidence:** Attach the “Provenance policy checks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C056 · Negative test

**Original checklist item:** Negative case: An approved key signs an image with absent required provenance. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Provenance policy checks” source counterexample: “An approved key signs an image with absent required provenance”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Provenance policy checks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C056-T03 · Valid control:** Construct a valid “Provenance policy checks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C056-T04 · Minimal adverse input:** Derive the “Provenance policy checks” adverse fixture from the control with the smallest documented change needed to reproduce “An approved key signs an image with absent required provenance”; retain that change as reproducible data.
- [ ] **UC-M04.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Provenance policy checks”; require “A signature cannot substitute for missing required build evidence” and forbid a false-success verdict.
- [ ] **UC-M04.08-C056-T06 · Adverse execution:** Exercise the “Provenance policy checks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C056-T07 · Effect inspection:** Inspect “Provenance policy checks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C056-T08 · Refusal versus failure:** Confirm the “Provenance policy checks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C056-T09 · Reset and retention:** Restore only the disposable “Provenance policy checks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C056-T10 · Negative regression:** Register the “Provenance policy checks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C057 · Change / failure test

**Original checklist item:** Exercise provenance policy checks when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C057-T01 · Scenario record:** Write the “Provenance policy checks” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “A signature cannot substitute for missing required build evidence”.
- [ ] **UC-M04.08-C057-T02 · Baseline capture:** Create a known-valid “Provenance policy checks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C057-T03 · Injection map:** Locate the “Provenance policy checks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Provenance policy checks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C057-T05 · Controlled trigger:** Introduce the controlled “Provenance policy checks” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C057-T06 · Intermediate inspection:** Inspect the “Provenance policy checks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Provenance policy checks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Provenance policy checks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C057-T09 · Repeat and compare:** Repeat the selected “Provenance policy checks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C057-T10 · Failure evidence:** Publish the “Provenance policy checks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C058 · Bounds

**Original checklist item:** Choose, document and test limits for required fields and provenance graph depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Provenance policy checks”: “Required fields and provenance graph depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C058-T02 · Measurement method:** Choose how to observe each “Provenance policy checks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C058-T03 · Budget decision:** Select justified resource and input limits for “Provenance policy checks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Provenance policy checks” cases for “Required fields and provenance graph depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Provenance policy checks” limit; preserve “A signature cannot substitute for missing required build evidence”.
- [ ] **UC-M04.08-C058-T06 · Normal measurement:** Run or review the normal “Provenance policy checks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C058-T07 · At-limit measurement:** Exercise the “Provenance policy checks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C058-T08 · Over-limit measurement:** Exercise the “Provenance policy checks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C058-T09 · Uncovered-scope report:** List the “Provenance policy checks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C058-T10 · Limit evidence:** Publish the selected “Provenance policy checks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for provenance policy checks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C059-T01 · Event inventory:** List the “Provenance policy checks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Provenance policy checks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C059-T03 · Failure mapping:** Map each documented “Provenance policy checks” refusal or error to a diagnostic outcome; include “An approved key signs an image with absent required provenance” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C059-T04 · Emission path:** Add the “Provenance policy checks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C059-T05 · Redaction check:** Test “Provenance policy checks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C059-T06 · Output budget:** Set and exercise bounded “Provenance policy checks” message size, rate and retention compatible with “Required fields and provenance graph depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C059-T07 · Success/refusal fixtures:** Capture “Provenance policy checks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Provenance policy checks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C059-T09 · Operator review:** Read the “Provenance policy checks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C059-T10 · Diagnostic evidence:** Publish redacted “Provenance policy checks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for provenance policy checks; label unexecuted checks as untested.

- [ ] **UC-M04.08-C060-T01 · Evidence inventory:** List the “Provenance policy checks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C060-T02 · Artifact references:** Record the exact “Provenance policy checks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C060-T03 · Fixture references:** Attach the “Provenance policy checks” fixture IDs, input identities and oracle definition; preserve the source counterexample “An approved key signs an image with absent required provenance” as a distinct evidence case.
- [ ] **UC-M04.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Provenance policy checks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C060-T05 · Environment record:** Record the actual “Provenance policy checks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C060-T06 · Expected versus observed:** Pair every “Provenance policy checks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C060-T07 · Failure and limit records:** Attach “Provenance policy checks” change/failure and bounds evidence where required; include uncovered “Required fields and provenance graph depth” and unresolved violations of “A signature cannot substitute for missing required build evidence”.
- [ ] **UC-M04.08-C060-T08 · Evidence hygiene:** Check the “Provenance policy checks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C060-T09 · Reproduction review:** Have the “Provenance policy checks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C060-T10 · Acceptance linkage:** Link the “Provenance policy checks” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Policy failure disposition

**Source delivery:** Return a distinct refusal for authentication or authorization failure.

**Source invariant:** Signature failure cannot degrade into checksum-only acceptance.

**Source negative case:** The verifier fails and the caller proceeds using file hashes alone.

**Source bounded quantities:** Error bytes and retry attempts.

### UC-M04.08-C061 · Contract

**Original checklist item:** Specify policy failure disposition inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C061-T01 · Scope statement:** Draft the operation boundary for “Policy failure disposition” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Policy failure disposition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C061-T03 · Output inventory:** List the outputs of “Policy failure disposition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Policy failure disposition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C061-T05 · Prerequisite contract:** Map “Policy failure disposition” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C061-T06 · Authority map:** Identify who may produce, change and consume “Policy failure disposition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C061-T07 · Invariant clause:** Add a normative clause for “Policy failure disposition” that preserves “Signature failure cannot degrade into checksum-only acceptance”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Policy failure disposition”; include the source counterexample “The verifier fails and the caller proceeds using file hashes alone” and the intended safe disposition.
- [ ] **UC-M04.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Error bytes and retry attempts” in the “Policy failure disposition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C061-T10 · Contract review:** Review the “Policy failure disposition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C062 · Delivery

**Original checklist item:** Return a distinct refusal for authentication or authorization failure.

- [ ] **UC-M04.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Policy failure disposition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C062-T02 · Change plan:** Break the source delivery for “Policy failure disposition” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Policy failure disposition” that realizes this source instruction: Return a distinct refusal for authentication or authorization failure.
- [ ] **UC-M04.08-C062-T04 · Concrete realization:** Trace “Policy failure disposition” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Policy failure disposition” needed to preserve “Signature failure cannot degrade into checksum-only acceptance”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C062-T06 · Dependency connection:** Connect the “Policy failure disposition” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C062-T07 · Resource behavior:** Account for “Error bytes and retry attempts” in “Policy failure disposition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C062-T08 · Delivery check:** Run the smallest real “Policy failure disposition” path and its adverse fixture “The verifier fails and the caller proceeds using file hashes alone”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C062-T09 · Patch review:** Review the “Policy failure disposition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C062-T10 · Delivery handoff:** Publish the “Policy failure disposition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Signature failure cannot degrade into checksum-only acceptance. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “Policy failure disposition”; copy its required invariant exactly: “Signature failure cannot degrade into checksum-only acceptance”.
- [ ] **UC-M04.08-C063-T02 · Observable terms:** Define each term in the “Policy failure disposition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C063-T03 · Precondition set:** List the preconditions under which “Signature failure cannot degrade into checksum-only acceptance” must hold for “Policy failure disposition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C063-T04 · Transition coverage:** Map the “Policy failure disposition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Policy failure disposition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C063-T06 · Satisfying fixture:** Create a concrete “Policy failure disposition” case that satisfies “Signature failure cannot degrade into checksum-only acceptance”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C063-T07 · Violating fixture:** Create the source counterexample “The verifier fails and the caller proceeds using file hashes alone” for “Policy failure disposition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C063-T08 · Enforcement evidence:** Exercise the “Policy failure disposition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C063-T09 · Regression linkage:** Link the “Policy failure disposition” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C063-T10 · Property disposition:** Compare the satisfying and violating “Policy failure disposition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C064 · Integration

**Original checklist item:** Integrate policy failure disposition with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Policy failure disposition” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C064-T02 · Field mapping:** Map every “Policy failure disposition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Policy failure disposition” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C064-T04 · Ownership agreement:** Specify who owns “Policy failure disposition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C064-T05 · Handoff implementation:** Connect “Policy failure disposition” through the mapped seam using the real adapter or explicit specification reference; preserve “Signature failure cannot degrade into checksum-only acceptance” across the handoff.
- [ ] **UC-M04.08-C064-T06 · Absent-input case:** Omit one required “Policy failure disposition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C064-T07 · Stale-input case:** Supply an outdated “Policy failure disposition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C064-T08 · Incompatible-input case:** Supply an incompatible “Policy failure disposition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C064-T09 · Valid integration trace:** Run a valid “Policy failure disposition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C064-T10 · Seam review:** Reconcile the “Policy failure disposition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for policy failure disposition; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Policy failure disposition” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C065-T02 · Expected-result oracle:** Specify the “Policy failure disposition” expected result independently of the implementation output; include the property “Signature failure cannot degrade into checksum-only acceptance” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C065-T03 · Fixture material:** Create the concrete “Policy failure disposition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C065-T04 · Target preparation:** Prepare the “Policy failure disposition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C065-T05 · Initial-state record:** Record the initial “Policy failure disposition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C065-T06 · Valid-path execution:** Execute the “Policy failure disposition” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C065-T07 · Outcome comparison:** Compare every declared “Policy failure disposition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C065-T08 · State and bounds check:** Inspect the “Policy failure disposition” ownership/state effects and actual use of “Error bytes and retry attempts”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C065-T09 · Repeatability check:** Repeat the same “Policy failure disposition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C065-T10 · Positive evidence:** Attach the “Policy failure disposition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C066 · Negative test

**Original checklist item:** Negative case: The verifier fails and the caller proceeds using file hashes alone. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “Policy failure disposition” source counterexample: “The verifier fails and the caller proceeds using file hashes alone”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Policy failure disposition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C066-T03 · Valid control:** Construct a valid “Policy failure disposition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C066-T04 · Minimal adverse input:** Derive the “Policy failure disposition” adverse fixture from the control with the smallest documented change needed to reproduce “The verifier fails and the caller proceeds using file hashes alone”; retain that change as reproducible data.
- [ ] **UC-M04.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Policy failure disposition”; require “Signature failure cannot degrade into checksum-only acceptance” and forbid a false-success verdict.
- [ ] **UC-M04.08-C066-T06 · Adverse execution:** Exercise the “Policy failure disposition” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C066-T07 · Effect inspection:** Inspect “Policy failure disposition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C066-T08 · Refusal versus failure:** Confirm the “Policy failure disposition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C066-T09 · Reset and retention:** Restore only the disposable “Policy failure disposition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C066-T10 · Negative regression:** Register the “Policy failure disposition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C067 · Change / failure test

**Original checklist item:** Exercise policy failure disposition when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C067-T01 · Scenario record:** Write the “Policy failure disposition” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “Signature failure cannot degrade into checksum-only acceptance”.
- [ ] **UC-M04.08-C067-T02 · Baseline capture:** Create a known-valid “Policy failure disposition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C067-T03 · Injection map:** Locate the “Policy failure disposition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Policy failure disposition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C067-T05 · Controlled trigger:** Introduce the controlled “Policy failure disposition” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C067-T06 · Intermediate inspection:** Inspect the “Policy failure disposition” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Policy failure disposition”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Policy failure disposition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C067-T09 · Repeat and compare:** Repeat the selected “Policy failure disposition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C067-T10 · Failure evidence:** Publish the “Policy failure disposition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C068 · Bounds

**Original checklist item:** Choose, document and test limits for error bytes and retry attempts; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “Policy failure disposition”: “Error bytes and retry attempts”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C068-T02 · Measurement method:** Choose how to observe each “Policy failure disposition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C068-T03 · Budget decision:** Select justified resource and input limits for “Policy failure disposition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Policy failure disposition” cases for “Error bytes and retry attempts”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Policy failure disposition” limit; preserve “Signature failure cannot degrade into checksum-only acceptance”.
- [ ] **UC-M04.08-C068-T06 · Normal measurement:** Run or review the normal “Policy failure disposition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C068-T07 · At-limit measurement:** Exercise the “Policy failure disposition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C068-T08 · Over-limit measurement:** Exercise the “Policy failure disposition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C068-T09 · Uncovered-scope report:** List the “Policy failure disposition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C068-T10 · Limit evidence:** Publish the selected “Policy failure disposition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for policy failure disposition with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C069-T01 · Event inventory:** List the “Policy failure disposition” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Policy failure disposition” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C069-T03 · Failure mapping:** Map each documented “Policy failure disposition” refusal or error to a diagnostic outcome; include “The verifier fails and the caller proceeds using file hashes alone” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C069-T04 · Emission path:** Add the “Policy failure disposition” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C069-T05 · Redaction check:** Test “Policy failure disposition” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C069-T06 · Output budget:** Set and exercise bounded “Policy failure disposition” message size, rate and retention compatible with “Error bytes and retry attempts”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C069-T07 · Success/refusal fixtures:** Capture “Policy failure disposition” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Policy failure disposition” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C069-T09 · Operator review:** Read the “Policy failure disposition” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C069-T10 · Diagnostic evidence:** Publish redacted “Policy failure disposition” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for policy failure disposition; label unexecuted checks as untested.

- [ ] **UC-M04.08-C070-T01 · Evidence inventory:** List the “Policy failure disposition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C070-T02 · Artifact references:** Record the exact “Policy failure disposition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C070-T03 · Fixture references:** Attach the “Policy failure disposition” fixture IDs, input identities and oracle definition; preserve the source counterexample “The verifier fails and the caller proceeds using file hashes alone” as a distinct evidence case.
- [ ] **UC-M04.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Policy failure disposition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C070-T05 · Environment record:** Record the actual “Policy failure disposition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C070-T06 · Expected versus observed:** Pair every “Policy failure disposition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C070-T07 · Failure and limit records:** Attach “Policy failure disposition” change/failure and bounds evidence where required; include uncovered “Error bytes and retry attempts” and unresolved violations of “Signature failure cannot degrade into checksum-only acceptance”.
- [ ] **UC-M04.08-C070-T08 · Evidence hygiene:** Check the “Policy failure disposition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C070-T09 · Reproduction review:** Have the “Policy failure disposition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C070-T10 · Acceptance linkage:** Link the “Policy failure disposition” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Admission evidence record

**Source delivery:** Persist image, signer, policy and verification outcome with workload generation.

**Source invariant:** The admitted image can be traced to the authority actually checked.

**Source negative case:** The record contains requested policy but not the applied policy.

**Source bounded quantities:** Record bytes and publication time.

### UC-M04.08-C071 · Contract

**Original checklist item:** Specify admission evidence record inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C071-T01 · Scope statement:** Draft the operation boundary for “Admission evidence record” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Admission evidence record”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C071-T03 · Output inventory:** List the outputs of “Admission evidence record” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Admission evidence record”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C071-T05 · Prerequisite contract:** Map “Admission evidence record” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Admission evidence record”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C071-T07 · Invariant clause:** Add a normative clause for “Admission evidence record” that preserves “The admitted image can be traced to the authority actually checked”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Admission evidence record”; include the source counterexample “The record contains requested policy but not the applied policy” and the intended safe disposition.
- [ ] **UC-M04.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Record bytes and publication time” in the “Admission evidence record” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C071-T10 · Contract review:** Review the “Admission evidence record” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C072 · Delivery

**Original checklist item:** Persist image, signer, policy and verification outcome with workload generation.

- [ ] **UC-M04.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Admission evidence record”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C072-T02 · Change plan:** Break the source delivery for “Admission evidence record” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Admission evidence record” that realizes this source instruction: Persist image, signer, policy and verification outcome with workload generation.
- [ ] **UC-M04.08-C072-T04 · Concrete realization:** Trace “Admission evidence record” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Admission evidence record” needed to preserve “The admitted image can be traced to the authority actually checked”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C072-T06 · Dependency connection:** Connect the “Admission evidence record” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C072-T07 · Resource behavior:** Account for “Record bytes and publication time” in “Admission evidence record”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C072-T08 · Delivery check:** Run the smallest real “Admission evidence record” path and its adverse fixture “The record contains requested policy but not the applied policy”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C072-T09 · Patch review:** Review the “Admission evidence record” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C072-T10 · Delivery handoff:** Publish the “Admission evidence record” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The admitted image can be traced to the authority actually checked. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Admission evidence record”; copy its required invariant exactly: “The admitted image can be traced to the authority actually checked”.
- [ ] **UC-M04.08-C073-T02 · Observable terms:** Define each term in the “Admission evidence record” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C073-T03 · Precondition set:** List the preconditions under which “The admitted image can be traced to the authority actually checked” must hold for “Admission evidence record”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C073-T04 · Transition coverage:** Map the “Admission evidence record” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Admission evidence record”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C073-T06 · Satisfying fixture:** Create a concrete “Admission evidence record” case that satisfies “The admitted image can be traced to the authority actually checked”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C073-T07 · Violating fixture:** Create the source counterexample “The record contains requested policy but not the applied policy” for “Admission evidence record”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C073-T08 · Enforcement evidence:** Exercise the “Admission evidence record” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C073-T09 · Regression linkage:** Link the “Admission evidence record” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Admission evidence record” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C074 · Integration

**Original checklist item:** Integrate admission evidence record with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Admission evidence record” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C074-T02 · Field mapping:** Map every “Admission evidence record” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Admission evidence record” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C074-T04 · Ownership agreement:** Specify who owns “Admission evidence record” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C074-T05 · Handoff implementation:** Connect “Admission evidence record” through the mapped seam using the real adapter or explicit specification reference; preserve “The admitted image can be traced to the authority actually checked” across the handoff.
- [ ] **UC-M04.08-C074-T06 · Absent-input case:** Omit one required “Admission evidence record” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C074-T07 · Stale-input case:** Supply an outdated “Admission evidence record” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Admission evidence record” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C074-T09 · Valid integration trace:** Run a valid “Admission evidence record” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C074-T10 · Seam review:** Reconcile the “Admission evidence record” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for admission evidence record; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Admission evidence record” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C075-T02 · Expected-result oracle:** Specify the “Admission evidence record” expected result independently of the implementation output; include the property “The admitted image can be traced to the authority actually checked” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C075-T03 · Fixture material:** Create the concrete “Admission evidence record” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C075-T04 · Target preparation:** Prepare the “Admission evidence record” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C075-T05 · Initial-state record:** Record the initial “Admission evidence record” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C075-T06 · Valid-path execution:** Execute the “Admission evidence record” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C075-T07 · Outcome comparison:** Compare every declared “Admission evidence record” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C075-T08 · State and bounds check:** Inspect the “Admission evidence record” ownership/state effects and actual use of “Record bytes and publication time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C075-T09 · Repeatability check:** Repeat the same “Admission evidence record” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C075-T10 · Positive evidence:** Attach the “Admission evidence record” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C076 · Negative test

**Original checklist item:** Negative case: The record contains requested policy but not the applied policy. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Admission evidence record” source counterexample: “The record contains requested policy but not the applied policy”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Admission evidence record”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C076-T03 · Valid control:** Construct a valid “Admission evidence record” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C076-T04 · Minimal adverse input:** Derive the “Admission evidence record” adverse fixture from the control with the smallest documented change needed to reproduce “The record contains requested policy but not the applied policy”; retain that change as reproducible data.
- [ ] **UC-M04.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Admission evidence record”; require “The admitted image can be traced to the authority actually checked” and forbid a false-success verdict.
- [ ] **UC-M04.08-C076-T06 · Adverse execution:** Exercise the “Admission evidence record” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C076-T07 · Effect inspection:** Inspect “Admission evidence record” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C076-T08 · Refusal versus failure:** Confirm the “Admission evidence record” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C076-T09 · Reset and retention:** Restore only the disposable “Admission evidence record” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C076-T10 · Negative regression:** Register the “Admission evidence record” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C077 · Change / failure test

**Original checklist item:** Exercise admission evidence record when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C077-T01 · Scenario record:** Write the “Admission evidence record” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “The admitted image can be traced to the authority actually checked”.
- [ ] **UC-M04.08-C077-T02 · Baseline capture:** Create a known-valid “Admission evidence record” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C077-T03 · Injection map:** Locate the “Admission evidence record” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Admission evidence record” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C077-T05 · Controlled trigger:** Introduce the controlled “Admission evidence record” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C077-T06 · Intermediate inspection:** Inspect the “Admission evidence record” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Admission evidence record”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Admission evidence record” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C077-T09 · Repeat and compare:** Repeat the selected “Admission evidence record” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C077-T10 · Failure evidence:** Publish the “Admission evidence record” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C078 · Bounds

**Original checklist item:** Choose, document and test limits for record bytes and publication time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Admission evidence record”: “Record bytes and publication time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C078-T02 · Measurement method:** Choose how to observe each “Admission evidence record” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C078-T03 · Budget decision:** Select justified resource and input limits for “Admission evidence record”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Admission evidence record” cases for “Record bytes and publication time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Admission evidence record” limit; preserve “The admitted image can be traced to the authority actually checked”.
- [ ] **UC-M04.08-C078-T06 · Normal measurement:** Run or review the normal “Admission evidence record” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C078-T07 · At-limit measurement:** Exercise the “Admission evidence record” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C078-T08 · Over-limit measurement:** Exercise the “Admission evidence record” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C078-T09 · Uncovered-scope report:** List the “Admission evidence record” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C078-T10 · Limit evidence:** Publish the selected “Admission evidence record” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for admission evidence record with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C079-T01 · Event inventory:** List the “Admission evidence record” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Admission evidence record” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C079-T03 · Failure mapping:** Map each documented “Admission evidence record” refusal or error to a diagnostic outcome; include “The record contains requested policy but not the applied policy” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C079-T04 · Emission path:** Add the “Admission evidence record” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C079-T05 · Redaction check:** Test “Admission evidence record” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C079-T06 · Output budget:** Set and exercise bounded “Admission evidence record” message size, rate and retention compatible with “Record bytes and publication time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C079-T07 · Success/refusal fixtures:** Capture “Admission evidence record” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Admission evidence record” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C079-T09 · Operator review:** Read the “Admission evidence record” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C079-T10 · Diagnostic evidence:** Publish redacted “Admission evidence record” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for admission evidence record; label unexecuted checks as untested.

- [ ] **UC-M04.08-C080-T01 · Evidence inventory:** List the “Admission evidence record” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C080-T02 · Artifact references:** Record the exact “Admission evidence record” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C080-T03 · Fixture references:** Attach the “Admission evidence record” fixture IDs, input identities and oracle definition; preserve the source counterexample “The record contains requested policy but not the applied policy” as a distinct evidence case.
- [ ] **UC-M04.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Admission evidence record”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C080-T05 · Environment record:** Record the actual “Admission evidence record” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C080-T06 · Expected versus observed:** Pair every “Admission evidence record” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C080-T07 · Failure and limit records:** Attach “Admission evidence record” change/failure and bounds evidence where required; include uncovered “Record bytes and publication time” and unresolved violations of “The admitted image can be traced to the authority actually checked”.
- [ ] **UC-M04.08-C080-T08 · Evidence hygiene:** Check the “Admission evidence record” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C080-T09 · Reproduction review:** Have the “Admission evidence record” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C080-T10 · Acceptance linkage:** Link the “Admission evidence record” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Trust-policy changes

**Source delivery:** Reevaluate future admissions when approved roots or signer policy change.

**Source invariant:** A removed signer cannot remain approved through stale cached decisions.

**Source negative case:** A signer is revoked while an old approval cache remains.

**Source bounded quantities:** Cache lifetime and invalidation fan-out.

### UC-M04.08-C081 · Contract

**Original checklist item:** Specify trust-policy changes inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C081-T01 · Scope statement:** Draft the operation boundary for “Trust-policy changes” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Trust-policy changes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C081-T03 · Output inventory:** List the outputs of “Trust-policy changes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Trust-policy changes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C081-T05 · Prerequisite contract:** Map “Trust-policy changes” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Trust-policy changes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C081-T07 · Invariant clause:** Add a normative clause for “Trust-policy changes” that preserves “A removed signer cannot remain approved through stale cached decisions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Trust-policy changes”; include the source counterexample “A signer is revoked while an old approval cache remains” and the intended safe disposition.
- [ ] **UC-M04.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Cache lifetime and invalidation fan-out” in the “Trust-policy changes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C081-T10 · Contract review:** Review the “Trust-policy changes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C082 · Delivery

**Original checklist item:** Reevaluate future admissions when approved roots or signer policy change.

- [ ] **UC-M04.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Trust-policy changes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C082-T02 · Change plan:** Break the source delivery for “Trust-policy changes” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Trust-policy changes” that realizes this source instruction: Reevaluate future admissions when approved roots or signer policy change.
- [ ] **UC-M04.08-C082-T04 · Concrete realization:** Trace “Trust-policy changes” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M04.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Trust-policy changes” needed to preserve “A removed signer cannot remain approved through stale cached decisions”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C082-T06 · Dependency connection:** Connect the “Trust-policy changes” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C082-T07 · Resource behavior:** Account for “Cache lifetime and invalidation fan-out” in “Trust-policy changes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C082-T08 · Delivery check:** Run the smallest real “Trust-policy changes” path and its adverse fixture “A signer is revoked while an old approval cache remains”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C082-T09 · Patch review:** Review the “Trust-policy changes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C082-T10 · Delivery handoff:** Publish the “Trust-policy changes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A removed signer cannot remain approved through stale cached decisions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Trust-policy changes”; copy its required invariant exactly: “A removed signer cannot remain approved through stale cached decisions”.
- [ ] **UC-M04.08-C083-T02 · Observable terms:** Define each term in the “Trust-policy changes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C083-T03 · Precondition set:** List the preconditions under which “A removed signer cannot remain approved through stale cached decisions” must hold for “Trust-policy changes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C083-T04 · Transition coverage:** Map the “Trust-policy changes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Trust-policy changes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C083-T06 · Satisfying fixture:** Create a concrete “Trust-policy changes” case that satisfies “A removed signer cannot remain approved through stale cached decisions”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C083-T07 · Violating fixture:** Create the source counterexample “A signer is revoked while an old approval cache remains” for “Trust-policy changes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C083-T08 · Enforcement evidence:** Exercise the “Trust-policy changes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C083-T09 · Regression linkage:** Link the “Trust-policy changes” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Trust-policy changes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C084 · Integration

**Original checklist item:** Integrate trust-policy changes with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Trust-policy changes” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C084-T02 · Field mapping:** Map every “Trust-policy changes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Trust-policy changes” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C084-T04 · Ownership agreement:** Specify who owns “Trust-policy changes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C084-T05 · Handoff implementation:** Connect “Trust-policy changes” through the mapped seam using the real adapter or explicit specification reference; preserve “A removed signer cannot remain approved through stale cached decisions” across the handoff.
- [ ] **UC-M04.08-C084-T06 · Absent-input case:** Omit one required “Trust-policy changes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C084-T07 · Stale-input case:** Supply an outdated “Trust-policy changes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Trust-policy changes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C084-T09 · Valid integration trace:** Run a valid “Trust-policy changes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C084-T10 · Seam review:** Reconcile the “Trust-policy changes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for trust-policy changes; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Trust-policy changes” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C085-T02 · Expected-result oracle:** Specify the “Trust-policy changes” expected result independently of the implementation output; include the property “A removed signer cannot remain approved through stale cached decisions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C085-T03 · Fixture material:** Create the concrete “Trust-policy changes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C085-T04 · Target preparation:** Prepare the “Trust-policy changes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C085-T05 · Initial-state record:** Record the initial “Trust-policy changes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C085-T06 · Valid-path execution:** Execute the “Trust-policy changes” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C085-T07 · Outcome comparison:** Compare every declared “Trust-policy changes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C085-T08 · State and bounds check:** Inspect the “Trust-policy changes” ownership/state effects and actual use of “Cache lifetime and invalidation fan-out”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C085-T09 · Repeatability check:** Repeat the same “Trust-policy changes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C085-T10 · Positive evidence:** Attach the “Trust-policy changes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C086 · Negative test

**Original checklist item:** Negative case: A signer is revoked while an old approval cache remains. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Trust-policy changes” source counterexample: “A signer is revoked while an old approval cache remains”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Trust-policy changes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C086-T03 · Valid control:** Construct a valid “Trust-policy changes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C086-T04 · Minimal adverse input:** Derive the “Trust-policy changes” adverse fixture from the control with the smallest documented change needed to reproduce “A signer is revoked while an old approval cache remains”; retain that change as reproducible data.
- [ ] **UC-M04.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Trust-policy changes”; require “A removed signer cannot remain approved through stale cached decisions” and forbid a false-success verdict.
- [ ] **UC-M04.08-C086-T06 · Adverse execution:** Exercise the “Trust-policy changes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C086-T07 · Effect inspection:** Inspect “Trust-policy changes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C086-T08 · Refusal versus failure:** Confirm the “Trust-policy changes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C086-T09 · Reset and retention:** Restore only the disposable “Trust-policy changes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C086-T10 · Negative regression:** Register the “Trust-policy changes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C087 · Change / failure test

**Original checklist item:** Exercise trust-policy changes when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C087-T01 · Scenario record:** Write the “Trust-policy changes” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “A removed signer cannot remain approved through stale cached decisions”.
- [ ] **UC-M04.08-C087-T02 · Baseline capture:** Create a known-valid “Trust-policy changes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C087-T03 · Injection map:** Locate the “Trust-policy changes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Trust-policy changes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C087-T05 · Controlled trigger:** Introduce the controlled “Trust-policy changes” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C087-T06 · Intermediate inspection:** Inspect the “Trust-policy changes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Trust-policy changes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Trust-policy changes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C087-T09 · Repeat and compare:** Repeat the selected “Trust-policy changes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C087-T10 · Failure evidence:** Publish the “Trust-policy changes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C088 · Bounds

**Original checklist item:** Choose, document and test limits for cache lifetime and invalidation fan-out; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Trust-policy changes”: “Cache lifetime and invalidation fan-out”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C088-T02 · Measurement method:** Choose how to observe each “Trust-policy changes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C088-T03 · Budget decision:** Select justified resource and input limits for “Trust-policy changes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Trust-policy changes” cases for “Cache lifetime and invalidation fan-out”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Trust-policy changes” limit; preserve “A removed signer cannot remain approved through stale cached decisions”.
- [ ] **UC-M04.08-C088-T06 · Normal measurement:** Run or review the normal “Trust-policy changes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C088-T07 · At-limit measurement:** Exercise the “Trust-policy changes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C088-T08 · Over-limit measurement:** Exercise the “Trust-policy changes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C088-T09 · Uncovered-scope report:** List the “Trust-policy changes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C088-T10 · Limit evidence:** Publish the selected “Trust-policy changes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for trust-policy changes with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C089-T01 · Event inventory:** List the “Trust-policy changes” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Trust-policy changes” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C089-T03 · Failure mapping:** Map each documented “Trust-policy changes” refusal or error to a diagnostic outcome; include “A signer is revoked while an old approval cache remains” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C089-T04 · Emission path:** Add the “Trust-policy changes” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C089-T05 · Redaction check:** Test “Trust-policy changes” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C089-T06 · Output budget:** Set and exercise bounded “Trust-policy changes” message size, rate and retention compatible with “Cache lifetime and invalidation fan-out”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C089-T07 · Success/refusal fixtures:** Capture “Trust-policy changes” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Trust-policy changes” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C089-T09 · Operator review:** Read the “Trust-policy changes” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C089-T10 · Diagnostic evidence:** Publish redacted “Trust-policy changes” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for trust-policy changes; label unexecuted checks as untested.

- [ ] **UC-M04.08-C090-T01 · Evidence inventory:** List the “Trust-policy changes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C090-T02 · Artifact references:** Record the exact “Trust-policy changes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C090-T03 · Fixture references:** Attach the “Trust-policy changes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A signer is revoked while an old approval cache remains” as a distinct evidence case.
- [ ] **UC-M04.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Trust-policy changes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C090-T05 · Environment record:** Record the actual “Trust-policy changes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C090-T06 · Expected versus observed:** Pair every “Trust-policy changes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C090-T07 · Failure and limit records:** Attach “Trust-policy changes” change/failure and bounds evidence where required; include uncovered “Cache lifetime and invalidation fan-out” and unresolved violations of “A removed signer cannot remain approved through stale cached decisions”.
- [ ] **UC-M04.08-C090-T08 · Evidence hygiene:** Check the “Trust-policy changes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C090-T09 · Reproduction review:** Have the “Trust-policy changes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C090-T10 · Acceptance linkage:** Link the “Trust-policy changes” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Independent refusal tests

**Source delivery:** Test intact self-signed, wrong-subject and unapproved-signer images.

**Source invariant:** Cryptographically intact but unauthorized images are refused.

**Source negative case:** A self-signed image passes because its internal checksums are correct.

**Source bounded quantities:** Fixture count and verification runtime.

### UC-M04.08-C091 · Contract

**Original checklist item:** Specify independent refusal tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M04.08-C091-T01 · Scope statement:** Draft the operation boundary for “Independent refusal tests” within Authenticated image admission; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M04.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Independent refusal tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M04.08-C091-T03 · Output inventory:** List the outputs of “Independent refusal tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M04.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Independent refusal tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M04.08-C091-T05 · Prerequisite contract:** Map “Independent refusal tests” to the source component prerequisites (UC-M04.05, UC-M04.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M04.08-C091-T06 · Authority map:** Identify who may produce, change and consume “Independent refusal tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M04.08-C091-T07 · Invariant clause:** Add a normative clause for “Independent refusal tests” that preserves “Cryptographically intact but unauthorized images are refused”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M04.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Independent refusal tests”; include the source counterexample “A self-signed image passes because its internal checksums are correct” and the intended safe disposition.
- [ ] **UC-M04.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture count and verification runtime” in the “Independent refusal tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M04.08-C091-T10 · Contract review:** Review the “Independent refusal tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M04.08-C092 · Delivery

**Original checklist item:** Test intact self-signed, wrong-subject and unapproved-signer images.

- [ ] **UC-M04.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Independent refusal tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M04.08-C092-T02 · Change plan:** Break the source delivery for “Independent refusal tests” into concrete edit targets and reviewable outputs; keep the UC-M04.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M04.08-C092-T03 · Core artifact:** Create the “Independent refusal tests” fixture or harness for this source instruction: Test intact self-signed, wrong-subject and unapproved-signer images.
- [ ] **UC-M04.08-C092-T04 · Concrete realization:** Connect the “Independent refusal tests” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M04.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Independent refusal tests” needed to preserve “Cryptographically intact but unauthorized images are refused”; record an enforcement gap where only a model exists.
- [ ] **UC-M04.08-C092-T06 · Dependency connection:** Connect the “Independent refusal tests” implementation to operator trust configuration, provenance policy and pre-execution admission; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M04.08-C092-T07 · Resource behavior:** Account for “Fixture count and verification runtime” in “Independent refusal tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M04.08-C092-T08 · Delivery check:** Run the smallest real “Independent refusal tests” path and its adverse fixture “A self-signed image passes because its internal checksums are correct”; retain actual output, state effects and final disposition.
- [ ] **UC-M04.08-C092-T09 · Patch review:** Review the “Independent refusal tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M04.08-C092-T10 · Delivery handoff:** Publish the “Independent refusal tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M04.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Cryptographically intact but unauthorized images are refused. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M04.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “Independent refusal tests”; copy its required invariant exactly: “Cryptographically intact but unauthorized images are refused”.
- [ ] **UC-M04.08-C093-T02 · Observable terms:** Define each term in the “Independent refusal tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M04.08-C093-T03 · Precondition set:** List the preconditions under which “Cryptographically intact but unauthorized images are refused” must hold for “Independent refusal tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M04.08-C093-T04 · Transition coverage:** Map the “Independent refusal tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M04.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Independent refusal tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M04.08-C093-T06 · Satisfying fixture:** Create a concrete “Independent refusal tests” case that satisfies “Cryptographically intact but unauthorized images are refused”; record its expected observation before running the assertion or review.
- [ ] **UC-M04.08-C093-T07 · Violating fixture:** Create the source counterexample “A self-signed image passes because its internal checksums are correct” for “Independent refusal tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M04.08-C093-T08 · Enforcement evidence:** Exercise the “Independent refusal tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M04.08-C093-T09 · Regression linkage:** Link the “Independent refusal tests” property to changes in operator trust configuration, provenance policy and pre-execution admission; record which dependency or contract changes require rerunning it.
- [ ] **UC-M04.08-C093-T10 · Property disposition:** Compare the satisfying and violating “Independent refusal tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M04.08-C094 · Integration

**Original checklist item:** Integrate independent refusal tests with operator trust configuration, provenance policy and pre-execution admission; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M04.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Independent refusal tests” across operator trust configuration, provenance policy and pre-execution admission; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M04.08-C094-T02 · Field mapping:** Map every “Independent refusal tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M04.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Independent refusal tests” (source dependency list: UC-M04.05, UC-M04.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M04.08-C094-T04 · Ownership agreement:** Specify who owns “Independent refusal tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M04.08-C094-T05 · Handoff implementation:** Connect “Independent refusal tests” through the mapped seam using the real adapter or explicit specification reference; preserve “Cryptographically intact but unauthorized images are refused” across the handoff.
- [ ] **UC-M04.08-C094-T06 · Absent-input case:** Omit one required “Independent refusal tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M04.08-C094-T07 · Stale-input case:** Supply an outdated “Independent refusal tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M04.08-C094-T08 · Incompatible-input case:** Supply an incompatible “Independent refusal tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M04.08-C094-T09 · Valid integration trace:** Run a valid “Independent refusal tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M04.08-C094-T10 · Seam review:** Reconcile the “Independent refusal tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M04.08-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for independent refusal tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M04.08-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Independent refusal tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M04.08-C095-T02 · Expected-result oracle:** Specify the “Independent refusal tests” expected result independently of the implementation output; include the property “Cryptographically intact but unauthorized images are refused” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M04.08-C095-T03 · Fixture material:** Create the concrete “Independent refusal tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M04.08-C095-T04 · Target preparation:** Prepare the “Independent refusal tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M04.08-C095-T05 · Initial-state record:** Record the initial “Independent refusal tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M04.08-C095-T06 · Valid-path execution:** Execute the “Independent refusal tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M04.08-C095-T07 · Outcome comparison:** Compare every declared “Independent refusal tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M04.08-C095-T08 · State and bounds check:** Inspect the “Independent refusal tests” ownership/state effects and actual use of “Fixture count and verification runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M04.08-C095-T09 · Repeatability check:** Repeat the same “Independent refusal tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M04.08-C095-T10 · Positive evidence:** Attach the “Independent refusal tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M04.08-C096 · Negative test

**Original checklist item:** Negative case: A self-signed image passes because its internal checksums are correct. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M04.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “Independent refusal tests” source counterexample: “A self-signed image passes because its internal checksums are correct”; state which precondition or invariant it challenges.
- [ ] **UC-M04.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Independent refusal tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M04.08-C096-T03 · Valid control:** Construct a valid “Independent refusal tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M04.08-C096-T04 · Minimal adverse input:** Derive the “Independent refusal tests” adverse fixture from the control with the smallest documented change needed to reproduce “A self-signed image passes because its internal checksums are correct”; retain that change as reproducible data.
- [ ] **UC-M04.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Independent refusal tests”; require “Cryptographically intact but unauthorized images are refused” and forbid a false-success verdict.
- [ ] **UC-M04.08-C096-T06 · Adverse execution:** Exercise the “Independent refusal tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M04.08-C096-T07 · Effect inspection:** Inspect “Independent refusal tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M04.08-C096-T08 · Refusal versus failure:** Confirm the “Independent refusal tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M04.08-C096-T09 · Reset and retention:** Restore only the disposable “Independent refusal tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M04.08-C096-T10 · Negative regression:** Register the “Independent refusal tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M04.08-C097 · Change / failure test

**Original checklist item:** Exercise independent refusal tests when the signer policy changes while an image waits for execution; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M04.08-C097-T01 · Scenario record:** Write the “Independent refusal tests” change/failure scenario exactly as supplied: the signer policy changes while an image waits for execution; identify the property that must remain true: “Cryptographically intact but unauthorized images are refused”.
- [ ] **UC-M04.08-C097-T02 · Baseline capture:** Create a known-valid “Independent refusal tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M04.08-C097-T03 · Injection map:** Locate the “Independent refusal tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M04.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Independent refusal tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M04.08-C097-T05 · Controlled trigger:** Introduce the controlled “Independent refusal tests” scenario in the disposable fixture: the signer policy changes while an image waits for execution; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M04.08-C097-T06 · Intermediate inspection:** Inspect the “Independent refusal tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M04.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Independent refusal tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M04.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Independent refusal tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M04.08-C097-T09 · Repeat and compare:** Repeat the selected “Independent refusal tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M04.08-C097-T10 · Failure evidence:** Publish the “Independent refusal tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M04.08-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fixture count and verification runtime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M04.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “Independent refusal tests”: “Fixture count and verification runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M04.08-C098-T02 · Measurement method:** Choose how to observe each “Independent refusal tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M04.08-C098-T03 · Budget decision:** Select justified resource and input limits for “Independent refusal tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M04.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Independent refusal tests” cases for “Fixture count and verification runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M04.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Independent refusal tests” limit; preserve “Cryptographically intact but unauthorized images are refused”.
- [ ] **UC-M04.08-C098-T06 · Normal measurement:** Run or review the normal “Independent refusal tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M04.08-C098-T07 · At-limit measurement:** Exercise the “Independent refusal tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M04.08-C098-T08 · Over-limit measurement:** Exercise the “Independent refusal tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M04.08-C098-T09 · Uncovered-scope report:** List the “Independent refusal tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M04.08-C098-T10 · Limit evidence:** Publish the selected “Independent refusal tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M04.08-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for independent refusal tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M04.08-C099-T01 · Event inventory:** List the “Independent refusal tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M04.08-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Independent refusal tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M04.08-C099-T03 · Failure mapping:** Map each documented “Independent refusal tests” refusal or error to a diagnostic outcome; include “A self-signed image passes because its internal checksums are correct” and prohibit conversion into a success message.
- [ ] **UC-M04.08-C099-T04 · Emission path:** Add the “Independent refusal tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M04.08-C099-T05 · Redaction check:** Test “Independent refusal tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M04.08-C099-T06 · Output budget:** Set and exercise bounded “Independent refusal tests” message size, rate and retention compatible with “Fixture count and verification runtime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M04.08-C099-T07 · Success/refusal fixtures:** Capture “Independent refusal tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M04.08-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Independent refusal tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M04.08-C099-T09 · Operator review:** Read the “Independent refusal tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M04.08-C099-T10 · Diagnostic evidence:** Publish redacted “Independent refusal tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M04.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for independent refusal tests; label unexecuted checks as untested.

- [ ] **UC-M04.08-C100-T01 · Evidence inventory:** List the “Independent refusal tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M04.08-C100-T02 · Artifact references:** Record the exact “Independent refusal tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M04.08-C100-T03 · Fixture references:** Attach the “Independent refusal tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “A self-signed image passes because its internal checksums are correct” as a distinct evidence case.
- [ ] **UC-M04.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Independent refusal tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M04.08-C100-T05 · Environment record:** Record the actual “Independent refusal tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M04.08-C100-T06 · Expected versus observed:** Pair every “Independent refusal tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M04.08-C100-T07 · Failure and limit records:** Attach “Independent refusal tests” change/failure and bounds evidence where required; include uncovered “Fixture count and verification runtime” and unresolved violations of “Cryptographically intact but unauthorized images are refused”.
- [ ] **UC-M04.08-C100-T08 · Evidence hygiene:** Check the “Independent refusal tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M04.08-C100-T09 · Reproduction review:** Have the “Independent refusal tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M04.08-C100-T10 · Acceptance linkage:** Link the “Independent refusal tests” evidence to its parent and UC-M04.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

