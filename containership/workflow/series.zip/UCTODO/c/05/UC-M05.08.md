# UC-M05.08 — Replica scaling and placement migration

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/05.md)

| Field | Preserved source value |
|---|---|
| Workstream | 05. Workload orchestration and scheduling |
| Milestone | C |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M05.02](../05/UC-M05.02.md), [UC-M05.06](../05/UC-M05.06.md), [UC-M05.07](../05/UC-M05.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S6]. |

## Original requirement

Add explicit stateless/stateful scaling semantics, allocation reservations and drain-before-replace behavior.

**Original acceptance criterion:** Scaling out or in respects application state semantics and does not lose accepted requests or bypass quotas.

**Source trace:** Original checklist `UC100/c/05/UC-M05.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 506–517 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Scaling applicability

**Source delivery:** Declare stateless or stateful scaling semantics for the selected application.

**Source invariant:** Scaling is enabled only when the workload's state model supports it.

**Source negative case:** A stateful workload is duplicated as though it were stateless.

**Source bounded quantities:** Supported scaling profiles and replica range.

### UC-M05.08-C001 · Contract

**Original checklist item:** Specify scaling applicability inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C001-T01 · Scope statement:** Draft the operation boundary for “Scaling applicability” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scaling applicability”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C001-T03 · Output inventory:** List the outputs of “Scaling applicability” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Scaling applicability”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C001-T05 · Prerequisite contract:** Map “Scaling applicability” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C001-T06 · Authority map:** Identify who may produce, change and consume “Scaling applicability”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C001-T07 · Invariant clause:** Add a normative clause for “Scaling applicability” that preserves “Scaling is enabled only when the workload's state model supports it”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scaling applicability”; include the source counterexample “A stateful workload is duplicated as though it were stateless” and the intended safe disposition.
- [ ] **UC-M05.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Supported scaling profiles and replica range” in the “Scaling applicability” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C001-T10 · Contract review:** Review the “Scaling applicability” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C002 · Delivery

**Original checklist item:** Declare stateless or stateful scaling semantics for the selected application.

- [ ] **UC-M05.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scaling applicability”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C002-T02 · Change plan:** Break the source delivery for “Scaling applicability” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C002-T03 · Core artifact:** Create the “Scaling applicability” model, schema or inventory that realizes this source instruction: Declare stateless or stateful scaling semantics for the selected application.
- [ ] **UC-M05.08-C002-T04 · Concrete realization:** Populate “Scaling applicability” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scaling applicability” needed to preserve “Scaling is enabled only when the workload's state model supports it”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C002-T06 · Dependency connection:** Connect the “Scaling applicability” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C002-T07 · Resource behavior:** Account for “Supported scaling profiles and replica range” in “Scaling applicability”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C002-T08 · Delivery check:** Run the smallest real “Scaling applicability” path and its adverse fixture “A stateful workload is duplicated as though it were stateless”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C002-T09 · Patch review:** Review the “Scaling applicability” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C002-T10 · Delivery handoff:** Publish the “Scaling applicability” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Scaling is enabled only when the workload's state model supports it. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “Scaling applicability”; copy its required invariant exactly: “Scaling is enabled only when the workload's state model supports it”.
- [ ] **UC-M05.08-C003-T02 · Observable terms:** Define each term in the “Scaling applicability” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C003-T03 · Precondition set:** List the preconditions under which “Scaling is enabled only when the workload's state model supports it” must hold for “Scaling applicability”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C003-T04 · Transition coverage:** Map the “Scaling applicability” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scaling applicability”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C003-T06 · Satisfying fixture:** Create a concrete “Scaling applicability” case that satisfies “Scaling is enabled only when the workload's state model supports it”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C003-T07 · Violating fixture:** Create the source counterexample “A stateful workload is duplicated as though it were stateless” for “Scaling applicability”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C003-T08 · Enforcement evidence:** Exercise the “Scaling applicability” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C003-T09 · Regression linkage:** Link the “Scaling applicability” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C003-T10 · Property disposition:** Compare the satisfying and violating “Scaling applicability” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C004 · Integration

**Original checklist item:** Integrate scaling applicability with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scaling applicability” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C004-T02 · Field mapping:** Map every “Scaling applicability” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Scaling applicability” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C004-T04 · Ownership agreement:** Specify who owns “Scaling applicability” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C004-T05 · Handoff implementation:** Connect “Scaling applicability” through the mapped seam using the real adapter or explicit specification reference; preserve “Scaling is enabled only when the workload's state model supports it” across the handoff.
- [ ] **UC-M05.08-C004-T06 · Absent-input case:** Omit one required “Scaling applicability” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C004-T07 · Stale-input case:** Supply an outdated “Scaling applicability” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C004-T08 · Incompatible-input case:** Supply an incompatible “Scaling applicability” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C004-T09 · Valid integration trace:** Run a valid “Scaling applicability” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C004-T10 · Seam review:** Reconcile the “Scaling applicability” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scaling applicability; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scaling applicability” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C005-T02 · Expected-result oracle:** Specify the “Scaling applicability” expected result independently of the implementation output; include the property “Scaling is enabled only when the workload's state model supports it” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C005-T03 · Fixture material:** Create the concrete “Scaling applicability” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C005-T04 · Target preparation:** Prepare the “Scaling applicability” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C005-T05 · Initial-state record:** Record the initial “Scaling applicability” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C005-T06 · Valid-path execution:** Execute the “Scaling applicability” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C005-T07 · Outcome comparison:** Compare every declared “Scaling applicability” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C005-T08 · State and bounds check:** Inspect the “Scaling applicability” ownership/state effects and actual use of “Supported scaling profiles and replica range”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C005-T09 · Repeatability check:** Repeat the same “Scaling applicability” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C005-T10 · Positive evidence:** Attach the “Scaling applicability” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C006 · Negative test

**Original checklist item:** Negative case: A stateful workload is duplicated as though it were stateless. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “Scaling applicability” source counterexample: “A stateful workload is duplicated as though it were stateless”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Scaling applicability”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C006-T03 · Valid control:** Construct a valid “Scaling applicability” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C006-T04 · Minimal adverse input:** Derive the “Scaling applicability” adverse fixture from the control with the smallest documented change needed to reproduce “A stateful workload is duplicated as though it were stateless”; retain that change as reproducible data.
- [ ] **UC-M05.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scaling applicability”; require “Scaling is enabled only when the workload's state model supports it” and forbid a false-success verdict.
- [ ] **UC-M05.08-C006-T06 · Adverse execution:** Exercise the “Scaling applicability” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C006-T07 · Effect inspection:** Inspect “Scaling applicability” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C006-T08 · Refusal versus failure:** Confirm the “Scaling applicability” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C006-T09 · Reset and retention:** Restore only the disposable “Scaling applicability” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C006-T10 · Negative regression:** Register the “Scaling applicability” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C007 · Change / failure test

**Original checklist item:** Exercise scaling applicability when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C007-T01 · Scenario record:** Write the “Scaling applicability” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Scaling is enabled only when the workload's state model supports it”.
- [ ] **UC-M05.08-C007-T02 · Baseline capture:** Create a known-valid “Scaling applicability” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C007-T03 · Injection map:** Locate the “Scaling applicability” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Scaling applicability” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C007-T05 · Controlled trigger:** Introduce the controlled “Scaling applicability” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C007-T06 · Intermediate inspection:** Inspect the “Scaling applicability” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scaling applicability”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Scaling applicability” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C007-T09 · Repeat and compare:** Repeat the selected “Scaling applicability” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C007-T10 · Failure evidence:** Publish the “Scaling applicability” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C008 · Bounds

**Original checklist item:** Choose, document and test limits for supported scaling profiles and replica range; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “Scaling applicability”: “Supported scaling profiles and replica range”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C008-T02 · Measurement method:** Choose how to observe each “Scaling applicability” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C008-T03 · Budget decision:** Select justified resource and input limits for “Scaling applicability”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scaling applicability” cases for “Supported scaling profiles and replica range”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scaling applicability” limit; preserve “Scaling is enabled only when the workload's state model supports it”.
- [ ] **UC-M05.08-C008-T06 · Normal measurement:** Run or review the normal “Scaling applicability” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C008-T07 · At-limit measurement:** Exercise the “Scaling applicability” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C008-T08 · Over-limit measurement:** Exercise the “Scaling applicability” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C008-T09 · Uncovered-scope report:** List the “Scaling applicability” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C008-T10 · Limit evidence:** Publish the selected “Scaling applicability” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scaling applicability with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C009-T01 · Event inventory:** List the “Scaling applicability” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Scaling applicability” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C009-T03 · Failure mapping:** Map each documented “Scaling applicability” refusal or error to a diagnostic outcome; include “A stateful workload is duplicated as though it were stateless” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C009-T04 · Emission path:** Add the “Scaling applicability” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C009-T05 · Redaction check:** Test “Scaling applicability” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C009-T06 · Output budget:** Set and exercise bounded “Scaling applicability” message size, rate and retention compatible with “Supported scaling profiles and replica range”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C009-T07 · Success/refusal fixtures:** Capture “Scaling applicability” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scaling applicability” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C009-T09 · Operator review:** Read the “Scaling applicability” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C009-T10 · Diagnostic evidence:** Publish redacted “Scaling applicability” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scaling applicability; label unexecuted checks as untested.

- [ ] **UC-M05.08-C010-T01 · Evidence inventory:** List the “Scaling applicability” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C010-T02 · Artifact references:** Record the exact “Scaling applicability” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C010-T03 · Fixture references:** Attach the “Scaling applicability” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stateful workload is duplicated as though it were stateless” as a distinct evidence case.
- [ ] **UC-M05.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scaling applicability”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C010-T05 · Environment record:** Record the actual “Scaling applicability” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C010-T06 · Expected versus observed:** Pair every “Scaling applicability” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C010-T07 · Failure and limit records:** Attach “Scaling applicability” change/failure and bounds evidence where required; include uncovered “Supported scaling profiles and replica range” and unresolved violations of “Scaling is enabled only when the workload's state model supports it”.
- [ ] **UC-M05.08-C010-T08 · Evidence hygiene:** Check the “Scaling applicability” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C010-T09 · Reproduction review:** Have the “Scaling applicability” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C010-T10 · Acceptance linkage:** Link the “Scaling applicability” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Replica identity

**Source delivery:** Assign immutable replica and generation identities under the workload.

**Source invariant:** Replica identity is distinct from reused display names.

**Source negative case:** A replacement replica adopts another replica's stale writer authority.

**Source bounded quantities:** Replica count and identity records.

### UC-M05.08-C011 · Contract

**Original checklist item:** Specify replica identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C011-T01 · Scope statement:** Draft the operation boundary for “Replica identity” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Replica identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C011-T03 · Output inventory:** List the outputs of “Replica identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Replica identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C011-T05 · Prerequisite contract:** Map “Replica identity” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Replica identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C011-T07 · Invariant clause:** Add a normative clause for “Replica identity” that preserves “Replica identity is distinct from reused display names”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Replica identity”; include the source counterexample “A replacement replica adopts another replica's stale writer authority” and the intended safe disposition.
- [ ] **UC-M05.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Replica count and identity records” in the “Replica identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C011-T10 · Contract review:** Review the “Replica identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C012 · Delivery

**Original checklist item:** Assign immutable replica and generation identities under the workload.

- [ ] **UC-M05.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Replica identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C012-T02 · Change plan:** Break the source delivery for “Replica identity” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Replica identity” that realizes this source instruction: Assign immutable replica and generation identities under the workload.
- [ ] **UC-M05.08-C012-T04 · Concrete realization:** Trace “Replica identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Replica identity” needed to preserve “Replica identity is distinct from reused display names”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C012-T06 · Dependency connection:** Connect the “Replica identity” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C012-T07 · Resource behavior:** Account for “Replica count and identity records” in “Replica identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C012-T08 · Delivery check:** Run the smallest real “Replica identity” path and its adverse fixture “A replacement replica adopts another replica's stale writer authority”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C012-T09 · Patch review:** Review the “Replica identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C012-T10 · Delivery handoff:** Publish the “Replica identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replica identity is distinct from reused display names. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Replica identity”; copy its required invariant exactly: “Replica identity is distinct from reused display names”.
- [ ] **UC-M05.08-C013-T02 · Observable terms:** Define each term in the “Replica identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C013-T03 · Precondition set:** List the preconditions under which “Replica identity is distinct from reused display names” must hold for “Replica identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C013-T04 · Transition coverage:** Map the “Replica identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Replica identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C013-T06 · Satisfying fixture:** Create a concrete “Replica identity” case that satisfies “Replica identity is distinct from reused display names”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C013-T07 · Violating fixture:** Create the source counterexample “A replacement replica adopts another replica's stale writer authority” for “Replica identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C013-T08 · Enforcement evidence:** Exercise the “Replica identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C013-T09 · Regression linkage:** Link the “Replica identity” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Replica identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C014 · Integration

**Original checklist item:** Integrate replica identity with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Replica identity” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C014-T02 · Field mapping:** Map every “Replica identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Replica identity” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C014-T04 · Ownership agreement:** Specify who owns “Replica identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C014-T05 · Handoff implementation:** Connect “Replica identity” through the mapped seam using the real adapter or explicit specification reference; preserve “Replica identity is distinct from reused display names” across the handoff.
- [ ] **UC-M05.08-C014-T06 · Absent-input case:** Omit one required “Replica identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C014-T07 · Stale-input case:** Supply an outdated “Replica identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Replica identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C014-T09 · Valid integration trace:** Run a valid “Replica identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C014-T10 · Seam review:** Reconcile the “Replica identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for replica identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Replica identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C015-T02 · Expected-result oracle:** Specify the “Replica identity” expected result independently of the implementation output; include the property “Replica identity is distinct from reused display names” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C015-T03 · Fixture material:** Create the concrete “Replica identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C015-T04 · Target preparation:** Prepare the “Replica identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C015-T05 · Initial-state record:** Record the initial “Replica identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C015-T06 · Valid-path execution:** Execute the “Replica identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C015-T07 · Outcome comparison:** Compare every declared “Replica identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C015-T08 · State and bounds check:** Inspect the “Replica identity” ownership/state effects and actual use of “Replica count and identity records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C015-T09 · Repeatability check:** Repeat the same “Replica identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C015-T10 · Positive evidence:** Attach the “Replica identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C016 · Negative test

**Original checklist item:** Negative case: A replacement replica adopts another replica's stale writer authority. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Replica identity” source counterexample: “A replacement replica adopts another replica's stale writer authority”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Replica identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C016-T03 · Valid control:** Construct a valid “Replica identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C016-T04 · Minimal adverse input:** Derive the “Replica identity” adverse fixture from the control with the smallest documented change needed to reproduce “A replacement replica adopts another replica's stale writer authority”; retain that change as reproducible data.
- [ ] **UC-M05.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Replica identity”; require “Replica identity is distinct from reused display names” and forbid a false-success verdict.
- [ ] **UC-M05.08-C016-T06 · Adverse execution:** Exercise the “Replica identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C016-T07 · Effect inspection:** Inspect “Replica identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C016-T08 · Refusal versus failure:** Confirm the “Replica identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C016-T09 · Reset and retention:** Restore only the disposable “Replica identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C016-T10 · Negative regression:** Register the “Replica identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C017 · Change / failure test

**Original checklist item:** Exercise replica identity when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C017-T01 · Scenario record:** Write the “Replica identity” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Replica identity is distinct from reused display names”.
- [ ] **UC-M05.08-C017-T02 · Baseline capture:** Create a known-valid “Replica identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C017-T03 · Injection map:** Locate the “Replica identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Replica identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C017-T05 · Controlled trigger:** Introduce the controlled “Replica identity” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C017-T06 · Intermediate inspection:** Inspect the “Replica identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Replica identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Replica identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C017-T09 · Repeat and compare:** Repeat the selected “Replica identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C017-T10 · Failure evidence:** Publish the “Replica identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C018 · Bounds

**Original checklist item:** Choose, document and test limits for replica count and identity records; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Replica identity”: “Replica count and identity records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C018-T02 · Measurement method:** Choose how to observe each “Replica identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C018-T03 · Budget decision:** Select justified resource and input limits for “Replica identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Replica identity” cases for “Replica count and identity records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Replica identity” limit; preserve “Replica identity is distinct from reused display names”.
- [ ] **UC-M05.08-C018-T06 · Normal measurement:** Run or review the normal “Replica identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C018-T07 · At-limit measurement:** Exercise the “Replica identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C018-T08 · Over-limit measurement:** Exercise the “Replica identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C018-T09 · Uncovered-scope report:** List the “Replica identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C018-T10 · Limit evidence:** Publish the selected “Replica identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for replica identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C019-T01 · Event inventory:** List the “Replica identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Replica identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C019-T03 · Failure mapping:** Map each documented “Replica identity” refusal or error to a diagnostic outcome; include “A replacement replica adopts another replica's stale writer authority” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C019-T04 · Emission path:** Add the “Replica identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C019-T05 · Redaction check:** Test “Replica identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C019-T06 · Output budget:** Set and exercise bounded “Replica identity” message size, rate and retention compatible with “Replica count and identity records”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C019-T07 · Success/refusal fixtures:** Capture “Replica identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Replica identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C019-T09 · Operator review:** Read the “Replica identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C019-T10 · Diagnostic evidence:** Publish redacted “Replica identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for replica identity; label unexecuted checks as untested.

- [ ] **UC-M05.08-C020-T01 · Evidence inventory:** List the “Replica identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C020-T02 · Artifact references:** Record the exact “Replica identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C020-T03 · Fixture references:** Attach the “Replica identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A replacement replica adopts another replica's stale writer authority” as a distinct evidence case.
- [ ] **UC-M05.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Replica identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C020-T05 · Environment record:** Record the actual “Replica identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C020-T06 · Expected versus observed:** Pair every “Replica identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C020-T07 · Failure and limit records:** Attach “Replica identity” change/failure and bounds evidence where required; include uncovered “Replica count and identity records” and unresolved violations of “Replica identity is distinct from reused display names”.
- [ ] **UC-M05.08-C020-T08 · Evidence hygiene:** Check the “Replica identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C020-T09 · Reproduction review:** Have the “Replica identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C020-T10 · Acceptance linkage:** Link the “Replica identity” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Capacity reservation

**Source delivery:** Reserve aggregate resources before increasing replica count.

**Source invariant:** Scale-out cannot bypass workload or tenant quotas.

**Source negative case:** Many small replicas exceed the tenant's aggregate memory budget.

**Source bounded quantities:** Replica reservations and aggregate resources.

### UC-M05.08-C021 · Contract

**Original checklist item:** Specify capacity reservation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C021-T01 · Scope statement:** Draft the operation boundary for “Capacity reservation” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capacity reservation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C021-T03 · Output inventory:** List the outputs of “Capacity reservation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Capacity reservation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C021-T05 · Prerequisite contract:** Map “Capacity reservation” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Capacity reservation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C021-T07 · Invariant clause:** Add a normative clause for “Capacity reservation” that preserves “Scale-out cannot bypass workload or tenant quotas”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capacity reservation”; include the source counterexample “Many small replicas exceed the tenant's aggregate memory budget” and the intended safe disposition.
- [ ] **UC-M05.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Replica reservations and aggregate resources” in the “Capacity reservation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C021-T10 · Contract review:** Review the “Capacity reservation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C022 · Delivery

**Original checklist item:** Reserve aggregate resources before increasing replica count.

- [ ] **UC-M05.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capacity reservation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C022-T02 · Change plan:** Break the source delivery for “Capacity reservation” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Capacity reservation” that realizes this source instruction: Reserve aggregate resources before increasing replica count.
- [ ] **UC-M05.08-C022-T04 · Concrete realization:** Trace “Capacity reservation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capacity reservation” needed to preserve “Scale-out cannot bypass workload or tenant quotas”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C022-T06 · Dependency connection:** Connect the “Capacity reservation” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C022-T07 · Resource behavior:** Account for “Replica reservations and aggregate resources” in “Capacity reservation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C022-T08 · Delivery check:** Run the smallest real “Capacity reservation” path and its adverse fixture “Many small replicas exceed the tenant's aggregate memory budget”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C022-T09 · Patch review:** Review the “Capacity reservation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C022-T10 · Delivery handoff:** Publish the “Capacity reservation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Scale-out cannot bypass workload or tenant quotas. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Capacity reservation”; copy its required invariant exactly: “Scale-out cannot bypass workload or tenant quotas”.
- [ ] **UC-M05.08-C023-T02 · Observable terms:** Define each term in the “Capacity reservation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C023-T03 · Precondition set:** List the preconditions under which “Scale-out cannot bypass workload or tenant quotas” must hold for “Capacity reservation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C023-T04 · Transition coverage:** Map the “Capacity reservation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capacity reservation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C023-T06 · Satisfying fixture:** Create a concrete “Capacity reservation” case that satisfies “Scale-out cannot bypass workload or tenant quotas”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C023-T07 · Violating fixture:** Create the source counterexample “Many small replicas exceed the tenant's aggregate memory budget” for “Capacity reservation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C023-T08 · Enforcement evidence:** Exercise the “Capacity reservation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C023-T09 · Regression linkage:** Link the “Capacity reservation” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Capacity reservation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C024 · Integration

**Original checklist item:** Integrate capacity reservation with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capacity reservation” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C024-T02 · Field mapping:** Map every “Capacity reservation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Capacity reservation” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C024-T04 · Ownership agreement:** Specify who owns “Capacity reservation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C024-T05 · Handoff implementation:** Connect “Capacity reservation” through the mapped seam using the real adapter or explicit specification reference; preserve “Scale-out cannot bypass workload or tenant quotas” across the handoff.
- [ ] **UC-M05.08-C024-T06 · Absent-input case:** Omit one required “Capacity reservation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C024-T07 · Stale-input case:** Supply an outdated “Capacity reservation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Capacity reservation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C024-T09 · Valid integration trace:** Run a valid “Capacity reservation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C024-T10 · Seam review:** Reconcile the “Capacity reservation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capacity reservation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capacity reservation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C025-T02 · Expected-result oracle:** Specify the “Capacity reservation” expected result independently of the implementation output; include the property “Scale-out cannot bypass workload or tenant quotas” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C025-T03 · Fixture material:** Create the concrete “Capacity reservation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C025-T04 · Target preparation:** Prepare the “Capacity reservation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C025-T05 · Initial-state record:** Record the initial “Capacity reservation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C025-T06 · Valid-path execution:** Execute the “Capacity reservation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C025-T07 · Outcome comparison:** Compare every declared “Capacity reservation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C025-T08 · State and bounds check:** Inspect the “Capacity reservation” ownership/state effects and actual use of “Replica reservations and aggregate resources”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C025-T09 · Repeatability check:** Repeat the same “Capacity reservation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C025-T10 · Positive evidence:** Attach the “Capacity reservation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C026 · Negative test

**Original checklist item:** Negative case: Many small replicas exceed the tenant's aggregate memory budget. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Capacity reservation” source counterexample: “Many small replicas exceed the tenant's aggregate memory budget”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Capacity reservation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C026-T03 · Valid control:** Construct a valid “Capacity reservation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C026-T04 · Minimal adverse input:** Derive the “Capacity reservation” adverse fixture from the control with the smallest documented change needed to reproduce “Many small replicas exceed the tenant's aggregate memory budget”; retain that change as reproducible data.
- [ ] **UC-M05.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capacity reservation”; require “Scale-out cannot bypass workload or tenant quotas” and forbid a false-success verdict.
- [ ] **UC-M05.08-C026-T06 · Adverse execution:** Exercise the “Capacity reservation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C026-T07 · Effect inspection:** Inspect “Capacity reservation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C026-T08 · Refusal versus failure:** Confirm the “Capacity reservation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C026-T09 · Reset and retention:** Restore only the disposable “Capacity reservation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C026-T10 · Negative regression:** Register the “Capacity reservation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C027 · Change / failure test

**Original checklist item:** Exercise capacity reservation when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C027-T01 · Scenario record:** Write the “Capacity reservation” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Scale-out cannot bypass workload or tenant quotas”.
- [ ] **UC-M05.08-C027-T02 · Baseline capture:** Create a known-valid “Capacity reservation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C027-T03 · Injection map:** Locate the “Capacity reservation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Capacity reservation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C027-T05 · Controlled trigger:** Introduce the controlled “Capacity reservation” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C027-T06 · Intermediate inspection:** Inspect the “Capacity reservation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capacity reservation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Capacity reservation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C027-T09 · Repeat and compare:** Repeat the selected “Capacity reservation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C027-T10 · Failure evidence:** Publish the “Capacity reservation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C028 · Bounds

**Original checklist item:** Choose, document and test limits for replica reservations and aggregate resources; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Capacity reservation”: “Replica reservations and aggregate resources”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C028-T02 · Measurement method:** Choose how to observe each “Capacity reservation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C028-T03 · Budget decision:** Select justified resource and input limits for “Capacity reservation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capacity reservation” cases for “Replica reservations and aggregate resources”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capacity reservation” limit; preserve “Scale-out cannot bypass workload or tenant quotas”.
- [ ] **UC-M05.08-C028-T06 · Normal measurement:** Run or review the normal “Capacity reservation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C028-T07 · At-limit measurement:** Exercise the “Capacity reservation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C028-T08 · Over-limit measurement:** Exercise the “Capacity reservation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C028-T09 · Uncovered-scope report:** List the “Capacity reservation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C028-T10 · Limit evidence:** Publish the selected “Capacity reservation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capacity reservation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C029-T01 · Event inventory:** List the “Capacity reservation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Capacity reservation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C029-T03 · Failure mapping:** Map each documented “Capacity reservation” refusal or error to a diagnostic outcome; include “Many small replicas exceed the tenant's aggregate memory budget” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C029-T04 · Emission path:** Add the “Capacity reservation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C029-T05 · Redaction check:** Test “Capacity reservation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C029-T06 · Output budget:** Set and exercise bounded “Capacity reservation” message size, rate and retention compatible with “Replica reservations and aggregate resources”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C029-T07 · Success/refusal fixtures:** Capture “Capacity reservation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capacity reservation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C029-T09 · Operator review:** Read the “Capacity reservation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C029-T10 · Diagnostic evidence:** Publish redacted “Capacity reservation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capacity reservation; label unexecuted checks as untested.

- [ ] **UC-M05.08-C030-T01 · Evidence inventory:** List the “Capacity reservation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C030-T02 · Artifact references:** Record the exact “Capacity reservation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C030-T03 · Fixture references:** Attach the “Capacity reservation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Many small replicas exceed the tenant's aggregate memory budget” as a distinct evidence case.
- [ ] **UC-M05.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capacity reservation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C030-T05 · Environment record:** Record the actual “Capacity reservation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C030-T06 · Expected versus observed:** Pair every “Capacity reservation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C030-T07 · Failure and limit records:** Attach “Capacity reservation” change/failure and bounds evidence where required; include uncovered “Replica reservations and aggregate resources” and unresolved violations of “Scale-out cannot bypass workload or tenant quotas”.
- [ ] **UC-M05.08-C030-T08 · Evidence hygiene:** Check the “Capacity reservation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C030-T09 · Reproduction review:** Have the “Capacity reservation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C030-T10 · Acceptance linkage:** Link the “Capacity reservation” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Scale-out readiness

**Source delivery:** Route work to added replicas only after required readiness passes.

**Source invariant:** A newly created but unready replica receives no admitted service work.

**Source negative case:** Traffic reaches a replica before its state is initialized.

**Source bounded quantities:** Concurrent starts and readiness deadline.

### UC-M05.08-C031 · Contract

**Original checklist item:** Specify scale-out readiness inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C031-T01 · Scope statement:** Draft the operation boundary for “Scale-out readiness” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scale-out readiness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C031-T03 · Output inventory:** List the outputs of “Scale-out readiness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Scale-out readiness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C031-T05 · Prerequisite contract:** Map “Scale-out readiness” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Scale-out readiness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C031-T07 · Invariant clause:** Add a normative clause for “Scale-out readiness” that preserves “A newly created but unready replica receives no admitted service work”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scale-out readiness”; include the source counterexample “Traffic reaches a replica before its state is initialized” and the intended safe disposition.
- [ ] **UC-M05.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent starts and readiness deadline” in the “Scale-out readiness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C031-T10 · Contract review:** Review the “Scale-out readiness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C032 · Delivery

**Original checklist item:** Route work to added replicas only after required readiness passes.

- [ ] **UC-M05.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scale-out readiness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C032-T02 · Change plan:** Break the source delivery for “Scale-out readiness” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Scale-out readiness” that realizes this source instruction: Route work to added replicas only after required readiness passes.
- [ ] **UC-M05.08-C032-T04 · Concrete realization:** Trace “Scale-out readiness” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scale-out readiness” needed to preserve “A newly created but unready replica receives no admitted service work”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C032-T06 · Dependency connection:** Connect the “Scale-out readiness” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C032-T07 · Resource behavior:** Account for “Concurrent starts and readiness deadline” in “Scale-out readiness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C032-T08 · Delivery check:** Run the smallest real “Scale-out readiness” path and its adverse fixture “Traffic reaches a replica before its state is initialized”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C032-T09 · Patch review:** Review the “Scale-out readiness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C032-T10 · Delivery handoff:** Publish the “Scale-out readiness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A newly created but unready replica receives no admitted service work. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Scale-out readiness”; copy its required invariant exactly: “A newly created but unready replica receives no admitted service work”.
- [ ] **UC-M05.08-C033-T02 · Observable terms:** Define each term in the “Scale-out readiness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C033-T03 · Precondition set:** List the preconditions under which “A newly created but unready replica receives no admitted service work” must hold for “Scale-out readiness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C033-T04 · Transition coverage:** Map the “Scale-out readiness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scale-out readiness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C033-T06 · Satisfying fixture:** Create a concrete “Scale-out readiness” case that satisfies “A newly created but unready replica receives no admitted service work”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C033-T07 · Violating fixture:** Create the source counterexample “Traffic reaches a replica before its state is initialized” for “Scale-out readiness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C033-T08 · Enforcement evidence:** Exercise the “Scale-out readiness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C033-T09 · Regression linkage:** Link the “Scale-out readiness” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Scale-out readiness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C034 · Integration

**Original checklist item:** Integrate scale-out readiness with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scale-out readiness” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C034-T02 · Field mapping:** Map every “Scale-out readiness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Scale-out readiness” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C034-T04 · Ownership agreement:** Specify who owns “Scale-out readiness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C034-T05 · Handoff implementation:** Connect “Scale-out readiness” through the mapped seam using the real adapter or explicit specification reference; preserve “A newly created but unready replica receives no admitted service work” across the handoff.
- [ ] **UC-M05.08-C034-T06 · Absent-input case:** Omit one required “Scale-out readiness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C034-T07 · Stale-input case:** Supply an outdated “Scale-out readiness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Scale-out readiness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C034-T09 · Valid integration trace:** Run a valid “Scale-out readiness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C034-T10 · Seam review:** Reconcile the “Scale-out readiness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scale-out readiness; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scale-out readiness” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C035-T02 · Expected-result oracle:** Specify the “Scale-out readiness” expected result independently of the implementation output; include the property “A newly created but unready replica receives no admitted service work” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C035-T03 · Fixture material:** Create the concrete “Scale-out readiness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C035-T04 · Target preparation:** Prepare the “Scale-out readiness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C035-T05 · Initial-state record:** Record the initial “Scale-out readiness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C035-T06 · Valid-path execution:** Execute the “Scale-out readiness” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C035-T07 · Outcome comparison:** Compare every declared “Scale-out readiness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C035-T08 · State and bounds check:** Inspect the “Scale-out readiness” ownership/state effects and actual use of “Concurrent starts and readiness deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C035-T09 · Repeatability check:** Repeat the same “Scale-out readiness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C035-T10 · Positive evidence:** Attach the “Scale-out readiness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C036 · Negative test

**Original checklist item:** Negative case: Traffic reaches a replica before its state is initialized. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Scale-out readiness” source counterexample: “Traffic reaches a replica before its state is initialized”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Scale-out readiness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C036-T03 · Valid control:** Construct a valid “Scale-out readiness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C036-T04 · Minimal adverse input:** Derive the “Scale-out readiness” adverse fixture from the control with the smallest documented change needed to reproduce “Traffic reaches a replica before its state is initialized”; retain that change as reproducible data.
- [ ] **UC-M05.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scale-out readiness”; require “A newly created but unready replica receives no admitted service work” and forbid a false-success verdict.
- [ ] **UC-M05.08-C036-T06 · Adverse execution:** Exercise the “Scale-out readiness” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C036-T07 · Effect inspection:** Inspect “Scale-out readiness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C036-T08 · Refusal versus failure:** Confirm the “Scale-out readiness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C036-T09 · Reset and retention:** Restore only the disposable “Scale-out readiness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C036-T10 · Negative regression:** Register the “Scale-out readiness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C037 · Change / failure test

**Original checklist item:** Exercise scale-out readiness when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C037-T01 · Scenario record:** Write the “Scale-out readiness” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “A newly created but unready replica receives no admitted service work”.
- [ ] **UC-M05.08-C037-T02 · Baseline capture:** Create a known-valid “Scale-out readiness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C037-T03 · Injection map:** Locate the “Scale-out readiness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Scale-out readiness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C037-T05 · Controlled trigger:** Introduce the controlled “Scale-out readiness” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C037-T06 · Intermediate inspection:** Inspect the “Scale-out readiness” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scale-out readiness”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Scale-out readiness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C037-T09 · Repeat and compare:** Repeat the selected “Scale-out readiness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C037-T10 · Failure evidence:** Publish the “Scale-out readiness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C038 · Bounds

**Original checklist item:** Choose, document and test limits for concurrent starts and readiness deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Scale-out readiness”: “Concurrent starts and readiness deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C038-T02 · Measurement method:** Choose how to observe each “Scale-out readiness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C038-T03 · Budget decision:** Select justified resource and input limits for “Scale-out readiness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scale-out readiness” cases for “Concurrent starts and readiness deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scale-out readiness” limit; preserve “A newly created but unready replica receives no admitted service work”.
- [ ] **UC-M05.08-C038-T06 · Normal measurement:** Run or review the normal “Scale-out readiness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C038-T07 · At-limit measurement:** Exercise the “Scale-out readiness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C038-T08 · Over-limit measurement:** Exercise the “Scale-out readiness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C038-T09 · Uncovered-scope report:** List the “Scale-out readiness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C038-T10 · Limit evidence:** Publish the selected “Scale-out readiness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scale-out readiness with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C039-T01 · Event inventory:** List the “Scale-out readiness” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Scale-out readiness” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C039-T03 · Failure mapping:** Map each documented “Scale-out readiness” refusal or error to a diagnostic outcome; include “Traffic reaches a replica before its state is initialized” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C039-T04 · Emission path:** Add the “Scale-out readiness” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C039-T05 · Redaction check:** Test “Scale-out readiness” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C039-T06 · Output budget:** Set and exercise bounded “Scale-out readiness” message size, rate and retention compatible with “Concurrent starts and readiness deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C039-T07 · Success/refusal fixtures:** Capture “Scale-out readiness” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scale-out readiness” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C039-T09 · Operator review:** Read the “Scale-out readiness” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C039-T10 · Diagnostic evidence:** Publish redacted “Scale-out readiness” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scale-out readiness; label unexecuted checks as untested.

- [ ] **UC-M05.08-C040-T01 · Evidence inventory:** List the “Scale-out readiness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C040-T02 · Artifact references:** Record the exact “Scale-out readiness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C040-T03 · Fixture references:** Attach the “Scale-out readiness” fixture IDs, input identities and oracle definition; preserve the source counterexample “Traffic reaches a replica before its state is initialized” as a distinct evidence case.
- [ ] **UC-M05.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scale-out readiness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C040-T05 · Environment record:** Record the actual “Scale-out readiness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C040-T06 · Expected versus observed:** Pair every “Scale-out readiness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C040-T07 · Failure and limit records:** Attach “Scale-out readiness” change/failure and bounds evidence where required; include uncovered “Concurrent starts and readiness deadline” and unresolved violations of “A newly created but unready replica receives no admitted service work”.
- [ ] **UC-M05.08-C040-T08 · Evidence hygiene:** Check the “Scale-out readiness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C040-T09 · Reproduction review:** Have the “Scale-out readiness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C040-T10 · Acceptance linkage:** Link the “Scale-out readiness” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Scale-in selection

**Source delivery:** Choose replicas for removal using explicit state and accepted-work constraints.

**Source invariant:** Scale-in does not discard accepted work silently.

**Source negative case:** The selected replica still owns uncommitted requests.

**Source bounded quantities:** Candidate replicas and pending work.

### UC-M05.08-C041 · Contract

**Original checklist item:** Specify scale-in selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C041-T01 · Scope statement:** Draft the operation boundary for “Scale-in selection” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scale-in selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C041-T03 · Output inventory:** List the outputs of “Scale-in selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Scale-in selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C041-T05 · Prerequisite contract:** Map “Scale-in selection” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Scale-in selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C041-T07 · Invariant clause:** Add a normative clause for “Scale-in selection” that preserves “Scale-in does not discard accepted work silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scale-in selection”; include the source counterexample “The selected replica still owns uncommitted requests” and the intended safe disposition.
- [ ] **UC-M05.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Candidate replicas and pending work” in the “Scale-in selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C041-T10 · Contract review:** Review the “Scale-in selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C042 · Delivery

**Original checklist item:** Choose replicas for removal using explicit state and accepted-work constraints.

- [ ] **UC-M05.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scale-in selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C042-T02 · Change plan:** Break the source delivery for “Scale-in selection” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C042-T03 · Core artifact:** Prepare the “Scale-in selection” decision record for this source instruction: Choose replicas for removal using explicit state and accepted-work constraints.
- [ ] **UC-M05.08-C042-T04 · Concrete realization:** Evaluate the “Scale-in selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M05.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scale-in selection” needed to preserve “Scale-in does not discard accepted work silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C042-T06 · Dependency connection:** Connect the “Scale-in selection” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C042-T07 · Resource behavior:** Account for “Candidate replicas and pending work” in “Scale-in selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C042-T08 · Delivery check:** Run the smallest real “Scale-in selection” path and its adverse fixture “The selected replica still owns uncommitted requests”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C042-T09 · Patch review:** Review the “Scale-in selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C042-T10 · Delivery handoff:** Publish the “Scale-in selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Scale-in does not discard accepted work silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Scale-in selection”; copy its required invariant exactly: “Scale-in does not discard accepted work silently”.
- [ ] **UC-M05.08-C043-T02 · Observable terms:** Define each term in the “Scale-in selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C043-T03 · Precondition set:** List the preconditions under which “Scale-in does not discard accepted work silently” must hold for “Scale-in selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C043-T04 · Transition coverage:** Map the “Scale-in selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scale-in selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C043-T06 · Satisfying fixture:** Create a concrete “Scale-in selection” case that satisfies “Scale-in does not discard accepted work silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C043-T07 · Violating fixture:** Create the source counterexample “The selected replica still owns uncommitted requests” for “Scale-in selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C043-T08 · Enforcement evidence:** Exercise the “Scale-in selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C043-T09 · Regression linkage:** Link the “Scale-in selection” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Scale-in selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C044 · Integration

**Original checklist item:** Integrate scale-in selection with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scale-in selection” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C044-T02 · Field mapping:** Map every “Scale-in selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Scale-in selection” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C044-T04 · Ownership agreement:** Specify who owns “Scale-in selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C044-T05 · Handoff implementation:** Connect “Scale-in selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Scale-in does not discard accepted work silently” across the handoff.
- [ ] **UC-M05.08-C044-T06 · Absent-input case:** Omit one required “Scale-in selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C044-T07 · Stale-input case:** Supply an outdated “Scale-in selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Scale-in selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C044-T09 · Valid integration trace:** Run a valid “Scale-in selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C044-T10 · Seam review:** Reconcile the “Scale-in selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scale-in selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scale-in selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C045-T02 · Expected-result oracle:** Specify the “Scale-in selection” expected result independently of the implementation output; include the property “Scale-in does not discard accepted work silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C045-T03 · Fixture material:** Create the concrete “Scale-in selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C045-T04 · Target preparation:** Prepare the “Scale-in selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C045-T05 · Initial-state record:** Record the initial “Scale-in selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C045-T06 · Valid-path execution:** Execute the “Scale-in selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C045-T07 · Outcome comparison:** Compare every declared “Scale-in selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C045-T08 · State and bounds check:** Inspect the “Scale-in selection” ownership/state effects and actual use of “Candidate replicas and pending work”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C045-T09 · Repeatability check:** Repeat the same “Scale-in selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C045-T10 · Positive evidence:** Attach the “Scale-in selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C046 · Negative test

**Original checklist item:** Negative case: The selected replica still owns uncommitted requests. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Scale-in selection” source counterexample: “The selected replica still owns uncommitted requests”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Scale-in selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C046-T03 · Valid control:** Construct a valid “Scale-in selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C046-T04 · Minimal adverse input:** Derive the “Scale-in selection” adverse fixture from the control with the smallest documented change needed to reproduce “The selected replica still owns uncommitted requests”; retain that change as reproducible data.
- [ ] **UC-M05.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scale-in selection”; require “Scale-in does not discard accepted work silently” and forbid a false-success verdict.
- [ ] **UC-M05.08-C046-T06 · Adverse execution:** Exercise the “Scale-in selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C046-T07 · Effect inspection:** Inspect “Scale-in selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C046-T08 · Refusal versus failure:** Confirm the “Scale-in selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C046-T09 · Reset and retention:** Restore only the disposable “Scale-in selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C046-T10 · Negative regression:** Register the “Scale-in selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C047 · Change / failure test

**Original checklist item:** Exercise scale-in selection when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C047-T01 · Scenario record:** Write the “Scale-in selection” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Scale-in does not discard accepted work silently”.
- [ ] **UC-M05.08-C047-T02 · Baseline capture:** Create a known-valid “Scale-in selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C047-T03 · Injection map:** Locate the “Scale-in selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Scale-in selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C047-T05 · Controlled trigger:** Introduce the controlled “Scale-in selection” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C047-T06 · Intermediate inspection:** Inspect the “Scale-in selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scale-in selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Scale-in selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C047-T09 · Repeat and compare:** Repeat the selected “Scale-in selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C047-T10 · Failure evidence:** Publish the “Scale-in selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C048 · Bounds

**Original checklist item:** Choose, document and test limits for candidate replicas and pending work; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Scale-in selection”: “Candidate replicas and pending work”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C048-T02 · Measurement method:** Choose how to observe each “Scale-in selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C048-T03 · Budget decision:** Select justified resource and input limits for “Scale-in selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scale-in selection” cases for “Candidate replicas and pending work”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scale-in selection” limit; preserve “Scale-in does not discard accepted work silently”.
- [ ] **UC-M05.08-C048-T06 · Normal measurement:** Run or review the normal “Scale-in selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C048-T07 · At-limit measurement:** Exercise the “Scale-in selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C048-T08 · Over-limit measurement:** Exercise the “Scale-in selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C048-T09 · Uncovered-scope report:** List the “Scale-in selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C048-T10 · Limit evidence:** Publish the selected “Scale-in selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scale-in selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C049-T01 · Event inventory:** List the “Scale-in selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Scale-in selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C049-T03 · Failure mapping:** Map each documented “Scale-in selection” refusal or error to a diagnostic outcome; include “The selected replica still owns uncommitted requests” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C049-T04 · Emission path:** Add the “Scale-in selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C049-T05 · Redaction check:** Test “Scale-in selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C049-T06 · Output budget:** Set and exercise bounded “Scale-in selection” message size, rate and retention compatible with “Candidate replicas and pending work”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C049-T07 · Success/refusal fixtures:** Capture “Scale-in selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scale-in selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C049-T09 · Operator review:** Read the “Scale-in selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C049-T10 · Diagnostic evidence:** Publish redacted “Scale-in selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scale-in selection; label unexecuted checks as untested.

- [ ] **UC-M05.08-C050-T01 · Evidence inventory:** List the “Scale-in selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C050-T02 · Artifact references:** Record the exact “Scale-in selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C050-T03 · Fixture references:** Attach the “Scale-in selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “The selected replica still owns uncommitted requests” as a distinct evidence case.
- [ ] **UC-M05.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scale-in selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C050-T05 · Environment record:** Record the actual “Scale-in selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C050-T06 · Expected versus observed:** Pair every “Scale-in selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C050-T07 · Failure and limit records:** Attach “Scale-in selection” change/failure and bounds evidence where required; include uncovered “Candidate replicas and pending work” and unresolved violations of “Scale-in does not discard accepted work silently”.
- [ ] **UC-M05.08-C050-T08 · Evidence hygiene:** Check the “Scale-in selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C050-T09 · Reproduction review:** Have the “Scale-in selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C050-T10 · Acceptance linkage:** Link the “Scale-in selection” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Drain-before-replace

**Source delivery:** Drain an old replica before revoking its authority or replacing its placement.

**Source invariant:** Replacement respects the workload's declared service continuity semantics.

**Source negative case:** An old and new replica both commit the same accepted request.

**Source bounded quantities:** Drain deadline and overlap window.

### UC-M05.08-C051 · Contract

**Original checklist item:** Specify drain-before-replace inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C051-T01 · Scope statement:** Draft the operation boundary for “Drain-before-replace” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Drain-before-replace”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C051-T03 · Output inventory:** List the outputs of “Drain-before-replace” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Drain-before-replace”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C051-T05 · Prerequisite contract:** Map “Drain-before-replace” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Drain-before-replace”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C051-T07 · Invariant clause:** Add a normative clause for “Drain-before-replace” that preserves “Replacement respects the workload's declared service continuity semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Drain-before-replace”; include the source counterexample “An old and new replica both commit the same accepted request” and the intended safe disposition.
- [ ] **UC-M05.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Drain deadline and overlap window” in the “Drain-before-replace” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C051-T10 · Contract review:** Review the “Drain-before-replace” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C052 · Delivery

**Original checklist item:** Drain an old replica before revoking its authority or replacing its placement.

- [ ] **UC-M05.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Drain-before-replace”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C052-T02 · Change plan:** Break the source delivery for “Drain-before-replace” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Drain-before-replace” that realizes this source instruction: Drain an old replica before revoking its authority or replacing its placement.
- [ ] **UC-M05.08-C052-T04 · Concrete realization:** Trace “Drain-before-replace” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Drain-before-replace” needed to preserve “Replacement respects the workload's declared service continuity semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C052-T06 · Dependency connection:** Connect the “Drain-before-replace” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C052-T07 · Resource behavior:** Account for “Drain deadline and overlap window” in “Drain-before-replace”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C052-T08 · Delivery check:** Run the smallest real “Drain-before-replace” path and its adverse fixture “An old and new replica both commit the same accepted request”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C052-T09 · Patch review:** Review the “Drain-before-replace” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C052-T10 · Delivery handoff:** Publish the “Drain-before-replace” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replacement respects the workload's declared service continuity semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Drain-before-replace”; copy its required invariant exactly: “Replacement respects the workload's declared service continuity semantics”.
- [ ] **UC-M05.08-C053-T02 · Observable terms:** Define each term in the “Drain-before-replace” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C053-T03 · Precondition set:** List the preconditions under which “Replacement respects the workload's declared service continuity semantics” must hold for “Drain-before-replace”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C053-T04 · Transition coverage:** Map the “Drain-before-replace” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Drain-before-replace”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C053-T06 · Satisfying fixture:** Create a concrete “Drain-before-replace” case that satisfies “Replacement respects the workload's declared service continuity semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C053-T07 · Violating fixture:** Create the source counterexample “An old and new replica both commit the same accepted request” for “Drain-before-replace”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C053-T08 · Enforcement evidence:** Exercise the “Drain-before-replace” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C053-T09 · Regression linkage:** Link the “Drain-before-replace” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Drain-before-replace” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C054 · Integration

**Original checklist item:** Integrate drain-before-replace with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Drain-before-replace” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C054-T02 · Field mapping:** Map every “Drain-before-replace” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Drain-before-replace” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C054-T04 · Ownership agreement:** Specify who owns “Drain-before-replace” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C054-T05 · Handoff implementation:** Connect “Drain-before-replace” through the mapped seam using the real adapter or explicit specification reference; preserve “Replacement respects the workload's declared service continuity semantics” across the handoff.
- [ ] **UC-M05.08-C054-T06 · Absent-input case:** Omit one required “Drain-before-replace” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C054-T07 · Stale-input case:** Supply an outdated “Drain-before-replace” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Drain-before-replace” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C054-T09 · Valid integration trace:** Run a valid “Drain-before-replace” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C054-T10 · Seam review:** Reconcile the “Drain-before-replace” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for drain-before-replace; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Drain-before-replace” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C055-T02 · Expected-result oracle:** Specify the “Drain-before-replace” expected result independently of the implementation output; include the property “Replacement respects the workload's declared service continuity semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C055-T03 · Fixture material:** Create the concrete “Drain-before-replace” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C055-T04 · Target preparation:** Prepare the “Drain-before-replace” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C055-T05 · Initial-state record:** Record the initial “Drain-before-replace” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C055-T06 · Valid-path execution:** Execute the “Drain-before-replace” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C055-T07 · Outcome comparison:** Compare every declared “Drain-before-replace” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C055-T08 · State and bounds check:** Inspect the “Drain-before-replace” ownership/state effects and actual use of “Drain deadline and overlap window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C055-T09 · Repeatability check:** Repeat the same “Drain-before-replace” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C055-T10 · Positive evidence:** Attach the “Drain-before-replace” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C056 · Negative test

**Original checklist item:** Negative case: An old and new replica both commit the same accepted request. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Drain-before-replace” source counterexample: “An old and new replica both commit the same accepted request”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Drain-before-replace”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C056-T03 · Valid control:** Construct a valid “Drain-before-replace” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C056-T04 · Minimal adverse input:** Derive the “Drain-before-replace” adverse fixture from the control with the smallest documented change needed to reproduce “An old and new replica both commit the same accepted request”; retain that change as reproducible data.
- [ ] **UC-M05.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Drain-before-replace”; require “Replacement respects the workload's declared service continuity semantics” and forbid a false-success verdict.
- [ ] **UC-M05.08-C056-T06 · Adverse execution:** Exercise the “Drain-before-replace” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C056-T07 · Effect inspection:** Inspect “Drain-before-replace” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C056-T08 · Refusal versus failure:** Confirm the “Drain-before-replace” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C056-T09 · Reset and retention:** Restore only the disposable “Drain-before-replace” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C056-T10 · Negative regression:** Register the “Drain-before-replace” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C057 · Change / failure test

**Original checklist item:** Exercise drain-before-replace when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C057-T01 · Scenario record:** Write the “Drain-before-replace” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Replacement respects the workload's declared service continuity semantics”.
- [ ] **UC-M05.08-C057-T02 · Baseline capture:** Create a known-valid “Drain-before-replace” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C057-T03 · Injection map:** Locate the “Drain-before-replace” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Drain-before-replace” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C057-T05 · Controlled trigger:** Introduce the controlled “Drain-before-replace” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C057-T06 · Intermediate inspection:** Inspect the “Drain-before-replace” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Drain-before-replace”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Drain-before-replace” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C057-T09 · Repeat and compare:** Repeat the selected “Drain-before-replace” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C057-T10 · Failure evidence:** Publish the “Drain-before-replace” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C058 · Bounds

**Original checklist item:** Choose, document and test limits for drain deadline and overlap window; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Drain-before-replace”: “Drain deadline and overlap window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C058-T02 · Measurement method:** Choose how to observe each “Drain-before-replace” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C058-T03 · Budget decision:** Select justified resource and input limits for “Drain-before-replace”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Drain-before-replace” cases for “Drain deadline and overlap window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Drain-before-replace” limit; preserve “Replacement respects the workload's declared service continuity semantics”.
- [ ] **UC-M05.08-C058-T06 · Normal measurement:** Run or review the normal “Drain-before-replace” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C058-T07 · At-limit measurement:** Exercise the “Drain-before-replace” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C058-T08 · Over-limit measurement:** Exercise the “Drain-before-replace” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C058-T09 · Uncovered-scope report:** List the “Drain-before-replace” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C058-T10 · Limit evidence:** Publish the selected “Drain-before-replace” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for drain-before-replace with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C059-T01 · Event inventory:** List the “Drain-before-replace” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Drain-before-replace” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C059-T03 · Failure mapping:** Map each documented “Drain-before-replace” refusal or error to a diagnostic outcome; include “An old and new replica both commit the same accepted request” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C059-T04 · Emission path:** Add the “Drain-before-replace” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C059-T05 · Redaction check:** Test “Drain-before-replace” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C059-T06 · Output budget:** Set and exercise bounded “Drain-before-replace” message size, rate and retention compatible with “Drain deadline and overlap window”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C059-T07 · Success/refusal fixtures:** Capture “Drain-before-replace” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Drain-before-replace” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C059-T09 · Operator review:** Read the “Drain-before-replace” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C059-T10 · Diagnostic evidence:** Publish redacted “Drain-before-replace” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for drain-before-replace; label unexecuted checks as untested.

- [ ] **UC-M05.08-C060-T01 · Evidence inventory:** List the “Drain-before-replace” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C060-T02 · Artifact references:** Record the exact “Drain-before-replace” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C060-T03 · Fixture references:** Attach the “Drain-before-replace” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old and new replica both commit the same accepted request” as a distinct evidence case.
- [ ] **UC-M05.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Drain-before-replace”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C060-T05 · Environment record:** Record the actual “Drain-before-replace” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C060-T06 · Expected versus observed:** Pair every “Drain-before-replace” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C060-T07 · Failure and limit records:** Attach “Drain-before-replace” change/failure and bounds evidence where required; include uncovered “Drain deadline and overlap window” and unresolved violations of “Replacement respects the workload's declared service continuity semantics”.
- [ ] **UC-M05.08-C060-T08 · Evidence hygiene:** Check the “Drain-before-replace” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C060-T09 · Reproduction review:** Have the “Drain-before-replace” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C060-T10 · Acceptance linkage:** Link the “Drain-before-replace” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. State ownership transfer

**Source delivery:** Define state handoff and generation checks for stateful moves.

**Source invariant:** Only the authorized current owner may commit state.

**Source negative case:** A moved replica continues writing from its old placement.

**Source bounded quantities:** State bytes and ownership transfer time.

### UC-M05.08-C061 · Contract

**Original checklist item:** Specify state ownership transfer inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C061-T01 · Scope statement:** Draft the operation boundary for “State ownership transfer” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State ownership transfer”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C061-T03 · Output inventory:** List the outputs of “State ownership transfer” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “State ownership transfer”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C061-T05 · Prerequisite contract:** Map “State ownership transfer” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C061-T06 · Authority map:** Identify who may produce, change and consume “State ownership transfer”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C061-T07 · Invariant clause:** Add a normative clause for “State ownership transfer” that preserves “Only the authorized current owner may commit state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State ownership transfer”; include the source counterexample “A moved replica continues writing from its old placement” and the intended safe disposition.
- [ ] **UC-M05.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “State bytes and ownership transfer time” in the “State ownership transfer” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C061-T10 · Contract review:** Review the “State ownership transfer” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C062 · Delivery

**Original checklist item:** Define state handoff and generation checks for stateful moves.

- [ ] **UC-M05.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State ownership transfer”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C062-T02 · Change plan:** Break the source delivery for “State ownership transfer” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C062-T03 · Core artifact:** Create the “State ownership transfer” model, schema or inventory that realizes this source instruction: Define state handoff and generation checks for stateful moves.
- [ ] **UC-M05.08-C062-T04 · Concrete realization:** Populate “State ownership transfer” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State ownership transfer” needed to preserve “Only the authorized current owner may commit state”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C062-T06 · Dependency connection:** Connect the “State ownership transfer” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C062-T07 · Resource behavior:** Account for “State bytes and ownership transfer time” in “State ownership transfer”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C062-T08 · Delivery check:** Run the smallest real “State ownership transfer” path and its adverse fixture “A moved replica continues writing from its old placement”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C062-T09 · Patch review:** Review the “State ownership transfer” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C062-T10 · Delivery handoff:** Publish the “State ownership transfer” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Only the authorized current owner may commit state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “State ownership transfer”; copy its required invariant exactly: “Only the authorized current owner may commit state”.
- [ ] **UC-M05.08-C063-T02 · Observable terms:** Define each term in the “State ownership transfer” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C063-T03 · Precondition set:** List the preconditions under which “Only the authorized current owner may commit state” must hold for “State ownership transfer”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C063-T04 · Transition coverage:** Map the “State ownership transfer” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State ownership transfer”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C063-T06 · Satisfying fixture:** Create a concrete “State ownership transfer” case that satisfies “Only the authorized current owner may commit state”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C063-T07 · Violating fixture:** Create the source counterexample “A moved replica continues writing from its old placement” for “State ownership transfer”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C063-T08 · Enforcement evidence:** Exercise the “State ownership transfer” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C063-T09 · Regression linkage:** Link the “State ownership transfer” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C063-T10 · Property disposition:** Compare the satisfying and violating “State ownership transfer” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C064 · Integration

**Original checklist item:** Integrate state ownership transfer with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State ownership transfer” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C064-T02 · Field mapping:** Map every “State ownership transfer” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “State ownership transfer” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C064-T04 · Ownership agreement:** Specify who owns “State ownership transfer” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C064-T05 · Handoff implementation:** Connect “State ownership transfer” through the mapped seam using the real adapter or explicit specification reference; preserve “Only the authorized current owner may commit state” across the handoff.
- [ ] **UC-M05.08-C064-T06 · Absent-input case:** Omit one required “State ownership transfer” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C064-T07 · Stale-input case:** Supply an outdated “State ownership transfer” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C064-T08 · Incompatible-input case:** Supply an incompatible “State ownership transfer” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C064-T09 · Valid integration trace:** Run a valid “State ownership transfer” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C064-T10 · Seam review:** Reconcile the “State ownership transfer” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for state ownership transfer; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “State ownership transfer” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C065-T02 · Expected-result oracle:** Specify the “State ownership transfer” expected result independently of the implementation output; include the property “Only the authorized current owner may commit state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C065-T03 · Fixture material:** Create the concrete “State ownership transfer” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C065-T04 · Target preparation:** Prepare the “State ownership transfer” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C065-T05 · Initial-state record:** Record the initial “State ownership transfer” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C065-T06 · Valid-path execution:** Execute the “State ownership transfer” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C065-T07 · Outcome comparison:** Compare every declared “State ownership transfer” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C065-T08 · State and bounds check:** Inspect the “State ownership transfer” ownership/state effects and actual use of “State bytes and ownership transfer time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C065-T09 · Repeatability check:** Repeat the same “State ownership transfer” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C065-T10 · Positive evidence:** Attach the “State ownership transfer” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C066 · Negative test

**Original checklist item:** Negative case: A moved replica continues writing from its old placement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “State ownership transfer” source counterexample: “A moved replica continues writing from its old placement”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “State ownership transfer”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C066-T03 · Valid control:** Construct a valid “State ownership transfer” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C066-T04 · Minimal adverse input:** Derive the “State ownership transfer” adverse fixture from the control with the smallest documented change needed to reproduce “A moved replica continues writing from its old placement”; retain that change as reproducible data.
- [ ] **UC-M05.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State ownership transfer”; require “Only the authorized current owner may commit state” and forbid a false-success verdict.
- [ ] **UC-M05.08-C066-T06 · Adverse execution:** Exercise the “State ownership transfer” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C066-T07 · Effect inspection:** Inspect “State ownership transfer” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C066-T08 · Refusal versus failure:** Confirm the “State ownership transfer” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C066-T09 · Reset and retention:** Restore only the disposable “State ownership transfer” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C066-T10 · Negative regression:** Register the “State ownership transfer” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C067 · Change / failure test

**Original checklist item:** Exercise state ownership transfer when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C067-T01 · Scenario record:** Write the “State ownership transfer” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Only the authorized current owner may commit state”.
- [ ] **UC-M05.08-C067-T02 · Baseline capture:** Create a known-valid “State ownership transfer” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C067-T03 · Injection map:** Locate the “State ownership transfer” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “State ownership transfer” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C067-T05 · Controlled trigger:** Introduce the controlled “State ownership transfer” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C067-T06 · Intermediate inspection:** Inspect the “State ownership transfer” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “State ownership transfer”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “State ownership transfer” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C067-T09 · Repeat and compare:** Repeat the selected “State ownership transfer” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C067-T10 · Failure evidence:** Publish the “State ownership transfer” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C068 · Bounds

**Original checklist item:** Choose, document and test limits for state bytes and ownership transfer time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “State ownership transfer”: “State bytes and ownership transfer time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C068-T02 · Measurement method:** Choose how to observe each “State ownership transfer” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C068-T03 · Budget decision:** Select justified resource and input limits for “State ownership transfer”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State ownership transfer” cases for “State bytes and ownership transfer time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State ownership transfer” limit; preserve “Only the authorized current owner may commit state”.
- [ ] **UC-M05.08-C068-T06 · Normal measurement:** Run or review the normal “State ownership transfer” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C068-T07 · At-limit measurement:** Exercise the “State ownership transfer” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C068-T08 · Over-limit measurement:** Exercise the “State ownership transfer” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C068-T09 · Uncovered-scope report:** List the “State ownership transfer” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C068-T10 · Limit evidence:** Publish the selected “State ownership transfer” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for state ownership transfer with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C069-T01 · Event inventory:** List the “State ownership transfer” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C069-T02 · Diagnostic schema:** Define nonsecret fields for “State ownership transfer” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C069-T03 · Failure mapping:** Map each documented “State ownership transfer” refusal or error to a diagnostic outcome; include “A moved replica continues writing from its old placement” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C069-T04 · Emission path:** Add the “State ownership transfer” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C069-T05 · Redaction check:** Test “State ownership transfer” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C069-T06 · Output budget:** Set and exercise bounded “State ownership transfer” message size, rate and retention compatible with “State bytes and ownership transfer time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C069-T07 · Success/refusal fixtures:** Capture “State ownership transfer” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “State ownership transfer” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C069-T09 · Operator review:** Read the “State ownership transfer” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C069-T10 · Diagnostic evidence:** Publish redacted “State ownership transfer” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state ownership transfer; label unexecuted checks as untested.

- [ ] **UC-M05.08-C070-T01 · Evidence inventory:** List the “State ownership transfer” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C070-T02 · Artifact references:** Record the exact “State ownership transfer” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C070-T03 · Fixture references:** Attach the “State ownership transfer” fixture IDs, input identities and oracle definition; preserve the source counterexample “A moved replica continues writing from its old placement” as a distinct evidence case.
- [ ] **UC-M05.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State ownership transfer”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C070-T05 · Environment record:** Record the actual “State ownership transfer” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C070-T06 · Expected versus observed:** Pair every “State ownership transfer” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C070-T07 · Failure and limit records:** Attach “State ownership transfer” change/failure and bounds evidence where required; include uncovered “State bytes and ownership transfer time” and unresolved violations of “Only the authorized current owner may commit state”.
- [ ] **UC-M05.08-C070-T08 · Evidence hygiene:** Check the “State ownership transfer” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C070-T09 · Reproduction review:** Have the “State ownership transfer” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C070-T10 · Acceptance linkage:** Link the “State ownership transfer” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Migration failure handling

**Source delivery:** Specify rollback or recovery when the replacement placement fails.

**Source invariant:** A failed move preserves a known disposition for accepted work and state.

**Source negative case:** The destination fails after the source has partially drained.

**Source bounded quantities:** Recovery deadline and retained generations.

### UC-M05.08-C071 · Contract

**Original checklist item:** Specify migration failure handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C071-T01 · Scope statement:** Draft the operation boundary for “Migration failure handling” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Migration failure handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C071-T03 · Output inventory:** List the outputs of “Migration failure handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Migration failure handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C071-T05 · Prerequisite contract:** Map “Migration failure handling” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Migration failure handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C071-T07 · Invariant clause:** Add a normative clause for “Migration failure handling” that preserves “A failed move preserves a known disposition for accepted work and state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Migration failure handling”; include the source counterexample “The destination fails after the source has partially drained” and the intended safe disposition.
- [ ] **UC-M05.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recovery deadline and retained generations” in the “Migration failure handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C071-T10 · Contract review:** Review the “Migration failure handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C072 · Delivery

**Original checklist item:** Specify rollback or recovery when the replacement placement fails.

- [ ] **UC-M05.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Migration failure handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C072-T02 · Change plan:** Break the source delivery for “Migration failure handling” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C072-T03 · Core artifact:** Create the “Migration failure handling” model, schema or inventory that realizes this source instruction: Specify rollback or recovery when the replacement placement fails.
- [ ] **UC-M05.08-C072-T04 · Concrete realization:** Populate “Migration failure handling” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Migration failure handling” needed to preserve “A failed move preserves a known disposition for accepted work and state”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C072-T06 · Dependency connection:** Connect the “Migration failure handling” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C072-T07 · Resource behavior:** Account for “Recovery deadline and retained generations” in “Migration failure handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C072-T08 · Delivery check:** Run the smallest real “Migration failure handling” path and its adverse fixture “The destination fails after the source has partially drained”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C072-T09 · Patch review:** Review the “Migration failure handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C072-T10 · Delivery handoff:** Publish the “Migration failure handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A failed move preserves a known disposition for accepted work and state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Migration failure handling”; copy its required invariant exactly: “A failed move preserves a known disposition for accepted work and state”.
- [ ] **UC-M05.08-C073-T02 · Observable terms:** Define each term in the “Migration failure handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C073-T03 · Precondition set:** List the preconditions under which “A failed move preserves a known disposition for accepted work and state” must hold for “Migration failure handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C073-T04 · Transition coverage:** Map the “Migration failure handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Migration failure handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C073-T06 · Satisfying fixture:** Create a concrete “Migration failure handling” case that satisfies “A failed move preserves a known disposition for accepted work and state”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C073-T07 · Violating fixture:** Create the source counterexample “The destination fails after the source has partially drained” for “Migration failure handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C073-T08 · Enforcement evidence:** Exercise the “Migration failure handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C073-T09 · Regression linkage:** Link the “Migration failure handling” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Migration failure handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C074 · Integration

**Original checklist item:** Integrate migration failure handling with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Migration failure handling” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C074-T02 · Field mapping:** Map every “Migration failure handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Migration failure handling” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C074-T04 · Ownership agreement:** Specify who owns “Migration failure handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C074-T05 · Handoff implementation:** Connect “Migration failure handling” through the mapped seam using the real adapter or explicit specification reference; preserve “A failed move preserves a known disposition for accepted work and state” across the handoff.
- [ ] **UC-M05.08-C074-T06 · Absent-input case:** Omit one required “Migration failure handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C074-T07 · Stale-input case:** Supply an outdated “Migration failure handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Migration failure handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C074-T09 · Valid integration trace:** Run a valid “Migration failure handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C074-T10 · Seam review:** Reconcile the “Migration failure handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for migration failure handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Migration failure handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C075-T02 · Expected-result oracle:** Specify the “Migration failure handling” expected result independently of the implementation output; include the property “A failed move preserves a known disposition for accepted work and state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C075-T03 · Fixture material:** Create the concrete “Migration failure handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C075-T04 · Target preparation:** Prepare the “Migration failure handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C075-T05 · Initial-state record:** Record the initial “Migration failure handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C075-T06 · Valid-path execution:** Execute the “Migration failure handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C075-T07 · Outcome comparison:** Compare every declared “Migration failure handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C075-T08 · State and bounds check:** Inspect the “Migration failure handling” ownership/state effects and actual use of “Recovery deadline and retained generations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C075-T09 · Repeatability check:** Repeat the same “Migration failure handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C075-T10 · Positive evidence:** Attach the “Migration failure handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C076 · Negative test

**Original checklist item:** Negative case: The destination fails after the source has partially drained. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Migration failure handling” source counterexample: “The destination fails after the source has partially drained”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Migration failure handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C076-T03 · Valid control:** Construct a valid “Migration failure handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C076-T04 · Minimal adverse input:** Derive the “Migration failure handling” adverse fixture from the control with the smallest documented change needed to reproduce “The destination fails after the source has partially drained”; retain that change as reproducible data.
- [ ] **UC-M05.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Migration failure handling”; require “A failed move preserves a known disposition for accepted work and state” and forbid a false-success verdict.
- [ ] **UC-M05.08-C076-T06 · Adverse execution:** Exercise the “Migration failure handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C076-T07 · Effect inspection:** Inspect “Migration failure handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C076-T08 · Refusal versus failure:** Confirm the “Migration failure handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C076-T09 · Reset and retention:** Restore only the disposable “Migration failure handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C076-T10 · Negative regression:** Register the “Migration failure handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C077 · Change / failure test

**Original checklist item:** Exercise migration failure handling when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C077-T01 · Scenario record:** Write the “Migration failure handling” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “A failed move preserves a known disposition for accepted work and state”.
- [ ] **UC-M05.08-C077-T02 · Baseline capture:** Create a known-valid “Migration failure handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C077-T03 · Injection map:** Locate the “Migration failure handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Migration failure handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C077-T05 · Controlled trigger:** Introduce the controlled “Migration failure handling” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C077-T06 · Intermediate inspection:** Inspect the “Migration failure handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Migration failure handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Migration failure handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C077-T09 · Repeat and compare:** Repeat the selected “Migration failure handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C077-T10 · Failure evidence:** Publish the “Migration failure handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C078 · Bounds

**Original checklist item:** Choose, document and test limits for recovery deadline and retained generations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Migration failure handling”: “Recovery deadline and retained generations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C078-T02 · Measurement method:** Choose how to observe each “Migration failure handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C078-T03 · Budget decision:** Select justified resource and input limits for “Migration failure handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Migration failure handling” cases for “Recovery deadline and retained generations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Migration failure handling” limit; preserve “A failed move preserves a known disposition for accepted work and state”.
- [ ] **UC-M05.08-C078-T06 · Normal measurement:** Run or review the normal “Migration failure handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C078-T07 · At-limit measurement:** Exercise the “Migration failure handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C078-T08 · Over-limit measurement:** Exercise the “Migration failure handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C078-T09 · Uncovered-scope report:** List the “Migration failure handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C078-T10 · Limit evidence:** Publish the selected “Migration failure handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for migration failure handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C079-T01 · Event inventory:** List the “Migration failure handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Migration failure handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C079-T03 · Failure mapping:** Map each documented “Migration failure handling” refusal or error to a diagnostic outcome; include “The destination fails after the source has partially drained” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C079-T04 · Emission path:** Add the “Migration failure handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C079-T05 · Redaction check:** Test “Migration failure handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C079-T06 · Output budget:** Set and exercise bounded “Migration failure handling” message size, rate and retention compatible with “Recovery deadline and retained generations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C079-T07 · Success/refusal fixtures:** Capture “Migration failure handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Migration failure handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C079-T09 · Operator review:** Read the “Migration failure handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C079-T10 · Diagnostic evidence:** Publish redacted “Migration failure handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for migration failure handling; label unexecuted checks as untested.

- [ ] **UC-M05.08-C080-T01 · Evidence inventory:** List the “Migration failure handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C080-T02 · Artifact references:** Record the exact “Migration failure handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C080-T03 · Fixture references:** Attach the “Migration failure handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “The destination fails after the source has partially drained” as a distinct evidence case.
- [ ] **UC-M05.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Migration failure handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C080-T05 · Environment record:** Record the actual “Migration failure handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C080-T06 · Expected versus observed:** Pair every “Migration failure handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C080-T07 · Failure and limit records:** Attach “Migration failure handling” change/failure and bounds evidence where required; include uncovered “Recovery deadline and retained generations” and unresolved violations of “A failed move preserves a known disposition for accepted work and state”.
- [ ] **UC-M05.08-C080-T08 · Evidence hygiene:** Check the “Migration failure handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C080-T09 · Reproduction review:** Have the “Migration failure handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C080-T10 · Acceptance linkage:** Link the “Migration failure handling” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Scaling reconciliation

**Source delivery:** Make repeated desired-replica updates idempotent and generation-aware.

**Source invariant:** Repeated scale requests do not create extra replicas.

**Source negative case:** A scale-out command is retried after an uncertain acknowledgment.

**Source bounded quantities:** Queued scaling requests and replica churn.

### UC-M05.08-C081 · Contract

**Original checklist item:** Specify scaling reconciliation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C081-T01 · Scope statement:** Draft the operation boundary for “Scaling reconciliation” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scaling reconciliation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C081-T03 · Output inventory:** List the outputs of “Scaling reconciliation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Scaling reconciliation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C081-T05 · Prerequisite contract:** Map “Scaling reconciliation” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Scaling reconciliation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C081-T07 · Invariant clause:** Add a normative clause for “Scaling reconciliation” that preserves “Repeated scale requests do not create extra replicas”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scaling reconciliation”; include the source counterexample “A scale-out command is retried after an uncertain acknowledgment” and the intended safe disposition.
- [ ] **UC-M05.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Queued scaling requests and replica churn” in the “Scaling reconciliation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C081-T10 · Contract review:** Review the “Scaling reconciliation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C082 · Delivery

**Original checklist item:** Make repeated desired-replica updates idempotent and generation-aware.

- [ ] **UC-M05.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scaling reconciliation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C082-T02 · Change plan:** Break the source delivery for “Scaling reconciliation” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Scaling reconciliation” that realizes this source instruction: Make repeated desired-replica updates idempotent and generation-aware.
- [ ] **UC-M05.08-C082-T04 · Concrete realization:** Trace “Scaling reconciliation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scaling reconciliation” needed to preserve “Repeated scale requests do not create extra replicas”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C082-T06 · Dependency connection:** Connect the “Scaling reconciliation” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C082-T07 · Resource behavior:** Account for “Queued scaling requests and replica churn” in “Scaling reconciliation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C082-T08 · Delivery check:** Run the smallest real “Scaling reconciliation” path and its adverse fixture “A scale-out command is retried after an uncertain acknowledgment”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C082-T09 · Patch review:** Review the “Scaling reconciliation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C082-T10 · Delivery handoff:** Publish the “Scaling reconciliation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Repeated scale requests do not create extra replicas. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Scaling reconciliation”; copy its required invariant exactly: “Repeated scale requests do not create extra replicas”.
- [ ] **UC-M05.08-C083-T02 · Observable terms:** Define each term in the “Scaling reconciliation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C083-T03 · Precondition set:** List the preconditions under which “Repeated scale requests do not create extra replicas” must hold for “Scaling reconciliation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C083-T04 · Transition coverage:** Map the “Scaling reconciliation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scaling reconciliation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C083-T06 · Satisfying fixture:** Create a concrete “Scaling reconciliation” case that satisfies “Repeated scale requests do not create extra replicas”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C083-T07 · Violating fixture:** Create the source counterexample “A scale-out command is retried after an uncertain acknowledgment” for “Scaling reconciliation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C083-T08 · Enforcement evidence:** Exercise the “Scaling reconciliation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C083-T09 · Regression linkage:** Link the “Scaling reconciliation” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Scaling reconciliation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C084 · Integration

**Original checklist item:** Integrate scaling reconciliation with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scaling reconciliation” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C084-T02 · Field mapping:** Map every “Scaling reconciliation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Scaling reconciliation” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C084-T04 · Ownership agreement:** Specify who owns “Scaling reconciliation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C084-T05 · Handoff implementation:** Connect “Scaling reconciliation” through the mapped seam using the real adapter or explicit specification reference; preserve “Repeated scale requests do not create extra replicas” across the handoff.
- [ ] **UC-M05.08-C084-T06 · Absent-input case:** Omit one required “Scaling reconciliation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C084-T07 · Stale-input case:** Supply an outdated “Scaling reconciliation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Scaling reconciliation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C084-T09 · Valid integration trace:** Run a valid “Scaling reconciliation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C084-T10 · Seam review:** Reconcile the “Scaling reconciliation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scaling reconciliation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scaling reconciliation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C085-T02 · Expected-result oracle:** Specify the “Scaling reconciliation” expected result independently of the implementation output; include the property “Repeated scale requests do not create extra replicas” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C085-T03 · Fixture material:** Create the concrete “Scaling reconciliation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C085-T04 · Target preparation:** Prepare the “Scaling reconciliation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C085-T05 · Initial-state record:** Record the initial “Scaling reconciliation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C085-T06 · Valid-path execution:** Execute the “Scaling reconciliation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C085-T07 · Outcome comparison:** Compare every declared “Scaling reconciliation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C085-T08 · State and bounds check:** Inspect the “Scaling reconciliation” ownership/state effects and actual use of “Queued scaling requests and replica churn”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C085-T09 · Repeatability check:** Repeat the same “Scaling reconciliation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C085-T10 · Positive evidence:** Attach the “Scaling reconciliation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C086 · Negative test

**Original checklist item:** Negative case: A scale-out command is retried after an uncertain acknowledgment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Scaling reconciliation” source counterexample: “A scale-out command is retried after an uncertain acknowledgment”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Scaling reconciliation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C086-T03 · Valid control:** Construct a valid “Scaling reconciliation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C086-T04 · Minimal adverse input:** Derive the “Scaling reconciliation” adverse fixture from the control with the smallest documented change needed to reproduce “A scale-out command is retried after an uncertain acknowledgment”; retain that change as reproducible data.
- [ ] **UC-M05.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scaling reconciliation”; require “Repeated scale requests do not create extra replicas” and forbid a false-success verdict.
- [ ] **UC-M05.08-C086-T06 · Adverse execution:** Exercise the “Scaling reconciliation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C086-T07 · Effect inspection:** Inspect “Scaling reconciliation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C086-T08 · Refusal versus failure:** Confirm the “Scaling reconciliation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C086-T09 · Reset and retention:** Restore only the disposable “Scaling reconciliation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C086-T10 · Negative regression:** Register the “Scaling reconciliation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C087 · Change / failure test

**Original checklist item:** Exercise scaling reconciliation when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C087-T01 · Scenario record:** Write the “Scaling reconciliation” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Repeated scale requests do not create extra replicas”.
- [ ] **UC-M05.08-C087-T02 · Baseline capture:** Create a known-valid “Scaling reconciliation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C087-T03 · Injection map:** Locate the “Scaling reconciliation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Scaling reconciliation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C087-T05 · Controlled trigger:** Introduce the controlled “Scaling reconciliation” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C087-T06 · Intermediate inspection:** Inspect the “Scaling reconciliation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scaling reconciliation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Scaling reconciliation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C087-T09 · Repeat and compare:** Repeat the selected “Scaling reconciliation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C087-T10 · Failure evidence:** Publish the “Scaling reconciliation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C088 · Bounds

**Original checklist item:** Choose, document and test limits for queued scaling requests and replica churn; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Scaling reconciliation”: “Queued scaling requests and replica churn”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C088-T02 · Measurement method:** Choose how to observe each “Scaling reconciliation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C088-T03 · Budget decision:** Select justified resource and input limits for “Scaling reconciliation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scaling reconciliation” cases for “Queued scaling requests and replica churn”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scaling reconciliation” limit; preserve “Repeated scale requests do not create extra replicas”.
- [ ] **UC-M05.08-C088-T06 · Normal measurement:** Run or review the normal “Scaling reconciliation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C088-T07 · At-limit measurement:** Exercise the “Scaling reconciliation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C088-T08 · Over-limit measurement:** Exercise the “Scaling reconciliation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C088-T09 · Uncovered-scope report:** List the “Scaling reconciliation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C088-T10 · Limit evidence:** Publish the selected “Scaling reconciliation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scaling reconciliation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C089-T01 · Event inventory:** List the “Scaling reconciliation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Scaling reconciliation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C089-T03 · Failure mapping:** Map each documented “Scaling reconciliation” refusal or error to a diagnostic outcome; include “A scale-out command is retried after an uncertain acknowledgment” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C089-T04 · Emission path:** Add the “Scaling reconciliation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C089-T05 · Redaction check:** Test “Scaling reconciliation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C089-T06 · Output budget:** Set and exercise bounded “Scaling reconciliation” message size, rate and retention compatible with “Queued scaling requests and replica churn”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C089-T07 · Success/refusal fixtures:** Capture “Scaling reconciliation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scaling reconciliation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C089-T09 · Operator review:** Read the “Scaling reconciliation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C089-T10 · Diagnostic evidence:** Publish redacted “Scaling reconciliation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scaling reconciliation; label unexecuted checks as untested.

- [ ] **UC-M05.08-C090-T01 · Evidence inventory:** List the “Scaling reconciliation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C090-T02 · Artifact references:** Record the exact “Scaling reconciliation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C090-T03 · Fixture references:** Attach the “Scaling reconciliation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A scale-out command is retried after an uncertain acknowledgment” as a distinct evidence case.
- [ ] **UC-M05.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scaling reconciliation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C090-T05 · Environment record:** Record the actual “Scaling reconciliation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C090-T06 · Expected versus observed:** Pair every “Scaling reconciliation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C090-T07 · Failure and limit records:** Attach “Scaling reconciliation” change/failure and bounds evidence where required; include uncovered “Queued scaling requests and replica churn” and unresolved violations of “Repeated scale requests do not create extra replicas”.
- [ ] **UC-M05.08-C090-T08 · Evidence hygiene:** Check the “Scaling reconciliation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C090-T09 · Reproduction review:** Have the “Scaling reconciliation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C090-T10 · Acceptance linkage:** Link the “Scaling reconciliation” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Scaling acceptance

**Source delivery:** Exercise growth, shrinkage and interrupted migration with quota checks.

**Source invariant:** Scaling preserves accepted requests and declared state semantics.

**Source negative case:** A scale-in test passes despite a lost in-flight operation.

**Source bounded quantities:** Replica matrix, request volume and test duration.

### UC-M05.08-C091 · Contract

**Original checklist item:** Specify scaling acceptance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.08-C091-T01 · Scope statement:** Draft the operation boundary for “Scaling acceptance” within Replica scaling and placement migration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scaling acceptance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.08-C091-T03 · Output inventory:** List the outputs of “Scaling acceptance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Scaling acceptance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.08-C091-T05 · Prerequisite contract:** Map “Scaling acceptance” to the source component prerequisites (UC-M05.02, UC-M05.06, UC-M05.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.08-C091-T06 · Authority map:** Identify who may produce, change and consume “Scaling acceptance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.08-C091-T07 · Invariant clause:** Add a normative clause for “Scaling acceptance” that preserves “Scaling preserves accepted requests and declared state semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scaling acceptance”; include the source counterexample “A scale-in test passes despite a lost in-flight operation” and the intended safe disposition.
- [ ] **UC-M05.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Replica matrix, request volume and test duration” in the “Scaling acceptance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.08-C091-T10 · Contract review:** Review the “Scaling acceptance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.08-C092 · Delivery

**Original checklist item:** Exercise growth, shrinkage and interrupted migration with quota checks.

- [ ] **UC-M05.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scaling acceptance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.08-C092-T02 · Change plan:** Break the source delivery for “Scaling acceptance” into concrete edit targets and reviewable outputs; keep the UC-M05.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.08-C092-T03 · Core artifact:** Create the “Scaling acceptance” fixture or harness for this source instruction: Exercise growth, shrinkage and interrupted migration with quota checks.
- [ ] **UC-M05.08-C092-T04 · Concrete realization:** Connect the “Scaling acceptance” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scaling acceptance” needed to preserve “Scaling preserves accepted requests and declared state semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.08-C092-T06 · Dependency connection:** Connect the “Scaling acceptance” implementation to replica reservations, readiness routing and state ownership transfer; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.08-C092-T07 · Resource behavior:** Account for “Replica matrix, request volume and test duration” in “Scaling acceptance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.08-C092-T08 · Delivery check:** Run the smallest real “Scaling acceptance” path and its adverse fixture “A scale-in test passes despite a lost in-flight operation”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.08-C092-T09 · Patch review:** Review the “Scaling acceptance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.08-C092-T10 · Delivery handoff:** Publish the “Scaling acceptance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Scaling preserves accepted requests and declared state semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “Scaling acceptance”; copy its required invariant exactly: “Scaling preserves accepted requests and declared state semantics”.
- [ ] **UC-M05.08-C093-T02 · Observable terms:** Define each term in the “Scaling acceptance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.08-C093-T03 · Precondition set:** List the preconditions under which “Scaling preserves accepted requests and declared state semantics” must hold for “Scaling acceptance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.08-C093-T04 · Transition coverage:** Map the “Scaling acceptance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scaling acceptance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.08-C093-T06 · Satisfying fixture:** Create a concrete “Scaling acceptance” case that satisfies “Scaling preserves accepted requests and declared state semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.08-C093-T07 · Violating fixture:** Create the source counterexample “A scale-in test passes despite a lost in-flight operation” for “Scaling acceptance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.08-C093-T08 · Enforcement evidence:** Exercise the “Scaling acceptance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.08-C093-T09 · Regression linkage:** Link the “Scaling acceptance” property to changes in replica reservations, readiness routing and state ownership transfer; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.08-C093-T10 · Property disposition:** Compare the satisfying and violating “Scaling acceptance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.08-C094 · Integration

**Original checklist item:** Integrate scaling acceptance with replica reservations, readiness routing and state ownership transfer; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scaling acceptance” across replica reservations, readiness routing and state ownership transfer; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.08-C094-T02 · Field mapping:** Map every “Scaling acceptance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Scaling acceptance” (source dependency list: UC-M05.02, UC-M05.06, UC-M05.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.08-C094-T04 · Ownership agreement:** Specify who owns “Scaling acceptance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.08-C094-T05 · Handoff implementation:** Connect “Scaling acceptance” through the mapped seam using the real adapter or explicit specification reference; preserve “Scaling preserves accepted requests and declared state semantics” across the handoff.
- [ ] **UC-M05.08-C094-T06 · Absent-input case:** Omit one required “Scaling acceptance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.08-C094-T07 · Stale-input case:** Supply an outdated “Scaling acceptance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.08-C094-T08 · Incompatible-input case:** Supply an incompatible “Scaling acceptance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.08-C094-T09 · Valid integration trace:** Run a valid “Scaling acceptance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.08-C094-T10 · Seam review:** Reconcile the “Scaling acceptance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.08-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scaling acceptance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.08-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scaling acceptance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.08-C095-T02 · Expected-result oracle:** Specify the “Scaling acceptance” expected result independently of the implementation output; include the property “Scaling preserves accepted requests and declared state semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.08-C095-T03 · Fixture material:** Create the concrete “Scaling acceptance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.08-C095-T04 · Target preparation:** Prepare the “Scaling acceptance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.08-C095-T05 · Initial-state record:** Record the initial “Scaling acceptance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.08-C095-T06 · Valid-path execution:** Execute the “Scaling acceptance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.08-C095-T07 · Outcome comparison:** Compare every declared “Scaling acceptance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.08-C095-T08 · State and bounds check:** Inspect the “Scaling acceptance” ownership/state effects and actual use of “Replica matrix, request volume and test duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.08-C095-T09 · Repeatability check:** Repeat the same “Scaling acceptance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.08-C095-T10 · Positive evidence:** Attach the “Scaling acceptance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.08-C096 · Negative test

**Original checklist item:** Negative case: A scale-in test passes despite a lost in-flight operation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “Scaling acceptance” source counterexample: “A scale-in test passes despite a lost in-flight operation”; state which precondition or invariant it challenges.
- [ ] **UC-M05.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Scaling acceptance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.08-C096-T03 · Valid control:** Construct a valid “Scaling acceptance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.08-C096-T04 · Minimal adverse input:** Derive the “Scaling acceptance” adverse fixture from the control with the smallest documented change needed to reproduce “A scale-in test passes despite a lost in-flight operation”; retain that change as reproducible data.
- [ ] **UC-M05.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scaling acceptance”; require “Scaling preserves accepted requests and declared state semantics” and forbid a false-success verdict.
- [ ] **UC-M05.08-C096-T06 · Adverse execution:** Exercise the “Scaling acceptance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.08-C096-T07 · Effect inspection:** Inspect “Scaling acceptance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.08-C096-T08 · Refusal versus failure:** Confirm the “Scaling acceptance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.08-C096-T09 · Reset and retention:** Restore only the disposable “Scaling acceptance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.08-C096-T10 · Negative regression:** Register the “Scaling acceptance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.08-C097 · Change / failure test

**Original checklist item:** Exercise scaling acceptance when a scale-in or placement move fails while accepted requests remain active; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.08-C097-T01 · Scenario record:** Write the “Scaling acceptance” change/failure scenario exactly as supplied: a scale-in or placement move fails while accepted requests remain active; identify the property that must remain true: “Scaling preserves accepted requests and declared state semantics”.
- [ ] **UC-M05.08-C097-T02 · Baseline capture:** Create a known-valid “Scaling acceptance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.08-C097-T03 · Injection map:** Locate the “Scaling acceptance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Scaling acceptance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.08-C097-T05 · Controlled trigger:** Introduce the controlled “Scaling acceptance” scenario in the disposable fixture: a scale-in or placement move fails while accepted requests remain active; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.08-C097-T06 · Intermediate inspection:** Inspect the “Scaling acceptance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scaling acceptance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Scaling acceptance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.08-C097-T09 · Repeat and compare:** Repeat the selected “Scaling acceptance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.08-C097-T10 · Failure evidence:** Publish the “Scaling acceptance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.08-C098 · Bounds

**Original checklist item:** Choose, document and test limits for replica matrix, request volume and test duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “Scaling acceptance”: “Replica matrix, request volume and test duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.08-C098-T02 · Measurement method:** Choose how to observe each “Scaling acceptance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.08-C098-T03 · Budget decision:** Select justified resource and input limits for “Scaling acceptance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scaling acceptance” cases for “Replica matrix, request volume and test duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scaling acceptance” limit; preserve “Scaling preserves accepted requests and declared state semantics”.
- [ ] **UC-M05.08-C098-T06 · Normal measurement:** Run or review the normal “Scaling acceptance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.08-C098-T07 · At-limit measurement:** Exercise the “Scaling acceptance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.08-C098-T08 · Over-limit measurement:** Exercise the “Scaling acceptance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.08-C098-T09 · Uncovered-scope report:** List the “Scaling acceptance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.08-C098-T10 · Limit evidence:** Publish the selected “Scaling acceptance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.08-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scaling acceptance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.08-C099-T01 · Event inventory:** List the “Scaling acceptance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.08-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Scaling acceptance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.08-C099-T03 · Failure mapping:** Map each documented “Scaling acceptance” refusal or error to a diagnostic outcome; include “A scale-in test passes despite a lost in-flight operation” and prohibit conversion into a success message.
- [ ] **UC-M05.08-C099-T04 · Emission path:** Add the “Scaling acceptance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.08-C099-T05 · Redaction check:** Test “Scaling acceptance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.08-C099-T06 · Output budget:** Set and exercise bounded “Scaling acceptance” message size, rate and retention compatible with “Replica matrix, request volume and test duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.08-C099-T07 · Success/refusal fixtures:** Capture “Scaling acceptance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.08-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scaling acceptance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.08-C099-T09 · Operator review:** Read the “Scaling acceptance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.08-C099-T10 · Diagnostic evidence:** Publish redacted “Scaling acceptance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scaling acceptance; label unexecuted checks as untested.

- [ ] **UC-M05.08-C100-T01 · Evidence inventory:** List the “Scaling acceptance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.08-C100-T02 · Artifact references:** Record the exact “Scaling acceptance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.08-C100-T03 · Fixture references:** Attach the “Scaling acceptance” fixture IDs, input identities and oracle definition; preserve the source counterexample “A scale-in test passes despite a lost in-flight operation” as a distinct evidence case.
- [ ] **UC-M05.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scaling acceptance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.08-C100-T05 · Environment record:** Record the actual “Scaling acceptance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.08-C100-T06 · Expected versus observed:** Pair every “Scaling acceptance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.08-C100-T07 · Failure and limit records:** Attach “Scaling acceptance” change/failure and bounds evidence where required; include uncovered “Replica matrix, request volume and test duration” and unresolved violations of “Scaling preserves accepted requests and declared state semantics”.
- [ ] **UC-M05.08-C100-T08 · Evidence hygiene:** Check the “Scaling acceptance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.08-C100-T09 · Reproduction review:** Have the “Scaling acceptance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.08-C100-T10 · Acceptance linkage:** Link the “Scaling acceptance” evidence to its parent and UC-M05.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

