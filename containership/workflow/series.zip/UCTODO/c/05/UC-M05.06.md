# UC-M05.06 — Graceful stop and drain protocol

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/05.md)

| Field | Preserved source value |
|---|---|
| Workstream | 05. Workload orchestration and scheduling |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M05.04](../05/UC-M05.04.md), [UC-M05.05](../05/UC-M05.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S6]. |

## Original requirement

Stop admission, drain accepted work, flush state within a bound, then terminate and preserve a definitive exit reason.

**Original acceptance criterion:** Stop during active I/O either commits or records an interrupted operation without silently reporting completion.

**Source trace:** Original checklist `UC100/c/05/UC-M05.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 484–494 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Admission closure

**Source delivery:** Stop accepting new work before beginning the drain phase.

**Source invariant:** A draining workload cannot accept untracked new requests.

**Source negative case:** A request arrives just after drain begins.

**Source bounded quantities:** Admission race window and queued requests.

### UC-M05.06-C001 · Contract

**Original checklist item:** Specify admission closure inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C001-T01 · Scope statement:** Draft the operation boundary for “Admission closure” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Admission closure”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C001-T03 · Output inventory:** List the outputs of “Admission closure” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Admission closure”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C001-T05 · Prerequisite contract:** Map “Admission closure” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Admission closure”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C001-T07 · Invariant clause:** Add a normative clause for “Admission closure” that preserves “A draining workload cannot accept untracked new requests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Admission closure”; include the source counterexample “A request arrives just after drain begins” and the intended safe disposition.
- [ ] **UC-M05.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Admission race window and queued requests” in the “Admission closure” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C001-T10 · Contract review:** Review the “Admission closure” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C002 · Delivery

**Original checklist item:** Stop accepting new work before beginning the drain phase.

- [ ] **UC-M05.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Admission closure”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C002-T02 · Change plan:** Break the source delivery for “Admission closure” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Admission closure” that realizes this source instruction: Stop accepting new work before beginning the drain phase.
- [ ] **UC-M05.06-C002-T04 · Concrete realization:** Trace “Admission closure” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Admission closure” needed to preserve “A draining workload cannot accept untracked new requests”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C002-T06 · Dependency connection:** Connect the “Admission closure” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C002-T07 · Resource behavior:** Account for “Admission race window and queued requests” in “Admission closure”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C002-T08 · Delivery check:** Run the smallest real “Admission closure” path and its adverse fixture “A request arrives just after drain begins”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C002-T09 · Patch review:** Review the “Admission closure” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C002-T10 · Delivery handoff:** Publish the “Admission closure” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A draining workload cannot accept untracked new requests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Admission closure”; copy its required invariant exactly: “A draining workload cannot accept untracked new requests”.
- [ ] **UC-M05.06-C003-T02 · Observable terms:** Define each term in the “Admission closure” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C003-T03 · Precondition set:** List the preconditions under which “A draining workload cannot accept untracked new requests” must hold for “Admission closure”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C003-T04 · Transition coverage:** Map the “Admission closure” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Admission closure”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C003-T06 · Satisfying fixture:** Create a concrete “Admission closure” case that satisfies “A draining workload cannot accept untracked new requests”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C003-T07 · Violating fixture:** Create the source counterexample “A request arrives just after drain begins” for “Admission closure”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C003-T08 · Enforcement evidence:** Exercise the “Admission closure” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C003-T09 · Regression linkage:** Link the “Admission closure” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Admission closure” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C004 · Integration

**Original checklist item:** Integrate admission closure with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Admission closure” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C004-T02 · Field mapping:** Map every “Admission closure” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Admission closure” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C004-T04 · Ownership agreement:** Specify who owns “Admission closure” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C004-T05 · Handoff implementation:** Connect “Admission closure” through the mapped seam using the real adapter or explicit specification reference; preserve “A draining workload cannot accept untracked new requests” across the handoff.
- [ ] **UC-M05.06-C004-T06 · Absent-input case:** Omit one required “Admission closure” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C004-T07 · Stale-input case:** Supply an outdated “Admission closure” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Admission closure” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C004-T09 · Valid integration trace:** Run a valid “Admission closure” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C004-T10 · Seam review:** Reconcile the “Admission closure” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for admission closure; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Admission closure” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C005-T02 · Expected-result oracle:** Specify the “Admission closure” expected result independently of the implementation output; include the property “A draining workload cannot accept untracked new requests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C005-T03 · Fixture material:** Create the concrete “Admission closure” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C005-T04 · Target preparation:** Prepare the “Admission closure” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C005-T05 · Initial-state record:** Record the initial “Admission closure” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C005-T06 · Valid-path execution:** Execute the “Admission closure” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C005-T07 · Outcome comparison:** Compare every declared “Admission closure” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C005-T08 · State and bounds check:** Inspect the “Admission closure” ownership/state effects and actual use of “Admission race window and queued requests”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C005-T09 · Repeatability check:** Repeat the same “Admission closure” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C005-T10 · Positive evidence:** Attach the “Admission closure” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C006 · Negative test

**Original checklist item:** Negative case: A request arrives just after drain begins. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Admission closure” source counterexample: “A request arrives just after drain begins”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Admission closure”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C006-T03 · Valid control:** Construct a valid “Admission closure” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C006-T04 · Minimal adverse input:** Derive the “Admission closure” adverse fixture from the control with the smallest documented change needed to reproduce “A request arrives just after drain begins”; retain that change as reproducible data.
- [ ] **UC-M05.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Admission closure”; require “A draining workload cannot accept untracked new requests” and forbid a false-success verdict.
- [ ] **UC-M05.06-C006-T06 · Adverse execution:** Exercise the “Admission closure” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C006-T07 · Effect inspection:** Inspect “Admission closure” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C006-T08 · Refusal versus failure:** Confirm the “Admission closure” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C006-T09 · Reset and retention:** Restore only the disposable “Admission closure” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C006-T10 · Negative regression:** Register the “Admission closure” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C007 · Change / failure test

**Original checklist item:** Exercise admission closure when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C007-T01 · Scenario record:** Write the “Admission closure” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “A draining workload cannot accept untracked new requests”.
- [ ] **UC-M05.06-C007-T02 · Baseline capture:** Create a known-valid “Admission closure” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C007-T03 · Injection map:** Locate the “Admission closure” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Admission closure” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C007-T05 · Controlled trigger:** Introduce the controlled “Admission closure” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C007-T06 · Intermediate inspection:** Inspect the “Admission closure” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Admission closure”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Admission closure” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C007-T09 · Repeat and compare:** Repeat the selected “Admission closure” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C007-T10 · Failure evidence:** Publish the “Admission closure” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for admission race window and queued requests; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Admission closure”: “Admission race window and queued requests”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C008-T02 · Measurement method:** Choose how to observe each “Admission closure” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Admission closure”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Admission closure” cases for “Admission race window and queued requests”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Admission closure” limit; preserve “A draining workload cannot accept untracked new requests”.
- [ ] **UC-M05.06-C008-T06 · Normal measurement:** Run or review the normal “Admission closure” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C008-T07 · At-limit measurement:** Exercise the “Admission closure” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C008-T08 · Over-limit measurement:** Exercise the “Admission closure” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C008-T09 · Uncovered-scope report:** List the “Admission closure” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C008-T10 · Limit evidence:** Publish the selected “Admission closure” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for admission closure with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C009-T01 · Event inventory:** List the “Admission closure” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Admission closure” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C009-T03 · Failure mapping:** Map each documented “Admission closure” refusal or error to a diagnostic outcome; include “A request arrives just after drain begins” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C009-T04 · Emission path:** Add the “Admission closure” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C009-T05 · Redaction check:** Test “Admission closure” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C009-T06 · Output budget:** Set and exercise bounded “Admission closure” message size, rate and retention compatible with “Admission race window and queued requests”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C009-T07 · Success/refusal fixtures:** Capture “Admission closure” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Admission closure” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C009-T09 · Operator review:** Read the “Admission closure” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C009-T10 · Diagnostic evidence:** Publish redacted “Admission closure” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for admission closure; label unexecuted checks as untested.

- [ ] **UC-M05.06-C010-T01 · Evidence inventory:** List the “Admission closure” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C010-T02 · Artifact references:** Record the exact “Admission closure” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C010-T03 · Fixture references:** Attach the “Admission closure” fixture IDs, input identities and oracle definition; preserve the source counterexample “A request arrives just after drain begins” as a distinct evidence case.
- [ ] **UC-M05.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Admission closure”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C010-T05 · Environment record:** Record the actual “Admission closure” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C010-T06 · Expected versus observed:** Pair every “Admission closure” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C010-T07 · Failure and limit records:** Attach “Admission closure” change/failure and bounds evidence where required; include uncovered “Admission race window and queued requests” and unresolved violations of “A draining workload cannot accept untracked new requests”.
- [ ] **UC-M05.06-C010-T08 · Evidence hygiene:** Check the “Admission closure” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C010-T09 · Reproduction review:** Have the “Admission closure” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C010-T10 · Acceptance linkage:** Link the “Admission closure” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Accepted-work census

**Source delivery:** Identify every accepted invocation and outstanding I/O operation.

**Source invariant:** Drain decisions account for already accepted work.

**Source negative case:** An in-flight request is omitted from the drain inventory.

**Source bounded quantities:** Active requests and census duration.

### UC-M05.06-C011 · Contract

**Original checklist item:** Specify accepted-work census inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C011-T01 · Scope statement:** Draft the operation boundary for “Accepted-work census” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Accepted-work census”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C011-T03 · Output inventory:** List the outputs of “Accepted-work census” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Accepted-work census”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C011-T05 · Prerequisite contract:** Map “Accepted-work census” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Accepted-work census”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C011-T07 · Invariant clause:** Add a normative clause for “Accepted-work census” that preserves “Drain decisions account for already accepted work”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Accepted-work census”; include the source counterexample “An in-flight request is omitted from the drain inventory” and the intended safe disposition.
- [ ] **UC-M05.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Active requests and census duration” in the “Accepted-work census” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C011-T10 · Contract review:** Review the “Accepted-work census” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C012 · Delivery

**Original checklist item:** Identify every accepted invocation and outstanding I/O operation.

- [ ] **UC-M05.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Accepted-work census”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C012-T02 · Change plan:** Break the source delivery for “Accepted-work census” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C012-T03 · Core artifact:** Create the “Accepted-work census” model, schema or inventory that realizes this source instruction: Identify every accepted invocation and outstanding I/O operation.
- [ ] **UC-M05.06-C012-T04 · Concrete realization:** Populate “Accepted-work census” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Accepted-work census” needed to preserve “Drain decisions account for already accepted work”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C012-T06 · Dependency connection:** Connect the “Accepted-work census” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C012-T07 · Resource behavior:** Account for “Active requests and census duration” in “Accepted-work census”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C012-T08 · Delivery check:** Run the smallest real “Accepted-work census” path and its adverse fixture “An in-flight request is omitted from the drain inventory”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C012-T09 · Patch review:** Review the “Accepted-work census” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C012-T10 · Delivery handoff:** Publish the “Accepted-work census” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Drain decisions account for already accepted work. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Accepted-work census”; copy its required invariant exactly: “Drain decisions account for already accepted work”.
- [ ] **UC-M05.06-C013-T02 · Observable terms:** Define each term in the “Accepted-work census” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C013-T03 · Precondition set:** List the preconditions under which “Drain decisions account for already accepted work” must hold for “Accepted-work census”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C013-T04 · Transition coverage:** Map the “Accepted-work census” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Accepted-work census”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C013-T06 · Satisfying fixture:** Create a concrete “Accepted-work census” case that satisfies “Drain decisions account for already accepted work”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C013-T07 · Violating fixture:** Create the source counterexample “An in-flight request is omitted from the drain inventory” for “Accepted-work census”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C013-T08 · Enforcement evidence:** Exercise the “Accepted-work census” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C013-T09 · Regression linkage:** Link the “Accepted-work census” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Accepted-work census” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C014 · Integration

**Original checklist item:** Integrate accepted-work census with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Accepted-work census” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C014-T02 · Field mapping:** Map every “Accepted-work census” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Accepted-work census” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C014-T04 · Ownership agreement:** Specify who owns “Accepted-work census” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C014-T05 · Handoff implementation:** Connect “Accepted-work census” through the mapped seam using the real adapter or explicit specification reference; preserve “Drain decisions account for already accepted work” across the handoff.
- [ ] **UC-M05.06-C014-T06 · Absent-input case:** Omit one required “Accepted-work census” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C014-T07 · Stale-input case:** Supply an outdated “Accepted-work census” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Accepted-work census” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C014-T09 · Valid integration trace:** Run a valid “Accepted-work census” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C014-T10 · Seam review:** Reconcile the “Accepted-work census” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for accepted-work census; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Accepted-work census” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C015-T02 · Expected-result oracle:** Specify the “Accepted-work census” expected result independently of the implementation output; include the property “Drain decisions account for already accepted work” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C015-T03 · Fixture material:** Create the concrete “Accepted-work census” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C015-T04 · Target preparation:** Prepare the “Accepted-work census” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C015-T05 · Initial-state record:** Record the initial “Accepted-work census” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C015-T06 · Valid-path execution:** Execute the “Accepted-work census” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C015-T07 · Outcome comparison:** Compare every declared “Accepted-work census” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C015-T08 · State and bounds check:** Inspect the “Accepted-work census” ownership/state effects and actual use of “Active requests and census duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C015-T09 · Repeatability check:** Repeat the same “Accepted-work census” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C015-T10 · Positive evidence:** Attach the “Accepted-work census” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C016 · Negative test

**Original checklist item:** Negative case: An in-flight request is omitted from the drain inventory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Accepted-work census” source counterexample: “An in-flight request is omitted from the drain inventory”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Accepted-work census”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C016-T03 · Valid control:** Construct a valid “Accepted-work census” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C016-T04 · Minimal adverse input:** Derive the “Accepted-work census” adverse fixture from the control with the smallest documented change needed to reproduce “An in-flight request is omitted from the drain inventory”; retain that change as reproducible data.
- [ ] **UC-M05.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Accepted-work census”; require “Drain decisions account for already accepted work” and forbid a false-success verdict.
- [ ] **UC-M05.06-C016-T06 · Adverse execution:** Exercise the “Accepted-work census” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C016-T07 · Effect inspection:** Inspect “Accepted-work census” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C016-T08 · Refusal versus failure:** Confirm the “Accepted-work census” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C016-T09 · Reset and retention:** Restore only the disposable “Accepted-work census” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C016-T10 · Negative regression:** Register the “Accepted-work census” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C017 · Change / failure test

**Original checklist item:** Exercise accepted-work census when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C017-T01 · Scenario record:** Write the “Accepted-work census” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “Drain decisions account for already accepted work”.
- [ ] **UC-M05.06-C017-T02 · Baseline capture:** Create a known-valid “Accepted-work census” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C017-T03 · Injection map:** Locate the “Accepted-work census” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Accepted-work census” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C017-T05 · Controlled trigger:** Introduce the controlled “Accepted-work census” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C017-T06 · Intermediate inspection:** Inspect the “Accepted-work census” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Accepted-work census”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Accepted-work census” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C017-T09 · Repeat and compare:** Repeat the selected “Accepted-work census” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C017-T10 · Failure evidence:** Publish the “Accepted-work census” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for active requests and census duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Accepted-work census”: “Active requests and census duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C018-T02 · Measurement method:** Choose how to observe each “Accepted-work census” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Accepted-work census”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Accepted-work census” cases for “Active requests and census duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Accepted-work census” limit; preserve “Drain decisions account for already accepted work”.
- [ ] **UC-M05.06-C018-T06 · Normal measurement:** Run or review the normal “Accepted-work census” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C018-T07 · At-limit measurement:** Exercise the “Accepted-work census” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C018-T08 · Over-limit measurement:** Exercise the “Accepted-work census” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C018-T09 · Uncovered-scope report:** List the “Accepted-work census” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C018-T10 · Limit evidence:** Publish the selected “Accepted-work census” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for accepted-work census with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C019-T01 · Event inventory:** List the “Accepted-work census” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Accepted-work census” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C019-T03 · Failure mapping:** Map each documented “Accepted-work census” refusal or error to a diagnostic outcome; include “An in-flight request is omitted from the drain inventory” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C019-T04 · Emission path:** Add the “Accepted-work census” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C019-T05 · Redaction check:** Test “Accepted-work census” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C019-T06 · Output budget:** Set and exercise bounded “Accepted-work census” message size, rate and retention compatible with “Active requests and census duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C019-T07 · Success/refusal fixtures:** Capture “Accepted-work census” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Accepted-work census” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C019-T09 · Operator review:** Read the “Accepted-work census” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C019-T10 · Diagnostic evidence:** Publish redacted “Accepted-work census” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for accepted-work census; label unexecuted checks as untested.

- [ ] **UC-M05.06-C020-T01 · Evidence inventory:** List the “Accepted-work census” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C020-T02 · Artifact references:** Record the exact “Accepted-work census” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C020-T03 · Fixture references:** Attach the “Accepted-work census” fixture IDs, input identities and oracle definition; preserve the source counterexample “An in-flight request is omitted from the drain inventory” as a distinct evidence case.
- [ ] **UC-M05.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Accepted-work census”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C020-T05 · Environment record:** Record the actual “Accepted-work census” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C020-T06 · Expected versus observed:** Pair every “Accepted-work census” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C020-T07 · Failure and limit records:** Attach “Accepted-work census” change/failure and bounds evidence where required; include uncovered “Active requests and census duration” and unresolved violations of “Drain decisions account for already accepted work”.
- [ ] **UC-M05.06-C020-T08 · Evidence hygiene:** Check the “Accepted-work census” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C020-T09 · Reproduction review:** Have the “Accepted-work census” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C020-T10 · Acceptance linkage:** Link the “Accepted-work census” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Drain state transition

**Source delivery:** Enter draining through a durable generation-aware lifecycle transition.

**Source invariant:** Drain cannot be applied accidentally to a replacement generation.

**Source negative case:** A delayed drain request targets a newer instance with the same name.

**Source bounded quantities:** Transition contention and metadata bytes.

### UC-M05.06-C021 · Contract

**Original checklist item:** Specify drain state transition inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C021-T01 · Scope statement:** Draft the operation boundary for “Drain state transition” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Drain state transition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C021-T03 · Output inventory:** List the outputs of “Drain state transition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Drain state transition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C021-T05 · Prerequisite contract:** Map “Drain state transition” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Drain state transition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C021-T07 · Invariant clause:** Add a normative clause for “Drain state transition” that preserves “Drain cannot be applied accidentally to a replacement generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Drain state transition”; include the source counterexample “A delayed drain request targets a newer instance with the same name” and the intended safe disposition.
- [ ] **UC-M05.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Transition contention and metadata bytes” in the “Drain state transition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C021-T10 · Contract review:** Review the “Drain state transition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C022 · Delivery

**Original checklist item:** Enter draining through a durable generation-aware lifecycle transition.

- [ ] **UC-M05.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Drain state transition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C022-T02 · Change plan:** Break the source delivery for “Drain state transition” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Drain state transition” that realizes this source instruction: Enter draining through a durable generation-aware lifecycle transition.
- [ ] **UC-M05.06-C022-T04 · Concrete realization:** Trace “Drain state transition” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Drain state transition” needed to preserve “Drain cannot be applied accidentally to a replacement generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C022-T06 · Dependency connection:** Connect the “Drain state transition” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C022-T07 · Resource behavior:** Account for “Transition contention and metadata bytes” in “Drain state transition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C022-T08 · Delivery check:** Run the smallest real “Drain state transition” path and its adverse fixture “A delayed drain request targets a newer instance with the same name”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C022-T09 · Patch review:** Review the “Drain state transition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C022-T10 · Delivery handoff:** Publish the “Drain state transition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Drain cannot be applied accidentally to a replacement generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Drain state transition”; copy its required invariant exactly: “Drain cannot be applied accidentally to a replacement generation”.
- [ ] **UC-M05.06-C023-T02 · Observable terms:** Define each term in the “Drain state transition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C023-T03 · Precondition set:** List the preconditions under which “Drain cannot be applied accidentally to a replacement generation” must hold for “Drain state transition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C023-T04 · Transition coverage:** Map the “Drain state transition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Drain state transition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C023-T06 · Satisfying fixture:** Create a concrete “Drain state transition” case that satisfies “Drain cannot be applied accidentally to a replacement generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C023-T07 · Violating fixture:** Create the source counterexample “A delayed drain request targets a newer instance with the same name” for “Drain state transition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C023-T08 · Enforcement evidence:** Exercise the “Drain state transition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C023-T09 · Regression linkage:** Link the “Drain state transition” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Drain state transition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C024 · Integration

**Original checklist item:** Integrate drain state transition with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Drain state transition” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C024-T02 · Field mapping:** Map every “Drain state transition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Drain state transition” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C024-T04 · Ownership agreement:** Specify who owns “Drain state transition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C024-T05 · Handoff implementation:** Connect “Drain state transition” through the mapped seam using the real adapter or explicit specification reference; preserve “Drain cannot be applied accidentally to a replacement generation” across the handoff.
- [ ] **UC-M05.06-C024-T06 · Absent-input case:** Omit one required “Drain state transition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C024-T07 · Stale-input case:** Supply an outdated “Drain state transition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Drain state transition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C024-T09 · Valid integration trace:** Run a valid “Drain state transition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C024-T10 · Seam review:** Reconcile the “Drain state transition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for drain state transition; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Drain state transition” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C025-T02 · Expected-result oracle:** Specify the “Drain state transition” expected result independently of the implementation output; include the property “Drain cannot be applied accidentally to a replacement generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C025-T03 · Fixture material:** Create the concrete “Drain state transition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C025-T04 · Target preparation:** Prepare the “Drain state transition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C025-T05 · Initial-state record:** Record the initial “Drain state transition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C025-T06 · Valid-path execution:** Execute the “Drain state transition” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C025-T07 · Outcome comparison:** Compare every declared “Drain state transition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C025-T08 · State and bounds check:** Inspect the “Drain state transition” ownership/state effects and actual use of “Transition contention and metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C025-T09 · Repeatability check:** Repeat the same “Drain state transition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C025-T10 · Positive evidence:** Attach the “Drain state transition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C026 · Negative test

**Original checklist item:** Negative case: A delayed drain request targets a newer instance with the same name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Drain state transition” source counterexample: “A delayed drain request targets a newer instance with the same name”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Drain state transition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C026-T03 · Valid control:** Construct a valid “Drain state transition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C026-T04 · Minimal adverse input:** Derive the “Drain state transition” adverse fixture from the control with the smallest documented change needed to reproduce “A delayed drain request targets a newer instance with the same name”; retain that change as reproducible data.
- [ ] **UC-M05.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Drain state transition”; require “Drain cannot be applied accidentally to a replacement generation” and forbid a false-success verdict.
- [ ] **UC-M05.06-C026-T06 · Adverse execution:** Exercise the “Drain state transition” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C026-T07 · Effect inspection:** Inspect “Drain state transition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C026-T08 · Refusal versus failure:** Confirm the “Drain state transition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C026-T09 · Reset and retention:** Restore only the disposable “Drain state transition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C026-T10 · Negative regression:** Register the “Drain state transition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C027 · Change / failure test

**Original checklist item:** Exercise drain state transition when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C027-T01 · Scenario record:** Write the “Drain state transition” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “Drain cannot be applied accidentally to a replacement generation”.
- [ ] **UC-M05.06-C027-T02 · Baseline capture:** Create a known-valid “Drain state transition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C027-T03 · Injection map:** Locate the “Drain state transition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Drain state transition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C027-T05 · Controlled trigger:** Introduce the controlled “Drain state transition” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C027-T06 · Intermediate inspection:** Inspect the “Drain state transition” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Drain state transition”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Drain state transition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C027-T09 · Repeat and compare:** Repeat the selected “Drain state transition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C027-T10 · Failure evidence:** Publish the “Drain state transition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for transition contention and metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Drain state transition”: “Transition contention and metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C028-T02 · Measurement method:** Choose how to observe each “Drain state transition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Drain state transition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Drain state transition” cases for “Transition contention and metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Drain state transition” limit; preserve “Drain cannot be applied accidentally to a replacement generation”.
- [ ] **UC-M05.06-C028-T06 · Normal measurement:** Run or review the normal “Drain state transition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C028-T07 · At-limit measurement:** Exercise the “Drain state transition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C028-T08 · Over-limit measurement:** Exercise the “Drain state transition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C028-T09 · Uncovered-scope report:** List the “Drain state transition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C028-T10 · Limit evidence:** Publish the selected “Drain state transition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for drain state transition with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C029-T01 · Event inventory:** List the “Drain state transition” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Drain state transition” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C029-T03 · Failure mapping:** Map each documented “Drain state transition” refusal or error to a diagnostic outcome; include “A delayed drain request targets a newer instance with the same name” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C029-T04 · Emission path:** Add the “Drain state transition” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C029-T05 · Redaction check:** Test “Drain state transition” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C029-T06 · Output budget:** Set and exercise bounded “Drain state transition” message size, rate and retention compatible with “Transition contention and metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C029-T07 · Success/refusal fixtures:** Capture “Drain state transition” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Drain state transition” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C029-T09 · Operator review:** Read the “Drain state transition” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C029-T10 · Diagnostic evidence:** Publish redacted “Drain state transition” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for drain state transition; label unexecuted checks as untested.

- [ ] **UC-M05.06-C030-T01 · Evidence inventory:** List the “Drain state transition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C030-T02 · Artifact references:** Record the exact “Drain state transition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C030-T03 · Fixture references:** Attach the “Drain state transition” fixture IDs, input identities and oracle definition; preserve the source counterexample “A delayed drain request targets a newer instance with the same name” as a distinct evidence case.
- [ ] **UC-M05.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Drain state transition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C030-T05 · Environment record:** Record the actual “Drain state transition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C030-T06 · Expected versus observed:** Pair every “Drain state transition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C030-T07 · Failure and limit records:** Attach “Drain state transition” change/failure and bounds evidence where required; include uncovered “Transition contention and metadata bytes” and unresolved violations of “Drain cannot be applied accidentally to a replacement generation”.
- [ ] **UC-M05.06-C030-T08 · Evidence hygiene:** Check the “Drain state transition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C030-T09 · Reproduction review:** Have the “Drain state transition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C030-T10 · Acceptance linkage:** Link the “Drain state transition” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Cooperative stop signal

**Source delivery:** Send the selected guest stop or drain signal through its declared interface.

**Source invariant:** The signal's meaning is explicit and bounded.

**Source negative case:** A guest interprets drain as immediate destructive reset.

**Source bounded quantities:** Signal bytes and acknowledgment deadline.

### UC-M05.06-C031 · Contract

**Original checklist item:** Specify cooperative stop signal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C031-T01 · Scope statement:** Draft the operation boundary for “Cooperative stop signal” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cooperative stop signal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C031-T03 · Output inventory:** List the outputs of “Cooperative stop signal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Cooperative stop signal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C031-T05 · Prerequisite contract:** Map “Cooperative stop signal” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Cooperative stop signal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C031-T07 · Invariant clause:** Add a normative clause for “Cooperative stop signal” that preserves “The signal's meaning is explicit and bounded”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cooperative stop signal”; include the source counterexample “A guest interprets drain as immediate destructive reset” and the intended safe disposition.
- [ ] **UC-M05.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Signal bytes and acknowledgment deadline” in the “Cooperative stop signal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C031-T10 · Contract review:** Review the “Cooperative stop signal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C032 · Delivery

**Original checklist item:** Send the selected guest stop or drain signal through its declared interface.

- [ ] **UC-M05.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cooperative stop signal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C032-T02 · Change plan:** Break the source delivery for “Cooperative stop signal” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Cooperative stop signal” that realizes this source instruction: Send the selected guest stop or drain signal through its declared interface.
- [ ] **UC-M05.06-C032-T04 · Concrete realization:** Trace “Cooperative stop signal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cooperative stop signal” needed to preserve “The signal's meaning is explicit and bounded”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C032-T06 · Dependency connection:** Connect the “Cooperative stop signal” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C032-T07 · Resource behavior:** Account for “Signal bytes and acknowledgment deadline” in “Cooperative stop signal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C032-T08 · Delivery check:** Run the smallest real “Cooperative stop signal” path and its adverse fixture “A guest interprets drain as immediate destructive reset”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C032-T09 · Patch review:** Review the “Cooperative stop signal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C032-T10 · Delivery handoff:** Publish the “Cooperative stop signal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The signal's meaning is explicit and bounded. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Cooperative stop signal”; copy its required invariant exactly: “The signal's meaning is explicit and bounded”.
- [ ] **UC-M05.06-C033-T02 · Observable terms:** Define each term in the “Cooperative stop signal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C033-T03 · Precondition set:** List the preconditions under which “The signal's meaning is explicit and bounded” must hold for “Cooperative stop signal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C033-T04 · Transition coverage:** Map the “Cooperative stop signal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cooperative stop signal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C033-T06 · Satisfying fixture:** Create a concrete “Cooperative stop signal” case that satisfies “The signal's meaning is explicit and bounded”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C033-T07 · Violating fixture:** Create the source counterexample “A guest interprets drain as immediate destructive reset” for “Cooperative stop signal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C033-T08 · Enforcement evidence:** Exercise the “Cooperative stop signal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C033-T09 · Regression linkage:** Link the “Cooperative stop signal” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Cooperative stop signal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C034 · Integration

**Original checklist item:** Integrate cooperative stop signal with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cooperative stop signal” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C034-T02 · Field mapping:** Map every “Cooperative stop signal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Cooperative stop signal” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C034-T04 · Ownership agreement:** Specify who owns “Cooperative stop signal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C034-T05 · Handoff implementation:** Connect “Cooperative stop signal” through the mapped seam using the real adapter or explicit specification reference; preserve “The signal's meaning is explicit and bounded” across the handoff.
- [ ] **UC-M05.06-C034-T06 · Absent-input case:** Omit one required “Cooperative stop signal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C034-T07 · Stale-input case:** Supply an outdated “Cooperative stop signal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Cooperative stop signal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C034-T09 · Valid integration trace:** Run a valid “Cooperative stop signal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C034-T10 · Seam review:** Reconcile the “Cooperative stop signal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cooperative stop signal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cooperative stop signal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C035-T02 · Expected-result oracle:** Specify the “Cooperative stop signal” expected result independently of the implementation output; include the property “The signal's meaning is explicit and bounded” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C035-T03 · Fixture material:** Create the concrete “Cooperative stop signal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C035-T04 · Target preparation:** Prepare the “Cooperative stop signal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C035-T05 · Initial-state record:** Record the initial “Cooperative stop signal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C035-T06 · Valid-path execution:** Execute the “Cooperative stop signal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C035-T07 · Outcome comparison:** Compare every declared “Cooperative stop signal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C035-T08 · State and bounds check:** Inspect the “Cooperative stop signal” ownership/state effects and actual use of “Signal bytes and acknowledgment deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C035-T09 · Repeatability check:** Repeat the same “Cooperative stop signal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C035-T10 · Positive evidence:** Attach the “Cooperative stop signal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C036 · Negative test

**Original checklist item:** Negative case: A guest interprets drain as immediate destructive reset. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Cooperative stop signal” source counterexample: “A guest interprets drain as immediate destructive reset”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Cooperative stop signal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C036-T03 · Valid control:** Construct a valid “Cooperative stop signal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C036-T04 · Minimal adverse input:** Derive the “Cooperative stop signal” adverse fixture from the control with the smallest documented change needed to reproduce “A guest interprets drain as immediate destructive reset”; retain that change as reproducible data.
- [ ] **UC-M05.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cooperative stop signal”; require “The signal's meaning is explicit and bounded” and forbid a false-success verdict.
- [ ] **UC-M05.06-C036-T06 · Adverse execution:** Exercise the “Cooperative stop signal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C036-T07 · Effect inspection:** Inspect “Cooperative stop signal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C036-T08 · Refusal versus failure:** Confirm the “Cooperative stop signal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C036-T09 · Reset and retention:** Restore only the disposable “Cooperative stop signal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C036-T10 · Negative regression:** Register the “Cooperative stop signal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C037 · Change / failure test

**Original checklist item:** Exercise cooperative stop signal when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C037-T01 · Scenario record:** Write the “Cooperative stop signal” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “The signal's meaning is explicit and bounded”.
- [ ] **UC-M05.06-C037-T02 · Baseline capture:** Create a known-valid “Cooperative stop signal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C037-T03 · Injection map:** Locate the “Cooperative stop signal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Cooperative stop signal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C037-T05 · Controlled trigger:** Introduce the controlled “Cooperative stop signal” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C037-T06 · Intermediate inspection:** Inspect the “Cooperative stop signal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cooperative stop signal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Cooperative stop signal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C037-T09 · Repeat and compare:** Repeat the selected “Cooperative stop signal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C037-T10 · Failure evidence:** Publish the “Cooperative stop signal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for signal bytes and acknowledgment deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Cooperative stop signal”: “Signal bytes and acknowledgment deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C038-T02 · Measurement method:** Choose how to observe each “Cooperative stop signal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Cooperative stop signal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cooperative stop signal” cases for “Signal bytes and acknowledgment deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cooperative stop signal” limit; preserve “The signal's meaning is explicit and bounded”.
- [ ] **UC-M05.06-C038-T06 · Normal measurement:** Run or review the normal “Cooperative stop signal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C038-T07 · At-limit measurement:** Exercise the “Cooperative stop signal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C038-T08 · Over-limit measurement:** Exercise the “Cooperative stop signal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C038-T09 · Uncovered-scope report:** List the “Cooperative stop signal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C038-T10 · Limit evidence:** Publish the selected “Cooperative stop signal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cooperative stop signal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C039-T01 · Event inventory:** List the “Cooperative stop signal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Cooperative stop signal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C039-T03 · Failure mapping:** Map each documented “Cooperative stop signal” refusal or error to a diagnostic outcome; include “A guest interprets drain as immediate destructive reset” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C039-T04 · Emission path:** Add the “Cooperative stop signal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C039-T05 · Redaction check:** Test “Cooperative stop signal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C039-T06 · Output budget:** Set and exercise bounded “Cooperative stop signal” message size, rate and retention compatible with “Signal bytes and acknowledgment deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C039-T07 · Success/refusal fixtures:** Capture “Cooperative stop signal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cooperative stop signal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C039-T09 · Operator review:** Read the “Cooperative stop signal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C039-T10 · Diagnostic evidence:** Publish redacted “Cooperative stop signal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cooperative stop signal; label unexecuted checks as untested.

- [ ] **UC-M05.06-C040-T01 · Evidence inventory:** List the “Cooperative stop signal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C040-T02 · Artifact references:** Record the exact “Cooperative stop signal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C040-T03 · Fixture references:** Attach the “Cooperative stop signal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest interprets drain as immediate destructive reset” as a distinct evidence case.
- [ ] **UC-M05.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cooperative stop signal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C040-T05 · Environment record:** Record the actual “Cooperative stop signal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C040-T06 · Expected versus observed:** Pair every “Cooperative stop signal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C040-T07 · Failure and limit records:** Attach “Cooperative stop signal” change/failure and bounds evidence where required; include uncovered “Signal bytes and acknowledgment deadline” and unresolved violations of “The signal's meaning is explicit and bounded”.
- [ ] **UC-M05.06-C040-T08 · Evidence hygiene:** Check the “Cooperative stop signal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C040-T09 · Reproduction review:** Have the “Cooperative stop signal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C040-T10 · Acceptance linkage:** Link the “Cooperative stop signal” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. State flush contract

**Source delivery:** Flush or checkpoint pending state using declared commit semantics.

**Source invariant:** A successful stop does not conceal uncommitted accepted state.

**Source negative case:** The guest exits before pending state is durably committed.

**Source bounded quantities:** Flush bytes and flush deadline.

### UC-M05.06-C041 · Contract

**Original checklist item:** Specify state flush contract inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C041-T01 · Scope statement:** Draft the operation boundary for “State flush contract” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State flush contract”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C041-T03 · Output inventory:** List the outputs of “State flush contract” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “State flush contract”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C041-T05 · Prerequisite contract:** Map “State flush contract” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C041-T06 · Authority map:** Identify who may produce, change and consume “State flush contract”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C041-T07 · Invariant clause:** Add a normative clause for “State flush contract” that preserves “A successful stop does not conceal uncommitted accepted state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State flush contract”; include the source counterexample “The guest exits before pending state is durably committed” and the intended safe disposition.
- [ ] **UC-M05.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Flush bytes and flush deadline” in the “State flush contract” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C041-T10 · Contract review:** Review the “State flush contract” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C042 · Delivery

**Original checklist item:** Flush or checkpoint pending state using declared commit semantics.

- [ ] **UC-M05.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State flush contract”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C042-T02 · Change plan:** Break the source delivery for “State flush contract” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “State flush contract” that realizes this source instruction: Flush or checkpoint pending state using declared commit semantics.
- [ ] **UC-M05.06-C042-T04 · Concrete realization:** Trace “State flush contract” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State flush contract” needed to preserve “A successful stop does not conceal uncommitted accepted state”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C042-T06 · Dependency connection:** Connect the “State flush contract” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C042-T07 · Resource behavior:** Account for “Flush bytes and flush deadline” in “State flush contract”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C042-T08 · Delivery check:** Run the smallest real “State flush contract” path and its adverse fixture “The guest exits before pending state is durably committed”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C042-T09 · Patch review:** Review the “State flush contract” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C042-T10 · Delivery handoff:** Publish the “State flush contract” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A successful stop does not conceal uncommitted accepted state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “State flush contract”; copy its required invariant exactly: “A successful stop does not conceal uncommitted accepted state”.
- [ ] **UC-M05.06-C043-T02 · Observable terms:** Define each term in the “State flush contract” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C043-T03 · Precondition set:** List the preconditions under which “A successful stop does not conceal uncommitted accepted state” must hold for “State flush contract”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C043-T04 · Transition coverage:** Map the “State flush contract” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State flush contract”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C043-T06 · Satisfying fixture:** Create a concrete “State flush contract” case that satisfies “A successful stop does not conceal uncommitted accepted state”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C043-T07 · Violating fixture:** Create the source counterexample “The guest exits before pending state is durably committed” for “State flush contract”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C043-T08 · Enforcement evidence:** Exercise the “State flush contract” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C043-T09 · Regression linkage:** Link the “State flush contract” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C043-T10 · Property disposition:** Compare the satisfying and violating “State flush contract” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C044 · Integration

**Original checklist item:** Integrate state flush contract with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State flush contract” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C044-T02 · Field mapping:** Map every “State flush contract” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “State flush contract” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C044-T04 · Ownership agreement:** Specify who owns “State flush contract” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C044-T05 · Handoff implementation:** Connect “State flush contract” through the mapped seam using the real adapter or explicit specification reference; preserve “A successful stop does not conceal uncommitted accepted state” across the handoff.
- [ ] **UC-M05.06-C044-T06 · Absent-input case:** Omit one required “State flush contract” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C044-T07 · Stale-input case:** Supply an outdated “State flush contract” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C044-T08 · Incompatible-input case:** Supply an incompatible “State flush contract” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C044-T09 · Valid integration trace:** Run a valid “State flush contract” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C044-T10 · Seam review:** Reconcile the “State flush contract” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for state flush contract; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “State flush contract” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C045-T02 · Expected-result oracle:** Specify the “State flush contract” expected result independently of the implementation output; include the property “A successful stop does not conceal uncommitted accepted state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C045-T03 · Fixture material:** Create the concrete “State flush contract” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C045-T04 · Target preparation:** Prepare the “State flush contract” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C045-T05 · Initial-state record:** Record the initial “State flush contract” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C045-T06 · Valid-path execution:** Execute the “State flush contract” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C045-T07 · Outcome comparison:** Compare every declared “State flush contract” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C045-T08 · State and bounds check:** Inspect the “State flush contract” ownership/state effects and actual use of “Flush bytes and flush deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C045-T09 · Repeatability check:** Repeat the same “State flush contract” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C045-T10 · Positive evidence:** Attach the “State flush contract” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C046 · Negative test

**Original checklist item:** Negative case: The guest exits before pending state is durably committed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “State flush contract” source counterexample: “The guest exits before pending state is durably committed”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “State flush contract”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C046-T03 · Valid control:** Construct a valid “State flush contract” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C046-T04 · Minimal adverse input:** Derive the “State flush contract” adverse fixture from the control with the smallest documented change needed to reproduce “The guest exits before pending state is durably committed”; retain that change as reproducible data.
- [ ] **UC-M05.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State flush contract”; require “A successful stop does not conceal uncommitted accepted state” and forbid a false-success verdict.
- [ ] **UC-M05.06-C046-T06 · Adverse execution:** Exercise the “State flush contract” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C046-T07 · Effect inspection:** Inspect “State flush contract” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C046-T08 · Refusal versus failure:** Confirm the “State flush contract” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C046-T09 · Reset and retention:** Restore only the disposable “State flush contract” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C046-T10 · Negative regression:** Register the “State flush contract” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C047 · Change / failure test

**Original checklist item:** Exercise state flush contract when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C047-T01 · Scenario record:** Write the “State flush contract” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “A successful stop does not conceal uncommitted accepted state”.
- [ ] **UC-M05.06-C047-T02 · Baseline capture:** Create a known-valid “State flush contract” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C047-T03 · Injection map:** Locate the “State flush contract” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “State flush contract” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C047-T05 · Controlled trigger:** Introduce the controlled “State flush contract” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C047-T06 · Intermediate inspection:** Inspect the “State flush contract” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “State flush contract”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “State flush contract” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C047-T09 · Repeat and compare:** Repeat the selected “State flush contract” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C047-T10 · Failure evidence:** Publish the “State flush contract” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for flush bytes and flush deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “State flush contract”: “Flush bytes and flush deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C048-T02 · Measurement method:** Choose how to observe each “State flush contract” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C048-T03 · Budget decision:** Select justified resource and input limits for “State flush contract”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State flush contract” cases for “Flush bytes and flush deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State flush contract” limit; preserve “A successful stop does not conceal uncommitted accepted state”.
- [ ] **UC-M05.06-C048-T06 · Normal measurement:** Run or review the normal “State flush contract” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C048-T07 · At-limit measurement:** Exercise the “State flush contract” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C048-T08 · Over-limit measurement:** Exercise the “State flush contract” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C048-T09 · Uncovered-scope report:** List the “State flush contract” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C048-T10 · Limit evidence:** Publish the selected “State flush contract” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for state flush contract with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C049-T01 · Event inventory:** List the “State flush contract” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “State flush contract” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C049-T03 · Failure mapping:** Map each documented “State flush contract” refusal or error to a diagnostic outcome; include “The guest exits before pending state is durably committed” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C049-T04 · Emission path:** Add the “State flush contract” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C049-T05 · Redaction check:** Test “State flush contract” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C049-T06 · Output budget:** Set and exercise bounded “State flush contract” message size, rate and retention compatible with “Flush bytes and flush deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C049-T07 · Success/refusal fixtures:** Capture “State flush contract” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “State flush contract” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C049-T09 · Operator review:** Read the “State flush contract” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C049-T10 · Diagnostic evidence:** Publish redacted “State flush contract” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state flush contract; label unexecuted checks as untested.

- [ ] **UC-M05.06-C050-T01 · Evidence inventory:** List the “State flush contract” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C050-T02 · Artifact references:** Record the exact “State flush contract” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C050-T03 · Fixture references:** Attach the “State flush contract” fixture IDs, input identities and oracle definition; preserve the source counterexample “The guest exits before pending state is durably committed” as a distinct evidence case.
- [ ] **UC-M05.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State flush contract”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C050-T05 · Environment record:** Record the actual “State flush contract” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C050-T06 · Expected versus observed:** Pair every “State flush contract” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C050-T07 · Failure and limit records:** Attach “State flush contract” change/failure and bounds evidence where required; include uncovered “Flush bytes and flush deadline” and unresolved violations of “A successful stop does not conceal uncommitted accepted state”.
- [ ] **UC-M05.06-C050-T08 · Evidence hygiene:** Check the “State flush contract” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C050-T09 · Reproduction review:** Have the “State flush contract” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C050-T10 · Acceptance linkage:** Link the “State flush contract” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Drain deadline

**Source delivery:** Apply a maximum drain period and a defined timeout disposition.

**Source invariant:** An uncooperative workload cannot drain indefinitely.

**Source negative case:** A guest continuously reports almost finished without completing.

**Source bounded quantities:** Drain duration and extension count.

### UC-M05.06-C051 · Contract

**Original checklist item:** Specify drain deadline inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C051-T01 · Scope statement:** Draft the operation boundary for “Drain deadline” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Drain deadline”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C051-T03 · Output inventory:** List the outputs of “Drain deadline” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Drain deadline”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C051-T05 · Prerequisite contract:** Map “Drain deadline” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Drain deadline”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C051-T07 · Invariant clause:** Add a normative clause for “Drain deadline” that preserves “An uncooperative workload cannot drain indefinitely”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Drain deadline”; include the source counterexample “A guest continuously reports almost finished without completing” and the intended safe disposition.
- [ ] **UC-M05.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Drain duration and extension count” in the “Drain deadline” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C051-T10 · Contract review:** Review the “Drain deadline” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C052 · Delivery

**Original checklist item:** Apply a maximum drain period and a defined timeout disposition.

- [ ] **UC-M05.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Drain deadline”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C052-T02 · Change plan:** Break the source delivery for “Drain deadline” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Drain deadline” that realizes this source instruction: Apply a maximum drain period and a defined timeout disposition.
- [ ] **UC-M05.06-C052-T04 · Concrete realization:** Trace “Drain deadline” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Drain deadline” needed to preserve “An uncooperative workload cannot drain indefinitely”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C052-T06 · Dependency connection:** Connect the “Drain deadline” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C052-T07 · Resource behavior:** Account for “Drain duration and extension count” in “Drain deadline”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C052-T08 · Delivery check:** Run the smallest real “Drain deadline” path and its adverse fixture “A guest continuously reports almost finished without completing”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C052-T09 · Patch review:** Review the “Drain deadline” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C052-T10 · Delivery handoff:** Publish the “Drain deadline” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An uncooperative workload cannot drain indefinitely. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Drain deadline”; copy its required invariant exactly: “An uncooperative workload cannot drain indefinitely”.
- [ ] **UC-M05.06-C053-T02 · Observable terms:** Define each term in the “Drain deadline” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C053-T03 · Precondition set:** List the preconditions under which “An uncooperative workload cannot drain indefinitely” must hold for “Drain deadline”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C053-T04 · Transition coverage:** Map the “Drain deadline” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Drain deadline”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C053-T06 · Satisfying fixture:** Create a concrete “Drain deadline” case that satisfies “An uncooperative workload cannot drain indefinitely”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C053-T07 · Violating fixture:** Create the source counterexample “A guest continuously reports almost finished without completing” for “Drain deadline”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C053-T08 · Enforcement evidence:** Exercise the “Drain deadline” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C053-T09 · Regression linkage:** Link the “Drain deadline” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Drain deadline” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C054 · Integration

**Original checklist item:** Integrate drain deadline with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Drain deadline” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C054-T02 · Field mapping:** Map every “Drain deadline” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Drain deadline” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C054-T04 · Ownership agreement:** Specify who owns “Drain deadline” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C054-T05 · Handoff implementation:** Connect “Drain deadline” through the mapped seam using the real adapter or explicit specification reference; preserve “An uncooperative workload cannot drain indefinitely” across the handoff.
- [ ] **UC-M05.06-C054-T06 · Absent-input case:** Omit one required “Drain deadline” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C054-T07 · Stale-input case:** Supply an outdated “Drain deadline” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Drain deadline” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C054-T09 · Valid integration trace:** Run a valid “Drain deadline” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C054-T10 · Seam review:** Reconcile the “Drain deadline” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for drain deadline; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Drain deadline” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C055-T02 · Expected-result oracle:** Specify the “Drain deadline” expected result independently of the implementation output; include the property “An uncooperative workload cannot drain indefinitely” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C055-T03 · Fixture material:** Create the concrete “Drain deadline” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C055-T04 · Target preparation:** Prepare the “Drain deadline” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C055-T05 · Initial-state record:** Record the initial “Drain deadline” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C055-T06 · Valid-path execution:** Execute the “Drain deadline” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C055-T07 · Outcome comparison:** Compare every declared “Drain deadline” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C055-T08 · State and bounds check:** Inspect the “Drain deadline” ownership/state effects and actual use of “Drain duration and extension count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C055-T09 · Repeatability check:** Repeat the same “Drain deadline” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C055-T10 · Positive evidence:** Attach the “Drain deadline” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C056 · Negative test

**Original checklist item:** Negative case: A guest continuously reports almost finished without completing. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Drain deadline” source counterexample: “A guest continuously reports almost finished without completing”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Drain deadline”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C056-T03 · Valid control:** Construct a valid “Drain deadline” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C056-T04 · Minimal adverse input:** Derive the “Drain deadline” adverse fixture from the control with the smallest documented change needed to reproduce “A guest continuously reports almost finished without completing”; retain that change as reproducible data.
- [ ] **UC-M05.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Drain deadline”; require “An uncooperative workload cannot drain indefinitely” and forbid a false-success verdict.
- [ ] **UC-M05.06-C056-T06 · Adverse execution:** Exercise the “Drain deadline” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C056-T07 · Effect inspection:** Inspect “Drain deadline” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C056-T08 · Refusal versus failure:** Confirm the “Drain deadline” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C056-T09 · Reset and retention:** Restore only the disposable “Drain deadline” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C056-T10 · Negative regression:** Register the “Drain deadline” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C057 · Change / failure test

**Original checklist item:** Exercise drain deadline when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C057-T01 · Scenario record:** Write the “Drain deadline” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “An uncooperative workload cannot drain indefinitely”.
- [ ] **UC-M05.06-C057-T02 · Baseline capture:** Create a known-valid “Drain deadline” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C057-T03 · Injection map:** Locate the “Drain deadline” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Drain deadline” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C057-T05 · Controlled trigger:** Introduce the controlled “Drain deadline” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C057-T06 · Intermediate inspection:** Inspect the “Drain deadline” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Drain deadline”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Drain deadline” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C057-T09 · Repeat and compare:** Repeat the selected “Drain deadline” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C057-T10 · Failure evidence:** Publish the “Drain deadline” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for drain duration and extension count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Drain deadline”: “Drain duration and extension count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C058-T02 · Measurement method:** Choose how to observe each “Drain deadline” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C058-T03 · Budget decision:** Select justified resource and input limits for “Drain deadline”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Drain deadline” cases for “Drain duration and extension count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Drain deadline” limit; preserve “An uncooperative workload cannot drain indefinitely”.
- [ ] **UC-M05.06-C058-T06 · Normal measurement:** Run or review the normal “Drain deadline” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C058-T07 · At-limit measurement:** Exercise the “Drain deadline” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C058-T08 · Over-limit measurement:** Exercise the “Drain deadline” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C058-T09 · Uncovered-scope report:** List the “Drain deadline” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C058-T10 · Limit evidence:** Publish the selected “Drain deadline” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for drain deadline with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C059-T01 · Event inventory:** List the “Drain deadline” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Drain deadline” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C059-T03 · Failure mapping:** Map each documented “Drain deadline” refusal or error to a diagnostic outcome; include “A guest continuously reports almost finished without completing” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C059-T04 · Emission path:** Add the “Drain deadline” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C059-T05 · Redaction check:** Test “Drain deadline” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C059-T06 · Output budget:** Set and exercise bounded “Drain deadline” message size, rate and retention compatible with “Drain duration and extension count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C059-T07 · Success/refusal fixtures:** Capture “Drain deadline” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Drain deadline” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C059-T09 · Operator review:** Read the “Drain deadline” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C059-T10 · Diagnostic evidence:** Publish redacted “Drain deadline” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for drain deadline; label unexecuted checks as untested.

- [ ] **UC-M05.06-C060-T01 · Evidence inventory:** List the “Drain deadline” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C060-T02 · Artifact references:** Record the exact “Drain deadline” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C060-T03 · Fixture references:** Attach the “Drain deadline” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest continuously reports almost finished without completing” as a distinct evidence case.
- [ ] **UC-M05.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Drain deadline”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C060-T05 · Environment record:** Record the actual “Drain deadline” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C060-T06 · Expected versus observed:** Pair every “Drain deadline” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C060-T07 · Failure and limit records:** Attach “Drain deadline” change/failure and bounds evidence where required; include uncovered “Drain duration and extension count” and unresolved violations of “An uncooperative workload cannot drain indefinitely”.
- [ ] **UC-M05.06-C060-T08 · Evidence hygiene:** Check the “Drain deadline” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C060-T09 · Reproduction review:** Have the “Drain deadline” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C060-T10 · Acceptance linkage:** Link the “Drain deadline” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Forced termination

**Source delivery:** Escalate to host-enforced termination after the allowed drain bound.

**Source invariant:** Forced stop records interruption rather than fabricated completion.

**Source negative case:** Active I/O is killed but the invocation is marked successful.

**Source bounded quantities:** Termination deadline and descendant count.

### UC-M05.06-C061 · Contract

**Original checklist item:** Specify forced termination inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C061-T01 · Scope statement:** Draft the operation boundary for “Forced termination” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Forced termination”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C061-T03 · Output inventory:** List the outputs of “Forced termination” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Forced termination”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C061-T05 · Prerequisite contract:** Map “Forced termination” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Forced termination”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C061-T07 · Invariant clause:** Add a normative clause for “Forced termination” that preserves “Forced stop records interruption rather than fabricated completion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Forced termination”; include the source counterexample “Active I/O is killed but the invocation is marked successful” and the intended safe disposition.
- [ ] **UC-M05.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Termination deadline and descendant count” in the “Forced termination” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C061-T10 · Contract review:** Review the “Forced termination” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C062 · Delivery

**Original checklist item:** Escalate to host-enforced termination after the allowed drain bound.

- [ ] **UC-M05.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Forced termination”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C062-T02 · Change plan:** Break the source delivery for “Forced termination” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Forced termination” that realizes this source instruction: Escalate to host-enforced termination after the allowed drain bound.
- [ ] **UC-M05.06-C062-T04 · Concrete realization:** Trace “Forced termination” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Forced termination” needed to preserve “Forced stop records interruption rather than fabricated completion”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C062-T06 · Dependency connection:** Connect the “Forced termination” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C062-T07 · Resource behavior:** Account for “Termination deadline and descendant count” in “Forced termination”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C062-T08 · Delivery check:** Run the smallest real “Forced termination” path and its adverse fixture “Active I/O is killed but the invocation is marked successful”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C062-T09 · Patch review:** Review the “Forced termination” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C062-T10 · Delivery handoff:** Publish the “Forced termination” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Forced stop records interruption rather than fabricated completion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Forced termination”; copy its required invariant exactly: “Forced stop records interruption rather than fabricated completion”.
- [ ] **UC-M05.06-C063-T02 · Observable terms:** Define each term in the “Forced termination” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C063-T03 · Precondition set:** List the preconditions under which “Forced stop records interruption rather than fabricated completion” must hold for “Forced termination”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C063-T04 · Transition coverage:** Map the “Forced termination” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Forced termination”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C063-T06 · Satisfying fixture:** Create a concrete “Forced termination” case that satisfies “Forced stop records interruption rather than fabricated completion”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C063-T07 · Violating fixture:** Create the source counterexample “Active I/O is killed but the invocation is marked successful” for “Forced termination”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C063-T08 · Enforcement evidence:** Exercise the “Forced termination” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C063-T09 · Regression linkage:** Link the “Forced termination” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Forced termination” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C064 · Integration

**Original checklist item:** Integrate forced termination with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Forced termination” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C064-T02 · Field mapping:** Map every “Forced termination” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Forced termination” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C064-T04 · Ownership agreement:** Specify who owns “Forced termination” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C064-T05 · Handoff implementation:** Connect “Forced termination” through the mapped seam using the real adapter or explicit specification reference; preserve “Forced stop records interruption rather than fabricated completion” across the handoff.
- [ ] **UC-M05.06-C064-T06 · Absent-input case:** Omit one required “Forced termination” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C064-T07 · Stale-input case:** Supply an outdated “Forced termination” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Forced termination” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C064-T09 · Valid integration trace:** Run a valid “Forced termination” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C064-T10 · Seam review:** Reconcile the “Forced termination” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for forced termination; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Forced termination” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C065-T02 · Expected-result oracle:** Specify the “Forced termination” expected result independently of the implementation output; include the property “Forced stop records interruption rather than fabricated completion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C065-T03 · Fixture material:** Create the concrete “Forced termination” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C065-T04 · Target preparation:** Prepare the “Forced termination” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C065-T05 · Initial-state record:** Record the initial “Forced termination” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C065-T06 · Valid-path execution:** Execute the “Forced termination” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C065-T07 · Outcome comparison:** Compare every declared “Forced termination” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C065-T08 · State and bounds check:** Inspect the “Forced termination” ownership/state effects and actual use of “Termination deadline and descendant count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C065-T09 · Repeatability check:** Repeat the same “Forced termination” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C065-T10 · Positive evidence:** Attach the “Forced termination” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C066 · Negative test

**Original checklist item:** Negative case: Active I/O is killed but the invocation is marked successful. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Forced termination” source counterexample: “Active I/O is killed but the invocation is marked successful”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Forced termination”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C066-T03 · Valid control:** Construct a valid “Forced termination” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C066-T04 · Minimal adverse input:** Derive the “Forced termination” adverse fixture from the control with the smallest documented change needed to reproduce “Active I/O is killed but the invocation is marked successful”; retain that change as reproducible data.
- [ ] **UC-M05.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Forced termination”; require “Forced stop records interruption rather than fabricated completion” and forbid a false-success verdict.
- [ ] **UC-M05.06-C066-T06 · Adverse execution:** Exercise the “Forced termination” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C066-T07 · Effect inspection:** Inspect “Forced termination” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C066-T08 · Refusal versus failure:** Confirm the “Forced termination” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C066-T09 · Reset and retention:** Restore only the disposable “Forced termination” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C066-T10 · Negative regression:** Register the “Forced termination” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C067 · Change / failure test

**Original checklist item:** Exercise forced termination when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C067-T01 · Scenario record:** Write the “Forced termination” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “Forced stop records interruption rather than fabricated completion”.
- [ ] **UC-M05.06-C067-T02 · Baseline capture:** Create a known-valid “Forced termination” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C067-T03 · Injection map:** Locate the “Forced termination” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Forced termination” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C067-T05 · Controlled trigger:** Introduce the controlled “Forced termination” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C067-T06 · Intermediate inspection:** Inspect the “Forced termination” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Forced termination”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Forced termination” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C067-T09 · Repeat and compare:** Repeat the selected “Forced termination” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C067-T10 · Failure evidence:** Publish the “Forced termination” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for termination deadline and descendant count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Forced termination”: “Termination deadline and descendant count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C068-T02 · Measurement method:** Choose how to observe each “Forced termination” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Forced termination”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Forced termination” cases for “Termination deadline and descendant count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Forced termination” limit; preserve “Forced stop records interruption rather than fabricated completion”.
- [ ] **UC-M05.06-C068-T06 · Normal measurement:** Run or review the normal “Forced termination” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C068-T07 · At-limit measurement:** Exercise the “Forced termination” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C068-T08 · Over-limit measurement:** Exercise the “Forced termination” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C068-T09 · Uncovered-scope report:** List the “Forced termination” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C068-T10 · Limit evidence:** Publish the selected “Forced termination” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for forced termination with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C069-T01 · Event inventory:** List the “Forced termination” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Forced termination” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C069-T03 · Failure mapping:** Map each documented “Forced termination” refusal or error to a diagnostic outcome; include “Active I/O is killed but the invocation is marked successful” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C069-T04 · Emission path:** Add the “Forced termination” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C069-T05 · Redaction check:** Test “Forced termination” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C069-T06 · Output budget:** Set and exercise bounded “Forced termination” message size, rate and retention compatible with “Termination deadline and descendant count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C069-T07 · Success/refusal fixtures:** Capture “Forced termination” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Forced termination” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C069-T09 · Operator review:** Read the “Forced termination” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C069-T10 · Diagnostic evidence:** Publish redacted “Forced termination” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for forced termination; label unexecuted checks as untested.

- [ ] **UC-M05.06-C070-T01 · Evidence inventory:** List the “Forced termination” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C070-T02 · Artifact references:** Record the exact “Forced termination” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C070-T03 · Fixture references:** Attach the “Forced termination” fixture IDs, input identities and oracle definition; preserve the source counterexample “Active I/O is killed but the invocation is marked successful” as a distinct evidence case.
- [ ] **UC-M05.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Forced termination”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C070-T05 · Environment record:** Record the actual “Forced termination” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C070-T06 · Expected versus observed:** Pair every “Forced termination” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C070-T07 · Failure and limit records:** Attach “Forced termination” change/failure and bounds evidence where required; include uncovered “Termination deadline and descendant count” and unresolved violations of “Forced stop records interruption rather than fabricated completion”.
- [ ] **UC-M05.06-C070-T08 · Evidence hygiene:** Check the “Forced termination” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C070-T09 · Reproduction review:** Have the “Forced termination” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C070-T10 · Acceptance linkage:** Link the “Forced termination” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. I/O disposition records

**Source delivery:** Record each pending operation as committed, canceled or interrupted.

**Source invariant:** Stop during I/O leaves no ambiguous successful outcome.

**Source negative case:** A partial write is reported as a complete accepted operation.

**Source bounded quantities:** Pending I/O count and record size.

### UC-M05.06-C071 · Contract

**Original checklist item:** Specify I/O disposition records inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C071-T01 · Scope statement:** Draft the operation boundary for “I/O disposition records” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “I/O disposition records”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C071-T03 · Output inventory:** List the outputs of “I/O disposition records” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “I/O disposition records”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C071-T05 · Prerequisite contract:** Map “I/O disposition records” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C071-T06 · Authority map:** Identify who may produce, change and consume “I/O disposition records”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C071-T07 · Invariant clause:** Add a normative clause for “I/O disposition records” that preserves “Stop during I/O leaves no ambiguous successful outcome”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “I/O disposition records”; include the source counterexample “A partial write is reported as a complete accepted operation” and the intended safe disposition.
- [ ] **UC-M05.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pending I/O count and record size” in the “I/O disposition records” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C071-T10 · Contract review:** Review the “I/O disposition records” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C072 · Delivery

**Original checklist item:** Record each pending operation as committed, canceled or interrupted.

- [ ] **UC-M05.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “I/O disposition records”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C072-T02 · Change plan:** Break the source delivery for “I/O disposition records” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C072-T03 · Core artifact:** Create the “I/O disposition records” model, schema or inventory that realizes this source instruction: Record each pending operation as committed, canceled or interrupted.
- [ ] **UC-M05.06-C072-T04 · Concrete realization:** Populate “I/O disposition records” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “I/O disposition records” needed to preserve “Stop during I/O leaves no ambiguous successful outcome”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C072-T06 · Dependency connection:** Connect the “I/O disposition records” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C072-T07 · Resource behavior:** Account for “Pending I/O count and record size” in “I/O disposition records”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C072-T08 · Delivery check:** Run the smallest real “I/O disposition records” path and its adverse fixture “A partial write is reported as a complete accepted operation”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C072-T09 · Patch review:** Review the “I/O disposition records” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C072-T10 · Delivery handoff:** Publish the “I/O disposition records” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stop during I/O leaves no ambiguous successful outcome. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “I/O disposition records”; copy its required invariant exactly: “Stop during I/O leaves no ambiguous successful outcome”.
- [ ] **UC-M05.06-C073-T02 · Observable terms:** Define each term in the “I/O disposition records” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C073-T03 · Precondition set:** List the preconditions under which “Stop during I/O leaves no ambiguous successful outcome” must hold for “I/O disposition records”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C073-T04 · Transition coverage:** Map the “I/O disposition records” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “I/O disposition records”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C073-T06 · Satisfying fixture:** Create a concrete “I/O disposition records” case that satisfies “Stop during I/O leaves no ambiguous successful outcome”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C073-T07 · Violating fixture:** Create the source counterexample “A partial write is reported as a complete accepted operation” for “I/O disposition records”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C073-T08 · Enforcement evidence:** Exercise the “I/O disposition records” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C073-T09 · Regression linkage:** Link the “I/O disposition records” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C073-T10 · Property disposition:** Compare the satisfying and violating “I/O disposition records” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C074 · Integration

**Original checklist item:** Integrate I/O disposition records with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “I/O disposition records” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C074-T02 · Field mapping:** Map every “I/O disposition records” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “I/O disposition records” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C074-T04 · Ownership agreement:** Specify who owns “I/O disposition records” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C074-T05 · Handoff implementation:** Connect “I/O disposition records” through the mapped seam using the real adapter or explicit specification reference; preserve “Stop during I/O leaves no ambiguous successful outcome” across the handoff.
- [ ] **UC-M05.06-C074-T06 · Absent-input case:** Omit one required “I/O disposition records” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C074-T07 · Stale-input case:** Supply an outdated “I/O disposition records” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C074-T08 · Incompatible-input case:** Supply an incompatible “I/O disposition records” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C074-T09 · Valid integration trace:** Run a valid “I/O disposition records” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C074-T10 · Seam review:** Reconcile the “I/O disposition records” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for I/O disposition records; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “I/O disposition records” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C075-T02 · Expected-result oracle:** Specify the “I/O disposition records” expected result independently of the implementation output; include the property “Stop during I/O leaves no ambiguous successful outcome” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C075-T03 · Fixture material:** Create the concrete “I/O disposition records” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C075-T04 · Target preparation:** Prepare the “I/O disposition records” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C075-T05 · Initial-state record:** Record the initial “I/O disposition records” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C075-T06 · Valid-path execution:** Execute the “I/O disposition records” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C075-T07 · Outcome comparison:** Compare every declared “I/O disposition records” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C075-T08 · State and bounds check:** Inspect the “I/O disposition records” ownership/state effects and actual use of “Pending I/O count and record size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C075-T09 · Repeatability check:** Repeat the same “I/O disposition records” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C075-T10 · Positive evidence:** Attach the “I/O disposition records” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C076 · Negative test

**Original checklist item:** Negative case: A partial write is reported as a complete accepted operation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “I/O disposition records” source counterexample: “A partial write is reported as a complete accepted operation”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “I/O disposition records”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C076-T03 · Valid control:** Construct a valid “I/O disposition records” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C076-T04 · Minimal adverse input:** Derive the “I/O disposition records” adverse fixture from the control with the smallest documented change needed to reproduce “A partial write is reported as a complete accepted operation”; retain that change as reproducible data.
- [ ] **UC-M05.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “I/O disposition records”; require “Stop during I/O leaves no ambiguous successful outcome” and forbid a false-success verdict.
- [ ] **UC-M05.06-C076-T06 · Adverse execution:** Exercise the “I/O disposition records” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C076-T07 · Effect inspection:** Inspect “I/O disposition records” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C076-T08 · Refusal versus failure:** Confirm the “I/O disposition records” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C076-T09 · Reset and retention:** Restore only the disposable “I/O disposition records” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C076-T10 · Negative regression:** Register the “I/O disposition records” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C077 · Change / failure test

**Original checklist item:** Exercise I/O disposition records when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C077-T01 · Scenario record:** Write the “I/O disposition records” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “Stop during I/O leaves no ambiguous successful outcome”.
- [ ] **UC-M05.06-C077-T02 · Baseline capture:** Create a known-valid “I/O disposition records” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C077-T03 · Injection map:** Locate the “I/O disposition records” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “I/O disposition records” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C077-T05 · Controlled trigger:** Introduce the controlled “I/O disposition records” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C077-T06 · Intermediate inspection:** Inspect the “I/O disposition records” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “I/O disposition records”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “I/O disposition records” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C077-T09 · Repeat and compare:** Repeat the selected “I/O disposition records” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C077-T10 · Failure evidence:** Publish the “I/O disposition records” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for pending I/O count and record size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “I/O disposition records”: “Pending I/O count and record size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C078-T02 · Measurement method:** Choose how to observe each “I/O disposition records” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C078-T03 · Budget decision:** Select justified resource and input limits for “I/O disposition records”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “I/O disposition records” cases for “Pending I/O count and record size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “I/O disposition records” limit; preserve “Stop during I/O leaves no ambiguous successful outcome”.
- [ ] **UC-M05.06-C078-T06 · Normal measurement:** Run or review the normal “I/O disposition records” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C078-T07 · At-limit measurement:** Exercise the “I/O disposition records” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C078-T08 · Over-limit measurement:** Exercise the “I/O disposition records” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C078-T09 · Uncovered-scope report:** List the “I/O disposition records” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C078-T10 · Limit evidence:** Publish the selected “I/O disposition records” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for I/O disposition records with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C079-T01 · Event inventory:** List the “I/O disposition records” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “I/O disposition records” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C079-T03 · Failure mapping:** Map each documented “I/O disposition records” refusal or error to a diagnostic outcome; include “A partial write is reported as a complete accepted operation” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C079-T04 · Emission path:** Add the “I/O disposition records” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C079-T05 · Redaction check:** Test “I/O disposition records” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C079-T06 · Output budget:** Set and exercise bounded “I/O disposition records” message size, rate and retention compatible with “Pending I/O count and record size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C079-T07 · Success/refusal fixtures:** Capture “I/O disposition records” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “I/O disposition records” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C079-T09 · Operator review:** Read the “I/O disposition records” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C079-T10 · Diagnostic evidence:** Publish redacted “I/O disposition records” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for I/O disposition records; label unexecuted checks as untested.

- [ ] **UC-M05.06-C080-T01 · Evidence inventory:** List the “I/O disposition records” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C080-T02 · Artifact references:** Record the exact “I/O disposition records” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C080-T03 · Fixture references:** Attach the “I/O disposition records” fixture IDs, input identities and oracle definition; preserve the source counterexample “A partial write is reported as a complete accepted operation” as a distinct evidence case.
- [ ] **UC-M05.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “I/O disposition records”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C080-T05 · Environment record:** Record the actual “I/O disposition records” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C080-T06 · Expected versus observed:** Pair every “I/O disposition records” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C080-T07 · Failure and limit records:** Attach “I/O disposition records” change/failure and bounds evidence where required; include uncovered “Pending I/O count and record size” and unresolved violations of “Stop during I/O leaves no ambiguous successful outcome”.
- [ ] **UC-M05.06-C080-T08 · Evidence hygiene:** Check the “I/O disposition records” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C080-T09 · Reproduction review:** Have the “I/O disposition records” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C080-T10 · Acceptance linkage:** Link the “I/O disposition records” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Resource release ordering

**Source delivery:** Release instance resources only after disposition and ownership records are safe.

**Source invariant:** Cleanup cannot erase evidence needed to recover interrupted work.

**Source negative case:** A temporary state root is deleted before its commit status is recorded.

**Source bounded quantities:** Cleanup steps and retained recovery bytes.

### UC-M05.06-C081 · Contract

**Original checklist item:** Specify resource release ordering inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C081-T01 · Scope statement:** Draft the operation boundary for “Resource release ordering” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource release ordering”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C081-T03 · Output inventory:** List the outputs of “Resource release ordering” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource release ordering”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C081-T05 · Prerequisite contract:** Map “Resource release ordering” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Resource release ordering”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C081-T07 · Invariant clause:** Add a normative clause for “Resource release ordering” that preserves “Cleanup cannot erase evidence needed to recover interrupted work”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource release ordering”; include the source counterexample “A temporary state root is deleted before its commit status is recorded” and the intended safe disposition.
- [ ] **UC-M05.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Cleanup steps and retained recovery bytes” in the “Resource release ordering” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C081-T10 · Contract review:** Review the “Resource release ordering” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C082 · Delivery

**Original checklist item:** Release instance resources only after disposition and ownership records are safe.

- [ ] **UC-M05.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource release ordering”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C082-T02 · Change plan:** Break the source delivery for “Resource release ordering” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Resource release ordering” that realizes this source instruction: Release instance resources only after disposition and ownership records are safe.
- [ ] **UC-M05.06-C082-T04 · Concrete realization:** Trace “Resource release ordering” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource release ordering” needed to preserve “Cleanup cannot erase evidence needed to recover interrupted work”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C082-T06 · Dependency connection:** Connect the “Resource release ordering” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C082-T07 · Resource behavior:** Account for “Cleanup steps and retained recovery bytes” in “Resource release ordering”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C082-T08 · Delivery check:** Run the smallest real “Resource release ordering” path and its adverse fixture “A temporary state root is deleted before its commit status is recorded”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C082-T09 · Patch review:** Review the “Resource release ordering” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C082-T10 · Delivery handoff:** Publish the “Resource release ordering” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Cleanup cannot erase evidence needed to recover interrupted work. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Resource release ordering”; copy its required invariant exactly: “Cleanup cannot erase evidence needed to recover interrupted work”.
- [ ] **UC-M05.06-C083-T02 · Observable terms:** Define each term in the “Resource release ordering” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C083-T03 · Precondition set:** List the preconditions under which “Cleanup cannot erase evidence needed to recover interrupted work” must hold for “Resource release ordering”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C083-T04 · Transition coverage:** Map the “Resource release ordering” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource release ordering”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C083-T06 · Satisfying fixture:** Create a concrete “Resource release ordering” case that satisfies “Cleanup cannot erase evidence needed to recover interrupted work”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C083-T07 · Violating fixture:** Create the source counterexample “A temporary state root is deleted before its commit status is recorded” for “Resource release ordering”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C083-T08 · Enforcement evidence:** Exercise the “Resource release ordering” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C083-T09 · Regression linkage:** Link the “Resource release ordering” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Resource release ordering” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C084 · Integration

**Original checklist item:** Integrate resource release ordering with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource release ordering” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C084-T02 · Field mapping:** Map every “Resource release ordering” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource release ordering” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C084-T04 · Ownership agreement:** Specify who owns “Resource release ordering” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C084-T05 · Handoff implementation:** Connect “Resource release ordering” through the mapped seam using the real adapter or explicit specification reference; preserve “Cleanup cannot erase evidence needed to recover interrupted work” across the handoff.
- [ ] **UC-M05.06-C084-T06 · Absent-input case:** Omit one required “Resource release ordering” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C084-T07 · Stale-input case:** Supply an outdated “Resource release ordering” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Resource release ordering” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C084-T09 · Valid integration trace:** Run a valid “Resource release ordering” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C084-T10 · Seam review:** Reconcile the “Resource release ordering” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for resource release ordering; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Resource release ordering” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C085-T02 · Expected-result oracle:** Specify the “Resource release ordering” expected result independently of the implementation output; include the property “Cleanup cannot erase evidence needed to recover interrupted work” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C085-T03 · Fixture material:** Create the concrete “Resource release ordering” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C085-T04 · Target preparation:** Prepare the “Resource release ordering” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C085-T05 · Initial-state record:** Record the initial “Resource release ordering” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C085-T06 · Valid-path execution:** Execute the “Resource release ordering” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C085-T07 · Outcome comparison:** Compare every declared “Resource release ordering” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C085-T08 · State and bounds check:** Inspect the “Resource release ordering” ownership/state effects and actual use of “Cleanup steps and retained recovery bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C085-T09 · Repeatability check:** Repeat the same “Resource release ordering” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C085-T10 · Positive evidence:** Attach the “Resource release ordering” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C086 · Negative test

**Original checklist item:** Negative case: A temporary state root is deleted before its commit status is recorded. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Resource release ordering” source counterexample: “A temporary state root is deleted before its commit status is recorded”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource release ordering”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C086-T03 · Valid control:** Construct a valid “Resource release ordering” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C086-T04 · Minimal adverse input:** Derive the “Resource release ordering” adverse fixture from the control with the smallest documented change needed to reproduce “A temporary state root is deleted before its commit status is recorded”; retain that change as reproducible data.
- [ ] **UC-M05.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource release ordering”; require “Cleanup cannot erase evidence needed to recover interrupted work” and forbid a false-success verdict.
- [ ] **UC-M05.06-C086-T06 · Adverse execution:** Exercise the “Resource release ordering” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C086-T07 · Effect inspection:** Inspect “Resource release ordering” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C086-T08 · Refusal versus failure:** Confirm the “Resource release ordering” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C086-T09 · Reset and retention:** Restore only the disposable “Resource release ordering” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C086-T10 · Negative regression:** Register the “Resource release ordering” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C087 · Change / failure test

**Original checklist item:** Exercise resource release ordering when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C087-T01 · Scenario record:** Write the “Resource release ordering” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “Cleanup cannot erase evidence needed to recover interrupted work”.
- [ ] **UC-M05.06-C087-T02 · Baseline capture:** Create a known-valid “Resource release ordering” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C087-T03 · Injection map:** Locate the “Resource release ordering” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Resource release ordering” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C087-T05 · Controlled trigger:** Introduce the controlled “Resource release ordering” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C087-T06 · Intermediate inspection:** Inspect the “Resource release ordering” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource release ordering”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource release ordering” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C087-T09 · Repeat and compare:** Repeat the selected “Resource release ordering” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C087-T10 · Failure evidence:** Publish the “Resource release ordering” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for cleanup steps and retained recovery bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Resource release ordering”: “Cleanup steps and retained recovery bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C088-T02 · Measurement method:** Choose how to observe each “Resource release ordering” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Resource release ordering”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource release ordering” cases for “Cleanup steps and retained recovery bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource release ordering” limit; preserve “Cleanup cannot erase evidence needed to recover interrupted work”.
- [ ] **UC-M05.06-C088-T06 · Normal measurement:** Run or review the normal “Resource release ordering” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C088-T07 · At-limit measurement:** Exercise the “Resource release ordering” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C088-T08 · Over-limit measurement:** Exercise the “Resource release ordering” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C088-T09 · Uncovered-scope report:** List the “Resource release ordering” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C088-T10 · Limit evidence:** Publish the selected “Resource release ordering” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for resource release ordering with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C089-T01 · Event inventory:** List the “Resource release ordering” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Resource release ordering” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C089-T03 · Failure mapping:** Map each documented “Resource release ordering” refusal or error to a diagnostic outcome; include “A temporary state root is deleted before its commit status is recorded” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C089-T04 · Emission path:** Add the “Resource release ordering” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C089-T05 · Redaction check:** Test “Resource release ordering” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C089-T06 · Output budget:** Set and exercise bounded “Resource release ordering” message size, rate and retention compatible with “Cleanup steps and retained recovery bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C089-T07 · Success/refusal fixtures:** Capture “Resource release ordering” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Resource release ordering” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C089-T09 · Operator review:** Read the “Resource release ordering” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C089-T10 · Diagnostic evidence:** Publish redacted “Resource release ordering” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource release ordering; label unexecuted checks as untested.

- [ ] **UC-M05.06-C090-T01 · Evidence inventory:** List the “Resource release ordering” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C090-T02 · Artifact references:** Record the exact “Resource release ordering” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C090-T03 · Fixture references:** Attach the “Resource release ordering” fixture IDs, input identities and oracle definition; preserve the source counterexample “A temporary state root is deleted before its commit status is recorded” as a distinct evidence case.
- [ ] **UC-M05.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource release ordering”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C090-T05 · Environment record:** Record the actual “Resource release ordering” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C090-T06 · Expected versus observed:** Pair every “Resource release ordering” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C090-T07 · Failure and limit records:** Attach “Resource release ordering” change/failure and bounds evidence where required; include uncovered “Cleanup steps and retained recovery bytes” and unresolved violations of “Cleanup cannot erase evidence needed to recover interrupted work”.
- [ ] **UC-M05.06-C090-T08 · Evidence hygiene:** Check the “Resource release ordering” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C090-T09 · Reproduction review:** Have the “Resource release ordering” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C090-T10 · Acceptance linkage:** Link the “Resource release ordering” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Stop acceptance tests

**Source delivery:** Stop guests during CPU work, queued work and active I/O.

**Source invariant:** Every accepted operation has a definitive recorded disposition after stop.

**Source negative case:** The test checks process exit but ignores lost accepted requests.

**Source bounded quantities:** Scenario count and drain/termination duration.

### UC-M05.06-C091 · Contract

**Original checklist item:** Specify stop acceptance tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.06-C091-T01 · Scope statement:** Draft the operation boundary for “Stop acceptance tests” within Graceful stop and drain protocol; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Stop acceptance tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.06-C091-T03 · Output inventory:** List the outputs of “Stop acceptance tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Stop acceptance tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.06-C091-T05 · Prerequisite contract:** Map “Stop acceptance tests” to the source component prerequisites (UC-M05.04, UC-M05.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Stop acceptance tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.06-C091-T07 · Invariant clause:** Add a normative clause for “Stop acceptance tests” that preserves “Every accepted operation has a definitive recorded disposition after stop”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Stop acceptance tests”; include the source counterexample “The test checks process exit but ignores lost accepted requests” and the intended safe disposition.
- [ ] **UC-M05.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scenario count and drain/termination duration” in the “Stop acceptance tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.06-C091-T10 · Contract review:** Review the “Stop acceptance tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.06-C092 · Delivery

**Original checklist item:** Stop guests during CPU work, queued work and active I/O.

- [ ] **UC-M05.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Stop acceptance tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.06-C092-T02 · Change plan:** Break the source delivery for “Stop acceptance tests” into concrete edit targets and reviewable outputs; keep the UC-M05.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.06-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Stop acceptance tests” that realizes this source instruction: Stop guests during CPU work, queued work and active I/O.
- [ ] **UC-M05.06-C092-T04 · Concrete realization:** Trace “Stop acceptance tests” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Stop acceptance tests” needed to preserve “Every accepted operation has a definitive recorded disposition after stop”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.06-C092-T06 · Dependency connection:** Connect the “Stop acceptance tests” implementation to admission closure, guest drain signaling and durable state/effect disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.06-C092-T07 · Resource behavior:** Account for “Scenario count and drain/termination duration” in “Stop acceptance tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.06-C092-T08 · Delivery check:** Run the smallest real “Stop acceptance tests” path and its adverse fixture “The test checks process exit but ignores lost accepted requests”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.06-C092-T09 · Patch review:** Review the “Stop acceptance tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.06-C092-T10 · Delivery handoff:** Publish the “Stop acceptance tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every accepted operation has a definitive recorded disposition after stop. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Stop acceptance tests”; copy its required invariant exactly: “Every accepted operation has a definitive recorded disposition after stop”.
- [ ] **UC-M05.06-C093-T02 · Observable terms:** Define each term in the “Stop acceptance tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.06-C093-T03 · Precondition set:** List the preconditions under which “Every accepted operation has a definitive recorded disposition after stop” must hold for “Stop acceptance tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.06-C093-T04 · Transition coverage:** Map the “Stop acceptance tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Stop acceptance tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.06-C093-T06 · Satisfying fixture:** Create a concrete “Stop acceptance tests” case that satisfies “Every accepted operation has a definitive recorded disposition after stop”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.06-C093-T07 · Violating fixture:** Create the source counterexample “The test checks process exit but ignores lost accepted requests” for “Stop acceptance tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.06-C093-T08 · Enforcement evidence:** Exercise the “Stop acceptance tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.06-C093-T09 · Regression linkage:** Link the “Stop acceptance tests” property to changes in admission closure, guest drain signaling and durable state/effect disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Stop acceptance tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.06-C094 · Integration

**Original checklist item:** Integrate stop acceptance tests with admission closure, guest drain signaling and durable state/effect disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Stop acceptance tests” across admission closure, guest drain signaling and durable state/effect disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.06-C094-T02 · Field mapping:** Map every “Stop acceptance tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Stop acceptance tests” (source dependency list: UC-M05.04, UC-M05.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.06-C094-T04 · Ownership agreement:** Specify who owns “Stop acceptance tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.06-C094-T05 · Handoff implementation:** Connect “Stop acceptance tests” through the mapped seam using the real adapter or explicit specification reference; preserve “Every accepted operation has a definitive recorded disposition after stop” across the handoff.
- [ ] **UC-M05.06-C094-T06 · Absent-input case:** Omit one required “Stop acceptance tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.06-C094-T07 · Stale-input case:** Supply an outdated “Stop acceptance tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Stop acceptance tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.06-C094-T09 · Valid integration trace:** Run a valid “Stop acceptance tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.06-C094-T10 · Seam review:** Reconcile the “Stop acceptance tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for stop acceptance tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Stop acceptance tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.06-C095-T02 · Expected-result oracle:** Specify the “Stop acceptance tests” expected result independently of the implementation output; include the property “Every accepted operation has a definitive recorded disposition after stop” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.06-C095-T03 · Fixture material:** Create the concrete “Stop acceptance tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.06-C095-T04 · Target preparation:** Prepare the “Stop acceptance tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.06-C095-T05 · Initial-state record:** Record the initial “Stop acceptance tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.06-C095-T06 · Valid-path execution:** Execute the “Stop acceptance tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.06-C095-T07 · Outcome comparison:** Compare every declared “Stop acceptance tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.06-C095-T08 · State and bounds check:** Inspect the “Stop acceptance tests” ownership/state effects and actual use of “Scenario count and drain/termination duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.06-C095-T09 · Repeatability check:** Repeat the same “Stop acceptance tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.06-C095-T10 · Positive evidence:** Attach the “Stop acceptance tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.06-C096 · Negative test

**Original checklist item:** Negative case: The test checks process exit but ignores lost accepted requests. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Stop acceptance tests” source counterexample: “The test checks process exit but ignores lost accepted requests”; state which precondition or invariant it challenges.
- [ ] **UC-M05.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Stop acceptance tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.06-C096-T03 · Valid control:** Construct a valid “Stop acceptance tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.06-C096-T04 · Minimal adverse input:** Derive the “Stop acceptance tests” adverse fixture from the control with the smallest documented change needed to reproduce “The test checks process exit but ignores lost accepted requests”; retain that change as reproducible data.
- [ ] **UC-M05.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Stop acceptance tests”; require “Every accepted operation has a definitive recorded disposition after stop” and forbid a false-success verdict.
- [ ] **UC-M05.06-C096-T06 · Adverse execution:** Exercise the “Stop acceptance tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.06-C096-T07 · Effect inspection:** Inspect “Stop acceptance tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.06-C096-T08 · Refusal versus failure:** Confirm the “Stop acceptance tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.06-C096-T09 · Reset and retention:** Restore only the disposable “Stop acceptance tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.06-C096-T10 · Negative regression:** Register the “Stop acceptance tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.06-C097 · Change / failure test

**Original checklist item:** Exercise stop acceptance tests when stop begins while accepted work still has active I/O; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.06-C097-T01 · Scenario record:** Write the “Stop acceptance tests” change/failure scenario exactly as supplied: stop begins while accepted work still has active I/O; identify the property that must remain true: “Every accepted operation has a definitive recorded disposition after stop”.
- [ ] **UC-M05.06-C097-T02 · Baseline capture:** Create a known-valid “Stop acceptance tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.06-C097-T03 · Injection map:** Locate the “Stop acceptance tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Stop acceptance tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.06-C097-T05 · Controlled trigger:** Introduce the controlled “Stop acceptance tests” scenario in the disposable fixture: stop begins while accepted work still has active I/O; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.06-C097-T06 · Intermediate inspection:** Inspect the “Stop acceptance tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Stop acceptance tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Stop acceptance tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.06-C097-T09 · Repeat and compare:** Repeat the selected “Stop acceptance tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.06-C097-T10 · Failure evidence:** Publish the “Stop acceptance tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for scenario count and drain/termination duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Stop acceptance tests”: “Scenario count and drain/termination duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.06-C098-T02 · Measurement method:** Choose how to observe each “Stop acceptance tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Stop acceptance tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Stop acceptance tests” cases for “Scenario count and drain/termination duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Stop acceptance tests” limit; preserve “Every accepted operation has a definitive recorded disposition after stop”.
- [ ] **UC-M05.06-C098-T06 · Normal measurement:** Run or review the normal “Stop acceptance tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.06-C098-T07 · At-limit measurement:** Exercise the “Stop acceptance tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.06-C098-T08 · Over-limit measurement:** Exercise the “Stop acceptance tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.06-C098-T09 · Uncovered-scope report:** List the “Stop acceptance tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.06-C098-T10 · Limit evidence:** Publish the selected “Stop acceptance tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for stop acceptance tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.06-C099-T01 · Event inventory:** List the “Stop acceptance tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Stop acceptance tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.06-C099-T03 · Failure mapping:** Map each documented “Stop acceptance tests” refusal or error to a diagnostic outcome; include “The test checks process exit but ignores lost accepted requests” and prohibit conversion into a success message.
- [ ] **UC-M05.06-C099-T04 · Emission path:** Add the “Stop acceptance tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.06-C099-T05 · Redaction check:** Test “Stop acceptance tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.06-C099-T06 · Output budget:** Set and exercise bounded “Stop acceptance tests” message size, rate and retention compatible with “Scenario count and drain/termination duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.06-C099-T07 · Success/refusal fixtures:** Capture “Stop acceptance tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Stop acceptance tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.06-C099-T09 · Operator review:** Read the “Stop acceptance tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.06-C099-T10 · Diagnostic evidence:** Publish redacted “Stop acceptance tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for stop acceptance tests; label unexecuted checks as untested.

- [ ] **UC-M05.06-C100-T01 · Evidence inventory:** List the “Stop acceptance tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.06-C100-T02 · Artifact references:** Record the exact “Stop acceptance tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.06-C100-T03 · Fixture references:** Attach the “Stop acceptance tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “The test checks process exit but ignores lost accepted requests” as a distinct evidence case.
- [ ] **UC-M05.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Stop acceptance tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.06-C100-T05 · Environment record:** Record the actual “Stop acceptance tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.06-C100-T06 · Expected versus observed:** Pair every “Stop acceptance tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.06-C100-T07 · Failure and limit records:** Attach “Stop acceptance tests” change/failure and bounds evidence where required; include uncovered “Scenario count and drain/termination duration” and unresolved violations of “Every accepted operation has a definitive recorded disposition after stop”.
- [ ] **UC-M05.06-C100-T08 · Evidence hygiene:** Check the “Stop acceptance tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.06-C100-T09 · Reproduction review:** Have the “Stop acceptance tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.06-C100-T10 · Acceptance linkage:** Link the “Stop acceptance tests” evidence to its parent and UC-M05.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

