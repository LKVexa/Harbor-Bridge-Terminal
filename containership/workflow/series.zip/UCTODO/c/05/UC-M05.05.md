# UC-M05.05 — Workload readiness and liveness checks

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/05.md)

| Field | Preserved source value |
|---|---|
| Workstream | 05. Workload orchestration and scheduling |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M03.06](../03/UC-M03.06.md), [UC-M05.04](../05/UC-M05.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S6]. |

## Original requirement

Separate successful build, boot, ready service, live process, completed invocation and correct application output.

**Original acceptance criterion:** A booted but incorrect or stalled guest is not marked ready; probes have deadlines and output-size limits.

**Source trace:** Original checklist `UC100/c/05/UC-M05.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 473–483 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Build-status separation

**Source delivery:** Represent successful build independently from boot and service readiness.

**Source invariant:** A built image is not automatically a ready service.

**Source negative case:** A successful compilation sets ready status without booting.

**Source bounded quantities:** Status fields and evidence retention.

### UC-M05.05-C001 · Contract

**Original checklist item:** Specify build-status separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C001-T01 · Scope statement:** Draft the operation boundary for “Build-status separation” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Build-status separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C001-T03 · Output inventory:** List the outputs of “Build-status separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Build-status separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C001-T05 · Prerequisite contract:** Map “Build-status separation” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Build-status separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C001-T07 · Invariant clause:** Add a normative clause for “Build-status separation” that preserves “A built image is not automatically a ready service”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Build-status separation”; include the source counterexample “A successful compilation sets ready status without booting” and the intended safe disposition.
- [ ] **UC-M05.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Status fields and evidence retention” in the “Build-status separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C001-T10 · Contract review:** Review the “Build-status separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C002 · Delivery

**Original checklist item:** Represent successful build independently from boot and service readiness.

- [ ] **UC-M05.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Build-status separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C002-T02 · Change plan:** Break the source delivery for “Build-status separation” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C002-T03 · Core artifact:** Create the “Build-status separation” model, schema or inventory that realizes this source instruction: Represent successful build independently from boot and service readiness.
- [ ] **UC-M05.05-C002-T04 · Concrete realization:** Populate “Build-status separation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Build-status separation” needed to preserve “A built image is not automatically a ready service”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C002-T06 · Dependency connection:** Connect the “Build-status separation” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C002-T07 · Resource behavior:** Account for “Status fields and evidence retention” in “Build-status separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C002-T08 · Delivery check:** Run the smallest real “Build-status separation” path and its adverse fixture “A successful compilation sets ready status without booting”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C002-T09 · Patch review:** Review the “Build-status separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C002-T10 · Delivery handoff:** Publish the “Build-status separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A built image is not automatically a ready service. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Build-status separation”; copy its required invariant exactly: “A built image is not automatically a ready service”.
- [ ] **UC-M05.05-C003-T02 · Observable terms:** Define each term in the “Build-status separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C003-T03 · Precondition set:** List the preconditions under which “A built image is not automatically a ready service” must hold for “Build-status separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C003-T04 · Transition coverage:** Map the “Build-status separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Build-status separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C003-T06 · Satisfying fixture:** Create a concrete “Build-status separation” case that satisfies “A built image is not automatically a ready service”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C003-T07 · Violating fixture:** Create the source counterexample “A successful compilation sets ready status without booting” for “Build-status separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C003-T08 · Enforcement evidence:** Exercise the “Build-status separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C003-T09 · Regression linkage:** Link the “Build-status separation” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Build-status separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C004 · Integration

**Original checklist item:** Integrate build-status separation with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Build-status separation” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C004-T02 · Field mapping:** Map every “Build-status separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Build-status separation” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C004-T04 · Ownership agreement:** Specify who owns “Build-status separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C004-T05 · Handoff implementation:** Connect “Build-status separation” through the mapped seam using the real adapter or explicit specification reference; preserve “A built image is not automatically a ready service” across the handoff.
- [ ] **UC-M05.05-C004-T06 · Absent-input case:** Omit one required “Build-status separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C004-T07 · Stale-input case:** Supply an outdated “Build-status separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Build-status separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C004-T09 · Valid integration trace:** Run a valid “Build-status separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C004-T10 · Seam review:** Reconcile the “Build-status separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for build-status separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Build-status separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C005-T02 · Expected-result oracle:** Specify the “Build-status separation” expected result independently of the implementation output; include the property “A built image is not automatically a ready service” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C005-T03 · Fixture material:** Create the concrete “Build-status separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C005-T04 · Target preparation:** Prepare the “Build-status separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C005-T05 · Initial-state record:** Record the initial “Build-status separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C005-T06 · Valid-path execution:** Execute the “Build-status separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C005-T07 · Outcome comparison:** Compare every declared “Build-status separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C005-T08 · State and bounds check:** Inspect the “Build-status separation” ownership/state effects and actual use of “Status fields and evidence retention”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C005-T09 · Repeatability check:** Repeat the same “Build-status separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C005-T10 · Positive evidence:** Attach the “Build-status separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C006 · Negative test

**Original checklist item:** Negative case: A successful compilation sets ready status without booting. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Build-status separation” source counterexample: “A successful compilation sets ready status without booting”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Build-status separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C006-T03 · Valid control:** Construct a valid “Build-status separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C006-T04 · Minimal adverse input:** Derive the “Build-status separation” adverse fixture from the control with the smallest documented change needed to reproduce “A successful compilation sets ready status without booting”; retain that change as reproducible data.
- [ ] **UC-M05.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Build-status separation”; require “A built image is not automatically a ready service” and forbid a false-success verdict.
- [ ] **UC-M05.05-C006-T06 · Adverse execution:** Exercise the “Build-status separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C006-T07 · Effect inspection:** Inspect “Build-status separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C006-T08 · Refusal versus failure:** Confirm the “Build-status separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C006-T09 · Reset and retention:** Restore only the disposable “Build-status separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C006-T10 · Negative regression:** Register the “Build-status separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C007 · Change / failure test

**Original checklist item:** Exercise build-status separation when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C007-T01 · Scenario record:** Write the “Build-status separation” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “A built image is not automatically a ready service”.
- [ ] **UC-M05.05-C007-T02 · Baseline capture:** Create a known-valid “Build-status separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C007-T03 · Injection map:** Locate the “Build-status separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Build-status separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C007-T05 · Controlled trigger:** Introduce the controlled “Build-status separation” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C007-T06 · Intermediate inspection:** Inspect the “Build-status separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Build-status separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Build-status separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C007-T09 · Repeat and compare:** Repeat the selected “Build-status separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C007-T10 · Failure evidence:** Publish the “Build-status separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C008 · Bounds

**Original checklist item:** Choose, document and test limits for status fields and evidence retention; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Build-status separation”: “Status fields and evidence retention”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C008-T02 · Measurement method:** Choose how to observe each “Build-status separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C008-T03 · Budget decision:** Select justified resource and input limits for “Build-status separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Build-status separation” cases for “Status fields and evidence retention”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Build-status separation” limit; preserve “A built image is not automatically a ready service”.
- [ ] **UC-M05.05-C008-T06 · Normal measurement:** Run or review the normal “Build-status separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C008-T07 · At-limit measurement:** Exercise the “Build-status separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C008-T08 · Over-limit measurement:** Exercise the “Build-status separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C008-T09 · Uncovered-scope report:** List the “Build-status separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C008-T10 · Limit evidence:** Publish the selected “Build-status separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for build-status separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C009-T01 · Event inventory:** List the “Build-status separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Build-status separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C009-T03 · Failure mapping:** Map each documented “Build-status separation” refusal or error to a diagnostic outcome; include “A successful compilation sets ready status without booting” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C009-T04 · Emission path:** Add the “Build-status separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C009-T05 · Redaction check:** Test “Build-status separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C009-T06 · Output budget:** Set and exercise bounded “Build-status separation” message size, rate and retention compatible with “Status fields and evidence retention”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C009-T07 · Success/refusal fixtures:** Capture “Build-status separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Build-status separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C009-T09 · Operator review:** Read the “Build-status separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C009-T10 · Diagnostic evidence:** Publish redacted “Build-status separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for build-status separation; label unexecuted checks as untested.

- [ ] **UC-M05.05-C010-T01 · Evidence inventory:** List the “Build-status separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C010-T02 · Artifact references:** Record the exact “Build-status separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C010-T03 · Fixture references:** Attach the “Build-status separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A successful compilation sets ready status without booting” as a distinct evidence case.
- [ ] **UC-M05.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Build-status separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C010-T05 · Environment record:** Record the actual “Build-status separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C010-T06 · Expected versus observed:** Pair every “Build-status separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C010-T07 · Failure and limit records:** Attach “Build-status separation” change/failure and bounds evidence where required; include uncovered “Status fields and evidence retention” and unresolved violations of “A built image is not automatically a ready service”.
- [ ] **UC-M05.05-C010-T08 · Evidence hygiene:** Check the “Build-status separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C010-T09 · Reproduction review:** Have the “Build-status separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C010-T10 · Acceptance linkage:** Link the “Build-status separation” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Boot observation

**Source delivery:** Require a guest-originated or backend-qualified boot observation.

**Source invariant:** A live host launcher is not proof that the guest booted.

**Source negative case:** The backend process runs but the guest never reaches its entry point.

**Source bounded quantities:** Boot deadline and observation bytes.

### UC-M05.05-C011 · Contract

**Original checklist item:** Specify boot observation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C011-T01 · Scope statement:** Draft the operation boundary for “Boot observation” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot observation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C011-T03 · Output inventory:** List the outputs of “Boot observation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot observation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C011-T05 · Prerequisite contract:** Map “Boot observation” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Boot observation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C011-T07 · Invariant clause:** Add a normative clause for “Boot observation” that preserves “A live host launcher is not proof that the guest booted”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot observation”; include the source counterexample “The backend process runs but the guest never reaches its entry point” and the intended safe disposition.
- [ ] **UC-M05.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Boot deadline and observation bytes” in the “Boot observation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C011-T10 · Contract review:** Review the “Boot observation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C012 · Delivery

**Original checklist item:** Require a guest-originated or backend-qualified boot observation.

- [ ] **UC-M05.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot observation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C012-T02 · Change plan:** Break the source delivery for “Boot observation” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Boot observation” that realizes this source instruction: Require a guest-originated or backend-qualified boot observation.
- [ ] **UC-M05.05-C012-T04 · Concrete realization:** Trace “Boot observation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot observation” needed to preserve “A live host launcher is not proof that the guest booted”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C012-T06 · Dependency connection:** Connect the “Boot observation” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C012-T07 · Resource behavior:** Account for “Boot deadline and observation bytes” in “Boot observation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C012-T08 · Delivery check:** Run the smallest real “Boot observation” path and its adverse fixture “The backend process runs but the guest never reaches its entry point”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C012-T09 · Patch review:** Review the “Boot observation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C012-T10 · Delivery handoff:** Publish the “Boot observation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A live host launcher is not proof that the guest booted. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Boot observation”; copy its required invariant exactly: “A live host launcher is not proof that the guest booted”.
- [ ] **UC-M05.05-C013-T02 · Observable terms:** Define each term in the “Boot observation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C013-T03 · Precondition set:** List the preconditions under which “A live host launcher is not proof that the guest booted” must hold for “Boot observation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C013-T04 · Transition coverage:** Map the “Boot observation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot observation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C013-T06 · Satisfying fixture:** Create a concrete “Boot observation” case that satisfies “A live host launcher is not proof that the guest booted”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C013-T07 · Violating fixture:** Create the source counterexample “The backend process runs but the guest never reaches its entry point” for “Boot observation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C013-T08 · Enforcement evidence:** Exercise the “Boot observation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C013-T09 · Regression linkage:** Link the “Boot observation” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Boot observation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C014 · Integration

**Original checklist item:** Integrate boot observation with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot observation” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C014-T02 · Field mapping:** Map every “Boot observation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot observation” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C014-T04 · Ownership agreement:** Specify who owns “Boot observation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C014-T05 · Handoff implementation:** Connect “Boot observation” through the mapped seam using the real adapter or explicit specification reference; preserve “A live host launcher is not proof that the guest booted” across the handoff.
- [ ] **UC-M05.05-C014-T06 · Absent-input case:** Omit one required “Boot observation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C014-T07 · Stale-input case:** Supply an outdated “Boot observation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Boot observation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C014-T09 · Valid integration trace:** Run a valid “Boot observation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C014-T10 · Seam review:** Reconcile the “Boot observation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot observation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot observation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C015-T02 · Expected-result oracle:** Specify the “Boot observation” expected result independently of the implementation output; include the property “A live host launcher is not proof that the guest booted” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C015-T03 · Fixture material:** Create the concrete “Boot observation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C015-T04 · Target preparation:** Prepare the “Boot observation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C015-T05 · Initial-state record:** Record the initial “Boot observation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C015-T06 · Valid-path execution:** Execute the “Boot observation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C015-T07 · Outcome comparison:** Compare every declared “Boot observation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C015-T08 · State and bounds check:** Inspect the “Boot observation” ownership/state effects and actual use of “Boot deadline and observation bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C015-T09 · Repeatability check:** Repeat the same “Boot observation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C015-T10 · Positive evidence:** Attach the “Boot observation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C016 · Negative test

**Original checklist item:** Negative case: The backend process runs but the guest never reaches its entry point. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Boot observation” source counterexample: “The backend process runs but the guest never reaches its entry point”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot observation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C016-T03 · Valid control:** Construct a valid “Boot observation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C016-T04 · Minimal adverse input:** Derive the “Boot observation” adverse fixture from the control with the smallest documented change needed to reproduce “The backend process runs but the guest never reaches its entry point”; retain that change as reproducible data.
- [ ] **UC-M05.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot observation”; require “A live host launcher is not proof that the guest booted” and forbid a false-success verdict.
- [ ] **UC-M05.05-C016-T06 · Adverse execution:** Exercise the “Boot observation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C016-T07 · Effect inspection:** Inspect “Boot observation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C016-T08 · Refusal versus failure:** Confirm the “Boot observation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C016-T09 · Reset and retention:** Restore only the disposable “Boot observation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C016-T10 · Negative regression:** Register the “Boot observation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C017 · Change / failure test

**Original checklist item:** Exercise boot observation when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C017-T01 · Scenario record:** Write the “Boot observation” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “A live host launcher is not proof that the guest booted”.
- [ ] **UC-M05.05-C017-T02 · Baseline capture:** Create a known-valid “Boot observation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C017-T03 · Injection map:** Locate the “Boot observation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Boot observation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C017-T05 · Controlled trigger:** Introduce the controlled “Boot observation” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C017-T06 · Intermediate inspection:** Inspect the “Boot observation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot observation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot observation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C017-T09 · Repeat and compare:** Repeat the selected “Boot observation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C017-T10 · Failure evidence:** Publish the “Boot observation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C018 · Bounds

**Original checklist item:** Choose, document and test limits for boot deadline and observation bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Boot observation”: “Boot deadline and observation bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C018-T02 · Measurement method:** Choose how to observe each “Boot observation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C018-T03 · Budget decision:** Select justified resource and input limits for “Boot observation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot observation” cases for “Boot deadline and observation bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot observation” limit; preserve “A live host launcher is not proof that the guest booted”.
- [ ] **UC-M05.05-C018-T06 · Normal measurement:** Run or review the normal “Boot observation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C018-T07 · At-limit measurement:** Exercise the “Boot observation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C018-T08 · Over-limit measurement:** Exercise the “Boot observation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C018-T09 · Uncovered-scope report:** List the “Boot observation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C018-T10 · Limit evidence:** Publish the selected “Boot observation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot observation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C019-T01 · Event inventory:** List the “Boot observation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Boot observation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C019-T03 · Failure mapping:** Map each documented “Boot observation” refusal or error to a diagnostic outcome; include “The backend process runs but the guest never reaches its entry point” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C019-T04 · Emission path:** Add the “Boot observation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C019-T05 · Redaction check:** Test “Boot observation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C019-T06 · Output budget:** Set and exercise bounded “Boot observation” message size, rate and retention compatible with “Boot deadline and observation bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C019-T07 · Success/refusal fixtures:** Capture “Boot observation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot observation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C019-T09 · Operator review:** Read the “Boot observation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C019-T10 · Diagnostic evidence:** Publish redacted “Boot observation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot observation; label unexecuted checks as untested.

- [ ] **UC-M05.05-C020-T01 · Evidence inventory:** List the “Boot observation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C020-T02 · Artifact references:** Record the exact “Boot observation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C020-T03 · Fixture references:** Attach the “Boot observation” fixture IDs, input identities and oracle definition; preserve the source counterexample “The backend process runs but the guest never reaches its entry point” as a distinct evidence case.
- [ ] **UC-M05.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot observation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C020-T05 · Environment record:** Record the actual “Boot observation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C020-T06 · Expected versus observed:** Pair every “Boot observation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C020-T07 · Failure and limit records:** Attach “Boot observation” change/failure and bounds evidence where required; include uncovered “Boot deadline and observation bytes” and unresolved violations of “A live host launcher is not proof that the guest booted”.
- [ ] **UC-M05.05-C020-T08 · Evidence hygiene:** Check the “Boot observation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C020-T09 · Reproduction review:** Have the “Boot observation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C020-T10 · Acceptance linkage:** Link the “Boot observation” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Readiness probe contract

**Source delivery:** Define application-specific readiness criteria and allowed probe responses.

**Source invariant:** A readiness pass demonstrates the declared readiness condition.

**Source negative case:** A guest returns a generic heartbeat while required state is unavailable.

**Source bounded quantities:** Probe payload size and response deadline.

### UC-M05.05-C021 · Contract

**Original checklist item:** Specify readiness probe contract inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C021-T01 · Scope statement:** Draft the operation boundary for “Readiness probe contract” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Readiness probe contract”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C021-T03 · Output inventory:** List the outputs of “Readiness probe contract” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Readiness probe contract”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C021-T05 · Prerequisite contract:** Map “Readiness probe contract” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Readiness probe contract”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C021-T07 · Invariant clause:** Add a normative clause for “Readiness probe contract” that preserves “A readiness pass demonstrates the declared readiness condition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Readiness probe contract”; include the source counterexample “A guest returns a generic heartbeat while required state is unavailable” and the intended safe disposition.
- [ ] **UC-M05.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe payload size and response deadline” in the “Readiness probe contract” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C021-T10 · Contract review:** Review the “Readiness probe contract” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C022 · Delivery

**Original checklist item:** Define application-specific readiness criteria and allowed probe responses.

- [ ] **UC-M05.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Readiness probe contract”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C022-T02 · Change plan:** Break the source delivery for “Readiness probe contract” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C022-T03 · Core artifact:** Create the “Readiness probe contract” model, schema or inventory that realizes this source instruction: Define application-specific readiness criteria and allowed probe responses.
- [ ] **UC-M05.05-C022-T04 · Concrete realization:** Populate “Readiness probe contract” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Readiness probe contract” needed to preserve “A readiness pass demonstrates the declared readiness condition”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C022-T06 · Dependency connection:** Connect the “Readiness probe contract” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C022-T07 · Resource behavior:** Account for “Probe payload size and response deadline” in “Readiness probe contract”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C022-T08 · Delivery check:** Run the smallest real “Readiness probe contract” path and its adverse fixture “A guest returns a generic heartbeat while required state is unavailable”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C022-T09 · Patch review:** Review the “Readiness probe contract” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C022-T10 · Delivery handoff:** Publish the “Readiness probe contract” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A readiness pass demonstrates the declared readiness condition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Readiness probe contract”; copy its required invariant exactly: “A readiness pass demonstrates the declared readiness condition”.
- [ ] **UC-M05.05-C023-T02 · Observable terms:** Define each term in the “Readiness probe contract” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C023-T03 · Precondition set:** List the preconditions under which “A readiness pass demonstrates the declared readiness condition” must hold for “Readiness probe contract”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C023-T04 · Transition coverage:** Map the “Readiness probe contract” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Readiness probe contract”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C023-T06 · Satisfying fixture:** Create a concrete “Readiness probe contract” case that satisfies “A readiness pass demonstrates the declared readiness condition”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C023-T07 · Violating fixture:** Create the source counterexample “A guest returns a generic heartbeat while required state is unavailable” for “Readiness probe contract”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C023-T08 · Enforcement evidence:** Exercise the “Readiness probe contract” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C023-T09 · Regression linkage:** Link the “Readiness probe contract” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Readiness probe contract” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C024 · Integration

**Original checklist item:** Integrate readiness probe contract with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Readiness probe contract” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C024-T02 · Field mapping:** Map every “Readiness probe contract” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Readiness probe contract” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C024-T04 · Ownership agreement:** Specify who owns “Readiness probe contract” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C024-T05 · Handoff implementation:** Connect “Readiness probe contract” through the mapped seam using the real adapter or explicit specification reference; preserve “A readiness pass demonstrates the declared readiness condition” across the handoff.
- [ ] **UC-M05.05-C024-T06 · Absent-input case:** Omit one required “Readiness probe contract” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C024-T07 · Stale-input case:** Supply an outdated “Readiness probe contract” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Readiness probe contract” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C024-T09 · Valid integration trace:** Run a valid “Readiness probe contract” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C024-T10 · Seam review:** Reconcile the “Readiness probe contract” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for readiness probe contract; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Readiness probe contract” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C025-T02 · Expected-result oracle:** Specify the “Readiness probe contract” expected result independently of the implementation output; include the property “A readiness pass demonstrates the declared readiness condition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C025-T03 · Fixture material:** Create the concrete “Readiness probe contract” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C025-T04 · Target preparation:** Prepare the “Readiness probe contract” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C025-T05 · Initial-state record:** Record the initial “Readiness probe contract” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C025-T06 · Valid-path execution:** Execute the “Readiness probe contract” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C025-T07 · Outcome comparison:** Compare every declared “Readiness probe contract” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C025-T08 · State and bounds check:** Inspect the “Readiness probe contract” ownership/state effects and actual use of “Probe payload size and response deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C025-T09 · Repeatability check:** Repeat the same “Readiness probe contract” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C025-T10 · Positive evidence:** Attach the “Readiness probe contract” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C026 · Negative test

**Original checklist item:** Negative case: A guest returns a generic heartbeat while required state is unavailable. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Readiness probe contract” source counterexample: “A guest returns a generic heartbeat while required state is unavailable”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Readiness probe contract”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C026-T03 · Valid control:** Construct a valid “Readiness probe contract” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C026-T04 · Minimal adverse input:** Derive the “Readiness probe contract” adverse fixture from the control with the smallest documented change needed to reproduce “A guest returns a generic heartbeat while required state is unavailable”; retain that change as reproducible data.
- [ ] **UC-M05.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Readiness probe contract”; require “A readiness pass demonstrates the declared readiness condition” and forbid a false-success verdict.
- [ ] **UC-M05.05-C026-T06 · Adverse execution:** Exercise the “Readiness probe contract” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C026-T07 · Effect inspection:** Inspect “Readiness probe contract” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C026-T08 · Refusal versus failure:** Confirm the “Readiness probe contract” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C026-T09 · Reset and retention:** Restore only the disposable “Readiness probe contract” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C026-T10 · Negative regression:** Register the “Readiness probe contract” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C027 · Change / failure test

**Original checklist item:** Exercise readiness probe contract when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C027-T01 · Scenario record:** Write the “Readiness probe contract” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “A readiness pass demonstrates the declared readiness condition”.
- [ ] **UC-M05.05-C027-T02 · Baseline capture:** Create a known-valid “Readiness probe contract” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C027-T03 · Injection map:** Locate the “Readiness probe contract” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Readiness probe contract” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C027-T05 · Controlled trigger:** Introduce the controlled “Readiness probe contract” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C027-T06 · Intermediate inspection:** Inspect the “Readiness probe contract” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Readiness probe contract”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Readiness probe contract” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C027-T09 · Repeat and compare:** Repeat the selected “Readiness probe contract” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C027-T10 · Failure evidence:** Publish the “Readiness probe contract” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C028 · Bounds

**Original checklist item:** Choose, document and test limits for probe payload size and response deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Readiness probe contract”: “Probe payload size and response deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C028-T02 · Measurement method:** Choose how to observe each “Readiness probe contract” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C028-T03 · Budget decision:** Select justified resource and input limits for “Readiness probe contract”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Readiness probe contract” cases for “Probe payload size and response deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Readiness probe contract” limit; preserve “A readiness pass demonstrates the declared readiness condition”.
- [ ] **UC-M05.05-C028-T06 · Normal measurement:** Run or review the normal “Readiness probe contract” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C028-T07 · At-limit measurement:** Exercise the “Readiness probe contract” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C028-T08 · Over-limit measurement:** Exercise the “Readiness probe contract” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C028-T09 · Uncovered-scope report:** List the “Readiness probe contract” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C028-T10 · Limit evidence:** Publish the selected “Readiness probe contract” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for readiness probe contract with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C029-T01 · Event inventory:** List the “Readiness probe contract” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Readiness probe contract” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C029-T03 · Failure mapping:** Map each documented “Readiness probe contract” refusal or error to a diagnostic outcome; include “A guest returns a generic heartbeat while required state is unavailable” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C029-T04 · Emission path:** Add the “Readiness probe contract” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C029-T05 · Redaction check:** Test “Readiness probe contract” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C029-T06 · Output budget:** Set and exercise bounded “Readiness probe contract” message size, rate and retention compatible with “Probe payload size and response deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C029-T07 · Success/refusal fixtures:** Capture “Readiness probe contract” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Readiness probe contract” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C029-T09 · Operator review:** Read the “Readiness probe contract” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C029-T10 · Diagnostic evidence:** Publish redacted “Readiness probe contract” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for readiness probe contract; label unexecuted checks as untested.

- [ ] **UC-M05.05-C030-T01 · Evidence inventory:** List the “Readiness probe contract” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C030-T02 · Artifact references:** Record the exact “Readiness probe contract” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C030-T03 · Fixture references:** Attach the “Readiness probe contract” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest returns a generic heartbeat while required state is unavailable” as a distinct evidence case.
- [ ] **UC-M05.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Readiness probe contract”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C030-T05 · Environment record:** Record the actual “Readiness probe contract” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C030-T06 · Expected versus observed:** Pair every “Readiness probe contract” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C030-T07 · Failure and limit records:** Attach “Readiness probe contract” change/failure and bounds evidence where required; include uncovered “Probe payload size and response deadline” and unresolved violations of “A readiness pass demonstrates the declared readiness condition”.
- [ ] **UC-M05.05-C030-T08 · Evidence hygiene:** Check the “Readiness probe contract” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C030-T09 · Reproduction review:** Have the “Readiness probe contract” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C030-T10 · Acceptance linkage:** Link the “Readiness probe contract” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Liveness probe contract

**Source delivery:** Distinguish continued execution from readiness and correctness.

**Source invariant:** A live but stalled or incorrect guest is not declared ready.

**Source negative case:** A spinning guest remains alive while making no required progress.

**Source bounded quantities:** Probe frequency and progress-age threshold.

### UC-M05.05-C031 · Contract

**Original checklist item:** Specify liveness probe contract inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C031-T01 · Scope statement:** Draft the operation boundary for “Liveness probe contract” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Liveness probe contract”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C031-T03 · Output inventory:** List the outputs of “Liveness probe contract” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Liveness probe contract”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C031-T05 · Prerequisite contract:** Map “Liveness probe contract” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Liveness probe contract”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C031-T07 · Invariant clause:** Add a normative clause for “Liveness probe contract” that preserves “A live but stalled or incorrect guest is not declared ready”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Liveness probe contract”; include the source counterexample “A spinning guest remains alive while making no required progress” and the intended safe disposition.
- [ ] **UC-M05.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe frequency and progress-age threshold” in the “Liveness probe contract” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C031-T10 · Contract review:** Review the “Liveness probe contract” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C032 · Delivery

**Original checklist item:** Distinguish continued execution from readiness and correctness.

- [ ] **UC-M05.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Liveness probe contract”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C032-T02 · Change plan:** Break the source delivery for “Liveness probe contract” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C032-T03 · Core artifact:** Create the “Liveness probe contract” model, schema or inventory that realizes this source instruction: Distinguish continued execution from readiness and correctness.
- [ ] **UC-M05.05-C032-T04 · Concrete realization:** Populate “Liveness probe contract” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Liveness probe contract” needed to preserve “A live but stalled or incorrect guest is not declared ready”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C032-T06 · Dependency connection:** Connect the “Liveness probe contract” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C032-T07 · Resource behavior:** Account for “Probe frequency and progress-age threshold” in “Liveness probe contract”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C032-T08 · Delivery check:** Run the smallest real “Liveness probe contract” path and its adverse fixture “A spinning guest remains alive while making no required progress”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C032-T09 · Patch review:** Review the “Liveness probe contract” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C032-T10 · Delivery handoff:** Publish the “Liveness probe contract” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A live but stalled or incorrect guest is not declared ready. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Liveness probe contract”; copy its required invariant exactly: “A live but stalled or incorrect guest is not declared ready”.
- [ ] **UC-M05.05-C033-T02 · Observable terms:** Define each term in the “Liveness probe contract” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C033-T03 · Precondition set:** List the preconditions under which “A live but stalled or incorrect guest is not declared ready” must hold for “Liveness probe contract”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C033-T04 · Transition coverage:** Map the “Liveness probe contract” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Liveness probe contract”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C033-T06 · Satisfying fixture:** Create a concrete “Liveness probe contract” case that satisfies “A live but stalled or incorrect guest is not declared ready”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C033-T07 · Violating fixture:** Create the source counterexample “A spinning guest remains alive while making no required progress” for “Liveness probe contract”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C033-T08 · Enforcement evidence:** Exercise the “Liveness probe contract” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C033-T09 · Regression linkage:** Link the “Liveness probe contract” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Liveness probe contract” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C034 · Integration

**Original checklist item:** Integrate liveness probe contract with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Liveness probe contract” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C034-T02 · Field mapping:** Map every “Liveness probe contract” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Liveness probe contract” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C034-T04 · Ownership agreement:** Specify who owns “Liveness probe contract” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C034-T05 · Handoff implementation:** Connect “Liveness probe contract” through the mapped seam using the real adapter or explicit specification reference; preserve “A live but stalled or incorrect guest is not declared ready” across the handoff.
- [ ] **UC-M05.05-C034-T06 · Absent-input case:** Omit one required “Liveness probe contract” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C034-T07 · Stale-input case:** Supply an outdated “Liveness probe contract” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Liveness probe contract” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C034-T09 · Valid integration trace:** Run a valid “Liveness probe contract” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C034-T10 · Seam review:** Reconcile the “Liveness probe contract” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for liveness probe contract; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Liveness probe contract” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C035-T02 · Expected-result oracle:** Specify the “Liveness probe contract” expected result independently of the implementation output; include the property “A live but stalled or incorrect guest is not declared ready” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C035-T03 · Fixture material:** Create the concrete “Liveness probe contract” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C035-T04 · Target preparation:** Prepare the “Liveness probe contract” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C035-T05 · Initial-state record:** Record the initial “Liveness probe contract” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C035-T06 · Valid-path execution:** Execute the “Liveness probe contract” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C035-T07 · Outcome comparison:** Compare every declared “Liveness probe contract” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C035-T08 · State and bounds check:** Inspect the “Liveness probe contract” ownership/state effects and actual use of “Probe frequency and progress-age threshold”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C035-T09 · Repeatability check:** Repeat the same “Liveness probe contract” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C035-T10 · Positive evidence:** Attach the “Liveness probe contract” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C036 · Negative test

**Original checklist item:** Negative case: A spinning guest remains alive while making no required progress. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Liveness probe contract” source counterexample: “A spinning guest remains alive while making no required progress”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Liveness probe contract”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C036-T03 · Valid control:** Construct a valid “Liveness probe contract” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C036-T04 · Minimal adverse input:** Derive the “Liveness probe contract” adverse fixture from the control with the smallest documented change needed to reproduce “A spinning guest remains alive while making no required progress”; retain that change as reproducible data.
- [ ] **UC-M05.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Liveness probe contract”; require “A live but stalled or incorrect guest is not declared ready” and forbid a false-success verdict.
- [ ] **UC-M05.05-C036-T06 · Adverse execution:** Exercise the “Liveness probe contract” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C036-T07 · Effect inspection:** Inspect “Liveness probe contract” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C036-T08 · Refusal versus failure:** Confirm the “Liveness probe contract” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C036-T09 · Reset and retention:** Restore only the disposable “Liveness probe contract” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C036-T10 · Negative regression:** Register the “Liveness probe contract” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C037 · Change / failure test

**Original checklist item:** Exercise liveness probe contract when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C037-T01 · Scenario record:** Write the “Liveness probe contract” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “A live but stalled or incorrect guest is not declared ready”.
- [ ] **UC-M05.05-C037-T02 · Baseline capture:** Create a known-valid “Liveness probe contract” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C037-T03 · Injection map:** Locate the “Liveness probe contract” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Liveness probe contract” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C037-T05 · Controlled trigger:** Introduce the controlled “Liveness probe contract” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C037-T06 · Intermediate inspection:** Inspect the “Liveness probe contract” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Liveness probe contract”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Liveness probe contract” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C037-T09 · Repeat and compare:** Repeat the selected “Liveness probe contract” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C037-T10 · Failure evidence:** Publish the “Liveness probe contract” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C038 · Bounds

**Original checklist item:** Choose, document and test limits for probe frequency and progress-age threshold; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Liveness probe contract”: “Probe frequency and progress-age threshold”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C038-T02 · Measurement method:** Choose how to observe each “Liveness probe contract” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C038-T03 · Budget decision:** Select justified resource and input limits for “Liveness probe contract”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Liveness probe contract” cases for “Probe frequency and progress-age threshold”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Liveness probe contract” limit; preserve “A live but stalled or incorrect guest is not declared ready”.
- [ ] **UC-M05.05-C038-T06 · Normal measurement:** Run or review the normal “Liveness probe contract” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C038-T07 · At-limit measurement:** Exercise the “Liveness probe contract” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C038-T08 · Over-limit measurement:** Exercise the “Liveness probe contract” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C038-T09 · Uncovered-scope report:** List the “Liveness probe contract” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C038-T10 · Limit evidence:** Publish the selected “Liveness probe contract” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for liveness probe contract with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C039-T01 · Event inventory:** List the “Liveness probe contract” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Liveness probe contract” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C039-T03 · Failure mapping:** Map each documented “Liveness probe contract” refusal or error to a diagnostic outcome; include “A spinning guest remains alive while making no required progress” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C039-T04 · Emission path:** Add the “Liveness probe contract” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C039-T05 · Redaction check:** Test “Liveness probe contract” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C039-T06 · Output budget:** Set and exercise bounded “Liveness probe contract” message size, rate and retention compatible with “Probe frequency and progress-age threshold”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C039-T07 · Success/refusal fixtures:** Capture “Liveness probe contract” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Liveness probe contract” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C039-T09 · Operator review:** Read the “Liveness probe contract” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C039-T10 · Diagnostic evidence:** Publish redacted “Liveness probe contract” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for liveness probe contract; label unexecuted checks as untested.

- [ ] **UC-M05.05-C040-T01 · Evidence inventory:** List the “Liveness probe contract” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C040-T02 · Artifact references:** Record the exact “Liveness probe contract” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C040-T03 · Fixture references:** Attach the “Liveness probe contract” fixture IDs, input identities and oracle definition; preserve the source counterexample “A spinning guest remains alive while making no required progress” as a distinct evidence case.
- [ ] **UC-M05.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Liveness probe contract”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C040-T05 · Environment record:** Record the actual “Liveness probe contract” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C040-T06 · Expected versus observed:** Pair every “Liveness probe contract” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C040-T07 · Failure and limit records:** Attach “Liveness probe contract” change/failure and bounds evidence where required; include uncovered “Probe frequency and progress-age threshold” and unresolved violations of “A live but stalled or incorrect guest is not declared ready”.
- [ ] **UC-M05.05-C040-T08 · Evidence hygiene:** Check the “Liveness probe contract” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C040-T09 · Reproduction review:** Have the “Liveness probe contract” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C040-T10 · Acceptance linkage:** Link the “Liveness probe contract” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Completion observation

**Source delivery:** Track invocation completion separately from process lifetime.

**Source invariant:** A running service does not imply that an invocation completed.

**Source negative case:** The guest stays alive after dropping the requested work.

**Source bounded quantities:** Outstanding invocations and completion deadline.

### UC-M05.05-C041 · Contract

**Original checklist item:** Specify completion observation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C041-T01 · Scope statement:** Draft the operation boundary for “Completion observation” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Completion observation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C041-T03 · Output inventory:** List the outputs of “Completion observation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Completion observation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C041-T05 · Prerequisite contract:** Map “Completion observation” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Completion observation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C041-T07 · Invariant clause:** Add a normative clause for “Completion observation” that preserves “A running service does not imply that an invocation completed”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Completion observation”; include the source counterexample “The guest stays alive after dropping the requested work” and the intended safe disposition.
- [ ] **UC-M05.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Outstanding invocations and completion deadline” in the “Completion observation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C041-T10 · Contract review:** Review the “Completion observation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C042 · Delivery

**Original checklist item:** Track invocation completion separately from process lifetime.

- [ ] **UC-M05.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Completion observation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C042-T02 · Change plan:** Break the source delivery for “Completion observation” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Completion observation” that realizes this source instruction: Track invocation completion separately from process lifetime.
- [ ] **UC-M05.05-C042-T04 · Concrete realization:** Trace “Completion observation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Completion observation” needed to preserve “A running service does not imply that an invocation completed”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C042-T06 · Dependency connection:** Connect the “Completion observation” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C042-T07 · Resource behavior:** Account for “Outstanding invocations and completion deadline” in “Completion observation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C042-T08 · Delivery check:** Run the smallest real “Completion observation” path and its adverse fixture “The guest stays alive after dropping the requested work”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C042-T09 · Patch review:** Review the “Completion observation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C042-T10 · Delivery handoff:** Publish the “Completion observation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A running service does not imply that an invocation completed. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Completion observation”; copy its required invariant exactly: “A running service does not imply that an invocation completed”.
- [ ] **UC-M05.05-C043-T02 · Observable terms:** Define each term in the “Completion observation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C043-T03 · Precondition set:** List the preconditions under which “A running service does not imply that an invocation completed” must hold for “Completion observation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C043-T04 · Transition coverage:** Map the “Completion observation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Completion observation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C043-T06 · Satisfying fixture:** Create a concrete “Completion observation” case that satisfies “A running service does not imply that an invocation completed”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C043-T07 · Violating fixture:** Create the source counterexample “The guest stays alive after dropping the requested work” for “Completion observation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C043-T08 · Enforcement evidence:** Exercise the “Completion observation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C043-T09 · Regression linkage:** Link the “Completion observation” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Completion observation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C044 · Integration

**Original checklist item:** Integrate completion observation with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Completion observation” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C044-T02 · Field mapping:** Map every “Completion observation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Completion observation” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C044-T04 · Ownership agreement:** Specify who owns “Completion observation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C044-T05 · Handoff implementation:** Connect “Completion observation” through the mapped seam using the real adapter or explicit specification reference; preserve “A running service does not imply that an invocation completed” across the handoff.
- [ ] **UC-M05.05-C044-T06 · Absent-input case:** Omit one required “Completion observation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C044-T07 · Stale-input case:** Supply an outdated “Completion observation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Completion observation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C044-T09 · Valid integration trace:** Run a valid “Completion observation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C044-T10 · Seam review:** Reconcile the “Completion observation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for completion observation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Completion observation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C045-T02 · Expected-result oracle:** Specify the “Completion observation” expected result independently of the implementation output; include the property “A running service does not imply that an invocation completed” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C045-T03 · Fixture material:** Create the concrete “Completion observation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C045-T04 · Target preparation:** Prepare the “Completion observation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C045-T05 · Initial-state record:** Record the initial “Completion observation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C045-T06 · Valid-path execution:** Execute the “Completion observation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C045-T07 · Outcome comparison:** Compare every declared “Completion observation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C045-T08 · State and bounds check:** Inspect the “Completion observation” ownership/state effects and actual use of “Outstanding invocations and completion deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C045-T09 · Repeatability check:** Repeat the same “Completion observation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C045-T10 · Positive evidence:** Attach the “Completion observation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C046 · Negative test

**Original checklist item:** Negative case: The guest stays alive after dropping the requested work. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Completion observation” source counterexample: “The guest stays alive after dropping the requested work”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Completion observation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C046-T03 · Valid control:** Construct a valid “Completion observation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C046-T04 · Minimal adverse input:** Derive the “Completion observation” adverse fixture from the control with the smallest documented change needed to reproduce “The guest stays alive after dropping the requested work”; retain that change as reproducible data.
- [ ] **UC-M05.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Completion observation”; require “A running service does not imply that an invocation completed” and forbid a false-success verdict.
- [ ] **UC-M05.05-C046-T06 · Adverse execution:** Exercise the “Completion observation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C046-T07 · Effect inspection:** Inspect “Completion observation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C046-T08 · Refusal versus failure:** Confirm the “Completion observation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C046-T09 · Reset and retention:** Restore only the disposable “Completion observation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C046-T10 · Negative regression:** Register the “Completion observation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C047 · Change / failure test

**Original checklist item:** Exercise completion observation when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C047-T01 · Scenario record:** Write the “Completion observation” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “A running service does not imply that an invocation completed”.
- [ ] **UC-M05.05-C047-T02 · Baseline capture:** Create a known-valid “Completion observation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C047-T03 · Injection map:** Locate the “Completion observation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Completion observation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C047-T05 · Controlled trigger:** Introduce the controlled “Completion observation” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C047-T06 · Intermediate inspection:** Inspect the “Completion observation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Completion observation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Completion observation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C047-T09 · Repeat and compare:** Repeat the selected “Completion observation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C047-T10 · Failure evidence:** Publish the “Completion observation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C048 · Bounds

**Original checklist item:** Choose, document and test limits for outstanding invocations and completion deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Completion observation”: “Outstanding invocations and completion deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C048-T02 · Measurement method:** Choose how to observe each “Completion observation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C048-T03 · Budget decision:** Select justified resource and input limits for “Completion observation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Completion observation” cases for “Outstanding invocations and completion deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Completion observation” limit; preserve “A running service does not imply that an invocation completed”.
- [ ] **UC-M05.05-C048-T06 · Normal measurement:** Run or review the normal “Completion observation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C048-T07 · At-limit measurement:** Exercise the “Completion observation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C048-T08 · Over-limit measurement:** Exercise the “Completion observation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C048-T09 · Uncovered-scope report:** List the “Completion observation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C048-T10 · Limit evidence:** Publish the selected “Completion observation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for completion observation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C049-T01 · Event inventory:** List the “Completion observation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Completion observation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C049-T03 · Failure mapping:** Map each documented “Completion observation” refusal or error to a diagnostic outcome; include “The guest stays alive after dropping the requested work” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C049-T04 · Emission path:** Add the “Completion observation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C049-T05 · Redaction check:** Test “Completion observation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C049-T06 · Output budget:** Set and exercise bounded “Completion observation” message size, rate and retention compatible with “Outstanding invocations and completion deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C049-T07 · Success/refusal fixtures:** Capture “Completion observation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Completion observation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C049-T09 · Operator review:** Read the “Completion observation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C049-T10 · Diagnostic evidence:** Publish redacted “Completion observation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for completion observation; label unexecuted checks as untested.

- [ ] **UC-M05.05-C050-T01 · Evidence inventory:** List the “Completion observation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C050-T02 · Artifact references:** Record the exact “Completion observation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C050-T03 · Fixture references:** Attach the “Completion observation” fixture IDs, input identities and oracle definition; preserve the source counterexample “The guest stays alive after dropping the requested work” as a distinct evidence case.
- [ ] **UC-M05.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Completion observation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C050-T05 · Environment record:** Record the actual “Completion observation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C050-T06 · Expected versus observed:** Pair every “Completion observation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C050-T07 · Failure and limit records:** Attach “Completion observation” change/failure and bounds evidence where required; include uncovered “Outstanding invocations and completion deadline” and unresolved violations of “A running service does not imply that an invocation completed”.
- [ ] **UC-M05.05-C050-T08 · Evidence hygiene:** Check the “Completion observation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C050-T09 · Reproduction review:** Have the “Completion observation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C050-T10 · Acceptance linkage:** Link the “Completion observation” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Semantic output gate

**Source delivery:** Evaluate actual application results using the declared semantic oracle.

**Source invariant:** Correctness is not inferred from a heartbeat or witness alone.

**Source negative case:** A guest is responsive but returns the wrong application output.

**Source bounded quantities:** Output bytes and oracle runtime.

### UC-M05.05-C051 · Contract

**Original checklist item:** Specify semantic output gate inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C051-T01 · Scope statement:** Draft the operation boundary for “Semantic output gate” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Semantic output gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C051-T03 · Output inventory:** List the outputs of “Semantic output gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Semantic output gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C051-T05 · Prerequisite contract:** Map “Semantic output gate” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Semantic output gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C051-T07 · Invariant clause:** Add a normative clause for “Semantic output gate” that preserves “Correctness is not inferred from a heartbeat or witness alone”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Semantic output gate”; include the source counterexample “A guest is responsive but returns the wrong application output” and the intended safe disposition.
- [ ] **UC-M05.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Output bytes and oracle runtime” in the “Semantic output gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C051-T10 · Contract review:** Review the “Semantic output gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C052 · Delivery

**Original checklist item:** Evaluate actual application results using the declared semantic oracle.

- [ ] **UC-M05.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Semantic output gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C052-T02 · Change plan:** Break the source delivery for “Semantic output gate” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Semantic output gate” that realizes this source instruction: Evaluate actual application results using the declared semantic oracle.
- [ ] **UC-M05.05-C052-T04 · Concrete realization:** Trace “Semantic output gate” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Semantic output gate” needed to preserve “Correctness is not inferred from a heartbeat or witness alone”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C052-T06 · Dependency connection:** Connect the “Semantic output gate” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C052-T07 · Resource behavior:** Account for “Output bytes and oracle runtime” in “Semantic output gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C052-T08 · Delivery check:** Run the smallest real “Semantic output gate” path and its adverse fixture “A guest is responsive but returns the wrong application output”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C052-T09 · Patch review:** Review the “Semantic output gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C052-T10 · Delivery handoff:** Publish the “Semantic output gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Correctness is not inferred from a heartbeat or witness alone. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Semantic output gate”; copy its required invariant exactly: “Correctness is not inferred from a heartbeat or witness alone”.
- [ ] **UC-M05.05-C053-T02 · Observable terms:** Define each term in the “Semantic output gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C053-T03 · Precondition set:** List the preconditions under which “Correctness is not inferred from a heartbeat or witness alone” must hold for “Semantic output gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C053-T04 · Transition coverage:** Map the “Semantic output gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Semantic output gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C053-T06 · Satisfying fixture:** Create a concrete “Semantic output gate” case that satisfies “Correctness is not inferred from a heartbeat or witness alone”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C053-T07 · Violating fixture:** Create the source counterexample “A guest is responsive but returns the wrong application output” for “Semantic output gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C053-T08 · Enforcement evidence:** Exercise the “Semantic output gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C053-T09 · Regression linkage:** Link the “Semantic output gate” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Semantic output gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C054 · Integration

**Original checklist item:** Integrate semantic output gate with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Semantic output gate” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C054-T02 · Field mapping:** Map every “Semantic output gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Semantic output gate” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C054-T04 · Ownership agreement:** Specify who owns “Semantic output gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C054-T05 · Handoff implementation:** Connect “Semantic output gate” through the mapped seam using the real adapter or explicit specification reference; preserve “Correctness is not inferred from a heartbeat or witness alone” across the handoff.
- [ ] **UC-M05.05-C054-T06 · Absent-input case:** Omit one required “Semantic output gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C054-T07 · Stale-input case:** Supply an outdated “Semantic output gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Semantic output gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C054-T09 · Valid integration trace:** Run a valid “Semantic output gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C054-T10 · Seam review:** Reconcile the “Semantic output gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for semantic output gate; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Semantic output gate” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C055-T02 · Expected-result oracle:** Specify the “Semantic output gate” expected result independently of the implementation output; include the property “Correctness is not inferred from a heartbeat or witness alone” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C055-T03 · Fixture material:** Create the concrete “Semantic output gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C055-T04 · Target preparation:** Prepare the “Semantic output gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C055-T05 · Initial-state record:** Record the initial “Semantic output gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C055-T06 · Valid-path execution:** Execute the “Semantic output gate” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C055-T07 · Outcome comparison:** Compare every declared “Semantic output gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C055-T08 · State and bounds check:** Inspect the “Semantic output gate” ownership/state effects and actual use of “Output bytes and oracle runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C055-T09 · Repeatability check:** Repeat the same “Semantic output gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C055-T10 · Positive evidence:** Attach the “Semantic output gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C056 · Negative test

**Original checklist item:** Negative case: A guest is responsive but returns the wrong application output. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Semantic output gate” source counterexample: “A guest is responsive but returns the wrong application output”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Semantic output gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C056-T03 · Valid control:** Construct a valid “Semantic output gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C056-T04 · Minimal adverse input:** Derive the “Semantic output gate” adverse fixture from the control with the smallest documented change needed to reproduce “A guest is responsive but returns the wrong application output”; retain that change as reproducible data.
- [ ] **UC-M05.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Semantic output gate”; require “Correctness is not inferred from a heartbeat or witness alone” and forbid a false-success verdict.
- [ ] **UC-M05.05-C056-T06 · Adverse execution:** Exercise the “Semantic output gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C056-T07 · Effect inspection:** Inspect “Semantic output gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C056-T08 · Refusal versus failure:** Confirm the “Semantic output gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C056-T09 · Reset and retention:** Restore only the disposable “Semantic output gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C056-T10 · Negative regression:** Register the “Semantic output gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C057 · Change / failure test

**Original checklist item:** Exercise semantic output gate when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C057-T01 · Scenario record:** Write the “Semantic output gate” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “Correctness is not inferred from a heartbeat or witness alone”.
- [ ] **UC-M05.05-C057-T02 · Baseline capture:** Create a known-valid “Semantic output gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C057-T03 · Injection map:** Locate the “Semantic output gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Semantic output gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C057-T05 · Controlled trigger:** Introduce the controlled “Semantic output gate” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C057-T06 · Intermediate inspection:** Inspect the “Semantic output gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Semantic output gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Semantic output gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C057-T09 · Repeat and compare:** Repeat the selected “Semantic output gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C057-T10 · Failure evidence:** Publish the “Semantic output gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C058 · Bounds

**Original checklist item:** Choose, document and test limits for output bytes and oracle runtime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Semantic output gate”: “Output bytes and oracle runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C058-T02 · Measurement method:** Choose how to observe each “Semantic output gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C058-T03 · Budget decision:** Select justified resource and input limits for “Semantic output gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Semantic output gate” cases for “Output bytes and oracle runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Semantic output gate” limit; preserve “Correctness is not inferred from a heartbeat or witness alone”.
- [ ] **UC-M05.05-C058-T06 · Normal measurement:** Run or review the normal “Semantic output gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C058-T07 · At-limit measurement:** Exercise the “Semantic output gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C058-T08 · Over-limit measurement:** Exercise the “Semantic output gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C058-T09 · Uncovered-scope report:** List the “Semantic output gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C058-T10 · Limit evidence:** Publish the selected “Semantic output gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for semantic output gate with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C059-T01 · Event inventory:** List the “Semantic output gate” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Semantic output gate” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C059-T03 · Failure mapping:** Map each documented “Semantic output gate” refusal or error to a diagnostic outcome; include “A guest is responsive but returns the wrong application output” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C059-T04 · Emission path:** Add the “Semantic output gate” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C059-T05 · Redaction check:** Test “Semantic output gate” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C059-T06 · Output budget:** Set and exercise bounded “Semantic output gate” message size, rate and retention compatible with “Output bytes and oracle runtime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C059-T07 · Success/refusal fixtures:** Capture “Semantic output gate” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Semantic output gate” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C059-T09 · Operator review:** Read the “Semantic output gate” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C059-T10 · Diagnostic evidence:** Publish redacted “Semantic output gate” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for semantic output gate; label unexecuted checks as untested.

- [ ] **UC-M05.05-C060-T01 · Evidence inventory:** List the “Semantic output gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C060-T02 · Artifact references:** Record the exact “Semantic output gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C060-T03 · Fixture references:** Attach the “Semantic output gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest is responsive but returns the wrong application output” as a distinct evidence case.
- [ ] **UC-M05.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Semantic output gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C060-T05 · Environment record:** Record the actual “Semantic output gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C060-T06 · Expected versus observed:** Pair every “Semantic output gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C060-T07 · Failure and limit records:** Attach “Semantic output gate” change/failure and bounds evidence where required; include uncovered “Output bytes and oracle runtime” and unresolved violations of “Correctness is not inferred from a heartbeat or witness alone”.
- [ ] **UC-M05.05-C060-T08 · Evidence hygiene:** Check the “Semantic output gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C060-T09 · Reproduction review:** Have the “Semantic output gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C060-T10 · Acceptance linkage:** Link the “Semantic output gate” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Probe resource limits

**Source delivery:** Bound probe execution, payload, retries and retained diagnostics.

**Source invariant:** Health checking cannot become an unbounded workload.

**Source negative case:** A guest streams an unlimited readiness response.

**Source bounded quantities:** Probe bytes, retries and concurrent probes.

### UC-M05.05-C061 · Contract

**Original checklist item:** Specify probe resource limits inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C061-T01 · Scope statement:** Draft the operation boundary for “Probe resource limits” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Probe resource limits”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C061-T03 · Output inventory:** List the outputs of “Probe resource limits” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Probe resource limits”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C061-T05 · Prerequisite contract:** Map “Probe resource limits” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Probe resource limits”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C061-T07 · Invariant clause:** Add a normative clause for “Probe resource limits” that preserves “Health checking cannot become an unbounded workload”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Probe resource limits”; include the source counterexample “A guest streams an unlimited readiness response” and the intended safe disposition.
- [ ] **UC-M05.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe bytes, retries and concurrent probes” in the “Probe resource limits” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C061-T10 · Contract review:** Review the “Probe resource limits” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C062 · Delivery

**Original checklist item:** Bound probe execution, payload, retries and retained diagnostics.

- [ ] **UC-M05.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Probe resource limits”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C062-T02 · Change plan:** Break the source delivery for “Probe resource limits” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Probe resource limits” that realizes this source instruction: Bound probe execution, payload, retries and retained diagnostics.
- [ ] **UC-M05.05-C062-T04 · Concrete realization:** Trace “Probe resource limits” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Probe resource limits” needed to preserve “Health checking cannot become an unbounded workload”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C062-T06 · Dependency connection:** Connect the “Probe resource limits” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C062-T07 · Resource behavior:** Account for “Probe bytes, retries and concurrent probes” in “Probe resource limits”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C062-T08 · Delivery check:** Run the smallest real “Probe resource limits” path and its adverse fixture “A guest streams an unlimited readiness response”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C062-T09 · Patch review:** Review the “Probe resource limits” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C062-T10 · Delivery handoff:** Publish the “Probe resource limits” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Health checking cannot become an unbounded workload. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Probe resource limits”; copy its required invariant exactly: “Health checking cannot become an unbounded workload”.
- [ ] **UC-M05.05-C063-T02 · Observable terms:** Define each term in the “Probe resource limits” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C063-T03 · Precondition set:** List the preconditions under which “Health checking cannot become an unbounded workload” must hold for “Probe resource limits”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C063-T04 · Transition coverage:** Map the “Probe resource limits” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Probe resource limits”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C063-T06 · Satisfying fixture:** Create a concrete “Probe resource limits” case that satisfies “Health checking cannot become an unbounded workload”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C063-T07 · Violating fixture:** Create the source counterexample “A guest streams an unlimited readiness response” for “Probe resource limits”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C063-T08 · Enforcement evidence:** Exercise the “Probe resource limits” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C063-T09 · Regression linkage:** Link the “Probe resource limits” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Probe resource limits” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C064 · Integration

**Original checklist item:** Integrate probe resource limits with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Probe resource limits” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C064-T02 · Field mapping:** Map every “Probe resource limits” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Probe resource limits” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C064-T04 · Ownership agreement:** Specify who owns “Probe resource limits” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C064-T05 · Handoff implementation:** Connect “Probe resource limits” through the mapped seam using the real adapter or explicit specification reference; preserve “Health checking cannot become an unbounded workload” across the handoff.
- [ ] **UC-M05.05-C064-T06 · Absent-input case:** Omit one required “Probe resource limits” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C064-T07 · Stale-input case:** Supply an outdated “Probe resource limits” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Probe resource limits” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C064-T09 · Valid integration trace:** Run a valid “Probe resource limits” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C064-T10 · Seam review:** Reconcile the “Probe resource limits” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for probe resource limits; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Probe resource limits” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C065-T02 · Expected-result oracle:** Specify the “Probe resource limits” expected result independently of the implementation output; include the property “Health checking cannot become an unbounded workload” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C065-T03 · Fixture material:** Create the concrete “Probe resource limits” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C065-T04 · Target preparation:** Prepare the “Probe resource limits” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C065-T05 · Initial-state record:** Record the initial “Probe resource limits” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C065-T06 · Valid-path execution:** Execute the “Probe resource limits” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C065-T07 · Outcome comparison:** Compare every declared “Probe resource limits” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C065-T08 · State and bounds check:** Inspect the “Probe resource limits” ownership/state effects and actual use of “Probe bytes, retries and concurrent probes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C065-T09 · Repeatability check:** Repeat the same “Probe resource limits” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C065-T10 · Positive evidence:** Attach the “Probe resource limits” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C066 · Negative test

**Original checklist item:** Negative case: A guest streams an unlimited readiness response. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Probe resource limits” source counterexample: “A guest streams an unlimited readiness response”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Probe resource limits”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C066-T03 · Valid control:** Construct a valid “Probe resource limits” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C066-T04 · Minimal adverse input:** Derive the “Probe resource limits” adverse fixture from the control with the smallest documented change needed to reproduce “A guest streams an unlimited readiness response”; retain that change as reproducible data.
- [ ] **UC-M05.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Probe resource limits”; require “Health checking cannot become an unbounded workload” and forbid a false-success verdict.
- [ ] **UC-M05.05-C066-T06 · Adverse execution:** Exercise the “Probe resource limits” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C066-T07 · Effect inspection:** Inspect “Probe resource limits” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C066-T08 · Refusal versus failure:** Confirm the “Probe resource limits” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C066-T09 · Reset and retention:** Restore only the disposable “Probe resource limits” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C066-T10 · Negative regression:** Register the “Probe resource limits” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C067 · Change / failure test

**Original checklist item:** Exercise probe resource limits when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C067-T01 · Scenario record:** Write the “Probe resource limits” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “Health checking cannot become an unbounded workload”.
- [ ] **UC-M05.05-C067-T02 · Baseline capture:** Create a known-valid “Probe resource limits” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C067-T03 · Injection map:** Locate the “Probe resource limits” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Probe resource limits” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C067-T05 · Controlled trigger:** Introduce the controlled “Probe resource limits” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C067-T06 · Intermediate inspection:** Inspect the “Probe resource limits” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Probe resource limits”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Probe resource limits” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C067-T09 · Repeat and compare:** Repeat the selected “Probe resource limits” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C067-T10 · Failure evidence:** Publish the “Probe resource limits” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C068 · Bounds

**Original checklist item:** Choose, document and test limits for probe bytes, retries and concurrent probes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Probe resource limits”: “Probe bytes, retries and concurrent probes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C068-T02 · Measurement method:** Choose how to observe each “Probe resource limits” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C068-T03 · Budget decision:** Select justified resource and input limits for “Probe resource limits”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Probe resource limits” cases for “Probe bytes, retries and concurrent probes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Probe resource limits” limit; preserve “Health checking cannot become an unbounded workload”.
- [ ] **UC-M05.05-C068-T06 · Normal measurement:** Run or review the normal “Probe resource limits” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C068-T07 · At-limit measurement:** Exercise the “Probe resource limits” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C068-T08 · Over-limit measurement:** Exercise the “Probe resource limits” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C068-T09 · Uncovered-scope report:** List the “Probe resource limits” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C068-T10 · Limit evidence:** Publish the selected “Probe resource limits” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for probe resource limits with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C069-T01 · Event inventory:** List the “Probe resource limits” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Probe resource limits” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C069-T03 · Failure mapping:** Map each documented “Probe resource limits” refusal or error to a diagnostic outcome; include “A guest streams an unlimited readiness response” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C069-T04 · Emission path:** Add the “Probe resource limits” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C069-T05 · Redaction check:** Test “Probe resource limits” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C069-T06 · Output budget:** Set and exercise bounded “Probe resource limits” message size, rate and retention compatible with “Probe bytes, retries and concurrent probes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C069-T07 · Success/refusal fixtures:** Capture “Probe resource limits” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Probe resource limits” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C069-T09 · Operator review:** Read the “Probe resource limits” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C069-T10 · Diagnostic evidence:** Publish redacted “Probe resource limits” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for probe resource limits; label unexecuted checks as untested.

- [ ] **UC-M05.05-C070-T01 · Evidence inventory:** List the “Probe resource limits” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C070-T02 · Artifact references:** Record the exact “Probe resource limits” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C070-T03 · Fixture references:** Attach the “Probe resource limits” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest streams an unlimited readiness response” as a distinct evidence case.
- [ ] **UC-M05.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Probe resource limits”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C070-T05 · Environment record:** Record the actual “Probe resource limits” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C070-T06 · Expected versus observed:** Pair every “Probe resource limits” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C070-T07 · Failure and limit records:** Attach “Probe resource limits” change/failure and bounds evidence where required; include uncovered “Probe bytes, retries and concurrent probes” and unresolved violations of “Health checking cannot become an unbounded workload”.
- [ ] **UC-M05.05-C070-T08 · Evidence hygiene:** Check the “Probe resource limits” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C070-T09 · Reproduction review:** Have the “Probe resource limits” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C070-T10 · Acceptance linkage:** Link the “Probe resource limits” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Stale observation handling

**Source delivery:** Expire or mark health observations when their freshness guarantee is exceeded.

**Source invariant:** Old success cannot keep a stopped workload healthy.

**Source negative case:** The last successful probe remains green after the guest stops.

**Source bounded quantities:** Maximum observation age and refresh interval.

### UC-M05.05-C071 · Contract

**Original checklist item:** Specify stale observation handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C071-T01 · Scope statement:** Draft the operation boundary for “Stale observation handling” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Stale observation handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C071-T03 · Output inventory:** List the outputs of “Stale observation handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Stale observation handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C071-T05 · Prerequisite contract:** Map “Stale observation handling” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Stale observation handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C071-T07 · Invariant clause:** Add a normative clause for “Stale observation handling” that preserves “Old success cannot keep a stopped workload healthy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Stale observation handling”; include the source counterexample “The last successful probe remains green after the guest stops” and the intended safe disposition.
- [ ] **UC-M05.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Maximum observation age and refresh interval” in the “Stale observation handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C071-T10 · Contract review:** Review the “Stale observation handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C072 · Delivery

**Original checklist item:** Expire or mark health observations when their freshness guarantee is exceeded.

- [ ] **UC-M05.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Stale observation handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C072-T02 · Change plan:** Break the source delivery for “Stale observation handling” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Stale observation handling” that realizes this source instruction: Expire or mark health observations when their freshness guarantee is exceeded.
- [ ] **UC-M05.05-C072-T04 · Concrete realization:** Trace “Stale observation handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Stale observation handling” needed to preserve “Old success cannot keep a stopped workload healthy”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C072-T06 · Dependency connection:** Connect the “Stale observation handling” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C072-T07 · Resource behavior:** Account for “Maximum observation age and refresh interval” in “Stale observation handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C072-T08 · Delivery check:** Run the smallest real “Stale observation handling” path and its adverse fixture “The last successful probe remains green after the guest stops”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C072-T09 · Patch review:** Review the “Stale observation handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C072-T10 · Delivery handoff:** Publish the “Stale observation handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Old success cannot keep a stopped workload healthy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Stale observation handling”; copy its required invariant exactly: “Old success cannot keep a stopped workload healthy”.
- [ ] **UC-M05.05-C073-T02 · Observable terms:** Define each term in the “Stale observation handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C073-T03 · Precondition set:** List the preconditions under which “Old success cannot keep a stopped workload healthy” must hold for “Stale observation handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C073-T04 · Transition coverage:** Map the “Stale observation handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Stale observation handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C073-T06 · Satisfying fixture:** Create a concrete “Stale observation handling” case that satisfies “Old success cannot keep a stopped workload healthy”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C073-T07 · Violating fixture:** Create the source counterexample “The last successful probe remains green after the guest stops” for “Stale observation handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C073-T08 · Enforcement evidence:** Exercise the “Stale observation handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C073-T09 · Regression linkage:** Link the “Stale observation handling” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Stale observation handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C074 · Integration

**Original checklist item:** Integrate stale observation handling with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Stale observation handling” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C074-T02 · Field mapping:** Map every “Stale observation handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Stale observation handling” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C074-T04 · Ownership agreement:** Specify who owns “Stale observation handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C074-T05 · Handoff implementation:** Connect “Stale observation handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Old success cannot keep a stopped workload healthy” across the handoff.
- [ ] **UC-M05.05-C074-T06 · Absent-input case:** Omit one required “Stale observation handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C074-T07 · Stale-input case:** Supply an outdated “Stale observation handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Stale observation handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C074-T09 · Valid integration trace:** Run a valid “Stale observation handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C074-T10 · Seam review:** Reconcile the “Stale observation handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for stale observation handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Stale observation handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C075-T02 · Expected-result oracle:** Specify the “Stale observation handling” expected result independently of the implementation output; include the property “Old success cannot keep a stopped workload healthy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C075-T03 · Fixture material:** Create the concrete “Stale observation handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C075-T04 · Target preparation:** Prepare the “Stale observation handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C075-T05 · Initial-state record:** Record the initial “Stale observation handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C075-T06 · Valid-path execution:** Execute the “Stale observation handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C075-T07 · Outcome comparison:** Compare every declared “Stale observation handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C075-T08 · State and bounds check:** Inspect the “Stale observation handling” ownership/state effects and actual use of “Maximum observation age and refresh interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C075-T09 · Repeatability check:** Repeat the same “Stale observation handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C075-T10 · Positive evidence:** Attach the “Stale observation handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C076 · Negative test

**Original checklist item:** Negative case: The last successful probe remains green after the guest stops. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Stale observation handling” source counterexample: “The last successful probe remains green after the guest stops”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Stale observation handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C076-T03 · Valid control:** Construct a valid “Stale observation handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C076-T04 · Minimal adverse input:** Derive the “Stale observation handling” adverse fixture from the control with the smallest documented change needed to reproduce “The last successful probe remains green after the guest stops”; retain that change as reproducible data.
- [ ] **UC-M05.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Stale observation handling”; require “Old success cannot keep a stopped workload healthy” and forbid a false-success verdict.
- [ ] **UC-M05.05-C076-T06 · Adverse execution:** Exercise the “Stale observation handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C076-T07 · Effect inspection:** Inspect “Stale observation handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C076-T08 · Refusal versus failure:** Confirm the “Stale observation handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C076-T09 · Reset and retention:** Restore only the disposable “Stale observation handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C076-T10 · Negative regression:** Register the “Stale observation handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C077 · Change / failure test

**Original checklist item:** Exercise stale observation handling when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C077-T01 · Scenario record:** Write the “Stale observation handling” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “Old success cannot keep a stopped workload healthy”.
- [ ] **UC-M05.05-C077-T02 · Baseline capture:** Create a known-valid “Stale observation handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C077-T03 · Injection map:** Locate the “Stale observation handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Stale observation handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C077-T05 · Controlled trigger:** Introduce the controlled “Stale observation handling” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C077-T06 · Intermediate inspection:** Inspect the “Stale observation handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Stale observation handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Stale observation handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C077-T09 · Repeat and compare:** Repeat the selected “Stale observation handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C077-T10 · Failure evidence:** Publish the “Stale observation handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C078 · Bounds

**Original checklist item:** Choose, document and test limits for maximum observation age and refresh interval; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Stale observation handling”: “Maximum observation age and refresh interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C078-T02 · Measurement method:** Choose how to observe each “Stale observation handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C078-T03 · Budget decision:** Select justified resource and input limits for “Stale observation handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Stale observation handling” cases for “Maximum observation age and refresh interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Stale observation handling” limit; preserve “Old success cannot keep a stopped workload healthy”.
- [ ] **UC-M05.05-C078-T06 · Normal measurement:** Run or review the normal “Stale observation handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C078-T07 · At-limit measurement:** Exercise the “Stale observation handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C078-T08 · Over-limit measurement:** Exercise the “Stale observation handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C078-T09 · Uncovered-scope report:** List the “Stale observation handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C078-T10 · Limit evidence:** Publish the selected “Stale observation handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for stale observation handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C079-T01 · Event inventory:** List the “Stale observation handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Stale observation handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C079-T03 · Failure mapping:** Map each documented “Stale observation handling” refusal or error to a diagnostic outcome; include “The last successful probe remains green after the guest stops” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C079-T04 · Emission path:** Add the “Stale observation handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C079-T05 · Redaction check:** Test “Stale observation handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C079-T06 · Output budget:** Set and exercise bounded “Stale observation handling” message size, rate and retention compatible with “Maximum observation age and refresh interval”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C079-T07 · Success/refusal fixtures:** Capture “Stale observation handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Stale observation handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C079-T09 · Operator review:** Read the “Stale observation handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C079-T10 · Diagnostic evidence:** Publish redacted “Stale observation handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for stale observation handling; label unexecuted checks as untested.

- [ ] **UC-M05.05-C080-T01 · Evidence inventory:** List the “Stale observation handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C080-T02 · Artifact references:** Record the exact “Stale observation handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C080-T03 · Fixture references:** Attach the “Stale observation handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “The last successful probe remains green after the guest stops” as a distinct evidence case.
- [ ] **UC-M05.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Stale observation handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C080-T05 · Environment record:** Record the actual “Stale observation handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C080-T06 · Expected versus observed:** Pair every “Stale observation handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C080-T07 · Failure and limit records:** Attach “Stale observation handling” change/failure and bounds evidence where required; include uncovered “Maximum observation age and refresh interval” and unresolved violations of “Old success cannot keep a stopped workload healthy”.
- [ ] **UC-M05.05-C080-T08 · Evidence hygiene:** Check the “Stale observation handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C080-T09 · Reproduction review:** Have the “Stale observation handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C080-T10 · Acceptance linkage:** Link the “Stale observation handling” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Failure escalation

**Source delivery:** Map probe failures to degraded, failed or restart-eligible states explicitly.

**Source invariant:** Probe failure cannot silently preserve a false healthy state.

**Source negative case:** Repeated readiness failures are ignored by the controller.

**Source bounded quantities:** Failure counts and escalation deadline.

### UC-M05.05-C081 · Contract

**Original checklist item:** Specify failure escalation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C081-T01 · Scope statement:** Draft the operation boundary for “Failure escalation” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure escalation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C081-T03 · Output inventory:** List the outputs of “Failure escalation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure escalation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C081-T05 · Prerequisite contract:** Map “Failure escalation” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Failure escalation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C081-T07 · Invariant clause:** Add a normative clause for “Failure escalation” that preserves “Probe failure cannot silently preserve a false healthy state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure escalation”; include the source counterexample “Repeated readiness failures are ignored by the controller” and the intended safe disposition.
- [ ] **UC-M05.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure counts and escalation deadline” in the “Failure escalation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C081-T10 · Contract review:** Review the “Failure escalation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C082 · Delivery

**Original checklist item:** Map probe failures to degraded, failed or restart-eligible states explicitly.

- [ ] **UC-M05.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure escalation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C082-T02 · Change plan:** Break the source delivery for “Failure escalation” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C082-T03 · Core artifact:** Create the “Failure escalation” model, schema or inventory that realizes this source instruction: Map probe failures to degraded, failed or restart-eligible states explicitly.
- [ ] **UC-M05.05-C082-T04 · Concrete realization:** Populate “Failure escalation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure escalation” needed to preserve “Probe failure cannot silently preserve a false healthy state”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C082-T06 · Dependency connection:** Connect the “Failure escalation” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C082-T07 · Resource behavior:** Account for “Failure counts and escalation deadline” in “Failure escalation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C082-T08 · Delivery check:** Run the smallest real “Failure escalation” path and its adverse fixture “Repeated readiness failures are ignored by the controller”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C082-T09 · Patch review:** Review the “Failure escalation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C082-T10 · Delivery handoff:** Publish the “Failure escalation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Probe failure cannot silently preserve a false healthy state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Failure escalation”; copy its required invariant exactly: “Probe failure cannot silently preserve a false healthy state”.
- [ ] **UC-M05.05-C083-T02 · Observable terms:** Define each term in the “Failure escalation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C083-T03 · Precondition set:** List the preconditions under which “Probe failure cannot silently preserve a false healthy state” must hold for “Failure escalation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C083-T04 · Transition coverage:** Map the “Failure escalation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure escalation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C083-T06 · Satisfying fixture:** Create a concrete “Failure escalation” case that satisfies “Probe failure cannot silently preserve a false healthy state”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C083-T07 · Violating fixture:** Create the source counterexample “Repeated readiness failures are ignored by the controller” for “Failure escalation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C083-T08 · Enforcement evidence:** Exercise the “Failure escalation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C083-T09 · Regression linkage:** Link the “Failure escalation” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Failure escalation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C084 · Integration

**Original checklist item:** Integrate failure escalation with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure escalation” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C084-T02 · Field mapping:** Map every “Failure escalation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure escalation” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C084-T04 · Ownership agreement:** Specify who owns “Failure escalation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C084-T05 · Handoff implementation:** Connect “Failure escalation” through the mapped seam using the real adapter or explicit specification reference; preserve “Probe failure cannot silently preserve a false healthy state” across the handoff.
- [ ] **UC-M05.05-C084-T06 · Absent-input case:** Omit one required “Failure escalation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C084-T07 · Stale-input case:** Supply an outdated “Failure escalation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Failure escalation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C084-T09 · Valid integration trace:** Run a valid “Failure escalation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C084-T10 · Seam review:** Reconcile the “Failure escalation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure escalation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure escalation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C085-T02 · Expected-result oracle:** Specify the “Failure escalation” expected result independently of the implementation output; include the property “Probe failure cannot silently preserve a false healthy state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C085-T03 · Fixture material:** Create the concrete “Failure escalation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C085-T04 · Target preparation:** Prepare the “Failure escalation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C085-T05 · Initial-state record:** Record the initial “Failure escalation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C085-T06 · Valid-path execution:** Execute the “Failure escalation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C085-T07 · Outcome comparison:** Compare every declared “Failure escalation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C085-T08 · State and bounds check:** Inspect the “Failure escalation” ownership/state effects and actual use of “Failure counts and escalation deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C085-T09 · Repeatability check:** Repeat the same “Failure escalation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C085-T10 · Positive evidence:** Attach the “Failure escalation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C086 · Negative test

**Original checklist item:** Negative case: Repeated readiness failures are ignored by the controller. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Failure escalation” source counterexample: “Repeated readiness failures are ignored by the controller”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure escalation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C086-T03 · Valid control:** Construct a valid “Failure escalation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C086-T04 · Minimal adverse input:** Derive the “Failure escalation” adverse fixture from the control with the smallest documented change needed to reproduce “Repeated readiness failures are ignored by the controller”; retain that change as reproducible data.
- [ ] **UC-M05.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure escalation”; require “Probe failure cannot silently preserve a false healthy state” and forbid a false-success verdict.
- [ ] **UC-M05.05-C086-T06 · Adverse execution:** Exercise the “Failure escalation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C086-T07 · Effect inspection:** Inspect “Failure escalation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C086-T08 · Refusal versus failure:** Confirm the “Failure escalation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C086-T09 · Reset and retention:** Restore only the disposable “Failure escalation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C086-T10 · Negative regression:** Register the “Failure escalation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C087 · Change / failure test

**Original checklist item:** Exercise failure escalation when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C087-T01 · Scenario record:** Write the “Failure escalation” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “Probe failure cannot silently preserve a false healthy state”.
- [ ] **UC-M05.05-C087-T02 · Baseline capture:** Create a known-valid “Failure escalation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C087-T03 · Injection map:** Locate the “Failure escalation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Failure escalation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C087-T05 · Controlled trigger:** Introduce the controlled “Failure escalation” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C087-T06 · Intermediate inspection:** Inspect the “Failure escalation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure escalation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure escalation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C087-T09 · Repeat and compare:** Repeat the selected “Failure escalation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C087-T10 · Failure evidence:** Publish the “Failure escalation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C088 · Bounds

**Original checklist item:** Choose, document and test limits for failure counts and escalation deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Failure escalation”: “Failure counts and escalation deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C088-T02 · Measurement method:** Choose how to observe each “Failure escalation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C088-T03 · Budget decision:** Select justified resource and input limits for “Failure escalation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure escalation” cases for “Failure counts and escalation deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure escalation” limit; preserve “Probe failure cannot silently preserve a false healthy state”.
- [ ] **UC-M05.05-C088-T06 · Normal measurement:** Run or review the normal “Failure escalation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C088-T07 · At-limit measurement:** Exercise the “Failure escalation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C088-T08 · Over-limit measurement:** Exercise the “Failure escalation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C088-T09 · Uncovered-scope report:** List the “Failure escalation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C088-T10 · Limit evidence:** Publish the selected “Failure escalation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure escalation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C089-T01 · Event inventory:** List the “Failure escalation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Failure escalation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C089-T03 · Failure mapping:** Map each documented “Failure escalation” refusal or error to a diagnostic outcome; include “Repeated readiness failures are ignored by the controller” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C089-T04 · Emission path:** Add the “Failure escalation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C089-T05 · Redaction check:** Test “Failure escalation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C089-T06 · Output budget:** Set and exercise bounded “Failure escalation” message size, rate and retention compatible with “Failure counts and escalation deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C089-T07 · Success/refusal fixtures:** Capture “Failure escalation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure escalation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C089-T09 · Operator review:** Read the “Failure escalation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C089-T10 · Diagnostic evidence:** Publish redacted “Failure escalation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure escalation; label unexecuted checks as untested.

- [ ] **UC-M05.05-C090-T01 · Evidence inventory:** List the “Failure escalation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C090-T02 · Artifact references:** Record the exact “Failure escalation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C090-T03 · Fixture references:** Attach the “Failure escalation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Repeated readiness failures are ignored by the controller” as a distinct evidence case.
- [ ] **UC-M05.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure escalation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C090-T05 · Environment record:** Record the actual “Failure escalation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C090-T06 · Expected versus observed:** Pair every “Failure escalation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C090-T07 · Failure and limit records:** Attach “Failure escalation” change/failure and bounds evidence where required; include uncovered “Failure counts and escalation deadline” and unresolved violations of “Probe failure cannot silently preserve a false healthy state”.
- [ ] **UC-M05.05-C090-T08 · Evidence hygiene:** Check the “Failure escalation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C090-T09 · Reproduction review:** Have the “Failure escalation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C090-T10 · Acceptance linkage:** Link the “Failure escalation” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Health qualification fixtures

**Source delivery:** Exercise booted-but-incorrect, stalled, stopped and successful guests.

**Source invariant:** Each fixture yields the distinct declared health and completion verdict.

**Source negative case:** One boolean health field hides all tested failure distinctions.

**Source bounded quantities:** Fixture count and observation duration.

### UC-M05.05-C091 · Contract

**Original checklist item:** Specify health qualification fixtures inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.05-C091-T01 · Scope statement:** Draft the operation boundary for “Health qualification fixtures” within Workload readiness and liveness checks; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Health qualification fixtures”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.05-C091-T03 · Output inventory:** List the outputs of “Health qualification fixtures” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Health qualification fixtures”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.05-C091-T05 · Prerequisite contract:** Map “Health qualification fixtures” to the source component prerequisites (UC-M03.06, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Health qualification fixtures”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.05-C091-T07 · Invariant clause:** Add a normative clause for “Health qualification fixtures” that preserves “Each fixture yields the distinct declared health and completion verdict”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Health qualification fixtures”; include the source counterexample “One boolean health field hides all tested failure distinctions” and the intended safe disposition.
- [ ] **UC-M05.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture count and observation duration” in the “Health qualification fixtures” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.05-C091-T10 · Contract review:** Review the “Health qualification fixtures” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.05-C092 · Delivery

**Original checklist item:** Exercise booted-but-incorrect, stalled, stopped and successful guests.

- [ ] **UC-M05.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Health qualification fixtures”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.05-C092-T02 · Change plan:** Break the source delivery for “Health qualification fixtures” into concrete edit targets and reviewable outputs; keep the UC-M05.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.05-C092-T03 · Core artifact:** Create the “Health qualification fixtures” fixture or harness for this source instruction: Exercise booted-but-incorrect, stalled, stopped and successful guests.
- [ ] **UC-M05.05-C092-T04 · Concrete realization:** Connect the “Health qualification fixtures” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Health qualification fixtures” needed to preserve “Each fixture yields the distinct declared health and completion verdict”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.05-C092-T06 · Dependency connection:** Connect the “Health qualification fixtures” implementation to guest observations, application probes and lifecycle promotion decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.05-C092-T07 · Resource behavior:** Account for “Fixture count and observation duration” in “Health qualification fixtures”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.05-C092-T08 · Delivery check:** Run the smallest real “Health qualification fixtures” path and its adverse fixture “One boolean health field hides all tested failure distinctions”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.05-C092-T09 · Patch review:** Review the “Health qualification fixtures” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.05-C092-T10 · Delivery handoff:** Publish the “Health qualification fixtures” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each fixture yields the distinct declared health and completion verdict. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Health qualification fixtures”; copy its required invariant exactly: “Each fixture yields the distinct declared health and completion verdict”.
- [ ] **UC-M05.05-C093-T02 · Observable terms:** Define each term in the “Health qualification fixtures” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.05-C093-T03 · Precondition set:** List the preconditions under which “Each fixture yields the distinct declared health and completion verdict” must hold for “Health qualification fixtures”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.05-C093-T04 · Transition coverage:** Map the “Health qualification fixtures” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Health qualification fixtures”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.05-C093-T06 · Satisfying fixture:** Create a concrete “Health qualification fixtures” case that satisfies “Each fixture yields the distinct declared health and completion verdict”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.05-C093-T07 · Violating fixture:** Create the source counterexample “One boolean health field hides all tested failure distinctions” for “Health qualification fixtures”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.05-C093-T08 · Enforcement evidence:** Exercise the “Health qualification fixtures” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.05-C093-T09 · Regression linkage:** Link the “Health qualification fixtures” property to changes in guest observations, application probes and lifecycle promotion decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Health qualification fixtures” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.05-C094 · Integration

**Original checklist item:** Integrate health qualification fixtures with guest observations, application probes and lifecycle promotion decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Health qualification fixtures” across guest observations, application probes and lifecycle promotion decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.05-C094-T02 · Field mapping:** Map every “Health qualification fixtures” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Health qualification fixtures” (source dependency list: UC-M03.06, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.05-C094-T04 · Ownership agreement:** Specify who owns “Health qualification fixtures” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.05-C094-T05 · Handoff implementation:** Connect “Health qualification fixtures” through the mapped seam using the real adapter or explicit specification reference; preserve “Each fixture yields the distinct declared health and completion verdict” across the handoff.
- [ ] **UC-M05.05-C094-T06 · Absent-input case:** Omit one required “Health qualification fixtures” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.05-C094-T07 · Stale-input case:** Supply an outdated “Health qualification fixtures” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Health qualification fixtures” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.05-C094-T09 · Valid integration trace:** Run a valid “Health qualification fixtures” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.05-C094-T10 · Seam review:** Reconcile the “Health qualification fixtures” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.05-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for health qualification fixtures; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.05-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Health qualification fixtures” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.05-C095-T02 · Expected-result oracle:** Specify the “Health qualification fixtures” expected result independently of the implementation output; include the property “Each fixture yields the distinct declared health and completion verdict” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.05-C095-T03 · Fixture material:** Create the concrete “Health qualification fixtures” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.05-C095-T04 · Target preparation:** Prepare the “Health qualification fixtures” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.05-C095-T05 · Initial-state record:** Record the initial “Health qualification fixtures” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.05-C095-T06 · Valid-path execution:** Execute the “Health qualification fixtures” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.05-C095-T07 · Outcome comparison:** Compare every declared “Health qualification fixtures” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.05-C095-T08 · State and bounds check:** Inspect the “Health qualification fixtures” ownership/state effects and actual use of “Fixture count and observation duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.05-C095-T09 · Repeatability check:** Repeat the same “Health qualification fixtures” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.05-C095-T10 · Positive evidence:** Attach the “Health qualification fixtures” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.05-C096 · Negative test

**Original checklist item:** Negative case: One boolean health field hides all tested failure distinctions. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Health qualification fixtures” source counterexample: “One boolean health field hides all tested failure distinctions”; state which precondition or invariant it challenges.
- [ ] **UC-M05.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Health qualification fixtures”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.05-C096-T03 · Valid control:** Construct a valid “Health qualification fixtures” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.05-C096-T04 · Minimal adverse input:** Derive the “Health qualification fixtures” adverse fixture from the control with the smallest documented change needed to reproduce “One boolean health field hides all tested failure distinctions”; retain that change as reproducible data.
- [ ] **UC-M05.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Health qualification fixtures”; require “Each fixture yields the distinct declared health and completion verdict” and forbid a false-success verdict.
- [ ] **UC-M05.05-C096-T06 · Adverse execution:** Exercise the “Health qualification fixtures” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.05-C096-T07 · Effect inspection:** Inspect “Health qualification fixtures” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.05-C096-T08 · Refusal versus failure:** Confirm the “Health qualification fixtures” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.05-C096-T09 · Reset and retention:** Restore only the disposable “Health qualification fixtures” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.05-C096-T10 · Negative regression:** Register the “Health qualification fixtures” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.05-C097 · Change / failure test

**Original checklist item:** Exercise health qualification fixtures when a previously ready workload stalls or stops without a fresh probe result; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.05-C097-T01 · Scenario record:** Write the “Health qualification fixtures” change/failure scenario exactly as supplied: a previously ready workload stalls or stops without a fresh probe result; identify the property that must remain true: “Each fixture yields the distinct declared health and completion verdict”.
- [ ] **UC-M05.05-C097-T02 · Baseline capture:** Create a known-valid “Health qualification fixtures” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.05-C097-T03 · Injection map:** Locate the “Health qualification fixtures” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Health qualification fixtures” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.05-C097-T05 · Controlled trigger:** Introduce the controlled “Health qualification fixtures” scenario in the disposable fixture: a previously ready workload stalls or stops without a fresh probe result; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.05-C097-T06 · Intermediate inspection:** Inspect the “Health qualification fixtures” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.05-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Health qualification fixtures”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Health qualification fixtures” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.05-C097-T09 · Repeat and compare:** Repeat the selected “Health qualification fixtures” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.05-C097-T10 · Failure evidence:** Publish the “Health qualification fixtures” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.05-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fixture count and observation duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Health qualification fixtures”: “Fixture count and observation duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.05-C098-T02 · Measurement method:** Choose how to observe each “Health qualification fixtures” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.05-C098-T03 · Budget decision:** Select justified resource and input limits for “Health qualification fixtures”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Health qualification fixtures” cases for “Fixture count and observation duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Health qualification fixtures” limit; preserve “Each fixture yields the distinct declared health and completion verdict”.
- [ ] **UC-M05.05-C098-T06 · Normal measurement:** Run or review the normal “Health qualification fixtures” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.05-C098-T07 · At-limit measurement:** Exercise the “Health qualification fixtures” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.05-C098-T08 · Over-limit measurement:** Exercise the “Health qualification fixtures” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.05-C098-T09 · Uncovered-scope report:** List the “Health qualification fixtures” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.05-C098-T10 · Limit evidence:** Publish the selected “Health qualification fixtures” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.05-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for health qualification fixtures with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.05-C099-T01 · Event inventory:** List the “Health qualification fixtures” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.05-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Health qualification fixtures” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.05-C099-T03 · Failure mapping:** Map each documented “Health qualification fixtures” refusal or error to a diagnostic outcome; include “One boolean health field hides all tested failure distinctions” and prohibit conversion into a success message.
- [ ] **UC-M05.05-C099-T04 · Emission path:** Add the “Health qualification fixtures” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.05-C099-T05 · Redaction check:** Test “Health qualification fixtures” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.05-C099-T06 · Output budget:** Set and exercise bounded “Health qualification fixtures” message size, rate and retention compatible with “Fixture count and observation duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.05-C099-T07 · Success/refusal fixtures:** Capture “Health qualification fixtures” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.05-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Health qualification fixtures” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.05-C099-T09 · Operator review:** Read the “Health qualification fixtures” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.05-C099-T10 · Diagnostic evidence:** Publish redacted “Health qualification fixtures” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for health qualification fixtures; label unexecuted checks as untested.

- [ ] **UC-M05.05-C100-T01 · Evidence inventory:** List the “Health qualification fixtures” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.05-C100-T02 · Artifact references:** Record the exact “Health qualification fixtures” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.05-C100-T03 · Fixture references:** Attach the “Health qualification fixtures” fixture IDs, input identities and oracle definition; preserve the source counterexample “One boolean health field hides all tested failure distinctions” as a distinct evidence case.
- [ ] **UC-M05.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Health qualification fixtures”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.05-C100-T05 · Environment record:** Record the actual “Health qualification fixtures” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.05-C100-T06 · Expected versus observed:** Pair every “Health qualification fixtures” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.05-C100-T07 · Failure and limit records:** Attach “Health qualification fixtures” change/failure and bounds evidence where required; include uncovered “Fixture count and observation duration” and unresolved violations of “Each fixture yields the distinct declared health and completion verdict”.
- [ ] **UC-M05.05-C100-T08 · Evidence hygiene:** Check the “Health qualification fixtures” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.05-C100-T09 · Reproduction review:** Have the “Health qualification fixtures” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.05-C100-T10 · Acceptance linkage:** Link the “Health qualification fixtures” evidence to its parent and UC-M05.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

