# UC-M05.02 — Resource-aware placement scheduler

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/05.md)

| Field | Preserved source value |
|---|---|
| Workstream | 05. Workload orchestration and scheduling |
| Milestone | C |
| Priority | P1 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M03.05](../03/UC-M03.05.md), [UC-M05.01](../05/UC-M05.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S6]. |

## Original requirement

Replace heuristic complexity-only routing with measured capacity, ISA compatibility, memory bounds and isolation requirements.

**Original acceptance criterion:** An infeasible workload is queued or refused; placement never violates a hard resource or ISA constraint.

**Source trace:** Original checklist `UC100/c/05/UC-M05.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 440–450 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Capacity inventory

**Source delivery:** Measure available CPU, memory, storage and relevant backend capacity.

**Source invariant:** Placement uses observed available capacity rather than only a complexity label.

**Source negative case:** A host appears available despite exhausted memory reservations.

**Source bounded quantities:** Capacity records and measurement freshness.

### UC-M05.02-C001 · Contract

**Original checklist item:** Specify capacity inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C001-T01 · Scope statement:** Draft the operation boundary for “Capacity inventory” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capacity inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C001-T03 · Output inventory:** List the outputs of “Capacity inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Capacity inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C001-T05 · Prerequisite contract:** Map “Capacity inventory” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Capacity inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C001-T07 · Invariant clause:** Add a normative clause for “Capacity inventory” that preserves “Placement uses observed available capacity rather than only a complexity label”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capacity inventory”; include the source counterexample “A host appears available despite exhausted memory reservations” and the intended safe disposition.
- [ ] **UC-M05.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capacity records and measurement freshness” in the “Capacity inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C001-T10 · Contract review:** Review the “Capacity inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C002 · Delivery

**Original checklist item:** Measure available CPU, memory, storage and relevant backend capacity.

- [ ] **UC-M05.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capacity inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C002-T02 · Change plan:** Break the source delivery for “Capacity inventory” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C002-T03 · Core artifact:** Create the “Capacity inventory” fixture or harness for this source instruction: Measure available CPU, memory, storage and relevant backend capacity.
- [ ] **UC-M05.02-C002-T04 · Concrete realization:** Connect the “Capacity inventory” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capacity inventory” needed to preserve “Placement uses observed available capacity rather than only a complexity label”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C002-T06 · Dependency connection:** Connect the “Capacity inventory” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C002-T07 · Resource behavior:** Account for “Capacity records and measurement freshness” in “Capacity inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C002-T08 · Delivery check:** Run the smallest real “Capacity inventory” path and its adverse fixture “A host appears available despite exhausted memory reservations”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C002-T09 · Patch review:** Review the “Capacity inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C002-T10 · Delivery handoff:** Publish the “Capacity inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Placement uses observed available capacity rather than only a complexity label. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Capacity inventory”; copy its required invariant exactly: “Placement uses observed available capacity rather than only a complexity label”.
- [ ] **UC-M05.02-C003-T02 · Observable terms:** Define each term in the “Capacity inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C003-T03 · Precondition set:** List the preconditions under which “Placement uses observed available capacity rather than only a complexity label” must hold for “Capacity inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C003-T04 · Transition coverage:** Map the “Capacity inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capacity inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C003-T06 · Satisfying fixture:** Create a concrete “Capacity inventory” case that satisfies “Placement uses observed available capacity rather than only a complexity label”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C003-T07 · Violating fixture:** Create the source counterexample “A host appears available despite exhausted memory reservations” for “Capacity inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C003-T08 · Enforcement evidence:** Exercise the “Capacity inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C003-T09 · Regression linkage:** Link the “Capacity inventory” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Capacity inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C004 · Integration

**Original checklist item:** Integrate capacity inventory with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capacity inventory” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C004-T02 · Field mapping:** Map every “Capacity inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Capacity inventory” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C004-T04 · Ownership agreement:** Specify who owns “Capacity inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C004-T05 · Handoff implementation:** Connect “Capacity inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Placement uses observed available capacity rather than only a complexity label” across the handoff.
- [ ] **UC-M05.02-C004-T06 · Absent-input case:** Omit one required “Capacity inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C004-T07 · Stale-input case:** Supply an outdated “Capacity inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Capacity inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C004-T09 · Valid integration trace:** Run a valid “Capacity inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C004-T10 · Seam review:** Reconcile the “Capacity inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capacity inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capacity inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C005-T02 · Expected-result oracle:** Specify the “Capacity inventory” expected result independently of the implementation output; include the property “Placement uses observed available capacity rather than only a complexity label” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C005-T03 · Fixture material:** Create the concrete “Capacity inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C005-T04 · Target preparation:** Prepare the “Capacity inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C005-T05 · Initial-state record:** Record the initial “Capacity inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C005-T06 · Valid-path execution:** Execute the “Capacity inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C005-T07 · Outcome comparison:** Compare every declared “Capacity inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C005-T08 · State and bounds check:** Inspect the “Capacity inventory” ownership/state effects and actual use of “Capacity records and measurement freshness”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C005-T09 · Repeatability check:** Repeat the same “Capacity inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C005-T10 · Positive evidence:** Attach the “Capacity inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C006 · Negative test

**Original checklist item:** Negative case: A host appears available despite exhausted memory reservations. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Capacity inventory” source counterexample: “A host appears available despite exhausted memory reservations”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Capacity inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C006-T03 · Valid control:** Construct a valid “Capacity inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C006-T04 · Minimal adverse input:** Derive the “Capacity inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A host appears available despite exhausted memory reservations”; retain that change as reproducible data.
- [ ] **UC-M05.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capacity inventory”; require “Placement uses observed available capacity rather than only a complexity label” and forbid a false-success verdict.
- [ ] **UC-M05.02-C006-T06 · Adverse execution:** Exercise the “Capacity inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C006-T07 · Effect inspection:** Inspect “Capacity inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C006-T08 · Refusal versus failure:** Confirm the “Capacity inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C006-T09 · Reset and retention:** Restore only the disposable “Capacity inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C006-T10 · Negative regression:** Register the “Capacity inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C007 · Change / failure test

**Original checklist item:** Exercise capacity inventory when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C007-T01 · Scenario record:** Write the “Capacity inventory” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “Placement uses observed available capacity rather than only a complexity label”.
- [ ] **UC-M05.02-C007-T02 · Baseline capture:** Create a known-valid “Capacity inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C007-T03 · Injection map:** Locate the “Capacity inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Capacity inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C007-T05 · Controlled trigger:** Introduce the controlled “Capacity inventory” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C007-T06 · Intermediate inspection:** Inspect the “Capacity inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capacity inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Capacity inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C007-T09 · Repeat and compare:** Repeat the selected “Capacity inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C007-T10 · Failure evidence:** Publish the “Capacity inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for capacity records and measurement freshness; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Capacity inventory”: “Capacity records and measurement freshness”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C008-T02 · Measurement method:** Choose how to observe each “Capacity inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C008-T03 · Budget decision:** Select justified resource and input limits for “Capacity inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capacity inventory” cases for “Capacity records and measurement freshness”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capacity inventory” limit; preserve “Placement uses observed available capacity rather than only a complexity label”.
- [ ] **UC-M05.02-C008-T06 · Normal measurement:** Run or review the normal “Capacity inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C008-T07 · At-limit measurement:** Exercise the “Capacity inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C008-T08 · Over-limit measurement:** Exercise the “Capacity inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C008-T09 · Uncovered-scope report:** List the “Capacity inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C008-T10 · Limit evidence:** Publish the selected “Capacity inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capacity inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C009-T01 · Event inventory:** List the “Capacity inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Capacity inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C009-T03 · Failure mapping:** Map each documented “Capacity inventory” refusal or error to a diagnostic outcome; include “A host appears available despite exhausted memory reservations” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C009-T04 · Emission path:** Add the “Capacity inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C009-T05 · Redaction check:** Test “Capacity inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C009-T06 · Output budget:** Set and exercise bounded “Capacity inventory” message size, rate and retention compatible with “Capacity records and measurement freshness”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C009-T07 · Success/refusal fixtures:** Capture “Capacity inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capacity inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C009-T09 · Operator review:** Read the “Capacity inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C009-T10 · Diagnostic evidence:** Publish redacted “Capacity inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capacity inventory; label unexecuted checks as untested.

- [ ] **UC-M05.02-C010-T01 · Evidence inventory:** List the “Capacity inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C010-T02 · Artifact references:** Record the exact “Capacity inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C010-T03 · Fixture references:** Attach the “Capacity inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host appears available despite exhausted memory reservations” as a distinct evidence case.
- [ ] **UC-M05.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capacity inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C010-T05 · Environment record:** Record the actual “Capacity inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C010-T06 · Expected versus observed:** Pair every “Capacity inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C010-T07 · Failure and limit records:** Attach “Capacity inventory” change/failure and bounds evidence where required; include uncovered “Capacity records and measurement freshness” and unresolved violations of “Placement uses observed available capacity rather than only a complexity label”.
- [ ] **UC-M05.02-C010-T08 · Evidence hygiene:** Check the “Capacity inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C010-T09 · Reproduction review:** Have the “Capacity inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C010-T10 · Acceptance linkage:** Link the “Capacity inventory” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. ISA compatibility

**Source delivery:** Match workload instruction-set and guest architecture requirements to candidate backends.

**Source invariant:** An incompatible ISA is a hard placement refusal.

**Source negative case:** An image is routed to a backend for a different architecture.

**Source bounded quantities:** Architecture matrix and candidate count.

### UC-M05.02-C011 · Contract

**Original checklist item:** Specify ISA compatibility inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C011-T01 · Scope statement:** Draft the operation boundary for “ISA compatibility” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “ISA compatibility”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C011-T03 · Output inventory:** List the outputs of “ISA compatibility” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “ISA compatibility”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C011-T05 · Prerequisite contract:** Map “ISA compatibility” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C011-T06 · Authority map:** Identify who may produce, change and consume “ISA compatibility”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C011-T07 · Invariant clause:** Add a normative clause for “ISA compatibility” that preserves “An incompatible ISA is a hard placement refusal”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “ISA compatibility”; include the source counterexample “An image is routed to a backend for a different architecture” and the intended safe disposition.
- [ ] **UC-M05.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Architecture matrix and candidate count” in the “ISA compatibility” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C011-T10 · Contract review:** Review the “ISA compatibility” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C012 · Delivery

**Original checklist item:** Match workload instruction-set and guest architecture requirements to candidate backends.

- [ ] **UC-M05.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “ISA compatibility”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C012-T02 · Change plan:** Break the source delivery for “ISA compatibility” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “ISA compatibility” that realizes this source instruction: Match workload instruction-set and guest architecture requirements to candidate backends.
- [ ] **UC-M05.02-C012-T04 · Concrete realization:** Trace “ISA compatibility” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “ISA compatibility” needed to preserve “An incompatible ISA is a hard placement refusal”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C012-T06 · Dependency connection:** Connect the “ISA compatibility” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C012-T07 · Resource behavior:** Account for “Architecture matrix and candidate count” in “ISA compatibility”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C012-T08 · Delivery check:** Run the smallest real “ISA compatibility” path and its adverse fixture “An image is routed to a backend for a different architecture”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C012-T09 · Patch review:** Review the “ISA compatibility” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C012-T10 · Delivery handoff:** Publish the “ISA compatibility” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An incompatible ISA is a hard placement refusal. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “ISA compatibility”; copy its required invariant exactly: “An incompatible ISA is a hard placement refusal”.
- [ ] **UC-M05.02-C013-T02 · Observable terms:** Define each term in the “ISA compatibility” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C013-T03 · Precondition set:** List the preconditions under which “An incompatible ISA is a hard placement refusal” must hold for “ISA compatibility”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C013-T04 · Transition coverage:** Map the “ISA compatibility” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “ISA compatibility”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C013-T06 · Satisfying fixture:** Create a concrete “ISA compatibility” case that satisfies “An incompatible ISA is a hard placement refusal”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C013-T07 · Violating fixture:** Create the source counterexample “An image is routed to a backend for a different architecture” for “ISA compatibility”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C013-T08 · Enforcement evidence:** Exercise the “ISA compatibility” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C013-T09 · Regression linkage:** Link the “ISA compatibility” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C013-T10 · Property disposition:** Compare the satisfying and violating “ISA compatibility” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C014 · Integration

**Original checklist item:** Integrate ISA compatibility with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “ISA compatibility” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C014-T02 · Field mapping:** Map every “ISA compatibility” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “ISA compatibility” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C014-T04 · Ownership agreement:** Specify who owns “ISA compatibility” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C014-T05 · Handoff implementation:** Connect “ISA compatibility” through the mapped seam using the real adapter or explicit specification reference; preserve “An incompatible ISA is a hard placement refusal” across the handoff.
- [ ] **UC-M05.02-C014-T06 · Absent-input case:** Omit one required “ISA compatibility” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C014-T07 · Stale-input case:** Supply an outdated “ISA compatibility” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C014-T08 · Incompatible-input case:** Supply an incompatible “ISA compatibility” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C014-T09 · Valid integration trace:** Run a valid “ISA compatibility” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C014-T10 · Seam review:** Reconcile the “ISA compatibility” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for ISA compatibility; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “ISA compatibility” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C015-T02 · Expected-result oracle:** Specify the “ISA compatibility” expected result independently of the implementation output; include the property “An incompatible ISA is a hard placement refusal” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C015-T03 · Fixture material:** Create the concrete “ISA compatibility” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C015-T04 · Target preparation:** Prepare the “ISA compatibility” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C015-T05 · Initial-state record:** Record the initial “ISA compatibility” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C015-T06 · Valid-path execution:** Execute the “ISA compatibility” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C015-T07 · Outcome comparison:** Compare every declared “ISA compatibility” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C015-T08 · State and bounds check:** Inspect the “ISA compatibility” ownership/state effects and actual use of “Architecture matrix and candidate count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C015-T09 · Repeatability check:** Repeat the same “ISA compatibility” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C015-T10 · Positive evidence:** Attach the “ISA compatibility” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C016 · Negative test

**Original checklist item:** Negative case: An image is routed to a backend for a different architecture. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “ISA compatibility” source counterexample: “An image is routed to a backend for a different architecture”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “ISA compatibility”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C016-T03 · Valid control:** Construct a valid “ISA compatibility” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C016-T04 · Minimal adverse input:** Derive the “ISA compatibility” adverse fixture from the control with the smallest documented change needed to reproduce “An image is routed to a backend for a different architecture”; retain that change as reproducible data.
- [ ] **UC-M05.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “ISA compatibility”; require “An incompatible ISA is a hard placement refusal” and forbid a false-success verdict.
- [ ] **UC-M05.02-C016-T06 · Adverse execution:** Exercise the “ISA compatibility” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C016-T07 · Effect inspection:** Inspect “ISA compatibility” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C016-T08 · Refusal versus failure:** Confirm the “ISA compatibility” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C016-T09 · Reset and retention:** Restore only the disposable “ISA compatibility” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C016-T10 · Negative regression:** Register the “ISA compatibility” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C017 · Change / failure test

**Original checklist item:** Exercise ISA compatibility when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C017-T01 · Scenario record:** Write the “ISA compatibility” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “An incompatible ISA is a hard placement refusal”.
- [ ] **UC-M05.02-C017-T02 · Baseline capture:** Create a known-valid “ISA compatibility” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C017-T03 · Injection map:** Locate the “ISA compatibility” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “ISA compatibility” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C017-T05 · Controlled trigger:** Introduce the controlled “ISA compatibility” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C017-T06 · Intermediate inspection:** Inspect the “ISA compatibility” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “ISA compatibility”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “ISA compatibility” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C017-T09 · Repeat and compare:** Repeat the selected “ISA compatibility” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C017-T10 · Failure evidence:** Publish the “ISA compatibility” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for architecture matrix and candidate count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “ISA compatibility”: “Architecture matrix and candidate count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C018-T02 · Measurement method:** Choose how to observe each “ISA compatibility” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C018-T03 · Budget decision:** Select justified resource and input limits for “ISA compatibility”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “ISA compatibility” cases for “Architecture matrix and candidate count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “ISA compatibility” limit; preserve “An incompatible ISA is a hard placement refusal”.
- [ ] **UC-M05.02-C018-T06 · Normal measurement:** Run or review the normal “ISA compatibility” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C018-T07 · At-limit measurement:** Exercise the “ISA compatibility” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C018-T08 · Over-limit measurement:** Exercise the “ISA compatibility” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C018-T09 · Uncovered-scope report:** List the “ISA compatibility” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C018-T10 · Limit evidence:** Publish the selected “ISA compatibility” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for ISA compatibility with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C019-T01 · Event inventory:** List the “ISA compatibility” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “ISA compatibility” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C019-T03 · Failure mapping:** Map each documented “ISA compatibility” refusal or error to a diagnostic outcome; include “An image is routed to a backend for a different architecture” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C019-T04 · Emission path:** Add the “ISA compatibility” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C019-T05 · Redaction check:** Test “ISA compatibility” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C019-T06 · Output budget:** Set and exercise bounded “ISA compatibility” message size, rate and retention compatible with “Architecture matrix and candidate count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C019-T07 · Success/refusal fixtures:** Capture “ISA compatibility” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “ISA compatibility” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C019-T09 · Operator review:** Read the “ISA compatibility” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C019-T10 · Diagnostic evidence:** Publish redacted “ISA compatibility” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for ISA compatibility; label unexecuted checks as untested.

- [ ] **UC-M05.02-C020-T01 · Evidence inventory:** List the “ISA compatibility” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C020-T02 · Artifact references:** Record the exact “ISA compatibility” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C020-T03 · Fixture references:** Attach the “ISA compatibility” fixture IDs, input identities and oracle definition; preserve the source counterexample “An image is routed to a backend for a different architecture” as a distinct evidence case.
- [ ] **UC-M05.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “ISA compatibility”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C020-T05 · Environment record:** Record the actual “ISA compatibility” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C020-T06 · Expected versus observed:** Pair every “ISA compatibility” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C020-T07 · Failure and limit records:** Attach “ISA compatibility” change/failure and bounds evidence where required; include uncovered “Architecture matrix and candidate count” and unresolved violations of “An incompatible ISA is a hard placement refusal”.
- [ ] **UC-M05.02-C020-T08 · Evidence hygiene:** Check the “ISA compatibility” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C020-T09 · Reproduction review:** Have the “ISA compatibility” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C020-T10 · Acceptance linkage:** Link the “ISA compatibility” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Memory feasibility

**Source delivery:** Compare declared and measured memory needs with allocatable capacity.

**Source invariant:** A workload cannot be admitted beyond a hard memory constraint.

**Source negative case:** Concurrent placements each assume the same free memory.

**Source bounded quantities:** Reservation bytes and placement concurrency.

### UC-M05.02-C021 · Contract

**Original checklist item:** Specify memory feasibility inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C021-T01 · Scope statement:** Draft the operation boundary for “Memory feasibility” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Memory feasibility”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C021-T03 · Output inventory:** List the outputs of “Memory feasibility” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Memory feasibility”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C021-T05 · Prerequisite contract:** Map “Memory feasibility” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Memory feasibility”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C021-T07 · Invariant clause:** Add a normative clause for “Memory feasibility” that preserves “A workload cannot be admitted beyond a hard memory constraint”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Memory feasibility”; include the source counterexample “Concurrent placements each assume the same free memory” and the intended safe disposition.
- [ ] **UC-M05.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reservation bytes and placement concurrency” in the “Memory feasibility” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C021-T10 · Contract review:** Review the “Memory feasibility” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C022 · Delivery

**Original checklist item:** Compare declared and measured memory needs with allocatable capacity.

- [ ] **UC-M05.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Memory feasibility”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C022-T02 · Change plan:** Break the source delivery for “Memory feasibility” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C022-T03 · Core artifact:** Create the “Memory feasibility” fixture or harness for this source instruction: Compare declared and measured memory needs with allocatable capacity.
- [ ] **UC-M05.02-C022-T04 · Concrete realization:** Connect the “Memory feasibility” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Memory feasibility” needed to preserve “A workload cannot be admitted beyond a hard memory constraint”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C022-T06 · Dependency connection:** Connect the “Memory feasibility” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C022-T07 · Resource behavior:** Account for “Reservation bytes and placement concurrency” in “Memory feasibility”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C022-T08 · Delivery check:** Run the smallest real “Memory feasibility” path and its adverse fixture “Concurrent placements each assume the same free memory”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C022-T09 · Patch review:** Review the “Memory feasibility” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C022-T10 · Delivery handoff:** Publish the “Memory feasibility” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A workload cannot be admitted beyond a hard memory constraint. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Memory feasibility”; copy its required invariant exactly: “A workload cannot be admitted beyond a hard memory constraint”.
- [ ] **UC-M05.02-C023-T02 · Observable terms:** Define each term in the “Memory feasibility” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C023-T03 · Precondition set:** List the preconditions under which “A workload cannot be admitted beyond a hard memory constraint” must hold for “Memory feasibility”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C023-T04 · Transition coverage:** Map the “Memory feasibility” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Memory feasibility”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C023-T06 · Satisfying fixture:** Create a concrete “Memory feasibility” case that satisfies “A workload cannot be admitted beyond a hard memory constraint”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C023-T07 · Violating fixture:** Create the source counterexample “Concurrent placements each assume the same free memory” for “Memory feasibility”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C023-T08 · Enforcement evidence:** Exercise the “Memory feasibility” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C023-T09 · Regression linkage:** Link the “Memory feasibility” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Memory feasibility” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C024 · Integration

**Original checklist item:** Integrate memory feasibility with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Memory feasibility” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C024-T02 · Field mapping:** Map every “Memory feasibility” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Memory feasibility” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C024-T04 · Ownership agreement:** Specify who owns “Memory feasibility” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C024-T05 · Handoff implementation:** Connect “Memory feasibility” through the mapped seam using the real adapter or explicit specification reference; preserve “A workload cannot be admitted beyond a hard memory constraint” across the handoff.
- [ ] **UC-M05.02-C024-T06 · Absent-input case:** Omit one required “Memory feasibility” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C024-T07 · Stale-input case:** Supply an outdated “Memory feasibility” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Memory feasibility” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C024-T09 · Valid integration trace:** Run a valid “Memory feasibility” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C024-T10 · Seam review:** Reconcile the “Memory feasibility” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for memory feasibility; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Memory feasibility” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C025-T02 · Expected-result oracle:** Specify the “Memory feasibility” expected result independently of the implementation output; include the property “A workload cannot be admitted beyond a hard memory constraint” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C025-T03 · Fixture material:** Create the concrete “Memory feasibility” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C025-T04 · Target preparation:** Prepare the “Memory feasibility” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C025-T05 · Initial-state record:** Record the initial “Memory feasibility” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C025-T06 · Valid-path execution:** Execute the “Memory feasibility” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C025-T07 · Outcome comparison:** Compare every declared “Memory feasibility” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C025-T08 · State and bounds check:** Inspect the “Memory feasibility” ownership/state effects and actual use of “Reservation bytes and placement concurrency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C025-T09 · Repeatability check:** Repeat the same “Memory feasibility” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C025-T10 · Positive evidence:** Attach the “Memory feasibility” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C026 · Negative test

**Original checklist item:** Negative case: Concurrent placements each assume the same free memory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Memory feasibility” source counterexample: “Concurrent placements each assume the same free memory”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Memory feasibility”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C026-T03 · Valid control:** Construct a valid “Memory feasibility” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C026-T04 · Minimal adverse input:** Derive the “Memory feasibility” adverse fixture from the control with the smallest documented change needed to reproduce “Concurrent placements each assume the same free memory”; retain that change as reproducible data.
- [ ] **UC-M05.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Memory feasibility”; require “A workload cannot be admitted beyond a hard memory constraint” and forbid a false-success verdict.
- [ ] **UC-M05.02-C026-T06 · Adverse execution:** Exercise the “Memory feasibility” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C026-T07 · Effect inspection:** Inspect “Memory feasibility” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C026-T08 · Refusal versus failure:** Confirm the “Memory feasibility” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C026-T09 · Reset and retention:** Restore only the disposable “Memory feasibility” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C026-T10 · Negative regression:** Register the “Memory feasibility” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C027 · Change / failure test

**Original checklist item:** Exercise memory feasibility when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C027-T01 · Scenario record:** Write the “Memory feasibility” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “A workload cannot be admitted beyond a hard memory constraint”.
- [ ] **UC-M05.02-C027-T02 · Baseline capture:** Create a known-valid “Memory feasibility” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C027-T03 · Injection map:** Locate the “Memory feasibility” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Memory feasibility” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C027-T05 · Controlled trigger:** Introduce the controlled “Memory feasibility” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C027-T06 · Intermediate inspection:** Inspect the “Memory feasibility” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Memory feasibility”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Memory feasibility” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C027-T09 · Repeat and compare:** Repeat the selected “Memory feasibility” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C027-T10 · Failure evidence:** Publish the “Memory feasibility” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for reservation bytes and placement concurrency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Memory feasibility”: “Reservation bytes and placement concurrency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C028-T02 · Measurement method:** Choose how to observe each “Memory feasibility” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Memory feasibility”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Memory feasibility” cases for “Reservation bytes and placement concurrency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Memory feasibility” limit; preserve “A workload cannot be admitted beyond a hard memory constraint”.
- [ ] **UC-M05.02-C028-T06 · Normal measurement:** Run or review the normal “Memory feasibility” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C028-T07 · At-limit measurement:** Exercise the “Memory feasibility” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C028-T08 · Over-limit measurement:** Exercise the “Memory feasibility” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C028-T09 · Uncovered-scope report:** List the “Memory feasibility” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C028-T10 · Limit evidence:** Publish the selected “Memory feasibility” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for memory feasibility with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C029-T01 · Event inventory:** List the “Memory feasibility” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Memory feasibility” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C029-T03 · Failure mapping:** Map each documented “Memory feasibility” refusal or error to a diagnostic outcome; include “Concurrent placements each assume the same free memory” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C029-T04 · Emission path:** Add the “Memory feasibility” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C029-T05 · Redaction check:** Test “Memory feasibility” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C029-T06 · Output budget:** Set and exercise bounded “Memory feasibility” message size, rate and retention compatible with “Reservation bytes and placement concurrency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C029-T07 · Success/refusal fixtures:** Capture “Memory feasibility” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Memory feasibility” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C029-T09 · Operator review:** Read the “Memory feasibility” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C029-T10 · Diagnostic evidence:** Publish redacted “Memory feasibility” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for memory feasibility; label unexecuted checks as untested.

- [ ] **UC-M05.02-C030-T01 · Evidence inventory:** List the “Memory feasibility” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C030-T02 · Artifact references:** Record the exact “Memory feasibility” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C030-T03 · Fixture references:** Attach the “Memory feasibility” fixture IDs, input identities and oracle definition; preserve the source counterexample “Concurrent placements each assume the same free memory” as a distinct evidence case.
- [ ] **UC-M05.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Memory feasibility”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C030-T05 · Environment record:** Record the actual “Memory feasibility” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C030-T06 · Expected versus observed:** Pair every “Memory feasibility” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C030-T07 · Failure and limit records:** Attach “Memory feasibility” change/failure and bounds evidence where required; include uncovered “Reservation bytes and placement concurrency” and unresolved violations of “A workload cannot be admitted beyond a hard memory constraint”.
- [ ] **UC-M05.02-C030-T08 · Evidence hygiene:** Check the “Memory feasibility” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C030-T09 · Reproduction review:** Have the “Memory feasibility” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C030-T10 · Acceptance linkage:** Link the “Memory feasibility” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Isolation feasibility

**Source delivery:** Filter candidate backends by required verified isolation class.

**Source invariant:** A cheaper or idle adapter cannot override required isolation.

**Source negative case:** An isolated workload is placed in an ordinary process because capacity is low.

**Source bounded quantities:** Backend candidates and policy-check time.

### UC-M05.02-C031 · Contract

**Original checklist item:** Specify isolation feasibility inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C031-T01 · Scope statement:** Draft the operation boundary for “Isolation feasibility” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Isolation feasibility”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C031-T03 · Output inventory:** List the outputs of “Isolation feasibility” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Isolation feasibility”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C031-T05 · Prerequisite contract:** Map “Isolation feasibility” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Isolation feasibility”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C031-T07 · Invariant clause:** Add a normative clause for “Isolation feasibility” that preserves “A cheaper or idle adapter cannot override required isolation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Isolation feasibility”; include the source counterexample “An isolated workload is placed in an ordinary process because capacity is low” and the intended safe disposition.
- [ ] **UC-M05.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Backend candidates and policy-check time” in the “Isolation feasibility” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C031-T10 · Contract review:** Review the “Isolation feasibility” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C032 · Delivery

**Original checklist item:** Filter candidate backends by required verified isolation class.

- [ ] **UC-M05.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Isolation feasibility”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C032-T02 · Change plan:** Break the source delivery for “Isolation feasibility” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Isolation feasibility” that realizes this source instruction: Filter candidate backends by required verified isolation class.
- [ ] **UC-M05.02-C032-T04 · Concrete realization:** Trace “Isolation feasibility” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Isolation feasibility” needed to preserve “A cheaper or idle adapter cannot override required isolation”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C032-T06 · Dependency connection:** Connect the “Isolation feasibility” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C032-T07 · Resource behavior:** Account for “Backend candidates and policy-check time” in “Isolation feasibility”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C032-T08 · Delivery check:** Run the smallest real “Isolation feasibility” path and its adverse fixture “An isolated workload is placed in an ordinary process because capacity is low”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C032-T09 · Patch review:** Review the “Isolation feasibility” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C032-T10 · Delivery handoff:** Publish the “Isolation feasibility” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A cheaper or idle adapter cannot override required isolation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Isolation feasibility”; copy its required invariant exactly: “A cheaper or idle adapter cannot override required isolation”.
- [ ] **UC-M05.02-C033-T02 · Observable terms:** Define each term in the “Isolation feasibility” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C033-T03 · Precondition set:** List the preconditions under which “A cheaper or idle adapter cannot override required isolation” must hold for “Isolation feasibility”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C033-T04 · Transition coverage:** Map the “Isolation feasibility” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Isolation feasibility”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C033-T06 · Satisfying fixture:** Create a concrete “Isolation feasibility” case that satisfies “A cheaper or idle adapter cannot override required isolation”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C033-T07 · Violating fixture:** Create the source counterexample “An isolated workload is placed in an ordinary process because capacity is low” for “Isolation feasibility”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C033-T08 · Enforcement evidence:** Exercise the “Isolation feasibility” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C033-T09 · Regression linkage:** Link the “Isolation feasibility” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Isolation feasibility” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C034 · Integration

**Original checklist item:** Integrate isolation feasibility with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Isolation feasibility” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C034-T02 · Field mapping:** Map every “Isolation feasibility” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Isolation feasibility” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C034-T04 · Ownership agreement:** Specify who owns “Isolation feasibility” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C034-T05 · Handoff implementation:** Connect “Isolation feasibility” through the mapped seam using the real adapter or explicit specification reference; preserve “A cheaper or idle adapter cannot override required isolation” across the handoff.
- [ ] **UC-M05.02-C034-T06 · Absent-input case:** Omit one required “Isolation feasibility” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C034-T07 · Stale-input case:** Supply an outdated “Isolation feasibility” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Isolation feasibility” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C034-T09 · Valid integration trace:** Run a valid “Isolation feasibility” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C034-T10 · Seam review:** Reconcile the “Isolation feasibility” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for isolation feasibility; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Isolation feasibility” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C035-T02 · Expected-result oracle:** Specify the “Isolation feasibility” expected result independently of the implementation output; include the property “A cheaper or idle adapter cannot override required isolation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C035-T03 · Fixture material:** Create the concrete “Isolation feasibility” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C035-T04 · Target preparation:** Prepare the “Isolation feasibility” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C035-T05 · Initial-state record:** Record the initial “Isolation feasibility” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C035-T06 · Valid-path execution:** Execute the “Isolation feasibility” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C035-T07 · Outcome comparison:** Compare every declared “Isolation feasibility” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C035-T08 · State and bounds check:** Inspect the “Isolation feasibility” ownership/state effects and actual use of “Backend candidates and policy-check time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C035-T09 · Repeatability check:** Repeat the same “Isolation feasibility” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C035-T10 · Positive evidence:** Attach the “Isolation feasibility” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C036 · Negative test

**Original checklist item:** Negative case: An isolated workload is placed in an ordinary process because capacity is low. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Isolation feasibility” source counterexample: “An isolated workload is placed in an ordinary process because capacity is low”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Isolation feasibility”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C036-T03 · Valid control:** Construct a valid “Isolation feasibility” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C036-T04 · Minimal adverse input:** Derive the “Isolation feasibility” adverse fixture from the control with the smallest documented change needed to reproduce “An isolated workload is placed in an ordinary process because capacity is low”; retain that change as reproducible data.
- [ ] **UC-M05.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Isolation feasibility”; require “A cheaper or idle adapter cannot override required isolation” and forbid a false-success verdict.
- [ ] **UC-M05.02-C036-T06 · Adverse execution:** Exercise the “Isolation feasibility” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C036-T07 · Effect inspection:** Inspect “Isolation feasibility” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C036-T08 · Refusal versus failure:** Confirm the “Isolation feasibility” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C036-T09 · Reset and retention:** Restore only the disposable “Isolation feasibility” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C036-T10 · Negative regression:** Register the “Isolation feasibility” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C037 · Change / failure test

**Original checklist item:** Exercise isolation feasibility when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C037-T01 · Scenario record:** Write the “Isolation feasibility” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “A cheaper or idle adapter cannot override required isolation”.
- [ ] **UC-M05.02-C037-T02 · Baseline capture:** Create a known-valid “Isolation feasibility” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C037-T03 · Injection map:** Locate the “Isolation feasibility” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Isolation feasibility” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C037-T05 · Controlled trigger:** Introduce the controlled “Isolation feasibility” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C037-T06 · Intermediate inspection:** Inspect the “Isolation feasibility” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Isolation feasibility”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Isolation feasibility” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C037-T09 · Repeat and compare:** Repeat the selected “Isolation feasibility” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C037-T10 · Failure evidence:** Publish the “Isolation feasibility” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for backend candidates and policy-check time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Isolation feasibility”: “Backend candidates and policy-check time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C038-T02 · Measurement method:** Choose how to observe each “Isolation feasibility” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C038-T03 · Budget decision:** Select justified resource and input limits for “Isolation feasibility”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Isolation feasibility” cases for “Backend candidates and policy-check time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Isolation feasibility” limit; preserve “A cheaper or idle adapter cannot override required isolation”.
- [ ] **UC-M05.02-C038-T06 · Normal measurement:** Run or review the normal “Isolation feasibility” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C038-T07 · At-limit measurement:** Exercise the “Isolation feasibility” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C038-T08 · Over-limit measurement:** Exercise the “Isolation feasibility” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C038-T09 · Uncovered-scope report:** List the “Isolation feasibility” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C038-T10 · Limit evidence:** Publish the selected “Isolation feasibility” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for isolation feasibility with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C039-T01 · Event inventory:** List the “Isolation feasibility” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Isolation feasibility” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C039-T03 · Failure mapping:** Map each documented “Isolation feasibility” refusal or error to a diagnostic outcome; include “An isolated workload is placed in an ordinary process because capacity is low” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C039-T04 · Emission path:** Add the “Isolation feasibility” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C039-T05 · Redaction check:** Test “Isolation feasibility” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C039-T06 · Output budget:** Set and exercise bounded “Isolation feasibility” message size, rate and retention compatible with “Backend candidates and policy-check time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C039-T07 · Success/refusal fixtures:** Capture “Isolation feasibility” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Isolation feasibility” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C039-T09 · Operator review:** Read the “Isolation feasibility” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C039-T10 · Diagnostic evidence:** Publish redacted “Isolation feasibility” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for isolation feasibility; label unexecuted checks as untested.

- [ ] **UC-M05.02-C040-T01 · Evidence inventory:** List the “Isolation feasibility” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C040-T02 · Artifact references:** Record the exact “Isolation feasibility” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C040-T03 · Fixture references:** Attach the “Isolation feasibility” fixture IDs, input identities and oracle definition; preserve the source counterexample “An isolated workload is placed in an ordinary process because capacity is low” as a distinct evidence case.
- [ ] **UC-M05.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Isolation feasibility”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C040-T05 · Environment record:** Record the actual “Isolation feasibility” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C040-T06 · Expected versus observed:** Pair every “Isolation feasibility” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C040-T07 · Failure and limit records:** Attach “Isolation feasibility” change/failure and bounds evidence where required; include uncovered “Backend candidates and policy-check time” and unresolved violations of “A cheaper or idle adapter cannot override required isolation”.
- [ ] **UC-M05.02-C040-T08 · Evidence hygiene:** Check the “Isolation feasibility” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C040-T09 · Reproduction review:** Have the “Isolation feasibility” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C040-T10 · Acceptance linkage:** Link the “Isolation feasibility” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Resource reservations

**Source delivery:** Reserve capacity atomically when a placement decision commits.

**Source invariant:** Two placements cannot spend the same reserved capacity.

**Source negative case:** Two scheduler workers simultaneously claim the final available slot.

**Source bounded quantities:** Reservations and contention wait.

### UC-M05.02-C041 · Contract

**Original checklist item:** Specify resource reservations inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C041-T01 · Scope statement:** Draft the operation boundary for “Resource reservations” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource reservations”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C041-T03 · Output inventory:** List the outputs of “Resource reservations” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource reservations”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C041-T05 · Prerequisite contract:** Map “Resource reservations” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Resource reservations”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C041-T07 · Invariant clause:** Add a normative clause for “Resource reservations” that preserves “Two placements cannot spend the same reserved capacity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource reservations”; include the source counterexample “Two scheduler workers simultaneously claim the final available slot” and the intended safe disposition.
- [ ] **UC-M05.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reservations and contention wait” in the “Resource reservations” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C041-T10 · Contract review:** Review the “Resource reservations” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C042 · Delivery

**Original checklist item:** Reserve capacity atomically when a placement decision commits.

- [ ] **UC-M05.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource reservations”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C042-T02 · Change plan:** Break the source delivery for “Resource reservations” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Resource reservations” that realizes this source instruction: Reserve capacity atomically when a placement decision commits.
- [ ] **UC-M05.02-C042-T04 · Concrete realization:** Trace “Resource reservations” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource reservations” needed to preserve “Two placements cannot spend the same reserved capacity”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C042-T06 · Dependency connection:** Connect the “Resource reservations” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C042-T07 · Resource behavior:** Account for “Reservations and contention wait” in “Resource reservations”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C042-T08 · Delivery check:** Run the smallest real “Resource reservations” path and its adverse fixture “Two scheduler workers simultaneously claim the final available slot”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C042-T09 · Patch review:** Review the “Resource reservations” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C042-T10 · Delivery handoff:** Publish the “Resource reservations” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Two placements cannot spend the same reserved capacity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Resource reservations”; copy its required invariant exactly: “Two placements cannot spend the same reserved capacity”.
- [ ] **UC-M05.02-C043-T02 · Observable terms:** Define each term in the “Resource reservations” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C043-T03 · Precondition set:** List the preconditions under which “Two placements cannot spend the same reserved capacity” must hold for “Resource reservations”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C043-T04 · Transition coverage:** Map the “Resource reservations” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource reservations”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C043-T06 · Satisfying fixture:** Create a concrete “Resource reservations” case that satisfies “Two placements cannot spend the same reserved capacity”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C043-T07 · Violating fixture:** Create the source counterexample “Two scheduler workers simultaneously claim the final available slot” for “Resource reservations”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C043-T08 · Enforcement evidence:** Exercise the “Resource reservations” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C043-T09 · Regression linkage:** Link the “Resource reservations” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Resource reservations” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C044 · Integration

**Original checklist item:** Integrate resource reservations with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource reservations” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C044-T02 · Field mapping:** Map every “Resource reservations” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource reservations” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C044-T04 · Ownership agreement:** Specify who owns “Resource reservations” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C044-T05 · Handoff implementation:** Connect “Resource reservations” through the mapped seam using the real adapter or explicit specification reference; preserve “Two placements cannot spend the same reserved capacity” across the handoff.
- [ ] **UC-M05.02-C044-T06 · Absent-input case:** Omit one required “Resource reservations” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C044-T07 · Stale-input case:** Supply an outdated “Resource reservations” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Resource reservations” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C044-T09 · Valid integration trace:** Run a valid “Resource reservations” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C044-T10 · Seam review:** Reconcile the “Resource reservations” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for resource reservations; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Resource reservations” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C045-T02 · Expected-result oracle:** Specify the “Resource reservations” expected result independently of the implementation output; include the property “Two placements cannot spend the same reserved capacity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C045-T03 · Fixture material:** Create the concrete “Resource reservations” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C045-T04 · Target preparation:** Prepare the “Resource reservations” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C045-T05 · Initial-state record:** Record the initial “Resource reservations” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C045-T06 · Valid-path execution:** Execute the “Resource reservations” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C045-T07 · Outcome comparison:** Compare every declared “Resource reservations” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C045-T08 · State and bounds check:** Inspect the “Resource reservations” ownership/state effects and actual use of “Reservations and contention wait”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C045-T09 · Repeatability check:** Repeat the same “Resource reservations” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C045-T10 · Positive evidence:** Attach the “Resource reservations” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C046 · Negative test

**Original checklist item:** Negative case: Two scheduler workers simultaneously claim the final available slot. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Resource reservations” source counterexample: “Two scheduler workers simultaneously claim the final available slot”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource reservations”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C046-T03 · Valid control:** Construct a valid “Resource reservations” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C046-T04 · Minimal adverse input:** Derive the “Resource reservations” adverse fixture from the control with the smallest documented change needed to reproduce “Two scheduler workers simultaneously claim the final available slot”; retain that change as reproducible data.
- [ ] **UC-M05.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource reservations”; require “Two placements cannot spend the same reserved capacity” and forbid a false-success verdict.
- [ ] **UC-M05.02-C046-T06 · Adverse execution:** Exercise the “Resource reservations” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C046-T07 · Effect inspection:** Inspect “Resource reservations” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C046-T08 · Refusal versus failure:** Confirm the “Resource reservations” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C046-T09 · Reset and retention:** Restore only the disposable “Resource reservations” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C046-T10 · Negative regression:** Register the “Resource reservations” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C047 · Change / failure test

**Original checklist item:** Exercise resource reservations when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C047-T01 · Scenario record:** Write the “Resource reservations” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “Two placements cannot spend the same reserved capacity”.
- [ ] **UC-M05.02-C047-T02 · Baseline capture:** Create a known-valid “Resource reservations” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C047-T03 · Injection map:** Locate the “Resource reservations” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Resource reservations” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C047-T05 · Controlled trigger:** Introduce the controlled “Resource reservations” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C047-T06 · Intermediate inspection:** Inspect the “Resource reservations” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource reservations”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource reservations” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C047-T09 · Repeat and compare:** Repeat the selected “Resource reservations” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C047-T10 · Failure evidence:** Publish the “Resource reservations” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for reservations and contention wait; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Resource reservations”: “Reservations and contention wait”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C048-T02 · Measurement method:** Choose how to observe each “Resource reservations” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C048-T03 · Budget decision:** Select justified resource and input limits for “Resource reservations”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource reservations” cases for “Reservations and contention wait”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource reservations” limit; preserve “Two placements cannot spend the same reserved capacity”.
- [ ] **UC-M05.02-C048-T06 · Normal measurement:** Run or review the normal “Resource reservations” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C048-T07 · At-limit measurement:** Exercise the “Resource reservations” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C048-T08 · Over-limit measurement:** Exercise the “Resource reservations” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C048-T09 · Uncovered-scope report:** List the “Resource reservations” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C048-T10 · Limit evidence:** Publish the selected “Resource reservations” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for resource reservations with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C049-T01 · Event inventory:** List the “Resource reservations” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Resource reservations” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C049-T03 · Failure mapping:** Map each documented “Resource reservations” refusal or error to a diagnostic outcome; include “Two scheduler workers simultaneously claim the final available slot” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C049-T04 · Emission path:** Add the “Resource reservations” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C049-T05 · Redaction check:** Test “Resource reservations” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C049-T06 · Output budget:** Set and exercise bounded “Resource reservations” message size, rate and retention compatible with “Reservations and contention wait”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C049-T07 · Success/refusal fixtures:** Capture “Resource reservations” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Resource reservations” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C049-T09 · Operator review:** Read the “Resource reservations” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C049-T10 · Diagnostic evidence:** Publish redacted “Resource reservations” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource reservations; label unexecuted checks as untested.

- [ ] **UC-M05.02-C050-T01 · Evidence inventory:** List the “Resource reservations” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C050-T02 · Artifact references:** Record the exact “Resource reservations” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C050-T03 · Fixture references:** Attach the “Resource reservations” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two scheduler workers simultaneously claim the final available slot” as a distinct evidence case.
- [ ] **UC-M05.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource reservations”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C050-T05 · Environment record:** Record the actual “Resource reservations” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C050-T06 · Expected versus observed:** Pair every “Resource reservations” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C050-T07 · Failure and limit records:** Attach “Resource reservations” change/failure and bounds evidence where required; include uncovered “Reservations and contention wait” and unresolved violations of “Two placements cannot spend the same reserved capacity”.
- [ ] **UC-M05.02-C050-T08 · Evidence hygiene:** Check the “Resource reservations” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C050-T09 · Reproduction review:** Have the “Resource reservations” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C050-T10 · Acceptance linkage:** Link the “Resource reservations” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Queue-or-refuse policy

**Source delivery:** Define explicit outcomes when no feasible placement exists.

**Source invariant:** Infeasible work is queued or refused rather than executed unsafely.

**Source negative case:** The scheduler ignores a hard constraint to keep the queue moving.

**Source bounded quantities:** Queue capacity and placement retry interval.

### UC-M05.02-C051 · Contract

**Original checklist item:** Specify queue-or-refuse policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C051-T01 · Scope statement:** Draft the operation boundary for “Queue-or-refuse policy” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Queue-or-refuse policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C051-T03 · Output inventory:** List the outputs of “Queue-or-refuse policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Queue-or-refuse policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C051-T05 · Prerequisite contract:** Map “Queue-or-refuse policy” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Queue-or-refuse policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C051-T07 · Invariant clause:** Add a normative clause for “Queue-or-refuse policy” that preserves “Infeasible work is queued or refused rather than executed unsafely”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Queue-or-refuse policy”; include the source counterexample “The scheduler ignores a hard constraint to keep the queue moving” and the intended safe disposition.
- [ ] **UC-M05.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Queue capacity and placement retry interval” in the “Queue-or-refuse policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C051-T10 · Contract review:** Review the “Queue-or-refuse policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C052 · Delivery

**Original checklist item:** Define explicit outcomes when no feasible placement exists.

- [ ] **UC-M05.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Queue-or-refuse policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C052-T02 · Change plan:** Break the source delivery for “Queue-or-refuse policy” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C052-T03 · Core artifact:** Create the “Queue-or-refuse policy” model, schema or inventory that realizes this source instruction: Define explicit outcomes when no feasible placement exists.
- [ ] **UC-M05.02-C052-T04 · Concrete realization:** Populate “Queue-or-refuse policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Queue-or-refuse policy” needed to preserve “Infeasible work is queued or refused rather than executed unsafely”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C052-T06 · Dependency connection:** Connect the “Queue-or-refuse policy” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C052-T07 · Resource behavior:** Account for “Queue capacity and placement retry interval” in “Queue-or-refuse policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C052-T08 · Delivery check:** Run the smallest real “Queue-or-refuse policy” path and its adverse fixture “The scheduler ignores a hard constraint to keep the queue moving”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C052-T09 · Patch review:** Review the “Queue-or-refuse policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C052-T10 · Delivery handoff:** Publish the “Queue-or-refuse policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Infeasible work is queued or refused rather than executed unsafely. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Queue-or-refuse policy”; copy its required invariant exactly: “Infeasible work is queued or refused rather than executed unsafely”.
- [ ] **UC-M05.02-C053-T02 · Observable terms:** Define each term in the “Queue-or-refuse policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C053-T03 · Precondition set:** List the preconditions under which “Infeasible work is queued or refused rather than executed unsafely” must hold for “Queue-or-refuse policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C053-T04 · Transition coverage:** Map the “Queue-or-refuse policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Queue-or-refuse policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C053-T06 · Satisfying fixture:** Create a concrete “Queue-or-refuse policy” case that satisfies “Infeasible work is queued or refused rather than executed unsafely”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C053-T07 · Violating fixture:** Create the source counterexample “The scheduler ignores a hard constraint to keep the queue moving” for “Queue-or-refuse policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C053-T08 · Enforcement evidence:** Exercise the “Queue-or-refuse policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C053-T09 · Regression linkage:** Link the “Queue-or-refuse policy” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Queue-or-refuse policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C054 · Integration

**Original checklist item:** Integrate queue-or-refuse policy with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Queue-or-refuse policy” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C054-T02 · Field mapping:** Map every “Queue-or-refuse policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Queue-or-refuse policy” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C054-T04 · Ownership agreement:** Specify who owns “Queue-or-refuse policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C054-T05 · Handoff implementation:** Connect “Queue-or-refuse policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Infeasible work is queued or refused rather than executed unsafely” across the handoff.
- [ ] **UC-M05.02-C054-T06 · Absent-input case:** Omit one required “Queue-or-refuse policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C054-T07 · Stale-input case:** Supply an outdated “Queue-or-refuse policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Queue-or-refuse policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C054-T09 · Valid integration trace:** Run a valid “Queue-or-refuse policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C054-T10 · Seam review:** Reconcile the “Queue-or-refuse policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for queue-or-refuse policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Queue-or-refuse policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C055-T02 · Expected-result oracle:** Specify the “Queue-or-refuse policy” expected result independently of the implementation output; include the property “Infeasible work is queued or refused rather than executed unsafely” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C055-T03 · Fixture material:** Create the concrete “Queue-or-refuse policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C055-T04 · Target preparation:** Prepare the “Queue-or-refuse policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C055-T05 · Initial-state record:** Record the initial “Queue-or-refuse policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C055-T06 · Valid-path execution:** Execute the “Queue-or-refuse policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C055-T07 · Outcome comparison:** Compare every declared “Queue-or-refuse policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C055-T08 · State and bounds check:** Inspect the “Queue-or-refuse policy” ownership/state effects and actual use of “Queue capacity and placement retry interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C055-T09 · Repeatability check:** Repeat the same “Queue-or-refuse policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C055-T10 · Positive evidence:** Attach the “Queue-or-refuse policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C056 · Negative test

**Original checklist item:** Negative case: The scheduler ignores a hard constraint to keep the queue moving. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Queue-or-refuse policy” source counterexample: “The scheduler ignores a hard constraint to keep the queue moving”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Queue-or-refuse policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C056-T03 · Valid control:** Construct a valid “Queue-or-refuse policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C056-T04 · Minimal adverse input:** Derive the “Queue-or-refuse policy” adverse fixture from the control with the smallest documented change needed to reproduce “The scheduler ignores a hard constraint to keep the queue moving”; retain that change as reproducible data.
- [ ] **UC-M05.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Queue-or-refuse policy”; require “Infeasible work is queued or refused rather than executed unsafely” and forbid a false-success verdict.
- [ ] **UC-M05.02-C056-T06 · Adverse execution:** Exercise the “Queue-or-refuse policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C056-T07 · Effect inspection:** Inspect “Queue-or-refuse policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C056-T08 · Refusal versus failure:** Confirm the “Queue-or-refuse policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C056-T09 · Reset and retention:** Restore only the disposable “Queue-or-refuse policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C056-T10 · Negative regression:** Register the “Queue-or-refuse policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C057 · Change / failure test

**Original checklist item:** Exercise queue-or-refuse policy when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C057-T01 · Scenario record:** Write the “Queue-or-refuse policy” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “Infeasible work is queued or refused rather than executed unsafely”.
- [ ] **UC-M05.02-C057-T02 · Baseline capture:** Create a known-valid “Queue-or-refuse policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C057-T03 · Injection map:** Locate the “Queue-or-refuse policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Queue-or-refuse policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C057-T05 · Controlled trigger:** Introduce the controlled “Queue-or-refuse policy” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C057-T06 · Intermediate inspection:** Inspect the “Queue-or-refuse policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Queue-or-refuse policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Queue-or-refuse policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C057-T09 · Repeat and compare:** Repeat the selected “Queue-or-refuse policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C057-T10 · Failure evidence:** Publish the “Queue-or-refuse policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for queue capacity and placement retry interval; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Queue-or-refuse policy”: “Queue capacity and placement retry interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C058-T02 · Measurement method:** Choose how to observe each “Queue-or-refuse policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Queue-or-refuse policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Queue-or-refuse policy” cases for “Queue capacity and placement retry interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Queue-or-refuse policy” limit; preserve “Infeasible work is queued or refused rather than executed unsafely”.
- [ ] **UC-M05.02-C058-T06 · Normal measurement:** Run or review the normal “Queue-or-refuse policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C058-T07 · At-limit measurement:** Exercise the “Queue-or-refuse policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C058-T08 · Over-limit measurement:** Exercise the “Queue-or-refuse policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C058-T09 · Uncovered-scope report:** List the “Queue-or-refuse policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C058-T10 · Limit evidence:** Publish the selected “Queue-or-refuse policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for queue-or-refuse policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C059-T01 · Event inventory:** List the “Queue-or-refuse policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Queue-or-refuse policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C059-T03 · Failure mapping:** Map each documented “Queue-or-refuse policy” refusal or error to a diagnostic outcome; include “The scheduler ignores a hard constraint to keep the queue moving” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C059-T04 · Emission path:** Add the “Queue-or-refuse policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C059-T05 · Redaction check:** Test “Queue-or-refuse policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C059-T06 · Output budget:** Set and exercise bounded “Queue-or-refuse policy” message size, rate and retention compatible with “Queue capacity and placement retry interval”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C059-T07 · Success/refusal fixtures:** Capture “Queue-or-refuse policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Queue-or-refuse policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C059-T09 · Operator review:** Read the “Queue-or-refuse policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C059-T10 · Diagnostic evidence:** Publish redacted “Queue-or-refuse policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for queue-or-refuse policy; label unexecuted checks as untested.

- [ ] **UC-M05.02-C060-T01 · Evidence inventory:** List the “Queue-or-refuse policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C060-T02 · Artifact references:** Record the exact “Queue-or-refuse policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C060-T03 · Fixture references:** Attach the “Queue-or-refuse policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “The scheduler ignores a hard constraint to keep the queue moving” as a distinct evidence case.
- [ ] **UC-M05.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Queue-or-refuse policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C060-T05 · Environment record:** Record the actual “Queue-or-refuse policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C060-T06 · Expected versus observed:** Pair every “Queue-or-refuse policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C060-T07 · Failure and limit records:** Attach “Queue-or-refuse policy” change/failure and bounds evidence where required; include uncovered “Queue capacity and placement retry interval” and unresolved violations of “Infeasible work is queued or refused rather than executed unsafely”.
- [ ] **UC-M05.02-C060-T08 · Evidence hygiene:** Check the “Queue-or-refuse policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C060-T09 · Reproduction review:** Have the “Queue-or-refuse policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C060-T10 · Acceptance linkage:** Link the “Queue-or-refuse policy” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Measured cost model

**Source delivery:** Use recorded execution and overhead observations to improve placement estimates.

**Source invariant:** Estimated costs remain distinct from enforced hard limits.

**Source negative case:** A low complexity score overrides measured high memory consumption.

**Source bounded quantities:** Model features and retained samples.

### UC-M05.02-C061 · Contract

**Original checklist item:** Specify measured cost model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C061-T01 · Scope statement:** Draft the operation boundary for “Measured cost model” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Measured cost model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C061-T03 · Output inventory:** List the outputs of “Measured cost model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Measured cost model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C061-T05 · Prerequisite contract:** Map “Measured cost model” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Measured cost model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C061-T07 · Invariant clause:** Add a normative clause for “Measured cost model” that preserves “Estimated costs remain distinct from enforced hard limits”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Measured cost model”; include the source counterexample “A low complexity score overrides measured high memory consumption” and the intended safe disposition.
- [ ] **UC-M05.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Model features and retained samples” in the “Measured cost model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C061-T10 · Contract review:** Review the “Measured cost model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C062 · Delivery

**Original checklist item:** Use recorded execution and overhead observations to improve placement estimates.

- [ ] **UC-M05.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Measured cost model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C062-T02 · Change plan:** Break the source delivery for “Measured cost model” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Measured cost model” that realizes this source instruction: Use recorded execution and overhead observations to improve placement estimates.
- [ ] **UC-M05.02-C062-T04 · Concrete realization:** Trace “Measured cost model” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Measured cost model” needed to preserve “Estimated costs remain distinct from enforced hard limits”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C062-T06 · Dependency connection:** Connect the “Measured cost model” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C062-T07 · Resource behavior:** Account for “Model features and retained samples” in “Measured cost model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C062-T08 · Delivery check:** Run the smallest real “Measured cost model” path and its adverse fixture “A low complexity score overrides measured high memory consumption”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C062-T09 · Patch review:** Review the “Measured cost model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C062-T10 · Delivery handoff:** Publish the “Measured cost model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Estimated costs remain distinct from enforced hard limits. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Measured cost model”; copy its required invariant exactly: “Estimated costs remain distinct from enforced hard limits”.
- [ ] **UC-M05.02-C063-T02 · Observable terms:** Define each term in the “Measured cost model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C063-T03 · Precondition set:** List the preconditions under which “Estimated costs remain distinct from enforced hard limits” must hold for “Measured cost model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C063-T04 · Transition coverage:** Map the “Measured cost model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Measured cost model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C063-T06 · Satisfying fixture:** Create a concrete “Measured cost model” case that satisfies “Estimated costs remain distinct from enforced hard limits”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C063-T07 · Violating fixture:** Create the source counterexample “A low complexity score overrides measured high memory consumption” for “Measured cost model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C063-T08 · Enforcement evidence:** Exercise the “Measured cost model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C063-T09 · Regression linkage:** Link the “Measured cost model” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Measured cost model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C064 · Integration

**Original checklist item:** Integrate measured cost model with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Measured cost model” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C064-T02 · Field mapping:** Map every “Measured cost model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Measured cost model” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C064-T04 · Ownership agreement:** Specify who owns “Measured cost model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C064-T05 · Handoff implementation:** Connect “Measured cost model” through the mapped seam using the real adapter or explicit specification reference; preserve “Estimated costs remain distinct from enforced hard limits” across the handoff.
- [ ] **UC-M05.02-C064-T06 · Absent-input case:** Omit one required “Measured cost model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C064-T07 · Stale-input case:** Supply an outdated “Measured cost model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Measured cost model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C064-T09 · Valid integration trace:** Run a valid “Measured cost model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C064-T10 · Seam review:** Reconcile the “Measured cost model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for measured cost model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Measured cost model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C065-T02 · Expected-result oracle:** Specify the “Measured cost model” expected result independently of the implementation output; include the property “Estimated costs remain distinct from enforced hard limits” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C065-T03 · Fixture material:** Create the concrete “Measured cost model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C065-T04 · Target preparation:** Prepare the “Measured cost model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C065-T05 · Initial-state record:** Record the initial “Measured cost model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C065-T06 · Valid-path execution:** Execute the “Measured cost model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C065-T07 · Outcome comparison:** Compare every declared “Measured cost model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C065-T08 · State and bounds check:** Inspect the “Measured cost model” ownership/state effects and actual use of “Model features and retained samples”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C065-T09 · Repeatability check:** Repeat the same “Measured cost model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C065-T10 · Positive evidence:** Attach the “Measured cost model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C066 · Negative test

**Original checklist item:** Negative case: A low complexity score overrides measured high memory consumption. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Measured cost model” source counterexample: “A low complexity score overrides measured high memory consumption”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Measured cost model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C066-T03 · Valid control:** Construct a valid “Measured cost model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C066-T04 · Minimal adverse input:** Derive the “Measured cost model” adverse fixture from the control with the smallest documented change needed to reproduce “A low complexity score overrides measured high memory consumption”; retain that change as reproducible data.
- [ ] **UC-M05.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Measured cost model”; require “Estimated costs remain distinct from enforced hard limits” and forbid a false-success verdict.
- [ ] **UC-M05.02-C066-T06 · Adverse execution:** Exercise the “Measured cost model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C066-T07 · Effect inspection:** Inspect “Measured cost model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C066-T08 · Refusal versus failure:** Confirm the “Measured cost model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C066-T09 · Reset and retention:** Restore only the disposable “Measured cost model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C066-T10 · Negative regression:** Register the “Measured cost model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C067 · Change / failure test

**Original checklist item:** Exercise measured cost model when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C067-T01 · Scenario record:** Write the “Measured cost model” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “Estimated costs remain distinct from enforced hard limits”.
- [ ] **UC-M05.02-C067-T02 · Baseline capture:** Create a known-valid “Measured cost model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C067-T03 · Injection map:** Locate the “Measured cost model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Measured cost model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C067-T05 · Controlled trigger:** Introduce the controlled “Measured cost model” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C067-T06 · Intermediate inspection:** Inspect the “Measured cost model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Measured cost model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Measured cost model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C067-T09 · Repeat and compare:** Repeat the selected “Measured cost model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C067-T10 · Failure evidence:** Publish the “Measured cost model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for model features and retained samples; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Measured cost model”: “Model features and retained samples”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C068-T02 · Measurement method:** Choose how to observe each “Measured cost model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Measured cost model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Measured cost model” cases for “Model features and retained samples”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Measured cost model” limit; preserve “Estimated costs remain distinct from enforced hard limits”.
- [ ] **UC-M05.02-C068-T06 · Normal measurement:** Run or review the normal “Measured cost model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C068-T07 · At-limit measurement:** Exercise the “Measured cost model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C068-T08 · Over-limit measurement:** Exercise the “Measured cost model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C068-T09 · Uncovered-scope report:** List the “Measured cost model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C068-T10 · Limit evidence:** Publish the selected “Measured cost model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for measured cost model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C069-T01 · Event inventory:** List the “Measured cost model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Measured cost model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C069-T03 · Failure mapping:** Map each documented “Measured cost model” refusal or error to a diagnostic outcome; include “A low complexity score overrides measured high memory consumption” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C069-T04 · Emission path:** Add the “Measured cost model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C069-T05 · Redaction check:** Test “Measured cost model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C069-T06 · Output budget:** Set and exercise bounded “Measured cost model” message size, rate and retention compatible with “Model features and retained samples”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C069-T07 · Success/refusal fixtures:** Capture “Measured cost model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Measured cost model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C069-T09 · Operator review:** Read the “Measured cost model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C069-T10 · Diagnostic evidence:** Publish redacted “Measured cost model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for measured cost model; label unexecuted checks as untested.

- [ ] **UC-M05.02-C070-T01 · Evidence inventory:** List the “Measured cost model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C070-T02 · Artifact references:** Record the exact “Measured cost model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C070-T03 · Fixture references:** Attach the “Measured cost model” fixture IDs, input identities and oracle definition; preserve the source counterexample “A low complexity score overrides measured high memory consumption” as a distinct evidence case.
- [ ] **UC-M05.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Measured cost model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C070-T05 · Environment record:** Record the actual “Measured cost model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C070-T06 · Expected versus observed:** Pair every “Measured cost model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C070-T07 · Failure and limit records:** Attach “Measured cost model” change/failure and bounds evidence where required; include uncovered “Model features and retained samples” and unresolved violations of “Estimated costs remain distinct from enforced hard limits”.
- [ ] **UC-M05.02-C070-T08 · Evidence hygiene:** Check the “Measured cost model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C070-T09 · Reproduction review:** Have the “Measured cost model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C070-T10 · Acceptance linkage:** Link the “Measured cost model” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Placement explanations

**Source delivery:** Record selected host/backend and reasons rejected candidates were unsuitable.

**Source invariant:** An operator can reconstruct why a placement was made.

**Source negative case:** Placement records contain only a final backend name.

**Source bounded quantities:** Explanation bytes and candidate history.

### UC-M05.02-C071 · Contract

**Original checklist item:** Specify placement explanations inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C071-T01 · Scope statement:** Draft the operation boundary for “Placement explanations” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Placement explanations”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C071-T03 · Output inventory:** List the outputs of “Placement explanations” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Placement explanations”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C071-T05 · Prerequisite contract:** Map “Placement explanations” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Placement explanations”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C071-T07 · Invariant clause:** Add a normative clause for “Placement explanations” that preserves “An operator can reconstruct why a placement was made”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Placement explanations”; include the source counterexample “Placement records contain only a final backend name” and the intended safe disposition.
- [ ] **UC-M05.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Explanation bytes and candidate history” in the “Placement explanations” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C071-T10 · Contract review:** Review the “Placement explanations” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C072 · Delivery

**Original checklist item:** Record selected host/backend and reasons rejected candidates were unsuitable.

- [ ] **UC-M05.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Placement explanations”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C072-T02 · Change plan:** Break the source delivery for “Placement explanations” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C072-T03 · Core artifact:** Create the “Placement explanations” model, schema or inventory that realizes this source instruction: Record selected host/backend and reasons rejected candidates were unsuitable.
- [ ] **UC-M05.02-C072-T04 · Concrete realization:** Populate “Placement explanations” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Placement explanations” needed to preserve “An operator can reconstruct why a placement was made”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C072-T06 · Dependency connection:** Connect the “Placement explanations” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C072-T07 · Resource behavior:** Account for “Explanation bytes and candidate history” in “Placement explanations”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C072-T08 · Delivery check:** Run the smallest real “Placement explanations” path and its adverse fixture “Placement records contain only a final backend name”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C072-T09 · Patch review:** Review the “Placement explanations” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C072-T10 · Delivery handoff:** Publish the “Placement explanations” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An operator can reconstruct why a placement was made. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Placement explanations”; copy its required invariant exactly: “An operator can reconstruct why a placement was made”.
- [ ] **UC-M05.02-C073-T02 · Observable terms:** Define each term in the “Placement explanations” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C073-T03 · Precondition set:** List the preconditions under which “An operator can reconstruct why a placement was made” must hold for “Placement explanations”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C073-T04 · Transition coverage:** Map the “Placement explanations” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Placement explanations”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C073-T06 · Satisfying fixture:** Create a concrete “Placement explanations” case that satisfies “An operator can reconstruct why a placement was made”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C073-T07 · Violating fixture:** Create the source counterexample “Placement records contain only a final backend name” for “Placement explanations”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C073-T08 · Enforcement evidence:** Exercise the “Placement explanations” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C073-T09 · Regression linkage:** Link the “Placement explanations” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Placement explanations” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C074 · Integration

**Original checklist item:** Integrate placement explanations with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Placement explanations” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C074-T02 · Field mapping:** Map every “Placement explanations” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Placement explanations” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C074-T04 · Ownership agreement:** Specify who owns “Placement explanations” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C074-T05 · Handoff implementation:** Connect “Placement explanations” through the mapped seam using the real adapter or explicit specification reference; preserve “An operator can reconstruct why a placement was made” across the handoff.
- [ ] **UC-M05.02-C074-T06 · Absent-input case:** Omit one required “Placement explanations” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C074-T07 · Stale-input case:** Supply an outdated “Placement explanations” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Placement explanations” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C074-T09 · Valid integration trace:** Run a valid “Placement explanations” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C074-T10 · Seam review:** Reconcile the “Placement explanations” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for placement explanations; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Placement explanations” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C075-T02 · Expected-result oracle:** Specify the “Placement explanations” expected result independently of the implementation output; include the property “An operator can reconstruct why a placement was made” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C075-T03 · Fixture material:** Create the concrete “Placement explanations” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C075-T04 · Target preparation:** Prepare the “Placement explanations” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C075-T05 · Initial-state record:** Record the initial “Placement explanations” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C075-T06 · Valid-path execution:** Execute the “Placement explanations” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C075-T07 · Outcome comparison:** Compare every declared “Placement explanations” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C075-T08 · State and bounds check:** Inspect the “Placement explanations” ownership/state effects and actual use of “Explanation bytes and candidate history”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C075-T09 · Repeatability check:** Repeat the same “Placement explanations” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C075-T10 · Positive evidence:** Attach the “Placement explanations” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C076 · Negative test

**Original checklist item:** Negative case: Placement records contain only a final backend name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Placement explanations” source counterexample: “Placement records contain only a final backend name”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Placement explanations”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C076-T03 · Valid control:** Construct a valid “Placement explanations” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C076-T04 · Minimal adverse input:** Derive the “Placement explanations” adverse fixture from the control with the smallest documented change needed to reproduce “Placement records contain only a final backend name”; retain that change as reproducible data.
- [ ] **UC-M05.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Placement explanations”; require “An operator can reconstruct why a placement was made” and forbid a false-success verdict.
- [ ] **UC-M05.02-C076-T06 · Adverse execution:** Exercise the “Placement explanations” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C076-T07 · Effect inspection:** Inspect “Placement explanations” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C076-T08 · Refusal versus failure:** Confirm the “Placement explanations” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C076-T09 · Reset and retention:** Restore only the disposable “Placement explanations” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C076-T10 · Negative regression:** Register the “Placement explanations” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C077 · Change / failure test

**Original checklist item:** Exercise placement explanations when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C077-T01 · Scenario record:** Write the “Placement explanations” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “An operator can reconstruct why a placement was made”.
- [ ] **UC-M05.02-C077-T02 · Baseline capture:** Create a known-valid “Placement explanations” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C077-T03 · Injection map:** Locate the “Placement explanations” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Placement explanations” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C077-T05 · Controlled trigger:** Introduce the controlled “Placement explanations” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C077-T06 · Intermediate inspection:** Inspect the “Placement explanations” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Placement explanations”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Placement explanations” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C077-T09 · Repeat and compare:** Repeat the selected “Placement explanations” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C077-T10 · Failure evidence:** Publish the “Placement explanations” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for explanation bytes and candidate history; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Placement explanations”: “Explanation bytes and candidate history”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C078-T02 · Measurement method:** Choose how to observe each “Placement explanations” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Placement explanations”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Placement explanations” cases for “Explanation bytes and candidate history”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Placement explanations” limit; preserve “An operator can reconstruct why a placement was made”.
- [ ] **UC-M05.02-C078-T06 · Normal measurement:** Run or review the normal “Placement explanations” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C078-T07 · At-limit measurement:** Exercise the “Placement explanations” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C078-T08 · Over-limit measurement:** Exercise the “Placement explanations” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C078-T09 · Uncovered-scope report:** List the “Placement explanations” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C078-T10 · Limit evidence:** Publish the selected “Placement explanations” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for placement explanations with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C079-T01 · Event inventory:** List the “Placement explanations” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Placement explanations” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C079-T03 · Failure mapping:** Map each documented “Placement explanations” refusal or error to a diagnostic outcome; include “Placement records contain only a final backend name” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C079-T04 · Emission path:** Add the “Placement explanations” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C079-T05 · Redaction check:** Test “Placement explanations” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C079-T06 · Output budget:** Set and exercise bounded “Placement explanations” message size, rate and retention compatible with “Explanation bytes and candidate history”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C079-T07 · Success/refusal fixtures:** Capture “Placement explanations” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Placement explanations” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C079-T09 · Operator review:** Read the “Placement explanations” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C079-T10 · Diagnostic evidence:** Publish redacted “Placement explanations” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for placement explanations; label unexecuted checks as untested.

- [ ] **UC-M05.02-C080-T01 · Evidence inventory:** List the “Placement explanations” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C080-T02 · Artifact references:** Record the exact “Placement explanations” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C080-T03 · Fixture references:** Attach the “Placement explanations” fixture IDs, input identities and oracle definition; preserve the source counterexample “Placement records contain only a final backend name” as a distinct evidence case.
- [ ] **UC-M05.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Placement explanations”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C080-T05 · Environment record:** Record the actual “Placement explanations” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C080-T06 · Expected versus observed:** Pair every “Placement explanations” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C080-T07 · Failure and limit records:** Attach “Placement explanations” change/failure and bounds evidence where required; include uncovered “Explanation bytes and candidate history” and unresolved violations of “An operator can reconstruct why a placement was made”.
- [ ] **UC-M05.02-C080-T08 · Evidence hygiene:** Check the “Placement explanations” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C080-T09 · Reproduction review:** Have the “Placement explanations” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C080-T10 · Acceptance linkage:** Link the “Placement explanations” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Capacity drift handling

**Source delivery:** Recheck critical capacity and policy constraints before execution.

**Source invariant:** A stale placement cannot start against invalidated hard requirements.

**Source negative case:** Capacity changes between reservation and guest creation.

**Source bounded quantities:** Reservation lifetime and revalidation delay.

### UC-M05.02-C081 · Contract

**Original checklist item:** Specify capacity drift handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C081-T01 · Scope statement:** Draft the operation boundary for “Capacity drift handling” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capacity drift handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C081-T03 · Output inventory:** List the outputs of “Capacity drift handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Capacity drift handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C081-T05 · Prerequisite contract:** Map “Capacity drift handling” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Capacity drift handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C081-T07 · Invariant clause:** Add a normative clause for “Capacity drift handling” that preserves “A stale placement cannot start against invalidated hard requirements”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capacity drift handling”; include the source counterexample “Capacity changes between reservation and guest creation” and the intended safe disposition.
- [ ] **UC-M05.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reservation lifetime and revalidation delay” in the “Capacity drift handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C081-T10 · Contract review:** Review the “Capacity drift handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C082 · Delivery

**Original checklist item:** Recheck critical capacity and policy constraints before execution.

- [ ] **UC-M05.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capacity drift handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C082-T02 · Change plan:** Break the source delivery for “Capacity drift handling” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Capacity drift handling” that realizes this source instruction: Recheck critical capacity and policy constraints before execution.
- [ ] **UC-M05.02-C082-T04 · Concrete realization:** Trace “Capacity drift handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capacity drift handling” needed to preserve “A stale placement cannot start against invalidated hard requirements”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C082-T06 · Dependency connection:** Connect the “Capacity drift handling” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C082-T07 · Resource behavior:** Account for “Reservation lifetime and revalidation delay” in “Capacity drift handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C082-T08 · Delivery check:** Run the smallest real “Capacity drift handling” path and its adverse fixture “Capacity changes between reservation and guest creation”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C082-T09 · Patch review:** Review the “Capacity drift handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C082-T10 · Delivery handoff:** Publish the “Capacity drift handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stale placement cannot start against invalidated hard requirements. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Capacity drift handling”; copy its required invariant exactly: “A stale placement cannot start against invalidated hard requirements”.
- [ ] **UC-M05.02-C083-T02 · Observable terms:** Define each term in the “Capacity drift handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C083-T03 · Precondition set:** List the preconditions under which “A stale placement cannot start against invalidated hard requirements” must hold for “Capacity drift handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C083-T04 · Transition coverage:** Map the “Capacity drift handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capacity drift handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C083-T06 · Satisfying fixture:** Create a concrete “Capacity drift handling” case that satisfies “A stale placement cannot start against invalidated hard requirements”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C083-T07 · Violating fixture:** Create the source counterexample “Capacity changes between reservation and guest creation” for “Capacity drift handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C083-T08 · Enforcement evidence:** Exercise the “Capacity drift handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C083-T09 · Regression linkage:** Link the “Capacity drift handling” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Capacity drift handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C084 · Integration

**Original checklist item:** Integrate capacity drift handling with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capacity drift handling” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C084-T02 · Field mapping:** Map every “Capacity drift handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Capacity drift handling” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C084-T04 · Ownership agreement:** Specify who owns “Capacity drift handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C084-T05 · Handoff implementation:** Connect “Capacity drift handling” through the mapped seam using the real adapter or explicit specification reference; preserve “A stale placement cannot start against invalidated hard requirements” across the handoff.
- [ ] **UC-M05.02-C084-T06 · Absent-input case:** Omit one required “Capacity drift handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C084-T07 · Stale-input case:** Supply an outdated “Capacity drift handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Capacity drift handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C084-T09 · Valid integration trace:** Run a valid “Capacity drift handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C084-T10 · Seam review:** Reconcile the “Capacity drift handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capacity drift handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capacity drift handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C085-T02 · Expected-result oracle:** Specify the “Capacity drift handling” expected result independently of the implementation output; include the property “A stale placement cannot start against invalidated hard requirements” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C085-T03 · Fixture material:** Create the concrete “Capacity drift handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C085-T04 · Target preparation:** Prepare the “Capacity drift handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C085-T05 · Initial-state record:** Record the initial “Capacity drift handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C085-T06 · Valid-path execution:** Execute the “Capacity drift handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C085-T07 · Outcome comparison:** Compare every declared “Capacity drift handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C085-T08 · State and bounds check:** Inspect the “Capacity drift handling” ownership/state effects and actual use of “Reservation lifetime and revalidation delay”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C085-T09 · Repeatability check:** Repeat the same “Capacity drift handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C085-T10 · Positive evidence:** Attach the “Capacity drift handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C086 · Negative test

**Original checklist item:** Negative case: Capacity changes between reservation and guest creation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Capacity drift handling” source counterexample: “Capacity changes between reservation and guest creation”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Capacity drift handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C086-T03 · Valid control:** Construct a valid “Capacity drift handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C086-T04 · Minimal adverse input:** Derive the “Capacity drift handling” adverse fixture from the control with the smallest documented change needed to reproduce “Capacity changes between reservation and guest creation”; retain that change as reproducible data.
- [ ] **UC-M05.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capacity drift handling”; require “A stale placement cannot start against invalidated hard requirements” and forbid a false-success verdict.
- [ ] **UC-M05.02-C086-T06 · Adverse execution:** Exercise the “Capacity drift handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C086-T07 · Effect inspection:** Inspect “Capacity drift handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C086-T08 · Refusal versus failure:** Confirm the “Capacity drift handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C086-T09 · Reset and retention:** Restore only the disposable “Capacity drift handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C086-T10 · Negative regression:** Register the “Capacity drift handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C087 · Change / failure test

**Original checklist item:** Exercise capacity drift handling when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C087-T01 · Scenario record:** Write the “Capacity drift handling” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “A stale placement cannot start against invalidated hard requirements”.
- [ ] **UC-M05.02-C087-T02 · Baseline capture:** Create a known-valid “Capacity drift handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C087-T03 · Injection map:** Locate the “Capacity drift handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Capacity drift handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C087-T05 · Controlled trigger:** Introduce the controlled “Capacity drift handling” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C087-T06 · Intermediate inspection:** Inspect the “Capacity drift handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capacity drift handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Capacity drift handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C087-T09 · Repeat and compare:** Repeat the selected “Capacity drift handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C087-T10 · Failure evidence:** Publish the “Capacity drift handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for reservation lifetime and revalidation delay; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Capacity drift handling”: “Reservation lifetime and revalidation delay”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C088-T02 · Measurement method:** Choose how to observe each “Capacity drift handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Capacity drift handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capacity drift handling” cases for “Reservation lifetime and revalidation delay”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capacity drift handling” limit; preserve “A stale placement cannot start against invalidated hard requirements”.
- [ ] **UC-M05.02-C088-T06 · Normal measurement:** Run or review the normal “Capacity drift handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C088-T07 · At-limit measurement:** Exercise the “Capacity drift handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C088-T08 · Over-limit measurement:** Exercise the “Capacity drift handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C088-T09 · Uncovered-scope report:** List the “Capacity drift handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C088-T10 · Limit evidence:** Publish the selected “Capacity drift handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capacity drift handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C089-T01 · Event inventory:** List the “Capacity drift handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Capacity drift handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C089-T03 · Failure mapping:** Map each documented “Capacity drift handling” refusal or error to a diagnostic outcome; include “Capacity changes between reservation and guest creation” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C089-T04 · Emission path:** Add the “Capacity drift handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C089-T05 · Redaction check:** Test “Capacity drift handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C089-T06 · Output budget:** Set and exercise bounded “Capacity drift handling” message size, rate and retention compatible with “Reservation lifetime and revalidation delay”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C089-T07 · Success/refusal fixtures:** Capture “Capacity drift handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capacity drift handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C089-T09 · Operator review:** Read the “Capacity drift handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C089-T10 · Diagnostic evidence:** Publish redacted “Capacity drift handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capacity drift handling; label unexecuted checks as untested.

- [ ] **UC-M05.02-C090-T01 · Evidence inventory:** List the “Capacity drift handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C090-T02 · Artifact references:** Record the exact “Capacity drift handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C090-T03 · Fixture references:** Attach the “Capacity drift handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “Capacity changes between reservation and guest creation” as a distinct evidence case.
- [ ] **UC-M05.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capacity drift handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C090-T05 · Environment record:** Record the actual “Capacity drift handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C090-T06 · Expected versus observed:** Pair every “Capacity drift handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C090-T07 · Failure and limit records:** Attach “Capacity drift handling” change/failure and bounds evidence where required; include uncovered “Reservation lifetime and revalidation delay” and unresolved violations of “A stale placement cannot start against invalidated hard requirements”.
- [ ] **UC-M05.02-C090-T08 · Evidence hygiene:** Check the “Capacity drift handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C090-T09 · Reproduction review:** Have the “Capacity drift handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C090-T10 · Acceptance linkage:** Link the “Capacity drift handling” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Scheduler conformance

**Source delivery:** Test feasible, infeasible and competing placements against hard constraints.

**Source invariant:** No accepted placement violates the selected ISA, quota or isolation policy.

**Source negative case:** A synthetic overload produces out-of-policy dispatch.

**Source bounded quantities:** Workload mix, candidate count and test duration.

### UC-M05.02-C091 · Contract

**Original checklist item:** Specify scheduler conformance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.02-C091-T01 · Scope statement:** Draft the operation boundary for “Scheduler conformance” within Resource-aware placement scheduler; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scheduler conformance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.02-C091-T03 · Output inventory:** List the outputs of “Scheduler conformance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Scheduler conformance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.02-C091-T05 · Prerequisite contract:** Map “Scheduler conformance” to the source component prerequisites (UC-M03.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Scheduler conformance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.02-C091-T07 · Invariant clause:** Add a normative clause for “Scheduler conformance” that preserves “No accepted placement violates the selected ISA, quota or isolation policy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scheduler conformance”; include the source counterexample “A synthetic overload produces out-of-policy dispatch” and the intended safe disposition.
- [ ] **UC-M05.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Workload mix, candidate count and test duration” in the “Scheduler conformance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.02-C091-T10 · Contract review:** Review the “Scheduler conformance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.02-C092 · Delivery

**Original checklist item:** Test feasible, infeasible and competing placements against hard constraints.

- [ ] **UC-M05.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scheduler conformance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.02-C092-T02 · Change plan:** Break the source delivery for “Scheduler conformance” into concrete edit targets and reviewable outputs; keep the UC-M05.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.02-C092-T03 · Core artifact:** Create the “Scheduler conformance” fixture or harness for this source instruction: Test feasible, infeasible and competing placements against hard constraints.
- [ ] **UC-M05.02-C092-T04 · Concrete realization:** Connect the “Scheduler conformance” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scheduler conformance” needed to preserve “No accepted placement violates the selected ISA, quota or isolation policy”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.02-C092-T06 · Dependency connection:** Connect the “Scheduler conformance” implementation to capacity observations, atomic reservations and backend requirement filters; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.02-C092-T07 · Resource behavior:** Account for “Workload mix, candidate count and test duration” in “Scheduler conformance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.02-C092-T08 · Delivery check:** Run the smallest real “Scheduler conformance” path and its adverse fixture “A synthetic overload produces out-of-policy dispatch”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.02-C092-T09 · Patch review:** Review the “Scheduler conformance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.02-C092-T10 · Delivery handoff:** Publish the “Scheduler conformance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No accepted placement violates the selected ISA, quota or isolation policy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Scheduler conformance”; copy its required invariant exactly: “No accepted placement violates the selected ISA, quota or isolation policy”.
- [ ] **UC-M05.02-C093-T02 · Observable terms:** Define each term in the “Scheduler conformance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.02-C093-T03 · Precondition set:** List the preconditions under which “No accepted placement violates the selected ISA, quota or isolation policy” must hold for “Scheduler conformance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.02-C093-T04 · Transition coverage:** Map the “Scheduler conformance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scheduler conformance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.02-C093-T06 · Satisfying fixture:** Create a concrete “Scheduler conformance” case that satisfies “No accepted placement violates the selected ISA, quota or isolation policy”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.02-C093-T07 · Violating fixture:** Create the source counterexample “A synthetic overload produces out-of-policy dispatch” for “Scheduler conformance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.02-C093-T08 · Enforcement evidence:** Exercise the “Scheduler conformance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.02-C093-T09 · Regression linkage:** Link the “Scheduler conformance” property to changes in capacity observations, atomic reservations and backend requirement filters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Scheduler conformance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.02-C094 · Integration

**Original checklist item:** Integrate scheduler conformance with capacity observations, atomic reservations and backend requirement filters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scheduler conformance” across capacity observations, atomic reservations and backend requirement filters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.02-C094-T02 · Field mapping:** Map every “Scheduler conformance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Scheduler conformance” (source dependency list: UC-M03.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.02-C094-T04 · Ownership agreement:** Specify who owns “Scheduler conformance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.02-C094-T05 · Handoff implementation:** Connect “Scheduler conformance” through the mapped seam using the real adapter or explicit specification reference; preserve “No accepted placement violates the selected ISA, quota or isolation policy” across the handoff.
- [ ] **UC-M05.02-C094-T06 · Absent-input case:** Omit one required “Scheduler conformance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.02-C094-T07 · Stale-input case:** Supply an outdated “Scheduler conformance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Scheduler conformance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.02-C094-T09 · Valid integration trace:** Run a valid “Scheduler conformance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.02-C094-T10 · Seam review:** Reconcile the “Scheduler conformance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scheduler conformance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scheduler conformance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.02-C095-T02 · Expected-result oracle:** Specify the “Scheduler conformance” expected result independently of the implementation output; include the property “No accepted placement violates the selected ISA, quota or isolation policy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.02-C095-T03 · Fixture material:** Create the concrete “Scheduler conformance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.02-C095-T04 · Target preparation:** Prepare the “Scheduler conformance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.02-C095-T05 · Initial-state record:** Record the initial “Scheduler conformance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.02-C095-T06 · Valid-path execution:** Execute the “Scheduler conformance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.02-C095-T07 · Outcome comparison:** Compare every declared “Scheduler conformance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.02-C095-T08 · State and bounds check:** Inspect the “Scheduler conformance” ownership/state effects and actual use of “Workload mix, candidate count and test duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.02-C095-T09 · Repeatability check:** Repeat the same “Scheduler conformance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.02-C095-T10 · Positive evidence:** Attach the “Scheduler conformance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.02-C096 · Negative test

**Original checklist item:** Negative case: A synthetic overload produces out-of-policy dispatch. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Scheduler conformance” source counterexample: “A synthetic overload produces out-of-policy dispatch”; state which precondition or invariant it challenges.
- [ ] **UC-M05.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Scheduler conformance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.02-C096-T03 · Valid control:** Construct a valid “Scheduler conformance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.02-C096-T04 · Minimal adverse input:** Derive the “Scheduler conformance” adverse fixture from the control with the smallest documented change needed to reproduce “A synthetic overload produces out-of-policy dispatch”; retain that change as reproducible data.
- [ ] **UC-M05.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scheduler conformance”; require “No accepted placement violates the selected ISA, quota or isolation policy” and forbid a false-success verdict.
- [ ] **UC-M05.02-C096-T06 · Adverse execution:** Exercise the “Scheduler conformance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.02-C096-T07 · Effect inspection:** Inspect “Scheduler conformance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.02-C096-T08 · Refusal versus failure:** Confirm the “Scheduler conformance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.02-C096-T09 · Reset and retention:** Restore only the disposable “Scheduler conformance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.02-C096-T10 · Negative regression:** Register the “Scheduler conformance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.02-C097 · Change / failure test

**Original checklist item:** Exercise scheduler conformance when capacity changes between selecting a placement and launching the workload; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.02-C097-T01 · Scenario record:** Write the “Scheduler conformance” change/failure scenario exactly as supplied: capacity changes between selecting a placement and launching the workload; identify the property that must remain true: “No accepted placement violates the selected ISA, quota or isolation policy”.
- [ ] **UC-M05.02-C097-T02 · Baseline capture:** Create a known-valid “Scheduler conformance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.02-C097-T03 · Injection map:** Locate the “Scheduler conformance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Scheduler conformance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.02-C097-T05 · Controlled trigger:** Introduce the controlled “Scheduler conformance” scenario in the disposable fixture: capacity changes between selecting a placement and launching the workload; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.02-C097-T06 · Intermediate inspection:** Inspect the “Scheduler conformance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scheduler conformance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Scheduler conformance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.02-C097-T09 · Repeat and compare:** Repeat the selected “Scheduler conformance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.02-C097-T10 · Failure evidence:** Publish the “Scheduler conformance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for workload mix, candidate count and test duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Scheduler conformance”: “Workload mix, candidate count and test duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.02-C098-T02 · Measurement method:** Choose how to observe each “Scheduler conformance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Scheduler conformance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scheduler conformance” cases for “Workload mix, candidate count and test duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scheduler conformance” limit; preserve “No accepted placement violates the selected ISA, quota or isolation policy”.
- [ ] **UC-M05.02-C098-T06 · Normal measurement:** Run or review the normal “Scheduler conformance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.02-C098-T07 · At-limit measurement:** Exercise the “Scheduler conformance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.02-C098-T08 · Over-limit measurement:** Exercise the “Scheduler conformance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.02-C098-T09 · Uncovered-scope report:** List the “Scheduler conformance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.02-C098-T10 · Limit evidence:** Publish the selected “Scheduler conformance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scheduler conformance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.02-C099-T01 · Event inventory:** List the “Scheduler conformance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Scheduler conformance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.02-C099-T03 · Failure mapping:** Map each documented “Scheduler conformance” refusal or error to a diagnostic outcome; include “A synthetic overload produces out-of-policy dispatch” and prohibit conversion into a success message.
- [ ] **UC-M05.02-C099-T04 · Emission path:** Add the “Scheduler conformance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.02-C099-T05 · Redaction check:** Test “Scheduler conformance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.02-C099-T06 · Output budget:** Set and exercise bounded “Scheduler conformance” message size, rate and retention compatible with “Workload mix, candidate count and test duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.02-C099-T07 · Success/refusal fixtures:** Capture “Scheduler conformance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scheduler conformance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.02-C099-T09 · Operator review:** Read the “Scheduler conformance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.02-C099-T10 · Diagnostic evidence:** Publish redacted “Scheduler conformance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scheduler conformance; label unexecuted checks as untested.

- [ ] **UC-M05.02-C100-T01 · Evidence inventory:** List the “Scheduler conformance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.02-C100-T02 · Artifact references:** Record the exact “Scheduler conformance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.02-C100-T03 · Fixture references:** Attach the “Scheduler conformance” fixture IDs, input identities and oracle definition; preserve the source counterexample “A synthetic overload produces out-of-policy dispatch” as a distinct evidence case.
- [ ] **UC-M05.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scheduler conformance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.02-C100-T05 · Environment record:** Record the actual “Scheduler conformance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.02-C100-T06 · Expected versus observed:** Pair every “Scheduler conformance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.02-C100-T07 · Failure and limit records:** Attach “Scheduler conformance” change/failure and bounds evidence where required; include uncovered “Workload mix, candidate count and test duration” and unresolved violations of “No accepted placement violates the selected ISA, quota or isolation policy”.
- [ ] **UC-M05.02-C100-T08 · Evidence hygiene:** Check the “Scheduler conformance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.02-C100-T09 · Reproduction review:** Have the “Scheduler conformance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.02-C100-T10 · Acceptance linkage:** Link the “Scheduler conformance” evidence to its parent and UC-M05.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

