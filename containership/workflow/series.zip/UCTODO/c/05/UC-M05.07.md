# UC-M05.07 — Safe restart and failure budget policy

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/05.md)

| Field | Preserved source value |
|---|---|
| Workstream | 05. Workload orchestration and scheduling |
| Milestone | C |
| Priority | P1 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M05.05](../05/UC-M05.05.md), [UC-M05.06](../05/UC-M05.06.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S6]. |

## Original requirement

Define retryable versus permanent failures, exponential backoff, restart ceilings and quarantine for deterministic crashes.

**Original acceptance criterion:** A crash loop cannot consume unbounded resources or repeatedly promote a known-bad image.

**Source trace:** Original checklist `UC100/c/05/UC-M05.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 495–505 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Failure classification

**Source delivery:** Classify admission, boot, transient service and deterministic application failures.

**Source invariant:** Retry policy is based on explicit failure meaning.

**Source negative case:** A signature refusal is treated as a retryable transient crash.

**Source bounded quantities:** Failure classes and rule count.

### UC-M05.07-C001 · Contract

**Original checklist item:** Specify failure classification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C001-T01 · Scope statement:** Draft the operation boundary for “Failure classification” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure classification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C001-T03 · Output inventory:** List the outputs of “Failure classification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure classification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C001-T05 · Prerequisite contract:** Map “Failure classification” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Failure classification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C001-T07 · Invariant clause:** Add a normative clause for “Failure classification” that preserves “Retry policy is based on explicit failure meaning”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure classification”; include the source counterexample “A signature refusal is treated as a retryable transient crash” and the intended safe disposition.
- [ ] **UC-M05.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure classes and rule count” in the “Failure classification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C001-T10 · Contract review:** Review the “Failure classification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C002 · Delivery

**Original checklist item:** Classify admission, boot, transient service and deterministic application failures.

- [ ] **UC-M05.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure classification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C002-T02 · Change plan:** Break the source delivery for “Failure classification” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C002-T03 · Core artifact:** Create the “Failure classification” model, schema or inventory that realizes this source instruction: Classify admission, boot, transient service and deterministic application failures.
- [ ] **UC-M05.07-C002-T04 · Concrete realization:** Populate “Failure classification” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure classification” needed to preserve “Retry policy is based on explicit failure meaning”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C002-T06 · Dependency connection:** Connect the “Failure classification” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C002-T07 · Resource behavior:** Account for “Failure classes and rule count” in “Failure classification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C002-T08 · Delivery check:** Run the smallest real “Failure classification” path and its adverse fixture “A signature refusal is treated as a retryable transient crash”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C002-T09 · Patch review:** Review the “Failure classification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C002-T10 · Delivery handoff:** Publish the “Failure classification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Retry policy is based on explicit failure meaning. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Failure classification”; copy its required invariant exactly: “Retry policy is based on explicit failure meaning”.
- [ ] **UC-M05.07-C003-T02 · Observable terms:** Define each term in the “Failure classification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C003-T03 · Precondition set:** List the preconditions under which “Retry policy is based on explicit failure meaning” must hold for “Failure classification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C003-T04 · Transition coverage:** Map the “Failure classification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure classification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C003-T06 · Satisfying fixture:** Create a concrete “Failure classification” case that satisfies “Retry policy is based on explicit failure meaning”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C003-T07 · Violating fixture:** Create the source counterexample “A signature refusal is treated as a retryable transient crash” for “Failure classification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C003-T08 · Enforcement evidence:** Exercise the “Failure classification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C003-T09 · Regression linkage:** Link the “Failure classification” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Failure classification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C004 · Integration

**Original checklist item:** Integrate failure classification with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure classification” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C004-T02 · Field mapping:** Map every “Failure classification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure classification” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C004-T04 · Ownership agreement:** Specify who owns “Failure classification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C004-T05 · Handoff implementation:** Connect “Failure classification” through the mapped seam using the real adapter or explicit specification reference; preserve “Retry policy is based on explicit failure meaning” across the handoff.
- [ ] **UC-M05.07-C004-T06 · Absent-input case:** Omit one required “Failure classification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C004-T07 · Stale-input case:** Supply an outdated “Failure classification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Failure classification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C004-T09 · Valid integration trace:** Run a valid “Failure classification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C004-T10 · Seam review:** Reconcile the “Failure classification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure classification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure classification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C005-T02 · Expected-result oracle:** Specify the “Failure classification” expected result independently of the implementation output; include the property “Retry policy is based on explicit failure meaning” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C005-T03 · Fixture material:** Create the concrete “Failure classification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C005-T04 · Target preparation:** Prepare the “Failure classification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C005-T05 · Initial-state record:** Record the initial “Failure classification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C005-T06 · Valid-path execution:** Execute the “Failure classification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C005-T07 · Outcome comparison:** Compare every declared “Failure classification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C005-T08 · State and bounds check:** Inspect the “Failure classification” ownership/state effects and actual use of “Failure classes and rule count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C005-T09 · Repeatability check:** Repeat the same “Failure classification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C005-T10 · Positive evidence:** Attach the “Failure classification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C006 · Negative test

**Original checklist item:** Negative case: A signature refusal is treated as a retryable transient crash. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Failure classification” source counterexample: “A signature refusal is treated as a retryable transient crash”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure classification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C006-T03 · Valid control:** Construct a valid “Failure classification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C006-T04 · Minimal adverse input:** Derive the “Failure classification” adverse fixture from the control with the smallest documented change needed to reproduce “A signature refusal is treated as a retryable transient crash”; retain that change as reproducible data.
- [ ] **UC-M05.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure classification”; require “Retry policy is based on explicit failure meaning” and forbid a false-success verdict.
- [ ] **UC-M05.07-C006-T06 · Adverse execution:** Exercise the “Failure classification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C006-T07 · Effect inspection:** Inspect “Failure classification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C006-T08 · Refusal versus failure:** Confirm the “Failure classification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C006-T09 · Reset and retention:** Restore only the disposable “Failure classification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C006-T10 · Negative regression:** Register the “Failure classification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C007 · Change / failure test

**Original checklist item:** Exercise failure classification when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C007-T01 · Scenario record:** Write the “Failure classification” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “Retry policy is based on explicit failure meaning”.
- [ ] **UC-M05.07-C007-T02 · Baseline capture:** Create a known-valid “Failure classification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C007-T03 · Injection map:** Locate the “Failure classification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Failure classification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C007-T05 · Controlled trigger:** Introduce the controlled “Failure classification” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C007-T06 · Intermediate inspection:** Inspect the “Failure classification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure classification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure classification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C007-T09 · Repeat and compare:** Repeat the selected “Failure classification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C007-T10 · Failure evidence:** Publish the “Failure classification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for failure classes and rule count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Failure classification”: “Failure classes and rule count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C008-T02 · Measurement method:** Choose how to observe each “Failure classification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Failure classification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure classification” cases for “Failure classes and rule count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure classification” limit; preserve “Retry policy is based on explicit failure meaning”.
- [ ] **UC-M05.07-C008-T06 · Normal measurement:** Run or review the normal “Failure classification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C008-T07 · At-limit measurement:** Exercise the “Failure classification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C008-T08 · Over-limit measurement:** Exercise the “Failure classification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C008-T09 · Uncovered-scope report:** List the “Failure classification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C008-T10 · Limit evidence:** Publish the selected “Failure classification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure classification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C009-T01 · Event inventory:** List the “Failure classification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Failure classification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C009-T03 · Failure mapping:** Map each documented “Failure classification” refusal or error to a diagnostic outcome; include “A signature refusal is treated as a retryable transient crash” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C009-T04 · Emission path:** Add the “Failure classification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C009-T05 · Redaction check:** Test “Failure classification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C009-T06 · Output budget:** Set and exercise bounded “Failure classification” message size, rate and retention compatible with “Failure classes and rule count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C009-T07 · Success/refusal fixtures:** Capture “Failure classification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure classification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C009-T09 · Operator review:** Read the “Failure classification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C009-T10 · Diagnostic evidence:** Publish redacted “Failure classification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure classification; label unexecuted checks as untested.

- [ ] **UC-M05.07-C010-T01 · Evidence inventory:** List the “Failure classification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C010-T02 · Artifact references:** Record the exact “Failure classification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C010-T03 · Fixture references:** Attach the “Failure classification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A signature refusal is treated as a retryable transient crash” as a distinct evidence case.
- [ ] **UC-M05.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure classification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C010-T05 · Environment record:** Record the actual “Failure classification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C010-T06 · Expected versus observed:** Pair every “Failure classification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C010-T07 · Failure and limit records:** Attach “Failure classification” change/failure and bounds evidence where required; include uncovered “Failure classes and rule count” and unresolved violations of “Retry policy is based on explicit failure meaning”.
- [ ] **UC-M05.07-C010-T08 · Evidence hygiene:** Check the “Failure classification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C010-T09 · Reproduction review:** Have the “Failure classification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C010-T10 · Acceptance linkage:** Link the “Failure classification” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Retry eligibility

**Source delivery:** Define which failures may trigger restart and under what evidence.

**Source invariant:** Permanent unsafe failures do not restart automatically.

**Source negative case:** A known-bad image is retried after every deterministic panic.

**Source bounded quantities:** Eligibility checks and retained failure history.

### UC-M05.07-C011 · Contract

**Original checklist item:** Specify retry eligibility inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C011-T01 · Scope statement:** Draft the operation boundary for “Retry eligibility” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Retry eligibility”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C011-T03 · Output inventory:** List the outputs of “Retry eligibility” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Retry eligibility”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C011-T05 · Prerequisite contract:** Map “Retry eligibility” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Retry eligibility”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C011-T07 · Invariant clause:** Add a normative clause for “Retry eligibility” that preserves “Permanent unsafe failures do not restart automatically”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Retry eligibility”; include the source counterexample “A known-bad image is retried after every deterministic panic” and the intended safe disposition.
- [ ] **UC-M05.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Eligibility checks and retained failure history” in the “Retry eligibility” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C011-T10 · Contract review:** Review the “Retry eligibility” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C012 · Delivery

**Original checklist item:** Define which failures may trigger restart and under what evidence.

- [ ] **UC-M05.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Retry eligibility”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C012-T02 · Change plan:** Break the source delivery for “Retry eligibility” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C012-T03 · Core artifact:** Create the “Retry eligibility” model, schema or inventory that realizes this source instruction: Define which failures may trigger restart and under what evidence.
- [ ] **UC-M05.07-C012-T04 · Concrete realization:** Populate “Retry eligibility” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Retry eligibility” needed to preserve “Permanent unsafe failures do not restart automatically”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C012-T06 · Dependency connection:** Connect the “Retry eligibility” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C012-T07 · Resource behavior:** Account for “Eligibility checks and retained failure history” in “Retry eligibility”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C012-T08 · Delivery check:** Run the smallest real “Retry eligibility” path and its adverse fixture “A known-bad image is retried after every deterministic panic”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C012-T09 · Patch review:** Review the “Retry eligibility” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C012-T10 · Delivery handoff:** Publish the “Retry eligibility” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Permanent unsafe failures do not restart automatically. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Retry eligibility”; copy its required invariant exactly: “Permanent unsafe failures do not restart automatically”.
- [ ] **UC-M05.07-C013-T02 · Observable terms:** Define each term in the “Retry eligibility” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C013-T03 · Precondition set:** List the preconditions under which “Permanent unsafe failures do not restart automatically” must hold for “Retry eligibility”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C013-T04 · Transition coverage:** Map the “Retry eligibility” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Retry eligibility”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C013-T06 · Satisfying fixture:** Create a concrete “Retry eligibility” case that satisfies “Permanent unsafe failures do not restart automatically”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C013-T07 · Violating fixture:** Create the source counterexample “A known-bad image is retried after every deterministic panic” for “Retry eligibility”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C013-T08 · Enforcement evidence:** Exercise the “Retry eligibility” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C013-T09 · Regression linkage:** Link the “Retry eligibility” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Retry eligibility” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C014 · Integration

**Original checklist item:** Integrate retry eligibility with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Retry eligibility” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C014-T02 · Field mapping:** Map every “Retry eligibility” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Retry eligibility” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C014-T04 · Ownership agreement:** Specify who owns “Retry eligibility” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C014-T05 · Handoff implementation:** Connect “Retry eligibility” through the mapped seam using the real adapter or explicit specification reference; preserve “Permanent unsafe failures do not restart automatically” across the handoff.
- [ ] **UC-M05.07-C014-T06 · Absent-input case:** Omit one required “Retry eligibility” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C014-T07 · Stale-input case:** Supply an outdated “Retry eligibility” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Retry eligibility” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C014-T09 · Valid integration trace:** Run a valid “Retry eligibility” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C014-T10 · Seam review:** Reconcile the “Retry eligibility” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for retry eligibility; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Retry eligibility” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C015-T02 · Expected-result oracle:** Specify the “Retry eligibility” expected result independently of the implementation output; include the property “Permanent unsafe failures do not restart automatically” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C015-T03 · Fixture material:** Create the concrete “Retry eligibility” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C015-T04 · Target preparation:** Prepare the “Retry eligibility” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C015-T05 · Initial-state record:** Record the initial “Retry eligibility” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C015-T06 · Valid-path execution:** Execute the “Retry eligibility” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C015-T07 · Outcome comparison:** Compare every declared “Retry eligibility” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C015-T08 · State and bounds check:** Inspect the “Retry eligibility” ownership/state effects and actual use of “Eligibility checks and retained failure history”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C015-T09 · Repeatability check:** Repeat the same “Retry eligibility” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C015-T10 · Positive evidence:** Attach the “Retry eligibility” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C016 · Negative test

**Original checklist item:** Negative case: A known-bad image is retried after every deterministic panic. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Retry eligibility” source counterexample: “A known-bad image is retried after every deterministic panic”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Retry eligibility”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C016-T03 · Valid control:** Construct a valid “Retry eligibility” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C016-T04 · Minimal adverse input:** Derive the “Retry eligibility” adverse fixture from the control with the smallest documented change needed to reproduce “A known-bad image is retried after every deterministic panic”; retain that change as reproducible data.
- [ ] **UC-M05.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Retry eligibility”; require “Permanent unsafe failures do not restart automatically” and forbid a false-success verdict.
- [ ] **UC-M05.07-C016-T06 · Adverse execution:** Exercise the “Retry eligibility” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C016-T07 · Effect inspection:** Inspect “Retry eligibility” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C016-T08 · Refusal versus failure:** Confirm the “Retry eligibility” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C016-T09 · Reset and retention:** Restore only the disposable “Retry eligibility” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C016-T10 · Negative regression:** Register the “Retry eligibility” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C017 · Change / failure test

**Original checklist item:** Exercise retry eligibility when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C017-T01 · Scenario record:** Write the “Retry eligibility” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “Permanent unsafe failures do not restart automatically”.
- [ ] **UC-M05.07-C017-T02 · Baseline capture:** Create a known-valid “Retry eligibility” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C017-T03 · Injection map:** Locate the “Retry eligibility” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Retry eligibility” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C017-T05 · Controlled trigger:** Introduce the controlled “Retry eligibility” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C017-T06 · Intermediate inspection:** Inspect the “Retry eligibility” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Retry eligibility”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Retry eligibility” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C017-T09 · Repeat and compare:** Repeat the selected “Retry eligibility” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C017-T10 · Failure evidence:** Publish the “Retry eligibility” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for eligibility checks and retained failure history; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Retry eligibility”: “Eligibility checks and retained failure history”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C018-T02 · Measurement method:** Choose how to observe each “Retry eligibility” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Retry eligibility”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Retry eligibility” cases for “Eligibility checks and retained failure history”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Retry eligibility” limit; preserve “Permanent unsafe failures do not restart automatically”.
- [ ] **UC-M05.07-C018-T06 · Normal measurement:** Run or review the normal “Retry eligibility” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C018-T07 · At-limit measurement:** Exercise the “Retry eligibility” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C018-T08 · Over-limit measurement:** Exercise the “Retry eligibility” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C018-T09 · Uncovered-scope report:** List the “Retry eligibility” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C018-T10 · Limit evidence:** Publish the selected “Retry eligibility” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for retry eligibility with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C019-T01 · Event inventory:** List the “Retry eligibility” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Retry eligibility” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C019-T03 · Failure mapping:** Map each documented “Retry eligibility” refusal or error to a diagnostic outcome; include “A known-bad image is retried after every deterministic panic” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C019-T04 · Emission path:** Add the “Retry eligibility” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C019-T05 · Redaction check:** Test “Retry eligibility” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C019-T06 · Output budget:** Set and exercise bounded “Retry eligibility” message size, rate and retention compatible with “Eligibility checks and retained failure history”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C019-T07 · Success/refusal fixtures:** Capture “Retry eligibility” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Retry eligibility” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C019-T09 · Operator review:** Read the “Retry eligibility” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C019-T10 · Diagnostic evidence:** Publish redacted “Retry eligibility” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for retry eligibility; label unexecuted checks as untested.

- [ ] **UC-M05.07-C020-T01 · Evidence inventory:** List the “Retry eligibility” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C020-T02 · Artifact references:** Record the exact “Retry eligibility” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C020-T03 · Fixture references:** Attach the “Retry eligibility” fixture IDs, input identities and oracle definition; preserve the source counterexample “A known-bad image is retried after every deterministic panic” as a distinct evidence case.
- [ ] **UC-M05.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Retry eligibility”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C020-T05 · Environment record:** Record the actual “Retry eligibility” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C020-T06 · Expected versus observed:** Pair every “Retry eligibility” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C020-T07 · Failure and limit records:** Attach “Retry eligibility” change/failure and bounds evidence where required; include uncovered “Eligibility checks and retained failure history” and unresolved violations of “Permanent unsafe failures do not restart automatically”.
- [ ] **UC-M05.07-C020-T08 · Evidence hygiene:** Check the “Retry eligibility” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C020-T09 · Reproduction review:** Have the “Retry eligibility” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C020-T10 · Acceptance linkage:** Link the “Retry eligibility” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Backoff policy

**Source delivery:** Apply bounded exponential or another explicitly selected retry backoff.

**Source invariant:** Restart timing cannot collapse into a tight crash loop.

**Source negative case:** Repeated immediate exits cause unrestricted rapid relaunches.

**Source bounded quantities:** Minimum delay, maximum delay and retry count.

### UC-M05.07-C021 · Contract

**Original checklist item:** Specify backoff policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C021-T01 · Scope statement:** Draft the operation boundary for “Backoff policy” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backoff policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C021-T03 · Output inventory:** List the outputs of “Backoff policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Backoff policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C021-T05 · Prerequisite contract:** Map “Backoff policy” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Backoff policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C021-T07 · Invariant clause:** Add a normative clause for “Backoff policy” that preserves “Restart timing cannot collapse into a tight crash loop”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backoff policy”; include the source counterexample “Repeated immediate exits cause unrestricted rapid relaunches” and the intended safe disposition.
- [ ] **UC-M05.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Minimum delay, maximum delay and retry count” in the “Backoff policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C021-T10 · Contract review:** Review the “Backoff policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C022 · Delivery

**Original checklist item:** Apply bounded exponential or another explicitly selected retry backoff.

- [ ] **UC-M05.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backoff policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C022-T02 · Change plan:** Break the source delivery for “Backoff policy” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Backoff policy” that realizes this source instruction: Apply bounded exponential or another explicitly selected retry backoff.
- [ ] **UC-M05.07-C022-T04 · Concrete realization:** Trace “Backoff policy” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backoff policy” needed to preserve “Restart timing cannot collapse into a tight crash loop”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C022-T06 · Dependency connection:** Connect the “Backoff policy” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C022-T07 · Resource behavior:** Account for “Minimum delay, maximum delay and retry count” in “Backoff policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C022-T08 · Delivery check:** Run the smallest real “Backoff policy” path and its adverse fixture “Repeated immediate exits cause unrestricted rapid relaunches”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C022-T09 · Patch review:** Review the “Backoff policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C022-T10 · Delivery handoff:** Publish the “Backoff policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restart timing cannot collapse into a tight crash loop. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Backoff policy”; copy its required invariant exactly: “Restart timing cannot collapse into a tight crash loop”.
- [ ] **UC-M05.07-C023-T02 · Observable terms:** Define each term in the “Backoff policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C023-T03 · Precondition set:** List the preconditions under which “Restart timing cannot collapse into a tight crash loop” must hold for “Backoff policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C023-T04 · Transition coverage:** Map the “Backoff policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backoff policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C023-T06 · Satisfying fixture:** Create a concrete “Backoff policy” case that satisfies “Restart timing cannot collapse into a tight crash loop”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C023-T07 · Violating fixture:** Create the source counterexample “Repeated immediate exits cause unrestricted rapid relaunches” for “Backoff policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C023-T08 · Enforcement evidence:** Exercise the “Backoff policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C023-T09 · Regression linkage:** Link the “Backoff policy” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Backoff policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C024 · Integration

**Original checklist item:** Integrate backoff policy with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backoff policy” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C024-T02 · Field mapping:** Map every “Backoff policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Backoff policy” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C024-T04 · Ownership agreement:** Specify who owns “Backoff policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C024-T05 · Handoff implementation:** Connect “Backoff policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Restart timing cannot collapse into a tight crash loop” across the handoff.
- [ ] **UC-M05.07-C024-T06 · Absent-input case:** Omit one required “Backoff policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C024-T07 · Stale-input case:** Supply an outdated “Backoff policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Backoff policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C024-T09 · Valid integration trace:** Run a valid “Backoff policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C024-T10 · Seam review:** Reconcile the “Backoff policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for backoff policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Backoff policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C025-T02 · Expected-result oracle:** Specify the “Backoff policy” expected result independently of the implementation output; include the property “Restart timing cannot collapse into a tight crash loop” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C025-T03 · Fixture material:** Create the concrete “Backoff policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C025-T04 · Target preparation:** Prepare the “Backoff policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C025-T05 · Initial-state record:** Record the initial “Backoff policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C025-T06 · Valid-path execution:** Execute the “Backoff policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C025-T07 · Outcome comparison:** Compare every declared “Backoff policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C025-T08 · State and bounds check:** Inspect the “Backoff policy” ownership/state effects and actual use of “Minimum delay, maximum delay and retry count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C025-T09 · Repeatability check:** Repeat the same “Backoff policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C025-T10 · Positive evidence:** Attach the “Backoff policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C026 · Negative test

**Original checklist item:** Negative case: Repeated immediate exits cause unrestricted rapid relaunches. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Backoff policy” source counterexample: “Repeated immediate exits cause unrestricted rapid relaunches”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Backoff policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C026-T03 · Valid control:** Construct a valid “Backoff policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C026-T04 · Minimal adverse input:** Derive the “Backoff policy” adverse fixture from the control with the smallest documented change needed to reproduce “Repeated immediate exits cause unrestricted rapid relaunches”; retain that change as reproducible data.
- [ ] **UC-M05.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backoff policy”; require “Restart timing cannot collapse into a tight crash loop” and forbid a false-success verdict.
- [ ] **UC-M05.07-C026-T06 · Adverse execution:** Exercise the “Backoff policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C026-T07 · Effect inspection:** Inspect “Backoff policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C026-T08 · Refusal versus failure:** Confirm the “Backoff policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C026-T09 · Reset and retention:** Restore only the disposable “Backoff policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C026-T10 · Negative regression:** Register the “Backoff policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C027 · Change / failure test

**Original checklist item:** Exercise backoff policy when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C027-T01 · Scenario record:** Write the “Backoff policy” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “Restart timing cannot collapse into a tight crash loop”.
- [ ] **UC-M05.07-C027-T02 · Baseline capture:** Create a known-valid “Backoff policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C027-T03 · Injection map:** Locate the “Backoff policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Backoff policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C027-T05 · Controlled trigger:** Introduce the controlled “Backoff policy” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C027-T06 · Intermediate inspection:** Inspect the “Backoff policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backoff policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Backoff policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C027-T09 · Repeat and compare:** Repeat the selected “Backoff policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C027-T10 · Failure evidence:** Publish the “Backoff policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for minimum delay, maximum delay and retry count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Backoff policy”: “Minimum delay, maximum delay and retry count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C028-T02 · Measurement method:** Choose how to observe each “Backoff policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Backoff policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backoff policy” cases for “Minimum delay, maximum delay and retry count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backoff policy” limit; preserve “Restart timing cannot collapse into a tight crash loop”.
- [ ] **UC-M05.07-C028-T06 · Normal measurement:** Run or review the normal “Backoff policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C028-T07 · At-limit measurement:** Exercise the “Backoff policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C028-T08 · Over-limit measurement:** Exercise the “Backoff policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C028-T09 · Uncovered-scope report:** List the “Backoff policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C028-T10 · Limit evidence:** Publish the selected “Backoff policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for backoff policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C029-T01 · Event inventory:** List the “Backoff policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Backoff policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C029-T03 · Failure mapping:** Map each documented “Backoff policy” refusal or error to a diagnostic outcome; include “Repeated immediate exits cause unrestricted rapid relaunches” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C029-T04 · Emission path:** Add the “Backoff policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C029-T05 · Redaction check:** Test “Backoff policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C029-T06 · Output budget:** Set and exercise bounded “Backoff policy” message size, rate and retention compatible with “Minimum delay, maximum delay and retry count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C029-T07 · Success/refusal fixtures:** Capture “Backoff policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Backoff policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C029-T09 · Operator review:** Read the “Backoff policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C029-T10 · Diagnostic evidence:** Publish redacted “Backoff policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backoff policy; label unexecuted checks as untested.

- [ ] **UC-M05.07-C030-T01 · Evidence inventory:** List the “Backoff policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C030-T02 · Artifact references:** Record the exact “Backoff policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C030-T03 · Fixture references:** Attach the “Backoff policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “Repeated immediate exits cause unrestricted rapid relaunches” as a distinct evidence case.
- [ ] **UC-M05.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backoff policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C030-T05 · Environment record:** Record the actual “Backoff policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C030-T06 · Expected versus observed:** Pair every “Backoff policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C030-T07 · Failure and limit records:** Attach “Backoff policy” change/failure and bounds evidence where required; include uncovered “Minimum delay, maximum delay and retry count” and unresolved violations of “Restart timing cannot collapse into a tight crash loop”.
- [ ] **UC-M05.07-C030-T08 · Evidence hygiene:** Check the “Backoff policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C030-T09 · Reproduction review:** Have the “Backoff policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C030-T10 · Acceptance linkage:** Link the “Backoff policy” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Restart ceilings

**Source delivery:** Limit retries per workload, image and relevant time window.

**Source invariant:** A crashing image cannot consume unbounded restart resources.

**Source negative case:** Changing display names bypasses a per-name retry limit.

**Source bounded quantities:** Restart budget and accounting window.

### UC-M05.07-C031 · Contract

**Original checklist item:** Specify restart ceilings inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C031-T01 · Scope statement:** Draft the operation boundary for “Restart ceilings” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restart ceilings”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C031-T03 · Output inventory:** List the outputs of “Restart ceilings” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Restart ceilings”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C031-T05 · Prerequisite contract:** Map “Restart ceilings” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Restart ceilings”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C031-T07 · Invariant clause:** Add a normative clause for “Restart ceilings” that preserves “A crashing image cannot consume unbounded restart resources”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restart ceilings”; include the source counterexample “Changing display names bypasses a per-name retry limit” and the intended safe disposition.
- [ ] **UC-M05.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Restart budget and accounting window” in the “Restart ceilings” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C031-T10 · Contract review:** Review the “Restart ceilings” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C032 · Delivery

**Original checklist item:** Limit retries per workload, image and relevant time window.

- [ ] **UC-M05.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restart ceilings”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C032-T02 · Change plan:** Break the source delivery for “Restart ceilings” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Restart ceilings” that realizes this source instruction: Limit retries per workload, image and relevant time window.
- [ ] **UC-M05.07-C032-T04 · Concrete realization:** Trace “Restart ceilings” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restart ceilings” needed to preserve “A crashing image cannot consume unbounded restart resources”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C032-T06 · Dependency connection:** Connect the “Restart ceilings” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C032-T07 · Resource behavior:** Account for “Restart budget and accounting window” in “Restart ceilings”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C032-T08 · Delivery check:** Run the smallest real “Restart ceilings” path and its adverse fixture “Changing display names bypasses a per-name retry limit”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C032-T09 · Patch review:** Review the “Restart ceilings” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C032-T10 · Delivery handoff:** Publish the “Restart ceilings” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A crashing image cannot consume unbounded restart resources. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Restart ceilings”; copy its required invariant exactly: “A crashing image cannot consume unbounded restart resources”.
- [ ] **UC-M05.07-C033-T02 · Observable terms:** Define each term in the “Restart ceilings” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C033-T03 · Precondition set:** List the preconditions under which “A crashing image cannot consume unbounded restart resources” must hold for “Restart ceilings”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C033-T04 · Transition coverage:** Map the “Restart ceilings” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restart ceilings”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C033-T06 · Satisfying fixture:** Create a concrete “Restart ceilings” case that satisfies “A crashing image cannot consume unbounded restart resources”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C033-T07 · Violating fixture:** Create the source counterexample “Changing display names bypasses a per-name retry limit” for “Restart ceilings”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C033-T08 · Enforcement evidence:** Exercise the “Restart ceilings” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C033-T09 · Regression linkage:** Link the “Restart ceilings” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Restart ceilings” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C034 · Integration

**Original checklist item:** Integrate restart ceilings with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restart ceilings” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C034-T02 · Field mapping:** Map every “Restart ceilings” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Restart ceilings” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C034-T04 · Ownership agreement:** Specify who owns “Restart ceilings” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C034-T05 · Handoff implementation:** Connect “Restart ceilings” through the mapped seam using the real adapter or explicit specification reference; preserve “A crashing image cannot consume unbounded restart resources” across the handoff.
- [ ] **UC-M05.07-C034-T06 · Absent-input case:** Omit one required “Restart ceilings” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C034-T07 · Stale-input case:** Supply an outdated “Restart ceilings” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Restart ceilings” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C034-T09 · Valid integration trace:** Run a valid “Restart ceilings” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C034-T10 · Seam review:** Reconcile the “Restart ceilings” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restart ceilings; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restart ceilings” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C035-T02 · Expected-result oracle:** Specify the “Restart ceilings” expected result independently of the implementation output; include the property “A crashing image cannot consume unbounded restart resources” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C035-T03 · Fixture material:** Create the concrete “Restart ceilings” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C035-T04 · Target preparation:** Prepare the “Restart ceilings” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C035-T05 · Initial-state record:** Record the initial “Restart ceilings” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C035-T06 · Valid-path execution:** Execute the “Restart ceilings” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C035-T07 · Outcome comparison:** Compare every declared “Restart ceilings” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C035-T08 · State and bounds check:** Inspect the “Restart ceilings” ownership/state effects and actual use of “Restart budget and accounting window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C035-T09 · Repeatability check:** Repeat the same “Restart ceilings” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C035-T10 · Positive evidence:** Attach the “Restart ceilings” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C036 · Negative test

**Original checklist item:** Negative case: Changing display names bypasses a per-name retry limit. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Restart ceilings” source counterexample: “Changing display names bypasses a per-name retry limit”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Restart ceilings”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C036-T03 · Valid control:** Construct a valid “Restart ceilings” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C036-T04 · Minimal adverse input:** Derive the “Restart ceilings” adverse fixture from the control with the smallest documented change needed to reproduce “Changing display names bypasses a per-name retry limit”; retain that change as reproducible data.
- [ ] **UC-M05.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restart ceilings”; require “A crashing image cannot consume unbounded restart resources” and forbid a false-success verdict.
- [ ] **UC-M05.07-C036-T06 · Adverse execution:** Exercise the “Restart ceilings” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C036-T07 · Effect inspection:** Inspect “Restart ceilings” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C036-T08 · Refusal versus failure:** Confirm the “Restart ceilings” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C036-T09 · Reset and retention:** Restore only the disposable “Restart ceilings” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C036-T10 · Negative regression:** Register the “Restart ceilings” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C037 · Change / failure test

**Original checklist item:** Exercise restart ceilings when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C037-T01 · Scenario record:** Write the “Restart ceilings” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “A crashing image cannot consume unbounded restart resources”.
- [ ] **UC-M05.07-C037-T02 · Baseline capture:** Create a known-valid “Restart ceilings” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C037-T03 · Injection map:** Locate the “Restart ceilings” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Restart ceilings” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C037-T05 · Controlled trigger:** Introduce the controlled “Restart ceilings” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C037-T06 · Intermediate inspection:** Inspect the “Restart ceilings” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restart ceilings”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Restart ceilings” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C037-T09 · Repeat and compare:** Repeat the selected “Restart ceilings” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C037-T10 · Failure evidence:** Publish the “Restart ceilings” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for restart budget and accounting window; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Restart ceilings”: “Restart budget and accounting window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C038-T02 · Measurement method:** Choose how to observe each “Restart ceilings” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Restart ceilings”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restart ceilings” cases for “Restart budget and accounting window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restart ceilings” limit; preserve “A crashing image cannot consume unbounded restart resources”.
- [ ] **UC-M05.07-C038-T06 · Normal measurement:** Run or review the normal “Restart ceilings” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C038-T07 · At-limit measurement:** Exercise the “Restart ceilings” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C038-T08 · Over-limit measurement:** Exercise the “Restart ceilings” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C038-T09 · Uncovered-scope report:** List the “Restart ceilings” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C038-T10 · Limit evidence:** Publish the selected “Restart ceilings” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restart ceilings with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C039-T01 · Event inventory:** List the “Restart ceilings” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Restart ceilings” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C039-T03 · Failure mapping:** Map each documented “Restart ceilings” refusal or error to a diagnostic outcome; include “Changing display names bypasses a per-name retry limit” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C039-T04 · Emission path:** Add the “Restart ceilings” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C039-T05 · Redaction check:** Test “Restart ceilings” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C039-T06 · Output budget:** Set and exercise bounded “Restart ceilings” message size, rate and retention compatible with “Restart budget and accounting window”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C039-T07 · Success/refusal fixtures:** Capture “Restart ceilings” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restart ceilings” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C039-T09 · Operator review:** Read the “Restart ceilings” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C039-T10 · Diagnostic evidence:** Publish redacted “Restart ceilings” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restart ceilings; label unexecuted checks as untested.

- [ ] **UC-M05.07-C040-T01 · Evidence inventory:** List the “Restart ceilings” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C040-T02 · Artifact references:** Record the exact “Restart ceilings” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C040-T03 · Fixture references:** Attach the “Restart ceilings” fixture IDs, input identities and oracle definition; preserve the source counterexample “Changing display names bypasses a per-name retry limit” as a distinct evidence case.
- [ ] **UC-M05.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restart ceilings”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C040-T05 · Environment record:** Record the actual “Restart ceilings” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C040-T06 · Expected versus observed:** Pair every “Restart ceilings” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C040-T07 · Failure and limit records:** Attach “Restart ceilings” change/failure and bounds evidence where required; include uncovered “Restart budget and accounting window” and unresolved violations of “A crashing image cannot consume unbounded restart resources”.
- [ ] **UC-M05.07-C040-T08 · Evidence hygiene:** Check the “Restart ceilings” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C040-T09 · Reproduction review:** Have the “Restart ceilings” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C040-T10 · Acceptance linkage:** Link the “Restart ceilings” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Failure budget persistence

**Source delivery:** Persist consumed restart budget across controller restarts.

**Source invariant:** Restarting the controller does not reset safety ceilings accidentally.

**Source negative case:** A crash loop continues indefinitely through controller restarts.

**Source bounded quantities:** Budget records and recovery scan time.

### UC-M05.07-C041 · Contract

**Original checklist item:** Specify failure budget persistence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C041-T01 · Scope statement:** Draft the operation boundary for “Failure budget persistence” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure budget persistence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C041-T03 · Output inventory:** List the outputs of “Failure budget persistence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure budget persistence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C041-T05 · Prerequisite contract:** Map “Failure budget persistence” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Failure budget persistence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C041-T07 · Invariant clause:** Add a normative clause for “Failure budget persistence” that preserves “Restarting the controller does not reset safety ceilings accidentally”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure budget persistence”; include the source counterexample “A crash loop continues indefinitely through controller restarts” and the intended safe disposition.
- [ ] **UC-M05.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Budget records and recovery scan time” in the “Failure budget persistence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C041-T10 · Contract review:** Review the “Failure budget persistence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C042 · Delivery

**Original checklist item:** Persist consumed restart budget across controller restarts.

- [ ] **UC-M05.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure budget persistence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C042-T02 · Change plan:** Break the source delivery for “Failure budget persistence” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Failure budget persistence” that realizes this source instruction: Persist consumed restart budget across controller restarts.
- [ ] **UC-M05.07-C042-T04 · Concrete realization:** Trace “Failure budget persistence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure budget persistence” needed to preserve “Restarting the controller does not reset safety ceilings accidentally”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C042-T06 · Dependency connection:** Connect the “Failure budget persistence” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C042-T07 · Resource behavior:** Account for “Budget records and recovery scan time” in “Failure budget persistence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C042-T08 · Delivery check:** Run the smallest real “Failure budget persistence” path and its adverse fixture “A crash loop continues indefinitely through controller restarts”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C042-T09 · Patch review:** Review the “Failure budget persistence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C042-T10 · Delivery handoff:** Publish the “Failure budget persistence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restarting the controller does not reset safety ceilings accidentally. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Failure budget persistence”; copy its required invariant exactly: “Restarting the controller does not reset safety ceilings accidentally”.
- [ ] **UC-M05.07-C043-T02 · Observable terms:** Define each term in the “Failure budget persistence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C043-T03 · Precondition set:** List the preconditions under which “Restarting the controller does not reset safety ceilings accidentally” must hold for “Failure budget persistence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C043-T04 · Transition coverage:** Map the “Failure budget persistence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure budget persistence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C043-T06 · Satisfying fixture:** Create a concrete “Failure budget persistence” case that satisfies “Restarting the controller does not reset safety ceilings accidentally”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C043-T07 · Violating fixture:** Create the source counterexample “A crash loop continues indefinitely through controller restarts” for “Failure budget persistence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C043-T08 · Enforcement evidence:** Exercise the “Failure budget persistence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C043-T09 · Regression linkage:** Link the “Failure budget persistence” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Failure budget persistence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C044 · Integration

**Original checklist item:** Integrate failure budget persistence with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure budget persistence” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C044-T02 · Field mapping:** Map every “Failure budget persistence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure budget persistence” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C044-T04 · Ownership agreement:** Specify who owns “Failure budget persistence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C044-T05 · Handoff implementation:** Connect “Failure budget persistence” through the mapped seam using the real adapter or explicit specification reference; preserve “Restarting the controller does not reset safety ceilings accidentally” across the handoff.
- [ ] **UC-M05.07-C044-T06 · Absent-input case:** Omit one required “Failure budget persistence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C044-T07 · Stale-input case:** Supply an outdated “Failure budget persistence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Failure budget persistence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C044-T09 · Valid integration trace:** Run a valid “Failure budget persistence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C044-T10 · Seam review:** Reconcile the “Failure budget persistence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure budget persistence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure budget persistence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C045-T02 · Expected-result oracle:** Specify the “Failure budget persistence” expected result independently of the implementation output; include the property “Restarting the controller does not reset safety ceilings accidentally” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C045-T03 · Fixture material:** Create the concrete “Failure budget persistence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C045-T04 · Target preparation:** Prepare the “Failure budget persistence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C045-T05 · Initial-state record:** Record the initial “Failure budget persistence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C045-T06 · Valid-path execution:** Execute the “Failure budget persistence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C045-T07 · Outcome comparison:** Compare every declared “Failure budget persistence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C045-T08 · State and bounds check:** Inspect the “Failure budget persistence” ownership/state effects and actual use of “Budget records and recovery scan time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C045-T09 · Repeatability check:** Repeat the same “Failure budget persistence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C045-T10 · Positive evidence:** Attach the “Failure budget persistence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C046 · Negative test

**Original checklist item:** Negative case: A crash loop continues indefinitely through controller restarts. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Failure budget persistence” source counterexample: “A crash loop continues indefinitely through controller restarts”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure budget persistence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C046-T03 · Valid control:** Construct a valid “Failure budget persistence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C046-T04 · Minimal adverse input:** Derive the “Failure budget persistence” adverse fixture from the control with the smallest documented change needed to reproduce “A crash loop continues indefinitely through controller restarts”; retain that change as reproducible data.
- [ ] **UC-M05.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure budget persistence”; require “Restarting the controller does not reset safety ceilings accidentally” and forbid a false-success verdict.
- [ ] **UC-M05.07-C046-T06 · Adverse execution:** Exercise the “Failure budget persistence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C046-T07 · Effect inspection:** Inspect “Failure budget persistence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C046-T08 · Refusal versus failure:** Confirm the “Failure budget persistence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C046-T09 · Reset and retention:** Restore only the disposable “Failure budget persistence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C046-T10 · Negative regression:** Register the “Failure budget persistence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C047 · Change / failure test

**Original checklist item:** Exercise failure budget persistence when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C047-T01 · Scenario record:** Write the “Failure budget persistence” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “Restarting the controller does not reset safety ceilings accidentally”.
- [ ] **UC-M05.07-C047-T02 · Baseline capture:** Create a known-valid “Failure budget persistence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C047-T03 · Injection map:** Locate the “Failure budget persistence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Failure budget persistence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C047-T05 · Controlled trigger:** Introduce the controlled “Failure budget persistence” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C047-T06 · Intermediate inspection:** Inspect the “Failure budget persistence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure budget persistence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure budget persistence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C047-T09 · Repeat and compare:** Repeat the selected “Failure budget persistence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C047-T10 · Failure evidence:** Publish the “Failure budget persistence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for budget records and recovery scan time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Failure budget persistence”: “Budget records and recovery scan time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C048-T02 · Measurement method:** Choose how to observe each “Failure budget persistence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Failure budget persistence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure budget persistence” cases for “Budget records and recovery scan time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure budget persistence” limit; preserve “Restarting the controller does not reset safety ceilings accidentally”.
- [ ] **UC-M05.07-C048-T06 · Normal measurement:** Run or review the normal “Failure budget persistence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C048-T07 · At-limit measurement:** Exercise the “Failure budget persistence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C048-T08 · Over-limit measurement:** Exercise the “Failure budget persistence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C048-T09 · Uncovered-scope report:** List the “Failure budget persistence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C048-T10 · Limit evidence:** Publish the selected “Failure budget persistence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure budget persistence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C049-T01 · Event inventory:** List the “Failure budget persistence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Failure budget persistence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C049-T03 · Failure mapping:** Map each documented “Failure budget persistence” refusal or error to a diagnostic outcome; include “A crash loop continues indefinitely through controller restarts” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C049-T04 · Emission path:** Add the “Failure budget persistence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C049-T05 · Redaction check:** Test “Failure budget persistence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C049-T06 · Output budget:** Set and exercise bounded “Failure budget persistence” message size, rate and retention compatible with “Budget records and recovery scan time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C049-T07 · Success/refusal fixtures:** Capture “Failure budget persistence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure budget persistence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C049-T09 · Operator review:** Read the “Failure budget persistence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C049-T10 · Diagnostic evidence:** Publish redacted “Failure budget persistence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure budget persistence; label unexecuted checks as untested.

- [ ] **UC-M05.07-C050-T01 · Evidence inventory:** List the “Failure budget persistence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C050-T02 · Artifact references:** Record the exact “Failure budget persistence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C050-T03 · Fixture references:** Attach the “Failure budget persistence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A crash loop continues indefinitely through controller restarts” as a distinct evidence case.
- [ ] **UC-M05.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure budget persistence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C050-T05 · Environment record:** Record the actual “Failure budget persistence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C050-T06 · Expected versus observed:** Pair every “Failure budget persistence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C050-T07 · Failure and limit records:** Attach “Failure budget persistence” change/failure and bounds evidence where required; include uncovered “Budget records and recovery scan time” and unresolved violations of “Restarting the controller does not reset safety ceilings accidentally”.
- [ ] **UC-M05.07-C050-T08 · Evidence hygiene:** Check the “Failure budget persistence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C050-T09 · Reproduction review:** Have the “Failure budget persistence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C050-T10 · Acceptance linkage:** Link the “Failure budget persistence” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Deterministic-crash quarantine

**Source delivery:** Quarantine repeated deterministic failures with image and input identity.

**Source invariant:** A known-bad image is not repeatedly promoted as healthy.

**Source negative case:** Identical panic evidence is ignored on every restart.

**Source bounded quantities:** Crash fingerprint count and quarantine backlog.

### UC-M05.07-C051 · Contract

**Original checklist item:** Specify deterministic-crash quarantine inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C051-T01 · Scope statement:** Draft the operation boundary for “Deterministic-crash quarantine” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Deterministic-crash quarantine”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C051-T03 · Output inventory:** List the outputs of “Deterministic-crash quarantine” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Deterministic-crash quarantine”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C051-T05 · Prerequisite contract:** Map “Deterministic-crash quarantine” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Deterministic-crash quarantine”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C051-T07 · Invariant clause:** Add a normative clause for “Deterministic-crash quarantine” that preserves “A known-bad image is not repeatedly promoted as healthy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Deterministic-crash quarantine”; include the source counterexample “Identical panic evidence is ignored on every restart” and the intended safe disposition.
- [ ] **UC-M05.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Crash fingerprint count and quarantine backlog” in the “Deterministic-crash quarantine” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C051-T10 · Contract review:** Review the “Deterministic-crash quarantine” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C052 · Delivery

**Original checklist item:** Quarantine repeated deterministic failures with image and input identity.

- [ ] **UC-M05.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Deterministic-crash quarantine”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C052-T02 · Change plan:** Break the source delivery for “Deterministic-crash quarantine” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Deterministic-crash quarantine” that realizes this source instruction: Quarantine repeated deterministic failures with image and input identity.
- [ ] **UC-M05.07-C052-T04 · Concrete realization:** Trace “Deterministic-crash quarantine” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Deterministic-crash quarantine” needed to preserve “A known-bad image is not repeatedly promoted as healthy”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C052-T06 · Dependency connection:** Connect the “Deterministic-crash quarantine” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C052-T07 · Resource behavior:** Account for “Crash fingerprint count and quarantine backlog” in “Deterministic-crash quarantine”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C052-T08 · Delivery check:** Run the smallest real “Deterministic-crash quarantine” path and its adverse fixture “Identical panic evidence is ignored on every restart”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C052-T09 · Patch review:** Review the “Deterministic-crash quarantine” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C052-T10 · Delivery handoff:** Publish the “Deterministic-crash quarantine” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A known-bad image is not repeatedly promoted as healthy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Deterministic-crash quarantine”; copy its required invariant exactly: “A known-bad image is not repeatedly promoted as healthy”.
- [ ] **UC-M05.07-C053-T02 · Observable terms:** Define each term in the “Deterministic-crash quarantine” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C053-T03 · Precondition set:** List the preconditions under which “A known-bad image is not repeatedly promoted as healthy” must hold for “Deterministic-crash quarantine”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C053-T04 · Transition coverage:** Map the “Deterministic-crash quarantine” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Deterministic-crash quarantine”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C053-T06 · Satisfying fixture:** Create a concrete “Deterministic-crash quarantine” case that satisfies “A known-bad image is not repeatedly promoted as healthy”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C053-T07 · Violating fixture:** Create the source counterexample “Identical panic evidence is ignored on every restart” for “Deterministic-crash quarantine”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C053-T08 · Enforcement evidence:** Exercise the “Deterministic-crash quarantine” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C053-T09 · Regression linkage:** Link the “Deterministic-crash quarantine” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Deterministic-crash quarantine” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C054 · Integration

**Original checklist item:** Integrate deterministic-crash quarantine with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Deterministic-crash quarantine” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C054-T02 · Field mapping:** Map every “Deterministic-crash quarantine” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Deterministic-crash quarantine” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C054-T04 · Ownership agreement:** Specify who owns “Deterministic-crash quarantine” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C054-T05 · Handoff implementation:** Connect “Deterministic-crash quarantine” through the mapped seam using the real adapter or explicit specification reference; preserve “A known-bad image is not repeatedly promoted as healthy” across the handoff.
- [ ] **UC-M05.07-C054-T06 · Absent-input case:** Omit one required “Deterministic-crash quarantine” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C054-T07 · Stale-input case:** Supply an outdated “Deterministic-crash quarantine” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Deterministic-crash quarantine” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C054-T09 · Valid integration trace:** Run a valid “Deterministic-crash quarantine” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C054-T10 · Seam review:** Reconcile the “Deterministic-crash quarantine” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for deterministic-crash quarantine; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Deterministic-crash quarantine” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C055-T02 · Expected-result oracle:** Specify the “Deterministic-crash quarantine” expected result independently of the implementation output; include the property “A known-bad image is not repeatedly promoted as healthy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C055-T03 · Fixture material:** Create the concrete “Deterministic-crash quarantine” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C055-T04 · Target preparation:** Prepare the “Deterministic-crash quarantine” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C055-T05 · Initial-state record:** Record the initial “Deterministic-crash quarantine” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C055-T06 · Valid-path execution:** Execute the “Deterministic-crash quarantine” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C055-T07 · Outcome comparison:** Compare every declared “Deterministic-crash quarantine” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C055-T08 · State and bounds check:** Inspect the “Deterministic-crash quarantine” ownership/state effects and actual use of “Crash fingerprint count and quarantine backlog”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C055-T09 · Repeatability check:** Repeat the same “Deterministic-crash quarantine” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C055-T10 · Positive evidence:** Attach the “Deterministic-crash quarantine” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C056 · Negative test

**Original checklist item:** Negative case: Identical panic evidence is ignored on every restart. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Deterministic-crash quarantine” source counterexample: “Identical panic evidence is ignored on every restart”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Deterministic-crash quarantine”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C056-T03 · Valid control:** Construct a valid “Deterministic-crash quarantine” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C056-T04 · Minimal adverse input:** Derive the “Deterministic-crash quarantine” adverse fixture from the control with the smallest documented change needed to reproduce “Identical panic evidence is ignored on every restart”; retain that change as reproducible data.
- [ ] **UC-M05.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Deterministic-crash quarantine”; require “A known-bad image is not repeatedly promoted as healthy” and forbid a false-success verdict.
- [ ] **UC-M05.07-C056-T06 · Adverse execution:** Exercise the “Deterministic-crash quarantine” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C056-T07 · Effect inspection:** Inspect “Deterministic-crash quarantine” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C056-T08 · Refusal versus failure:** Confirm the “Deterministic-crash quarantine” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C056-T09 · Reset and retention:** Restore only the disposable “Deterministic-crash quarantine” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C056-T10 · Negative regression:** Register the “Deterministic-crash quarantine” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C057 · Change / failure test

**Original checklist item:** Exercise deterministic-crash quarantine when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C057-T01 · Scenario record:** Write the “Deterministic-crash quarantine” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “A known-bad image is not repeatedly promoted as healthy”.
- [ ] **UC-M05.07-C057-T02 · Baseline capture:** Create a known-valid “Deterministic-crash quarantine” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C057-T03 · Injection map:** Locate the “Deterministic-crash quarantine” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Deterministic-crash quarantine” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C057-T05 · Controlled trigger:** Introduce the controlled “Deterministic-crash quarantine” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C057-T06 · Intermediate inspection:** Inspect the “Deterministic-crash quarantine” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Deterministic-crash quarantine”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Deterministic-crash quarantine” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C057-T09 · Repeat and compare:** Repeat the selected “Deterministic-crash quarantine” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C057-T10 · Failure evidence:** Publish the “Deterministic-crash quarantine” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for crash fingerprint count and quarantine backlog; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Deterministic-crash quarantine”: “Crash fingerprint count and quarantine backlog”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C058-T02 · Measurement method:** Choose how to observe each “Deterministic-crash quarantine” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C058-T03 · Budget decision:** Select justified resource and input limits for “Deterministic-crash quarantine”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Deterministic-crash quarantine” cases for “Crash fingerprint count and quarantine backlog”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Deterministic-crash quarantine” limit; preserve “A known-bad image is not repeatedly promoted as healthy”.
- [ ] **UC-M05.07-C058-T06 · Normal measurement:** Run or review the normal “Deterministic-crash quarantine” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C058-T07 · At-limit measurement:** Exercise the “Deterministic-crash quarantine” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C058-T08 · Over-limit measurement:** Exercise the “Deterministic-crash quarantine” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C058-T09 · Uncovered-scope report:** List the “Deterministic-crash quarantine” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C058-T10 · Limit evidence:** Publish the selected “Deterministic-crash quarantine” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for deterministic-crash quarantine with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C059-T01 · Event inventory:** List the “Deterministic-crash quarantine” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Deterministic-crash quarantine” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C059-T03 · Failure mapping:** Map each documented “Deterministic-crash quarantine” refusal or error to a diagnostic outcome; include “Identical panic evidence is ignored on every restart” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C059-T04 · Emission path:** Add the “Deterministic-crash quarantine” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C059-T05 · Redaction check:** Test “Deterministic-crash quarantine” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C059-T06 · Output budget:** Set and exercise bounded “Deterministic-crash quarantine” message size, rate and retention compatible with “Crash fingerprint count and quarantine backlog”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C059-T07 · Success/refusal fixtures:** Capture “Deterministic-crash quarantine” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Deterministic-crash quarantine” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C059-T09 · Operator review:** Read the “Deterministic-crash quarantine” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C059-T10 · Diagnostic evidence:** Publish redacted “Deterministic-crash quarantine” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for deterministic-crash quarantine; label unexecuted checks as untested.

- [ ] **UC-M05.07-C060-T01 · Evidence inventory:** List the “Deterministic-crash quarantine” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C060-T02 · Artifact references:** Record the exact “Deterministic-crash quarantine” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C060-T03 · Fixture references:** Attach the “Deterministic-crash quarantine” fixture IDs, input identities and oracle definition; preserve the source counterexample “Identical panic evidence is ignored on every restart” as a distinct evidence case.
- [ ] **UC-M05.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Deterministic-crash quarantine”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C060-T05 · Environment record:** Record the actual “Deterministic-crash quarantine” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C060-T06 · Expected versus observed:** Pair every “Deterministic-crash quarantine” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C060-T07 · Failure and limit records:** Attach “Deterministic-crash quarantine” change/failure and bounds evidence where required; include uncovered “Crash fingerprint count and quarantine backlog” and unresolved violations of “A known-bad image is not repeatedly promoted as healthy”.
- [ ] **UC-M05.07-C060-T08 · Evidence hygiene:** Check the “Deterministic-crash quarantine” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C060-T09 · Reproduction review:** Have the “Deterministic-crash quarantine” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C060-T10 · Acceptance linkage:** Link the “Deterministic-crash quarantine” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Successful-run reset policy

**Source delivery:** Specify when observed healthy execution may replenish retry budget.

**Source invariant:** A brief boot signal cannot erase a persistent failure history.

**Source negative case:** A guest emits ready and crashes before meaningful work on each restart.

**Source bounded quantities:** Healthy observation duration and reset frequency.

### UC-M05.07-C061 · Contract

**Original checklist item:** Specify successful-run reset policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C061-T01 · Scope statement:** Draft the operation boundary for “Successful-run reset policy” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Successful-run reset policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C061-T03 · Output inventory:** List the outputs of “Successful-run reset policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Successful-run reset policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C061-T05 · Prerequisite contract:** Map “Successful-run reset policy” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Successful-run reset policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C061-T07 · Invariant clause:** Add a normative clause for “Successful-run reset policy” that preserves “A brief boot signal cannot erase a persistent failure history”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Successful-run reset policy”; include the source counterexample “A guest emits ready and crashes before meaningful work on each restart” and the intended safe disposition.
- [ ] **UC-M05.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Healthy observation duration and reset frequency” in the “Successful-run reset policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C061-T10 · Contract review:** Review the “Successful-run reset policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C062 · Delivery

**Original checklist item:** Specify when observed healthy execution may replenish retry budget.

- [ ] **UC-M05.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Successful-run reset policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C062-T02 · Change plan:** Break the source delivery for “Successful-run reset policy” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C062-T03 · Core artifact:** Create the “Successful-run reset policy” model, schema or inventory that realizes this source instruction: Specify when observed healthy execution may replenish retry budget.
- [ ] **UC-M05.07-C062-T04 · Concrete realization:** Populate “Successful-run reset policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Successful-run reset policy” needed to preserve “A brief boot signal cannot erase a persistent failure history”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C062-T06 · Dependency connection:** Connect the “Successful-run reset policy” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C062-T07 · Resource behavior:** Account for “Healthy observation duration and reset frequency” in “Successful-run reset policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C062-T08 · Delivery check:** Run the smallest real “Successful-run reset policy” path and its adverse fixture “A guest emits ready and crashes before meaningful work on each restart”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C062-T09 · Patch review:** Review the “Successful-run reset policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C062-T10 · Delivery handoff:** Publish the “Successful-run reset policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A brief boot signal cannot erase a persistent failure history. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Successful-run reset policy”; copy its required invariant exactly: “A brief boot signal cannot erase a persistent failure history”.
- [ ] **UC-M05.07-C063-T02 · Observable terms:** Define each term in the “Successful-run reset policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C063-T03 · Precondition set:** List the preconditions under which “A brief boot signal cannot erase a persistent failure history” must hold for “Successful-run reset policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C063-T04 · Transition coverage:** Map the “Successful-run reset policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Successful-run reset policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C063-T06 · Satisfying fixture:** Create a concrete “Successful-run reset policy” case that satisfies “A brief boot signal cannot erase a persistent failure history”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C063-T07 · Violating fixture:** Create the source counterexample “A guest emits ready and crashes before meaningful work on each restart” for “Successful-run reset policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C063-T08 · Enforcement evidence:** Exercise the “Successful-run reset policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C063-T09 · Regression linkage:** Link the “Successful-run reset policy” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Successful-run reset policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C064 · Integration

**Original checklist item:** Integrate successful-run reset policy with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Successful-run reset policy” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C064-T02 · Field mapping:** Map every “Successful-run reset policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Successful-run reset policy” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C064-T04 · Ownership agreement:** Specify who owns “Successful-run reset policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C064-T05 · Handoff implementation:** Connect “Successful-run reset policy” through the mapped seam using the real adapter or explicit specification reference; preserve “A brief boot signal cannot erase a persistent failure history” across the handoff.
- [ ] **UC-M05.07-C064-T06 · Absent-input case:** Omit one required “Successful-run reset policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C064-T07 · Stale-input case:** Supply an outdated “Successful-run reset policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Successful-run reset policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C064-T09 · Valid integration trace:** Run a valid “Successful-run reset policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C064-T10 · Seam review:** Reconcile the “Successful-run reset policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for successful-run reset policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Successful-run reset policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C065-T02 · Expected-result oracle:** Specify the “Successful-run reset policy” expected result independently of the implementation output; include the property “A brief boot signal cannot erase a persistent failure history” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C065-T03 · Fixture material:** Create the concrete “Successful-run reset policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C065-T04 · Target preparation:** Prepare the “Successful-run reset policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C065-T05 · Initial-state record:** Record the initial “Successful-run reset policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C065-T06 · Valid-path execution:** Execute the “Successful-run reset policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C065-T07 · Outcome comparison:** Compare every declared “Successful-run reset policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C065-T08 · State and bounds check:** Inspect the “Successful-run reset policy” ownership/state effects and actual use of “Healthy observation duration and reset frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C065-T09 · Repeatability check:** Repeat the same “Successful-run reset policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C065-T10 · Positive evidence:** Attach the “Successful-run reset policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C066 · Negative test

**Original checklist item:** Negative case: A guest emits ready and crashes before meaningful work on each restart. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Successful-run reset policy” source counterexample: “A guest emits ready and crashes before meaningful work on each restart”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Successful-run reset policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C066-T03 · Valid control:** Construct a valid “Successful-run reset policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C066-T04 · Minimal adverse input:** Derive the “Successful-run reset policy” adverse fixture from the control with the smallest documented change needed to reproduce “A guest emits ready and crashes before meaningful work on each restart”; retain that change as reproducible data.
- [ ] **UC-M05.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Successful-run reset policy”; require “A brief boot signal cannot erase a persistent failure history” and forbid a false-success verdict.
- [ ] **UC-M05.07-C066-T06 · Adverse execution:** Exercise the “Successful-run reset policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C066-T07 · Effect inspection:** Inspect “Successful-run reset policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C066-T08 · Refusal versus failure:** Confirm the “Successful-run reset policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C066-T09 · Reset and retention:** Restore only the disposable “Successful-run reset policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C066-T10 · Negative regression:** Register the “Successful-run reset policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C067 · Change / failure test

**Original checklist item:** Exercise successful-run reset policy when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C067-T01 · Scenario record:** Write the “Successful-run reset policy” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “A brief boot signal cannot erase a persistent failure history”.
- [ ] **UC-M05.07-C067-T02 · Baseline capture:** Create a known-valid “Successful-run reset policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C067-T03 · Injection map:** Locate the “Successful-run reset policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Successful-run reset policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C067-T05 · Controlled trigger:** Introduce the controlled “Successful-run reset policy” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C067-T06 · Intermediate inspection:** Inspect the “Successful-run reset policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Successful-run reset policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Successful-run reset policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C067-T09 · Repeat and compare:** Repeat the selected “Successful-run reset policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C067-T10 · Failure evidence:** Publish the “Successful-run reset policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for healthy observation duration and reset frequency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Successful-run reset policy”: “Healthy observation duration and reset frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C068-T02 · Measurement method:** Choose how to observe each “Successful-run reset policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Successful-run reset policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Successful-run reset policy” cases for “Healthy observation duration and reset frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Successful-run reset policy” limit; preserve “A brief boot signal cannot erase a persistent failure history”.
- [ ] **UC-M05.07-C068-T06 · Normal measurement:** Run or review the normal “Successful-run reset policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C068-T07 · At-limit measurement:** Exercise the “Successful-run reset policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C068-T08 · Over-limit measurement:** Exercise the “Successful-run reset policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C068-T09 · Uncovered-scope report:** List the “Successful-run reset policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C068-T10 · Limit evidence:** Publish the selected “Successful-run reset policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for successful-run reset policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C069-T01 · Event inventory:** List the “Successful-run reset policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Successful-run reset policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C069-T03 · Failure mapping:** Map each documented “Successful-run reset policy” refusal or error to a diagnostic outcome; include “A guest emits ready and crashes before meaningful work on each restart” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C069-T04 · Emission path:** Add the “Successful-run reset policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C069-T05 · Redaction check:** Test “Successful-run reset policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C069-T06 · Output budget:** Set and exercise bounded “Successful-run reset policy” message size, rate and retention compatible with “Healthy observation duration and reset frequency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C069-T07 · Success/refusal fixtures:** Capture “Successful-run reset policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Successful-run reset policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C069-T09 · Operator review:** Read the “Successful-run reset policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C069-T10 · Diagnostic evidence:** Publish redacted “Successful-run reset policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for successful-run reset policy; label unexecuted checks as untested.

- [ ] **UC-M05.07-C070-T01 · Evidence inventory:** List the “Successful-run reset policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C070-T02 · Artifact references:** Record the exact “Successful-run reset policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C070-T03 · Fixture references:** Attach the “Successful-run reset policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest emits ready and crashes before meaningful work on each restart” as a distinct evidence case.
- [ ] **UC-M05.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Successful-run reset policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C070-T05 · Environment record:** Record the actual “Successful-run reset policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C070-T06 · Expected versus observed:** Pair every “Successful-run reset policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C070-T07 · Failure and limit records:** Attach “Successful-run reset policy” change/failure and bounds evidence where required; include uncovered “Healthy observation duration and reset frequency” and unresolved violations of “A brief boot signal cannot erase a persistent failure history”.
- [ ] **UC-M05.07-C070-T08 · Evidence hygiene:** Check the “Successful-run reset policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C070-T09 · Reproduction review:** Have the “Successful-run reset policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C070-T10 · Acceptance linkage:** Link the “Successful-run reset policy” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Operator override controls

**Source delivery:** Require explicit authorized override for quarantined or exhausted workloads.

**Source invariant:** An override cannot silently erase failure evidence.

**Source negative case:** A read-only operator clears quarantine through a retry flag.

**Source bounded quantities:** Override count and authorization latency.

### UC-M05.07-C071 · Contract

**Original checklist item:** Specify operator override controls inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C071-T01 · Scope statement:** Draft the operation boundary for “Operator override controls” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Operator override controls”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C071-T03 · Output inventory:** List the outputs of “Operator override controls” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Operator override controls”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C071-T05 · Prerequisite contract:** Map “Operator override controls” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Operator override controls”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C071-T07 · Invariant clause:** Add a normative clause for “Operator override controls” that preserves “An override cannot silently erase failure evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Operator override controls”; include the source counterexample “A read-only operator clears quarantine through a retry flag” and the intended safe disposition.
- [ ] **UC-M05.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Override count and authorization latency” in the “Operator override controls” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C071-T10 · Contract review:** Review the “Operator override controls” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C072 · Delivery

**Original checklist item:** Require explicit authorized override for quarantined or exhausted workloads.

- [ ] **UC-M05.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Operator override controls”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C072-T02 · Change plan:** Break the source delivery for “Operator override controls” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Operator override controls” that realizes this source instruction: Require explicit authorized override for quarantined or exhausted workloads.
- [ ] **UC-M05.07-C072-T04 · Concrete realization:** Trace “Operator override controls” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Operator override controls” needed to preserve “An override cannot silently erase failure evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C072-T06 · Dependency connection:** Connect the “Operator override controls” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C072-T07 · Resource behavior:** Account for “Override count and authorization latency” in “Operator override controls”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C072-T08 · Delivery check:** Run the smallest real “Operator override controls” path and its adverse fixture “A read-only operator clears quarantine through a retry flag”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C072-T09 · Patch review:** Review the “Operator override controls” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C072-T10 · Delivery handoff:** Publish the “Operator override controls” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An override cannot silently erase failure evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Operator override controls”; copy its required invariant exactly: “An override cannot silently erase failure evidence”.
- [ ] **UC-M05.07-C073-T02 · Observable terms:** Define each term in the “Operator override controls” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C073-T03 · Precondition set:** List the preconditions under which “An override cannot silently erase failure evidence” must hold for “Operator override controls”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C073-T04 · Transition coverage:** Map the “Operator override controls” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Operator override controls”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C073-T06 · Satisfying fixture:** Create a concrete “Operator override controls” case that satisfies “An override cannot silently erase failure evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C073-T07 · Violating fixture:** Create the source counterexample “A read-only operator clears quarantine through a retry flag” for “Operator override controls”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C073-T08 · Enforcement evidence:** Exercise the “Operator override controls” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C073-T09 · Regression linkage:** Link the “Operator override controls” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Operator override controls” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C074 · Integration

**Original checklist item:** Integrate operator override controls with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Operator override controls” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C074-T02 · Field mapping:** Map every “Operator override controls” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Operator override controls” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C074-T04 · Ownership agreement:** Specify who owns “Operator override controls” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C074-T05 · Handoff implementation:** Connect “Operator override controls” through the mapped seam using the real adapter or explicit specification reference; preserve “An override cannot silently erase failure evidence” across the handoff.
- [ ] **UC-M05.07-C074-T06 · Absent-input case:** Omit one required “Operator override controls” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C074-T07 · Stale-input case:** Supply an outdated “Operator override controls” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Operator override controls” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C074-T09 · Valid integration trace:** Run a valid “Operator override controls” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C074-T10 · Seam review:** Reconcile the “Operator override controls” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for operator override controls; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Operator override controls” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C075-T02 · Expected-result oracle:** Specify the “Operator override controls” expected result independently of the implementation output; include the property “An override cannot silently erase failure evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C075-T03 · Fixture material:** Create the concrete “Operator override controls” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C075-T04 · Target preparation:** Prepare the “Operator override controls” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C075-T05 · Initial-state record:** Record the initial “Operator override controls” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C075-T06 · Valid-path execution:** Execute the “Operator override controls” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C075-T07 · Outcome comparison:** Compare every declared “Operator override controls” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C075-T08 · State and bounds check:** Inspect the “Operator override controls” ownership/state effects and actual use of “Override count and authorization latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C075-T09 · Repeatability check:** Repeat the same “Operator override controls” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C075-T10 · Positive evidence:** Attach the “Operator override controls” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C076 · Negative test

**Original checklist item:** Negative case: A read-only operator clears quarantine through a retry flag. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Operator override controls” source counterexample: “A read-only operator clears quarantine through a retry flag”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Operator override controls”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C076-T03 · Valid control:** Construct a valid “Operator override controls” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C076-T04 · Minimal adverse input:** Derive the “Operator override controls” adverse fixture from the control with the smallest documented change needed to reproduce “A read-only operator clears quarantine through a retry flag”; retain that change as reproducible data.
- [ ] **UC-M05.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Operator override controls”; require “An override cannot silently erase failure evidence” and forbid a false-success verdict.
- [ ] **UC-M05.07-C076-T06 · Adverse execution:** Exercise the “Operator override controls” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C076-T07 · Effect inspection:** Inspect “Operator override controls” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C076-T08 · Refusal versus failure:** Confirm the “Operator override controls” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C076-T09 · Reset and retention:** Restore only the disposable “Operator override controls” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C076-T10 · Negative regression:** Register the “Operator override controls” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C077 · Change / failure test

**Original checklist item:** Exercise operator override controls when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C077-T01 · Scenario record:** Write the “Operator override controls” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “An override cannot silently erase failure evidence”.
- [ ] **UC-M05.07-C077-T02 · Baseline capture:** Create a known-valid “Operator override controls” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C077-T03 · Injection map:** Locate the “Operator override controls” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Operator override controls” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C077-T05 · Controlled trigger:** Introduce the controlled “Operator override controls” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C077-T06 · Intermediate inspection:** Inspect the “Operator override controls” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Operator override controls”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Operator override controls” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C077-T09 · Repeat and compare:** Repeat the selected “Operator override controls” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C077-T10 · Failure evidence:** Publish the “Operator override controls” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for override count and authorization latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Operator override controls”: “Override count and authorization latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C078-T02 · Measurement method:** Choose how to observe each “Operator override controls” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Operator override controls”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Operator override controls” cases for “Override count and authorization latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Operator override controls” limit; preserve “An override cannot silently erase failure evidence”.
- [ ] **UC-M05.07-C078-T06 · Normal measurement:** Run or review the normal “Operator override controls” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C078-T07 · At-limit measurement:** Exercise the “Operator override controls” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C078-T08 · Over-limit measurement:** Exercise the “Operator override controls” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C078-T09 · Uncovered-scope report:** List the “Operator override controls” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C078-T10 · Limit evidence:** Publish the selected “Operator override controls” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for operator override controls with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C079-T01 · Event inventory:** List the “Operator override controls” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Operator override controls” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C079-T03 · Failure mapping:** Map each documented “Operator override controls” refusal or error to a diagnostic outcome; include “A read-only operator clears quarantine through a retry flag” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C079-T04 · Emission path:** Add the “Operator override controls” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C079-T05 · Redaction check:** Test “Operator override controls” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C079-T06 · Output budget:** Set and exercise bounded “Operator override controls” message size, rate and retention compatible with “Override count and authorization latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C079-T07 · Success/refusal fixtures:** Capture “Operator override controls” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Operator override controls” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C079-T09 · Operator review:** Read the “Operator override controls” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C079-T10 · Diagnostic evidence:** Publish redacted “Operator override controls” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for operator override controls; label unexecuted checks as untested.

- [ ] **UC-M05.07-C080-T01 · Evidence inventory:** List the “Operator override controls” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C080-T02 · Artifact references:** Record the exact “Operator override controls” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C080-T03 · Fixture references:** Attach the “Operator override controls” fixture IDs, input identities and oracle definition; preserve the source counterexample “A read-only operator clears quarantine through a retry flag” as a distinct evidence case.
- [ ] **UC-M05.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Operator override controls”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C080-T05 · Environment record:** Record the actual “Operator override controls” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C080-T06 · Expected versus observed:** Pair every “Operator override controls” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C080-T07 · Failure and limit records:** Attach “Operator override controls” change/failure and bounds evidence where required; include uncovered “Override count and authorization latency” and unresolved violations of “An override cannot silently erase failure evidence”.
- [ ] **UC-M05.07-C080-T08 · Evidence hygiene:** Check the “Operator override controls” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C080-T09 · Reproduction review:** Have the “Operator override controls” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C080-T10 · Acceptance linkage:** Link the “Operator override controls” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Restart diagnostics

**Source delivery:** Expose next retry, remaining budget and final quarantine reason.

**Source invariant:** Operators can distinguish backoff from stalled reconciliation.

**Source negative case:** The UI reports running while the workload waits in retry backoff.

**Source bounded quantities:** Diagnostic bytes and update interval.

### UC-M05.07-C081 · Contract

**Original checklist item:** Specify restart diagnostics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C081-T01 · Scope statement:** Draft the operation boundary for “Restart diagnostics” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restart diagnostics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C081-T03 · Output inventory:** List the outputs of “Restart diagnostics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Restart diagnostics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C081-T05 · Prerequisite contract:** Map “Restart diagnostics” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Restart diagnostics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C081-T07 · Invariant clause:** Add a normative clause for “Restart diagnostics” that preserves “Operators can distinguish backoff from stalled reconciliation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restart diagnostics”; include the source counterexample “The UI reports running while the workload waits in retry backoff” and the intended safe disposition.
- [ ] **UC-M05.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Diagnostic bytes and update interval” in the “Restart diagnostics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C081-T10 · Contract review:** Review the “Restart diagnostics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C082 · Delivery

**Original checklist item:** Expose next retry, remaining budget and final quarantine reason.

- [ ] **UC-M05.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restart diagnostics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C082-T02 · Change plan:** Break the source delivery for “Restart diagnostics” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Restart diagnostics” that realizes this source instruction: Expose next retry, remaining budget and final quarantine reason.
- [ ] **UC-M05.07-C082-T04 · Concrete realization:** Trace “Restart diagnostics” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restart diagnostics” needed to preserve “Operators can distinguish backoff from stalled reconciliation”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C082-T06 · Dependency connection:** Connect the “Restart diagnostics” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C082-T07 · Resource behavior:** Account for “Diagnostic bytes and update interval” in “Restart diagnostics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C082-T08 · Delivery check:** Run the smallest real “Restart diagnostics” path and its adverse fixture “The UI reports running while the workload waits in retry backoff”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C082-T09 · Patch review:** Review the “Restart diagnostics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C082-T10 · Delivery handoff:** Publish the “Restart diagnostics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Operators can distinguish backoff from stalled reconciliation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Restart diagnostics”; copy its required invariant exactly: “Operators can distinguish backoff from stalled reconciliation”.
- [ ] **UC-M05.07-C083-T02 · Observable terms:** Define each term in the “Restart diagnostics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C083-T03 · Precondition set:** List the preconditions under which “Operators can distinguish backoff from stalled reconciliation” must hold for “Restart diagnostics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C083-T04 · Transition coverage:** Map the “Restart diagnostics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restart diagnostics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C083-T06 · Satisfying fixture:** Create a concrete “Restart diagnostics” case that satisfies “Operators can distinguish backoff from stalled reconciliation”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C083-T07 · Violating fixture:** Create the source counterexample “The UI reports running while the workload waits in retry backoff” for “Restart diagnostics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C083-T08 · Enforcement evidence:** Exercise the “Restart diagnostics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C083-T09 · Regression linkage:** Link the “Restart diagnostics” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Restart diagnostics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C084 · Integration

**Original checklist item:** Integrate restart diagnostics with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restart diagnostics” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C084-T02 · Field mapping:** Map every “Restart diagnostics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Restart diagnostics” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C084-T04 · Ownership agreement:** Specify who owns “Restart diagnostics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C084-T05 · Handoff implementation:** Connect “Restart diagnostics” through the mapped seam using the real adapter or explicit specification reference; preserve “Operators can distinguish backoff from stalled reconciliation” across the handoff.
- [ ] **UC-M05.07-C084-T06 · Absent-input case:** Omit one required “Restart diagnostics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C084-T07 · Stale-input case:** Supply an outdated “Restart diagnostics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Restart diagnostics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C084-T09 · Valid integration trace:** Run a valid “Restart diagnostics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C084-T10 · Seam review:** Reconcile the “Restart diagnostics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restart diagnostics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restart diagnostics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C085-T02 · Expected-result oracle:** Specify the “Restart diagnostics” expected result independently of the implementation output; include the property “Operators can distinguish backoff from stalled reconciliation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C085-T03 · Fixture material:** Create the concrete “Restart diagnostics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C085-T04 · Target preparation:** Prepare the “Restart diagnostics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C085-T05 · Initial-state record:** Record the initial “Restart diagnostics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C085-T06 · Valid-path execution:** Execute the “Restart diagnostics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C085-T07 · Outcome comparison:** Compare every declared “Restart diagnostics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C085-T08 · State and bounds check:** Inspect the “Restart diagnostics” ownership/state effects and actual use of “Diagnostic bytes and update interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C085-T09 · Repeatability check:** Repeat the same “Restart diagnostics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C085-T10 · Positive evidence:** Attach the “Restart diagnostics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C086 · Negative test

**Original checklist item:** Negative case: The UI reports running while the workload waits in retry backoff. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Restart diagnostics” source counterexample: “The UI reports running while the workload waits in retry backoff”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Restart diagnostics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C086-T03 · Valid control:** Construct a valid “Restart diagnostics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C086-T04 · Minimal adverse input:** Derive the “Restart diagnostics” adverse fixture from the control with the smallest documented change needed to reproduce “The UI reports running while the workload waits in retry backoff”; retain that change as reproducible data.
- [ ] **UC-M05.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restart diagnostics”; require “Operators can distinguish backoff from stalled reconciliation” and forbid a false-success verdict.
- [ ] **UC-M05.07-C086-T06 · Adverse execution:** Exercise the “Restart diagnostics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C086-T07 · Effect inspection:** Inspect “Restart diagnostics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C086-T08 · Refusal versus failure:** Confirm the “Restart diagnostics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C086-T09 · Reset and retention:** Restore only the disposable “Restart diagnostics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C086-T10 · Negative regression:** Register the “Restart diagnostics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C087 · Change / failure test

**Original checklist item:** Exercise restart diagnostics when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C087-T01 · Scenario record:** Write the “Restart diagnostics” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “Operators can distinguish backoff from stalled reconciliation”.
- [ ] **UC-M05.07-C087-T02 · Baseline capture:** Create a known-valid “Restart diagnostics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C087-T03 · Injection map:** Locate the “Restart diagnostics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Restart diagnostics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C087-T05 · Controlled trigger:** Introduce the controlled “Restart diagnostics” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C087-T06 · Intermediate inspection:** Inspect the “Restart diagnostics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restart diagnostics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Restart diagnostics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C087-T09 · Repeat and compare:** Repeat the selected “Restart diagnostics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C087-T10 · Failure evidence:** Publish the “Restart diagnostics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for diagnostic bytes and update interval; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Restart diagnostics”: “Diagnostic bytes and update interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C088-T02 · Measurement method:** Choose how to observe each “Restart diagnostics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C088-T03 · Budget decision:** Select justified resource and input limits for “Restart diagnostics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restart diagnostics” cases for “Diagnostic bytes and update interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restart diagnostics” limit; preserve “Operators can distinguish backoff from stalled reconciliation”.
- [ ] **UC-M05.07-C088-T06 · Normal measurement:** Run or review the normal “Restart diagnostics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C088-T07 · At-limit measurement:** Exercise the “Restart diagnostics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C088-T08 · Over-limit measurement:** Exercise the “Restart diagnostics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C088-T09 · Uncovered-scope report:** List the “Restart diagnostics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C088-T10 · Limit evidence:** Publish the selected “Restart diagnostics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restart diagnostics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C089-T01 · Event inventory:** List the “Restart diagnostics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Restart diagnostics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C089-T03 · Failure mapping:** Map each documented “Restart diagnostics” refusal or error to a diagnostic outcome; include “The UI reports running while the workload waits in retry backoff” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C089-T04 · Emission path:** Add the “Restart diagnostics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C089-T05 · Redaction check:** Test “Restart diagnostics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C089-T06 · Output budget:** Set and exercise bounded “Restart diagnostics” message size, rate and retention compatible with “Diagnostic bytes and update interval”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C089-T07 · Success/refusal fixtures:** Capture “Restart diagnostics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restart diagnostics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C089-T09 · Operator review:** Read the “Restart diagnostics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C089-T10 · Diagnostic evidence:** Publish redacted “Restart diagnostics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restart diagnostics; label unexecuted checks as untested.

- [ ] **UC-M05.07-C090-T01 · Evidence inventory:** List the “Restart diagnostics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C090-T02 · Artifact references:** Record the exact “Restart diagnostics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C090-T03 · Fixture references:** Attach the “Restart diagnostics” fixture IDs, input identities and oracle definition; preserve the source counterexample “The UI reports running while the workload waits in retry backoff” as a distinct evidence case.
- [ ] **UC-M05.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restart diagnostics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C090-T05 · Environment record:** Record the actual “Restart diagnostics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C090-T06 · Expected versus observed:** Pair every “Restart diagnostics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C090-T07 · Failure and limit records:** Attach “Restart diagnostics” change/failure and bounds evidence where required; include uncovered “Diagnostic bytes and update interval” and unresolved violations of “Operators can distinguish backoff from stalled reconciliation”.
- [ ] **UC-M05.07-C090-T08 · Evidence hygiene:** Check the “Restart diagnostics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C090-T09 · Reproduction review:** Have the “Restart diagnostics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C090-T10 · Acceptance linkage:** Link the “Restart diagnostics” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Crash-loop qualification

**Source delivery:** Run transient and deterministic crash sequences under bounded resources.

**Source invariant:** The declared ceilings and quarantine policy stop sustained crash loops.

**Source negative case:** A failing guest continues relaunching after its budget is exhausted.

**Source bounded quantities:** Sequence length and observation window.

### UC-M05.07-C091 · Contract

**Original checklist item:** Specify crash-loop qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.07-C091-T01 · Scope statement:** Draft the operation boundary for “Crash-loop qualification” within Safe restart and failure budget policy; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Crash-loop qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.07-C091-T03 · Output inventory:** List the outputs of “Crash-loop qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Crash-loop qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.07-C091-T05 · Prerequisite contract:** Map “Crash-loop qualification” to the source component prerequisites (UC-M05.05, UC-M05.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Crash-loop qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.07-C091-T07 · Invariant clause:** Add a normative clause for “Crash-loop qualification” that preserves “The declared ceilings and quarantine policy stop sustained crash loops”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Crash-loop qualification”; include the source counterexample “A failing guest continues relaunching after its budget is exhausted” and the intended safe disposition.
- [ ] **UC-M05.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Sequence length and observation window” in the “Crash-loop qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.07-C091-T10 · Contract review:** Review the “Crash-loop qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.07-C092 · Delivery

**Original checklist item:** Run transient and deterministic crash sequences under bounded resources.

- [ ] **UC-M05.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Crash-loop qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.07-C092-T02 · Change plan:** Break the source delivery for “Crash-loop qualification” into concrete edit targets and reviewable outputs; keep the UC-M05.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.07-C092-T03 · Core artifact:** Create the “Crash-loop qualification” fixture or harness for this source instruction: Run transient and deterministic crash sequences under bounded resources.
- [ ] **UC-M05.07-C092-T04 · Concrete realization:** Connect the “Crash-loop qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Crash-loop qualification” needed to preserve “The declared ceilings and quarantine policy stop sustained crash loops”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.07-C092-T06 · Dependency connection:** Connect the “Crash-loop qualification” implementation to health failures, persisted restart budgets and image quarantine; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.07-C092-T07 · Resource behavior:** Account for “Sequence length and observation window” in “Crash-loop qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.07-C092-T08 · Delivery check:** Run the smallest real “Crash-loop qualification” path and its adverse fixture “A failing guest continues relaunching after its budget is exhausted”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.07-C092-T09 · Patch review:** Review the “Crash-loop qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.07-C092-T10 · Delivery handoff:** Publish the “Crash-loop qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The declared ceilings and quarantine policy stop sustained crash loops. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Crash-loop qualification”; copy its required invariant exactly: “The declared ceilings and quarantine policy stop sustained crash loops”.
- [ ] **UC-M05.07-C093-T02 · Observable terms:** Define each term in the “Crash-loop qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.07-C093-T03 · Precondition set:** List the preconditions under which “The declared ceilings and quarantine policy stop sustained crash loops” must hold for “Crash-loop qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.07-C093-T04 · Transition coverage:** Map the “Crash-loop qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Crash-loop qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.07-C093-T06 · Satisfying fixture:** Create a concrete “Crash-loop qualification” case that satisfies “The declared ceilings and quarantine policy stop sustained crash loops”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.07-C093-T07 · Violating fixture:** Create the source counterexample “A failing guest continues relaunching after its budget is exhausted” for “Crash-loop qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.07-C093-T08 · Enforcement evidence:** Exercise the “Crash-loop qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.07-C093-T09 · Regression linkage:** Link the “Crash-loop qualification” property to changes in health failures, persisted restart budgets and image quarantine; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Crash-loop qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.07-C094 · Integration

**Original checklist item:** Integrate crash-loop qualification with health failures, persisted restart budgets and image quarantine; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Crash-loop qualification” across health failures, persisted restart budgets and image quarantine; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.07-C094-T02 · Field mapping:** Map every “Crash-loop qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Crash-loop qualification” (source dependency list: UC-M05.05, UC-M05.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.07-C094-T04 · Ownership agreement:** Specify who owns “Crash-loop qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.07-C094-T05 · Handoff implementation:** Connect “Crash-loop qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “The declared ceilings and quarantine policy stop sustained crash loops” across the handoff.
- [ ] **UC-M05.07-C094-T06 · Absent-input case:** Omit one required “Crash-loop qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.07-C094-T07 · Stale-input case:** Supply an outdated “Crash-loop qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Crash-loop qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.07-C094-T09 · Valid integration trace:** Run a valid “Crash-loop qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.07-C094-T10 · Seam review:** Reconcile the “Crash-loop qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for crash-loop qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Crash-loop qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.07-C095-T02 · Expected-result oracle:** Specify the “Crash-loop qualification” expected result independently of the implementation output; include the property “The declared ceilings and quarantine policy stop sustained crash loops” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.07-C095-T03 · Fixture material:** Create the concrete “Crash-loop qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.07-C095-T04 · Target preparation:** Prepare the “Crash-loop qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.07-C095-T05 · Initial-state record:** Record the initial “Crash-loop qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.07-C095-T06 · Valid-path execution:** Execute the “Crash-loop qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.07-C095-T07 · Outcome comparison:** Compare every declared “Crash-loop qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.07-C095-T08 · State and bounds check:** Inspect the “Crash-loop qualification” ownership/state effects and actual use of “Sequence length and observation window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.07-C095-T09 · Repeatability check:** Repeat the same “Crash-loop qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.07-C095-T10 · Positive evidence:** Attach the “Crash-loop qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.07-C096 · Negative test

**Original checklist item:** Negative case: A failing guest continues relaunching after its budget is exhausted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Crash-loop qualification” source counterexample: “A failing guest continues relaunching after its budget is exhausted”; state which precondition or invariant it challenges.
- [ ] **UC-M05.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Crash-loop qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.07-C096-T03 · Valid control:** Construct a valid “Crash-loop qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.07-C096-T04 · Minimal adverse input:** Derive the “Crash-loop qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A failing guest continues relaunching after its budget is exhausted”; retain that change as reproducible data.
- [ ] **UC-M05.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Crash-loop qualification”; require “The declared ceilings and quarantine policy stop sustained crash loops” and forbid a false-success verdict.
- [ ] **UC-M05.07-C096-T06 · Adverse execution:** Exercise the “Crash-loop qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.07-C096-T07 · Effect inspection:** Inspect “Crash-loop qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.07-C096-T08 · Refusal versus failure:** Confirm the “Crash-loop qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.07-C096-T09 · Reset and retention:** Restore only the disposable “Crash-loop qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.07-C096-T10 · Negative regression:** Register the “Crash-loop qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.07-C097 · Change / failure test

**Original checklist item:** Exercise crash-loop qualification when the controller restarts during a deterministic guest crash loop; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.07-C097-T01 · Scenario record:** Write the “Crash-loop qualification” change/failure scenario exactly as supplied: the controller restarts during a deterministic guest crash loop; identify the property that must remain true: “The declared ceilings and quarantine policy stop sustained crash loops”.
- [ ] **UC-M05.07-C097-T02 · Baseline capture:** Create a known-valid “Crash-loop qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.07-C097-T03 · Injection map:** Locate the “Crash-loop qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Crash-loop qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.07-C097-T05 · Controlled trigger:** Introduce the controlled “Crash-loop qualification” scenario in the disposable fixture: the controller restarts during a deterministic guest crash loop; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.07-C097-T06 · Intermediate inspection:** Inspect the “Crash-loop qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Crash-loop qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Crash-loop qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.07-C097-T09 · Repeat and compare:** Repeat the selected “Crash-loop qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.07-C097-T10 · Failure evidence:** Publish the “Crash-loop qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for sequence length and observation window; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Crash-loop qualification”: “Sequence length and observation window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.07-C098-T02 · Measurement method:** Choose how to observe each “Crash-loop qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Crash-loop qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Crash-loop qualification” cases for “Sequence length and observation window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Crash-loop qualification” limit; preserve “The declared ceilings and quarantine policy stop sustained crash loops”.
- [ ] **UC-M05.07-C098-T06 · Normal measurement:** Run or review the normal “Crash-loop qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.07-C098-T07 · At-limit measurement:** Exercise the “Crash-loop qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.07-C098-T08 · Over-limit measurement:** Exercise the “Crash-loop qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.07-C098-T09 · Uncovered-scope report:** List the “Crash-loop qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.07-C098-T10 · Limit evidence:** Publish the selected “Crash-loop qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for crash-loop qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.07-C099-T01 · Event inventory:** List the “Crash-loop qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Crash-loop qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.07-C099-T03 · Failure mapping:** Map each documented “Crash-loop qualification” refusal or error to a diagnostic outcome; include “A failing guest continues relaunching after its budget is exhausted” and prohibit conversion into a success message.
- [ ] **UC-M05.07-C099-T04 · Emission path:** Add the “Crash-loop qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.07-C099-T05 · Redaction check:** Test “Crash-loop qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.07-C099-T06 · Output budget:** Set and exercise bounded “Crash-loop qualification” message size, rate and retention compatible with “Sequence length and observation window”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.07-C099-T07 · Success/refusal fixtures:** Capture “Crash-loop qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Crash-loop qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.07-C099-T09 · Operator review:** Read the “Crash-loop qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.07-C099-T10 · Diagnostic evidence:** Publish redacted “Crash-loop qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for crash-loop qualification; label unexecuted checks as untested.

- [ ] **UC-M05.07-C100-T01 · Evidence inventory:** List the “Crash-loop qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.07-C100-T02 · Artifact references:** Record the exact “Crash-loop qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.07-C100-T03 · Fixture references:** Attach the “Crash-loop qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failing guest continues relaunching after its budget is exhausted” as a distinct evidence case.
- [ ] **UC-M05.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Crash-loop qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.07-C100-T05 · Environment record:** Record the actual “Crash-loop qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.07-C100-T06 · Expected versus observed:** Pair every “Crash-loop qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.07-C100-T07 · Failure and limit records:** Attach “Crash-loop qualification” change/failure and bounds evidence where required; include uncovered “Sequence length and observation window” and unresolved violations of “The declared ceilings and quarantine policy stop sustained crash loops”.
- [ ] **UC-M05.07-C100-T08 · Evidence hygiene:** Check the “Crash-loop qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.07-C100-T09 · Reproduction review:** Have the “Crash-loop qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.07-C100-T10 · Acceptance linkage:** Link the “Crash-loop qualification” evidence to its parent and UC-M05.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

