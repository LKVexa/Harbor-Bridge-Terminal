# UC-M05.01 — Executable workload DAG planner

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/05.md)

| Field | Preserved source value |
|---|---|
| Workstream | 05. Workload orchestration and scheduling |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M01.07](../01/UC-M01.07.md), [UC-M01.08](../01/UC-M01.08.md), [UC-M03.01](../03/UC-M03.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S6]. |

## Original requirement

Convert declared entry points and dependency edges into actual invocations, not merely script placement into folders.

**Original acceptance criterion:** A multi-step workload executes dependencies exactly in the required order and publishes explicit outputs.

**Source trace:** Original checklist `UC100/c/05/UC-M05.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 429–439 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Executable node model

**Source delivery:** Represent each workload step with an actual executable entry point and typed inputs and outputs.

**Source invariant:** Placing a script in a folder does not count as executing a DAG node.

**Source negative case:** A planner marks a step complete after copying its script.

**Source bounded quantities:** Node count and descriptor bytes.

### UC-M05.01-C001 · Contract

**Original checklist item:** Specify executable node model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C001-T01 · Scope statement:** Draft the operation boundary for “Executable node model” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Executable node model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C001-T03 · Output inventory:** List the outputs of “Executable node model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Executable node model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C001-T05 · Prerequisite contract:** Map “Executable node model” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Executable node model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C001-T07 · Invariant clause:** Add a normative clause for “Executable node model” that preserves “Placing a script in a folder does not count as executing a DAG node”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Executable node model”; include the source counterexample “A planner marks a step complete after copying its script” and the intended safe disposition.
- [ ] **UC-M05.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Node count and descriptor bytes” in the “Executable node model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C001-T10 · Contract review:** Review the “Executable node model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C002 · Delivery

**Original checklist item:** Represent each workload step with an actual executable entry point and typed inputs and outputs.

- [ ] **UC-M05.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Executable node model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C002-T02 · Change plan:** Break the source delivery for “Executable node model” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C002-T03 · Core artifact:** Create the “Executable node model” model, schema or inventory that realizes this source instruction: Represent each workload step with an actual executable entry point and typed inputs and outputs.
- [ ] **UC-M05.01-C002-T04 · Concrete realization:** Populate “Executable node model” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Executable node model” needed to preserve “Placing a script in a folder does not count as executing a DAG node”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C002-T06 · Dependency connection:** Connect the “Executable node model” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C002-T07 · Resource behavior:** Account for “Node count and descriptor bytes” in “Executable node model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C002-T08 · Delivery check:** Run the smallest real “Executable node model” path and its adverse fixture “A planner marks a step complete after copying its script”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C002-T09 · Patch review:** Review the “Executable node model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C002-T10 · Delivery handoff:** Publish the “Executable node model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Placing a script in a folder does not count as executing a DAG node. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Executable node model”; copy its required invariant exactly: “Placing a script in a folder does not count as executing a DAG node”.
- [ ] **UC-M05.01-C003-T02 · Observable terms:** Define each term in the “Executable node model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C003-T03 · Precondition set:** List the preconditions under which “Placing a script in a folder does not count as executing a DAG node” must hold for “Executable node model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C003-T04 · Transition coverage:** Map the “Executable node model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Executable node model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C003-T06 · Satisfying fixture:** Create a concrete “Executable node model” case that satisfies “Placing a script in a folder does not count as executing a DAG node”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C003-T07 · Violating fixture:** Create the source counterexample “A planner marks a step complete after copying its script” for “Executable node model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C003-T08 · Enforcement evidence:** Exercise the “Executable node model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C003-T09 · Regression linkage:** Link the “Executable node model” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Executable node model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C004 · Integration

**Original checklist item:** Integrate executable node model with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Executable node model” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C004-T02 · Field mapping:** Map every “Executable node model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Executable node model” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C004-T04 · Ownership agreement:** Specify who owns “Executable node model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C004-T05 · Handoff implementation:** Connect “Executable node model” through the mapped seam using the real adapter or explicit specification reference; preserve “Placing a script in a folder does not count as executing a DAG node” across the handoff.
- [ ] **UC-M05.01-C004-T06 · Absent-input case:** Omit one required “Executable node model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C004-T07 · Stale-input case:** Supply an outdated “Executable node model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Executable node model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C004-T09 · Valid integration trace:** Run a valid “Executable node model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C004-T10 · Seam review:** Reconcile the “Executable node model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for executable node model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Executable node model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C005-T02 · Expected-result oracle:** Specify the “Executable node model” expected result independently of the implementation output; include the property “Placing a script in a folder does not count as executing a DAG node” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C005-T03 · Fixture material:** Create the concrete “Executable node model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C005-T04 · Target preparation:** Prepare the “Executable node model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C005-T05 · Initial-state record:** Record the initial “Executable node model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C005-T06 · Valid-path execution:** Execute the “Executable node model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C005-T07 · Outcome comparison:** Compare every declared “Executable node model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C005-T08 · State and bounds check:** Inspect the “Executable node model” ownership/state effects and actual use of “Node count and descriptor bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C005-T09 · Repeatability check:** Repeat the same “Executable node model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C005-T10 · Positive evidence:** Attach the “Executable node model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C006 · Negative test

**Original checklist item:** Negative case: A planner marks a step complete after copying its script. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Executable node model” source counterexample: “A planner marks a step complete after copying its script”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Executable node model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C006-T03 · Valid control:** Construct a valid “Executable node model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C006-T04 · Minimal adverse input:** Derive the “Executable node model” adverse fixture from the control with the smallest documented change needed to reproduce “A planner marks a step complete after copying its script”; retain that change as reproducible data.
- [ ] **UC-M05.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Executable node model”; require “Placing a script in a folder does not count as executing a DAG node” and forbid a false-success verdict.
- [ ] **UC-M05.01-C006-T06 · Adverse execution:** Exercise the “Executable node model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C006-T07 · Effect inspection:** Inspect “Executable node model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C006-T08 · Refusal versus failure:** Confirm the “Executable node model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C006-T09 · Reset and retention:** Restore only the disposable “Executable node model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C006-T10 · Negative regression:** Register the “Executable node model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C007 · Change / failure test

**Original checklist item:** Exercise executable node model when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C007-T01 · Scenario record:** Write the “Executable node model” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “Placing a script in a folder does not count as executing a DAG node”.
- [ ] **UC-M05.01-C007-T02 · Baseline capture:** Create a known-valid “Executable node model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C007-T03 · Injection map:** Locate the “Executable node model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Executable node model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C007-T05 · Controlled trigger:** Introduce the controlled “Executable node model” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C007-T06 · Intermediate inspection:** Inspect the “Executable node model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Executable node model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Executable node model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C007-T09 · Repeat and compare:** Repeat the selected “Executable node model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C007-T10 · Failure evidence:** Publish the “Executable node model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for node count and descriptor bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Executable node model”: “Node count and descriptor bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C008-T02 · Measurement method:** Choose how to observe each “Executable node model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Executable node model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Executable node model” cases for “Node count and descriptor bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Executable node model” limit; preserve “Placing a script in a folder does not count as executing a DAG node”.
- [ ] **UC-M05.01-C008-T06 · Normal measurement:** Run or review the normal “Executable node model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C008-T07 · At-limit measurement:** Exercise the “Executable node model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C008-T08 · Over-limit measurement:** Exercise the “Executable node model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C008-T09 · Uncovered-scope report:** List the “Executable node model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C008-T10 · Limit evidence:** Publish the selected “Executable node model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for executable node model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C009-T01 · Event inventory:** List the “Executable node model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Executable node model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C009-T03 · Failure mapping:** Map each documented “Executable node model” refusal or error to a diagnostic outcome; include “A planner marks a step complete after copying its script” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C009-T04 · Emission path:** Add the “Executable node model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C009-T05 · Redaction check:** Test “Executable node model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C009-T06 · Output budget:** Set and exercise bounded “Executable node model” message size, rate and retention compatible with “Node count and descriptor bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C009-T07 · Success/refusal fixtures:** Capture “Executable node model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Executable node model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C009-T09 · Operator review:** Read the “Executable node model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C009-T10 · Diagnostic evidence:** Publish redacted “Executable node model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for executable node model; label unexecuted checks as untested.

- [ ] **UC-M05.01-C010-T01 · Evidence inventory:** List the “Executable node model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C010-T02 · Artifact references:** Record the exact “Executable node model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C010-T03 · Fixture references:** Attach the “Executable node model” fixture IDs, input identities and oracle definition; preserve the source counterexample “A planner marks a step complete after copying its script” as a distinct evidence case.
- [ ] **UC-M05.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Executable node model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C010-T05 · Environment record:** Record the actual “Executable node model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C010-T06 · Expected versus observed:** Pair every “Executable node model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C010-T07 · Failure and limit records:** Attach “Executable node model” change/failure and bounds evidence where required; include uncovered “Node count and descriptor bytes” and unresolved violations of “Placing a script in a folder does not count as executing a DAG node”.
- [ ] **UC-M05.01-C010-T08 · Evidence hygiene:** Check the “Executable node model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C010-T09 · Reproduction review:** Have the “Executable node model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C010-T10 · Acceptance linkage:** Link the “Executable node model” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Dependency validation

**Source delivery:** Check that each required predecessor and input artifact exists before scheduling.

**Source invariant:** Missing dependencies cannot be treated as completed work.

**Source negative case:** A node starts despite an unresolved required predecessor.

**Source bounded quantities:** Edge count and graph traversal memory.

### UC-M05.01-C011 · Contract

**Original checklist item:** Specify dependency validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C011-T01 · Scope statement:** Draft the operation boundary for “Dependency validation” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Dependency validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C011-T03 · Output inventory:** List the outputs of “Dependency validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Dependency validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C011-T05 · Prerequisite contract:** Map “Dependency validation” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Dependency validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C011-T07 · Invariant clause:** Add a normative clause for “Dependency validation” that preserves “Missing dependencies cannot be treated as completed work”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Dependency validation”; include the source counterexample “A node starts despite an unresolved required predecessor” and the intended safe disposition.
- [ ] **UC-M05.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Edge count and graph traversal memory” in the “Dependency validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C011-T10 · Contract review:** Review the “Dependency validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C012 · Delivery

**Original checklist item:** Check that each required predecessor and input artifact exists before scheduling.

- [ ] **UC-M05.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Dependency validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C012-T02 · Change plan:** Break the source delivery for “Dependency validation” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C012-T03 · Core artifact:** Create the “Dependency validation” fixture or harness for this source instruction: Check that each required predecessor and input artifact exists before scheduling.
- [ ] **UC-M05.01-C012-T04 · Concrete realization:** Connect the “Dependency validation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Dependency validation” needed to preserve “Missing dependencies cannot be treated as completed work”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C012-T06 · Dependency connection:** Connect the “Dependency validation” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C012-T07 · Resource behavior:** Account for “Edge count and graph traversal memory” in “Dependency validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C012-T08 · Delivery check:** Run the smallest real “Dependency validation” path and its adverse fixture “A node starts despite an unresolved required predecessor”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C012-T09 · Patch review:** Review the “Dependency validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C012-T10 · Delivery handoff:** Publish the “Dependency validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Missing dependencies cannot be treated as completed work. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Dependency validation”; copy its required invariant exactly: “Missing dependencies cannot be treated as completed work”.
- [ ] **UC-M05.01-C013-T02 · Observable terms:** Define each term in the “Dependency validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C013-T03 · Precondition set:** List the preconditions under which “Missing dependencies cannot be treated as completed work” must hold for “Dependency validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C013-T04 · Transition coverage:** Map the “Dependency validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Dependency validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C013-T06 · Satisfying fixture:** Create a concrete “Dependency validation” case that satisfies “Missing dependencies cannot be treated as completed work”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C013-T07 · Violating fixture:** Create the source counterexample “A node starts despite an unresolved required predecessor” for “Dependency validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C013-T08 · Enforcement evidence:** Exercise the “Dependency validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C013-T09 · Regression linkage:** Link the “Dependency validation” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Dependency validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C014 · Integration

**Original checklist item:** Integrate dependency validation with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Dependency validation” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C014-T02 · Field mapping:** Map every “Dependency validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Dependency validation” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C014-T04 · Ownership agreement:** Specify who owns “Dependency validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C014-T05 · Handoff implementation:** Connect “Dependency validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Missing dependencies cannot be treated as completed work” across the handoff.
- [ ] **UC-M05.01-C014-T06 · Absent-input case:** Omit one required “Dependency validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C014-T07 · Stale-input case:** Supply an outdated “Dependency validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Dependency validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C014-T09 · Valid integration trace:** Run a valid “Dependency validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C014-T10 · Seam review:** Reconcile the “Dependency validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for dependency validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Dependency validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C015-T02 · Expected-result oracle:** Specify the “Dependency validation” expected result independently of the implementation output; include the property “Missing dependencies cannot be treated as completed work” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C015-T03 · Fixture material:** Create the concrete “Dependency validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C015-T04 · Target preparation:** Prepare the “Dependency validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C015-T05 · Initial-state record:** Record the initial “Dependency validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C015-T06 · Valid-path execution:** Execute the “Dependency validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C015-T07 · Outcome comparison:** Compare every declared “Dependency validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C015-T08 · State and bounds check:** Inspect the “Dependency validation” ownership/state effects and actual use of “Edge count and graph traversal memory”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C015-T09 · Repeatability check:** Repeat the same “Dependency validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C015-T10 · Positive evidence:** Attach the “Dependency validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C016 · Negative test

**Original checklist item:** Negative case: A node starts despite an unresolved required predecessor. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Dependency validation” source counterexample: “A node starts despite an unresolved required predecessor”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Dependency validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C016-T03 · Valid control:** Construct a valid “Dependency validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C016-T04 · Minimal adverse input:** Derive the “Dependency validation” adverse fixture from the control with the smallest documented change needed to reproduce “A node starts despite an unresolved required predecessor”; retain that change as reproducible data.
- [ ] **UC-M05.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Dependency validation”; require “Missing dependencies cannot be treated as completed work” and forbid a false-success verdict.
- [ ] **UC-M05.01-C016-T06 · Adverse execution:** Exercise the “Dependency validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C016-T07 · Effect inspection:** Inspect “Dependency validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C016-T08 · Refusal versus failure:** Confirm the “Dependency validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C016-T09 · Reset and retention:** Restore only the disposable “Dependency validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C016-T10 · Negative regression:** Register the “Dependency validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C017 · Change / failure test

**Original checklist item:** Exercise dependency validation when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C017-T01 · Scenario record:** Write the “Dependency validation” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “Missing dependencies cannot be treated as completed work”.
- [ ] **UC-M05.01-C017-T02 · Baseline capture:** Create a known-valid “Dependency validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C017-T03 · Injection map:** Locate the “Dependency validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Dependency validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C017-T05 · Controlled trigger:** Introduce the controlled “Dependency validation” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C017-T06 · Intermediate inspection:** Inspect the “Dependency validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Dependency validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Dependency validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C017-T09 · Repeat and compare:** Repeat the selected “Dependency validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C017-T10 · Failure evidence:** Publish the “Dependency validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for edge count and graph traversal memory; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Dependency validation”: “Edge count and graph traversal memory”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C018-T02 · Measurement method:** Choose how to observe each “Dependency validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Dependency validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Dependency validation” cases for “Edge count and graph traversal memory”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Dependency validation” limit; preserve “Missing dependencies cannot be treated as completed work”.
- [ ] **UC-M05.01-C018-T06 · Normal measurement:** Run or review the normal “Dependency validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C018-T07 · At-limit measurement:** Exercise the “Dependency validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C018-T08 · Over-limit measurement:** Exercise the “Dependency validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C018-T09 · Uncovered-scope report:** List the “Dependency validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C018-T10 · Limit evidence:** Publish the selected “Dependency validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for dependency validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C019-T01 · Event inventory:** List the “Dependency validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Dependency validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C019-T03 · Failure mapping:** Map each documented “Dependency validation” refusal or error to a diagnostic outcome; include “A node starts despite an unresolved required predecessor” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C019-T04 · Emission path:** Add the “Dependency validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C019-T05 · Redaction check:** Test “Dependency validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C019-T06 · Output budget:** Set and exercise bounded “Dependency validation” message size, rate and retention compatible with “Edge count and graph traversal memory”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C019-T07 · Success/refusal fixtures:** Capture “Dependency validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Dependency validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C019-T09 · Operator review:** Read the “Dependency validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C019-T10 · Diagnostic evidence:** Publish redacted “Dependency validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for dependency validation; label unexecuted checks as untested.

- [ ] **UC-M05.01-C020-T01 · Evidence inventory:** List the “Dependency validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C020-T02 · Artifact references:** Record the exact “Dependency validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C020-T03 · Fixture references:** Attach the “Dependency validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A node starts despite an unresolved required predecessor” as a distinct evidence case.
- [ ] **UC-M05.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Dependency validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C020-T05 · Environment record:** Record the actual “Dependency validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C020-T06 · Expected versus observed:** Pair every “Dependency validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C020-T07 · Failure and limit records:** Attach “Dependency validation” change/failure and bounds evidence where required; include uncovered “Edge count and graph traversal memory” and unresolved violations of “Missing dependencies cannot be treated as completed work”.
- [ ] **UC-M05.01-C020-T08 · Evidence hygiene:** Check the “Dependency validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C020-T09 · Reproduction review:** Have the “Dependency validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C020-T10 · Acceptance linkage:** Link the “Dependency validation” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Cycle rejection

**Source delivery:** Detect cycles with an actionable path before dispatch.

**Source invariant:** Only acyclic executable plans enter the runnable queue.

**Source negative case:** Two workload steps require each other's final outputs.

**Source bounded quantities:** Graph depth and cycle-detection time.

### UC-M05.01-C021 · Contract

**Original checklist item:** Specify cycle rejection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C021-T01 · Scope statement:** Draft the operation boundary for “Cycle rejection” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cycle rejection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C021-T03 · Output inventory:** List the outputs of “Cycle rejection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Cycle rejection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C021-T05 · Prerequisite contract:** Map “Cycle rejection” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Cycle rejection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C021-T07 · Invariant clause:** Add a normative clause for “Cycle rejection” that preserves “Only acyclic executable plans enter the runnable queue”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cycle rejection”; include the source counterexample “Two workload steps require each other's final outputs” and the intended safe disposition.
- [ ] **UC-M05.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Graph depth and cycle-detection time” in the “Cycle rejection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C021-T10 · Contract review:** Review the “Cycle rejection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C022 · Delivery

**Original checklist item:** Detect cycles with an actionable path before dispatch.

- [ ] **UC-M05.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cycle rejection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C022-T02 · Change plan:** Break the source delivery for “Cycle rejection” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Cycle rejection” that realizes this source instruction: Detect cycles with an actionable path before dispatch.
- [ ] **UC-M05.01-C022-T04 · Concrete realization:** Trace “Cycle rejection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cycle rejection” needed to preserve “Only acyclic executable plans enter the runnable queue”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C022-T06 · Dependency connection:** Connect the “Cycle rejection” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C022-T07 · Resource behavior:** Account for “Graph depth and cycle-detection time” in “Cycle rejection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C022-T08 · Delivery check:** Run the smallest real “Cycle rejection” path and its adverse fixture “Two workload steps require each other's final outputs”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C022-T09 · Patch review:** Review the “Cycle rejection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C022-T10 · Delivery handoff:** Publish the “Cycle rejection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Only acyclic executable plans enter the runnable queue. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Cycle rejection”; copy its required invariant exactly: “Only acyclic executable plans enter the runnable queue”.
- [ ] **UC-M05.01-C023-T02 · Observable terms:** Define each term in the “Cycle rejection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C023-T03 · Precondition set:** List the preconditions under which “Only acyclic executable plans enter the runnable queue” must hold for “Cycle rejection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C023-T04 · Transition coverage:** Map the “Cycle rejection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cycle rejection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C023-T06 · Satisfying fixture:** Create a concrete “Cycle rejection” case that satisfies “Only acyclic executable plans enter the runnable queue”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C023-T07 · Violating fixture:** Create the source counterexample “Two workload steps require each other's final outputs” for “Cycle rejection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C023-T08 · Enforcement evidence:** Exercise the “Cycle rejection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C023-T09 · Regression linkage:** Link the “Cycle rejection” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Cycle rejection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C024 · Integration

**Original checklist item:** Integrate cycle rejection with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cycle rejection” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C024-T02 · Field mapping:** Map every “Cycle rejection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Cycle rejection” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C024-T04 · Ownership agreement:** Specify who owns “Cycle rejection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C024-T05 · Handoff implementation:** Connect “Cycle rejection” through the mapped seam using the real adapter or explicit specification reference; preserve “Only acyclic executable plans enter the runnable queue” across the handoff.
- [ ] **UC-M05.01-C024-T06 · Absent-input case:** Omit one required “Cycle rejection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C024-T07 · Stale-input case:** Supply an outdated “Cycle rejection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Cycle rejection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C024-T09 · Valid integration trace:** Run a valid “Cycle rejection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C024-T10 · Seam review:** Reconcile the “Cycle rejection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cycle rejection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cycle rejection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C025-T02 · Expected-result oracle:** Specify the “Cycle rejection” expected result independently of the implementation output; include the property “Only acyclic executable plans enter the runnable queue” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C025-T03 · Fixture material:** Create the concrete “Cycle rejection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C025-T04 · Target preparation:** Prepare the “Cycle rejection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C025-T05 · Initial-state record:** Record the initial “Cycle rejection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C025-T06 · Valid-path execution:** Execute the “Cycle rejection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C025-T07 · Outcome comparison:** Compare every declared “Cycle rejection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C025-T08 · State and bounds check:** Inspect the “Cycle rejection” ownership/state effects and actual use of “Graph depth and cycle-detection time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C025-T09 · Repeatability check:** Repeat the same “Cycle rejection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C025-T10 · Positive evidence:** Attach the “Cycle rejection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C026 · Negative test

**Original checklist item:** Negative case: Two workload steps require each other's final outputs. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Cycle rejection” source counterexample: “Two workload steps require each other's final outputs”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Cycle rejection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C026-T03 · Valid control:** Construct a valid “Cycle rejection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C026-T04 · Minimal adverse input:** Derive the “Cycle rejection” adverse fixture from the control with the smallest documented change needed to reproduce “Two workload steps require each other's final outputs”; retain that change as reproducible data.
- [ ] **UC-M05.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cycle rejection”; require “Only acyclic executable plans enter the runnable queue” and forbid a false-success verdict.
- [ ] **UC-M05.01-C026-T06 · Adverse execution:** Exercise the “Cycle rejection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C026-T07 · Effect inspection:** Inspect “Cycle rejection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C026-T08 · Refusal versus failure:** Confirm the “Cycle rejection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C026-T09 · Reset and retention:** Restore only the disposable “Cycle rejection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C026-T10 · Negative regression:** Register the “Cycle rejection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C027 · Change / failure test

**Original checklist item:** Exercise cycle rejection when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C027-T01 · Scenario record:** Write the “Cycle rejection” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “Only acyclic executable plans enter the runnable queue”.
- [ ] **UC-M05.01-C027-T02 · Baseline capture:** Create a known-valid “Cycle rejection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C027-T03 · Injection map:** Locate the “Cycle rejection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Cycle rejection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C027-T05 · Controlled trigger:** Introduce the controlled “Cycle rejection” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C027-T06 · Intermediate inspection:** Inspect the “Cycle rejection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cycle rejection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Cycle rejection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C027-T09 · Repeat and compare:** Repeat the selected “Cycle rejection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C027-T10 · Failure evidence:** Publish the “Cycle rejection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for graph depth and cycle-detection time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Cycle rejection”: “Graph depth and cycle-detection time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C028-T02 · Measurement method:** Choose how to observe each “Cycle rejection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Cycle rejection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cycle rejection” cases for “Graph depth and cycle-detection time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cycle rejection” limit; preserve “Only acyclic executable plans enter the runnable queue”.
- [ ] **UC-M05.01-C028-T06 · Normal measurement:** Run or review the normal “Cycle rejection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C028-T07 · At-limit measurement:** Exercise the “Cycle rejection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C028-T08 · Over-limit measurement:** Exercise the “Cycle rejection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C028-T09 · Uncovered-scope report:** List the “Cycle rejection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C028-T10 · Limit evidence:** Publish the selected “Cycle rejection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cycle rejection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C029-T01 · Event inventory:** List the “Cycle rejection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Cycle rejection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C029-T03 · Failure mapping:** Map each documented “Cycle rejection” refusal or error to a diagnostic outcome; include “Two workload steps require each other's final outputs” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C029-T04 · Emission path:** Add the “Cycle rejection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C029-T05 · Redaction check:** Test “Cycle rejection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C029-T06 · Output budget:** Set and exercise bounded “Cycle rejection” message size, rate and retention compatible with “Graph depth and cycle-detection time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C029-T07 · Success/refusal fixtures:** Capture “Cycle rejection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cycle rejection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C029-T09 · Operator review:** Read the “Cycle rejection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C029-T10 · Diagnostic evidence:** Publish redacted “Cycle rejection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cycle rejection; label unexecuted checks as untested.

- [ ] **UC-M05.01-C030-T01 · Evidence inventory:** List the “Cycle rejection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C030-T02 · Artifact references:** Record the exact “Cycle rejection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C030-T03 · Fixture references:** Attach the “Cycle rejection” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two workload steps require each other's final outputs” as a distinct evidence case.
- [ ] **UC-M05.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cycle rejection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C030-T05 · Environment record:** Record the actual “Cycle rejection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C030-T06 · Expected versus observed:** Pair every “Cycle rejection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C030-T07 · Failure and limit records:** Attach “Cycle rejection” change/failure and bounds evidence where required; include uncovered “Graph depth and cycle-detection time” and unresolved violations of “Only acyclic executable plans enter the runnable queue”.
- [ ] **UC-M05.01-C030-T08 · Evidence hygiene:** Check the “Cycle rejection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C030-T09 · Reproduction review:** Have the “Cycle rejection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C030-T10 · Acceptance linkage:** Link the “Cycle rejection” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Topological execution

**Source delivery:** Schedule dependency-ready nodes in a legal topological order.

**Source invariant:** A node executes only after its required predecessors succeed.

**Source negative case:** A dependent step starts while its prerequisite is still running.

**Source bounded quantities:** Runnable nodes and dispatch concurrency.

### UC-M05.01-C031 · Contract

**Original checklist item:** Specify topological execution inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C031-T01 · Scope statement:** Draft the operation boundary for “Topological execution” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Topological execution”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C031-T03 · Output inventory:** List the outputs of “Topological execution” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Topological execution”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C031-T05 · Prerequisite contract:** Map “Topological execution” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Topological execution”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C031-T07 · Invariant clause:** Add a normative clause for “Topological execution” that preserves “A node executes only after its required predecessors succeed”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Topological execution”; include the source counterexample “A dependent step starts while its prerequisite is still running” and the intended safe disposition.
- [ ] **UC-M05.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Runnable nodes and dispatch concurrency” in the “Topological execution” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C031-T10 · Contract review:** Review the “Topological execution” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C032 · Delivery

**Original checklist item:** Schedule dependency-ready nodes in a legal topological order.

- [ ] **UC-M05.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Topological execution”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C032-T02 · Change plan:** Break the source delivery for “Topological execution” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Topological execution” that realizes this source instruction: Schedule dependency-ready nodes in a legal topological order.
- [ ] **UC-M05.01-C032-T04 · Concrete realization:** Trace “Topological execution” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Topological execution” needed to preserve “A node executes only after its required predecessors succeed”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C032-T06 · Dependency connection:** Connect the “Topological execution” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C032-T07 · Resource behavior:** Account for “Runnable nodes and dispatch concurrency” in “Topological execution”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C032-T08 · Delivery check:** Run the smallest real “Topological execution” path and its adverse fixture “A dependent step starts while its prerequisite is still running”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C032-T09 · Patch review:** Review the “Topological execution” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C032-T10 · Delivery handoff:** Publish the “Topological execution” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A node executes only after its required predecessors succeed. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Topological execution”; copy its required invariant exactly: “A node executes only after its required predecessors succeed”.
- [ ] **UC-M05.01-C033-T02 · Observable terms:** Define each term in the “Topological execution” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C033-T03 · Precondition set:** List the preconditions under which “A node executes only after its required predecessors succeed” must hold for “Topological execution”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C033-T04 · Transition coverage:** Map the “Topological execution” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Topological execution”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C033-T06 · Satisfying fixture:** Create a concrete “Topological execution” case that satisfies “A node executes only after its required predecessors succeed”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C033-T07 · Violating fixture:** Create the source counterexample “A dependent step starts while its prerequisite is still running” for “Topological execution”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C033-T08 · Enforcement evidence:** Exercise the “Topological execution” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C033-T09 · Regression linkage:** Link the “Topological execution” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Topological execution” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C034 · Integration

**Original checklist item:** Integrate topological execution with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Topological execution” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C034-T02 · Field mapping:** Map every “Topological execution” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Topological execution” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C034-T04 · Ownership agreement:** Specify who owns “Topological execution” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C034-T05 · Handoff implementation:** Connect “Topological execution” through the mapped seam using the real adapter or explicit specification reference; preserve “A node executes only after its required predecessors succeed” across the handoff.
- [ ] **UC-M05.01-C034-T06 · Absent-input case:** Omit one required “Topological execution” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C034-T07 · Stale-input case:** Supply an outdated “Topological execution” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Topological execution” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C034-T09 · Valid integration trace:** Run a valid “Topological execution” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C034-T10 · Seam review:** Reconcile the “Topological execution” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for topological execution; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Topological execution” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C035-T02 · Expected-result oracle:** Specify the “Topological execution” expected result independently of the implementation output; include the property “A node executes only after its required predecessors succeed” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C035-T03 · Fixture material:** Create the concrete “Topological execution” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C035-T04 · Target preparation:** Prepare the “Topological execution” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C035-T05 · Initial-state record:** Record the initial “Topological execution” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C035-T06 · Valid-path execution:** Execute the “Topological execution” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C035-T07 · Outcome comparison:** Compare every declared “Topological execution” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C035-T08 · State and bounds check:** Inspect the “Topological execution” ownership/state effects and actual use of “Runnable nodes and dispatch concurrency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C035-T09 · Repeatability check:** Repeat the same “Topological execution” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C035-T10 · Positive evidence:** Attach the “Topological execution” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C036 · Negative test

**Original checklist item:** Negative case: A dependent step starts while its prerequisite is still running. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Topological execution” source counterexample: “A dependent step starts while its prerequisite is still running”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Topological execution”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C036-T03 · Valid control:** Construct a valid “Topological execution” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C036-T04 · Minimal adverse input:** Derive the “Topological execution” adverse fixture from the control with the smallest documented change needed to reproduce “A dependent step starts while its prerequisite is still running”; retain that change as reproducible data.
- [ ] **UC-M05.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Topological execution”; require “A node executes only after its required predecessors succeed” and forbid a false-success verdict.
- [ ] **UC-M05.01-C036-T06 · Adverse execution:** Exercise the “Topological execution” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C036-T07 · Effect inspection:** Inspect “Topological execution” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C036-T08 · Refusal versus failure:** Confirm the “Topological execution” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C036-T09 · Reset and retention:** Restore only the disposable “Topological execution” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C036-T10 · Negative regression:** Register the “Topological execution” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C037 · Change / failure test

**Original checklist item:** Exercise topological execution when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C037-T01 · Scenario record:** Write the “Topological execution” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “A node executes only after its required predecessors succeed”.
- [ ] **UC-M05.01-C037-T02 · Baseline capture:** Create a known-valid “Topological execution” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C037-T03 · Injection map:** Locate the “Topological execution” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Topological execution” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C037-T05 · Controlled trigger:** Introduce the controlled “Topological execution” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C037-T06 · Intermediate inspection:** Inspect the “Topological execution” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Topological execution”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Topological execution” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C037-T09 · Repeat and compare:** Repeat the selected “Topological execution” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C037-T10 · Failure evidence:** Publish the “Topological execution” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for runnable nodes and dispatch concurrency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Topological execution”: “Runnable nodes and dispatch concurrency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C038-T02 · Measurement method:** Choose how to observe each “Topological execution” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Topological execution”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Topological execution” cases for “Runnable nodes and dispatch concurrency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Topological execution” limit; preserve “A node executes only after its required predecessors succeed”.
- [ ] **UC-M05.01-C038-T06 · Normal measurement:** Run or review the normal “Topological execution” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C038-T07 · At-limit measurement:** Exercise the “Topological execution” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C038-T08 · Over-limit measurement:** Exercise the “Topological execution” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C038-T09 · Uncovered-scope report:** List the “Topological execution” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C038-T10 · Limit evidence:** Publish the selected “Topological execution” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for topological execution with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C039-T01 · Event inventory:** List the “Topological execution” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Topological execution” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C039-T03 · Failure mapping:** Map each documented “Topological execution” refusal or error to a diagnostic outcome; include “A dependent step starts while its prerequisite is still running” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C039-T04 · Emission path:** Add the “Topological execution” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C039-T05 · Redaction check:** Test “Topological execution” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C039-T06 · Output budget:** Set and exercise bounded “Topological execution” message size, rate and retention compatible with “Runnable nodes and dispatch concurrency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C039-T07 · Success/refusal fixtures:** Capture “Topological execution” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Topological execution” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C039-T09 · Operator review:** Read the “Topological execution” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C039-T10 · Diagnostic evidence:** Publish redacted “Topological execution” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for topological execution; label unexecuted checks as untested.

- [ ] **UC-M05.01-C040-T01 · Evidence inventory:** List the “Topological execution” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C040-T02 · Artifact references:** Record the exact “Topological execution” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C040-T03 · Fixture references:** Attach the “Topological execution” fixture IDs, input identities and oracle definition; preserve the source counterexample “A dependent step starts while its prerequisite is still running” as a distinct evidence case.
- [ ] **UC-M05.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Topological execution”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C040-T05 · Environment record:** Record the actual “Topological execution” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C040-T06 · Expected versus observed:** Pair every “Topological execution” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C040-T07 · Failure and limit records:** Attach “Topological execution” change/failure and bounds evidence where required; include uncovered “Runnable nodes and dispatch concurrency” and unresolved violations of “A node executes only after its required predecessors succeed”.
- [ ] **UC-M05.01-C040-T08 · Evidence hygiene:** Check the “Topological execution” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C040-T09 · Reproduction review:** Have the “Topological execution” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C040-T10 · Acceptance linkage:** Link the “Topological execution” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Input materialization

**Source delivery:** Materialize each step's identified inputs through approved artifact references.

**Source invariant:** A step cannot consume an ambiguous or unverified output.

**Source negative case:** A dependency output path is replaced before use.

**Source bounded quantities:** Input bytes and materialization time.

### UC-M05.01-C041 · Contract

**Original checklist item:** Specify input materialization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C041-T01 · Scope statement:** Draft the operation boundary for “Input materialization” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Input materialization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C041-T03 · Output inventory:** List the outputs of “Input materialization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Input materialization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C041-T05 · Prerequisite contract:** Map “Input materialization” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Input materialization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C041-T07 · Invariant clause:** Add a normative clause for “Input materialization” that preserves “A step cannot consume an ambiguous or unverified output”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Input materialization”; include the source counterexample “A dependency output path is replaced before use” and the intended safe disposition.
- [ ] **UC-M05.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Input bytes and materialization time” in the “Input materialization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C041-T10 · Contract review:** Review the “Input materialization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C042 · Delivery

**Original checklist item:** Materialize each step's identified inputs through approved artifact references.

- [ ] **UC-M05.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Input materialization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C042-T02 · Change plan:** Break the source delivery for “Input materialization” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Input materialization” that realizes this source instruction: Materialize each step's identified inputs through approved artifact references.
- [ ] **UC-M05.01-C042-T04 · Concrete realization:** Trace “Input materialization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Input materialization” needed to preserve “A step cannot consume an ambiguous or unverified output”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C042-T06 · Dependency connection:** Connect the “Input materialization” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C042-T07 · Resource behavior:** Account for “Input bytes and materialization time” in “Input materialization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C042-T08 · Delivery check:** Run the smallest real “Input materialization” path and its adverse fixture “A dependency output path is replaced before use”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C042-T09 · Patch review:** Review the “Input materialization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C042-T10 · Delivery handoff:** Publish the “Input materialization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A step cannot consume an ambiguous or unverified output. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Input materialization”; copy its required invariant exactly: “A step cannot consume an ambiguous or unverified output”.
- [ ] **UC-M05.01-C043-T02 · Observable terms:** Define each term in the “Input materialization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C043-T03 · Precondition set:** List the preconditions under which “A step cannot consume an ambiguous or unverified output” must hold for “Input materialization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C043-T04 · Transition coverage:** Map the “Input materialization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Input materialization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C043-T06 · Satisfying fixture:** Create a concrete “Input materialization” case that satisfies “A step cannot consume an ambiguous or unverified output”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C043-T07 · Violating fixture:** Create the source counterexample “A dependency output path is replaced before use” for “Input materialization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C043-T08 · Enforcement evidence:** Exercise the “Input materialization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C043-T09 · Regression linkage:** Link the “Input materialization” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Input materialization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C044 · Integration

**Original checklist item:** Integrate input materialization with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Input materialization” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C044-T02 · Field mapping:** Map every “Input materialization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Input materialization” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C044-T04 · Ownership agreement:** Specify who owns “Input materialization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C044-T05 · Handoff implementation:** Connect “Input materialization” through the mapped seam using the real adapter or explicit specification reference; preserve “A step cannot consume an ambiguous or unverified output” across the handoff.
- [ ] **UC-M05.01-C044-T06 · Absent-input case:** Omit one required “Input materialization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C044-T07 · Stale-input case:** Supply an outdated “Input materialization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Input materialization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C044-T09 · Valid integration trace:** Run a valid “Input materialization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C044-T10 · Seam review:** Reconcile the “Input materialization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for input materialization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Input materialization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C045-T02 · Expected-result oracle:** Specify the “Input materialization” expected result independently of the implementation output; include the property “A step cannot consume an ambiguous or unverified output” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C045-T03 · Fixture material:** Create the concrete “Input materialization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C045-T04 · Target preparation:** Prepare the “Input materialization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C045-T05 · Initial-state record:** Record the initial “Input materialization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C045-T06 · Valid-path execution:** Execute the “Input materialization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C045-T07 · Outcome comparison:** Compare every declared “Input materialization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C045-T08 · State and bounds check:** Inspect the “Input materialization” ownership/state effects and actual use of “Input bytes and materialization time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C045-T09 · Repeatability check:** Repeat the same “Input materialization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C045-T10 · Positive evidence:** Attach the “Input materialization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C046 · Negative test

**Original checklist item:** Negative case: A dependency output path is replaced before use. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Input materialization” source counterexample: “A dependency output path is replaced before use”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Input materialization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C046-T03 · Valid control:** Construct a valid “Input materialization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C046-T04 · Minimal adverse input:** Derive the “Input materialization” adverse fixture from the control with the smallest documented change needed to reproduce “A dependency output path is replaced before use”; retain that change as reproducible data.
- [ ] **UC-M05.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Input materialization”; require “A step cannot consume an ambiguous or unverified output” and forbid a false-success verdict.
- [ ] **UC-M05.01-C046-T06 · Adverse execution:** Exercise the “Input materialization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C046-T07 · Effect inspection:** Inspect “Input materialization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C046-T08 · Refusal versus failure:** Confirm the “Input materialization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C046-T09 · Reset and retention:** Restore only the disposable “Input materialization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C046-T10 · Negative regression:** Register the “Input materialization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C047 · Change / failure test

**Original checklist item:** Exercise input materialization when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C047-T01 · Scenario record:** Write the “Input materialization” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “A step cannot consume an ambiguous or unverified output”.
- [ ] **UC-M05.01-C047-T02 · Baseline capture:** Create a known-valid “Input materialization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C047-T03 · Injection map:** Locate the “Input materialization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Input materialization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C047-T05 · Controlled trigger:** Introduce the controlled “Input materialization” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C047-T06 · Intermediate inspection:** Inspect the “Input materialization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Input materialization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Input materialization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C047-T09 · Repeat and compare:** Repeat the selected “Input materialization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C047-T10 · Failure evidence:** Publish the “Input materialization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for input bytes and materialization time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Input materialization”: “Input bytes and materialization time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C048-T02 · Measurement method:** Choose how to observe each “Input materialization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Input materialization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Input materialization” cases for “Input bytes and materialization time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Input materialization” limit; preserve “A step cannot consume an ambiguous or unverified output”.
- [ ] **UC-M05.01-C048-T06 · Normal measurement:** Run or review the normal “Input materialization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C048-T07 · At-limit measurement:** Exercise the “Input materialization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C048-T08 · Over-limit measurement:** Exercise the “Input materialization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C048-T09 · Uncovered-scope report:** List the “Input materialization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C048-T10 · Limit evidence:** Publish the selected “Input materialization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for input materialization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C049-T01 · Event inventory:** List the “Input materialization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Input materialization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C049-T03 · Failure mapping:** Map each documented “Input materialization” refusal or error to a diagnostic outcome; include “A dependency output path is replaced before use” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C049-T04 · Emission path:** Add the “Input materialization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C049-T05 · Redaction check:** Test “Input materialization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C049-T06 · Output budget:** Set and exercise bounded “Input materialization” message size, rate and retention compatible with “Input bytes and materialization time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C049-T07 · Success/refusal fixtures:** Capture “Input materialization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Input materialization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C049-T09 · Operator review:** Read the “Input materialization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C049-T10 · Diagnostic evidence:** Publish redacted “Input materialization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for input materialization; label unexecuted checks as untested.

- [ ] **UC-M05.01-C050-T01 · Evidence inventory:** List the “Input materialization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C050-T02 · Artifact references:** Record the exact “Input materialization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C050-T03 · Fixture references:** Attach the “Input materialization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A dependency output path is replaced before use” as a distinct evidence case.
- [ ] **UC-M05.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Input materialization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C050-T05 · Environment record:** Record the actual “Input materialization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C050-T06 · Expected versus observed:** Pair every “Input materialization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C050-T07 · Failure and limit records:** Attach “Input materialization” change/failure and bounds evidence where required; include uncovered “Input bytes and materialization time” and unresolved violations of “A step cannot consume an ambiguous or unverified output”.
- [ ] **UC-M05.01-C050-T08 · Evidence hygiene:** Check the “Input materialization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C050-T09 · Reproduction review:** Have the “Input materialization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C050-T10 · Acceptance linkage:** Link the “Input materialization” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Output publication

**Source delivery:** Publish explicit typed outputs only after the producing invocation commits.

**Source invariant:** File presence alone does not prove successful step completion.

**Source negative case:** A failed producer leaves a partial output that a consumer reads.

**Source bounded quantities:** Output count and staged output bytes.

### UC-M05.01-C051 · Contract

**Original checklist item:** Specify output publication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C051-T01 · Scope statement:** Draft the operation boundary for “Output publication” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Output publication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C051-T03 · Output inventory:** List the outputs of “Output publication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Output publication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C051-T05 · Prerequisite contract:** Map “Output publication” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Output publication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C051-T07 · Invariant clause:** Add a normative clause for “Output publication” that preserves “File presence alone does not prove successful step completion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Output publication”; include the source counterexample “A failed producer leaves a partial output that a consumer reads” and the intended safe disposition.
- [ ] **UC-M05.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Output count and staged output bytes” in the “Output publication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C051-T10 · Contract review:** Review the “Output publication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C052 · Delivery

**Original checklist item:** Publish explicit typed outputs only after the producing invocation commits.

- [ ] **UC-M05.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Output publication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C052-T02 · Change plan:** Break the source delivery for “Output publication” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C052-T03 · Core artifact:** Create the “Output publication” output artifact for this source instruction: Publish explicit typed outputs only after the producing invocation commits.
- [ ] **UC-M05.01-C052-T04 · Concrete realization:** Populate the “Output publication” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M05.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Output publication” needed to preserve “File presence alone does not prove successful step completion”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C052-T06 · Dependency connection:** Connect the “Output publication” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C052-T07 · Resource behavior:** Account for “Output count and staged output bytes” in “Output publication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C052-T08 · Delivery check:** Run the smallest real “Output publication” path and its adverse fixture “A failed producer leaves a partial output that a consumer reads”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C052-T09 · Patch review:** Review the “Output publication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C052-T10 · Delivery handoff:** Publish the “Output publication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: File presence alone does not prove successful step completion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Output publication”; copy its required invariant exactly: “File presence alone does not prove successful step completion”.
- [ ] **UC-M05.01-C053-T02 · Observable terms:** Define each term in the “Output publication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C053-T03 · Precondition set:** List the preconditions under which “File presence alone does not prove successful step completion” must hold for “Output publication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C053-T04 · Transition coverage:** Map the “Output publication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Output publication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C053-T06 · Satisfying fixture:** Create a concrete “Output publication” case that satisfies “File presence alone does not prove successful step completion”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C053-T07 · Violating fixture:** Create the source counterexample “A failed producer leaves a partial output that a consumer reads” for “Output publication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C053-T08 · Enforcement evidence:** Exercise the “Output publication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C053-T09 · Regression linkage:** Link the “Output publication” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Output publication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C054 · Integration

**Original checklist item:** Integrate output publication with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Output publication” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C054-T02 · Field mapping:** Map every “Output publication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Output publication” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C054-T04 · Ownership agreement:** Specify who owns “Output publication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C054-T05 · Handoff implementation:** Connect “Output publication” through the mapped seam using the real adapter or explicit specification reference; preserve “File presence alone does not prove successful step completion” across the handoff.
- [ ] **UC-M05.01-C054-T06 · Absent-input case:** Omit one required “Output publication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C054-T07 · Stale-input case:** Supply an outdated “Output publication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Output publication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C054-T09 · Valid integration trace:** Run a valid “Output publication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C054-T10 · Seam review:** Reconcile the “Output publication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for output publication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Output publication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C055-T02 · Expected-result oracle:** Specify the “Output publication” expected result independently of the implementation output; include the property “File presence alone does not prove successful step completion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C055-T03 · Fixture material:** Create the concrete “Output publication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C055-T04 · Target preparation:** Prepare the “Output publication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C055-T05 · Initial-state record:** Record the initial “Output publication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C055-T06 · Valid-path execution:** Execute the “Output publication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C055-T07 · Outcome comparison:** Compare every declared “Output publication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C055-T08 · State and bounds check:** Inspect the “Output publication” ownership/state effects and actual use of “Output count and staged output bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C055-T09 · Repeatability check:** Repeat the same “Output publication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C055-T10 · Positive evidence:** Attach the “Output publication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C056 · Negative test

**Original checklist item:** Negative case: A failed producer leaves a partial output that a consumer reads. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Output publication” source counterexample: “A failed producer leaves a partial output that a consumer reads”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Output publication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C056-T03 · Valid control:** Construct a valid “Output publication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C056-T04 · Minimal adverse input:** Derive the “Output publication” adverse fixture from the control with the smallest documented change needed to reproduce “A failed producer leaves a partial output that a consumer reads”; retain that change as reproducible data.
- [ ] **UC-M05.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Output publication”; require “File presence alone does not prove successful step completion” and forbid a false-success verdict.
- [ ] **UC-M05.01-C056-T06 · Adverse execution:** Exercise the “Output publication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C056-T07 · Effect inspection:** Inspect “Output publication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C056-T08 · Refusal versus failure:** Confirm the “Output publication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C056-T09 · Reset and retention:** Restore only the disposable “Output publication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C056-T10 · Negative regression:** Register the “Output publication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C057 · Change / failure test

**Original checklist item:** Exercise output publication when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C057-T01 · Scenario record:** Write the “Output publication” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “File presence alone does not prove successful step completion”.
- [ ] **UC-M05.01-C057-T02 · Baseline capture:** Create a known-valid “Output publication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C057-T03 · Injection map:** Locate the “Output publication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Output publication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C057-T05 · Controlled trigger:** Introduce the controlled “Output publication” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C057-T06 · Intermediate inspection:** Inspect the “Output publication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Output publication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Output publication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C057-T09 · Repeat and compare:** Repeat the selected “Output publication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C057-T10 · Failure evidence:** Publish the “Output publication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for output count and staged output bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Output publication”: “Output count and staged output bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C058-T02 · Measurement method:** Choose how to observe each “Output publication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Output publication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Output publication” cases for “Output count and staged output bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Output publication” limit; preserve “File presence alone does not prove successful step completion”.
- [ ] **UC-M05.01-C058-T06 · Normal measurement:** Run or review the normal “Output publication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C058-T07 · At-limit measurement:** Exercise the “Output publication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C058-T08 · Over-limit measurement:** Exercise the “Output publication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C058-T09 · Uncovered-scope report:** List the “Output publication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C058-T10 · Limit evidence:** Publish the selected “Output publication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for output publication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C059-T01 · Event inventory:** List the “Output publication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Output publication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C059-T03 · Failure mapping:** Map each documented “Output publication” refusal or error to a diagnostic outcome; include “A failed producer leaves a partial output that a consumer reads” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C059-T04 · Emission path:** Add the “Output publication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C059-T05 · Redaction check:** Test “Output publication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C059-T06 · Output budget:** Set and exercise bounded “Output publication” message size, rate and retention compatible with “Output count and staged output bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C059-T07 · Success/refusal fixtures:** Capture “Output publication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Output publication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C059-T09 · Operator review:** Read the “Output publication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C059-T10 · Diagnostic evidence:** Publish redacted “Output publication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for output publication; label unexecuted checks as untested.

- [ ] **UC-M05.01-C060-T01 · Evidence inventory:** List the “Output publication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C060-T02 · Artifact references:** Record the exact “Output publication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C060-T03 · Fixture references:** Attach the “Output publication” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed producer leaves a partial output that a consumer reads” as a distinct evidence case.
- [ ] **UC-M05.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Output publication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C060-T05 · Environment record:** Record the actual “Output publication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C060-T06 · Expected versus observed:** Pair every “Output publication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C060-T07 · Failure and limit records:** Attach “Output publication” change/failure and bounds evidence where required; include uncovered “Output count and staged output bytes” and unresolved violations of “File presence alone does not prove successful step completion”.
- [ ] **UC-M05.01-C060-T08 · Evidence hygiene:** Check the “Output publication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C060-T09 · Reproduction review:** Have the “Output publication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C060-T10 · Acceptance linkage:** Link the “Output publication” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Failure propagation

**Source delivery:** Define which dependent nodes block, cancel or become retryable after a step fails.

**Source invariant:** Failure cannot be hidden by continuing as though the output existed.

**Source negative case:** A failed root step is ignored and descendants report success.

**Source bounded quantities:** Blocked descendants and propagation delay.

### UC-M05.01-C061 · Contract

**Original checklist item:** Specify failure propagation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C061-T01 · Scope statement:** Draft the operation boundary for “Failure propagation” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure propagation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C061-T03 · Output inventory:** List the outputs of “Failure propagation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure propagation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C061-T05 · Prerequisite contract:** Map “Failure propagation” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Failure propagation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C061-T07 · Invariant clause:** Add a normative clause for “Failure propagation” that preserves “Failure cannot be hidden by continuing as though the output existed”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure propagation”; include the source counterexample “A failed root step is ignored and descendants report success” and the intended safe disposition.
- [ ] **UC-M05.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Blocked descendants and propagation delay” in the “Failure propagation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C061-T10 · Contract review:** Review the “Failure propagation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C062 · Delivery

**Original checklist item:** Define which dependent nodes block, cancel or become retryable after a step fails.

- [ ] **UC-M05.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure propagation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C062-T02 · Change plan:** Break the source delivery for “Failure propagation” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C062-T03 · Core artifact:** Create the “Failure propagation” model, schema or inventory that realizes this source instruction: Define which dependent nodes block, cancel or become retryable after a step fails.
- [ ] **UC-M05.01-C062-T04 · Concrete realization:** Populate “Failure propagation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure propagation” needed to preserve “Failure cannot be hidden by continuing as though the output existed”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C062-T06 · Dependency connection:** Connect the “Failure propagation” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C062-T07 · Resource behavior:** Account for “Blocked descendants and propagation delay” in “Failure propagation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C062-T08 · Delivery check:** Run the smallest real “Failure propagation” path and its adverse fixture “A failed root step is ignored and descendants report success”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C062-T09 · Patch review:** Review the “Failure propagation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C062-T10 · Delivery handoff:** Publish the “Failure propagation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Failure cannot be hidden by continuing as though the output existed. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Failure propagation”; copy its required invariant exactly: “Failure cannot be hidden by continuing as though the output existed”.
- [ ] **UC-M05.01-C063-T02 · Observable terms:** Define each term in the “Failure propagation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C063-T03 · Precondition set:** List the preconditions under which “Failure cannot be hidden by continuing as though the output existed” must hold for “Failure propagation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C063-T04 · Transition coverage:** Map the “Failure propagation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure propagation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C063-T06 · Satisfying fixture:** Create a concrete “Failure propagation” case that satisfies “Failure cannot be hidden by continuing as though the output existed”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C063-T07 · Violating fixture:** Create the source counterexample “A failed root step is ignored and descendants report success” for “Failure propagation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C063-T08 · Enforcement evidence:** Exercise the “Failure propagation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C063-T09 · Regression linkage:** Link the “Failure propagation” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Failure propagation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C064 · Integration

**Original checklist item:** Integrate failure propagation with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure propagation” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C064-T02 · Field mapping:** Map every “Failure propagation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure propagation” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C064-T04 · Ownership agreement:** Specify who owns “Failure propagation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C064-T05 · Handoff implementation:** Connect “Failure propagation” through the mapped seam using the real adapter or explicit specification reference; preserve “Failure cannot be hidden by continuing as though the output existed” across the handoff.
- [ ] **UC-M05.01-C064-T06 · Absent-input case:** Omit one required “Failure propagation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C064-T07 · Stale-input case:** Supply an outdated “Failure propagation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Failure propagation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C064-T09 · Valid integration trace:** Run a valid “Failure propagation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C064-T10 · Seam review:** Reconcile the “Failure propagation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure propagation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure propagation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C065-T02 · Expected-result oracle:** Specify the “Failure propagation” expected result independently of the implementation output; include the property “Failure cannot be hidden by continuing as though the output existed” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C065-T03 · Fixture material:** Create the concrete “Failure propagation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C065-T04 · Target preparation:** Prepare the “Failure propagation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C065-T05 · Initial-state record:** Record the initial “Failure propagation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C065-T06 · Valid-path execution:** Execute the “Failure propagation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C065-T07 · Outcome comparison:** Compare every declared “Failure propagation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C065-T08 · State and bounds check:** Inspect the “Failure propagation” ownership/state effects and actual use of “Blocked descendants and propagation delay”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C065-T09 · Repeatability check:** Repeat the same “Failure propagation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C065-T10 · Positive evidence:** Attach the “Failure propagation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C066 · Negative test

**Original checklist item:** Negative case: A failed root step is ignored and descendants report success. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Failure propagation” source counterexample: “A failed root step is ignored and descendants report success”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure propagation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C066-T03 · Valid control:** Construct a valid “Failure propagation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C066-T04 · Minimal adverse input:** Derive the “Failure propagation” adverse fixture from the control with the smallest documented change needed to reproduce “A failed root step is ignored and descendants report success”; retain that change as reproducible data.
- [ ] **UC-M05.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure propagation”; require “Failure cannot be hidden by continuing as though the output existed” and forbid a false-success verdict.
- [ ] **UC-M05.01-C066-T06 · Adverse execution:** Exercise the “Failure propagation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C066-T07 · Effect inspection:** Inspect “Failure propagation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C066-T08 · Refusal versus failure:** Confirm the “Failure propagation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C066-T09 · Reset and retention:** Restore only the disposable “Failure propagation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C066-T10 · Negative regression:** Register the “Failure propagation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C067 · Change / failure test

**Original checklist item:** Exercise failure propagation when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C067-T01 · Scenario record:** Write the “Failure propagation” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “Failure cannot be hidden by continuing as though the output existed”.
- [ ] **UC-M05.01-C067-T02 · Baseline capture:** Create a known-valid “Failure propagation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C067-T03 · Injection map:** Locate the “Failure propagation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Failure propagation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C067-T05 · Controlled trigger:** Introduce the controlled “Failure propagation” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C067-T06 · Intermediate inspection:** Inspect the “Failure propagation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure propagation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure propagation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C067-T09 · Repeat and compare:** Repeat the selected “Failure propagation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C067-T10 · Failure evidence:** Publish the “Failure propagation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for blocked descendants and propagation delay; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Failure propagation”: “Blocked descendants and propagation delay”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C068-T02 · Measurement method:** Choose how to observe each “Failure propagation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Failure propagation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure propagation” cases for “Blocked descendants and propagation delay”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure propagation” limit; preserve “Failure cannot be hidden by continuing as though the output existed”.
- [ ] **UC-M05.01-C068-T06 · Normal measurement:** Run or review the normal “Failure propagation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C068-T07 · At-limit measurement:** Exercise the “Failure propagation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C068-T08 · Over-limit measurement:** Exercise the “Failure propagation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C068-T09 · Uncovered-scope report:** List the “Failure propagation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C068-T10 · Limit evidence:** Publish the selected “Failure propagation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure propagation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C069-T01 · Event inventory:** List the “Failure propagation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Failure propagation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C069-T03 · Failure mapping:** Map each documented “Failure propagation” refusal or error to a diagnostic outcome; include “A failed root step is ignored and descendants report success” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C069-T04 · Emission path:** Add the “Failure propagation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C069-T05 · Redaction check:** Test “Failure propagation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C069-T06 · Output budget:** Set and exercise bounded “Failure propagation” message size, rate and retention compatible with “Blocked descendants and propagation delay”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C069-T07 · Success/refusal fixtures:** Capture “Failure propagation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure propagation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C069-T09 · Operator review:** Read the “Failure propagation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C069-T10 · Diagnostic evidence:** Publish redacted “Failure propagation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure propagation; label unexecuted checks as untested.

- [ ] **UC-M05.01-C070-T01 · Evidence inventory:** List the “Failure propagation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C070-T02 · Artifact references:** Record the exact “Failure propagation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C070-T03 · Fixture references:** Attach the “Failure propagation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed root step is ignored and descendants report success” as a distinct evidence case.
- [ ] **UC-M05.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure propagation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C070-T05 · Environment record:** Record the actual “Failure propagation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C070-T06 · Expected versus observed:** Pair every “Failure propagation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C070-T07 · Failure and limit records:** Attach “Failure propagation” change/failure and bounds evidence where required; include uncovered “Blocked descendants and propagation delay” and unresolved violations of “Failure cannot be hidden by continuing as though the output existed”.
- [ ] **UC-M05.01-C070-T08 · Evidence hygiene:** Check the “Failure propagation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C070-T09 · Reproduction review:** Have the “Failure propagation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C070-T10 · Acceptance linkage:** Link the “Failure propagation” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Invocation identity

**Source delivery:** Assign stable work and invocation IDs to each planned step and generation.

**Source invariant:** Repeated dispatch cannot silently duplicate a committed side effect.

**Source negative case:** The controller redelivers a completed node with a new accidental identity.

**Source bounded quantities:** Invocation records and deduplication span.

### UC-M05.01-C071 · Contract

**Original checklist item:** Specify invocation identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C071-T01 · Scope statement:** Draft the operation boundary for “Invocation identity” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Invocation identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C071-T03 · Output inventory:** List the outputs of “Invocation identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Invocation identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C071-T05 · Prerequisite contract:** Map “Invocation identity” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Invocation identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C071-T07 · Invariant clause:** Add a normative clause for “Invocation identity” that preserves “Repeated dispatch cannot silently duplicate a committed side effect”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Invocation identity”; include the source counterexample “The controller redelivers a completed node with a new accidental identity” and the intended safe disposition.
- [ ] **UC-M05.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Invocation records and deduplication span” in the “Invocation identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C071-T10 · Contract review:** Review the “Invocation identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C072 · Delivery

**Original checklist item:** Assign stable work and invocation IDs to each planned step and generation.

- [ ] **UC-M05.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Invocation identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C072-T02 · Change plan:** Break the source delivery for “Invocation identity” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Invocation identity” that realizes this source instruction: Assign stable work and invocation IDs to each planned step and generation.
- [ ] **UC-M05.01-C072-T04 · Concrete realization:** Trace “Invocation identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Invocation identity” needed to preserve “Repeated dispatch cannot silently duplicate a committed side effect”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C072-T06 · Dependency connection:** Connect the “Invocation identity” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C072-T07 · Resource behavior:** Account for “Invocation records and deduplication span” in “Invocation identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C072-T08 · Delivery check:** Run the smallest real “Invocation identity” path and its adverse fixture “The controller redelivers a completed node with a new accidental identity”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C072-T09 · Patch review:** Review the “Invocation identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C072-T10 · Delivery handoff:** Publish the “Invocation identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Repeated dispatch cannot silently duplicate a committed side effect. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Invocation identity”; copy its required invariant exactly: “Repeated dispatch cannot silently duplicate a committed side effect”.
- [ ] **UC-M05.01-C073-T02 · Observable terms:** Define each term in the “Invocation identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C073-T03 · Precondition set:** List the preconditions under which “Repeated dispatch cannot silently duplicate a committed side effect” must hold for “Invocation identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C073-T04 · Transition coverage:** Map the “Invocation identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Invocation identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C073-T06 · Satisfying fixture:** Create a concrete “Invocation identity” case that satisfies “Repeated dispatch cannot silently duplicate a committed side effect”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C073-T07 · Violating fixture:** Create the source counterexample “The controller redelivers a completed node with a new accidental identity” for “Invocation identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C073-T08 · Enforcement evidence:** Exercise the “Invocation identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C073-T09 · Regression linkage:** Link the “Invocation identity” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Invocation identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C074 · Integration

**Original checklist item:** Integrate invocation identity with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Invocation identity” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C074-T02 · Field mapping:** Map every “Invocation identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Invocation identity” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C074-T04 · Ownership agreement:** Specify who owns “Invocation identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C074-T05 · Handoff implementation:** Connect “Invocation identity” through the mapped seam using the real adapter or explicit specification reference; preserve “Repeated dispatch cannot silently duplicate a committed side effect” across the handoff.
- [ ] **UC-M05.01-C074-T06 · Absent-input case:** Omit one required “Invocation identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C074-T07 · Stale-input case:** Supply an outdated “Invocation identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Invocation identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C074-T09 · Valid integration trace:** Run a valid “Invocation identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C074-T10 · Seam review:** Reconcile the “Invocation identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for invocation identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Invocation identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C075-T02 · Expected-result oracle:** Specify the “Invocation identity” expected result independently of the implementation output; include the property “Repeated dispatch cannot silently duplicate a committed side effect” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C075-T03 · Fixture material:** Create the concrete “Invocation identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C075-T04 · Target preparation:** Prepare the “Invocation identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C075-T05 · Initial-state record:** Record the initial “Invocation identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C075-T06 · Valid-path execution:** Execute the “Invocation identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C075-T07 · Outcome comparison:** Compare every declared “Invocation identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C075-T08 · State and bounds check:** Inspect the “Invocation identity” ownership/state effects and actual use of “Invocation records and deduplication span”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C075-T09 · Repeatability check:** Repeat the same “Invocation identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C075-T10 · Positive evidence:** Attach the “Invocation identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C076 · Negative test

**Original checklist item:** Negative case: The controller redelivers a completed node with a new accidental identity. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Invocation identity” source counterexample: “The controller redelivers a completed node with a new accidental identity”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Invocation identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C076-T03 · Valid control:** Construct a valid “Invocation identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C076-T04 · Minimal adverse input:** Derive the “Invocation identity” adverse fixture from the control with the smallest documented change needed to reproduce “The controller redelivers a completed node with a new accidental identity”; retain that change as reproducible data.
- [ ] **UC-M05.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Invocation identity”; require “Repeated dispatch cannot silently duplicate a committed side effect” and forbid a false-success verdict.
- [ ] **UC-M05.01-C076-T06 · Adverse execution:** Exercise the “Invocation identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C076-T07 · Effect inspection:** Inspect “Invocation identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C076-T08 · Refusal versus failure:** Confirm the “Invocation identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C076-T09 · Reset and retention:** Restore only the disposable “Invocation identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C076-T10 · Negative regression:** Register the “Invocation identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C077 · Change / failure test

**Original checklist item:** Exercise invocation identity when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C077-T01 · Scenario record:** Write the “Invocation identity” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “Repeated dispatch cannot silently duplicate a committed side effect”.
- [ ] **UC-M05.01-C077-T02 · Baseline capture:** Create a known-valid “Invocation identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C077-T03 · Injection map:** Locate the “Invocation identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Invocation identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C077-T05 · Controlled trigger:** Introduce the controlled “Invocation identity” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C077-T06 · Intermediate inspection:** Inspect the “Invocation identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Invocation identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Invocation identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C077-T09 · Repeat and compare:** Repeat the selected “Invocation identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C077-T10 · Failure evidence:** Publish the “Invocation identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for invocation records and deduplication span; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Invocation identity”: “Invocation records and deduplication span”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C078-T02 · Measurement method:** Choose how to observe each “Invocation identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Invocation identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Invocation identity” cases for “Invocation records and deduplication span”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Invocation identity” limit; preserve “Repeated dispatch cannot silently duplicate a committed side effect”.
- [ ] **UC-M05.01-C078-T06 · Normal measurement:** Run or review the normal “Invocation identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C078-T07 · At-limit measurement:** Exercise the “Invocation identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C078-T08 · Over-limit measurement:** Exercise the “Invocation identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C078-T09 · Uncovered-scope report:** List the “Invocation identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C078-T10 · Limit evidence:** Publish the selected “Invocation identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for invocation identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C079-T01 · Event inventory:** List the “Invocation identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Invocation identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C079-T03 · Failure mapping:** Map each documented “Invocation identity” refusal or error to a diagnostic outcome; include “The controller redelivers a completed node with a new accidental identity” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C079-T04 · Emission path:** Add the “Invocation identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C079-T05 · Redaction check:** Test “Invocation identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C079-T06 · Output budget:** Set and exercise bounded “Invocation identity” message size, rate and retention compatible with “Invocation records and deduplication span”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C079-T07 · Success/refusal fixtures:** Capture “Invocation identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Invocation identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C079-T09 · Operator review:** Read the “Invocation identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C079-T10 · Diagnostic evidence:** Publish redacted “Invocation identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for invocation identity; label unexecuted checks as untested.

- [ ] **UC-M05.01-C080-T01 · Evidence inventory:** List the “Invocation identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C080-T02 · Artifact references:** Record the exact “Invocation identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C080-T03 · Fixture references:** Attach the “Invocation identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “The controller redelivers a completed node with a new accidental identity” as a distinct evidence case.
- [ ] **UC-M05.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Invocation identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C080-T05 · Environment record:** Record the actual “Invocation identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C080-T06 · Expected versus observed:** Pair every “Invocation identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C080-T07 · Failure and limit records:** Attach “Invocation identity” change/failure and bounds evidence where required; include uncovered “Invocation records and deduplication span” and unresolved violations of “Repeated dispatch cannot silently duplicate a committed side effect”.
- [ ] **UC-M05.01-C080-T08 · Evidence hygiene:** Check the “Invocation identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C080-T09 · Reproduction review:** Have the “Invocation identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C080-T10 · Acceptance linkage:** Link the “Invocation identity” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Backend requirement binding

**Source delivery:** Bind each node to required ISA, isolation and runtime capabilities.

**Source invariant:** An executable plan cannot weaken a node's hard requirements.

**Source negative case:** A guest-required node is sent to a host-only adapter.

**Source bounded quantities:** Capability checks and supported node profiles.

### UC-M05.01-C081 · Contract

**Original checklist item:** Specify backend requirement binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C081-T01 · Scope statement:** Draft the operation boundary for “Backend requirement binding” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backend requirement binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C081-T03 · Output inventory:** List the outputs of “Backend requirement binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Backend requirement binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C081-T05 · Prerequisite contract:** Map “Backend requirement binding” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Backend requirement binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C081-T07 · Invariant clause:** Add a normative clause for “Backend requirement binding” that preserves “An executable plan cannot weaken a node's hard requirements”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backend requirement binding”; include the source counterexample “A guest-required node is sent to a host-only adapter” and the intended safe disposition.
- [ ] **UC-M05.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capability checks and supported node profiles” in the “Backend requirement binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C081-T10 · Contract review:** Review the “Backend requirement binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C082 · Delivery

**Original checklist item:** Bind each node to required ISA, isolation and runtime capabilities.

- [ ] **UC-M05.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backend requirement binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C082-T02 · Change plan:** Break the source delivery for “Backend requirement binding” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Backend requirement binding” that realizes this source instruction: Bind each node to required ISA, isolation and runtime capabilities.
- [ ] **UC-M05.01-C082-T04 · Concrete realization:** Trace “Backend requirement binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backend requirement binding” needed to preserve “An executable plan cannot weaken a node's hard requirements”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C082-T06 · Dependency connection:** Connect the “Backend requirement binding” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C082-T07 · Resource behavior:** Account for “Capability checks and supported node profiles” in “Backend requirement binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C082-T08 · Delivery check:** Run the smallest real “Backend requirement binding” path and its adverse fixture “A guest-required node is sent to a host-only adapter”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C082-T09 · Patch review:** Review the “Backend requirement binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C082-T10 · Delivery handoff:** Publish the “Backend requirement binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An executable plan cannot weaken a node's hard requirements. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Backend requirement binding”; copy its required invariant exactly: “An executable plan cannot weaken a node's hard requirements”.
- [ ] **UC-M05.01-C083-T02 · Observable terms:** Define each term in the “Backend requirement binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C083-T03 · Precondition set:** List the preconditions under which “An executable plan cannot weaken a node's hard requirements” must hold for “Backend requirement binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C083-T04 · Transition coverage:** Map the “Backend requirement binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backend requirement binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C083-T06 · Satisfying fixture:** Create a concrete “Backend requirement binding” case that satisfies “An executable plan cannot weaken a node's hard requirements”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C083-T07 · Violating fixture:** Create the source counterexample “A guest-required node is sent to a host-only adapter” for “Backend requirement binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C083-T08 · Enforcement evidence:** Exercise the “Backend requirement binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C083-T09 · Regression linkage:** Link the “Backend requirement binding” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Backend requirement binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C084 · Integration

**Original checklist item:** Integrate backend requirement binding with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backend requirement binding” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C084-T02 · Field mapping:** Map every “Backend requirement binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Backend requirement binding” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C084-T04 · Ownership agreement:** Specify who owns “Backend requirement binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C084-T05 · Handoff implementation:** Connect “Backend requirement binding” through the mapped seam using the real adapter or explicit specification reference; preserve “An executable plan cannot weaken a node's hard requirements” across the handoff.
- [ ] **UC-M05.01-C084-T06 · Absent-input case:** Omit one required “Backend requirement binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C084-T07 · Stale-input case:** Supply an outdated “Backend requirement binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Backend requirement binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C084-T09 · Valid integration trace:** Run a valid “Backend requirement binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C084-T10 · Seam review:** Reconcile the “Backend requirement binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for backend requirement binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Backend requirement binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C085-T02 · Expected-result oracle:** Specify the “Backend requirement binding” expected result independently of the implementation output; include the property “An executable plan cannot weaken a node's hard requirements” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C085-T03 · Fixture material:** Create the concrete “Backend requirement binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C085-T04 · Target preparation:** Prepare the “Backend requirement binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C085-T05 · Initial-state record:** Record the initial “Backend requirement binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C085-T06 · Valid-path execution:** Execute the “Backend requirement binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C085-T07 · Outcome comparison:** Compare every declared “Backend requirement binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C085-T08 · State and bounds check:** Inspect the “Backend requirement binding” ownership/state effects and actual use of “Capability checks and supported node profiles”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C085-T09 · Repeatability check:** Repeat the same “Backend requirement binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C085-T10 · Positive evidence:** Attach the “Backend requirement binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C086 · Negative test

**Original checklist item:** Negative case: A guest-required node is sent to a host-only adapter. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Backend requirement binding” source counterexample: “A guest-required node is sent to a host-only adapter”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Backend requirement binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C086-T03 · Valid control:** Construct a valid “Backend requirement binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C086-T04 · Minimal adverse input:** Derive the “Backend requirement binding” adverse fixture from the control with the smallest documented change needed to reproduce “A guest-required node is sent to a host-only adapter”; retain that change as reproducible data.
- [ ] **UC-M05.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backend requirement binding”; require “An executable plan cannot weaken a node's hard requirements” and forbid a false-success verdict.
- [ ] **UC-M05.01-C086-T06 · Adverse execution:** Exercise the “Backend requirement binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C086-T07 · Effect inspection:** Inspect “Backend requirement binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C086-T08 · Refusal versus failure:** Confirm the “Backend requirement binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C086-T09 · Reset and retention:** Restore only the disposable “Backend requirement binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C086-T10 · Negative regression:** Register the “Backend requirement binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C087 · Change / failure test

**Original checklist item:** Exercise backend requirement binding when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C087-T01 · Scenario record:** Write the “Backend requirement binding” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “An executable plan cannot weaken a node's hard requirements”.
- [ ] **UC-M05.01-C087-T02 · Baseline capture:** Create a known-valid “Backend requirement binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C087-T03 · Injection map:** Locate the “Backend requirement binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Backend requirement binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C087-T05 · Controlled trigger:** Introduce the controlled “Backend requirement binding” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C087-T06 · Intermediate inspection:** Inspect the “Backend requirement binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backend requirement binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Backend requirement binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C087-T09 · Repeat and compare:** Repeat the selected “Backend requirement binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C087-T10 · Failure evidence:** Publish the “Backend requirement binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for capability checks and supported node profiles; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Backend requirement binding”: “Capability checks and supported node profiles”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C088-T02 · Measurement method:** Choose how to observe each “Backend requirement binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Backend requirement binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backend requirement binding” cases for “Capability checks and supported node profiles”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backend requirement binding” limit; preserve “An executable plan cannot weaken a node's hard requirements”.
- [ ] **UC-M05.01-C088-T06 · Normal measurement:** Run or review the normal “Backend requirement binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C088-T07 · At-limit measurement:** Exercise the “Backend requirement binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C088-T08 · Over-limit measurement:** Exercise the “Backend requirement binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C088-T09 · Uncovered-scope report:** List the “Backend requirement binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C088-T10 · Limit evidence:** Publish the selected “Backend requirement binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for backend requirement binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C089-T01 · Event inventory:** List the “Backend requirement binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Backend requirement binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C089-T03 · Failure mapping:** Map each documented “Backend requirement binding” refusal or error to a diagnostic outcome; include “A guest-required node is sent to a host-only adapter” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C089-T04 · Emission path:** Add the “Backend requirement binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C089-T05 · Redaction check:** Test “Backend requirement binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C089-T06 · Output budget:** Set and exercise bounded “Backend requirement binding” message size, rate and retention compatible with “Capability checks and supported node profiles”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C089-T07 · Success/refusal fixtures:** Capture “Backend requirement binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Backend requirement binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C089-T09 · Operator review:** Read the “Backend requirement binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C089-T10 · Diagnostic evidence:** Publish redacted “Backend requirement binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backend requirement binding; label unexecuted checks as untested.

- [ ] **UC-M05.01-C090-T01 · Evidence inventory:** List the “Backend requirement binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C090-T02 · Artifact references:** Record the exact “Backend requirement binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C090-T03 · Fixture references:** Attach the “Backend requirement binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest-required node is sent to a host-only adapter” as a distinct evidence case.
- [ ] **UC-M05.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backend requirement binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C090-T05 · Environment record:** Record the actual “Backend requirement binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C090-T06 · Expected versus observed:** Pair every “Backend requirement binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C090-T07 · Failure and limit records:** Attach “Backend requirement binding” change/failure and bounds evidence where required; include uncovered “Capability checks and supported node profiles” and unresolved violations of “An executable plan cannot weaken a node's hard requirements”.
- [ ] **UC-M05.01-C090-T08 · Evidence hygiene:** Check the “Backend requirement binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C090-T09 · Reproduction review:** Have the “Backend requirement binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C090-T10 · Acceptance linkage:** Link the “Backend requirement binding” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. DAG acceptance fixture

**Source delivery:** Run a nontrivial multi-step workload and verify ordered execution and outputs.

**Source invariant:** The acceptance evidence shows actual invocations, not only planned paths.

**Source negative case:** A test passes using a graph visualization without executing its steps.

**Source bounded quantities:** Fixture nodes, runtime and artifact bytes.

### UC-M05.01-C091 · Contract

**Original checklist item:** Specify DAG acceptance fixture inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.01-C091-T01 · Scope statement:** Draft the operation boundary for “DAG acceptance fixture” within Executable workload DAG planner; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “DAG acceptance fixture”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.01-C091-T03 · Output inventory:** List the outputs of “DAG acceptance fixture” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “DAG acceptance fixture”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.01-C091-T05 · Prerequisite contract:** Map “DAG acceptance fixture” to the source component prerequisites (UC-M01.07, UC-M01.08, UC-M03.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.01-C091-T06 · Authority map:** Identify who may produce, change and consume “DAG acceptance fixture”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.01-C091-T07 · Invariant clause:** Add a normative clause for “DAG acceptance fixture” that preserves “The acceptance evidence shows actual invocations, not only planned paths”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “DAG acceptance fixture”; include the source counterexample “A test passes using a graph visualization without executing its steps” and the intended safe disposition.
- [ ] **UC-M05.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture nodes, runtime and artifact bytes” in the “DAG acceptance fixture” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.01-C091-T10 · Contract review:** Review the “DAG acceptance fixture” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.01-C092 · Delivery

**Original checklist item:** Run a nontrivial multi-step workload and verify ordered execution and outputs.

- [ ] **UC-M05.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “DAG acceptance fixture”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.01-C092-T02 · Change plan:** Break the source delivery for “DAG acceptance fixture” into concrete edit targets and reviewable outputs; keep the UC-M05.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.01-C092-T03 · Core artifact:** Create the “DAG acceptance fixture” fixture or harness for this source instruction: Run a nontrivial multi-step workload and verify ordered execution and outputs.
- [ ] **UC-M05.01-C092-T04 · Concrete realization:** Connect the “DAG acceptance fixture” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “DAG acceptance fixture” needed to preserve “The acceptance evidence shows actual invocations, not only planned paths”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.01-C092-T06 · Dependency connection:** Connect the “DAG acceptance fixture” implementation to typed workload graphs, artifact handoff and backend invocations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.01-C092-T07 · Resource behavior:** Account for “Fixture nodes, runtime and artifact bytes” in “DAG acceptance fixture”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.01-C092-T08 · Delivery check:** Run the smallest real “DAG acceptance fixture” path and its adverse fixture “A test passes using a graph visualization without executing its steps”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.01-C092-T09 · Patch review:** Review the “DAG acceptance fixture” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.01-C092-T10 · Delivery handoff:** Publish the “DAG acceptance fixture” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The acceptance evidence shows actual invocations, not only planned paths. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “DAG acceptance fixture”; copy its required invariant exactly: “The acceptance evidence shows actual invocations, not only planned paths”.
- [ ] **UC-M05.01-C093-T02 · Observable terms:** Define each term in the “DAG acceptance fixture” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.01-C093-T03 · Precondition set:** List the preconditions under which “The acceptance evidence shows actual invocations, not only planned paths” must hold for “DAG acceptance fixture”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.01-C093-T04 · Transition coverage:** Map the “DAG acceptance fixture” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “DAG acceptance fixture”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.01-C093-T06 · Satisfying fixture:** Create a concrete “DAG acceptance fixture” case that satisfies “The acceptance evidence shows actual invocations, not only planned paths”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.01-C093-T07 · Violating fixture:** Create the source counterexample “A test passes using a graph visualization without executing its steps” for “DAG acceptance fixture”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.01-C093-T08 · Enforcement evidence:** Exercise the “DAG acceptance fixture” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.01-C093-T09 · Regression linkage:** Link the “DAG acceptance fixture” property to changes in typed workload graphs, artifact handoff and backend invocations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.01-C093-T10 · Property disposition:** Compare the satisfying and violating “DAG acceptance fixture” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.01-C094 · Integration

**Original checklist item:** Integrate DAG acceptance fixture with typed workload graphs, artifact handoff and backend invocations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “DAG acceptance fixture” across typed workload graphs, artifact handoff and backend invocations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.01-C094-T02 · Field mapping:** Map every “DAG acceptance fixture” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “DAG acceptance fixture” (source dependency list: UC-M01.07, UC-M01.08, UC-M03.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.01-C094-T04 · Ownership agreement:** Specify who owns “DAG acceptance fixture” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.01-C094-T05 · Handoff implementation:** Connect “DAG acceptance fixture” through the mapped seam using the real adapter or explicit specification reference; preserve “The acceptance evidence shows actual invocations, not only planned paths” across the handoff.
- [ ] **UC-M05.01-C094-T06 · Absent-input case:** Omit one required “DAG acceptance fixture” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.01-C094-T07 · Stale-input case:** Supply an outdated “DAG acceptance fixture” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.01-C094-T08 · Incompatible-input case:** Supply an incompatible “DAG acceptance fixture” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.01-C094-T09 · Valid integration trace:** Run a valid “DAG acceptance fixture” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.01-C094-T10 · Seam review:** Reconcile the “DAG acceptance fixture” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for DAG acceptance fixture; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “DAG acceptance fixture” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.01-C095-T02 · Expected-result oracle:** Specify the “DAG acceptance fixture” expected result independently of the implementation output; include the property “The acceptance evidence shows actual invocations, not only planned paths” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.01-C095-T03 · Fixture material:** Create the concrete “DAG acceptance fixture” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.01-C095-T04 · Target preparation:** Prepare the “DAG acceptance fixture” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.01-C095-T05 · Initial-state record:** Record the initial “DAG acceptance fixture” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.01-C095-T06 · Valid-path execution:** Execute the “DAG acceptance fixture” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.01-C095-T07 · Outcome comparison:** Compare every declared “DAG acceptance fixture” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.01-C095-T08 · State and bounds check:** Inspect the “DAG acceptance fixture” ownership/state effects and actual use of “Fixture nodes, runtime and artifact bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.01-C095-T09 · Repeatability check:** Repeat the same “DAG acceptance fixture” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.01-C095-T10 · Positive evidence:** Attach the “DAG acceptance fixture” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.01-C096 · Negative test

**Original checklist item:** Negative case: A test passes using a graph visualization without executing its steps. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “DAG acceptance fixture” source counterexample: “A test passes using a graph visualization without executing its steps”; state which precondition or invariant it challenges.
- [ ] **UC-M05.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “DAG acceptance fixture”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.01-C096-T03 · Valid control:** Construct a valid “DAG acceptance fixture” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.01-C096-T04 · Minimal adverse input:** Derive the “DAG acceptance fixture” adverse fixture from the control with the smallest documented change needed to reproduce “A test passes using a graph visualization without executing its steps”; retain that change as reproducible data.
- [ ] **UC-M05.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “DAG acceptance fixture”; require “The acceptance evidence shows actual invocations, not only planned paths” and forbid a false-success verdict.
- [ ] **UC-M05.01-C096-T06 · Adverse execution:** Exercise the “DAG acceptance fixture” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.01-C096-T07 · Effect inspection:** Inspect “DAG acceptance fixture” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.01-C096-T08 · Refusal versus failure:** Confirm the “DAG acceptance fixture” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.01-C096-T09 · Reset and retention:** Restore only the disposable “DAG acceptance fixture” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.01-C096-T10 · Negative regression:** Register the “DAG acceptance fixture” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.01-C097 · Change / failure test

**Original checklist item:** Exercise DAG acceptance fixture when a predecessor fails or its completion acknowledgment is redelivered; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.01-C097-T01 · Scenario record:** Write the “DAG acceptance fixture” change/failure scenario exactly as supplied: a predecessor fails or its completion acknowledgment is redelivered; identify the property that must remain true: “The acceptance evidence shows actual invocations, not only planned paths”.
- [ ] **UC-M05.01-C097-T02 · Baseline capture:** Create a known-valid “DAG acceptance fixture” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.01-C097-T03 · Injection map:** Locate the “DAG acceptance fixture” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “DAG acceptance fixture” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.01-C097-T05 · Controlled trigger:** Introduce the controlled “DAG acceptance fixture” scenario in the disposable fixture: a predecessor fails or its completion acknowledgment is redelivered; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.01-C097-T06 · Intermediate inspection:** Inspect the “DAG acceptance fixture” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “DAG acceptance fixture”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “DAG acceptance fixture” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.01-C097-T09 · Repeat and compare:** Repeat the selected “DAG acceptance fixture” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.01-C097-T10 · Failure evidence:** Publish the “DAG acceptance fixture” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fixture nodes, runtime and artifact bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “DAG acceptance fixture”: “Fixture nodes, runtime and artifact bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.01-C098-T02 · Measurement method:** Choose how to observe each “DAG acceptance fixture” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.01-C098-T03 · Budget decision:** Select justified resource and input limits for “DAG acceptance fixture”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “DAG acceptance fixture” cases for “Fixture nodes, runtime and artifact bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “DAG acceptance fixture” limit; preserve “The acceptance evidence shows actual invocations, not only planned paths”.
- [ ] **UC-M05.01-C098-T06 · Normal measurement:** Run or review the normal “DAG acceptance fixture” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.01-C098-T07 · At-limit measurement:** Exercise the “DAG acceptance fixture” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.01-C098-T08 · Over-limit measurement:** Exercise the “DAG acceptance fixture” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.01-C098-T09 · Uncovered-scope report:** List the “DAG acceptance fixture” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.01-C098-T10 · Limit evidence:** Publish the selected “DAG acceptance fixture” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for DAG acceptance fixture with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.01-C099-T01 · Event inventory:** List the “DAG acceptance fixture” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “DAG acceptance fixture” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.01-C099-T03 · Failure mapping:** Map each documented “DAG acceptance fixture” refusal or error to a diagnostic outcome; include “A test passes using a graph visualization without executing its steps” and prohibit conversion into a success message.
- [ ] **UC-M05.01-C099-T04 · Emission path:** Add the “DAG acceptance fixture” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.01-C099-T05 · Redaction check:** Test “DAG acceptance fixture” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.01-C099-T06 · Output budget:** Set and exercise bounded “DAG acceptance fixture” message size, rate and retention compatible with “Fixture nodes, runtime and artifact bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.01-C099-T07 · Success/refusal fixtures:** Capture “DAG acceptance fixture” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “DAG acceptance fixture” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.01-C099-T09 · Operator review:** Read the “DAG acceptance fixture” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.01-C099-T10 · Diagnostic evidence:** Publish redacted “DAG acceptance fixture” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for DAG acceptance fixture; label unexecuted checks as untested.

- [ ] **UC-M05.01-C100-T01 · Evidence inventory:** List the “DAG acceptance fixture” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.01-C100-T02 · Artifact references:** Record the exact “DAG acceptance fixture” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.01-C100-T03 · Fixture references:** Attach the “DAG acceptance fixture” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test passes using a graph visualization without executing its steps” as a distinct evidence case.
- [ ] **UC-M05.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “DAG acceptance fixture”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.01-C100-T05 · Environment record:** Record the actual “DAG acceptance fixture” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.01-C100-T06 · Expected versus observed:** Pair every “DAG acceptance fixture” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.01-C100-T07 · Failure and limit records:** Attach “DAG acceptance fixture” change/failure and bounds evidence where required; include uncovered “Fixture nodes, runtime and artifact bytes” and unresolved violations of “The acceptance evidence shows actual invocations, not only planned paths”.
- [ ] **UC-M05.01-C100-T08 · Evidence hygiene:** Check the “DAG acceptance fixture” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.01-C100-T09 · Reproduction review:** Have the “DAG acceptance fixture” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.01-C100-T10 · Acceptance linkage:** Link the “DAG acceptance fixture” evidence to its parent and UC-M05.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

