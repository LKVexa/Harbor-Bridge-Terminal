# UC-M05.04 — Idempotent reconciliation controller

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/05.md)

| Field | Preserved source value |
|---|---|
| Workstream | 05. Workload orchestration and scheduling |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M01.03](../01/UC-M01.03.md), [UC-M01.05](../01/UC-M01.05.md), [UC-M05.01](../05/UC-M05.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S6]. |

## Original requirement

Continuously reconcile desired state to observed instances through generation-scoped idempotent operations.

**Original acceptance criterion:** Restarting the controller or redelivering a command neither duplicates instances nor loses an admitted workload.

**Source trace:** Original checklist `UC100/c/05/UC-M05.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 462–472 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Desired-state persistence

**Source delivery:** Persist workload intent with identity, generation and requested lifecycle state.

**Source invariant:** Accepted intent survives controller restart.

**Source negative case:** A successful API response precedes loss of unpersisted desired state.

**Source bounded quantities:** Intent records and commit latency.

### UC-M05.04-C001 · Contract

**Original checklist item:** Specify desired-state persistence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C001-T01 · Scope statement:** Draft the operation boundary for “Desired-state persistence” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Desired-state persistence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C001-T03 · Output inventory:** List the outputs of “Desired-state persistence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Desired-state persistence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C001-T05 · Prerequisite contract:** Map “Desired-state persistence” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Desired-state persistence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C001-T07 · Invariant clause:** Add a normative clause for “Desired-state persistence” that preserves “Accepted intent survives controller restart”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Desired-state persistence”; include the source counterexample “A successful API response precedes loss of unpersisted desired state” and the intended safe disposition.
- [ ] **UC-M05.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Intent records and commit latency” in the “Desired-state persistence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C001-T10 · Contract review:** Review the “Desired-state persistence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C002 · Delivery

**Original checklist item:** Persist workload intent with identity, generation and requested lifecycle state.

- [ ] **UC-M05.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Desired-state persistence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C002-T02 · Change plan:** Break the source delivery for “Desired-state persistence” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Desired-state persistence” that realizes this source instruction: Persist workload intent with identity, generation and requested lifecycle state.
- [ ] **UC-M05.04-C002-T04 · Concrete realization:** Trace “Desired-state persistence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Desired-state persistence” needed to preserve “Accepted intent survives controller restart”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C002-T06 · Dependency connection:** Connect the “Desired-state persistence” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C002-T07 · Resource behavior:** Account for “Intent records and commit latency” in “Desired-state persistence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C002-T08 · Delivery check:** Run the smallest real “Desired-state persistence” path and its adverse fixture “A successful API response precedes loss of unpersisted desired state”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C002-T09 · Patch review:** Review the “Desired-state persistence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C002-T10 · Delivery handoff:** Publish the “Desired-state persistence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Accepted intent survives controller restart. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Desired-state persistence”; copy its required invariant exactly: “Accepted intent survives controller restart”.
- [ ] **UC-M05.04-C003-T02 · Observable terms:** Define each term in the “Desired-state persistence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C003-T03 · Precondition set:** List the preconditions under which “Accepted intent survives controller restart” must hold for “Desired-state persistence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C003-T04 · Transition coverage:** Map the “Desired-state persistence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Desired-state persistence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C003-T06 · Satisfying fixture:** Create a concrete “Desired-state persistence” case that satisfies “Accepted intent survives controller restart”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C003-T07 · Violating fixture:** Create the source counterexample “A successful API response precedes loss of unpersisted desired state” for “Desired-state persistence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C003-T08 · Enforcement evidence:** Exercise the “Desired-state persistence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C003-T09 · Regression linkage:** Link the “Desired-state persistence” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Desired-state persistence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C004 · Integration

**Original checklist item:** Integrate desired-state persistence with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Desired-state persistence” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C004-T02 · Field mapping:** Map every “Desired-state persistence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Desired-state persistence” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C004-T04 · Ownership agreement:** Specify who owns “Desired-state persistence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C004-T05 · Handoff implementation:** Connect “Desired-state persistence” through the mapped seam using the real adapter or explicit specification reference; preserve “Accepted intent survives controller restart” across the handoff.
- [ ] **UC-M05.04-C004-T06 · Absent-input case:** Omit one required “Desired-state persistence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C004-T07 · Stale-input case:** Supply an outdated “Desired-state persistence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Desired-state persistence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C004-T09 · Valid integration trace:** Run a valid “Desired-state persistence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C004-T10 · Seam review:** Reconcile the “Desired-state persistence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for desired-state persistence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Desired-state persistence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C005-T02 · Expected-result oracle:** Specify the “Desired-state persistence” expected result independently of the implementation output; include the property “Accepted intent survives controller restart” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C005-T03 · Fixture material:** Create the concrete “Desired-state persistence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C005-T04 · Target preparation:** Prepare the “Desired-state persistence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C005-T05 · Initial-state record:** Record the initial “Desired-state persistence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C005-T06 · Valid-path execution:** Execute the “Desired-state persistence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C005-T07 · Outcome comparison:** Compare every declared “Desired-state persistence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C005-T08 · State and bounds check:** Inspect the “Desired-state persistence” ownership/state effects and actual use of “Intent records and commit latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C005-T09 · Repeatability check:** Repeat the same “Desired-state persistence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C005-T10 · Positive evidence:** Attach the “Desired-state persistence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C006 · Negative test

**Original checklist item:** Negative case: A successful API response precedes loss of unpersisted desired state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Desired-state persistence” source counterexample: “A successful API response precedes loss of unpersisted desired state”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Desired-state persistence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C006-T03 · Valid control:** Construct a valid “Desired-state persistence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C006-T04 · Minimal adverse input:** Derive the “Desired-state persistence” adverse fixture from the control with the smallest documented change needed to reproduce “A successful API response precedes loss of unpersisted desired state”; retain that change as reproducible data.
- [ ] **UC-M05.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Desired-state persistence”; require “Accepted intent survives controller restart” and forbid a false-success verdict.
- [ ] **UC-M05.04-C006-T06 · Adverse execution:** Exercise the “Desired-state persistence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C006-T07 · Effect inspection:** Inspect “Desired-state persistence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C006-T08 · Refusal versus failure:** Confirm the “Desired-state persistence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C006-T09 · Reset and retention:** Restore only the disposable “Desired-state persistence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C006-T10 · Negative regression:** Register the “Desired-state persistence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C007 · Change / failure test

**Original checklist item:** Exercise desired-state persistence when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C007-T01 · Scenario record:** Write the “Desired-state persistence” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Accepted intent survives controller restart”.
- [ ] **UC-M05.04-C007-T02 · Baseline capture:** Create a known-valid “Desired-state persistence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C007-T03 · Injection map:** Locate the “Desired-state persistence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Desired-state persistence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C007-T05 · Controlled trigger:** Introduce the controlled “Desired-state persistence” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C007-T06 · Intermediate inspection:** Inspect the “Desired-state persistence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Desired-state persistence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Desired-state persistence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C007-T09 · Repeat and compare:** Repeat the selected “Desired-state persistence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C007-T10 · Failure evidence:** Publish the “Desired-state persistence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C008 · Bounds

**Original checklist item:** Choose, document and test limits for intent records and commit latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Desired-state persistence”: “Intent records and commit latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C008-T02 · Measurement method:** Choose how to observe each “Desired-state persistence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C008-T03 · Budget decision:** Select justified resource and input limits for “Desired-state persistence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Desired-state persistence” cases for “Intent records and commit latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Desired-state persistence” limit; preserve “Accepted intent survives controller restart”.
- [ ] **UC-M05.04-C008-T06 · Normal measurement:** Run or review the normal “Desired-state persistence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C008-T07 · At-limit measurement:** Exercise the “Desired-state persistence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C008-T08 · Over-limit measurement:** Exercise the “Desired-state persistence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C008-T09 · Uncovered-scope report:** List the “Desired-state persistence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C008-T10 · Limit evidence:** Publish the selected “Desired-state persistence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for desired-state persistence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C009-T01 · Event inventory:** List the “Desired-state persistence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Desired-state persistence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C009-T03 · Failure mapping:** Map each documented “Desired-state persistence” refusal or error to a diagnostic outcome; include “A successful API response precedes loss of unpersisted desired state” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C009-T04 · Emission path:** Add the “Desired-state persistence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C009-T05 · Redaction check:** Test “Desired-state persistence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C009-T06 · Output budget:** Set and exercise bounded “Desired-state persistence” message size, rate and retention compatible with “Intent records and commit latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C009-T07 · Success/refusal fixtures:** Capture “Desired-state persistence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Desired-state persistence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C009-T09 · Operator review:** Read the “Desired-state persistence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C009-T10 · Diagnostic evidence:** Publish redacted “Desired-state persistence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for desired-state persistence; label unexecuted checks as untested.

- [ ] **UC-M05.04-C010-T01 · Evidence inventory:** List the “Desired-state persistence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C010-T02 · Artifact references:** Record the exact “Desired-state persistence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C010-T03 · Fixture references:** Attach the “Desired-state persistence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A successful API response precedes loss of unpersisted desired state” as a distinct evidence case.
- [ ] **UC-M05.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Desired-state persistence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C010-T05 · Environment record:** Record the actual “Desired-state persistence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C010-T06 · Expected versus observed:** Pair every “Desired-state persistence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C010-T07 · Failure and limit records:** Attach “Desired-state persistence” change/failure and bounds evidence where required; include uncovered “Intent records and commit latency” and unresolved violations of “Accepted intent survives controller restart”.
- [ ] **UC-M05.04-C010-T08 · Evidence hygiene:** Check the “Desired-state persistence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C010-T09 · Reproduction review:** Have the “Desired-state persistence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C010-T10 · Acceptance linkage:** Link the “Desired-state persistence” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Observed-instance inventory

**Source delivery:** Inspect actual backend instances independently of desired state.

**Source invariant:** A missing guest cannot be inferred to exist from its registry entry.

**Source negative case:** A process is gone while its metadata still says running.

**Source bounded quantities:** Instance count and observation interval.

### UC-M05.04-C011 · Contract

**Original checklist item:** Specify observed-instance inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C011-T01 · Scope statement:** Draft the operation boundary for “Observed-instance inventory” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Observed-instance inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C011-T03 · Output inventory:** List the outputs of “Observed-instance inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Observed-instance inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C011-T05 · Prerequisite contract:** Map “Observed-instance inventory” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Observed-instance inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C011-T07 · Invariant clause:** Add a normative clause for “Observed-instance inventory” that preserves “A missing guest cannot be inferred to exist from its registry entry”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Observed-instance inventory”; include the source counterexample “A process is gone while its metadata still says running” and the intended safe disposition.
- [ ] **UC-M05.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Instance count and observation interval” in the “Observed-instance inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C011-T10 · Contract review:** Review the “Observed-instance inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C012 · Delivery

**Original checklist item:** Inspect actual backend instances independently of desired state.

- [ ] **UC-M05.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Observed-instance inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C012-T02 · Change plan:** Break the source delivery for “Observed-instance inventory” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Observed-instance inventory” that realizes this source instruction: Inspect actual backend instances independently of desired state.
- [ ] **UC-M05.04-C012-T04 · Concrete realization:** Trace “Observed-instance inventory” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Observed-instance inventory” needed to preserve “A missing guest cannot be inferred to exist from its registry entry”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C012-T06 · Dependency connection:** Connect the “Observed-instance inventory” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C012-T07 · Resource behavior:** Account for “Instance count and observation interval” in “Observed-instance inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C012-T08 · Delivery check:** Run the smallest real “Observed-instance inventory” path and its adverse fixture “A process is gone while its metadata still says running”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C012-T09 · Patch review:** Review the “Observed-instance inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C012-T10 · Delivery handoff:** Publish the “Observed-instance inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A missing guest cannot be inferred to exist from its registry entry. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Observed-instance inventory”; copy its required invariant exactly: “A missing guest cannot be inferred to exist from its registry entry”.
- [ ] **UC-M05.04-C013-T02 · Observable terms:** Define each term in the “Observed-instance inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C013-T03 · Precondition set:** List the preconditions under which “A missing guest cannot be inferred to exist from its registry entry” must hold for “Observed-instance inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C013-T04 · Transition coverage:** Map the “Observed-instance inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Observed-instance inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C013-T06 · Satisfying fixture:** Create a concrete “Observed-instance inventory” case that satisfies “A missing guest cannot be inferred to exist from its registry entry”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C013-T07 · Violating fixture:** Create the source counterexample “A process is gone while its metadata still says running” for “Observed-instance inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C013-T08 · Enforcement evidence:** Exercise the “Observed-instance inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C013-T09 · Regression linkage:** Link the “Observed-instance inventory” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Observed-instance inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C014 · Integration

**Original checklist item:** Integrate observed-instance inventory with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Observed-instance inventory” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C014-T02 · Field mapping:** Map every “Observed-instance inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Observed-instance inventory” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C014-T04 · Ownership agreement:** Specify who owns “Observed-instance inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C014-T05 · Handoff implementation:** Connect “Observed-instance inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “A missing guest cannot be inferred to exist from its registry entry” across the handoff.
- [ ] **UC-M05.04-C014-T06 · Absent-input case:** Omit one required “Observed-instance inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C014-T07 · Stale-input case:** Supply an outdated “Observed-instance inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Observed-instance inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C014-T09 · Valid integration trace:** Run a valid “Observed-instance inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C014-T10 · Seam review:** Reconcile the “Observed-instance inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for observed-instance inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Observed-instance inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C015-T02 · Expected-result oracle:** Specify the “Observed-instance inventory” expected result independently of the implementation output; include the property “A missing guest cannot be inferred to exist from its registry entry” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C015-T03 · Fixture material:** Create the concrete “Observed-instance inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C015-T04 · Target preparation:** Prepare the “Observed-instance inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C015-T05 · Initial-state record:** Record the initial “Observed-instance inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C015-T06 · Valid-path execution:** Execute the “Observed-instance inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C015-T07 · Outcome comparison:** Compare every declared “Observed-instance inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C015-T08 · State and bounds check:** Inspect the “Observed-instance inventory” ownership/state effects and actual use of “Instance count and observation interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C015-T09 · Repeatability check:** Repeat the same “Observed-instance inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C015-T10 · Positive evidence:** Attach the “Observed-instance inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C016 · Negative test

**Original checklist item:** Negative case: A process is gone while its metadata still says running. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Observed-instance inventory” source counterexample: “A process is gone while its metadata still says running”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Observed-instance inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C016-T03 · Valid control:** Construct a valid “Observed-instance inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C016-T04 · Minimal adverse input:** Derive the “Observed-instance inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A process is gone while its metadata still says running”; retain that change as reproducible data.
- [ ] **UC-M05.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Observed-instance inventory”; require “A missing guest cannot be inferred to exist from its registry entry” and forbid a false-success verdict.
- [ ] **UC-M05.04-C016-T06 · Adverse execution:** Exercise the “Observed-instance inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C016-T07 · Effect inspection:** Inspect “Observed-instance inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C016-T08 · Refusal versus failure:** Confirm the “Observed-instance inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C016-T09 · Reset and retention:** Restore only the disposable “Observed-instance inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C016-T10 · Negative regression:** Register the “Observed-instance inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C017 · Change / failure test

**Original checklist item:** Exercise observed-instance inventory when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C017-T01 · Scenario record:** Write the “Observed-instance inventory” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “A missing guest cannot be inferred to exist from its registry entry”.
- [ ] **UC-M05.04-C017-T02 · Baseline capture:** Create a known-valid “Observed-instance inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C017-T03 · Injection map:** Locate the “Observed-instance inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Observed-instance inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C017-T05 · Controlled trigger:** Introduce the controlled “Observed-instance inventory” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C017-T06 · Intermediate inspection:** Inspect the “Observed-instance inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Observed-instance inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Observed-instance inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C017-T09 · Repeat and compare:** Repeat the selected “Observed-instance inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C017-T10 · Failure evidence:** Publish the “Observed-instance inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C018 · Bounds

**Original checklist item:** Choose, document and test limits for instance count and observation interval; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Observed-instance inventory”: “Instance count and observation interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C018-T02 · Measurement method:** Choose how to observe each “Observed-instance inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C018-T03 · Budget decision:** Select justified resource and input limits for “Observed-instance inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Observed-instance inventory” cases for “Instance count and observation interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Observed-instance inventory” limit; preserve “A missing guest cannot be inferred to exist from its registry entry”.
- [ ] **UC-M05.04-C018-T06 · Normal measurement:** Run or review the normal “Observed-instance inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C018-T07 · At-limit measurement:** Exercise the “Observed-instance inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C018-T08 · Over-limit measurement:** Exercise the “Observed-instance inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C018-T09 · Uncovered-scope report:** List the “Observed-instance inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C018-T10 · Limit evidence:** Publish the selected “Observed-instance inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for observed-instance inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C019-T01 · Event inventory:** List the “Observed-instance inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Observed-instance inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C019-T03 · Failure mapping:** Map each documented “Observed-instance inventory” refusal or error to a diagnostic outcome; include “A process is gone while its metadata still says running” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C019-T04 · Emission path:** Add the “Observed-instance inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C019-T05 · Redaction check:** Test “Observed-instance inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C019-T06 · Output budget:** Set and exercise bounded “Observed-instance inventory” message size, rate and retention compatible with “Instance count and observation interval”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C019-T07 · Success/refusal fixtures:** Capture “Observed-instance inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Observed-instance inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C019-T09 · Operator review:** Read the “Observed-instance inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C019-T10 · Diagnostic evidence:** Publish redacted “Observed-instance inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for observed-instance inventory; label unexecuted checks as untested.

- [ ] **UC-M05.04-C020-T01 · Evidence inventory:** List the “Observed-instance inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C020-T02 · Artifact references:** Record the exact “Observed-instance inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C020-T03 · Fixture references:** Attach the “Observed-instance inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A process is gone while its metadata still says running” as a distinct evidence case.
- [ ] **UC-M05.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Observed-instance inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C020-T05 · Environment record:** Record the actual “Observed-instance inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C020-T06 · Expected versus observed:** Pair every “Observed-instance inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C020-T07 · Failure and limit records:** Attach “Observed-instance inventory” change/failure and bounds evidence where required; include uncovered “Instance count and observation interval” and unresolved violations of “A missing guest cannot be inferred to exist from its registry entry”.
- [ ] **UC-M05.04-C020-T08 · Evidence hygiene:** Check the “Observed-instance inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C020-T09 · Reproduction review:** Have the “Observed-instance inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C020-T10 · Acceptance linkage:** Link the “Observed-instance inventory” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Reconciliation comparison

**Source delivery:** Compute actions from desired and observed states using the legal lifecycle model.

**Source invariant:** Each proposed action has a valid state-transition reason.

**Source negative case:** A stale observation causes an illegal start after draining began.

**Source bounded quantities:** Comparison work and reconciliation batch size.

### UC-M05.04-C021 · Contract

**Original checklist item:** Specify reconciliation comparison inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C021-T01 · Scope statement:** Draft the operation boundary for “Reconciliation comparison” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reconciliation comparison”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C021-T03 · Output inventory:** List the outputs of “Reconciliation comparison” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Reconciliation comparison”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C021-T05 · Prerequisite contract:** Map “Reconciliation comparison” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Reconciliation comparison”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C021-T07 · Invariant clause:** Add a normative clause for “Reconciliation comparison” that preserves “Each proposed action has a valid state-transition reason”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reconciliation comparison”; include the source counterexample “A stale observation causes an illegal start after draining began” and the intended safe disposition.
- [ ] **UC-M05.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Comparison work and reconciliation batch size” in the “Reconciliation comparison” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C021-T10 · Contract review:** Review the “Reconciliation comparison” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C022 · Delivery

**Original checklist item:** Compute actions from desired and observed states using the legal lifecycle model.

- [ ] **UC-M05.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reconciliation comparison”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C022-T02 · Change plan:** Break the source delivery for “Reconciliation comparison” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Reconciliation comparison” that realizes this source instruction: Compute actions from desired and observed states using the legal lifecycle model.
- [ ] **UC-M05.04-C022-T04 · Concrete realization:** Trace “Reconciliation comparison” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reconciliation comparison” needed to preserve “Each proposed action has a valid state-transition reason”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C022-T06 · Dependency connection:** Connect the “Reconciliation comparison” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C022-T07 · Resource behavior:** Account for “Comparison work and reconciliation batch size” in “Reconciliation comparison”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C022-T08 · Delivery check:** Run the smallest real “Reconciliation comparison” path and its adverse fixture “A stale observation causes an illegal start after draining began”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C022-T09 · Patch review:** Review the “Reconciliation comparison” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C022-T10 · Delivery handoff:** Publish the “Reconciliation comparison” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each proposed action has a valid state-transition reason. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Reconciliation comparison”; copy its required invariant exactly: “Each proposed action has a valid state-transition reason”.
- [ ] **UC-M05.04-C023-T02 · Observable terms:** Define each term in the “Reconciliation comparison” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C023-T03 · Precondition set:** List the preconditions under which “Each proposed action has a valid state-transition reason” must hold for “Reconciliation comparison”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C023-T04 · Transition coverage:** Map the “Reconciliation comparison” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reconciliation comparison”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C023-T06 · Satisfying fixture:** Create a concrete “Reconciliation comparison” case that satisfies “Each proposed action has a valid state-transition reason”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C023-T07 · Violating fixture:** Create the source counterexample “A stale observation causes an illegal start after draining began” for “Reconciliation comparison”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C023-T08 · Enforcement evidence:** Exercise the “Reconciliation comparison” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C023-T09 · Regression linkage:** Link the “Reconciliation comparison” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Reconciliation comparison” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C024 · Integration

**Original checklist item:** Integrate reconciliation comparison with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reconciliation comparison” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C024-T02 · Field mapping:** Map every “Reconciliation comparison” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Reconciliation comparison” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C024-T04 · Ownership agreement:** Specify who owns “Reconciliation comparison” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C024-T05 · Handoff implementation:** Connect “Reconciliation comparison” through the mapped seam using the real adapter or explicit specification reference; preserve “Each proposed action has a valid state-transition reason” across the handoff.
- [ ] **UC-M05.04-C024-T06 · Absent-input case:** Omit one required “Reconciliation comparison” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C024-T07 · Stale-input case:** Supply an outdated “Reconciliation comparison” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Reconciliation comparison” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C024-T09 · Valid integration trace:** Run a valid “Reconciliation comparison” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C024-T10 · Seam review:** Reconcile the “Reconciliation comparison” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reconciliation comparison; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reconciliation comparison” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C025-T02 · Expected-result oracle:** Specify the “Reconciliation comparison” expected result independently of the implementation output; include the property “Each proposed action has a valid state-transition reason” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C025-T03 · Fixture material:** Create the concrete “Reconciliation comparison” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C025-T04 · Target preparation:** Prepare the “Reconciliation comparison” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C025-T05 · Initial-state record:** Record the initial “Reconciliation comparison” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C025-T06 · Valid-path execution:** Execute the “Reconciliation comparison” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C025-T07 · Outcome comparison:** Compare every declared “Reconciliation comparison” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C025-T08 · State and bounds check:** Inspect the “Reconciliation comparison” ownership/state effects and actual use of “Comparison work and reconciliation batch size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C025-T09 · Repeatability check:** Repeat the same “Reconciliation comparison” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C025-T10 · Positive evidence:** Attach the “Reconciliation comparison” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C026 · Negative test

**Original checklist item:** Negative case: A stale observation causes an illegal start after draining began. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Reconciliation comparison” source counterexample: “A stale observation causes an illegal start after draining began”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Reconciliation comparison”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C026-T03 · Valid control:** Construct a valid “Reconciliation comparison” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C026-T04 · Minimal adverse input:** Derive the “Reconciliation comparison” adverse fixture from the control with the smallest documented change needed to reproduce “A stale observation causes an illegal start after draining began”; retain that change as reproducible data.
- [ ] **UC-M05.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reconciliation comparison”; require “Each proposed action has a valid state-transition reason” and forbid a false-success verdict.
- [ ] **UC-M05.04-C026-T06 · Adverse execution:** Exercise the “Reconciliation comparison” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C026-T07 · Effect inspection:** Inspect “Reconciliation comparison” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C026-T08 · Refusal versus failure:** Confirm the “Reconciliation comparison” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C026-T09 · Reset and retention:** Restore only the disposable “Reconciliation comparison” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C026-T10 · Negative regression:** Register the “Reconciliation comparison” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C027 · Change / failure test

**Original checklist item:** Exercise reconciliation comparison when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C027-T01 · Scenario record:** Write the “Reconciliation comparison” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Each proposed action has a valid state-transition reason”.
- [ ] **UC-M05.04-C027-T02 · Baseline capture:** Create a known-valid “Reconciliation comparison” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C027-T03 · Injection map:** Locate the “Reconciliation comparison” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Reconciliation comparison” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C027-T05 · Controlled trigger:** Introduce the controlled “Reconciliation comparison” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C027-T06 · Intermediate inspection:** Inspect the “Reconciliation comparison” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reconciliation comparison”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Reconciliation comparison” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C027-T09 · Repeat and compare:** Repeat the selected “Reconciliation comparison” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C027-T10 · Failure evidence:** Publish the “Reconciliation comparison” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C028 · Bounds

**Original checklist item:** Choose, document and test limits for comparison work and reconciliation batch size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Reconciliation comparison”: “Comparison work and reconciliation batch size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C028-T02 · Measurement method:** Choose how to observe each “Reconciliation comparison” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C028-T03 · Budget decision:** Select justified resource and input limits for “Reconciliation comparison”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reconciliation comparison” cases for “Comparison work and reconciliation batch size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reconciliation comparison” limit; preserve “Each proposed action has a valid state-transition reason”.
- [ ] **UC-M05.04-C028-T06 · Normal measurement:** Run or review the normal “Reconciliation comparison” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C028-T07 · At-limit measurement:** Exercise the “Reconciliation comparison” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C028-T08 · Over-limit measurement:** Exercise the “Reconciliation comparison” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C028-T09 · Uncovered-scope report:** List the “Reconciliation comparison” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C028-T10 · Limit evidence:** Publish the selected “Reconciliation comparison” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reconciliation comparison with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C029-T01 · Event inventory:** List the “Reconciliation comparison” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Reconciliation comparison” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C029-T03 · Failure mapping:** Map each documented “Reconciliation comparison” refusal or error to a diagnostic outcome; include “A stale observation causes an illegal start after draining began” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C029-T04 · Emission path:** Add the “Reconciliation comparison” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C029-T05 · Redaction check:** Test “Reconciliation comparison” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C029-T06 · Output budget:** Set and exercise bounded “Reconciliation comparison” message size, rate and retention compatible with “Comparison work and reconciliation batch size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C029-T07 · Success/refusal fixtures:** Capture “Reconciliation comparison” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reconciliation comparison” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C029-T09 · Operator review:** Read the “Reconciliation comparison” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C029-T10 · Diagnostic evidence:** Publish redacted “Reconciliation comparison” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reconciliation comparison; label unexecuted checks as untested.

- [ ] **UC-M05.04-C030-T01 · Evidence inventory:** List the “Reconciliation comparison” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C030-T02 · Artifact references:** Record the exact “Reconciliation comparison” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C030-T03 · Fixture references:** Attach the “Reconciliation comparison” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale observation causes an illegal start after draining began” as a distinct evidence case.
- [ ] **UC-M05.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reconciliation comparison”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C030-T05 · Environment record:** Record the actual “Reconciliation comparison” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C030-T06 · Expected versus observed:** Pair every “Reconciliation comparison” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C030-T07 · Failure and limit records:** Attach “Reconciliation comparison” change/failure and bounds evidence where required; include uncovered “Comparison work and reconciliation batch size” and unresolved violations of “Each proposed action has a valid state-transition reason”.
- [ ] **UC-M05.04-C030-T08 · Evidence hygiene:** Check the “Reconciliation comparison” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C030-T09 · Reproduction review:** Have the “Reconciliation comparison” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C030-T10 · Acceptance linkage:** Link the “Reconciliation comparison” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Idempotency keys

**Source delivery:** Bind create, stop and other actions to durable generation-scoped identifiers.

**Source invariant:** Redelivering an action does not duplicate its committed effect.

**Source negative case:** The same create command is delivered twice after a timeout.

**Source bounded quantities:** Idempotency records and retention duration.

### UC-M05.04-C031 · Contract

**Original checklist item:** Specify idempotency keys inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C031-T01 · Scope statement:** Draft the operation boundary for “Idempotency keys” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Idempotency keys”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C031-T03 · Output inventory:** List the outputs of “Idempotency keys” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Idempotency keys”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C031-T05 · Prerequisite contract:** Map “Idempotency keys” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Idempotency keys”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C031-T07 · Invariant clause:** Add a normative clause for “Idempotency keys” that preserves “Redelivering an action does not duplicate its committed effect”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Idempotency keys”; include the source counterexample “The same create command is delivered twice after a timeout” and the intended safe disposition.
- [ ] **UC-M05.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Idempotency records and retention duration” in the “Idempotency keys” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C031-T10 · Contract review:** Review the “Idempotency keys” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C032 · Delivery

**Original checklist item:** Bind create, stop and other actions to durable generation-scoped identifiers.

- [ ] **UC-M05.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Idempotency keys”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C032-T02 · Change plan:** Break the source delivery for “Idempotency keys” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Idempotency keys” that realizes this source instruction: Bind create, stop and other actions to durable generation-scoped identifiers.
- [ ] **UC-M05.04-C032-T04 · Concrete realization:** Trace “Idempotency keys” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Idempotency keys” needed to preserve “Redelivering an action does not duplicate its committed effect”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C032-T06 · Dependency connection:** Connect the “Idempotency keys” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C032-T07 · Resource behavior:** Account for “Idempotency records and retention duration” in “Idempotency keys”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C032-T08 · Delivery check:** Run the smallest real “Idempotency keys” path and its adverse fixture “The same create command is delivered twice after a timeout”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C032-T09 · Patch review:** Review the “Idempotency keys” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C032-T10 · Delivery handoff:** Publish the “Idempotency keys” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Redelivering an action does not duplicate its committed effect. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Idempotency keys”; copy its required invariant exactly: “Redelivering an action does not duplicate its committed effect”.
- [ ] **UC-M05.04-C033-T02 · Observable terms:** Define each term in the “Idempotency keys” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C033-T03 · Precondition set:** List the preconditions under which “Redelivering an action does not duplicate its committed effect” must hold for “Idempotency keys”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C033-T04 · Transition coverage:** Map the “Idempotency keys” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Idempotency keys”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C033-T06 · Satisfying fixture:** Create a concrete “Idempotency keys” case that satisfies “Redelivering an action does not duplicate its committed effect”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C033-T07 · Violating fixture:** Create the source counterexample “The same create command is delivered twice after a timeout” for “Idempotency keys”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C033-T08 · Enforcement evidence:** Exercise the “Idempotency keys” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C033-T09 · Regression linkage:** Link the “Idempotency keys” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Idempotency keys” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C034 · Integration

**Original checklist item:** Integrate idempotency keys with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Idempotency keys” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C034-T02 · Field mapping:** Map every “Idempotency keys” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Idempotency keys” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C034-T04 · Ownership agreement:** Specify who owns “Idempotency keys” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C034-T05 · Handoff implementation:** Connect “Idempotency keys” through the mapped seam using the real adapter or explicit specification reference; preserve “Redelivering an action does not duplicate its committed effect” across the handoff.
- [ ] **UC-M05.04-C034-T06 · Absent-input case:** Omit one required “Idempotency keys” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C034-T07 · Stale-input case:** Supply an outdated “Idempotency keys” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Idempotency keys” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C034-T09 · Valid integration trace:** Run a valid “Idempotency keys” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C034-T10 · Seam review:** Reconcile the “Idempotency keys” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for idempotency keys; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Idempotency keys” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C035-T02 · Expected-result oracle:** Specify the “Idempotency keys” expected result independently of the implementation output; include the property “Redelivering an action does not duplicate its committed effect” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C035-T03 · Fixture material:** Create the concrete “Idempotency keys” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C035-T04 · Target preparation:** Prepare the “Idempotency keys” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C035-T05 · Initial-state record:** Record the initial “Idempotency keys” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C035-T06 · Valid-path execution:** Execute the “Idempotency keys” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C035-T07 · Outcome comparison:** Compare every declared “Idempotency keys” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C035-T08 · State and bounds check:** Inspect the “Idempotency keys” ownership/state effects and actual use of “Idempotency records and retention duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C035-T09 · Repeatability check:** Repeat the same “Idempotency keys” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C035-T10 · Positive evidence:** Attach the “Idempotency keys” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C036 · Negative test

**Original checklist item:** Negative case: The same create command is delivered twice after a timeout. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Idempotency keys” source counterexample: “The same create command is delivered twice after a timeout”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Idempotency keys”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C036-T03 · Valid control:** Construct a valid “Idempotency keys” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C036-T04 · Minimal adverse input:** Derive the “Idempotency keys” adverse fixture from the control with the smallest documented change needed to reproduce “The same create command is delivered twice after a timeout”; retain that change as reproducible data.
- [ ] **UC-M05.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Idempotency keys”; require “Redelivering an action does not duplicate its committed effect” and forbid a false-success verdict.
- [ ] **UC-M05.04-C036-T06 · Adverse execution:** Exercise the “Idempotency keys” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C036-T07 · Effect inspection:** Inspect “Idempotency keys” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C036-T08 · Refusal versus failure:** Confirm the “Idempotency keys” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C036-T09 · Reset and retention:** Restore only the disposable “Idempotency keys” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C036-T10 · Negative regression:** Register the “Idempotency keys” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C037 · Change / failure test

**Original checklist item:** Exercise idempotency keys when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C037-T01 · Scenario record:** Write the “Idempotency keys” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Redelivering an action does not duplicate its committed effect”.
- [ ] **UC-M05.04-C037-T02 · Baseline capture:** Create a known-valid “Idempotency keys” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C037-T03 · Injection map:** Locate the “Idempotency keys” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Idempotency keys” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C037-T05 · Controlled trigger:** Introduce the controlled “Idempotency keys” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C037-T06 · Intermediate inspection:** Inspect the “Idempotency keys” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Idempotency keys”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Idempotency keys” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C037-T09 · Repeat and compare:** Repeat the selected “Idempotency keys” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C037-T10 · Failure evidence:** Publish the “Idempotency keys” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C038 · Bounds

**Original checklist item:** Choose, document and test limits for idempotency records and retention duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Idempotency keys”: “Idempotency records and retention duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C038-T02 · Measurement method:** Choose how to observe each “Idempotency keys” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C038-T03 · Budget decision:** Select justified resource and input limits for “Idempotency keys”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Idempotency keys” cases for “Idempotency records and retention duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Idempotency keys” limit; preserve “Redelivering an action does not duplicate its committed effect”.
- [ ] **UC-M05.04-C038-T06 · Normal measurement:** Run or review the normal “Idempotency keys” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C038-T07 · At-limit measurement:** Exercise the “Idempotency keys” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C038-T08 · Over-limit measurement:** Exercise the “Idempotency keys” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C038-T09 · Uncovered-scope report:** List the “Idempotency keys” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C038-T10 · Limit evidence:** Publish the selected “Idempotency keys” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for idempotency keys with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C039-T01 · Event inventory:** List the “Idempotency keys” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Idempotency keys” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C039-T03 · Failure mapping:** Map each documented “Idempotency keys” refusal or error to a diagnostic outcome; include “The same create command is delivered twice after a timeout” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C039-T04 · Emission path:** Add the “Idempotency keys” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C039-T05 · Redaction check:** Test “Idempotency keys” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C039-T06 · Output budget:** Set and exercise bounded “Idempotency keys” message size, rate and retention compatible with “Idempotency records and retention duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C039-T07 · Success/refusal fixtures:** Capture “Idempotency keys” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Idempotency keys” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C039-T09 · Operator review:** Read the “Idempotency keys” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C039-T10 · Diagnostic evidence:** Publish redacted “Idempotency keys” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for idempotency keys; label unexecuted checks as untested.

- [ ] **UC-M05.04-C040-T01 · Evidence inventory:** List the “Idempotency keys” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C040-T02 · Artifact references:** Record the exact “Idempotency keys” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C040-T03 · Fixture references:** Attach the “Idempotency keys” fixture IDs, input identities and oracle definition; preserve the source counterexample “The same create command is delivered twice after a timeout” as a distinct evidence case.
- [ ] **UC-M05.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Idempotency keys”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C040-T05 · Environment record:** Record the actual “Idempotency keys” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C040-T06 · Expected versus observed:** Pair every “Idempotency keys” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C040-T07 · Failure and limit records:** Attach “Idempotency keys” change/failure and bounds evidence where required; include uncovered “Idempotency records and retention duration” and unresolved violations of “Redelivering an action does not duplicate its committed effect”.
- [ ] **UC-M05.04-C040-T08 · Evidence hygiene:** Check the “Idempotency keys” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C040-T09 · Reproduction review:** Have the “Idempotency keys” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C040-T10 · Acceptance linkage:** Link the “Idempotency keys” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Generation checks

**Source delivery:** Reject reconciliation actions targeting obsolete workload generations.

**Source invariant:** Old controller work cannot mutate a replacement generation.

**Source negative case:** A delayed stop for an old generation reaches the new instance.

**Source bounded quantities:** Pending actions and stale-action age.

### UC-M05.04-C041 · Contract

**Original checklist item:** Specify generation checks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C041-T01 · Scope statement:** Draft the operation boundary for “Generation checks” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Generation checks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C041-T03 · Output inventory:** List the outputs of “Generation checks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Generation checks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C041-T05 · Prerequisite contract:** Map “Generation checks” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Generation checks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C041-T07 · Invariant clause:** Add a normative clause for “Generation checks” that preserves “Old controller work cannot mutate a replacement generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Generation checks”; include the source counterexample “A delayed stop for an old generation reaches the new instance” and the intended safe disposition.
- [ ] **UC-M05.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pending actions and stale-action age” in the “Generation checks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C041-T10 · Contract review:** Review the “Generation checks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C042 · Delivery

**Original checklist item:** Reject reconciliation actions targeting obsolete workload generations.

- [ ] **UC-M05.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Generation checks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C042-T02 · Change plan:** Break the source delivery for “Generation checks” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Generation checks” that realizes this source instruction: Reject reconciliation actions targeting obsolete workload generations.
- [ ] **UC-M05.04-C042-T04 · Concrete realization:** Trace “Generation checks” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Generation checks” needed to preserve “Old controller work cannot mutate a replacement generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C042-T06 · Dependency connection:** Connect the “Generation checks” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C042-T07 · Resource behavior:** Account for “Pending actions and stale-action age” in “Generation checks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C042-T08 · Delivery check:** Run the smallest real “Generation checks” path and its adverse fixture “A delayed stop for an old generation reaches the new instance”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C042-T09 · Patch review:** Review the “Generation checks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C042-T10 · Delivery handoff:** Publish the “Generation checks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Old controller work cannot mutate a replacement generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Generation checks”; copy its required invariant exactly: “Old controller work cannot mutate a replacement generation”.
- [ ] **UC-M05.04-C043-T02 · Observable terms:** Define each term in the “Generation checks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C043-T03 · Precondition set:** List the preconditions under which “Old controller work cannot mutate a replacement generation” must hold for “Generation checks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C043-T04 · Transition coverage:** Map the “Generation checks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Generation checks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C043-T06 · Satisfying fixture:** Create a concrete “Generation checks” case that satisfies “Old controller work cannot mutate a replacement generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C043-T07 · Violating fixture:** Create the source counterexample “A delayed stop for an old generation reaches the new instance” for “Generation checks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C043-T08 · Enforcement evidence:** Exercise the “Generation checks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C043-T09 · Regression linkage:** Link the “Generation checks” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Generation checks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C044 · Integration

**Original checklist item:** Integrate generation checks with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Generation checks” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C044-T02 · Field mapping:** Map every “Generation checks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Generation checks” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C044-T04 · Ownership agreement:** Specify who owns “Generation checks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C044-T05 · Handoff implementation:** Connect “Generation checks” through the mapped seam using the real adapter or explicit specification reference; preserve “Old controller work cannot mutate a replacement generation” across the handoff.
- [ ] **UC-M05.04-C044-T06 · Absent-input case:** Omit one required “Generation checks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C044-T07 · Stale-input case:** Supply an outdated “Generation checks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Generation checks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C044-T09 · Valid integration trace:** Run a valid “Generation checks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C044-T10 · Seam review:** Reconcile the “Generation checks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for generation checks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Generation checks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C045-T02 · Expected-result oracle:** Specify the “Generation checks” expected result independently of the implementation output; include the property “Old controller work cannot mutate a replacement generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C045-T03 · Fixture material:** Create the concrete “Generation checks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C045-T04 · Target preparation:** Prepare the “Generation checks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C045-T05 · Initial-state record:** Record the initial “Generation checks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C045-T06 · Valid-path execution:** Execute the “Generation checks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C045-T07 · Outcome comparison:** Compare every declared “Generation checks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C045-T08 · State and bounds check:** Inspect the “Generation checks” ownership/state effects and actual use of “Pending actions and stale-action age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C045-T09 · Repeatability check:** Repeat the same “Generation checks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C045-T10 · Positive evidence:** Attach the “Generation checks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C046 · Negative test

**Original checklist item:** Negative case: A delayed stop for an old generation reaches the new instance. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Generation checks” source counterexample: “A delayed stop for an old generation reaches the new instance”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Generation checks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C046-T03 · Valid control:** Construct a valid “Generation checks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C046-T04 · Minimal adverse input:** Derive the “Generation checks” adverse fixture from the control with the smallest documented change needed to reproduce “A delayed stop for an old generation reaches the new instance”; retain that change as reproducible data.
- [ ] **UC-M05.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Generation checks”; require “Old controller work cannot mutate a replacement generation” and forbid a false-success verdict.
- [ ] **UC-M05.04-C046-T06 · Adverse execution:** Exercise the “Generation checks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C046-T07 · Effect inspection:** Inspect “Generation checks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C046-T08 · Refusal versus failure:** Confirm the “Generation checks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C046-T09 · Reset and retention:** Restore only the disposable “Generation checks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C046-T10 · Negative regression:** Register the “Generation checks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C047 · Change / failure test

**Original checklist item:** Exercise generation checks when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C047-T01 · Scenario record:** Write the “Generation checks” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Old controller work cannot mutate a replacement generation”.
- [ ] **UC-M05.04-C047-T02 · Baseline capture:** Create a known-valid “Generation checks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C047-T03 · Injection map:** Locate the “Generation checks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Generation checks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C047-T05 · Controlled trigger:** Introduce the controlled “Generation checks” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C047-T06 · Intermediate inspection:** Inspect the “Generation checks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Generation checks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Generation checks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C047-T09 · Repeat and compare:** Repeat the selected “Generation checks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C047-T10 · Failure evidence:** Publish the “Generation checks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C048 · Bounds

**Original checklist item:** Choose, document and test limits for pending actions and stale-action age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Generation checks”: “Pending actions and stale-action age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C048-T02 · Measurement method:** Choose how to observe each “Generation checks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C048-T03 · Budget decision:** Select justified resource and input limits for “Generation checks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Generation checks” cases for “Pending actions and stale-action age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Generation checks” limit; preserve “Old controller work cannot mutate a replacement generation”.
- [ ] **UC-M05.04-C048-T06 · Normal measurement:** Run or review the normal “Generation checks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C048-T07 · At-limit measurement:** Exercise the “Generation checks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C048-T08 · Over-limit measurement:** Exercise the “Generation checks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C048-T09 · Uncovered-scope report:** List the “Generation checks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C048-T10 · Limit evidence:** Publish the selected “Generation checks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for generation checks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C049-T01 · Event inventory:** List the “Generation checks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Generation checks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C049-T03 · Failure mapping:** Map each documented “Generation checks” refusal or error to a diagnostic outcome; include “A delayed stop for an old generation reaches the new instance” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C049-T04 · Emission path:** Add the “Generation checks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C049-T05 · Redaction check:** Test “Generation checks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C049-T06 · Output budget:** Set and exercise bounded “Generation checks” message size, rate and retention compatible with “Pending actions and stale-action age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C049-T07 · Success/refusal fixtures:** Capture “Generation checks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Generation checks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C049-T09 · Operator review:** Read the “Generation checks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C049-T10 · Diagnostic evidence:** Publish redacted “Generation checks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for generation checks; label unexecuted checks as untested.

- [ ] **UC-M05.04-C050-T01 · Evidence inventory:** List the “Generation checks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C050-T02 · Artifact references:** Record the exact “Generation checks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C050-T03 · Fixture references:** Attach the “Generation checks” fixture IDs, input identities and oracle definition; preserve the source counterexample “A delayed stop for an old generation reaches the new instance” as a distinct evidence case.
- [ ] **UC-M05.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Generation checks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C050-T05 · Environment record:** Record the actual “Generation checks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C050-T06 · Expected versus observed:** Pair every “Generation checks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C050-T07 · Failure and limit records:** Attach “Generation checks” change/failure and bounds evidence where required; include uncovered “Pending actions and stale-action age” and unresolved violations of “Old controller work cannot mutate a replacement generation”.
- [ ] **UC-M05.04-C050-T08 · Evidence hygiene:** Check the “Generation checks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C050-T09 · Reproduction review:** Have the “Generation checks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C050-T10 · Acceptance linkage:** Link the “Generation checks” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Crash recovery

**Source delivery:** Resume incomplete actions from durable state and backend inspection.

**Source invariant:** Restart neither loses admitted work nor creates duplicate guests.

**Source negative case:** The controller crashes after backend creation but before recording success.

**Source bounded quantities:** Recovery scan size and convergence deadline.

### UC-M05.04-C051 · Contract

**Original checklist item:** Specify crash recovery inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C051-T01 · Scope statement:** Draft the operation boundary for “Crash recovery” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Crash recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C051-T03 · Output inventory:** List the outputs of “Crash recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Crash recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C051-T05 · Prerequisite contract:** Map “Crash recovery” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Crash recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C051-T07 · Invariant clause:** Add a normative clause for “Crash recovery” that preserves “Restart neither loses admitted work nor creates duplicate guests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Crash recovery”; include the source counterexample “The controller crashes after backend creation but before recording success” and the intended safe disposition.
- [ ] **UC-M05.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recovery scan size and convergence deadline” in the “Crash recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C051-T10 · Contract review:** Review the “Crash recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C052 · Delivery

**Original checklist item:** Resume incomplete actions from durable state and backend inspection.

- [ ] **UC-M05.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Crash recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C052-T02 · Change plan:** Break the source delivery for “Crash recovery” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Crash recovery” that realizes this source instruction: Resume incomplete actions from durable state and backend inspection.
- [ ] **UC-M05.04-C052-T04 · Concrete realization:** Trace “Crash recovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Crash recovery” needed to preserve “Restart neither loses admitted work nor creates duplicate guests”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C052-T06 · Dependency connection:** Connect the “Crash recovery” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C052-T07 · Resource behavior:** Account for “Recovery scan size and convergence deadline” in “Crash recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C052-T08 · Delivery check:** Run the smallest real “Crash recovery” path and its adverse fixture “The controller crashes after backend creation but before recording success”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C052-T09 · Patch review:** Review the “Crash recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C052-T10 · Delivery handoff:** Publish the “Crash recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restart neither loses admitted work nor creates duplicate guests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Crash recovery”; copy its required invariant exactly: “Restart neither loses admitted work nor creates duplicate guests”.
- [ ] **UC-M05.04-C053-T02 · Observable terms:** Define each term in the “Crash recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C053-T03 · Precondition set:** List the preconditions under which “Restart neither loses admitted work nor creates duplicate guests” must hold for “Crash recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C053-T04 · Transition coverage:** Map the “Crash recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Crash recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C053-T06 · Satisfying fixture:** Create a concrete “Crash recovery” case that satisfies “Restart neither loses admitted work nor creates duplicate guests”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C053-T07 · Violating fixture:** Create the source counterexample “The controller crashes after backend creation but before recording success” for “Crash recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C053-T08 · Enforcement evidence:** Exercise the “Crash recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C053-T09 · Regression linkage:** Link the “Crash recovery” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Crash recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C054 · Integration

**Original checklist item:** Integrate crash recovery with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Crash recovery” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C054-T02 · Field mapping:** Map every “Crash recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Crash recovery” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C054-T04 · Ownership agreement:** Specify who owns “Crash recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C054-T05 · Handoff implementation:** Connect “Crash recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Restart neither loses admitted work nor creates duplicate guests” across the handoff.
- [ ] **UC-M05.04-C054-T06 · Absent-input case:** Omit one required “Crash recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C054-T07 · Stale-input case:** Supply an outdated “Crash recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Crash recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C054-T09 · Valid integration trace:** Run a valid “Crash recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C054-T10 · Seam review:** Reconcile the “Crash recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for crash recovery; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Crash recovery” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C055-T02 · Expected-result oracle:** Specify the “Crash recovery” expected result independently of the implementation output; include the property “Restart neither loses admitted work nor creates duplicate guests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C055-T03 · Fixture material:** Create the concrete “Crash recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C055-T04 · Target preparation:** Prepare the “Crash recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C055-T05 · Initial-state record:** Record the initial “Crash recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C055-T06 · Valid-path execution:** Execute the “Crash recovery” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C055-T07 · Outcome comparison:** Compare every declared “Crash recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C055-T08 · State and bounds check:** Inspect the “Crash recovery” ownership/state effects and actual use of “Recovery scan size and convergence deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C055-T09 · Repeatability check:** Repeat the same “Crash recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C055-T10 · Positive evidence:** Attach the “Crash recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C056 · Negative test

**Original checklist item:** Negative case: The controller crashes after backend creation but before recording success. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Crash recovery” source counterexample: “The controller crashes after backend creation but before recording success”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Crash recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C056-T03 · Valid control:** Construct a valid “Crash recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C056-T04 · Minimal adverse input:** Derive the “Crash recovery” adverse fixture from the control with the smallest documented change needed to reproduce “The controller crashes after backend creation but before recording success”; retain that change as reproducible data.
- [ ] **UC-M05.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Crash recovery”; require “Restart neither loses admitted work nor creates duplicate guests” and forbid a false-success verdict.
- [ ] **UC-M05.04-C056-T06 · Adverse execution:** Exercise the “Crash recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C056-T07 · Effect inspection:** Inspect “Crash recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C056-T08 · Refusal versus failure:** Confirm the “Crash recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C056-T09 · Reset and retention:** Restore only the disposable “Crash recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C056-T10 · Negative regression:** Register the “Crash recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C057 · Change / failure test

**Original checklist item:** Exercise crash recovery when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C057-T01 · Scenario record:** Write the “Crash recovery” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Restart neither loses admitted work nor creates duplicate guests”.
- [ ] **UC-M05.04-C057-T02 · Baseline capture:** Create a known-valid “Crash recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C057-T03 · Injection map:** Locate the “Crash recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Crash recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C057-T05 · Controlled trigger:** Introduce the controlled “Crash recovery” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C057-T06 · Intermediate inspection:** Inspect the “Crash recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Crash recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Crash recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C057-T09 · Repeat and compare:** Repeat the selected “Crash recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C057-T10 · Failure evidence:** Publish the “Crash recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C058 · Bounds

**Original checklist item:** Choose, document and test limits for recovery scan size and convergence deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Crash recovery”: “Recovery scan size and convergence deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C058-T02 · Measurement method:** Choose how to observe each “Crash recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C058-T03 · Budget decision:** Select justified resource and input limits for “Crash recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Crash recovery” cases for “Recovery scan size and convergence deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Crash recovery” limit; preserve “Restart neither loses admitted work nor creates duplicate guests”.
- [ ] **UC-M05.04-C058-T06 · Normal measurement:** Run or review the normal “Crash recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C058-T07 · At-limit measurement:** Exercise the “Crash recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C058-T08 · Over-limit measurement:** Exercise the “Crash recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C058-T09 · Uncovered-scope report:** List the “Crash recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C058-T10 · Limit evidence:** Publish the selected “Crash recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for crash recovery with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C059-T01 · Event inventory:** List the “Crash recovery” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Crash recovery” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C059-T03 · Failure mapping:** Map each documented “Crash recovery” refusal or error to a diagnostic outcome; include “The controller crashes after backend creation but before recording success” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C059-T04 · Emission path:** Add the “Crash recovery” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C059-T05 · Redaction check:** Test “Crash recovery” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C059-T06 · Output budget:** Set and exercise bounded “Crash recovery” message size, rate and retention compatible with “Recovery scan size and convergence deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C059-T07 · Success/refusal fixtures:** Capture “Crash recovery” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Crash recovery” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C059-T09 · Operator review:** Read the “Crash recovery” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C059-T10 · Diagnostic evidence:** Publish redacted “Crash recovery” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for crash recovery; label unexecuted checks as untested.

- [ ] **UC-M05.04-C060-T01 · Evidence inventory:** List the “Crash recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C060-T02 · Artifact references:** Record the exact “Crash recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C060-T03 · Fixture references:** Attach the “Crash recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “The controller crashes after backend creation but before recording success” as a distinct evidence case.
- [ ] **UC-M05.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Crash recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C060-T05 · Environment record:** Record the actual “Crash recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C060-T06 · Expected versus observed:** Pair every “Crash recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C060-T07 · Failure and limit records:** Attach “Crash recovery” change/failure and bounds evidence where required; include uncovered “Recovery scan size and convergence deadline” and unresolved violations of “Restart neither loses admitted work nor creates duplicate guests”.
- [ ] **UC-M05.04-C060-T08 · Evidence hygiene:** Check the “Crash recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C060-T09 · Reproduction review:** Have the “Crash recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C060-T10 · Acceptance linkage:** Link the “Crash recovery” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Action retry policy

**Source delivery:** Retry only actions whose outcome and idempotency contract permit it.

**Source invariant:** An uncertain result is reconciled rather than blindly repeated.

**Source negative case:** A timed-out create is retried without checking whether the guest exists.

**Source bounded quantities:** Retry count and backoff ceiling.

### UC-M05.04-C061 · Contract

**Original checklist item:** Specify action retry policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C061-T01 · Scope statement:** Draft the operation boundary for “Action retry policy” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Action retry policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C061-T03 · Output inventory:** List the outputs of “Action retry policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Action retry policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C061-T05 · Prerequisite contract:** Map “Action retry policy” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Action retry policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C061-T07 · Invariant clause:** Add a normative clause for “Action retry policy” that preserves “An uncertain result is reconciled rather than blindly repeated”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Action retry policy”; include the source counterexample “A timed-out create is retried without checking whether the guest exists” and the intended safe disposition.
- [ ] **UC-M05.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retry count and backoff ceiling” in the “Action retry policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C061-T10 · Contract review:** Review the “Action retry policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C062 · Delivery

**Original checklist item:** Retry only actions whose outcome and idempotency contract permit it.

- [ ] **UC-M05.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Action retry policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C062-T02 · Change plan:** Break the source delivery for “Action retry policy” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Action retry policy” that realizes this source instruction: Retry only actions whose outcome and idempotency contract permit it.
- [ ] **UC-M05.04-C062-T04 · Concrete realization:** Trace “Action retry policy” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Action retry policy” needed to preserve “An uncertain result is reconciled rather than blindly repeated”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C062-T06 · Dependency connection:** Connect the “Action retry policy” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C062-T07 · Resource behavior:** Account for “Retry count and backoff ceiling” in “Action retry policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C062-T08 · Delivery check:** Run the smallest real “Action retry policy” path and its adverse fixture “A timed-out create is retried without checking whether the guest exists”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C062-T09 · Patch review:** Review the “Action retry policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C062-T10 · Delivery handoff:** Publish the “Action retry policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An uncertain result is reconciled rather than blindly repeated. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Action retry policy”; copy its required invariant exactly: “An uncertain result is reconciled rather than blindly repeated”.
- [ ] **UC-M05.04-C063-T02 · Observable terms:** Define each term in the “Action retry policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C063-T03 · Precondition set:** List the preconditions under which “An uncertain result is reconciled rather than blindly repeated” must hold for “Action retry policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C063-T04 · Transition coverage:** Map the “Action retry policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Action retry policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C063-T06 · Satisfying fixture:** Create a concrete “Action retry policy” case that satisfies “An uncertain result is reconciled rather than blindly repeated”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C063-T07 · Violating fixture:** Create the source counterexample “A timed-out create is retried without checking whether the guest exists” for “Action retry policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C063-T08 · Enforcement evidence:** Exercise the “Action retry policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C063-T09 · Regression linkage:** Link the “Action retry policy” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Action retry policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C064 · Integration

**Original checklist item:** Integrate action retry policy with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Action retry policy” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C064-T02 · Field mapping:** Map every “Action retry policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Action retry policy” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C064-T04 · Ownership agreement:** Specify who owns “Action retry policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C064-T05 · Handoff implementation:** Connect “Action retry policy” through the mapped seam using the real adapter or explicit specification reference; preserve “An uncertain result is reconciled rather than blindly repeated” across the handoff.
- [ ] **UC-M05.04-C064-T06 · Absent-input case:** Omit one required “Action retry policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C064-T07 · Stale-input case:** Supply an outdated “Action retry policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Action retry policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C064-T09 · Valid integration trace:** Run a valid “Action retry policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C064-T10 · Seam review:** Reconcile the “Action retry policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for action retry policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Action retry policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C065-T02 · Expected-result oracle:** Specify the “Action retry policy” expected result independently of the implementation output; include the property “An uncertain result is reconciled rather than blindly repeated” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C065-T03 · Fixture material:** Create the concrete “Action retry policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C065-T04 · Target preparation:** Prepare the “Action retry policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C065-T05 · Initial-state record:** Record the initial “Action retry policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C065-T06 · Valid-path execution:** Execute the “Action retry policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C065-T07 · Outcome comparison:** Compare every declared “Action retry policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C065-T08 · State and bounds check:** Inspect the “Action retry policy” ownership/state effects and actual use of “Retry count and backoff ceiling”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C065-T09 · Repeatability check:** Repeat the same “Action retry policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C065-T10 · Positive evidence:** Attach the “Action retry policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C066 · Negative test

**Original checklist item:** Negative case: A timed-out create is retried without checking whether the guest exists. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Action retry policy” source counterexample: “A timed-out create is retried without checking whether the guest exists”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Action retry policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C066-T03 · Valid control:** Construct a valid “Action retry policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C066-T04 · Minimal adverse input:** Derive the “Action retry policy” adverse fixture from the control with the smallest documented change needed to reproduce “A timed-out create is retried without checking whether the guest exists”; retain that change as reproducible data.
- [ ] **UC-M05.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Action retry policy”; require “An uncertain result is reconciled rather than blindly repeated” and forbid a false-success verdict.
- [ ] **UC-M05.04-C066-T06 · Adverse execution:** Exercise the “Action retry policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C066-T07 · Effect inspection:** Inspect “Action retry policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C066-T08 · Refusal versus failure:** Confirm the “Action retry policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C066-T09 · Reset and retention:** Restore only the disposable “Action retry policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C066-T10 · Negative regression:** Register the “Action retry policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C067 · Change / failure test

**Original checklist item:** Exercise action retry policy when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C067-T01 · Scenario record:** Write the “Action retry policy” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “An uncertain result is reconciled rather than blindly repeated”.
- [ ] **UC-M05.04-C067-T02 · Baseline capture:** Create a known-valid “Action retry policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C067-T03 · Injection map:** Locate the “Action retry policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Action retry policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C067-T05 · Controlled trigger:** Introduce the controlled “Action retry policy” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C067-T06 · Intermediate inspection:** Inspect the “Action retry policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Action retry policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Action retry policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C067-T09 · Repeat and compare:** Repeat the selected “Action retry policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C067-T10 · Failure evidence:** Publish the “Action retry policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C068 · Bounds

**Original checklist item:** Choose, document and test limits for retry count and backoff ceiling; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Action retry policy”: “Retry count and backoff ceiling”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C068-T02 · Measurement method:** Choose how to observe each “Action retry policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C068-T03 · Budget decision:** Select justified resource and input limits for “Action retry policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Action retry policy” cases for “Retry count and backoff ceiling”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Action retry policy” limit; preserve “An uncertain result is reconciled rather than blindly repeated”.
- [ ] **UC-M05.04-C068-T06 · Normal measurement:** Run or review the normal “Action retry policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C068-T07 · At-limit measurement:** Exercise the “Action retry policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C068-T08 · Over-limit measurement:** Exercise the “Action retry policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C068-T09 · Uncovered-scope report:** List the “Action retry policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C068-T10 · Limit evidence:** Publish the selected “Action retry policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for action retry policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C069-T01 · Event inventory:** List the “Action retry policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Action retry policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C069-T03 · Failure mapping:** Map each documented “Action retry policy” refusal or error to a diagnostic outcome; include “A timed-out create is retried without checking whether the guest exists” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C069-T04 · Emission path:** Add the “Action retry policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C069-T05 · Redaction check:** Test “Action retry policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C069-T06 · Output budget:** Set and exercise bounded “Action retry policy” message size, rate and retention compatible with “Retry count and backoff ceiling”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C069-T07 · Success/refusal fixtures:** Capture “Action retry policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Action retry policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C069-T09 · Operator review:** Read the “Action retry policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C069-T10 · Diagnostic evidence:** Publish redacted “Action retry policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for action retry policy; label unexecuted checks as untested.

- [ ] **UC-M05.04-C070-T01 · Evidence inventory:** List the “Action retry policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C070-T02 · Artifact references:** Record the exact “Action retry policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C070-T03 · Fixture references:** Attach the “Action retry policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A timed-out create is retried without checking whether the guest exists” as a distinct evidence case.
- [ ] **UC-M05.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Action retry policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C070-T05 · Environment record:** Record the actual “Action retry policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C070-T06 · Expected versus observed:** Pair every “Action retry policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C070-T07 · Failure and limit records:** Attach “Action retry policy” change/failure and bounds evidence where required; include uncovered “Retry count and backoff ceiling” and unresolved violations of “An uncertain result is reconciled rather than blindly repeated”.
- [ ] **UC-M05.04-C070-T08 · Evidence hygiene:** Check the “Action retry policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C070-T09 · Reproduction review:** Have the “Action retry policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C070-T10 · Acceptance linkage:** Link the “Action retry policy” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Orphan detection

**Source delivery:** Identify backend instances with no valid current control-plane ownership.

**Source invariant:** Orphans have an explicit quarantine or cleanup disposition.

**Source negative case:** An unowned guest continues running after registry recovery.

**Source bounded quantities:** Orphan count and cleanup deadline.

### UC-M05.04-C071 · Contract

**Original checklist item:** Specify orphan detection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C071-T01 · Scope statement:** Draft the operation boundary for “Orphan detection” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Orphan detection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C071-T03 · Output inventory:** List the outputs of “Orphan detection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Orphan detection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C071-T05 · Prerequisite contract:** Map “Orphan detection” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Orphan detection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C071-T07 · Invariant clause:** Add a normative clause for “Orphan detection” that preserves “Orphans have an explicit quarantine or cleanup disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Orphan detection”; include the source counterexample “An unowned guest continues running after registry recovery” and the intended safe disposition.
- [ ] **UC-M05.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Orphan count and cleanup deadline” in the “Orphan detection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C071-T10 · Contract review:** Review the “Orphan detection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C072 · Delivery

**Original checklist item:** Identify backend instances with no valid current control-plane ownership.

- [ ] **UC-M05.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Orphan detection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C072-T02 · Change plan:** Break the source delivery for “Orphan detection” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C072-T03 · Core artifact:** Create the “Orphan detection” model, schema or inventory that realizes this source instruction: Identify backend instances with no valid current control-plane ownership.
- [ ] **UC-M05.04-C072-T04 · Concrete realization:** Populate “Orphan detection” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M05.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Orphan detection” needed to preserve “Orphans have an explicit quarantine or cleanup disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C072-T06 · Dependency connection:** Connect the “Orphan detection” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C072-T07 · Resource behavior:** Account for “Orphan count and cleanup deadline” in “Orphan detection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C072-T08 · Delivery check:** Run the smallest real “Orphan detection” path and its adverse fixture “An unowned guest continues running after registry recovery”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C072-T09 · Patch review:** Review the “Orphan detection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C072-T10 · Delivery handoff:** Publish the “Orphan detection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Orphans have an explicit quarantine or cleanup disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Orphan detection”; copy its required invariant exactly: “Orphans have an explicit quarantine or cleanup disposition”.
- [ ] **UC-M05.04-C073-T02 · Observable terms:** Define each term in the “Orphan detection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C073-T03 · Precondition set:** List the preconditions under which “Orphans have an explicit quarantine or cleanup disposition” must hold for “Orphan detection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C073-T04 · Transition coverage:** Map the “Orphan detection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Orphan detection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C073-T06 · Satisfying fixture:** Create a concrete “Orphan detection” case that satisfies “Orphans have an explicit quarantine or cleanup disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C073-T07 · Violating fixture:** Create the source counterexample “An unowned guest continues running after registry recovery” for “Orphan detection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C073-T08 · Enforcement evidence:** Exercise the “Orphan detection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C073-T09 · Regression linkage:** Link the “Orphan detection” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Orphan detection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C074 · Integration

**Original checklist item:** Integrate orphan detection with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Orphan detection” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C074-T02 · Field mapping:** Map every “Orphan detection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Orphan detection” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C074-T04 · Ownership agreement:** Specify who owns “Orphan detection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C074-T05 · Handoff implementation:** Connect “Orphan detection” through the mapped seam using the real adapter or explicit specification reference; preserve “Orphans have an explicit quarantine or cleanup disposition” across the handoff.
- [ ] **UC-M05.04-C074-T06 · Absent-input case:** Omit one required “Orphan detection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C074-T07 · Stale-input case:** Supply an outdated “Orphan detection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Orphan detection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C074-T09 · Valid integration trace:** Run a valid “Orphan detection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C074-T10 · Seam review:** Reconcile the “Orphan detection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for orphan detection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Orphan detection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C075-T02 · Expected-result oracle:** Specify the “Orphan detection” expected result independently of the implementation output; include the property “Orphans have an explicit quarantine or cleanup disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C075-T03 · Fixture material:** Create the concrete “Orphan detection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C075-T04 · Target preparation:** Prepare the “Orphan detection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C075-T05 · Initial-state record:** Record the initial “Orphan detection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C075-T06 · Valid-path execution:** Execute the “Orphan detection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C075-T07 · Outcome comparison:** Compare every declared “Orphan detection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C075-T08 · State and bounds check:** Inspect the “Orphan detection” ownership/state effects and actual use of “Orphan count and cleanup deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C075-T09 · Repeatability check:** Repeat the same “Orphan detection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C075-T10 · Positive evidence:** Attach the “Orphan detection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C076 · Negative test

**Original checklist item:** Negative case: An unowned guest continues running after registry recovery. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Orphan detection” source counterexample: “An unowned guest continues running after registry recovery”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Orphan detection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C076-T03 · Valid control:** Construct a valid “Orphan detection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C076-T04 · Minimal adverse input:** Derive the “Orphan detection” adverse fixture from the control with the smallest documented change needed to reproduce “An unowned guest continues running after registry recovery”; retain that change as reproducible data.
- [ ] **UC-M05.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Orphan detection”; require “Orphans have an explicit quarantine or cleanup disposition” and forbid a false-success verdict.
- [ ] **UC-M05.04-C076-T06 · Adverse execution:** Exercise the “Orphan detection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C076-T07 · Effect inspection:** Inspect “Orphan detection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C076-T08 · Refusal versus failure:** Confirm the “Orphan detection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C076-T09 · Reset and retention:** Restore only the disposable “Orphan detection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C076-T10 · Negative regression:** Register the “Orphan detection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C077 · Change / failure test

**Original checklist item:** Exercise orphan detection when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C077-T01 · Scenario record:** Write the “Orphan detection” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Orphans have an explicit quarantine or cleanup disposition”.
- [ ] **UC-M05.04-C077-T02 · Baseline capture:** Create a known-valid “Orphan detection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C077-T03 · Injection map:** Locate the “Orphan detection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Orphan detection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C077-T05 · Controlled trigger:** Introduce the controlled “Orphan detection” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C077-T06 · Intermediate inspection:** Inspect the “Orphan detection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Orphan detection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Orphan detection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C077-T09 · Repeat and compare:** Repeat the selected “Orphan detection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C077-T10 · Failure evidence:** Publish the “Orphan detection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C078 · Bounds

**Original checklist item:** Choose, document and test limits for orphan count and cleanup deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Orphan detection”: “Orphan count and cleanup deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C078-T02 · Measurement method:** Choose how to observe each “Orphan detection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C078-T03 · Budget decision:** Select justified resource and input limits for “Orphan detection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Orphan detection” cases for “Orphan count and cleanup deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Orphan detection” limit; preserve “Orphans have an explicit quarantine or cleanup disposition”.
- [ ] **UC-M05.04-C078-T06 · Normal measurement:** Run or review the normal “Orphan detection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C078-T07 · At-limit measurement:** Exercise the “Orphan detection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C078-T08 · Over-limit measurement:** Exercise the “Orphan detection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C078-T09 · Uncovered-scope report:** List the “Orphan detection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C078-T10 · Limit evidence:** Publish the selected “Orphan detection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for orphan detection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C079-T01 · Event inventory:** List the “Orphan detection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Orphan detection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C079-T03 · Failure mapping:** Map each documented “Orphan detection” refusal or error to a diagnostic outcome; include “An unowned guest continues running after registry recovery” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C079-T04 · Emission path:** Add the “Orphan detection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C079-T05 · Redaction check:** Test “Orphan detection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C079-T06 · Output budget:** Set and exercise bounded “Orphan detection” message size, rate and retention compatible with “Orphan count and cleanup deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C079-T07 · Success/refusal fixtures:** Capture “Orphan detection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Orphan detection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C079-T09 · Operator review:** Read the “Orphan detection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C079-T10 · Diagnostic evidence:** Publish redacted “Orphan detection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for orphan detection; label unexecuted checks as untested.

- [ ] **UC-M05.04-C080-T01 · Evidence inventory:** List the “Orphan detection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C080-T02 · Artifact references:** Record the exact “Orphan detection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C080-T03 · Fixture references:** Attach the “Orphan detection” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unowned guest continues running after registry recovery” as a distinct evidence case.
- [ ] **UC-M05.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Orphan detection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C080-T05 · Environment record:** Record the actual “Orphan detection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C080-T06 · Expected versus observed:** Pair every “Orphan detection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C080-T07 · Failure and limit records:** Attach “Orphan detection” change/failure and bounds evidence where required; include uncovered “Orphan count and cleanup deadline” and unresolved violations of “Orphans have an explicit quarantine or cleanup disposition”.
- [ ] **UC-M05.04-C080-T08 · Evidence hygiene:** Check the “Orphan detection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C080-T09 · Reproduction review:** Have the “Orphan detection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C080-T10 · Acceptance linkage:** Link the “Orphan detection” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Concurrent controller safety

**Source delivery:** Coordinate simultaneous reconcilers for the supported single-host profile.

**Source invariant:** Two reconcilers cannot both own the same generation's mutation.

**Source negative case:** Two controller processes reconcile the same workload concurrently.

**Source bounded quantities:** Controller count and lock contention.

### UC-M05.04-C081 · Contract

**Original checklist item:** Specify concurrent controller safety inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C081-T01 · Scope statement:** Draft the operation boundary for “Concurrent controller safety” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Concurrent controller safety”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C081-T03 · Output inventory:** List the outputs of “Concurrent controller safety” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Concurrent controller safety”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C081-T05 · Prerequisite contract:** Map “Concurrent controller safety” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Concurrent controller safety”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C081-T07 · Invariant clause:** Add a normative clause for “Concurrent controller safety” that preserves “Two reconcilers cannot both own the same generation's mutation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Concurrent controller safety”; include the source counterexample “Two controller processes reconcile the same workload concurrently” and the intended safe disposition.
- [ ] **UC-M05.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Controller count and lock contention” in the “Concurrent controller safety” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C081-T10 · Contract review:** Review the “Concurrent controller safety” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C082 · Delivery

**Original checklist item:** Coordinate simultaneous reconcilers for the supported single-host profile.

- [ ] **UC-M05.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Concurrent controller safety”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C082-T02 · Change plan:** Break the source delivery for “Concurrent controller safety” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Concurrent controller safety” that realizes this source instruction: Coordinate simultaneous reconcilers for the supported single-host profile.
- [ ] **UC-M05.04-C082-T04 · Concrete realization:** Trace “Concurrent controller safety” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M05.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Concurrent controller safety” needed to preserve “Two reconcilers cannot both own the same generation's mutation”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C082-T06 · Dependency connection:** Connect the “Concurrent controller safety” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C082-T07 · Resource behavior:** Account for “Controller count and lock contention” in “Concurrent controller safety”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C082-T08 · Delivery check:** Run the smallest real “Concurrent controller safety” path and its adverse fixture “Two controller processes reconcile the same workload concurrently”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C082-T09 · Patch review:** Review the “Concurrent controller safety” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C082-T10 · Delivery handoff:** Publish the “Concurrent controller safety” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Two reconcilers cannot both own the same generation's mutation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Concurrent controller safety”; copy its required invariant exactly: “Two reconcilers cannot both own the same generation's mutation”.
- [ ] **UC-M05.04-C083-T02 · Observable terms:** Define each term in the “Concurrent controller safety” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C083-T03 · Precondition set:** List the preconditions under which “Two reconcilers cannot both own the same generation's mutation” must hold for “Concurrent controller safety”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C083-T04 · Transition coverage:** Map the “Concurrent controller safety” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Concurrent controller safety”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C083-T06 · Satisfying fixture:** Create a concrete “Concurrent controller safety” case that satisfies “Two reconcilers cannot both own the same generation's mutation”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C083-T07 · Violating fixture:** Create the source counterexample “Two controller processes reconcile the same workload concurrently” for “Concurrent controller safety”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C083-T08 · Enforcement evidence:** Exercise the “Concurrent controller safety” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C083-T09 · Regression linkage:** Link the “Concurrent controller safety” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Concurrent controller safety” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C084 · Integration

**Original checklist item:** Integrate concurrent controller safety with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Concurrent controller safety” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C084-T02 · Field mapping:** Map every “Concurrent controller safety” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Concurrent controller safety” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C084-T04 · Ownership agreement:** Specify who owns “Concurrent controller safety” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C084-T05 · Handoff implementation:** Connect “Concurrent controller safety” through the mapped seam using the real adapter or explicit specification reference; preserve “Two reconcilers cannot both own the same generation's mutation” across the handoff.
- [ ] **UC-M05.04-C084-T06 · Absent-input case:** Omit one required “Concurrent controller safety” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C084-T07 · Stale-input case:** Supply an outdated “Concurrent controller safety” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Concurrent controller safety” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C084-T09 · Valid integration trace:** Run a valid “Concurrent controller safety” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C084-T10 · Seam review:** Reconcile the “Concurrent controller safety” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for concurrent controller safety; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Concurrent controller safety” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C085-T02 · Expected-result oracle:** Specify the “Concurrent controller safety” expected result independently of the implementation output; include the property “Two reconcilers cannot both own the same generation's mutation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C085-T03 · Fixture material:** Create the concrete “Concurrent controller safety” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C085-T04 · Target preparation:** Prepare the “Concurrent controller safety” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C085-T05 · Initial-state record:** Record the initial “Concurrent controller safety” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C085-T06 · Valid-path execution:** Execute the “Concurrent controller safety” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C085-T07 · Outcome comparison:** Compare every declared “Concurrent controller safety” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C085-T08 · State and bounds check:** Inspect the “Concurrent controller safety” ownership/state effects and actual use of “Controller count and lock contention”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C085-T09 · Repeatability check:** Repeat the same “Concurrent controller safety” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C085-T10 · Positive evidence:** Attach the “Concurrent controller safety” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C086 · Negative test

**Original checklist item:** Negative case: Two controller processes reconcile the same workload concurrently. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Concurrent controller safety” source counterexample: “Two controller processes reconcile the same workload concurrently”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Concurrent controller safety”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C086-T03 · Valid control:** Construct a valid “Concurrent controller safety” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C086-T04 · Minimal adverse input:** Derive the “Concurrent controller safety” adverse fixture from the control with the smallest documented change needed to reproduce “Two controller processes reconcile the same workload concurrently”; retain that change as reproducible data.
- [ ] **UC-M05.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Concurrent controller safety”; require “Two reconcilers cannot both own the same generation's mutation” and forbid a false-success verdict.
- [ ] **UC-M05.04-C086-T06 · Adverse execution:** Exercise the “Concurrent controller safety” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C086-T07 · Effect inspection:** Inspect “Concurrent controller safety” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C086-T08 · Refusal versus failure:** Confirm the “Concurrent controller safety” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C086-T09 · Reset and retention:** Restore only the disposable “Concurrent controller safety” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C086-T10 · Negative regression:** Register the “Concurrent controller safety” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C087 · Change / failure test

**Original checklist item:** Exercise concurrent controller safety when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C087-T01 · Scenario record:** Write the “Concurrent controller safety” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Two reconcilers cannot both own the same generation's mutation”.
- [ ] **UC-M05.04-C087-T02 · Baseline capture:** Create a known-valid “Concurrent controller safety” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C087-T03 · Injection map:** Locate the “Concurrent controller safety” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Concurrent controller safety” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C087-T05 · Controlled trigger:** Introduce the controlled “Concurrent controller safety” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C087-T06 · Intermediate inspection:** Inspect the “Concurrent controller safety” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Concurrent controller safety”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Concurrent controller safety” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C087-T09 · Repeat and compare:** Repeat the selected “Concurrent controller safety” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C087-T10 · Failure evidence:** Publish the “Concurrent controller safety” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C088 · Bounds

**Original checklist item:** Choose, document and test limits for controller count and lock contention; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Concurrent controller safety”: “Controller count and lock contention”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C088-T02 · Measurement method:** Choose how to observe each “Concurrent controller safety” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C088-T03 · Budget decision:** Select justified resource and input limits for “Concurrent controller safety”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Concurrent controller safety” cases for “Controller count and lock contention”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Concurrent controller safety” limit; preserve “Two reconcilers cannot both own the same generation's mutation”.
- [ ] **UC-M05.04-C088-T06 · Normal measurement:** Run or review the normal “Concurrent controller safety” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C088-T07 · At-limit measurement:** Exercise the “Concurrent controller safety” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C088-T08 · Over-limit measurement:** Exercise the “Concurrent controller safety” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C088-T09 · Uncovered-scope report:** List the “Concurrent controller safety” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C088-T10 · Limit evidence:** Publish the selected “Concurrent controller safety” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for concurrent controller safety with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C089-T01 · Event inventory:** List the “Concurrent controller safety” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Concurrent controller safety” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C089-T03 · Failure mapping:** Map each documented “Concurrent controller safety” refusal or error to a diagnostic outcome; include “Two controller processes reconcile the same workload concurrently” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C089-T04 · Emission path:** Add the “Concurrent controller safety” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C089-T05 · Redaction check:** Test “Concurrent controller safety” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C089-T06 · Output budget:** Set and exercise bounded “Concurrent controller safety” message size, rate and retention compatible with “Controller count and lock contention”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C089-T07 · Success/refusal fixtures:** Capture “Concurrent controller safety” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Concurrent controller safety” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C089-T09 · Operator review:** Read the “Concurrent controller safety” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C089-T10 · Diagnostic evidence:** Publish redacted “Concurrent controller safety” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for concurrent controller safety; label unexecuted checks as untested.

- [ ] **UC-M05.04-C090-T01 · Evidence inventory:** List the “Concurrent controller safety” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C090-T02 · Artifact references:** Record the exact “Concurrent controller safety” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C090-T03 · Fixture references:** Attach the “Concurrent controller safety” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two controller processes reconcile the same workload concurrently” as a distinct evidence case.
- [ ] **UC-M05.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Concurrent controller safety”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C090-T05 · Environment record:** Record the actual “Concurrent controller safety” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C090-T06 · Expected versus observed:** Pair every “Concurrent controller safety” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C090-T07 · Failure and limit records:** Attach “Concurrent controller safety” change/failure and bounds evidence where required; include uncovered “Controller count and lock contention” and unresolved violations of “Two reconcilers cannot both own the same generation's mutation”.
- [ ] **UC-M05.04-C090-T08 · Evidence hygiene:** Check the “Concurrent controller safety” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C090-T09 · Reproduction review:** Have the “Concurrent controller safety” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C090-T10 · Acceptance linkage:** Link the “Concurrent controller safety” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Convergence qualification

**Source delivery:** Test repeated commands and controller restart during each lifecycle action.

**Source invariant:** Observed state converges without duplicated instances or lost admitted work.

**Source negative case:** Repeated delivery creates several guests for one workload.

**Source bounded quantities:** Sequence length and convergence observations.

### UC-M05.04-C091 · Contract

**Original checklist item:** Specify convergence qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M05.04-C091-T01 · Scope statement:** Draft the operation boundary for “Convergence qualification” within Idempotent reconciliation controller; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M05.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Convergence qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M05.04-C091-T03 · Output inventory:** List the outputs of “Convergence qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M05.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Convergence qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M05.04-C091-T05 · Prerequisite contract:** Map “Convergence qualification” to the source component prerequisites (UC-M01.03, UC-M01.05, UC-M05.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M05.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Convergence qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M05.04-C091-T07 · Invariant clause:** Add a normative clause for “Convergence qualification” that preserves “Observed state converges without duplicated instances or lost admitted work”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M05.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Convergence qualification”; include the source counterexample “Repeated delivery creates several guests for one workload” and the intended safe disposition.
- [ ] **UC-M05.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Sequence length and convergence observations” in the “Convergence qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M05.04-C091-T10 · Contract review:** Review the “Convergence qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M05.04-C092 · Delivery

**Original checklist item:** Test repeated commands and controller restart during each lifecycle action.

- [ ] **UC-M05.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Convergence qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M05.04-C092-T02 · Change plan:** Break the source delivery for “Convergence qualification” into concrete edit targets and reviewable outputs; keep the UC-M05.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M05.04-C092-T03 · Core artifact:** Create the “Convergence qualification” fixture or harness for this source instruction: Test repeated commands and controller restart during each lifecycle action.
- [ ] **UC-M05.04-C092-T04 · Concrete realization:** Connect the “Convergence qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M05.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Convergence qualification” needed to preserve “Observed state converges without duplicated instances or lost admitted work”; record an enforcement gap where only a model exists.
- [ ] **UC-M05.04-C092-T06 · Dependency connection:** Connect the “Convergence qualification” implementation to durable intent, actual backend instances and idempotent lifecycle operations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M05.04-C092-T07 · Resource behavior:** Account for “Sequence length and convergence observations” in “Convergence qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M05.04-C092-T08 · Delivery check:** Run the smallest real “Convergence qualification” path and its adverse fixture “Repeated delivery creates several guests for one workload”; retain actual output, state effects and final disposition.
- [ ] **UC-M05.04-C092-T09 · Patch review:** Review the “Convergence qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M05.04-C092-T10 · Delivery handoff:** Publish the “Convergence qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M05.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Observed state converges without duplicated instances or lost admitted work. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M05.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Convergence qualification”; copy its required invariant exactly: “Observed state converges without duplicated instances or lost admitted work”.
- [ ] **UC-M05.04-C093-T02 · Observable terms:** Define each term in the “Convergence qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M05.04-C093-T03 · Precondition set:** List the preconditions under which “Observed state converges without duplicated instances or lost admitted work” must hold for “Convergence qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M05.04-C093-T04 · Transition coverage:** Map the “Convergence qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M05.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Convergence qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M05.04-C093-T06 · Satisfying fixture:** Create a concrete “Convergence qualification” case that satisfies “Observed state converges without duplicated instances or lost admitted work”; record its expected observation before running the assertion or review.
- [ ] **UC-M05.04-C093-T07 · Violating fixture:** Create the source counterexample “Repeated delivery creates several guests for one workload” for “Convergence qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M05.04-C093-T08 · Enforcement evidence:** Exercise the “Convergence qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M05.04-C093-T09 · Regression linkage:** Link the “Convergence qualification” property to changes in durable intent, actual backend instances and idempotent lifecycle operations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M05.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Convergence qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M05.04-C094 · Integration

**Original checklist item:** Integrate convergence qualification with durable intent, actual backend instances and idempotent lifecycle operations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M05.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Convergence qualification” across durable intent, actual backend instances and idempotent lifecycle operations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M05.04-C094-T02 · Field mapping:** Map every “Convergence qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M05.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Convergence qualification” (source dependency list: UC-M01.03, UC-M01.05, UC-M05.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M05.04-C094-T04 · Ownership agreement:** Specify who owns “Convergence qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M05.04-C094-T05 · Handoff implementation:** Connect “Convergence qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Observed state converges without duplicated instances or lost admitted work” across the handoff.
- [ ] **UC-M05.04-C094-T06 · Absent-input case:** Omit one required “Convergence qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M05.04-C094-T07 · Stale-input case:** Supply an outdated “Convergence qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M05.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Convergence qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M05.04-C094-T09 · Valid integration trace:** Run a valid “Convergence qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M05.04-C094-T10 · Seam review:** Reconcile the “Convergence qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M05.04-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for convergence qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M05.04-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Convergence qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M05.04-C095-T02 · Expected-result oracle:** Specify the “Convergence qualification” expected result independently of the implementation output; include the property “Observed state converges without duplicated instances or lost admitted work” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M05.04-C095-T03 · Fixture material:** Create the concrete “Convergence qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M05.04-C095-T04 · Target preparation:** Prepare the “Convergence qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M05.04-C095-T05 · Initial-state record:** Record the initial “Convergence qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M05.04-C095-T06 · Valid-path execution:** Execute the “Convergence qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M05.04-C095-T07 · Outcome comparison:** Compare every declared “Convergence qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M05.04-C095-T08 · State and bounds check:** Inspect the “Convergence qualification” ownership/state effects and actual use of “Sequence length and convergence observations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M05.04-C095-T09 · Repeatability check:** Repeat the same “Convergence qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M05.04-C095-T10 · Positive evidence:** Attach the “Convergence qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M05.04-C096 · Negative test

**Original checklist item:** Negative case: Repeated delivery creates several guests for one workload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M05.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Convergence qualification” source counterexample: “Repeated delivery creates several guests for one workload”; state which precondition or invariant it challenges.
- [ ] **UC-M05.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Convergence qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M05.04-C096-T03 · Valid control:** Construct a valid “Convergence qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M05.04-C096-T04 · Minimal adverse input:** Derive the “Convergence qualification” adverse fixture from the control with the smallest documented change needed to reproduce “Repeated delivery creates several guests for one workload”; retain that change as reproducible data.
- [ ] **UC-M05.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Convergence qualification”; require “Observed state converges without duplicated instances or lost admitted work” and forbid a false-success verdict.
- [ ] **UC-M05.04-C096-T06 · Adverse execution:** Exercise the “Convergence qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M05.04-C096-T07 · Effect inspection:** Inspect “Convergence qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M05.04-C096-T08 · Refusal versus failure:** Confirm the “Convergence qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M05.04-C096-T09 · Reset and retention:** Restore only the disposable “Convergence qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M05.04-C096-T10 · Negative regression:** Register the “Convergence qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M05.04-C097 · Change / failure test

**Original checklist item:** Exercise convergence qualification when a create acknowledgment is lost and the controller restarts before retrying; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M05.04-C097-T01 · Scenario record:** Write the “Convergence qualification” change/failure scenario exactly as supplied: a create acknowledgment is lost and the controller restarts before retrying; identify the property that must remain true: “Observed state converges without duplicated instances or lost admitted work”.
- [ ] **UC-M05.04-C097-T02 · Baseline capture:** Create a known-valid “Convergence qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M05.04-C097-T03 · Injection map:** Locate the “Convergence qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M05.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Convergence qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M05.04-C097-T05 · Controlled trigger:** Introduce the controlled “Convergence qualification” scenario in the disposable fixture: a create acknowledgment is lost and the controller restarts before retrying; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M05.04-C097-T06 · Intermediate inspection:** Inspect the “Convergence qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M05.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Convergence qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M05.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Convergence qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M05.04-C097-T09 · Repeat and compare:** Repeat the selected “Convergence qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M05.04-C097-T10 · Failure evidence:** Publish the “Convergence qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M05.04-C098 · Bounds

**Original checklist item:** Choose, document and test limits for sequence length and convergence observations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M05.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Convergence qualification”: “Sequence length and convergence observations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M05.04-C098-T02 · Measurement method:** Choose how to observe each “Convergence qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M05.04-C098-T03 · Budget decision:** Select justified resource and input limits for “Convergence qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M05.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Convergence qualification” cases for “Sequence length and convergence observations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M05.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Convergence qualification” limit; preserve “Observed state converges without duplicated instances or lost admitted work”.
- [ ] **UC-M05.04-C098-T06 · Normal measurement:** Run or review the normal “Convergence qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M05.04-C098-T07 · At-limit measurement:** Exercise the “Convergence qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M05.04-C098-T08 · Over-limit measurement:** Exercise the “Convergence qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M05.04-C098-T09 · Uncovered-scope report:** List the “Convergence qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M05.04-C098-T10 · Limit evidence:** Publish the selected “Convergence qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M05.04-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for convergence qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M05.04-C099-T01 · Event inventory:** List the “Convergence qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M05.04-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Convergence qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M05.04-C099-T03 · Failure mapping:** Map each documented “Convergence qualification” refusal or error to a diagnostic outcome; include “Repeated delivery creates several guests for one workload” and prohibit conversion into a success message.
- [ ] **UC-M05.04-C099-T04 · Emission path:** Add the “Convergence qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M05.04-C099-T05 · Redaction check:** Test “Convergence qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M05.04-C099-T06 · Output budget:** Set and exercise bounded “Convergence qualification” message size, rate and retention compatible with “Sequence length and convergence observations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M05.04-C099-T07 · Success/refusal fixtures:** Capture “Convergence qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M05.04-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Convergence qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M05.04-C099-T09 · Operator review:** Read the “Convergence qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M05.04-C099-T10 · Diagnostic evidence:** Publish redacted “Convergence qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M05.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for convergence qualification; label unexecuted checks as untested.

- [ ] **UC-M05.04-C100-T01 · Evidence inventory:** List the “Convergence qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M05.04-C100-T02 · Artifact references:** Record the exact “Convergence qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M05.04-C100-T03 · Fixture references:** Attach the “Convergence qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “Repeated delivery creates several guests for one workload” as a distinct evidence case.
- [ ] **UC-M05.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Convergence qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M05.04-C100-T05 · Environment record:** Record the actual “Convergence qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M05.04-C100-T06 · Expected versus observed:** Pair every “Convergence qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M05.04-C100-T07 · Failure and limit records:** Attach “Convergence qualification” change/failure and bounds evidence where required; include uncovered “Sequence length and convergence observations” and unresolved violations of “Observed state converges without duplicated instances or lost admitted work”.
- [ ] **UC-M05.04-C100-T08 · Evidence hygiene:** Check the “Convergence qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M05.04-C100-T09 · Reproduction review:** Have the “Convergence qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M05.04-C100-T10 · Acceptance linkage:** Link the “Convergence qualification” evidence to its parent and UC-M05.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

