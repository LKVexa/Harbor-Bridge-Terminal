# UC-M08.01 — Typed guest-host IPC ABI

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/08.md)

| Field | Preserved source value |
|---|---|
| Workstream | 08. Guest communication and data plane |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M01.02](../01/UC-M01.02.md), [UC-M02.07](../02/UC-M02.07.md), [UC-M03.07](../03/UC-M03.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3], [S4]. |

## Original requirement

Define request/response buffers, handles, errors and ownership across the actual guest boundary; default to local transport.

**Original acceptance criterion:** Unknown operations, invalid handles and out-of-bounds buffers cannot reach arbitrary host functions.

**Source trace:** Original checklist `UC100/c/08/UC-M08.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 714–724 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. IPC operation table

**Source delivery:** Define supported guest-host operations and explicit unknown-operation refusal.

**Source invariant:** Guest requests can reach only enumerated host functions.

**Source negative case:** An unknown operation number invokes an arbitrary handler.

**Source bounded quantities:** Operation count and dispatch-table size.

### UC-M08.01-C001 · Contract

**Original checklist item:** Specify IPC operation table inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C001-T01 · Scope statement:** Draft the operation boundary for “IPC operation table” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “IPC operation table”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C001-T03 · Output inventory:** List the outputs of “IPC operation table” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “IPC operation table”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C001-T05 · Prerequisite contract:** Map “IPC operation table” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C001-T06 · Authority map:** Identify who may produce, change and consume “IPC operation table”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C001-T07 · Invariant clause:** Add a normative clause for “IPC operation table” that preserves “Guest requests can reach only enumerated host functions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “IPC operation table”; include the source counterexample “An unknown operation number invokes an arbitrary handler” and the intended safe disposition.
- [ ] **UC-M08.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Operation count and dispatch-table size” in the “IPC operation table” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C001-T10 · Contract review:** Review the “IPC operation table” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C002 · Delivery

**Original checklist item:** Define supported guest-host operations and explicit unknown-operation refusal.

- [ ] **UC-M08.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “IPC operation table”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C002-T02 · Change plan:** Break the source delivery for “IPC operation table” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C002-T03 · Core artifact:** Create the “IPC operation table” model, schema or inventory that realizes this source instruction: Define supported guest-host operations and explicit unknown-operation refusal.
- [ ] **UC-M08.01-C002-T04 · Concrete realization:** Populate “IPC operation table” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “IPC operation table” needed to preserve “Guest requests can reach only enumerated host functions”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C002-T06 · Dependency connection:** Connect the “IPC operation table” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C002-T07 · Resource behavior:** Account for “Operation count and dispatch-table size” in “IPC operation table”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C002-T08 · Delivery check:** Run the smallest real “IPC operation table” path and its adverse fixture “An unknown operation number invokes an arbitrary handler”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C002-T09 · Patch review:** Review the “IPC operation table” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C002-T10 · Delivery handoff:** Publish the “IPC operation table” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Guest requests can reach only enumerated host functions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “IPC operation table”; copy its required invariant exactly: “Guest requests can reach only enumerated host functions”.
- [ ] **UC-M08.01-C003-T02 · Observable terms:** Define each term in the “IPC operation table” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C003-T03 · Precondition set:** List the preconditions under which “Guest requests can reach only enumerated host functions” must hold for “IPC operation table”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C003-T04 · Transition coverage:** Map the “IPC operation table” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “IPC operation table”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C003-T06 · Satisfying fixture:** Create a concrete “IPC operation table” case that satisfies “Guest requests can reach only enumerated host functions”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C003-T07 · Violating fixture:** Create the source counterexample “An unknown operation number invokes an arbitrary handler” for “IPC operation table”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C003-T08 · Enforcement evidence:** Exercise the “IPC operation table” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C003-T09 · Regression linkage:** Link the “IPC operation table” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C003-T10 · Property disposition:** Compare the satisfying and violating “IPC operation table” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C004 · Integration

**Original checklist item:** Integrate IPC operation table with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “IPC operation table” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C004-T02 · Field mapping:** Map every “IPC operation table” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “IPC operation table” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C004-T04 · Ownership agreement:** Specify who owns “IPC operation table” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C004-T05 · Handoff implementation:** Connect “IPC operation table” through the mapped seam using the real adapter or explicit specification reference; preserve “Guest requests can reach only enumerated host functions” across the handoff.
- [ ] **UC-M08.01-C004-T06 · Absent-input case:** Omit one required “IPC operation table” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C004-T07 · Stale-input case:** Supply an outdated “IPC operation table” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C004-T08 · Incompatible-input case:** Supply an incompatible “IPC operation table” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C004-T09 · Valid integration trace:** Run a valid “IPC operation table” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C004-T10 · Seam review:** Reconcile the “IPC operation table” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for IPC operation table; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “IPC operation table” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C005-T02 · Expected-result oracle:** Specify the “IPC operation table” expected result independently of the implementation output; include the property “Guest requests can reach only enumerated host functions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C005-T03 · Fixture material:** Create the concrete “IPC operation table” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C005-T04 · Target preparation:** Prepare the “IPC operation table” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C005-T05 · Initial-state record:** Record the initial “IPC operation table” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C005-T06 · Valid-path execution:** Execute the “IPC operation table” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C005-T07 · Outcome comparison:** Compare every declared “IPC operation table” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C005-T08 · State and bounds check:** Inspect the “IPC operation table” ownership/state effects and actual use of “Operation count and dispatch-table size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C005-T09 · Repeatability check:** Repeat the same “IPC operation table” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C005-T10 · Positive evidence:** Attach the “IPC operation table” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C006 · Negative test

**Original checklist item:** Negative case: An unknown operation number invokes an arbitrary handler. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “IPC operation table” source counterexample: “An unknown operation number invokes an arbitrary handler”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “IPC operation table”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C006-T03 · Valid control:** Construct a valid “IPC operation table” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C006-T04 · Minimal adverse input:** Derive the “IPC operation table” adverse fixture from the control with the smallest documented change needed to reproduce “An unknown operation number invokes an arbitrary handler”; retain that change as reproducible data.
- [ ] **UC-M08.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “IPC operation table”; require “Guest requests can reach only enumerated host functions” and forbid a false-success verdict.
- [ ] **UC-M08.01-C006-T06 · Adverse execution:** Exercise the “IPC operation table” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C006-T07 · Effect inspection:** Inspect “IPC operation table” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C006-T08 · Refusal versus failure:** Confirm the “IPC operation table” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C006-T09 · Reset and retention:** Restore only the disposable “IPC operation table” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C006-T10 · Negative regression:** Register the “IPC operation table” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C007 · Change / failure test

**Original checklist item:** Exercise IPC operation table when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C007-T01 · Scenario record:** Write the “IPC operation table” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “Guest requests can reach only enumerated host functions”.
- [ ] **UC-M08.01-C007-T02 · Baseline capture:** Create a known-valid “IPC operation table” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C007-T03 · Injection map:** Locate the “IPC operation table” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “IPC operation table” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C007-T05 · Controlled trigger:** Introduce the controlled “IPC operation table” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C007-T06 · Intermediate inspection:** Inspect the “IPC operation table” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “IPC operation table”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “IPC operation table” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C007-T09 · Repeat and compare:** Repeat the selected “IPC operation table” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C007-T10 · Failure evidence:** Publish the “IPC operation table” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for operation count and dispatch-table size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “IPC operation table”: “Operation count and dispatch-table size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C008-T02 · Measurement method:** Choose how to observe each “IPC operation table” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C008-T03 · Budget decision:** Select justified resource and input limits for “IPC operation table”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “IPC operation table” cases for “Operation count and dispatch-table size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “IPC operation table” limit; preserve “Guest requests can reach only enumerated host functions”.
- [ ] **UC-M08.01-C008-T06 · Normal measurement:** Run or review the normal “IPC operation table” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C008-T07 · At-limit measurement:** Exercise the “IPC operation table” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C008-T08 · Over-limit measurement:** Exercise the “IPC operation table” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C008-T09 · Uncovered-scope report:** List the “IPC operation table” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C008-T10 · Limit evidence:** Publish the selected “IPC operation table” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for IPC operation table with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C009-T01 · Event inventory:** List the “IPC operation table” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “IPC operation table” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C009-T03 · Failure mapping:** Map each documented “IPC operation table” refusal or error to a diagnostic outcome; include “An unknown operation number invokes an arbitrary handler” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C009-T04 · Emission path:** Add the “IPC operation table” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C009-T05 · Redaction check:** Test “IPC operation table” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C009-T06 · Output budget:** Set and exercise bounded “IPC operation table” message size, rate and retention compatible with “Operation count and dispatch-table size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C009-T07 · Success/refusal fixtures:** Capture “IPC operation table” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “IPC operation table” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C009-T09 · Operator review:** Read the “IPC operation table” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C009-T10 · Diagnostic evidence:** Publish redacted “IPC operation table” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for IPC operation table; label unexecuted checks as untested.

- [ ] **UC-M08.01-C010-T01 · Evidence inventory:** List the “IPC operation table” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C010-T02 · Artifact references:** Record the exact “IPC operation table” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C010-T03 · Fixture references:** Attach the “IPC operation table” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unknown operation number invokes an arbitrary handler” as a distinct evidence case.
- [ ] **UC-M08.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “IPC operation table”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C010-T05 · Environment record:** Record the actual “IPC operation table” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C010-T06 · Expected versus observed:** Pair every “IPC operation table” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C010-T07 · Failure and limit records:** Attach “IPC operation table” change/failure and bounds evidence where required; include uncovered “Operation count and dispatch-table size” and unresolved violations of “Guest requests can reach only enumerated host functions”.
- [ ] **UC-M08.01-C010-T08 · Evidence hygiene:** Check the “IPC operation table” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C010-T09 · Reproduction review:** Have the “IPC operation table” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C010-T10 · Acceptance linkage:** Link the “IPC operation table” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Request buffer contract

**Source delivery:** Specify request buffer address, length, ownership and allowed access direction.

**Source invariant:** Request reads remain inside the granted buffer.

**Source negative case:** A request length exceeds its guest-owned buffer.

**Source bounded quantities:** Request bytes and buffer count.

### UC-M08.01-C011 · Contract

**Original checklist item:** Specify request buffer contract inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C011-T01 · Scope statement:** Draft the operation boundary for “Request buffer contract” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Request buffer contract”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C011-T03 · Output inventory:** List the outputs of “Request buffer contract” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Request buffer contract”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C011-T05 · Prerequisite contract:** Map “Request buffer contract” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Request buffer contract”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C011-T07 · Invariant clause:** Add a normative clause for “Request buffer contract” that preserves “Request reads remain inside the granted buffer”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Request buffer contract”; include the source counterexample “A request length exceeds its guest-owned buffer” and the intended safe disposition.
- [ ] **UC-M08.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Request bytes and buffer count” in the “Request buffer contract” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C011-T10 · Contract review:** Review the “Request buffer contract” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C012 · Delivery

**Original checklist item:** Specify request buffer address, length, ownership and allowed access direction.

- [ ] **UC-M08.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Request buffer contract”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C012-T02 · Change plan:** Break the source delivery for “Request buffer contract” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C012-T03 · Core artifact:** Create the “Request buffer contract” model, schema or inventory that realizes this source instruction: Specify request buffer address, length, ownership and allowed access direction.
- [ ] **UC-M08.01-C012-T04 · Concrete realization:** Populate “Request buffer contract” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Request buffer contract” needed to preserve “Request reads remain inside the granted buffer”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C012-T06 · Dependency connection:** Connect the “Request buffer contract” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C012-T07 · Resource behavior:** Account for “Request bytes and buffer count” in “Request buffer contract”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C012-T08 · Delivery check:** Run the smallest real “Request buffer contract” path and its adverse fixture “A request length exceeds its guest-owned buffer”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C012-T09 · Patch review:** Review the “Request buffer contract” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C012-T10 · Delivery handoff:** Publish the “Request buffer contract” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Request reads remain inside the granted buffer. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Request buffer contract”; copy its required invariant exactly: “Request reads remain inside the granted buffer”.
- [ ] **UC-M08.01-C013-T02 · Observable terms:** Define each term in the “Request buffer contract” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C013-T03 · Precondition set:** List the preconditions under which “Request reads remain inside the granted buffer” must hold for “Request buffer contract”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C013-T04 · Transition coverage:** Map the “Request buffer contract” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Request buffer contract”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C013-T06 · Satisfying fixture:** Create a concrete “Request buffer contract” case that satisfies “Request reads remain inside the granted buffer”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C013-T07 · Violating fixture:** Create the source counterexample “A request length exceeds its guest-owned buffer” for “Request buffer contract”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C013-T08 · Enforcement evidence:** Exercise the “Request buffer contract” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C013-T09 · Regression linkage:** Link the “Request buffer contract” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Request buffer contract” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C014 · Integration

**Original checklist item:** Integrate request buffer contract with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Request buffer contract” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C014-T02 · Field mapping:** Map every “Request buffer contract” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Request buffer contract” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C014-T04 · Ownership agreement:** Specify who owns “Request buffer contract” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C014-T05 · Handoff implementation:** Connect “Request buffer contract” through the mapped seam using the real adapter or explicit specification reference; preserve “Request reads remain inside the granted buffer” across the handoff.
- [ ] **UC-M08.01-C014-T06 · Absent-input case:** Omit one required “Request buffer contract” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C014-T07 · Stale-input case:** Supply an outdated “Request buffer contract” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Request buffer contract” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C014-T09 · Valid integration trace:** Run a valid “Request buffer contract” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C014-T10 · Seam review:** Reconcile the “Request buffer contract” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for request buffer contract; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Request buffer contract” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C015-T02 · Expected-result oracle:** Specify the “Request buffer contract” expected result independently of the implementation output; include the property “Request reads remain inside the granted buffer” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C015-T03 · Fixture material:** Create the concrete “Request buffer contract” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C015-T04 · Target preparation:** Prepare the “Request buffer contract” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C015-T05 · Initial-state record:** Record the initial “Request buffer contract” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C015-T06 · Valid-path execution:** Execute the “Request buffer contract” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C015-T07 · Outcome comparison:** Compare every declared “Request buffer contract” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C015-T08 · State and bounds check:** Inspect the “Request buffer contract” ownership/state effects and actual use of “Request bytes and buffer count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C015-T09 · Repeatability check:** Repeat the same “Request buffer contract” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C015-T10 · Positive evidence:** Attach the “Request buffer contract” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C016 · Negative test

**Original checklist item:** Negative case: A request length exceeds its guest-owned buffer. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Request buffer contract” source counterexample: “A request length exceeds its guest-owned buffer”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Request buffer contract”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C016-T03 · Valid control:** Construct a valid “Request buffer contract” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C016-T04 · Minimal adverse input:** Derive the “Request buffer contract” adverse fixture from the control with the smallest documented change needed to reproduce “A request length exceeds its guest-owned buffer”; retain that change as reproducible data.
- [ ] **UC-M08.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Request buffer contract”; require “Request reads remain inside the granted buffer” and forbid a false-success verdict.
- [ ] **UC-M08.01-C016-T06 · Adverse execution:** Exercise the “Request buffer contract” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C016-T07 · Effect inspection:** Inspect “Request buffer contract” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C016-T08 · Refusal versus failure:** Confirm the “Request buffer contract” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C016-T09 · Reset and retention:** Restore only the disposable “Request buffer contract” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C016-T10 · Negative regression:** Register the “Request buffer contract” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C017 · Change / failure test

**Original checklist item:** Exercise request buffer contract when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C017-T01 · Scenario record:** Write the “Request buffer contract” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “Request reads remain inside the granted buffer”.
- [ ] **UC-M08.01-C017-T02 · Baseline capture:** Create a known-valid “Request buffer contract” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C017-T03 · Injection map:** Locate the “Request buffer contract” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Request buffer contract” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C017-T05 · Controlled trigger:** Introduce the controlled “Request buffer contract” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C017-T06 · Intermediate inspection:** Inspect the “Request buffer contract” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Request buffer contract”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Request buffer contract” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C017-T09 · Repeat and compare:** Repeat the selected “Request buffer contract” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C017-T10 · Failure evidence:** Publish the “Request buffer contract” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for request bytes and buffer count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Request buffer contract”: “Request bytes and buffer count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C018-T02 · Measurement method:** Choose how to observe each “Request buffer contract” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Request buffer contract”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Request buffer contract” cases for “Request bytes and buffer count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Request buffer contract” limit; preserve “Request reads remain inside the granted buffer”.
- [ ] **UC-M08.01-C018-T06 · Normal measurement:** Run or review the normal “Request buffer contract” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C018-T07 · At-limit measurement:** Exercise the “Request buffer contract” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C018-T08 · Over-limit measurement:** Exercise the “Request buffer contract” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C018-T09 · Uncovered-scope report:** List the “Request buffer contract” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C018-T10 · Limit evidence:** Publish the selected “Request buffer contract” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for request buffer contract with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C019-T01 · Event inventory:** List the “Request buffer contract” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Request buffer contract” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C019-T03 · Failure mapping:** Map each documented “Request buffer contract” refusal or error to a diagnostic outcome; include “A request length exceeds its guest-owned buffer” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C019-T04 · Emission path:** Add the “Request buffer contract” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C019-T05 · Redaction check:** Test “Request buffer contract” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C019-T06 · Output budget:** Set and exercise bounded “Request buffer contract” message size, rate and retention compatible with “Request bytes and buffer count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C019-T07 · Success/refusal fixtures:** Capture “Request buffer contract” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Request buffer contract” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C019-T09 · Operator review:** Read the “Request buffer contract” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C019-T10 · Diagnostic evidence:** Publish redacted “Request buffer contract” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for request buffer contract; label unexecuted checks as untested.

- [ ] **UC-M08.01-C020-T01 · Evidence inventory:** List the “Request buffer contract” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C020-T02 · Artifact references:** Record the exact “Request buffer contract” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C020-T03 · Fixture references:** Attach the “Request buffer contract” fixture IDs, input identities and oracle definition; preserve the source counterexample “A request length exceeds its guest-owned buffer” as a distinct evidence case.
- [ ] **UC-M08.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Request buffer contract”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C020-T05 · Environment record:** Record the actual “Request buffer contract” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C020-T06 · Expected versus observed:** Pair every “Request buffer contract” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C020-T07 · Failure and limit records:** Attach “Request buffer contract” change/failure and bounds evidence where required; include uncovered “Request bytes and buffer count” and unresolved violations of “Request reads remain inside the granted buffer”.
- [ ] **UC-M08.01-C020-T08 · Evidence hygiene:** Check the “Request buffer contract” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C020-T09 · Reproduction review:** Have the “Request buffer contract” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C020-T10 · Acceptance linkage:** Link the “Request buffer contract” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Response buffer contract

**Source delivery:** Define response capacity and actual-length reporting separately.

**Source invariant:** Host responses cannot write beyond the guest's granted capacity.

**Source negative case:** A response exceeds the buffer size declared by the guest.

**Source bounded quantities:** Response bytes and outstanding response buffers.

### UC-M08.01-C021 · Contract

**Original checklist item:** Specify response buffer contract inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C021-T01 · Scope statement:** Draft the operation boundary for “Response buffer contract” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Response buffer contract”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C021-T03 · Output inventory:** List the outputs of “Response buffer contract” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Response buffer contract”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C021-T05 · Prerequisite contract:** Map “Response buffer contract” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Response buffer contract”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C021-T07 · Invariant clause:** Add a normative clause for “Response buffer contract” that preserves “Host responses cannot write beyond the guest's granted capacity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Response buffer contract”; include the source counterexample “A response exceeds the buffer size declared by the guest” and the intended safe disposition.
- [ ] **UC-M08.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Response bytes and outstanding response buffers” in the “Response buffer contract” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C021-T10 · Contract review:** Review the “Response buffer contract” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C022 · Delivery

**Original checklist item:** Define response capacity and actual-length reporting separately.

- [ ] **UC-M08.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Response buffer contract”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C022-T02 · Change plan:** Break the source delivery for “Response buffer contract” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C022-T03 · Core artifact:** Create the “Response buffer contract” model, schema or inventory that realizes this source instruction: Define response capacity and actual-length reporting separately.
- [ ] **UC-M08.01-C022-T04 · Concrete realization:** Populate “Response buffer contract” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Response buffer contract” needed to preserve “Host responses cannot write beyond the guest's granted capacity”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C022-T06 · Dependency connection:** Connect the “Response buffer contract” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C022-T07 · Resource behavior:** Account for “Response bytes and outstanding response buffers” in “Response buffer contract”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C022-T08 · Delivery check:** Run the smallest real “Response buffer contract” path and its adverse fixture “A response exceeds the buffer size declared by the guest”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C022-T09 · Patch review:** Review the “Response buffer contract” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C022-T10 · Delivery handoff:** Publish the “Response buffer contract” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Host responses cannot write beyond the guest's granted capacity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Response buffer contract”; copy its required invariant exactly: “Host responses cannot write beyond the guest's granted capacity”.
- [ ] **UC-M08.01-C023-T02 · Observable terms:** Define each term in the “Response buffer contract” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C023-T03 · Precondition set:** List the preconditions under which “Host responses cannot write beyond the guest's granted capacity” must hold for “Response buffer contract”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C023-T04 · Transition coverage:** Map the “Response buffer contract” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Response buffer contract”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C023-T06 · Satisfying fixture:** Create a concrete “Response buffer contract” case that satisfies “Host responses cannot write beyond the guest's granted capacity”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C023-T07 · Violating fixture:** Create the source counterexample “A response exceeds the buffer size declared by the guest” for “Response buffer contract”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C023-T08 · Enforcement evidence:** Exercise the “Response buffer contract” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C023-T09 · Regression linkage:** Link the “Response buffer contract” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Response buffer contract” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C024 · Integration

**Original checklist item:** Integrate response buffer contract with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Response buffer contract” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C024-T02 · Field mapping:** Map every “Response buffer contract” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Response buffer contract” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C024-T04 · Ownership agreement:** Specify who owns “Response buffer contract” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C024-T05 · Handoff implementation:** Connect “Response buffer contract” through the mapped seam using the real adapter or explicit specification reference; preserve “Host responses cannot write beyond the guest's granted capacity” across the handoff.
- [ ] **UC-M08.01-C024-T06 · Absent-input case:** Omit one required “Response buffer contract” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C024-T07 · Stale-input case:** Supply an outdated “Response buffer contract” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Response buffer contract” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C024-T09 · Valid integration trace:** Run a valid “Response buffer contract” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C024-T10 · Seam review:** Reconcile the “Response buffer contract” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for response buffer contract; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Response buffer contract” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C025-T02 · Expected-result oracle:** Specify the “Response buffer contract” expected result independently of the implementation output; include the property “Host responses cannot write beyond the guest's granted capacity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C025-T03 · Fixture material:** Create the concrete “Response buffer contract” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C025-T04 · Target preparation:** Prepare the “Response buffer contract” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C025-T05 · Initial-state record:** Record the initial “Response buffer contract” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C025-T06 · Valid-path execution:** Execute the “Response buffer contract” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C025-T07 · Outcome comparison:** Compare every declared “Response buffer contract” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C025-T08 · State and bounds check:** Inspect the “Response buffer contract” ownership/state effects and actual use of “Response bytes and outstanding response buffers”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C025-T09 · Repeatability check:** Repeat the same “Response buffer contract” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C025-T10 · Positive evidence:** Attach the “Response buffer contract” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C026 · Negative test

**Original checklist item:** Negative case: A response exceeds the buffer size declared by the guest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Response buffer contract” source counterexample: “A response exceeds the buffer size declared by the guest”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Response buffer contract”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C026-T03 · Valid control:** Construct a valid “Response buffer contract” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C026-T04 · Minimal adverse input:** Derive the “Response buffer contract” adverse fixture from the control with the smallest documented change needed to reproduce “A response exceeds the buffer size declared by the guest”; retain that change as reproducible data.
- [ ] **UC-M08.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Response buffer contract”; require “Host responses cannot write beyond the guest's granted capacity” and forbid a false-success verdict.
- [ ] **UC-M08.01-C026-T06 · Adverse execution:** Exercise the “Response buffer contract” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C026-T07 · Effect inspection:** Inspect “Response buffer contract” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C026-T08 · Refusal versus failure:** Confirm the “Response buffer contract” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C026-T09 · Reset and retention:** Restore only the disposable “Response buffer contract” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C026-T10 · Negative regression:** Register the “Response buffer contract” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C027 · Change / failure test

**Original checklist item:** Exercise response buffer contract when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C027-T01 · Scenario record:** Write the “Response buffer contract” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “Host responses cannot write beyond the guest's granted capacity”.
- [ ] **UC-M08.01-C027-T02 · Baseline capture:** Create a known-valid “Response buffer contract” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C027-T03 · Injection map:** Locate the “Response buffer contract” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Response buffer contract” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C027-T05 · Controlled trigger:** Introduce the controlled “Response buffer contract” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C027-T06 · Intermediate inspection:** Inspect the “Response buffer contract” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Response buffer contract”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Response buffer contract” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C027-T09 · Repeat and compare:** Repeat the selected “Response buffer contract” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C027-T10 · Failure evidence:** Publish the “Response buffer contract” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for response bytes and outstanding response buffers; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Response buffer contract”: “Response bytes and outstanding response buffers”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C028-T02 · Measurement method:** Choose how to observe each “Response buffer contract” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Response buffer contract”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Response buffer contract” cases for “Response bytes and outstanding response buffers”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Response buffer contract” limit; preserve “Host responses cannot write beyond the guest's granted capacity”.
- [ ] **UC-M08.01-C028-T06 · Normal measurement:** Run or review the normal “Response buffer contract” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C028-T07 · At-limit measurement:** Exercise the “Response buffer contract” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C028-T08 · Over-limit measurement:** Exercise the “Response buffer contract” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C028-T09 · Uncovered-scope report:** List the “Response buffer contract” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C028-T10 · Limit evidence:** Publish the selected “Response buffer contract” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for response buffer contract with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C029-T01 · Event inventory:** List the “Response buffer contract” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Response buffer contract” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C029-T03 · Failure mapping:** Map each documented “Response buffer contract” refusal or error to a diagnostic outcome; include “A response exceeds the buffer size declared by the guest” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C029-T04 · Emission path:** Add the “Response buffer contract” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C029-T05 · Redaction check:** Test “Response buffer contract” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C029-T06 · Output budget:** Set and exercise bounded “Response buffer contract” message size, rate and retention compatible with “Response bytes and outstanding response buffers”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C029-T07 · Success/refusal fixtures:** Capture “Response buffer contract” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Response buffer contract” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C029-T09 · Operator review:** Read the “Response buffer contract” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C029-T10 · Diagnostic evidence:** Publish redacted “Response buffer contract” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for response buffer contract; label unexecuted checks as untested.

- [ ] **UC-M08.01-C030-T01 · Evidence inventory:** List the “Response buffer contract” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C030-T02 · Artifact references:** Record the exact “Response buffer contract” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C030-T03 · Fixture references:** Attach the “Response buffer contract” fixture IDs, input identities and oracle definition; preserve the source counterexample “A response exceeds the buffer size declared by the guest” as a distinct evidence case.
- [ ] **UC-M08.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Response buffer contract”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C030-T05 · Environment record:** Record the actual “Response buffer contract” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C030-T06 · Expected versus observed:** Pair every “Response buffer contract” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C030-T07 · Failure and limit records:** Attach “Response buffer contract” change/failure and bounds evidence where required; include uncovered “Response bytes and outstanding response buffers” and unresolved violations of “Host responses cannot write beyond the guest's granted capacity”.
- [ ] **UC-M08.01-C030-T08 · Evidence hygiene:** Check the “Response buffer contract” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C030-T09 · Reproduction review:** Have the “Response buffer contract” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C030-T10 · Acceptance linkage:** Link the “Response buffer contract” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Opaque handles

**Source delivery:** Use scoped handles for host resources rather than caller-controlled raw references.

**Source invariant:** A handle cannot access unrelated host resources.

**Source negative case:** A guest submits a guessed handle owned by another instance.

**Source bounded quantities:** Handle count and lookup cost.

### UC-M08.01-C031 · Contract

**Original checklist item:** Specify opaque handles inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C031-T01 · Scope statement:** Draft the operation boundary for “Opaque handles” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Opaque handles”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C031-T03 · Output inventory:** List the outputs of “Opaque handles” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Opaque handles”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C031-T05 · Prerequisite contract:** Map “Opaque handles” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Opaque handles”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C031-T07 · Invariant clause:** Add a normative clause for “Opaque handles” that preserves “A handle cannot access unrelated host resources”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Opaque handles”; include the source counterexample “A guest submits a guessed handle owned by another instance” and the intended safe disposition.
- [ ] **UC-M08.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Handle count and lookup cost” in the “Opaque handles” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C031-T10 · Contract review:** Review the “Opaque handles” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C032 · Delivery

**Original checklist item:** Use scoped handles for host resources rather than caller-controlled raw references.

- [ ] **UC-M08.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Opaque handles”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C032-T02 · Change plan:** Break the source delivery for “Opaque handles” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Opaque handles” that realizes this source instruction: Use scoped handles for host resources rather than caller-controlled raw references.
- [ ] **UC-M08.01-C032-T04 · Concrete realization:** Trace “Opaque handles” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Opaque handles” needed to preserve “A handle cannot access unrelated host resources”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C032-T06 · Dependency connection:** Connect the “Opaque handles” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C032-T07 · Resource behavior:** Account for “Handle count and lookup cost” in “Opaque handles”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C032-T08 · Delivery check:** Run the smallest real “Opaque handles” path and its adverse fixture “A guest submits a guessed handle owned by another instance”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C032-T09 · Patch review:** Review the “Opaque handles” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C032-T10 · Delivery handoff:** Publish the “Opaque handles” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A handle cannot access unrelated host resources. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Opaque handles”; copy its required invariant exactly: “A handle cannot access unrelated host resources”.
- [ ] **UC-M08.01-C033-T02 · Observable terms:** Define each term in the “Opaque handles” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C033-T03 · Precondition set:** List the preconditions under which “A handle cannot access unrelated host resources” must hold for “Opaque handles”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C033-T04 · Transition coverage:** Map the “Opaque handles” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Opaque handles”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C033-T06 · Satisfying fixture:** Create a concrete “Opaque handles” case that satisfies “A handle cannot access unrelated host resources”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C033-T07 · Violating fixture:** Create the source counterexample “A guest submits a guessed handle owned by another instance” for “Opaque handles”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C033-T08 · Enforcement evidence:** Exercise the “Opaque handles” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C033-T09 · Regression linkage:** Link the “Opaque handles” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Opaque handles” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C034 · Integration

**Original checklist item:** Integrate opaque handles with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Opaque handles” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C034-T02 · Field mapping:** Map every “Opaque handles” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Opaque handles” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C034-T04 · Ownership agreement:** Specify who owns “Opaque handles” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C034-T05 · Handoff implementation:** Connect “Opaque handles” through the mapped seam using the real adapter or explicit specification reference; preserve “A handle cannot access unrelated host resources” across the handoff.
- [ ] **UC-M08.01-C034-T06 · Absent-input case:** Omit one required “Opaque handles” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C034-T07 · Stale-input case:** Supply an outdated “Opaque handles” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Opaque handles” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C034-T09 · Valid integration trace:** Run a valid “Opaque handles” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C034-T10 · Seam review:** Reconcile the “Opaque handles” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for opaque handles; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Opaque handles” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C035-T02 · Expected-result oracle:** Specify the “Opaque handles” expected result independently of the implementation output; include the property “A handle cannot access unrelated host resources” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C035-T03 · Fixture material:** Create the concrete “Opaque handles” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C035-T04 · Target preparation:** Prepare the “Opaque handles” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C035-T05 · Initial-state record:** Record the initial “Opaque handles” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C035-T06 · Valid-path execution:** Execute the “Opaque handles” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C035-T07 · Outcome comparison:** Compare every declared “Opaque handles” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C035-T08 · State and bounds check:** Inspect the “Opaque handles” ownership/state effects and actual use of “Handle count and lookup cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C035-T09 · Repeatability check:** Repeat the same “Opaque handles” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C035-T10 · Positive evidence:** Attach the “Opaque handles” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C036 · Negative test

**Original checklist item:** Negative case: A guest submits a guessed handle owned by another instance. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Opaque handles” source counterexample: “A guest submits a guessed handle owned by another instance”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Opaque handles”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C036-T03 · Valid control:** Construct a valid “Opaque handles” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C036-T04 · Minimal adverse input:** Derive the “Opaque handles” adverse fixture from the control with the smallest documented change needed to reproduce “A guest submits a guessed handle owned by another instance”; retain that change as reproducible data.
- [ ] **UC-M08.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Opaque handles”; require “A handle cannot access unrelated host resources” and forbid a false-success verdict.
- [ ] **UC-M08.01-C036-T06 · Adverse execution:** Exercise the “Opaque handles” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C036-T07 · Effect inspection:** Inspect “Opaque handles” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C036-T08 · Refusal versus failure:** Confirm the “Opaque handles” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C036-T09 · Reset and retention:** Restore only the disposable “Opaque handles” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C036-T10 · Negative regression:** Register the “Opaque handles” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C037 · Change / failure test

**Original checklist item:** Exercise opaque handles when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C037-T01 · Scenario record:** Write the “Opaque handles” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “A handle cannot access unrelated host resources”.
- [ ] **UC-M08.01-C037-T02 · Baseline capture:** Create a known-valid “Opaque handles” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C037-T03 · Injection map:** Locate the “Opaque handles” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Opaque handles” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C037-T05 · Controlled trigger:** Introduce the controlled “Opaque handles” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C037-T06 · Intermediate inspection:** Inspect the “Opaque handles” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Opaque handles”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Opaque handles” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C037-T09 · Repeat and compare:** Repeat the selected “Opaque handles” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C037-T10 · Failure evidence:** Publish the “Opaque handles” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for handle count and lookup cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Opaque handles”: “Handle count and lookup cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C038-T02 · Measurement method:** Choose how to observe each “Opaque handles” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Opaque handles”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Opaque handles” cases for “Handle count and lookup cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Opaque handles” limit; preserve “A handle cannot access unrelated host resources”.
- [ ] **UC-M08.01-C038-T06 · Normal measurement:** Run or review the normal “Opaque handles” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C038-T07 · At-limit measurement:** Exercise the “Opaque handles” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C038-T08 · Over-limit measurement:** Exercise the “Opaque handles” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C038-T09 · Uncovered-scope report:** List the “Opaque handles” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C038-T10 · Limit evidence:** Publish the selected “Opaque handles” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for opaque handles with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C039-T01 · Event inventory:** List the “Opaque handles” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Opaque handles” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C039-T03 · Failure mapping:** Map each documented “Opaque handles” refusal or error to a diagnostic outcome; include “A guest submits a guessed handle owned by another instance” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C039-T04 · Emission path:** Add the “Opaque handles” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C039-T05 · Redaction check:** Test “Opaque handles” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C039-T06 · Output budget:** Set and exercise bounded “Opaque handles” message size, rate and retention compatible with “Handle count and lookup cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C039-T07 · Success/refusal fixtures:** Capture “Opaque handles” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Opaque handles” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C039-T09 · Operator review:** Read the “Opaque handles” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C039-T10 · Diagnostic evidence:** Publish redacted “Opaque handles” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for opaque handles; label unexecuted checks as untested.

- [ ] **UC-M08.01-C040-T01 · Evidence inventory:** List the “Opaque handles” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C040-T02 · Artifact references:** Record the exact “Opaque handles” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C040-T03 · Fixture references:** Attach the “Opaque handles” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest submits a guessed handle owned by another instance” as a distinct evidence case.
- [ ] **UC-M08.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Opaque handles”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C040-T05 · Environment record:** Record the actual “Opaque handles” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C040-T06 · Expected versus observed:** Pair every “Opaque handles” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C040-T07 · Failure and limit records:** Attach “Opaque handles” change/failure and bounds evidence where required; include uncovered “Handle count and lookup cost” and unresolved violations of “A handle cannot access unrelated host resources”.
- [ ] **UC-M08.01-C040-T08 · Evidence hygiene:** Check the “Opaque handles” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C040-T09 · Reproduction review:** Have the “Opaque handles” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C040-T10 · Acceptance linkage:** Link the “Opaque handles” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Ownership transitions

**Source delivery:** Document when guest or host owns each request, response and resource reference.

**Source invariant:** A buffer has one valid ownership state during an operation.

**Source negative case:** A guest reuses a buffer while the host still owns it.

**Source bounded quantities:** Concurrent buffers and ownership states.

### UC-M08.01-C041 · Contract

**Original checklist item:** Specify ownership transitions inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C041-T01 · Scope statement:** Draft the operation boundary for “Ownership transitions” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Ownership transitions”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C041-T03 · Output inventory:** List the outputs of “Ownership transitions” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Ownership transitions”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C041-T05 · Prerequisite contract:** Map “Ownership transitions” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Ownership transitions”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C041-T07 · Invariant clause:** Add a normative clause for “Ownership transitions” that preserves “A buffer has one valid ownership state during an operation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Ownership transitions”; include the source counterexample “A guest reuses a buffer while the host still owns it” and the intended safe disposition.
- [ ] **UC-M08.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent buffers and ownership states” in the “Ownership transitions” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C041-T10 · Contract review:** Review the “Ownership transitions” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C042 · Delivery

**Original checklist item:** Document when guest or host owns each request, response and resource reference.

- [ ] **UC-M08.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Ownership transitions”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C042-T02 · Change plan:** Break the source delivery for “Ownership transitions” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C042-T03 · Core artifact:** Create the “Ownership transitions” model, schema or inventory that realizes this source instruction: Document when guest or host owns each request, response and resource reference.
- [ ] **UC-M08.01-C042-T04 · Concrete realization:** Populate “Ownership transitions” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Ownership transitions” needed to preserve “A buffer has one valid ownership state during an operation”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C042-T06 · Dependency connection:** Connect the “Ownership transitions” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C042-T07 · Resource behavior:** Account for “Concurrent buffers and ownership states” in “Ownership transitions”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C042-T08 · Delivery check:** Run the smallest real “Ownership transitions” path and its adverse fixture “A guest reuses a buffer while the host still owns it”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C042-T09 · Patch review:** Review the “Ownership transitions” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C042-T10 · Delivery handoff:** Publish the “Ownership transitions” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A buffer has one valid ownership state during an operation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Ownership transitions”; copy its required invariant exactly: “A buffer has one valid ownership state during an operation”.
- [ ] **UC-M08.01-C043-T02 · Observable terms:** Define each term in the “Ownership transitions” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C043-T03 · Precondition set:** List the preconditions under which “A buffer has one valid ownership state during an operation” must hold for “Ownership transitions”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C043-T04 · Transition coverage:** Map the “Ownership transitions” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Ownership transitions”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C043-T06 · Satisfying fixture:** Create a concrete “Ownership transitions” case that satisfies “A buffer has one valid ownership state during an operation”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C043-T07 · Violating fixture:** Create the source counterexample “A guest reuses a buffer while the host still owns it” for “Ownership transitions”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C043-T08 · Enforcement evidence:** Exercise the “Ownership transitions” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C043-T09 · Regression linkage:** Link the “Ownership transitions” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Ownership transitions” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C044 · Integration

**Original checklist item:** Integrate ownership transitions with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Ownership transitions” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C044-T02 · Field mapping:** Map every “Ownership transitions” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Ownership transitions” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C044-T04 · Ownership agreement:** Specify who owns “Ownership transitions” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C044-T05 · Handoff implementation:** Connect “Ownership transitions” through the mapped seam using the real adapter or explicit specification reference; preserve “A buffer has one valid ownership state during an operation” across the handoff.
- [ ] **UC-M08.01-C044-T06 · Absent-input case:** Omit one required “Ownership transitions” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C044-T07 · Stale-input case:** Supply an outdated “Ownership transitions” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Ownership transitions” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C044-T09 · Valid integration trace:** Run a valid “Ownership transitions” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C044-T10 · Seam review:** Reconcile the “Ownership transitions” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for ownership transitions; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Ownership transitions” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C045-T02 · Expected-result oracle:** Specify the “Ownership transitions” expected result independently of the implementation output; include the property “A buffer has one valid ownership state during an operation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C045-T03 · Fixture material:** Create the concrete “Ownership transitions” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C045-T04 · Target preparation:** Prepare the “Ownership transitions” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C045-T05 · Initial-state record:** Record the initial “Ownership transitions” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C045-T06 · Valid-path execution:** Execute the “Ownership transitions” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C045-T07 · Outcome comparison:** Compare every declared “Ownership transitions” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C045-T08 · State and bounds check:** Inspect the “Ownership transitions” ownership/state effects and actual use of “Concurrent buffers and ownership states”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C045-T09 · Repeatability check:** Repeat the same “Ownership transitions” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C045-T10 · Positive evidence:** Attach the “Ownership transitions” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C046 · Negative test

**Original checklist item:** Negative case: A guest reuses a buffer while the host still owns it. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Ownership transitions” source counterexample: “A guest reuses a buffer while the host still owns it”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Ownership transitions”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C046-T03 · Valid control:** Construct a valid “Ownership transitions” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C046-T04 · Minimal adverse input:** Derive the “Ownership transitions” adverse fixture from the control with the smallest documented change needed to reproduce “A guest reuses a buffer while the host still owns it”; retain that change as reproducible data.
- [ ] **UC-M08.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Ownership transitions”; require “A buffer has one valid ownership state during an operation” and forbid a false-success verdict.
- [ ] **UC-M08.01-C046-T06 · Adverse execution:** Exercise the “Ownership transitions” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C046-T07 · Effect inspection:** Inspect “Ownership transitions” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C046-T08 · Refusal versus failure:** Confirm the “Ownership transitions” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C046-T09 · Reset and retention:** Restore only the disposable “Ownership transitions” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C046-T10 · Negative regression:** Register the “Ownership transitions” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C047 · Change / failure test

**Original checklist item:** Exercise ownership transitions when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C047-T01 · Scenario record:** Write the “Ownership transitions” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “A buffer has one valid ownership state during an operation”.
- [ ] **UC-M08.01-C047-T02 · Baseline capture:** Create a known-valid “Ownership transitions” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C047-T03 · Injection map:** Locate the “Ownership transitions” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Ownership transitions” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C047-T05 · Controlled trigger:** Introduce the controlled “Ownership transitions” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C047-T06 · Intermediate inspection:** Inspect the “Ownership transitions” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Ownership transitions”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Ownership transitions” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C047-T09 · Repeat and compare:** Repeat the selected “Ownership transitions” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C047-T10 · Failure evidence:** Publish the “Ownership transitions” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for concurrent buffers and ownership states; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Ownership transitions”: “Concurrent buffers and ownership states”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C048-T02 · Measurement method:** Choose how to observe each “Ownership transitions” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Ownership transitions”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Ownership transitions” cases for “Concurrent buffers and ownership states”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Ownership transitions” limit; preserve “A buffer has one valid ownership state during an operation”.
- [ ] **UC-M08.01-C048-T06 · Normal measurement:** Run or review the normal “Ownership transitions” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C048-T07 · At-limit measurement:** Exercise the “Ownership transitions” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C048-T08 · Over-limit measurement:** Exercise the “Ownership transitions” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C048-T09 · Uncovered-scope report:** List the “Ownership transitions” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C048-T10 · Limit evidence:** Publish the selected “Ownership transitions” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for ownership transitions with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C049-T01 · Event inventory:** List the “Ownership transitions” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Ownership transitions” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C049-T03 · Failure mapping:** Map each documented “Ownership transitions” refusal or error to a diagnostic outcome; include “A guest reuses a buffer while the host still owns it” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C049-T04 · Emission path:** Add the “Ownership transitions” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C049-T05 · Redaction check:** Test “Ownership transitions” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C049-T06 · Output budget:** Set and exercise bounded “Ownership transitions” message size, rate and retention compatible with “Concurrent buffers and ownership states”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C049-T07 · Success/refusal fixtures:** Capture “Ownership transitions” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Ownership transitions” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C049-T09 · Operator review:** Read the “Ownership transitions” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C049-T10 · Diagnostic evidence:** Publish redacted “Ownership transitions” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for ownership transitions; label unexecuted checks as untested.

- [ ] **UC-M08.01-C050-T01 · Evidence inventory:** List the “Ownership transitions” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C050-T02 · Artifact references:** Record the exact “Ownership transitions” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C050-T03 · Fixture references:** Attach the “Ownership transitions” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest reuses a buffer while the host still owns it” as a distinct evidence case.
- [ ] **UC-M08.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Ownership transitions”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C050-T05 · Environment record:** Record the actual “Ownership transitions” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C050-T06 · Expected versus observed:** Pair every “Ownership transitions” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C050-T07 · Failure and limit records:** Attach “Ownership transitions” change/failure and bounds evidence where required; include uncovered “Concurrent buffers and ownership states” and unresolved violations of “A buffer has one valid ownership state during an operation”.
- [ ] **UC-M08.01-C050-T08 · Evidence hygiene:** Check the “Ownership transitions” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C050-T09 · Reproduction review:** Have the “Ownership transitions” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C050-T10 · Acceptance linkage:** Link the “Ownership transitions” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Error vocabulary

**Source delivery:** Define stable IPC errors for invalid operations, handles and buffer bounds.

**Source invariant:** Boundary violations return explicit errors without arbitrary side effects.

**Source negative case:** An invalid handle is treated as a default privileged resource.

**Source bounded quantities:** Error count and diagnostic bytes.

### UC-M08.01-C051 · Contract

**Original checklist item:** Specify error vocabulary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C051-T01 · Scope statement:** Draft the operation boundary for “Error vocabulary” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Error vocabulary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C051-T03 · Output inventory:** List the outputs of “Error vocabulary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Error vocabulary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C051-T05 · Prerequisite contract:** Map “Error vocabulary” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Error vocabulary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C051-T07 · Invariant clause:** Add a normative clause for “Error vocabulary” that preserves “Boundary violations return explicit errors without arbitrary side effects”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Error vocabulary”; include the source counterexample “An invalid handle is treated as a default privileged resource” and the intended safe disposition.
- [ ] **UC-M08.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Error count and diagnostic bytes” in the “Error vocabulary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C051-T10 · Contract review:** Review the “Error vocabulary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C052 · Delivery

**Original checklist item:** Define stable IPC errors for invalid operations, handles and buffer bounds.

- [ ] **UC-M08.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Error vocabulary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C052-T02 · Change plan:** Break the source delivery for “Error vocabulary” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C052-T03 · Core artifact:** Create the “Error vocabulary” model, schema or inventory that realizes this source instruction: Define stable IPC errors for invalid operations, handles and buffer bounds.
- [ ] **UC-M08.01-C052-T04 · Concrete realization:** Populate “Error vocabulary” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Error vocabulary” needed to preserve “Boundary violations return explicit errors without arbitrary side effects”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C052-T06 · Dependency connection:** Connect the “Error vocabulary” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C052-T07 · Resource behavior:** Account for “Error count and diagnostic bytes” in “Error vocabulary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C052-T08 · Delivery check:** Run the smallest real “Error vocabulary” path and its adverse fixture “An invalid handle is treated as a default privileged resource”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C052-T09 · Patch review:** Review the “Error vocabulary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C052-T10 · Delivery handoff:** Publish the “Error vocabulary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Boundary violations return explicit errors without arbitrary side effects. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Error vocabulary”; copy its required invariant exactly: “Boundary violations return explicit errors without arbitrary side effects”.
- [ ] **UC-M08.01-C053-T02 · Observable terms:** Define each term in the “Error vocabulary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C053-T03 · Precondition set:** List the preconditions under which “Boundary violations return explicit errors without arbitrary side effects” must hold for “Error vocabulary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C053-T04 · Transition coverage:** Map the “Error vocabulary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Error vocabulary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C053-T06 · Satisfying fixture:** Create a concrete “Error vocabulary” case that satisfies “Boundary violations return explicit errors without arbitrary side effects”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C053-T07 · Violating fixture:** Create the source counterexample “An invalid handle is treated as a default privileged resource” for “Error vocabulary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C053-T08 · Enforcement evidence:** Exercise the “Error vocabulary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C053-T09 · Regression linkage:** Link the “Error vocabulary” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Error vocabulary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C054 · Integration

**Original checklist item:** Integrate error vocabulary with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Error vocabulary” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C054-T02 · Field mapping:** Map every “Error vocabulary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Error vocabulary” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C054-T04 · Ownership agreement:** Specify who owns “Error vocabulary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C054-T05 · Handoff implementation:** Connect “Error vocabulary” through the mapped seam using the real adapter or explicit specification reference; preserve “Boundary violations return explicit errors without arbitrary side effects” across the handoff.
- [ ] **UC-M08.01-C054-T06 · Absent-input case:** Omit one required “Error vocabulary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C054-T07 · Stale-input case:** Supply an outdated “Error vocabulary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Error vocabulary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C054-T09 · Valid integration trace:** Run a valid “Error vocabulary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C054-T10 · Seam review:** Reconcile the “Error vocabulary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for error vocabulary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Error vocabulary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C055-T02 · Expected-result oracle:** Specify the “Error vocabulary” expected result independently of the implementation output; include the property “Boundary violations return explicit errors without arbitrary side effects” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C055-T03 · Fixture material:** Create the concrete “Error vocabulary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C055-T04 · Target preparation:** Prepare the “Error vocabulary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C055-T05 · Initial-state record:** Record the initial “Error vocabulary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C055-T06 · Valid-path execution:** Execute the “Error vocabulary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C055-T07 · Outcome comparison:** Compare every declared “Error vocabulary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C055-T08 · State and bounds check:** Inspect the “Error vocabulary” ownership/state effects and actual use of “Error count and diagnostic bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C055-T09 · Repeatability check:** Repeat the same “Error vocabulary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C055-T10 · Positive evidence:** Attach the “Error vocabulary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C056 · Negative test

**Original checklist item:** Negative case: An invalid handle is treated as a default privileged resource. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Error vocabulary” source counterexample: “An invalid handle is treated as a default privileged resource”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Error vocabulary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C056-T03 · Valid control:** Construct a valid “Error vocabulary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C056-T04 · Minimal adverse input:** Derive the “Error vocabulary” adverse fixture from the control with the smallest documented change needed to reproduce “An invalid handle is treated as a default privileged resource”; retain that change as reproducible data.
- [ ] **UC-M08.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Error vocabulary”; require “Boundary violations return explicit errors without arbitrary side effects” and forbid a false-success verdict.
- [ ] **UC-M08.01-C056-T06 · Adverse execution:** Exercise the “Error vocabulary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C056-T07 · Effect inspection:** Inspect “Error vocabulary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C056-T08 · Refusal versus failure:** Confirm the “Error vocabulary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C056-T09 · Reset and retention:** Restore only the disposable “Error vocabulary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C056-T10 · Negative regression:** Register the “Error vocabulary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C057 · Change / failure test

**Original checklist item:** Exercise error vocabulary when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C057-T01 · Scenario record:** Write the “Error vocabulary” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “Boundary violations return explicit errors without arbitrary side effects”.
- [ ] **UC-M08.01-C057-T02 · Baseline capture:** Create a known-valid “Error vocabulary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C057-T03 · Injection map:** Locate the “Error vocabulary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Error vocabulary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C057-T05 · Controlled trigger:** Introduce the controlled “Error vocabulary” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C057-T06 · Intermediate inspection:** Inspect the “Error vocabulary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Error vocabulary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Error vocabulary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C057-T09 · Repeat and compare:** Repeat the selected “Error vocabulary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C057-T10 · Failure evidence:** Publish the “Error vocabulary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for error count and diagnostic bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Error vocabulary”: “Error count and diagnostic bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C058-T02 · Measurement method:** Choose how to observe each “Error vocabulary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Error vocabulary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Error vocabulary” cases for “Error count and diagnostic bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Error vocabulary” limit; preserve “Boundary violations return explicit errors without arbitrary side effects”.
- [ ] **UC-M08.01-C058-T06 · Normal measurement:** Run or review the normal “Error vocabulary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C058-T07 · At-limit measurement:** Exercise the “Error vocabulary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C058-T08 · Over-limit measurement:** Exercise the “Error vocabulary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C058-T09 · Uncovered-scope report:** List the “Error vocabulary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C058-T10 · Limit evidence:** Publish the selected “Error vocabulary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for error vocabulary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C059-T01 · Event inventory:** List the “Error vocabulary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Error vocabulary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C059-T03 · Failure mapping:** Map each documented “Error vocabulary” refusal or error to a diagnostic outcome; include “An invalid handle is treated as a default privileged resource” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C059-T04 · Emission path:** Add the “Error vocabulary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C059-T05 · Redaction check:** Test “Error vocabulary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C059-T06 · Output budget:** Set and exercise bounded “Error vocabulary” message size, rate and retention compatible with “Error count and diagnostic bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C059-T07 · Success/refusal fixtures:** Capture “Error vocabulary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Error vocabulary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C059-T09 · Operator review:** Read the “Error vocabulary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C059-T10 · Diagnostic evidence:** Publish redacted “Error vocabulary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for error vocabulary; label unexecuted checks as untested.

- [ ] **UC-M08.01-C060-T01 · Evidence inventory:** List the “Error vocabulary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C060-T02 · Artifact references:** Record the exact “Error vocabulary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C060-T03 · Fixture references:** Attach the “Error vocabulary” fixture IDs, input identities and oracle definition; preserve the source counterexample “An invalid handle is treated as a default privileged resource” as a distinct evidence case.
- [ ] **UC-M08.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Error vocabulary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C060-T05 · Environment record:** Record the actual “Error vocabulary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C060-T06 · Expected versus observed:** Pair every “Error vocabulary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C060-T07 · Failure and limit records:** Attach “Error vocabulary” change/failure and bounds evidence where required; include uncovered “Error count and diagnostic bytes” and unresolved violations of “Boundary violations return explicit errors without arbitrary side effects”.
- [ ] **UC-M08.01-C060-T08 · Evidence hygiene:** Check the “Error vocabulary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C060-T09 · Reproduction review:** Have the “Error vocabulary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C060-T10 · Acceptance linkage:** Link the “Error vocabulary” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Local transport profile

**Source delivery:** Choose a bounded local transport for the first guest-host interface.

**Source invariant:** IPC support does not implicitly enable external networking.

**Source negative case:** Enabling guest-host messaging opens an unsolicited network listener.

**Source bounded quantities:** Channels and local endpoints.

### UC-M08.01-C061 · Contract

**Original checklist item:** Specify local transport profile inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C061-T01 · Scope statement:** Draft the operation boundary for “Local transport profile” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Local transport profile”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C061-T03 · Output inventory:** List the outputs of “Local transport profile” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Local transport profile”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C061-T05 · Prerequisite contract:** Map “Local transport profile” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Local transport profile”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C061-T07 · Invariant clause:** Add a normative clause for “Local transport profile” that preserves “IPC support does not implicitly enable external networking”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Local transport profile”; include the source counterexample “Enabling guest-host messaging opens an unsolicited network listener” and the intended safe disposition.
- [ ] **UC-M08.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Channels and local endpoints” in the “Local transport profile” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C061-T10 · Contract review:** Review the “Local transport profile” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C062 · Delivery

**Original checklist item:** Choose a bounded local transport for the first guest-host interface.

- [ ] **UC-M08.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Local transport profile”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C062-T02 · Change plan:** Break the source delivery for “Local transport profile” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C062-T03 · Core artifact:** Prepare the “Local transport profile” decision record for this source instruction: Choose a bounded local transport for the first guest-host interface.
- [ ] **UC-M08.01-C062-T04 · Concrete realization:** Evaluate the “Local transport profile” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M08.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Local transport profile” needed to preserve “IPC support does not implicitly enable external networking”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C062-T06 · Dependency connection:** Connect the “Local transport profile” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C062-T07 · Resource behavior:** Account for “Channels and local endpoints” in “Local transport profile”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C062-T08 · Delivery check:** Run the smallest real “Local transport profile” path and its adverse fixture “Enabling guest-host messaging opens an unsolicited network listener”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C062-T09 · Patch review:** Review the “Local transport profile” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C062-T10 · Delivery handoff:** Publish the “Local transport profile” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: IPC support does not implicitly enable external networking. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Local transport profile”; copy its required invariant exactly: “IPC support does not implicitly enable external networking”.
- [ ] **UC-M08.01-C063-T02 · Observable terms:** Define each term in the “Local transport profile” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C063-T03 · Precondition set:** List the preconditions under which “IPC support does not implicitly enable external networking” must hold for “Local transport profile”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C063-T04 · Transition coverage:** Map the “Local transport profile” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Local transport profile”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C063-T06 · Satisfying fixture:** Create a concrete “Local transport profile” case that satisfies “IPC support does not implicitly enable external networking”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C063-T07 · Violating fixture:** Create the source counterexample “Enabling guest-host messaging opens an unsolicited network listener” for “Local transport profile”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C063-T08 · Enforcement evidence:** Exercise the “Local transport profile” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C063-T09 · Regression linkage:** Link the “Local transport profile” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Local transport profile” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C064 · Integration

**Original checklist item:** Integrate local transport profile with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Local transport profile” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C064-T02 · Field mapping:** Map every “Local transport profile” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Local transport profile” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C064-T04 · Ownership agreement:** Specify who owns “Local transport profile” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C064-T05 · Handoff implementation:** Connect “Local transport profile” through the mapped seam using the real adapter or explicit specification reference; preserve “IPC support does not implicitly enable external networking” across the handoff.
- [ ] **UC-M08.01-C064-T06 · Absent-input case:** Omit one required “Local transport profile” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C064-T07 · Stale-input case:** Supply an outdated “Local transport profile” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Local transport profile” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C064-T09 · Valid integration trace:** Run a valid “Local transport profile” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C064-T10 · Seam review:** Reconcile the “Local transport profile” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for local transport profile; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Local transport profile” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C065-T02 · Expected-result oracle:** Specify the “Local transport profile” expected result independently of the implementation output; include the property “IPC support does not implicitly enable external networking” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C065-T03 · Fixture material:** Create the concrete “Local transport profile” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C065-T04 · Target preparation:** Prepare the “Local transport profile” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C065-T05 · Initial-state record:** Record the initial “Local transport profile” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C065-T06 · Valid-path execution:** Execute the “Local transport profile” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C065-T07 · Outcome comparison:** Compare every declared “Local transport profile” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C065-T08 · State and bounds check:** Inspect the “Local transport profile” ownership/state effects and actual use of “Channels and local endpoints”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C065-T09 · Repeatability check:** Repeat the same “Local transport profile” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C065-T10 · Positive evidence:** Attach the “Local transport profile” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C066 · Negative test

**Original checklist item:** Negative case: Enabling guest-host messaging opens an unsolicited network listener. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Local transport profile” source counterexample: “Enabling guest-host messaging opens an unsolicited network listener”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Local transport profile”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C066-T03 · Valid control:** Construct a valid “Local transport profile” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C066-T04 · Minimal adverse input:** Derive the “Local transport profile” adverse fixture from the control with the smallest documented change needed to reproduce “Enabling guest-host messaging opens an unsolicited network listener”; retain that change as reproducible data.
- [ ] **UC-M08.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Local transport profile”; require “IPC support does not implicitly enable external networking” and forbid a false-success verdict.
- [ ] **UC-M08.01-C066-T06 · Adverse execution:** Exercise the “Local transport profile” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C066-T07 · Effect inspection:** Inspect “Local transport profile” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C066-T08 · Refusal versus failure:** Confirm the “Local transport profile” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C066-T09 · Reset and retention:** Restore only the disposable “Local transport profile” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C066-T10 · Negative regression:** Register the “Local transport profile” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C067 · Change / failure test

**Original checklist item:** Exercise local transport profile when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C067-T01 · Scenario record:** Write the “Local transport profile” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “IPC support does not implicitly enable external networking”.
- [ ] **UC-M08.01-C067-T02 · Baseline capture:** Create a known-valid “Local transport profile” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C067-T03 · Injection map:** Locate the “Local transport profile” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Local transport profile” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C067-T05 · Controlled trigger:** Introduce the controlled “Local transport profile” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C067-T06 · Intermediate inspection:** Inspect the “Local transport profile” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Local transport profile”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Local transport profile” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C067-T09 · Repeat and compare:** Repeat the selected “Local transport profile” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C067-T10 · Failure evidence:** Publish the “Local transport profile” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for channels and local endpoints; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Local transport profile”: “Channels and local endpoints”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C068-T02 · Measurement method:** Choose how to observe each “Local transport profile” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Local transport profile”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Local transport profile” cases for “Channels and local endpoints”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Local transport profile” limit; preserve “IPC support does not implicitly enable external networking”.
- [ ] **UC-M08.01-C068-T06 · Normal measurement:** Run or review the normal “Local transport profile” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C068-T07 · At-limit measurement:** Exercise the “Local transport profile” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C068-T08 · Over-limit measurement:** Exercise the “Local transport profile” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C068-T09 · Uncovered-scope report:** List the “Local transport profile” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C068-T10 · Limit evidence:** Publish the selected “Local transport profile” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for local transport profile with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C069-T01 · Event inventory:** List the “Local transport profile” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Local transport profile” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C069-T03 · Failure mapping:** Map each documented “Local transport profile” refusal or error to a diagnostic outcome; include “Enabling guest-host messaging opens an unsolicited network listener” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C069-T04 · Emission path:** Add the “Local transport profile” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C069-T05 · Redaction check:** Test “Local transport profile” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C069-T06 · Output budget:** Set and exercise bounded “Local transport profile” message size, rate and retention compatible with “Channels and local endpoints”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C069-T07 · Success/refusal fixtures:** Capture “Local transport profile” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Local transport profile” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C069-T09 · Operator review:** Read the “Local transport profile” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C069-T10 · Diagnostic evidence:** Publish redacted “Local transport profile” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for local transport profile; label unexecuted checks as untested.

- [ ] **UC-M08.01-C070-T01 · Evidence inventory:** List the “Local transport profile” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C070-T02 · Artifact references:** Record the exact “Local transport profile” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C070-T03 · Fixture references:** Attach the “Local transport profile” fixture IDs, input identities and oracle definition; preserve the source counterexample “Enabling guest-host messaging opens an unsolicited network listener” as a distinct evidence case.
- [ ] **UC-M08.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Local transport profile”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C070-T05 · Environment record:** Record the actual “Local transport profile” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C070-T06 · Expected versus observed:** Pair every “Local transport profile” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C070-T07 · Failure and limit records:** Attach “Local transport profile” change/failure and bounds evidence where required; include uncovered “Channels and local endpoints” and unresolved violations of “IPC support does not implicitly enable external networking”.
- [ ] **UC-M08.01-C070-T08 · Evidence hygiene:** Check the “Local transport profile” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C070-T09 · Reproduction review:** Have the “Local transport profile” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C070-T10 · Acceptance linkage:** Link the “Local transport profile” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Broker routing

**Source delivery:** Route privileged IPC operations through the narrow authorized broker interface.

**Source invariant:** A guest cannot bypass broker authorization through an IPC shortcut.

**Source negative case:** A guest requests direct host filesystem access through a generic IPC call.

**Source bounded quantities:** Broker operations and request rate.

### UC-M08.01-C071 · Contract

**Original checklist item:** Specify broker routing inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C071-T01 · Scope statement:** Draft the operation boundary for “Broker routing” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Broker routing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C071-T03 · Output inventory:** List the outputs of “Broker routing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Broker routing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C071-T05 · Prerequisite contract:** Map “Broker routing” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Broker routing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C071-T07 · Invariant clause:** Add a normative clause for “Broker routing” that preserves “A guest cannot bypass broker authorization through an IPC shortcut”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Broker routing”; include the source counterexample “A guest requests direct host filesystem access through a generic IPC call” and the intended safe disposition.
- [ ] **UC-M08.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Broker operations and request rate” in the “Broker routing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C071-T10 · Contract review:** Review the “Broker routing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C072 · Delivery

**Original checklist item:** Route privileged IPC operations through the narrow authorized broker interface.

- [ ] **UC-M08.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Broker routing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C072-T02 · Change plan:** Break the source delivery for “Broker routing” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Broker routing” that realizes this source instruction: Route privileged IPC operations through the narrow authorized broker interface.
- [ ] **UC-M08.01-C072-T04 · Concrete realization:** Trace “Broker routing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Broker routing” needed to preserve “A guest cannot bypass broker authorization through an IPC shortcut”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C072-T06 · Dependency connection:** Connect the “Broker routing” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C072-T07 · Resource behavior:** Account for “Broker operations and request rate” in “Broker routing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C072-T08 · Delivery check:** Run the smallest real “Broker routing” path and its adverse fixture “A guest requests direct host filesystem access through a generic IPC call”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C072-T09 · Patch review:** Review the “Broker routing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C072-T10 · Delivery handoff:** Publish the “Broker routing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A guest cannot bypass broker authorization through an IPC shortcut. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Broker routing”; copy its required invariant exactly: “A guest cannot bypass broker authorization through an IPC shortcut”.
- [ ] **UC-M08.01-C073-T02 · Observable terms:** Define each term in the “Broker routing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C073-T03 · Precondition set:** List the preconditions under which “A guest cannot bypass broker authorization through an IPC shortcut” must hold for “Broker routing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C073-T04 · Transition coverage:** Map the “Broker routing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Broker routing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C073-T06 · Satisfying fixture:** Create a concrete “Broker routing” case that satisfies “A guest cannot bypass broker authorization through an IPC shortcut”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C073-T07 · Violating fixture:** Create the source counterexample “A guest requests direct host filesystem access through a generic IPC call” for “Broker routing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C073-T08 · Enforcement evidence:** Exercise the “Broker routing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C073-T09 · Regression linkage:** Link the “Broker routing” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Broker routing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C074 · Integration

**Original checklist item:** Integrate broker routing with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Broker routing” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C074-T02 · Field mapping:** Map every “Broker routing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Broker routing” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C074-T04 · Ownership agreement:** Specify who owns “Broker routing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C074-T05 · Handoff implementation:** Connect “Broker routing” through the mapped seam using the real adapter or explicit specification reference; preserve “A guest cannot bypass broker authorization through an IPC shortcut” across the handoff.
- [ ] **UC-M08.01-C074-T06 · Absent-input case:** Omit one required “Broker routing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C074-T07 · Stale-input case:** Supply an outdated “Broker routing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Broker routing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C074-T09 · Valid integration trace:** Run a valid “Broker routing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C074-T10 · Seam review:** Reconcile the “Broker routing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for broker routing; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Broker routing” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C075-T02 · Expected-result oracle:** Specify the “Broker routing” expected result independently of the implementation output; include the property “A guest cannot bypass broker authorization through an IPC shortcut” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C075-T03 · Fixture material:** Create the concrete “Broker routing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C075-T04 · Target preparation:** Prepare the “Broker routing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C075-T05 · Initial-state record:** Record the initial “Broker routing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C075-T06 · Valid-path execution:** Execute the “Broker routing” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C075-T07 · Outcome comparison:** Compare every declared “Broker routing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C075-T08 · State and bounds check:** Inspect the “Broker routing” ownership/state effects and actual use of “Broker operations and request rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C075-T09 · Repeatability check:** Repeat the same “Broker routing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C075-T10 · Positive evidence:** Attach the “Broker routing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C076 · Negative test

**Original checklist item:** Negative case: A guest requests direct host filesystem access through a generic IPC call. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Broker routing” source counterexample: “A guest requests direct host filesystem access through a generic IPC call”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Broker routing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C076-T03 · Valid control:** Construct a valid “Broker routing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C076-T04 · Minimal adverse input:** Derive the “Broker routing” adverse fixture from the control with the smallest documented change needed to reproduce “A guest requests direct host filesystem access through a generic IPC call”; retain that change as reproducible data.
- [ ] **UC-M08.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Broker routing”; require “A guest cannot bypass broker authorization through an IPC shortcut” and forbid a false-success verdict.
- [ ] **UC-M08.01-C076-T06 · Adverse execution:** Exercise the “Broker routing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C076-T07 · Effect inspection:** Inspect “Broker routing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C076-T08 · Refusal versus failure:** Confirm the “Broker routing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C076-T09 · Reset and retention:** Restore only the disposable “Broker routing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C076-T10 · Negative regression:** Register the “Broker routing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C077 · Change / failure test

**Original checklist item:** Exercise broker routing when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C077-T01 · Scenario record:** Write the “Broker routing” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “A guest cannot bypass broker authorization through an IPC shortcut”.
- [ ] **UC-M08.01-C077-T02 · Baseline capture:** Create a known-valid “Broker routing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C077-T03 · Injection map:** Locate the “Broker routing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Broker routing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C077-T05 · Controlled trigger:** Introduce the controlled “Broker routing” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C077-T06 · Intermediate inspection:** Inspect the “Broker routing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Broker routing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Broker routing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C077-T09 · Repeat and compare:** Repeat the selected “Broker routing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C077-T10 · Failure evidence:** Publish the “Broker routing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for broker operations and request rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Broker routing”: “Broker operations and request rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C078-T02 · Measurement method:** Choose how to observe each “Broker routing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Broker routing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Broker routing” cases for “Broker operations and request rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Broker routing” limit; preserve “A guest cannot bypass broker authorization through an IPC shortcut”.
- [ ] **UC-M08.01-C078-T06 · Normal measurement:** Run or review the normal “Broker routing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C078-T07 · At-limit measurement:** Exercise the “Broker routing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C078-T08 · Over-limit measurement:** Exercise the “Broker routing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C078-T09 · Uncovered-scope report:** List the “Broker routing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C078-T10 · Limit evidence:** Publish the selected “Broker routing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for broker routing with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C079-T01 · Event inventory:** List the “Broker routing” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Broker routing” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C079-T03 · Failure mapping:** Map each documented “Broker routing” refusal or error to a diagnostic outcome; include “A guest requests direct host filesystem access through a generic IPC call” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C079-T04 · Emission path:** Add the “Broker routing” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C079-T05 · Redaction check:** Test “Broker routing” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C079-T06 · Output budget:** Set and exercise bounded “Broker routing” message size, rate and retention compatible with “Broker operations and request rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C079-T07 · Success/refusal fixtures:** Capture “Broker routing” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Broker routing” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C079-T09 · Operator review:** Read the “Broker routing” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C079-T10 · Diagnostic evidence:** Publish redacted “Broker routing” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for broker routing; label unexecuted checks as untested.

- [ ] **UC-M08.01-C080-T01 · Evidence inventory:** List the “Broker routing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C080-T02 · Artifact references:** Record the exact “Broker routing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C080-T03 · Fixture references:** Attach the “Broker routing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest requests direct host filesystem access through a generic IPC call” as a distinct evidence case.
- [ ] **UC-M08.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Broker routing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C080-T05 · Environment record:** Record the actual “Broker routing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C080-T06 · Expected versus observed:** Pair every “Broker routing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C080-T07 · Failure and limit records:** Attach “Broker routing” change/failure and bounds evidence where required; include uncovered “Broker operations and request rate” and unresolved violations of “A guest cannot bypass broker authorization through an IPC shortcut”.
- [ ] **UC-M08.01-C080-T08 · Evidence hygiene:** Check the “Broker routing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C080-T09 · Reproduction review:** Have the “Broker routing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C080-T10 · Acceptance linkage:** Link the “Broker routing” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Generation binding

**Source delivery:** Bind channel and handle authority to tenant and workload generation.

**Source invariant:** A replaced guest cannot continue using its former IPC authority.

**Source negative case:** A stale channel sends requests after workload replacement.

**Source bounded quantities:** Channel lifetime and retired handle count.

### UC-M08.01-C081 · Contract

**Original checklist item:** Specify generation binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C081-T01 · Scope statement:** Draft the operation boundary for “Generation binding” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Generation binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C081-T03 · Output inventory:** List the outputs of “Generation binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Generation binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C081-T05 · Prerequisite contract:** Map “Generation binding” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Generation binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C081-T07 · Invariant clause:** Add a normative clause for “Generation binding” that preserves “A replaced guest cannot continue using its former IPC authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Generation binding”; include the source counterexample “A stale channel sends requests after workload replacement” and the intended safe disposition.
- [ ] **UC-M08.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Channel lifetime and retired handle count” in the “Generation binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C081-T10 · Contract review:** Review the “Generation binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C082 · Delivery

**Original checklist item:** Bind channel and handle authority to tenant and workload generation.

- [ ] **UC-M08.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Generation binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C082-T02 · Change plan:** Break the source delivery for “Generation binding” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Generation binding” that realizes this source instruction: Bind channel and handle authority to tenant and workload generation.
- [ ] **UC-M08.01-C082-T04 · Concrete realization:** Trace “Generation binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Generation binding” needed to preserve “A replaced guest cannot continue using its former IPC authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C082-T06 · Dependency connection:** Connect the “Generation binding” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C082-T07 · Resource behavior:** Account for “Channel lifetime and retired handle count” in “Generation binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C082-T08 · Delivery check:** Run the smallest real “Generation binding” path and its adverse fixture “A stale channel sends requests after workload replacement”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C082-T09 · Patch review:** Review the “Generation binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C082-T10 · Delivery handoff:** Publish the “Generation binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A replaced guest cannot continue using its former IPC authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Generation binding”; copy its required invariant exactly: “A replaced guest cannot continue using its former IPC authority”.
- [ ] **UC-M08.01-C083-T02 · Observable terms:** Define each term in the “Generation binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C083-T03 · Precondition set:** List the preconditions under which “A replaced guest cannot continue using its former IPC authority” must hold for “Generation binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C083-T04 · Transition coverage:** Map the “Generation binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Generation binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C083-T06 · Satisfying fixture:** Create a concrete “Generation binding” case that satisfies “A replaced guest cannot continue using its former IPC authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C083-T07 · Violating fixture:** Create the source counterexample “A stale channel sends requests after workload replacement” for “Generation binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C083-T08 · Enforcement evidence:** Exercise the “Generation binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C083-T09 · Regression linkage:** Link the “Generation binding” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Generation binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C084 · Integration

**Original checklist item:** Integrate generation binding with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Generation binding” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C084-T02 · Field mapping:** Map every “Generation binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Generation binding” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C084-T04 · Ownership agreement:** Specify who owns “Generation binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C084-T05 · Handoff implementation:** Connect “Generation binding” through the mapped seam using the real adapter or explicit specification reference; preserve “A replaced guest cannot continue using its former IPC authority” across the handoff.
- [ ] **UC-M08.01-C084-T06 · Absent-input case:** Omit one required “Generation binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C084-T07 · Stale-input case:** Supply an outdated “Generation binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Generation binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C084-T09 · Valid integration trace:** Run a valid “Generation binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C084-T10 · Seam review:** Reconcile the “Generation binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for generation binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Generation binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C085-T02 · Expected-result oracle:** Specify the “Generation binding” expected result independently of the implementation output; include the property “A replaced guest cannot continue using its former IPC authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C085-T03 · Fixture material:** Create the concrete “Generation binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C085-T04 · Target preparation:** Prepare the “Generation binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C085-T05 · Initial-state record:** Record the initial “Generation binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C085-T06 · Valid-path execution:** Execute the “Generation binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C085-T07 · Outcome comparison:** Compare every declared “Generation binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C085-T08 · State and bounds check:** Inspect the “Generation binding” ownership/state effects and actual use of “Channel lifetime and retired handle count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C085-T09 · Repeatability check:** Repeat the same “Generation binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C085-T10 · Positive evidence:** Attach the “Generation binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C086 · Negative test

**Original checklist item:** Negative case: A stale channel sends requests after workload replacement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Generation binding” source counterexample: “A stale channel sends requests after workload replacement”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Generation binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C086-T03 · Valid control:** Construct a valid “Generation binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C086-T04 · Minimal adverse input:** Derive the “Generation binding” adverse fixture from the control with the smallest documented change needed to reproduce “A stale channel sends requests after workload replacement”; retain that change as reproducible data.
- [ ] **UC-M08.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Generation binding”; require “A replaced guest cannot continue using its former IPC authority” and forbid a false-success verdict.
- [ ] **UC-M08.01-C086-T06 · Adverse execution:** Exercise the “Generation binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C086-T07 · Effect inspection:** Inspect “Generation binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C086-T08 · Refusal versus failure:** Confirm the “Generation binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C086-T09 · Reset and retention:** Restore only the disposable “Generation binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C086-T10 · Negative regression:** Register the “Generation binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C087 · Change / failure test

**Original checklist item:** Exercise generation binding when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C087-T01 · Scenario record:** Write the “Generation binding” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “A replaced guest cannot continue using its former IPC authority”.
- [ ] **UC-M08.01-C087-T02 · Baseline capture:** Create a known-valid “Generation binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C087-T03 · Injection map:** Locate the “Generation binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Generation binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C087-T05 · Controlled trigger:** Introduce the controlled “Generation binding” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C087-T06 · Intermediate inspection:** Inspect the “Generation binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Generation binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Generation binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C087-T09 · Repeat and compare:** Repeat the selected “Generation binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C087-T10 · Failure evidence:** Publish the “Generation binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for channel lifetime and retired handle count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Generation binding”: “Channel lifetime and retired handle count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C088-T02 · Measurement method:** Choose how to observe each “Generation binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Generation binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Generation binding” cases for “Channel lifetime and retired handle count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Generation binding” limit; preserve “A replaced guest cannot continue using its former IPC authority”.
- [ ] **UC-M08.01-C088-T06 · Normal measurement:** Run or review the normal “Generation binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C088-T07 · At-limit measurement:** Exercise the “Generation binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C088-T08 · Over-limit measurement:** Exercise the “Generation binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C088-T09 · Uncovered-scope report:** List the “Generation binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C088-T10 · Limit evidence:** Publish the selected “Generation binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for generation binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C089-T01 · Event inventory:** List the “Generation binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Generation binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C089-T03 · Failure mapping:** Map each documented “Generation binding” refusal or error to a diagnostic outcome; include “A stale channel sends requests after workload replacement” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C089-T04 · Emission path:** Add the “Generation binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C089-T05 · Redaction check:** Test “Generation binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C089-T06 · Output budget:** Set and exercise bounded “Generation binding” message size, rate and retention compatible with “Channel lifetime and retired handle count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C089-T07 · Success/refusal fixtures:** Capture “Generation binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Generation binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C089-T09 · Operator review:** Read the “Generation binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C089-T10 · Diagnostic evidence:** Publish redacted “Generation binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for generation binding; label unexecuted checks as untested.

- [ ] **UC-M08.01-C090-T01 · Evidence inventory:** List the “Generation binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C090-T02 · Artifact references:** Record the exact “Generation binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C090-T03 · Fixture references:** Attach the “Generation binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale channel sends requests after workload replacement” as a distinct evidence case.
- [ ] **UC-M08.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Generation binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C090-T05 · Environment record:** Record the actual “Generation binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C090-T06 · Expected versus observed:** Pair every “Generation binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C090-T07 · Failure and limit records:** Attach “Generation binding” change/failure and bounds evidence where required; include uncovered “Channel lifetime and retired handle count” and unresolved violations of “A replaced guest cannot continue using its former IPC authority”.
- [ ] **UC-M08.01-C090-T08 · Evidence hygiene:** Check the “Generation binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C090-T09 · Reproduction review:** Have the “Generation binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C090-T10 · Acceptance linkage:** Link the “Generation binding” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. IPC boundary conformance

**Source delivery:** Exercise valid calls, unknown operations, invalid handles and out-of-bounds buffers.

**Source invariant:** No malformed request reaches an arbitrary host function.

**Source negative case:** A negative buffer test succeeds at the host side.

**Source bounded quantities:** Corpus size and per-request deadline.

### UC-M08.01-C091 · Contract

**Original checklist item:** Specify IPC boundary conformance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.01-C091-T01 · Scope statement:** Draft the operation boundary for “IPC boundary conformance” within Typed guest-host IPC ABI; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “IPC boundary conformance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.01-C091-T03 · Output inventory:** List the outputs of “IPC boundary conformance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “IPC boundary conformance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.01-C091-T05 · Prerequisite contract:** Map “IPC boundary conformance” to the source component prerequisites (UC-M01.02, UC-M02.07, UC-M03.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.01-C091-T06 · Authority map:** Identify who may produce, change and consume “IPC boundary conformance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.01-C091-T07 · Invariant clause:** Add a normative clause for “IPC boundary conformance” that preserves “No malformed request reaches an arbitrary host function”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “IPC boundary conformance”; include the source counterexample “A negative buffer test succeeds at the host side” and the intended safe disposition.
- [ ] **UC-M08.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Corpus size and per-request deadline” in the “IPC boundary conformance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.01-C091-T10 · Contract review:** Review the “IPC boundary conformance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.01-C092 · Delivery

**Original checklist item:** Exercise valid calls, unknown operations, invalid handles and out-of-bounds buffers.

- [ ] **UC-M08.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “IPC boundary conformance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.01-C092-T02 · Change plan:** Break the source delivery for “IPC boundary conformance” into concrete edit targets and reviewable outputs; keep the UC-M08.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.01-C092-T03 · Core artifact:** Create the “IPC boundary conformance” fixture or harness for this source instruction: Exercise valid calls, unknown operations, invalid handles and out-of-bounds buffers.
- [ ] **UC-M08.01-C092-T04 · Concrete realization:** Connect the “IPC boundary conformance” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M08.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “IPC boundary conformance” needed to preserve “No malformed request reaches an arbitrary host function”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.01-C092-T06 · Dependency connection:** Connect the “IPC boundary conformance” implementation to guest ABI buffers, scoped handles and authorized host/broker dispatch; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.01-C092-T07 · Resource behavior:** Account for “Corpus size and per-request deadline” in “IPC boundary conformance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.01-C092-T08 · Delivery check:** Run the smallest real “IPC boundary conformance” path and its adverse fixture “A negative buffer test succeeds at the host side”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.01-C092-T09 · Patch review:** Review the “IPC boundary conformance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.01-C092-T10 · Delivery handoff:** Publish the “IPC boundary conformance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No malformed request reaches an arbitrary host function. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “IPC boundary conformance”; copy its required invariant exactly: “No malformed request reaches an arbitrary host function”.
- [ ] **UC-M08.01-C093-T02 · Observable terms:** Define each term in the “IPC boundary conformance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.01-C093-T03 · Precondition set:** List the preconditions under which “No malformed request reaches an arbitrary host function” must hold for “IPC boundary conformance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.01-C093-T04 · Transition coverage:** Map the “IPC boundary conformance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “IPC boundary conformance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.01-C093-T06 · Satisfying fixture:** Create a concrete “IPC boundary conformance” case that satisfies “No malformed request reaches an arbitrary host function”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.01-C093-T07 · Violating fixture:** Create the source counterexample “A negative buffer test succeeds at the host side” for “IPC boundary conformance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.01-C093-T08 · Enforcement evidence:** Exercise the “IPC boundary conformance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.01-C093-T09 · Regression linkage:** Link the “IPC boundary conformance” property to changes in guest ABI buffers, scoped handles and authorized host/broker dispatch; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.01-C093-T10 · Property disposition:** Compare the satisfying and violating “IPC boundary conformance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.01-C094 · Integration

**Original checklist item:** Integrate IPC boundary conformance with guest ABI buffers, scoped handles and authorized host/broker dispatch; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “IPC boundary conformance” across guest ABI buffers, scoped handles and authorized host/broker dispatch; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.01-C094-T02 · Field mapping:** Map every “IPC boundary conformance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “IPC boundary conformance” (source dependency list: UC-M01.02, UC-M02.07, UC-M03.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.01-C094-T04 · Ownership agreement:** Specify who owns “IPC boundary conformance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.01-C094-T05 · Handoff implementation:** Connect “IPC boundary conformance” through the mapped seam using the real adapter or explicit specification reference; preserve “No malformed request reaches an arbitrary host function” across the handoff.
- [ ] **UC-M08.01-C094-T06 · Absent-input case:** Omit one required “IPC boundary conformance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.01-C094-T07 · Stale-input case:** Supply an outdated “IPC boundary conformance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.01-C094-T08 · Incompatible-input case:** Supply an incompatible “IPC boundary conformance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.01-C094-T09 · Valid integration trace:** Run a valid “IPC boundary conformance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.01-C094-T10 · Seam review:** Reconcile the “IPC boundary conformance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for IPC boundary conformance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “IPC boundary conformance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.01-C095-T02 · Expected-result oracle:** Specify the “IPC boundary conformance” expected result independently of the implementation output; include the property “No malformed request reaches an arbitrary host function” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.01-C095-T03 · Fixture material:** Create the concrete “IPC boundary conformance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.01-C095-T04 · Target preparation:** Prepare the “IPC boundary conformance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.01-C095-T05 · Initial-state record:** Record the initial “IPC boundary conformance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.01-C095-T06 · Valid-path execution:** Execute the “IPC boundary conformance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.01-C095-T07 · Outcome comparison:** Compare every declared “IPC boundary conformance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.01-C095-T08 · State and bounds check:** Inspect the “IPC boundary conformance” ownership/state effects and actual use of “Corpus size and per-request deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.01-C095-T09 · Repeatability check:** Repeat the same “IPC boundary conformance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.01-C095-T10 · Positive evidence:** Attach the “IPC boundary conformance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.01-C096 · Negative test

**Original checklist item:** Negative case: A negative buffer test succeeds at the host side. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “IPC boundary conformance” source counterexample: “A negative buffer test succeeds at the host side”; state which precondition or invariant it challenges.
- [ ] **UC-M08.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “IPC boundary conformance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.01-C096-T03 · Valid control:** Construct a valid “IPC boundary conformance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.01-C096-T04 · Minimal adverse input:** Derive the “IPC boundary conformance” adverse fixture from the control with the smallest documented change needed to reproduce “A negative buffer test succeeds at the host side”; retain that change as reproducible data.
- [ ] **UC-M08.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “IPC boundary conformance”; require “No malformed request reaches an arbitrary host function” and forbid a false-success verdict.
- [ ] **UC-M08.01-C096-T06 · Adverse execution:** Exercise the “IPC boundary conformance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.01-C096-T07 · Effect inspection:** Inspect “IPC boundary conformance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.01-C096-T08 · Refusal versus failure:** Confirm the “IPC boundary conformance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.01-C096-T09 · Reset and retention:** Restore only the disposable “IPC boundary conformance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.01-C096-T10 · Negative regression:** Register the “IPC boundary conformance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.01-C097 · Change / failure test

**Original checklist item:** Exercise IPC boundary conformance when a channel is reset after its owning generation has been replaced; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.01-C097-T01 · Scenario record:** Write the “IPC boundary conformance” change/failure scenario exactly as supplied: a channel is reset after its owning generation has been replaced; identify the property that must remain true: “No malformed request reaches an arbitrary host function”.
- [ ] **UC-M08.01-C097-T02 · Baseline capture:** Create a known-valid “IPC boundary conformance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.01-C097-T03 · Injection map:** Locate the “IPC boundary conformance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “IPC boundary conformance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.01-C097-T05 · Controlled trigger:** Introduce the controlled “IPC boundary conformance” scenario in the disposable fixture: a channel is reset after its owning generation has been replaced; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.01-C097-T06 · Intermediate inspection:** Inspect the “IPC boundary conformance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “IPC boundary conformance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “IPC boundary conformance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.01-C097-T09 · Repeat and compare:** Repeat the selected “IPC boundary conformance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.01-C097-T10 · Failure evidence:** Publish the “IPC boundary conformance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for corpus size and per-request deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “IPC boundary conformance”: “Corpus size and per-request deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.01-C098-T02 · Measurement method:** Choose how to observe each “IPC boundary conformance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.01-C098-T03 · Budget decision:** Select justified resource and input limits for “IPC boundary conformance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “IPC boundary conformance” cases for “Corpus size and per-request deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “IPC boundary conformance” limit; preserve “No malformed request reaches an arbitrary host function”.
- [ ] **UC-M08.01-C098-T06 · Normal measurement:** Run or review the normal “IPC boundary conformance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.01-C098-T07 · At-limit measurement:** Exercise the “IPC boundary conformance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.01-C098-T08 · Over-limit measurement:** Exercise the “IPC boundary conformance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.01-C098-T09 · Uncovered-scope report:** List the “IPC boundary conformance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.01-C098-T10 · Limit evidence:** Publish the selected “IPC boundary conformance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for IPC boundary conformance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.01-C099-T01 · Event inventory:** List the “IPC boundary conformance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “IPC boundary conformance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.01-C099-T03 · Failure mapping:** Map each documented “IPC boundary conformance” refusal or error to a diagnostic outcome; include “A negative buffer test succeeds at the host side” and prohibit conversion into a success message.
- [ ] **UC-M08.01-C099-T04 · Emission path:** Add the “IPC boundary conformance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.01-C099-T05 · Redaction check:** Test “IPC boundary conformance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.01-C099-T06 · Output budget:** Set and exercise bounded “IPC boundary conformance” message size, rate and retention compatible with “Corpus size and per-request deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.01-C099-T07 · Success/refusal fixtures:** Capture “IPC boundary conformance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “IPC boundary conformance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.01-C099-T09 · Operator review:** Read the “IPC boundary conformance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.01-C099-T10 · Diagnostic evidence:** Publish redacted “IPC boundary conformance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for IPC boundary conformance; label unexecuted checks as untested.

- [ ] **UC-M08.01-C100-T01 · Evidence inventory:** List the “IPC boundary conformance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.01-C100-T02 · Artifact references:** Record the exact “IPC boundary conformance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.01-C100-T03 · Fixture references:** Attach the “IPC boundary conformance” fixture IDs, input identities and oracle definition; preserve the source counterexample “A negative buffer test succeeds at the host side” as a distinct evidence case.
- [ ] **UC-M08.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “IPC boundary conformance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.01-C100-T05 · Environment record:** Record the actual “IPC boundary conformance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.01-C100-T06 · Expected versus observed:** Pair every “IPC boundary conformance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.01-C100-T07 · Failure and limit records:** Attach “IPC boundary conformance” change/failure and bounds evidence where required; include uncovered “Corpus size and per-request deadline” and unresolved violations of “No malformed request reaches an arbitrary host function”.
- [ ] **UC-M08.01-C100-T08 · Evidence hygiene:** Check the “IPC boundary conformance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.01-C100-T09 · Reproduction review:** Have the “IPC boundary conformance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.01-C100-T10 · Acceptance linkage:** Link the “IPC boundary conformance” evidence to its parent and UC-M08.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

