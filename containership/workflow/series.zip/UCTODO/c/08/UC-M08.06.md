# UC-M08.06 — Shared-memory or buffer grant safety

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/08.md)

| Field | Preserved source value |
|---|---|
| Workstream | 08. Guest communication and data plane |
| Milestone | C |
| Priority | P1 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M06.04](../06/UC-M06.04.md), [UC-M08.01](../08/UC-M08.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3], [S4]. |

## Original requirement

Where zero-copy is selected, validate grant lifetime, size, direction and revocation; otherwise keep bounded copied buffers.

**Original acceptance criterion:** Revoked or cross-tenant grants cannot be used after stop, replacement or channel reset.

**Source trace:** Original checklist `UC100/c/08/UC-M08.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 769–779 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Copy-versus-grant decision

**Source delivery:** Select bounded copied buffers unless a justified zero-copy profile is explicitly chosen.

**Source invariant:** Zero-copy is optional rather than assumed necessary for first-guest completion.

**Source negative case:** A workload is blocked because an unnecessary grant mechanism is absent.

**Source bounded quantities:** Selected transport profiles and buffer size.

### UC-M08.06-C001 · Contract

**Original checklist item:** Specify copy-versus-grant decision inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C001-T01 · Scope statement:** Draft the operation boundary for “Copy-versus-grant decision” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Copy-versus-grant decision”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C001-T03 · Output inventory:** List the outputs of “Copy-versus-grant decision” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Copy-versus-grant decision”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C001-T05 · Prerequisite contract:** Map “Copy-versus-grant decision” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Copy-versus-grant decision”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C001-T07 · Invariant clause:** Add a normative clause for “Copy-versus-grant decision” that preserves “Zero-copy is optional rather than assumed necessary for first-guest completion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Copy-versus-grant decision”; include the source counterexample “A workload is blocked because an unnecessary grant mechanism is absent” and the intended safe disposition.
- [ ] **UC-M08.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Selected transport profiles and buffer size” in the “Copy-versus-grant decision” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C001-T10 · Contract review:** Review the “Copy-versus-grant decision” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C002 · Delivery

**Original checklist item:** Select bounded copied buffers unless a justified zero-copy profile is explicitly chosen.

- [ ] **UC-M08.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Copy-versus-grant decision”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C002-T02 · Change plan:** Break the source delivery for “Copy-versus-grant decision” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C002-T03 · Core artifact:** Prepare the “Copy-versus-grant decision” decision record for this source instruction: Select bounded copied buffers unless a justified zero-copy profile is explicitly chosen.
- [ ] **UC-M08.06-C002-T04 · Concrete realization:** Evaluate the “Copy-versus-grant decision” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M08.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Copy-versus-grant decision” needed to preserve “Zero-copy is optional rather than assumed necessary for first-guest completion”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C002-T06 · Dependency connection:** Connect the “Copy-versus-grant decision” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C002-T07 · Resource behavior:** Account for “Selected transport profiles and buffer size” in “Copy-versus-grant decision”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C002-T08 · Delivery check:** Run the smallest real “Copy-versus-grant decision” path and its adverse fixture “A workload is blocked because an unnecessary grant mechanism is absent”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C002-T09 · Patch review:** Review the “Copy-versus-grant decision” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C002-T10 · Delivery handoff:** Publish the “Copy-versus-grant decision” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Zero-copy is optional rather than assumed necessary for first-guest completion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Copy-versus-grant decision”; copy its required invariant exactly: “Zero-copy is optional rather than assumed necessary for first-guest completion”.
- [ ] **UC-M08.06-C003-T02 · Observable terms:** Define each term in the “Copy-versus-grant decision” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C003-T03 · Precondition set:** List the preconditions under which “Zero-copy is optional rather than assumed necessary for first-guest completion” must hold for “Copy-versus-grant decision”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C003-T04 · Transition coverage:** Map the “Copy-versus-grant decision” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Copy-versus-grant decision”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C003-T06 · Satisfying fixture:** Create a concrete “Copy-versus-grant decision” case that satisfies “Zero-copy is optional rather than assumed necessary for first-guest completion”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C003-T07 · Violating fixture:** Create the source counterexample “A workload is blocked because an unnecessary grant mechanism is absent” for “Copy-versus-grant decision”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C003-T08 · Enforcement evidence:** Exercise the “Copy-versus-grant decision” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C003-T09 · Regression linkage:** Link the “Copy-versus-grant decision” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Copy-versus-grant decision” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C004 · Integration

**Original checklist item:** Integrate copy-versus-grant decision with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Copy-versus-grant decision” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C004-T02 · Field mapping:** Map every “Copy-versus-grant decision” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Copy-versus-grant decision” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C004-T04 · Ownership agreement:** Specify who owns “Copy-versus-grant decision” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C004-T05 · Handoff implementation:** Connect “Copy-versus-grant decision” through the mapped seam using the real adapter or explicit specification reference; preserve “Zero-copy is optional rather than assumed necessary for first-guest completion” across the handoff.
- [ ] **UC-M08.06-C004-T06 · Absent-input case:** Omit one required “Copy-versus-grant decision” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C004-T07 · Stale-input case:** Supply an outdated “Copy-versus-grant decision” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Copy-versus-grant decision” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C004-T09 · Valid integration trace:** Run a valid “Copy-versus-grant decision” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C004-T10 · Seam review:** Reconcile the “Copy-versus-grant decision” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for copy-versus-grant decision; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Copy-versus-grant decision” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C005-T02 · Expected-result oracle:** Specify the “Copy-versus-grant decision” expected result independently of the implementation output; include the property “Zero-copy is optional rather than assumed necessary for first-guest completion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C005-T03 · Fixture material:** Create the concrete “Copy-versus-grant decision” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C005-T04 · Target preparation:** Prepare the “Copy-versus-grant decision” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C005-T05 · Initial-state record:** Record the initial “Copy-versus-grant decision” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C005-T06 · Valid-path execution:** Execute the “Copy-versus-grant decision” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C005-T07 · Outcome comparison:** Compare every declared “Copy-versus-grant decision” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C005-T08 · State and bounds check:** Inspect the “Copy-versus-grant decision” ownership/state effects and actual use of “Selected transport profiles and buffer size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C005-T09 · Repeatability check:** Repeat the same “Copy-versus-grant decision” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C005-T10 · Positive evidence:** Attach the “Copy-versus-grant decision” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C006 · Negative test

**Original checklist item:** Negative case: A workload is blocked because an unnecessary grant mechanism is absent. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Copy-versus-grant decision” source counterexample: “A workload is blocked because an unnecessary grant mechanism is absent”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Copy-versus-grant decision”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C006-T03 · Valid control:** Construct a valid “Copy-versus-grant decision” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C006-T04 · Minimal adverse input:** Derive the “Copy-versus-grant decision” adverse fixture from the control with the smallest documented change needed to reproduce “A workload is blocked because an unnecessary grant mechanism is absent”; retain that change as reproducible data.
- [ ] **UC-M08.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Copy-versus-grant decision”; require “Zero-copy is optional rather than assumed necessary for first-guest completion” and forbid a false-success verdict.
- [ ] **UC-M08.06-C006-T06 · Adverse execution:** Exercise the “Copy-versus-grant decision” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C006-T07 · Effect inspection:** Inspect “Copy-versus-grant decision” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C006-T08 · Refusal versus failure:** Confirm the “Copy-versus-grant decision” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C006-T09 · Reset and retention:** Restore only the disposable “Copy-versus-grant decision” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C006-T10 · Negative regression:** Register the “Copy-versus-grant decision” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C007 · Change / failure test

**Original checklist item:** Exercise copy-versus-grant decision when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C007-T01 · Scenario record:** Write the “Copy-versus-grant decision” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “Zero-copy is optional rather than assumed necessary for first-guest completion”.
- [ ] **UC-M08.06-C007-T02 · Baseline capture:** Create a known-valid “Copy-versus-grant decision” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C007-T03 · Injection map:** Locate the “Copy-versus-grant decision” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Copy-versus-grant decision” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C007-T05 · Controlled trigger:** Introduce the controlled “Copy-versus-grant decision” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C007-T06 · Intermediate inspection:** Inspect the “Copy-versus-grant decision” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Copy-versus-grant decision”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Copy-versus-grant decision” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C007-T09 · Repeat and compare:** Repeat the selected “Copy-versus-grant decision” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C007-T10 · Failure evidence:** Publish the “Copy-versus-grant decision” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for selected transport profiles and buffer size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Copy-versus-grant decision”: “Selected transport profiles and buffer size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C008-T02 · Measurement method:** Choose how to observe each “Copy-versus-grant decision” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Copy-versus-grant decision”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Copy-versus-grant decision” cases for “Selected transport profiles and buffer size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Copy-versus-grant decision” limit; preserve “Zero-copy is optional rather than assumed necessary for first-guest completion”.
- [ ] **UC-M08.06-C008-T06 · Normal measurement:** Run or review the normal “Copy-versus-grant decision” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C008-T07 · At-limit measurement:** Exercise the “Copy-versus-grant decision” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C008-T08 · Over-limit measurement:** Exercise the “Copy-versus-grant decision” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C008-T09 · Uncovered-scope report:** List the “Copy-versus-grant decision” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C008-T10 · Limit evidence:** Publish the selected “Copy-versus-grant decision” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for copy-versus-grant decision with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C009-T01 · Event inventory:** List the “Copy-versus-grant decision” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Copy-versus-grant decision” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C009-T03 · Failure mapping:** Map each documented “Copy-versus-grant decision” refusal or error to a diagnostic outcome; include “A workload is blocked because an unnecessary grant mechanism is absent” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C009-T04 · Emission path:** Add the “Copy-versus-grant decision” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C009-T05 · Redaction check:** Test “Copy-versus-grant decision” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C009-T06 · Output budget:** Set and exercise bounded “Copy-versus-grant decision” message size, rate and retention compatible with “Selected transport profiles and buffer size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C009-T07 · Success/refusal fixtures:** Capture “Copy-versus-grant decision” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Copy-versus-grant decision” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C009-T09 · Operator review:** Read the “Copy-versus-grant decision” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C009-T10 · Diagnostic evidence:** Publish redacted “Copy-versus-grant decision” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for copy-versus-grant decision; label unexecuted checks as untested.

- [ ] **UC-M08.06-C010-T01 · Evidence inventory:** List the “Copy-versus-grant decision” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C010-T02 · Artifact references:** Record the exact “Copy-versus-grant decision” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C010-T03 · Fixture references:** Attach the “Copy-versus-grant decision” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload is blocked because an unnecessary grant mechanism is absent” as a distinct evidence case.
- [ ] **UC-M08.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Copy-versus-grant decision”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C010-T05 · Environment record:** Record the actual “Copy-versus-grant decision” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C010-T06 · Expected versus observed:** Pair every “Copy-versus-grant decision” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C010-T07 · Failure and limit records:** Attach “Copy-versus-grant decision” change/failure and bounds evidence where required; include uncovered “Selected transport profiles and buffer size” and unresolved violations of “Zero-copy is optional rather than assumed necessary for first-guest completion”.
- [ ] **UC-M08.06-C010-T08 · Evidence hygiene:** Check the “Copy-versus-grant decision” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C010-T09 · Reproduction review:** Have the “Copy-versus-grant decision” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C010-T10 · Acceptance linkage:** Link the “Copy-versus-grant decision” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Grant descriptor

**Source delivery:** Define grant identity, owner, size, direction and lifetime fields.

**Source invariant:** A grant cannot exist without explicit ownership and bounds.

**Source negative case:** A descriptor omits whether host writes are permitted.

**Source bounded quantities:** Descriptor bytes and live grants.

### UC-M08.06-C011 · Contract

**Original checklist item:** Specify grant descriptor inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C011-T01 · Scope statement:** Draft the operation boundary for “Grant descriptor” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Grant descriptor”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C011-T03 · Output inventory:** List the outputs of “Grant descriptor” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Grant descriptor”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C011-T05 · Prerequisite contract:** Map “Grant descriptor” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Grant descriptor”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C011-T07 · Invariant clause:** Add a normative clause for “Grant descriptor” that preserves “A grant cannot exist without explicit ownership and bounds”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Grant descriptor”; include the source counterexample “A descriptor omits whether host writes are permitted” and the intended safe disposition.
- [ ] **UC-M08.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Descriptor bytes and live grants” in the “Grant descriptor” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C011-T10 · Contract review:** Review the “Grant descriptor” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C012 · Delivery

**Original checklist item:** Define grant identity, owner, size, direction and lifetime fields.

- [ ] **UC-M08.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Grant descriptor”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C012-T02 · Change plan:** Break the source delivery for “Grant descriptor” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C012-T03 · Core artifact:** Create the “Grant descriptor” model, schema or inventory that realizes this source instruction: Define grant identity, owner, size, direction and lifetime fields.
- [ ] **UC-M08.06-C012-T04 · Concrete realization:** Populate “Grant descriptor” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Grant descriptor” needed to preserve “A grant cannot exist without explicit ownership and bounds”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C012-T06 · Dependency connection:** Connect the “Grant descriptor” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C012-T07 · Resource behavior:** Account for “Descriptor bytes and live grants” in “Grant descriptor”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C012-T08 · Delivery check:** Run the smallest real “Grant descriptor” path and its adverse fixture “A descriptor omits whether host writes are permitted”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C012-T09 · Patch review:** Review the “Grant descriptor” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C012-T10 · Delivery handoff:** Publish the “Grant descriptor” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A grant cannot exist without explicit ownership and bounds. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Grant descriptor”; copy its required invariant exactly: “A grant cannot exist without explicit ownership and bounds”.
- [ ] **UC-M08.06-C013-T02 · Observable terms:** Define each term in the “Grant descriptor” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C013-T03 · Precondition set:** List the preconditions under which “A grant cannot exist without explicit ownership and bounds” must hold for “Grant descriptor”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C013-T04 · Transition coverage:** Map the “Grant descriptor” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Grant descriptor”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C013-T06 · Satisfying fixture:** Create a concrete “Grant descriptor” case that satisfies “A grant cannot exist without explicit ownership and bounds”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C013-T07 · Violating fixture:** Create the source counterexample “A descriptor omits whether host writes are permitted” for “Grant descriptor”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C013-T08 · Enforcement evidence:** Exercise the “Grant descriptor” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C013-T09 · Regression linkage:** Link the “Grant descriptor” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Grant descriptor” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C014 · Integration

**Original checklist item:** Integrate grant descriptor with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Grant descriptor” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C014-T02 · Field mapping:** Map every “Grant descriptor” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Grant descriptor” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C014-T04 · Ownership agreement:** Specify who owns “Grant descriptor” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C014-T05 · Handoff implementation:** Connect “Grant descriptor” through the mapped seam using the real adapter or explicit specification reference; preserve “A grant cannot exist without explicit ownership and bounds” across the handoff.
- [ ] **UC-M08.06-C014-T06 · Absent-input case:** Omit one required “Grant descriptor” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C014-T07 · Stale-input case:** Supply an outdated “Grant descriptor” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Grant descriptor” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C014-T09 · Valid integration trace:** Run a valid “Grant descriptor” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C014-T10 · Seam review:** Reconcile the “Grant descriptor” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for grant descriptor; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Grant descriptor” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C015-T02 · Expected-result oracle:** Specify the “Grant descriptor” expected result independently of the implementation output; include the property “A grant cannot exist without explicit ownership and bounds” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C015-T03 · Fixture material:** Create the concrete “Grant descriptor” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C015-T04 · Target preparation:** Prepare the “Grant descriptor” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C015-T05 · Initial-state record:** Record the initial “Grant descriptor” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C015-T06 · Valid-path execution:** Execute the “Grant descriptor” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C015-T07 · Outcome comparison:** Compare every declared “Grant descriptor” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C015-T08 · State and bounds check:** Inspect the “Grant descriptor” ownership/state effects and actual use of “Descriptor bytes and live grants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C015-T09 · Repeatability check:** Repeat the same “Grant descriptor” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C015-T10 · Positive evidence:** Attach the “Grant descriptor” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C016 · Negative test

**Original checklist item:** Negative case: A descriptor omits whether host writes are permitted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Grant descriptor” source counterexample: “A descriptor omits whether host writes are permitted”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Grant descriptor”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C016-T03 · Valid control:** Construct a valid “Grant descriptor” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C016-T04 · Minimal adverse input:** Derive the “Grant descriptor” adverse fixture from the control with the smallest documented change needed to reproduce “A descriptor omits whether host writes are permitted”; retain that change as reproducible data.
- [ ] **UC-M08.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Grant descriptor”; require “A grant cannot exist without explicit ownership and bounds” and forbid a false-success verdict.
- [ ] **UC-M08.06-C016-T06 · Adverse execution:** Exercise the “Grant descriptor” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C016-T07 · Effect inspection:** Inspect “Grant descriptor” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C016-T08 · Refusal versus failure:** Confirm the “Grant descriptor” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C016-T09 · Reset and retention:** Restore only the disposable “Grant descriptor” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C016-T10 · Negative regression:** Register the “Grant descriptor” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C017 · Change / failure test

**Original checklist item:** Exercise grant descriptor when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C017-T01 · Scenario record:** Write the “Grant descriptor” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “A grant cannot exist without explicit ownership and bounds”.
- [ ] **UC-M08.06-C017-T02 · Baseline capture:** Create a known-valid “Grant descriptor” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C017-T03 · Injection map:** Locate the “Grant descriptor” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Grant descriptor” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C017-T05 · Controlled trigger:** Introduce the controlled “Grant descriptor” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C017-T06 · Intermediate inspection:** Inspect the “Grant descriptor” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Grant descriptor”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Grant descriptor” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C017-T09 · Repeat and compare:** Repeat the selected “Grant descriptor” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C017-T10 · Failure evidence:** Publish the “Grant descriptor” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for descriptor bytes and live grants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Grant descriptor”: “Descriptor bytes and live grants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C018-T02 · Measurement method:** Choose how to observe each “Grant descriptor” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Grant descriptor”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Grant descriptor” cases for “Descriptor bytes and live grants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Grant descriptor” limit; preserve “A grant cannot exist without explicit ownership and bounds”.
- [ ] **UC-M08.06-C018-T06 · Normal measurement:** Run or review the normal “Grant descriptor” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C018-T07 · At-limit measurement:** Exercise the “Grant descriptor” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C018-T08 · Over-limit measurement:** Exercise the “Grant descriptor” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C018-T09 · Uncovered-scope report:** List the “Grant descriptor” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C018-T10 · Limit evidence:** Publish the selected “Grant descriptor” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for grant descriptor with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C019-T01 · Event inventory:** List the “Grant descriptor” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Grant descriptor” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C019-T03 · Failure mapping:** Map each documented “Grant descriptor” refusal or error to a diagnostic outcome; include “A descriptor omits whether host writes are permitted” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C019-T04 · Emission path:** Add the “Grant descriptor” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C019-T05 · Redaction check:** Test “Grant descriptor” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C019-T06 · Output budget:** Set and exercise bounded “Grant descriptor” message size, rate and retention compatible with “Descriptor bytes and live grants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C019-T07 · Success/refusal fixtures:** Capture “Grant descriptor” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Grant descriptor” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C019-T09 · Operator review:** Read the “Grant descriptor” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C019-T10 · Diagnostic evidence:** Publish redacted “Grant descriptor” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for grant descriptor; label unexecuted checks as untested.

- [ ] **UC-M08.06-C020-T01 · Evidence inventory:** List the “Grant descriptor” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C020-T02 · Artifact references:** Record the exact “Grant descriptor” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C020-T03 · Fixture references:** Attach the “Grant descriptor” fixture IDs, input identities and oracle definition; preserve the source counterexample “A descriptor omits whether host writes are permitted” as a distinct evidence case.
- [ ] **UC-M08.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Grant descriptor”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C020-T05 · Environment record:** Record the actual “Grant descriptor” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C020-T06 · Expected versus observed:** Pair every “Grant descriptor” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C020-T07 · Failure and limit records:** Attach “Grant descriptor” change/failure and bounds evidence where required; include uncovered “Descriptor bytes and live grants” and unresolved violations of “A grant cannot exist without explicit ownership and bounds”.
- [ ] **UC-M08.06-C020-T08 · Evidence hygiene:** Check the “Grant descriptor” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C020-T09 · Reproduction review:** Have the “Grant descriptor” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C020-T10 · Acceptance linkage:** Link the “Grant descriptor” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Bounds validation

**Source delivery:** Validate every grant mapping and access against its declared range.

**Source invariant:** A grant cannot expose adjacent memory.

**Source negative case:** A request accesses one byte beyond the granted range.

**Source bounded quantities:** Grant bytes and validation work.

### UC-M08.06-C021 · Contract

**Original checklist item:** Specify bounds validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C021-T01 · Scope statement:** Draft the operation boundary for “Bounds validation” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Bounds validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C021-T03 · Output inventory:** List the outputs of “Bounds validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Bounds validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C021-T05 · Prerequisite contract:** Map “Bounds validation” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Bounds validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C021-T07 · Invariant clause:** Add a normative clause for “Bounds validation” that preserves “A grant cannot expose adjacent memory”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Bounds validation”; include the source counterexample “A request accesses one byte beyond the granted range” and the intended safe disposition.
- [ ] **UC-M08.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Grant bytes and validation work” in the “Bounds validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C021-T10 · Contract review:** Review the “Bounds validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C022 · Delivery

**Original checklist item:** Validate every grant mapping and access against its declared range.

- [ ] **UC-M08.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Bounds validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C022-T02 · Change plan:** Break the source delivery for “Bounds validation” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Bounds validation” that realizes this source instruction: Validate every grant mapping and access against its declared range.
- [ ] **UC-M08.06-C022-T04 · Concrete realization:** Trace “Bounds validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Bounds validation” needed to preserve “A grant cannot expose adjacent memory”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C022-T06 · Dependency connection:** Connect the “Bounds validation” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C022-T07 · Resource behavior:** Account for “Grant bytes and validation work” in “Bounds validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C022-T08 · Delivery check:** Run the smallest real “Bounds validation” path and its adverse fixture “A request accesses one byte beyond the granted range”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C022-T09 · Patch review:** Review the “Bounds validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C022-T10 · Delivery handoff:** Publish the “Bounds validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A grant cannot expose adjacent memory. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Bounds validation”; copy its required invariant exactly: “A grant cannot expose adjacent memory”.
- [ ] **UC-M08.06-C023-T02 · Observable terms:** Define each term in the “Bounds validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C023-T03 · Precondition set:** List the preconditions under which “A grant cannot expose adjacent memory” must hold for “Bounds validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C023-T04 · Transition coverage:** Map the “Bounds validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Bounds validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C023-T06 · Satisfying fixture:** Create a concrete “Bounds validation” case that satisfies “A grant cannot expose adjacent memory”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C023-T07 · Violating fixture:** Create the source counterexample “A request accesses one byte beyond the granted range” for “Bounds validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C023-T08 · Enforcement evidence:** Exercise the “Bounds validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C023-T09 · Regression linkage:** Link the “Bounds validation” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Bounds validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C024 · Integration

**Original checklist item:** Integrate bounds validation with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Bounds validation” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C024-T02 · Field mapping:** Map every “Bounds validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Bounds validation” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C024-T04 · Ownership agreement:** Specify who owns “Bounds validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C024-T05 · Handoff implementation:** Connect “Bounds validation” through the mapped seam using the real adapter or explicit specification reference; preserve “A grant cannot expose adjacent memory” across the handoff.
- [ ] **UC-M08.06-C024-T06 · Absent-input case:** Omit one required “Bounds validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C024-T07 · Stale-input case:** Supply an outdated “Bounds validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Bounds validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C024-T09 · Valid integration trace:** Run a valid “Bounds validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C024-T10 · Seam review:** Reconcile the “Bounds validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for bounds validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Bounds validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C025-T02 · Expected-result oracle:** Specify the “Bounds validation” expected result independently of the implementation output; include the property “A grant cannot expose adjacent memory” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C025-T03 · Fixture material:** Create the concrete “Bounds validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C025-T04 · Target preparation:** Prepare the “Bounds validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C025-T05 · Initial-state record:** Record the initial “Bounds validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C025-T06 · Valid-path execution:** Execute the “Bounds validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C025-T07 · Outcome comparison:** Compare every declared “Bounds validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C025-T08 · State and bounds check:** Inspect the “Bounds validation” ownership/state effects and actual use of “Grant bytes and validation work”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C025-T09 · Repeatability check:** Repeat the same “Bounds validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C025-T10 · Positive evidence:** Attach the “Bounds validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C026 · Negative test

**Original checklist item:** Negative case: A request accesses one byte beyond the granted range. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Bounds validation” source counterexample: “A request accesses one byte beyond the granted range”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Bounds validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C026-T03 · Valid control:** Construct a valid “Bounds validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C026-T04 · Minimal adverse input:** Derive the “Bounds validation” adverse fixture from the control with the smallest documented change needed to reproduce “A request accesses one byte beyond the granted range”; retain that change as reproducible data.
- [ ] **UC-M08.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Bounds validation”; require “A grant cannot expose adjacent memory” and forbid a false-success verdict.
- [ ] **UC-M08.06-C026-T06 · Adverse execution:** Exercise the “Bounds validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C026-T07 · Effect inspection:** Inspect “Bounds validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C026-T08 · Refusal versus failure:** Confirm the “Bounds validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C026-T09 · Reset and retention:** Restore only the disposable “Bounds validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C026-T10 · Negative regression:** Register the “Bounds validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C027 · Change / failure test

**Original checklist item:** Exercise bounds validation when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C027-T01 · Scenario record:** Write the “Bounds validation” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “A grant cannot expose adjacent memory”.
- [ ] **UC-M08.06-C027-T02 · Baseline capture:** Create a known-valid “Bounds validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C027-T03 · Injection map:** Locate the “Bounds validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Bounds validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C027-T05 · Controlled trigger:** Introduce the controlled “Bounds validation” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C027-T06 · Intermediate inspection:** Inspect the “Bounds validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Bounds validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Bounds validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C027-T09 · Repeat and compare:** Repeat the selected “Bounds validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C027-T10 · Failure evidence:** Publish the “Bounds validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for grant bytes and validation work; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Bounds validation”: “Grant bytes and validation work”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C028-T02 · Measurement method:** Choose how to observe each “Bounds validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Bounds validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Bounds validation” cases for “Grant bytes and validation work”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Bounds validation” limit; preserve “A grant cannot expose adjacent memory”.
- [ ] **UC-M08.06-C028-T06 · Normal measurement:** Run or review the normal “Bounds validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C028-T07 · At-limit measurement:** Exercise the “Bounds validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C028-T08 · Over-limit measurement:** Exercise the “Bounds validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C028-T09 · Uncovered-scope report:** List the “Bounds validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C028-T10 · Limit evidence:** Publish the selected “Bounds validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for bounds validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C029-T01 · Event inventory:** List the “Bounds validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Bounds validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C029-T03 · Failure mapping:** Map each documented “Bounds validation” refusal or error to a diagnostic outcome; include “A request accesses one byte beyond the granted range” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C029-T04 · Emission path:** Add the “Bounds validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C029-T05 · Redaction check:** Test “Bounds validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C029-T06 · Output budget:** Set and exercise bounded “Bounds validation” message size, rate and retention compatible with “Grant bytes and validation work”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C029-T07 · Success/refusal fixtures:** Capture “Bounds validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Bounds validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C029-T09 · Operator review:** Read the “Bounds validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C029-T10 · Diagnostic evidence:** Publish redacted “Bounds validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for bounds validation; label unexecuted checks as untested.

- [ ] **UC-M08.06-C030-T01 · Evidence inventory:** List the “Bounds validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C030-T02 · Artifact references:** Record the exact “Bounds validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C030-T03 · Fixture references:** Attach the “Bounds validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A request accesses one byte beyond the granted range” as a distinct evidence case.
- [ ] **UC-M08.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Bounds validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C030-T05 · Environment record:** Record the actual “Bounds validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C030-T06 · Expected versus observed:** Pair every “Bounds validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C030-T07 · Failure and limit records:** Attach “Bounds validation” change/failure and bounds evidence where required; include uncovered “Grant bytes and validation work” and unresolved violations of “A grant cannot expose adjacent memory”.
- [ ] **UC-M08.06-C030-T08 · Evidence hygiene:** Check the “Bounds validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C030-T09 · Reproduction review:** Have the “Bounds validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C030-T10 · Acceptance linkage:** Link the “Bounds validation” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Direction enforcement

**Source delivery:** Enforce read-only or write permission according to the grant contract.

**Source invariant:** A read-only grant cannot become a writable host mapping.

**Source negative case:** A guest requests a write through a read-only grant.

**Source bounded quantities:** Permission modes and mappings per grant.

### UC-M08.06-C031 · Contract

**Original checklist item:** Specify direction enforcement inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C031-T01 · Scope statement:** Draft the operation boundary for “Direction enforcement” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Direction enforcement”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C031-T03 · Output inventory:** List the outputs of “Direction enforcement” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Direction enforcement”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C031-T05 · Prerequisite contract:** Map “Direction enforcement” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Direction enforcement”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C031-T07 · Invariant clause:** Add a normative clause for “Direction enforcement” that preserves “A read-only grant cannot become a writable host mapping”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Direction enforcement”; include the source counterexample “A guest requests a write through a read-only grant” and the intended safe disposition.
- [ ] **UC-M08.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Permission modes and mappings per grant” in the “Direction enforcement” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C031-T10 · Contract review:** Review the “Direction enforcement” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C032 · Delivery

**Original checklist item:** Enforce read-only or write permission according to the grant contract.

- [ ] **UC-M08.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Direction enforcement”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C032-T02 · Change plan:** Break the source delivery for “Direction enforcement” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Direction enforcement” that realizes this source instruction: Enforce read-only or write permission according to the grant contract.
- [ ] **UC-M08.06-C032-T04 · Concrete realization:** Trace “Direction enforcement” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Direction enforcement” needed to preserve “A read-only grant cannot become a writable host mapping”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C032-T06 · Dependency connection:** Connect the “Direction enforcement” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C032-T07 · Resource behavior:** Account for “Permission modes and mappings per grant” in “Direction enforcement”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C032-T08 · Delivery check:** Run the smallest real “Direction enforcement” path and its adverse fixture “A guest requests a write through a read-only grant”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C032-T09 · Patch review:** Review the “Direction enforcement” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C032-T10 · Delivery handoff:** Publish the “Direction enforcement” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A read-only grant cannot become a writable host mapping. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Direction enforcement”; copy its required invariant exactly: “A read-only grant cannot become a writable host mapping”.
- [ ] **UC-M08.06-C033-T02 · Observable terms:** Define each term in the “Direction enforcement” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C033-T03 · Precondition set:** List the preconditions under which “A read-only grant cannot become a writable host mapping” must hold for “Direction enforcement”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C033-T04 · Transition coverage:** Map the “Direction enforcement” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Direction enforcement”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C033-T06 · Satisfying fixture:** Create a concrete “Direction enforcement” case that satisfies “A read-only grant cannot become a writable host mapping”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C033-T07 · Violating fixture:** Create the source counterexample “A guest requests a write through a read-only grant” for “Direction enforcement”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C033-T08 · Enforcement evidence:** Exercise the “Direction enforcement” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C033-T09 · Regression linkage:** Link the “Direction enforcement” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Direction enforcement” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C034 · Integration

**Original checklist item:** Integrate direction enforcement with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Direction enforcement” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C034-T02 · Field mapping:** Map every “Direction enforcement” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Direction enforcement” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C034-T04 · Ownership agreement:** Specify who owns “Direction enforcement” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C034-T05 · Handoff implementation:** Connect “Direction enforcement” through the mapped seam using the real adapter or explicit specification reference; preserve “A read-only grant cannot become a writable host mapping” across the handoff.
- [ ] **UC-M08.06-C034-T06 · Absent-input case:** Omit one required “Direction enforcement” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C034-T07 · Stale-input case:** Supply an outdated “Direction enforcement” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Direction enforcement” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C034-T09 · Valid integration trace:** Run a valid “Direction enforcement” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C034-T10 · Seam review:** Reconcile the “Direction enforcement” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for direction enforcement; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Direction enforcement” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C035-T02 · Expected-result oracle:** Specify the “Direction enforcement” expected result independently of the implementation output; include the property “A read-only grant cannot become a writable host mapping” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C035-T03 · Fixture material:** Create the concrete “Direction enforcement” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C035-T04 · Target preparation:** Prepare the “Direction enforcement” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C035-T05 · Initial-state record:** Record the initial “Direction enforcement” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C035-T06 · Valid-path execution:** Execute the “Direction enforcement” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C035-T07 · Outcome comparison:** Compare every declared “Direction enforcement” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C035-T08 · State and bounds check:** Inspect the “Direction enforcement” ownership/state effects and actual use of “Permission modes and mappings per grant”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C035-T09 · Repeatability check:** Repeat the same “Direction enforcement” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C035-T10 · Positive evidence:** Attach the “Direction enforcement” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C036 · Negative test

**Original checklist item:** Negative case: A guest requests a write through a read-only grant. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Direction enforcement” source counterexample: “A guest requests a write through a read-only grant”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Direction enforcement”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C036-T03 · Valid control:** Construct a valid “Direction enforcement” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C036-T04 · Minimal adverse input:** Derive the “Direction enforcement” adverse fixture from the control with the smallest documented change needed to reproduce “A guest requests a write through a read-only grant”; retain that change as reproducible data.
- [ ] **UC-M08.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Direction enforcement”; require “A read-only grant cannot become a writable host mapping” and forbid a false-success verdict.
- [ ] **UC-M08.06-C036-T06 · Adverse execution:** Exercise the “Direction enforcement” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C036-T07 · Effect inspection:** Inspect “Direction enforcement” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C036-T08 · Refusal versus failure:** Confirm the “Direction enforcement” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C036-T09 · Reset and retention:** Restore only the disposable “Direction enforcement” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C036-T10 · Negative regression:** Register the “Direction enforcement” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C037 · Change / failure test

**Original checklist item:** Exercise direction enforcement when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C037-T01 · Scenario record:** Write the “Direction enforcement” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “A read-only grant cannot become a writable host mapping”.
- [ ] **UC-M08.06-C037-T02 · Baseline capture:** Create a known-valid “Direction enforcement” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C037-T03 · Injection map:** Locate the “Direction enforcement” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Direction enforcement” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C037-T05 · Controlled trigger:** Introduce the controlled “Direction enforcement” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C037-T06 · Intermediate inspection:** Inspect the “Direction enforcement” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Direction enforcement”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Direction enforcement” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C037-T09 · Repeat and compare:** Repeat the selected “Direction enforcement” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C037-T10 · Failure evidence:** Publish the “Direction enforcement” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for permission modes and mappings per grant; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Direction enforcement”: “Permission modes and mappings per grant”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C038-T02 · Measurement method:** Choose how to observe each “Direction enforcement” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Direction enforcement”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Direction enforcement” cases for “Permission modes and mappings per grant”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Direction enforcement” limit; preserve “A read-only grant cannot become a writable host mapping”.
- [ ] **UC-M08.06-C038-T06 · Normal measurement:** Run or review the normal “Direction enforcement” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C038-T07 · At-limit measurement:** Exercise the “Direction enforcement” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C038-T08 · Over-limit measurement:** Exercise the “Direction enforcement” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C038-T09 · Uncovered-scope report:** List the “Direction enforcement” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C038-T10 · Limit evidence:** Publish the selected “Direction enforcement” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for direction enforcement with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C039-T01 · Event inventory:** List the “Direction enforcement” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Direction enforcement” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C039-T03 · Failure mapping:** Map each documented “Direction enforcement” refusal or error to a diagnostic outcome; include “A guest requests a write through a read-only grant” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C039-T04 · Emission path:** Add the “Direction enforcement” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C039-T05 · Redaction check:** Test “Direction enforcement” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C039-T06 · Output budget:** Set and exercise bounded “Direction enforcement” message size, rate and retention compatible with “Permission modes and mappings per grant”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C039-T07 · Success/refusal fixtures:** Capture “Direction enforcement” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Direction enforcement” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C039-T09 · Operator review:** Read the “Direction enforcement” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C039-T10 · Diagnostic evidence:** Publish redacted “Direction enforcement” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for direction enforcement; label unexecuted checks as untested.

- [ ] **UC-M08.06-C040-T01 · Evidence inventory:** List the “Direction enforcement” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C040-T02 · Artifact references:** Record the exact “Direction enforcement” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C040-T03 · Fixture references:** Attach the “Direction enforcement” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest requests a write through a read-only grant” as a distinct evidence case.
- [ ] **UC-M08.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Direction enforcement”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C040-T05 · Environment record:** Record the actual “Direction enforcement” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C040-T06 · Expected versus observed:** Pair every “Direction enforcement” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C040-T07 · Failure and limit records:** Attach “Direction enforcement” change/failure and bounds evidence where required; include uncovered “Permission modes and mappings per grant” and unresolved violations of “A read-only grant cannot become a writable host mapping”.
- [ ] **UC-M08.06-C040-T08 · Evidence hygiene:** Check the “Direction enforcement” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C040-T09 · Reproduction review:** Have the “Direction enforcement” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C040-T10 · Acceptance linkage:** Link the “Direction enforcement” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Tenant binding

**Source delivery:** Associate grants with authenticated tenant and workload identity.

**Source invariant:** A grant from another tenant cannot be imported by guessing its identifier.

**Source negative case:** A guest submits a valid cross-tenant grant token.

**Source bounded quantities:** Tenant grants and lookup cost.

### UC-M08.06-C041 · Contract

**Original checklist item:** Specify tenant binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C041-T01 · Scope statement:** Draft the operation boundary for “Tenant binding” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Tenant binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C041-T03 · Output inventory:** List the outputs of “Tenant binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Tenant binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C041-T05 · Prerequisite contract:** Map “Tenant binding” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Tenant binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C041-T07 · Invariant clause:** Add a normative clause for “Tenant binding” that preserves “A grant from another tenant cannot be imported by guessing its identifier”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Tenant binding”; include the source counterexample “A guest submits a valid cross-tenant grant token” and the intended safe disposition.
- [ ] **UC-M08.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Tenant grants and lookup cost” in the “Tenant binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C041-T10 · Contract review:** Review the “Tenant binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C042 · Delivery

**Original checklist item:** Associate grants with authenticated tenant and workload identity.

- [ ] **UC-M08.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Tenant binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C042-T02 · Change plan:** Break the source delivery for “Tenant binding” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Tenant binding” that realizes this source instruction: Associate grants with authenticated tenant and workload identity.
- [ ] **UC-M08.06-C042-T04 · Concrete realization:** Trace “Tenant binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Tenant binding” needed to preserve “A grant from another tenant cannot be imported by guessing its identifier”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C042-T06 · Dependency connection:** Connect the “Tenant binding” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C042-T07 · Resource behavior:** Account for “Tenant grants and lookup cost” in “Tenant binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C042-T08 · Delivery check:** Run the smallest real “Tenant binding” path and its adverse fixture “A guest submits a valid cross-tenant grant token”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C042-T09 · Patch review:** Review the “Tenant binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C042-T10 · Delivery handoff:** Publish the “Tenant binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A grant from another tenant cannot be imported by guessing its identifier. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Tenant binding”; copy its required invariant exactly: “A grant from another tenant cannot be imported by guessing its identifier”.
- [ ] **UC-M08.06-C043-T02 · Observable terms:** Define each term in the “Tenant binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C043-T03 · Precondition set:** List the preconditions under which “A grant from another tenant cannot be imported by guessing its identifier” must hold for “Tenant binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C043-T04 · Transition coverage:** Map the “Tenant binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Tenant binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C043-T06 · Satisfying fixture:** Create a concrete “Tenant binding” case that satisfies “A grant from another tenant cannot be imported by guessing its identifier”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C043-T07 · Violating fixture:** Create the source counterexample “A guest submits a valid cross-tenant grant token” for “Tenant binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C043-T08 · Enforcement evidence:** Exercise the “Tenant binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C043-T09 · Regression linkage:** Link the “Tenant binding” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Tenant binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C044 · Integration

**Original checklist item:** Integrate tenant binding with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Tenant binding” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C044-T02 · Field mapping:** Map every “Tenant binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Tenant binding” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C044-T04 · Ownership agreement:** Specify who owns “Tenant binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C044-T05 · Handoff implementation:** Connect “Tenant binding” through the mapped seam using the real adapter or explicit specification reference; preserve “A grant from another tenant cannot be imported by guessing its identifier” across the handoff.
- [ ] **UC-M08.06-C044-T06 · Absent-input case:** Omit one required “Tenant binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C044-T07 · Stale-input case:** Supply an outdated “Tenant binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Tenant binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C044-T09 · Valid integration trace:** Run a valid “Tenant binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C044-T10 · Seam review:** Reconcile the “Tenant binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for tenant binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Tenant binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C045-T02 · Expected-result oracle:** Specify the “Tenant binding” expected result independently of the implementation output; include the property “A grant from another tenant cannot be imported by guessing its identifier” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C045-T03 · Fixture material:** Create the concrete “Tenant binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C045-T04 · Target preparation:** Prepare the “Tenant binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C045-T05 · Initial-state record:** Record the initial “Tenant binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C045-T06 · Valid-path execution:** Execute the “Tenant binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C045-T07 · Outcome comparison:** Compare every declared “Tenant binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C045-T08 · State and bounds check:** Inspect the “Tenant binding” ownership/state effects and actual use of “Tenant grants and lookup cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C045-T09 · Repeatability check:** Repeat the same “Tenant binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C045-T10 · Positive evidence:** Attach the “Tenant binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C046 · Negative test

**Original checklist item:** Negative case: A guest submits a valid cross-tenant grant token. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Tenant binding” source counterexample: “A guest submits a valid cross-tenant grant token”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Tenant binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C046-T03 · Valid control:** Construct a valid “Tenant binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C046-T04 · Minimal adverse input:** Derive the “Tenant binding” adverse fixture from the control with the smallest documented change needed to reproduce “A guest submits a valid cross-tenant grant token”; retain that change as reproducible data.
- [ ] **UC-M08.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Tenant binding”; require “A grant from another tenant cannot be imported by guessing its identifier” and forbid a false-success verdict.
- [ ] **UC-M08.06-C046-T06 · Adverse execution:** Exercise the “Tenant binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C046-T07 · Effect inspection:** Inspect “Tenant binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C046-T08 · Refusal versus failure:** Confirm the “Tenant binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C046-T09 · Reset and retention:** Restore only the disposable “Tenant binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C046-T10 · Negative regression:** Register the “Tenant binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C047 · Change / failure test

**Original checklist item:** Exercise tenant binding when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C047-T01 · Scenario record:** Write the “Tenant binding” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “A grant from another tenant cannot be imported by guessing its identifier”.
- [ ] **UC-M08.06-C047-T02 · Baseline capture:** Create a known-valid “Tenant binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C047-T03 · Injection map:** Locate the “Tenant binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Tenant binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C047-T05 · Controlled trigger:** Introduce the controlled “Tenant binding” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C047-T06 · Intermediate inspection:** Inspect the “Tenant binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Tenant binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Tenant binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C047-T09 · Repeat and compare:** Repeat the selected “Tenant binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C047-T10 · Failure evidence:** Publish the “Tenant binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for tenant grants and lookup cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Tenant binding”: “Tenant grants and lookup cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C048-T02 · Measurement method:** Choose how to observe each “Tenant binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C048-T03 · Budget decision:** Select justified resource and input limits for “Tenant binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Tenant binding” cases for “Tenant grants and lookup cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Tenant binding” limit; preserve “A grant from another tenant cannot be imported by guessing its identifier”.
- [ ] **UC-M08.06-C048-T06 · Normal measurement:** Run or review the normal “Tenant binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C048-T07 · At-limit measurement:** Exercise the “Tenant binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C048-T08 · Over-limit measurement:** Exercise the “Tenant binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C048-T09 · Uncovered-scope report:** List the “Tenant binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C048-T10 · Limit evidence:** Publish the selected “Tenant binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for tenant binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C049-T01 · Event inventory:** List the “Tenant binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Tenant binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C049-T03 · Failure mapping:** Map each documented “Tenant binding” refusal or error to a diagnostic outcome; include “A guest submits a valid cross-tenant grant token” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C049-T04 · Emission path:** Add the “Tenant binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C049-T05 · Redaction check:** Test “Tenant binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C049-T06 · Output budget:** Set and exercise bounded “Tenant binding” message size, rate and retention compatible with “Tenant grants and lookup cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C049-T07 · Success/refusal fixtures:** Capture “Tenant binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Tenant binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C049-T09 · Operator review:** Read the “Tenant binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C049-T10 · Diagnostic evidence:** Publish redacted “Tenant binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for tenant binding; label unexecuted checks as untested.

- [ ] **UC-M08.06-C050-T01 · Evidence inventory:** List the “Tenant binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C050-T02 · Artifact references:** Record the exact “Tenant binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C050-T03 · Fixture references:** Attach the “Tenant binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest submits a valid cross-tenant grant token” as a distinct evidence case.
- [ ] **UC-M08.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Tenant binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C050-T05 · Environment record:** Record the actual “Tenant binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C050-T06 · Expected versus observed:** Pair every “Tenant binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C050-T07 · Failure and limit records:** Attach “Tenant binding” change/failure and bounds evidence where required; include uncovered “Tenant grants and lookup cost” and unresolved violations of “A grant from another tenant cannot be imported by guessing its identifier”.
- [ ] **UC-M08.06-C050-T08 · Evidence hygiene:** Check the “Tenant binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C050-T09 · Reproduction review:** Have the “Tenant binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C050-T10 · Acceptance linkage:** Link the “Tenant binding” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Lifetime management

**Source delivery:** Track creation, active use and expiration without ambiguous ownership.

**Source invariant:** An expired grant cannot authorize a new access.

**Source negative case:** A long-running request reuses a grant after its lifetime expires.

**Source bounded quantities:** Grant lifetime and active references.

### UC-M08.06-C051 · Contract

**Original checklist item:** Specify lifetime management inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C051-T01 · Scope statement:** Draft the operation boundary for “Lifetime management” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Lifetime management”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C051-T03 · Output inventory:** List the outputs of “Lifetime management” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Lifetime management”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C051-T05 · Prerequisite contract:** Map “Lifetime management” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Lifetime management”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C051-T07 · Invariant clause:** Add a normative clause for “Lifetime management” that preserves “An expired grant cannot authorize a new access”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Lifetime management”; include the source counterexample “A long-running request reuses a grant after its lifetime expires” and the intended safe disposition.
- [ ] **UC-M08.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Grant lifetime and active references” in the “Lifetime management” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C051-T10 · Contract review:** Review the “Lifetime management” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C052 · Delivery

**Original checklist item:** Track creation, active use and expiration without ambiguous ownership.

- [ ] **UC-M08.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Lifetime management”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C052-T02 · Change plan:** Break the source delivery for “Lifetime management” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Lifetime management” that realizes this source instruction: Track creation, active use and expiration without ambiguous ownership.
- [ ] **UC-M08.06-C052-T04 · Concrete realization:** Trace “Lifetime management” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Lifetime management” needed to preserve “An expired grant cannot authorize a new access”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C052-T06 · Dependency connection:** Connect the “Lifetime management” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C052-T07 · Resource behavior:** Account for “Grant lifetime and active references” in “Lifetime management”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C052-T08 · Delivery check:** Run the smallest real “Lifetime management” path and its adverse fixture “A long-running request reuses a grant after its lifetime expires”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C052-T09 · Patch review:** Review the “Lifetime management” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C052-T10 · Delivery handoff:** Publish the “Lifetime management” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An expired grant cannot authorize a new access. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Lifetime management”; copy its required invariant exactly: “An expired grant cannot authorize a new access”.
- [ ] **UC-M08.06-C053-T02 · Observable terms:** Define each term in the “Lifetime management” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C053-T03 · Precondition set:** List the preconditions under which “An expired grant cannot authorize a new access” must hold for “Lifetime management”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C053-T04 · Transition coverage:** Map the “Lifetime management” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Lifetime management”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C053-T06 · Satisfying fixture:** Create a concrete “Lifetime management” case that satisfies “An expired grant cannot authorize a new access”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C053-T07 · Violating fixture:** Create the source counterexample “A long-running request reuses a grant after its lifetime expires” for “Lifetime management”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C053-T08 · Enforcement evidence:** Exercise the “Lifetime management” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C053-T09 · Regression linkage:** Link the “Lifetime management” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Lifetime management” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C054 · Integration

**Original checklist item:** Integrate lifetime management with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Lifetime management” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C054-T02 · Field mapping:** Map every “Lifetime management” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Lifetime management” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C054-T04 · Ownership agreement:** Specify who owns “Lifetime management” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C054-T05 · Handoff implementation:** Connect “Lifetime management” through the mapped seam using the real adapter or explicit specification reference; preserve “An expired grant cannot authorize a new access” across the handoff.
- [ ] **UC-M08.06-C054-T06 · Absent-input case:** Omit one required “Lifetime management” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C054-T07 · Stale-input case:** Supply an outdated “Lifetime management” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Lifetime management” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C054-T09 · Valid integration trace:** Run a valid “Lifetime management” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C054-T10 · Seam review:** Reconcile the “Lifetime management” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for lifetime management; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Lifetime management” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C055-T02 · Expected-result oracle:** Specify the “Lifetime management” expected result independently of the implementation output; include the property “An expired grant cannot authorize a new access” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C055-T03 · Fixture material:** Create the concrete “Lifetime management” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C055-T04 · Target preparation:** Prepare the “Lifetime management” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C055-T05 · Initial-state record:** Record the initial “Lifetime management” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C055-T06 · Valid-path execution:** Execute the “Lifetime management” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C055-T07 · Outcome comparison:** Compare every declared “Lifetime management” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C055-T08 · State and bounds check:** Inspect the “Lifetime management” ownership/state effects and actual use of “Grant lifetime and active references”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C055-T09 · Repeatability check:** Repeat the same “Lifetime management” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C055-T10 · Positive evidence:** Attach the “Lifetime management” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C056 · Negative test

**Original checklist item:** Negative case: A long-running request reuses a grant after its lifetime expires. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Lifetime management” source counterexample: “A long-running request reuses a grant after its lifetime expires”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Lifetime management”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C056-T03 · Valid control:** Construct a valid “Lifetime management” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C056-T04 · Minimal adverse input:** Derive the “Lifetime management” adverse fixture from the control with the smallest documented change needed to reproduce “A long-running request reuses a grant after its lifetime expires”; retain that change as reproducible data.
- [ ] **UC-M08.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Lifetime management”; require “An expired grant cannot authorize a new access” and forbid a false-success verdict.
- [ ] **UC-M08.06-C056-T06 · Adverse execution:** Exercise the “Lifetime management” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C056-T07 · Effect inspection:** Inspect “Lifetime management” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C056-T08 · Refusal versus failure:** Confirm the “Lifetime management” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C056-T09 · Reset and retention:** Restore only the disposable “Lifetime management” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C056-T10 · Negative regression:** Register the “Lifetime management” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C057 · Change / failure test

**Original checklist item:** Exercise lifetime management when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C057-T01 · Scenario record:** Write the “Lifetime management” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “An expired grant cannot authorize a new access”.
- [ ] **UC-M08.06-C057-T02 · Baseline capture:** Create a known-valid “Lifetime management” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C057-T03 · Injection map:** Locate the “Lifetime management” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Lifetime management” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C057-T05 · Controlled trigger:** Introduce the controlled “Lifetime management” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C057-T06 · Intermediate inspection:** Inspect the “Lifetime management” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Lifetime management”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Lifetime management” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C057-T09 · Repeat and compare:** Repeat the selected “Lifetime management” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C057-T10 · Failure evidence:** Publish the “Lifetime management” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for grant lifetime and active references; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Lifetime management”: “Grant lifetime and active references”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C058-T02 · Measurement method:** Choose how to observe each “Lifetime management” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C058-T03 · Budget decision:** Select justified resource and input limits for “Lifetime management”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Lifetime management” cases for “Grant lifetime and active references”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Lifetime management” limit; preserve “An expired grant cannot authorize a new access”.
- [ ] **UC-M08.06-C058-T06 · Normal measurement:** Run or review the normal “Lifetime management” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C058-T07 · At-limit measurement:** Exercise the “Lifetime management” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C058-T08 · Over-limit measurement:** Exercise the “Lifetime management” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C058-T09 · Uncovered-scope report:** List the “Lifetime management” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C058-T10 · Limit evidence:** Publish the selected “Lifetime management” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for lifetime management with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C059-T01 · Event inventory:** List the “Lifetime management” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Lifetime management” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C059-T03 · Failure mapping:** Map each documented “Lifetime management” refusal or error to a diagnostic outcome; include “A long-running request reuses a grant after its lifetime expires” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C059-T04 · Emission path:** Add the “Lifetime management” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C059-T05 · Redaction check:** Test “Lifetime management” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C059-T06 · Output budget:** Set and exercise bounded “Lifetime management” message size, rate and retention compatible with “Grant lifetime and active references”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C059-T07 · Success/refusal fixtures:** Capture “Lifetime management” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Lifetime management” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C059-T09 · Operator review:** Read the “Lifetime management” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C059-T10 · Diagnostic evidence:** Publish redacted “Lifetime management” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for lifetime management; label unexecuted checks as untested.

- [ ] **UC-M08.06-C060-T01 · Evidence inventory:** List the “Lifetime management” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C060-T02 · Artifact references:** Record the exact “Lifetime management” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C060-T03 · Fixture references:** Attach the “Lifetime management” fixture IDs, input identities and oracle definition; preserve the source counterexample “A long-running request reuses a grant after its lifetime expires” as a distinct evidence case.
- [ ] **UC-M08.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Lifetime management”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C060-T05 · Environment record:** Record the actual “Lifetime management” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C060-T06 · Expected versus observed:** Pair every “Lifetime management” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C060-T07 · Failure and limit records:** Attach “Lifetime management” change/failure and bounds evidence where required; include uncovered “Grant lifetime and active references” and unresolved violations of “An expired grant cannot authorize a new access”.
- [ ] **UC-M08.06-C060-T08 · Evidence hygiene:** Check the “Lifetime management” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C060-T09 · Reproduction review:** Have the “Lifetime management” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C060-T10 · Acceptance linkage:** Link the “Lifetime management” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Revocation semantics

**Source delivery:** Define when revocation takes effect and how in-flight users are handled.

**Source invariant:** A revoked grant cannot be used by newly arriving operations.

**Source negative case:** An access begins after revocation was acknowledged.

**Source bounded quantities:** Revocation latency and in-flight users.

### UC-M08.06-C061 · Contract

**Original checklist item:** Specify revocation semantics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C061-T01 · Scope statement:** Draft the operation boundary for “Revocation semantics” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Revocation semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C061-T03 · Output inventory:** List the outputs of “Revocation semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Revocation semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C061-T05 · Prerequisite contract:** Map “Revocation semantics” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Revocation semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C061-T07 · Invariant clause:** Add a normative clause for “Revocation semantics” that preserves “A revoked grant cannot be used by newly arriving operations”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Revocation semantics”; include the source counterexample “An access begins after revocation was acknowledged” and the intended safe disposition.
- [ ] **UC-M08.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Revocation latency and in-flight users” in the “Revocation semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C061-T10 · Contract review:** Review the “Revocation semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C062 · Delivery

**Original checklist item:** Define when revocation takes effect and how in-flight users are handled.

- [ ] **UC-M08.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Revocation semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C062-T02 · Change plan:** Break the source delivery for “Revocation semantics” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C062-T03 · Core artifact:** Create the “Revocation semantics” model, schema or inventory that realizes this source instruction: Define when revocation takes effect and how in-flight users are handled.
- [ ] **UC-M08.06-C062-T04 · Concrete realization:** Populate “Revocation semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Revocation semantics” needed to preserve “A revoked grant cannot be used by newly arriving operations”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C062-T06 · Dependency connection:** Connect the “Revocation semantics” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C062-T07 · Resource behavior:** Account for “Revocation latency and in-flight users” in “Revocation semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C062-T08 · Delivery check:** Run the smallest real “Revocation semantics” path and its adverse fixture “An access begins after revocation was acknowledged”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C062-T09 · Patch review:** Review the “Revocation semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C062-T10 · Delivery handoff:** Publish the “Revocation semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A revoked grant cannot be used by newly arriving operations. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Revocation semantics”; copy its required invariant exactly: “A revoked grant cannot be used by newly arriving operations”.
- [ ] **UC-M08.06-C063-T02 · Observable terms:** Define each term in the “Revocation semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C063-T03 · Precondition set:** List the preconditions under which “A revoked grant cannot be used by newly arriving operations” must hold for “Revocation semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C063-T04 · Transition coverage:** Map the “Revocation semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Revocation semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C063-T06 · Satisfying fixture:** Create a concrete “Revocation semantics” case that satisfies “A revoked grant cannot be used by newly arriving operations”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C063-T07 · Violating fixture:** Create the source counterexample “An access begins after revocation was acknowledged” for “Revocation semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C063-T08 · Enforcement evidence:** Exercise the “Revocation semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C063-T09 · Regression linkage:** Link the “Revocation semantics” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Revocation semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C064 · Integration

**Original checklist item:** Integrate revocation semantics with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Revocation semantics” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C064-T02 · Field mapping:** Map every “Revocation semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Revocation semantics” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C064-T04 · Ownership agreement:** Specify who owns “Revocation semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C064-T05 · Handoff implementation:** Connect “Revocation semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “A revoked grant cannot be used by newly arriving operations” across the handoff.
- [ ] **UC-M08.06-C064-T06 · Absent-input case:** Omit one required “Revocation semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C064-T07 · Stale-input case:** Supply an outdated “Revocation semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Revocation semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C064-T09 · Valid integration trace:** Run a valid “Revocation semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C064-T10 · Seam review:** Reconcile the “Revocation semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for revocation semantics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Revocation semantics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C065-T02 · Expected-result oracle:** Specify the “Revocation semantics” expected result independently of the implementation output; include the property “A revoked grant cannot be used by newly arriving operations” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C065-T03 · Fixture material:** Create the concrete “Revocation semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C065-T04 · Target preparation:** Prepare the “Revocation semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C065-T05 · Initial-state record:** Record the initial “Revocation semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C065-T06 · Valid-path execution:** Execute the “Revocation semantics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C065-T07 · Outcome comparison:** Compare every declared “Revocation semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C065-T08 · State and bounds check:** Inspect the “Revocation semantics” ownership/state effects and actual use of “Revocation latency and in-flight users”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C065-T09 · Repeatability check:** Repeat the same “Revocation semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C065-T10 · Positive evidence:** Attach the “Revocation semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C066 · Negative test

**Original checklist item:** Negative case: An access begins after revocation was acknowledged. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Revocation semantics” source counterexample: “An access begins after revocation was acknowledged”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Revocation semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C066-T03 · Valid control:** Construct a valid “Revocation semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C066-T04 · Minimal adverse input:** Derive the “Revocation semantics” adverse fixture from the control with the smallest documented change needed to reproduce “An access begins after revocation was acknowledged”; retain that change as reproducible data.
- [ ] **UC-M08.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Revocation semantics”; require “A revoked grant cannot be used by newly arriving operations” and forbid a false-success verdict.
- [ ] **UC-M08.06-C066-T06 · Adverse execution:** Exercise the “Revocation semantics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C066-T07 · Effect inspection:** Inspect “Revocation semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C066-T08 · Refusal versus failure:** Confirm the “Revocation semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C066-T09 · Reset and retention:** Restore only the disposable “Revocation semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C066-T10 · Negative regression:** Register the “Revocation semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C067 · Change / failure test

**Original checklist item:** Exercise revocation semantics when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C067-T01 · Scenario record:** Write the “Revocation semantics” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “A revoked grant cannot be used by newly arriving operations”.
- [ ] **UC-M08.06-C067-T02 · Baseline capture:** Create a known-valid “Revocation semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C067-T03 · Injection map:** Locate the “Revocation semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Revocation semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C067-T05 · Controlled trigger:** Introduce the controlled “Revocation semantics” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C067-T06 · Intermediate inspection:** Inspect the “Revocation semantics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Revocation semantics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Revocation semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C067-T09 · Repeat and compare:** Repeat the selected “Revocation semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C067-T10 · Failure evidence:** Publish the “Revocation semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for revocation latency and in-flight users; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Revocation semantics”: “Revocation latency and in-flight users”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C068-T02 · Measurement method:** Choose how to observe each “Revocation semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Revocation semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Revocation semantics” cases for “Revocation latency and in-flight users”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Revocation semantics” limit; preserve “A revoked grant cannot be used by newly arriving operations”.
- [ ] **UC-M08.06-C068-T06 · Normal measurement:** Run or review the normal “Revocation semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C068-T07 · At-limit measurement:** Exercise the “Revocation semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C068-T08 · Over-limit measurement:** Exercise the “Revocation semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C068-T09 · Uncovered-scope report:** List the “Revocation semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C068-T10 · Limit evidence:** Publish the selected “Revocation semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for revocation semantics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C069-T01 · Event inventory:** List the “Revocation semantics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Revocation semantics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C069-T03 · Failure mapping:** Map each documented “Revocation semantics” refusal or error to a diagnostic outcome; include “An access begins after revocation was acknowledged” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C069-T04 · Emission path:** Add the “Revocation semantics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C069-T05 · Redaction check:** Test “Revocation semantics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C069-T06 · Output budget:** Set and exercise bounded “Revocation semantics” message size, rate and retention compatible with “Revocation latency and in-flight users”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C069-T07 · Success/refusal fixtures:** Capture “Revocation semantics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Revocation semantics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C069-T09 · Operator review:** Read the “Revocation semantics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C069-T10 · Diagnostic evidence:** Publish redacted “Revocation semantics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for revocation semantics; label unexecuted checks as untested.

- [ ] **UC-M08.06-C070-T01 · Evidence inventory:** List the “Revocation semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C070-T02 · Artifact references:** Record the exact “Revocation semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C070-T03 · Fixture references:** Attach the “Revocation semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “An access begins after revocation was acknowledged” as a distinct evidence case.
- [ ] **UC-M08.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Revocation semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C070-T05 · Environment record:** Record the actual “Revocation semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C070-T06 · Expected versus observed:** Pair every “Revocation semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C070-T07 · Failure and limit records:** Attach “Revocation semantics” change/failure and bounds evidence where required; include uncovered “Revocation latency and in-flight users” and unresolved violations of “A revoked grant cannot be used by newly arriving operations”.
- [ ] **UC-M08.06-C070-T08 · Evidence hygiene:** Check the “Revocation semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C070-T09 · Reproduction review:** Have the “Revocation semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C070-T10 · Acceptance linkage:** Link the “Revocation semantics” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Stop and replacement cleanup

**Source delivery:** Revoke grants when their owning generation stops or is replaced.

**Source invariant:** A stale generation cannot retain memory access after replacement.

**Source negative case:** A stopped guest accesses a still-mapped grant.

**Source bounded quantities:** Retired mappings and cleanup deadline.

### UC-M08.06-C071 · Contract

**Original checklist item:** Specify stop and replacement cleanup inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C071-T01 · Scope statement:** Draft the operation boundary for “Stop and replacement cleanup” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Stop and replacement cleanup”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C071-T03 · Output inventory:** List the outputs of “Stop and replacement cleanup” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Stop and replacement cleanup”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C071-T05 · Prerequisite contract:** Map “Stop and replacement cleanup” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Stop and replacement cleanup”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C071-T07 · Invariant clause:** Add a normative clause for “Stop and replacement cleanup” that preserves “A stale generation cannot retain memory access after replacement”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Stop and replacement cleanup”; include the source counterexample “A stopped guest accesses a still-mapped grant” and the intended safe disposition.
- [ ] **UC-M08.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retired mappings and cleanup deadline” in the “Stop and replacement cleanup” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C071-T10 · Contract review:** Review the “Stop and replacement cleanup” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C072 · Delivery

**Original checklist item:** Revoke grants when their owning generation stops or is replaced.

- [ ] **UC-M08.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Stop and replacement cleanup”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C072-T02 · Change plan:** Break the source delivery for “Stop and replacement cleanup” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Stop and replacement cleanup” that realizes this source instruction: Revoke grants when their owning generation stops or is replaced.
- [ ] **UC-M08.06-C072-T04 · Concrete realization:** Trace “Stop and replacement cleanup” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Stop and replacement cleanup” needed to preserve “A stale generation cannot retain memory access after replacement”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C072-T06 · Dependency connection:** Connect the “Stop and replacement cleanup” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C072-T07 · Resource behavior:** Account for “Retired mappings and cleanup deadline” in “Stop and replacement cleanup”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C072-T08 · Delivery check:** Run the smallest real “Stop and replacement cleanup” path and its adverse fixture “A stopped guest accesses a still-mapped grant”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C072-T09 · Patch review:** Review the “Stop and replacement cleanup” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C072-T10 · Delivery handoff:** Publish the “Stop and replacement cleanup” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stale generation cannot retain memory access after replacement. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Stop and replacement cleanup”; copy its required invariant exactly: “A stale generation cannot retain memory access after replacement”.
- [ ] **UC-M08.06-C073-T02 · Observable terms:** Define each term in the “Stop and replacement cleanup” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C073-T03 · Precondition set:** List the preconditions under which “A stale generation cannot retain memory access after replacement” must hold for “Stop and replacement cleanup”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C073-T04 · Transition coverage:** Map the “Stop and replacement cleanup” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Stop and replacement cleanup”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C073-T06 · Satisfying fixture:** Create a concrete “Stop and replacement cleanup” case that satisfies “A stale generation cannot retain memory access after replacement”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C073-T07 · Violating fixture:** Create the source counterexample “A stopped guest accesses a still-mapped grant” for “Stop and replacement cleanup”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C073-T08 · Enforcement evidence:** Exercise the “Stop and replacement cleanup” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C073-T09 · Regression linkage:** Link the “Stop and replacement cleanup” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Stop and replacement cleanup” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C074 · Integration

**Original checklist item:** Integrate stop and replacement cleanup with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Stop and replacement cleanup” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C074-T02 · Field mapping:** Map every “Stop and replacement cleanup” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Stop and replacement cleanup” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C074-T04 · Ownership agreement:** Specify who owns “Stop and replacement cleanup” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C074-T05 · Handoff implementation:** Connect “Stop and replacement cleanup” through the mapped seam using the real adapter or explicit specification reference; preserve “A stale generation cannot retain memory access after replacement” across the handoff.
- [ ] **UC-M08.06-C074-T06 · Absent-input case:** Omit one required “Stop and replacement cleanup” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C074-T07 · Stale-input case:** Supply an outdated “Stop and replacement cleanup” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Stop and replacement cleanup” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C074-T09 · Valid integration trace:** Run a valid “Stop and replacement cleanup” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C074-T10 · Seam review:** Reconcile the “Stop and replacement cleanup” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for stop and replacement cleanup; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Stop and replacement cleanup” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C075-T02 · Expected-result oracle:** Specify the “Stop and replacement cleanup” expected result independently of the implementation output; include the property “A stale generation cannot retain memory access after replacement” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C075-T03 · Fixture material:** Create the concrete “Stop and replacement cleanup” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C075-T04 · Target preparation:** Prepare the “Stop and replacement cleanup” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C075-T05 · Initial-state record:** Record the initial “Stop and replacement cleanup” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C075-T06 · Valid-path execution:** Execute the “Stop and replacement cleanup” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C075-T07 · Outcome comparison:** Compare every declared “Stop and replacement cleanup” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C075-T08 · State and bounds check:** Inspect the “Stop and replacement cleanup” ownership/state effects and actual use of “Retired mappings and cleanup deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C075-T09 · Repeatability check:** Repeat the same “Stop and replacement cleanup” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C075-T10 · Positive evidence:** Attach the “Stop and replacement cleanup” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C076 · Negative test

**Original checklist item:** Negative case: A stopped guest accesses a still-mapped grant. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Stop and replacement cleanup” source counterexample: “A stopped guest accesses a still-mapped grant”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Stop and replacement cleanup”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C076-T03 · Valid control:** Construct a valid “Stop and replacement cleanup” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C076-T04 · Minimal adverse input:** Derive the “Stop and replacement cleanup” adverse fixture from the control with the smallest documented change needed to reproduce “A stopped guest accesses a still-mapped grant”; retain that change as reproducible data.
- [ ] **UC-M08.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Stop and replacement cleanup”; require “A stale generation cannot retain memory access after replacement” and forbid a false-success verdict.
- [ ] **UC-M08.06-C076-T06 · Adverse execution:** Exercise the “Stop and replacement cleanup” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C076-T07 · Effect inspection:** Inspect “Stop and replacement cleanup” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C076-T08 · Refusal versus failure:** Confirm the “Stop and replacement cleanup” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C076-T09 · Reset and retention:** Restore only the disposable “Stop and replacement cleanup” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C076-T10 · Negative regression:** Register the “Stop and replacement cleanup” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C077 · Change / failure test

**Original checklist item:** Exercise stop and replacement cleanup when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C077-T01 · Scenario record:** Write the “Stop and replacement cleanup” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “A stale generation cannot retain memory access after replacement”.
- [ ] **UC-M08.06-C077-T02 · Baseline capture:** Create a known-valid “Stop and replacement cleanup” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C077-T03 · Injection map:** Locate the “Stop and replacement cleanup” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Stop and replacement cleanup” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C077-T05 · Controlled trigger:** Introduce the controlled “Stop and replacement cleanup” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C077-T06 · Intermediate inspection:** Inspect the “Stop and replacement cleanup” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Stop and replacement cleanup”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Stop and replacement cleanup” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C077-T09 · Repeat and compare:** Repeat the selected “Stop and replacement cleanup” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C077-T10 · Failure evidence:** Publish the “Stop and replacement cleanup” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for retired mappings and cleanup deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Stop and replacement cleanup”: “Retired mappings and cleanup deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C078-T02 · Measurement method:** Choose how to observe each “Stop and replacement cleanup” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C078-T03 · Budget decision:** Select justified resource and input limits for “Stop and replacement cleanup”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Stop and replacement cleanup” cases for “Retired mappings and cleanup deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Stop and replacement cleanup” limit; preserve “A stale generation cannot retain memory access after replacement”.
- [ ] **UC-M08.06-C078-T06 · Normal measurement:** Run or review the normal “Stop and replacement cleanup” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C078-T07 · At-limit measurement:** Exercise the “Stop and replacement cleanup” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C078-T08 · Over-limit measurement:** Exercise the “Stop and replacement cleanup” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C078-T09 · Uncovered-scope report:** List the “Stop and replacement cleanup” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C078-T10 · Limit evidence:** Publish the selected “Stop and replacement cleanup” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for stop and replacement cleanup with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C079-T01 · Event inventory:** List the “Stop and replacement cleanup” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Stop and replacement cleanup” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C079-T03 · Failure mapping:** Map each documented “Stop and replacement cleanup” refusal or error to a diagnostic outcome; include “A stopped guest accesses a still-mapped grant” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C079-T04 · Emission path:** Add the “Stop and replacement cleanup” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C079-T05 · Redaction check:** Test “Stop and replacement cleanup” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C079-T06 · Output budget:** Set and exercise bounded “Stop and replacement cleanup” message size, rate and retention compatible with “Retired mappings and cleanup deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C079-T07 · Success/refusal fixtures:** Capture “Stop and replacement cleanup” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Stop and replacement cleanup” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C079-T09 · Operator review:** Read the “Stop and replacement cleanup” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C079-T10 · Diagnostic evidence:** Publish redacted “Stop and replacement cleanup” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for stop and replacement cleanup; label unexecuted checks as untested.

- [ ] **UC-M08.06-C080-T01 · Evidence inventory:** List the “Stop and replacement cleanup” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C080-T02 · Artifact references:** Record the exact “Stop and replacement cleanup” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C080-T03 · Fixture references:** Attach the “Stop and replacement cleanup” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stopped guest accesses a still-mapped grant” as a distinct evidence case.
- [ ] **UC-M08.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Stop and replacement cleanup”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C080-T05 · Environment record:** Record the actual “Stop and replacement cleanup” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C080-T06 · Expected versus observed:** Pair every “Stop and replacement cleanup” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C080-T07 · Failure and limit records:** Attach “Stop and replacement cleanup” change/failure and bounds evidence where required; include uncovered “Retired mappings and cleanup deadline” and unresolved violations of “A stale generation cannot retain memory access after replacement”.
- [ ] **UC-M08.06-C080-T08 · Evidence hygiene:** Check the “Stop and replacement cleanup” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C080-T09 · Reproduction review:** Have the “Stop and replacement cleanup” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C080-T10 · Acceptance linkage:** Link the “Stop and replacement cleanup” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Channel reset behavior

**Source delivery:** Invalidate or revalidate grants across transport resets as specified.

**Source invariant:** Reset cannot accidentally revive previously revoked authority.

**Source negative case:** A reset reuses old grant IDs without checking ownership.

**Source bounded quantities:** Reset frequency and stale grant records.

### UC-M08.06-C081 · Contract

**Original checklist item:** Specify channel reset behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C081-T01 · Scope statement:** Draft the operation boundary for “Channel reset behavior” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Channel reset behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C081-T03 · Output inventory:** List the outputs of “Channel reset behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Channel reset behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C081-T05 · Prerequisite contract:** Map “Channel reset behavior” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Channel reset behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C081-T07 · Invariant clause:** Add a normative clause for “Channel reset behavior” that preserves “Reset cannot accidentally revive previously revoked authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Channel reset behavior”; include the source counterexample “A reset reuses old grant IDs without checking ownership” and the intended safe disposition.
- [ ] **UC-M08.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reset frequency and stale grant records” in the “Channel reset behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C081-T10 · Contract review:** Review the “Channel reset behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C082 · Delivery

**Original checklist item:** Invalidate or revalidate grants across transport resets as specified.

- [ ] **UC-M08.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Channel reset behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C082-T02 · Change plan:** Break the source delivery for “Channel reset behavior” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Channel reset behavior” that realizes this source instruction: Invalidate or revalidate grants across transport resets as specified.
- [ ] **UC-M08.06-C082-T04 · Concrete realization:** Trace “Channel reset behavior” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Channel reset behavior” needed to preserve “Reset cannot accidentally revive previously revoked authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C082-T06 · Dependency connection:** Connect the “Channel reset behavior” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C082-T07 · Resource behavior:** Account for “Reset frequency and stale grant records” in “Channel reset behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C082-T08 · Delivery check:** Run the smallest real “Channel reset behavior” path and its adverse fixture “A reset reuses old grant IDs without checking ownership”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C082-T09 · Patch review:** Review the “Channel reset behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C082-T10 · Delivery handoff:** Publish the “Channel reset behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Reset cannot accidentally revive previously revoked authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Channel reset behavior”; copy its required invariant exactly: “Reset cannot accidentally revive previously revoked authority”.
- [ ] **UC-M08.06-C083-T02 · Observable terms:** Define each term in the “Channel reset behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C083-T03 · Precondition set:** List the preconditions under which “Reset cannot accidentally revive previously revoked authority” must hold for “Channel reset behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C083-T04 · Transition coverage:** Map the “Channel reset behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Channel reset behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C083-T06 · Satisfying fixture:** Create a concrete “Channel reset behavior” case that satisfies “Reset cannot accidentally revive previously revoked authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C083-T07 · Violating fixture:** Create the source counterexample “A reset reuses old grant IDs without checking ownership” for “Channel reset behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C083-T08 · Enforcement evidence:** Exercise the “Channel reset behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C083-T09 · Regression linkage:** Link the “Channel reset behavior” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Channel reset behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C084 · Integration

**Original checklist item:** Integrate channel reset behavior with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Channel reset behavior” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C084-T02 · Field mapping:** Map every “Channel reset behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Channel reset behavior” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C084-T04 · Ownership agreement:** Specify who owns “Channel reset behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C084-T05 · Handoff implementation:** Connect “Channel reset behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Reset cannot accidentally revive previously revoked authority” across the handoff.
- [ ] **UC-M08.06-C084-T06 · Absent-input case:** Omit one required “Channel reset behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C084-T07 · Stale-input case:** Supply an outdated “Channel reset behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Channel reset behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C084-T09 · Valid integration trace:** Run a valid “Channel reset behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C084-T10 · Seam review:** Reconcile the “Channel reset behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for channel reset behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Channel reset behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C085-T02 · Expected-result oracle:** Specify the “Channel reset behavior” expected result independently of the implementation output; include the property “Reset cannot accidentally revive previously revoked authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C085-T03 · Fixture material:** Create the concrete “Channel reset behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C085-T04 · Target preparation:** Prepare the “Channel reset behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C085-T05 · Initial-state record:** Record the initial “Channel reset behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C085-T06 · Valid-path execution:** Execute the “Channel reset behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C085-T07 · Outcome comparison:** Compare every declared “Channel reset behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C085-T08 · State and bounds check:** Inspect the “Channel reset behavior” ownership/state effects and actual use of “Reset frequency and stale grant records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C085-T09 · Repeatability check:** Repeat the same “Channel reset behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C085-T10 · Positive evidence:** Attach the “Channel reset behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C086 · Negative test

**Original checklist item:** Negative case: A reset reuses old grant IDs without checking ownership. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Channel reset behavior” source counterexample: “A reset reuses old grant IDs without checking ownership”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Channel reset behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C086-T03 · Valid control:** Construct a valid “Channel reset behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C086-T04 · Minimal adverse input:** Derive the “Channel reset behavior” adverse fixture from the control with the smallest documented change needed to reproduce “A reset reuses old grant IDs without checking ownership”; retain that change as reproducible data.
- [ ] **UC-M08.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Channel reset behavior”; require “Reset cannot accidentally revive previously revoked authority” and forbid a false-success verdict.
- [ ] **UC-M08.06-C086-T06 · Adverse execution:** Exercise the “Channel reset behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C086-T07 · Effect inspection:** Inspect “Channel reset behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C086-T08 · Refusal versus failure:** Confirm the “Channel reset behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C086-T09 · Reset and retention:** Restore only the disposable “Channel reset behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C086-T10 · Negative regression:** Register the “Channel reset behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C087 · Change / failure test

**Original checklist item:** Exercise channel reset behavior when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C087-T01 · Scenario record:** Write the “Channel reset behavior” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “Reset cannot accidentally revive previously revoked authority”.
- [ ] **UC-M08.06-C087-T02 · Baseline capture:** Create a known-valid “Channel reset behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C087-T03 · Injection map:** Locate the “Channel reset behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Channel reset behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C087-T05 · Controlled trigger:** Introduce the controlled “Channel reset behavior” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C087-T06 · Intermediate inspection:** Inspect the “Channel reset behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Channel reset behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Channel reset behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C087-T09 · Repeat and compare:** Repeat the selected “Channel reset behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C087-T10 · Failure evidence:** Publish the “Channel reset behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for reset frequency and stale grant records; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Channel reset behavior”: “Reset frequency and stale grant records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C088-T02 · Measurement method:** Choose how to observe each “Channel reset behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Channel reset behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Channel reset behavior” cases for “Reset frequency and stale grant records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Channel reset behavior” limit; preserve “Reset cannot accidentally revive previously revoked authority”.
- [ ] **UC-M08.06-C088-T06 · Normal measurement:** Run or review the normal “Channel reset behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C088-T07 · At-limit measurement:** Exercise the “Channel reset behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C088-T08 · Over-limit measurement:** Exercise the “Channel reset behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C088-T09 · Uncovered-scope report:** List the “Channel reset behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C088-T10 · Limit evidence:** Publish the selected “Channel reset behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for channel reset behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C089-T01 · Event inventory:** List the “Channel reset behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Channel reset behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C089-T03 · Failure mapping:** Map each documented “Channel reset behavior” refusal or error to a diagnostic outcome; include “A reset reuses old grant IDs without checking ownership” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C089-T04 · Emission path:** Add the “Channel reset behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C089-T05 · Redaction check:** Test “Channel reset behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C089-T06 · Output budget:** Set and exercise bounded “Channel reset behavior” message size, rate and retention compatible with “Reset frequency and stale grant records”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C089-T07 · Success/refusal fixtures:** Capture “Channel reset behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Channel reset behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C089-T09 · Operator review:** Read the “Channel reset behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C089-T10 · Diagnostic evidence:** Publish redacted “Channel reset behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for channel reset behavior; label unexecuted checks as untested.

- [ ] **UC-M08.06-C090-T01 · Evidence inventory:** List the “Channel reset behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C090-T02 · Artifact references:** Record the exact “Channel reset behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C090-T03 · Fixture references:** Attach the “Channel reset behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “A reset reuses old grant IDs without checking ownership” as a distinct evidence case.
- [ ] **UC-M08.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Channel reset behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C090-T05 · Environment record:** Record the actual “Channel reset behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C090-T06 · Expected versus observed:** Pair every “Channel reset behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C090-T07 · Failure and limit records:** Attach “Channel reset behavior” change/failure and bounds evidence where required; include uncovered “Reset frequency and stale grant records” and unresolved violations of “Reset cannot accidentally revive previously revoked authority”.
- [ ] **UC-M08.06-C090-T08 · Evidence hygiene:** Check the “Channel reset behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C090-T09 · Reproduction review:** Have the “Channel reset behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C090-T10 · Acceptance linkage:** Link the “Channel reset behavior” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Grant safety qualification

**Source delivery:** Test bounds, direction, cross-tenant use and use-after-revocation.

**Source invariant:** The selected grant profile passes its declared lifetime and isolation tests.

**Source negative case:** A revoked grant remains accessible through a cached mapping.

**Source bounded quantities:** Grant corpus and concurrent access trials.

### UC-M08.06-C091 · Contract

**Original checklist item:** Specify grant safety qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.06-C091-T01 · Scope statement:** Draft the operation boundary for “Grant safety qualification” within Shared-memory or buffer grant safety; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Grant safety qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.06-C091-T03 · Output inventory:** List the outputs of “Grant safety qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Grant safety qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.06-C091-T05 · Prerequisite contract:** Map “Grant safety qualification” to the source component prerequisites (UC-M06.04, UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Grant safety qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.06-C091-T07 · Invariant clause:** Add a normative clause for “Grant safety qualification” that preserves “The selected grant profile passes its declared lifetime and isolation tests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Grant safety qualification”; include the source counterexample “A revoked grant remains accessible through a cached mapping” and the intended safe disposition.
- [ ] **UC-M08.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Grant corpus and concurrent access trials” in the “Grant safety qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.06-C091-T10 · Contract review:** Review the “Grant safety qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.06-C092 · Delivery

**Original checklist item:** Test bounds, direction, cross-tenant use and use-after-revocation.

- [ ] **UC-M08.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Grant safety qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.06-C092-T02 · Change plan:** Break the source delivery for “Grant safety qualification” into concrete edit targets and reviewable outputs; keep the UC-M08.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.06-C092-T03 · Core artifact:** Create the “Grant safety qualification” fixture or harness for this source instruction: Test bounds, direction, cross-tenant use and use-after-revocation.
- [ ] **UC-M08.06-C092-T04 · Concrete realization:** Connect the “Grant safety qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M08.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Grant safety qualification” needed to preserve “The selected grant profile passes its declared lifetime and isolation tests”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.06-C092-T06 · Dependency connection:** Connect the “Grant safety qualification” implementation to buffer ownership, tenant-scoped grants and stop/reset revocation; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.06-C092-T07 · Resource behavior:** Account for “Grant corpus and concurrent access trials” in “Grant safety qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.06-C092-T08 · Delivery check:** Run the smallest real “Grant safety qualification” path and its adverse fixture “A revoked grant remains accessible through a cached mapping”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.06-C092-T09 · Patch review:** Review the “Grant safety qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.06-C092-T10 · Delivery handoff:** Publish the “Grant safety qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The selected grant profile passes its declared lifetime and isolation tests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Grant safety qualification”; copy its required invariant exactly: “The selected grant profile passes its declared lifetime and isolation tests”.
- [ ] **UC-M08.06-C093-T02 · Observable terms:** Define each term in the “Grant safety qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.06-C093-T03 · Precondition set:** List the preconditions under which “The selected grant profile passes its declared lifetime and isolation tests” must hold for “Grant safety qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.06-C093-T04 · Transition coverage:** Map the “Grant safety qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Grant safety qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.06-C093-T06 · Satisfying fixture:** Create a concrete “Grant safety qualification” case that satisfies “The selected grant profile passes its declared lifetime and isolation tests”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.06-C093-T07 · Violating fixture:** Create the source counterexample “A revoked grant remains accessible through a cached mapping” for “Grant safety qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.06-C093-T08 · Enforcement evidence:** Exercise the “Grant safety qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.06-C093-T09 · Regression linkage:** Link the “Grant safety qualification” property to changes in buffer ownership, tenant-scoped grants and stop/reset revocation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Grant safety qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.06-C094 · Integration

**Original checklist item:** Integrate grant safety qualification with buffer ownership, tenant-scoped grants and stop/reset revocation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Grant safety qualification” across buffer ownership, tenant-scoped grants and stop/reset revocation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.06-C094-T02 · Field mapping:** Map every “Grant safety qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Grant safety qualification” (source dependency list: UC-M06.04, UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.06-C094-T04 · Ownership agreement:** Specify who owns “Grant safety qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.06-C094-T05 · Handoff implementation:** Connect “Grant safety qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “The selected grant profile passes its declared lifetime and isolation tests” across the handoff.
- [ ] **UC-M08.06-C094-T06 · Absent-input case:** Omit one required “Grant safety qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.06-C094-T07 · Stale-input case:** Supply an outdated “Grant safety qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Grant safety qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.06-C094-T09 · Valid integration trace:** Run a valid “Grant safety qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.06-C094-T10 · Seam review:** Reconcile the “Grant safety qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for grant safety qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Grant safety qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.06-C095-T02 · Expected-result oracle:** Specify the “Grant safety qualification” expected result independently of the implementation output; include the property “The selected grant profile passes its declared lifetime and isolation tests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.06-C095-T03 · Fixture material:** Create the concrete “Grant safety qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.06-C095-T04 · Target preparation:** Prepare the “Grant safety qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.06-C095-T05 · Initial-state record:** Record the initial “Grant safety qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.06-C095-T06 · Valid-path execution:** Execute the “Grant safety qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.06-C095-T07 · Outcome comparison:** Compare every declared “Grant safety qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.06-C095-T08 · State and bounds check:** Inspect the “Grant safety qualification” ownership/state effects and actual use of “Grant corpus and concurrent access trials”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.06-C095-T09 · Repeatability check:** Repeat the same “Grant safety qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.06-C095-T10 · Positive evidence:** Attach the “Grant safety qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.06-C096 · Negative test

**Original checklist item:** Negative case: A revoked grant remains accessible through a cached mapping. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Grant safety qualification” source counterexample: “A revoked grant remains accessible through a cached mapping”; state which precondition or invariant it challenges.
- [ ] **UC-M08.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Grant safety qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.06-C096-T03 · Valid control:** Construct a valid “Grant safety qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.06-C096-T04 · Minimal adverse input:** Derive the “Grant safety qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A revoked grant remains accessible through a cached mapping”; retain that change as reproducible data.
- [ ] **UC-M08.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Grant safety qualification”; require “The selected grant profile passes its declared lifetime and isolation tests” and forbid a false-success verdict.
- [ ] **UC-M08.06-C096-T06 · Adverse execution:** Exercise the “Grant safety qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.06-C096-T07 · Effect inspection:** Inspect “Grant safety qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.06-C096-T08 · Refusal versus failure:** Confirm the “Grant safety qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.06-C096-T09 · Reset and retention:** Restore only the disposable “Grant safety qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.06-C096-T10 · Negative regression:** Register the “Grant safety qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.06-C097 · Change / failure test

**Original checklist item:** Exercise grant safety qualification when a grant is revoked while an old-generation operation still retains a reference; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.06-C097-T01 · Scenario record:** Write the “Grant safety qualification” change/failure scenario exactly as supplied: a grant is revoked while an old-generation operation still retains a reference; identify the property that must remain true: “The selected grant profile passes its declared lifetime and isolation tests”.
- [ ] **UC-M08.06-C097-T02 · Baseline capture:** Create a known-valid “Grant safety qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.06-C097-T03 · Injection map:** Locate the “Grant safety qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Grant safety qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.06-C097-T05 · Controlled trigger:** Introduce the controlled “Grant safety qualification” scenario in the disposable fixture: a grant is revoked while an old-generation operation still retains a reference; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.06-C097-T06 · Intermediate inspection:** Inspect the “Grant safety qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Grant safety qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Grant safety qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.06-C097-T09 · Repeat and compare:** Repeat the selected “Grant safety qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.06-C097-T10 · Failure evidence:** Publish the “Grant safety qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for grant corpus and concurrent access trials; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Grant safety qualification”: “Grant corpus and concurrent access trials”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.06-C098-T02 · Measurement method:** Choose how to observe each “Grant safety qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Grant safety qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Grant safety qualification” cases for “Grant corpus and concurrent access trials”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Grant safety qualification” limit; preserve “The selected grant profile passes its declared lifetime and isolation tests”.
- [ ] **UC-M08.06-C098-T06 · Normal measurement:** Run or review the normal “Grant safety qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.06-C098-T07 · At-limit measurement:** Exercise the “Grant safety qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.06-C098-T08 · Over-limit measurement:** Exercise the “Grant safety qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.06-C098-T09 · Uncovered-scope report:** List the “Grant safety qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.06-C098-T10 · Limit evidence:** Publish the selected “Grant safety qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for grant safety qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.06-C099-T01 · Event inventory:** List the “Grant safety qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Grant safety qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.06-C099-T03 · Failure mapping:** Map each documented “Grant safety qualification” refusal or error to a diagnostic outcome; include “A revoked grant remains accessible through a cached mapping” and prohibit conversion into a success message.
- [ ] **UC-M08.06-C099-T04 · Emission path:** Add the “Grant safety qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.06-C099-T05 · Redaction check:** Test “Grant safety qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.06-C099-T06 · Output budget:** Set and exercise bounded “Grant safety qualification” message size, rate and retention compatible with “Grant corpus and concurrent access trials”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.06-C099-T07 · Success/refusal fixtures:** Capture “Grant safety qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Grant safety qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.06-C099-T09 · Operator review:** Read the “Grant safety qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.06-C099-T10 · Diagnostic evidence:** Publish redacted “Grant safety qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for grant safety qualification; label unexecuted checks as untested.

- [ ] **UC-M08.06-C100-T01 · Evidence inventory:** List the “Grant safety qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.06-C100-T02 · Artifact references:** Record the exact “Grant safety qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.06-C100-T03 · Fixture references:** Attach the “Grant safety qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A revoked grant remains accessible through a cached mapping” as a distinct evidence case.
- [ ] **UC-M08.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Grant safety qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.06-C100-T05 · Environment record:** Record the actual “Grant safety qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.06-C100-T06 · Expected versus observed:** Pair every “Grant safety qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.06-C100-T07 · Failure and limit records:** Attach “Grant safety qualification” change/failure and bounds evidence where required; include uncovered “Grant corpus and concurrent access trials” and unresolved violations of “The selected grant profile passes its declared lifetime and isolation tests”.
- [ ] **UC-M08.06-C100-T08 · Evidence hygiene:** Check the “Grant safety qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.06-C100-T09 · Reproduction review:** Have the “Grant safety qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.06-C100-T10 · Acceptance linkage:** Link the “Grant safety qualification” evidence to its parent and UC-M08.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

