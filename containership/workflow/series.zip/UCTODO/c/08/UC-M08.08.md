# UC-M08.08 — Optional service discovery and routing

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/08.md)

| Field | Preserved source value |
|---|---|
| Workstream | 08. Guest communication and data plane |
| Milestone | C |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional feature |
| Dependencies | [UC-M05.05](../05/UC-M05.05.md), [UC-M05.06](../05/UC-M05.06.md), [UC-M08.07](../08/UC-M08.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3], [S4]. |

## Original requirement

For multi-service deployments, publish authenticated generation-aware endpoints with readiness, expiry and withdrawal.

**Original acceptance criterion:** A stopped or replaced generation cannot receive newly routed requests after its endpoint is withdrawn.

**Source trace:** Original checklist `UC100/c/08/UC-M08.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 791–802 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Discovery applicability

**Source delivery:** Enable discovery only for explicitly selected multi-service deployments.

**Source invariant:** Offline single-guest operation does not depend on discovery.

**Source negative case:** Boot fails because an unused discovery service is absent.

**Source bounded quantities:** Service profiles and dependency count.

### UC-M08.08-C001 · Contract

**Original checklist item:** Specify discovery applicability inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C001-T01 · Scope statement:** Draft the operation boundary for “Discovery applicability” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Discovery applicability”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C001-T03 · Output inventory:** List the outputs of “Discovery applicability” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Discovery applicability”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C001-T05 · Prerequisite contract:** Map “Discovery applicability” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C001-T06 · Authority map:** Identify who may produce, change and consume “Discovery applicability”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C001-T07 · Invariant clause:** Add a normative clause for “Discovery applicability” that preserves “Offline single-guest operation does not depend on discovery”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Discovery applicability”; include the source counterexample “Boot fails because an unused discovery service is absent” and the intended safe disposition.
- [ ] **UC-M08.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Service profiles and dependency count” in the “Discovery applicability” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C001-T10 · Contract review:** Review the “Discovery applicability” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C002 · Delivery

**Original checklist item:** Enable discovery only for explicitly selected multi-service deployments.

- [ ] **UC-M08.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Discovery applicability”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C002-T02 · Change plan:** Break the source delivery for “Discovery applicability” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Discovery applicability” that realizes this source instruction: Enable discovery only for explicitly selected multi-service deployments.
- [ ] **UC-M08.08-C002-T04 · Concrete realization:** Trace “Discovery applicability” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Discovery applicability” needed to preserve “Offline single-guest operation does not depend on discovery”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C002-T06 · Dependency connection:** Connect the “Discovery applicability” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C002-T07 · Resource behavior:** Account for “Service profiles and dependency count” in “Discovery applicability”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C002-T08 · Delivery check:** Run the smallest real “Discovery applicability” path and its adverse fixture “Boot fails because an unused discovery service is absent”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C002-T09 · Patch review:** Review the “Discovery applicability” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C002-T10 · Delivery handoff:** Publish the “Discovery applicability” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Offline single-guest operation does not depend on discovery. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “Discovery applicability”; copy its required invariant exactly: “Offline single-guest operation does not depend on discovery”.
- [ ] **UC-M08.08-C003-T02 · Observable terms:** Define each term in the “Discovery applicability” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C003-T03 · Precondition set:** List the preconditions under which “Offline single-guest operation does not depend on discovery” must hold for “Discovery applicability”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C003-T04 · Transition coverage:** Map the “Discovery applicability” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Discovery applicability”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C003-T06 · Satisfying fixture:** Create a concrete “Discovery applicability” case that satisfies “Offline single-guest operation does not depend on discovery”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C003-T07 · Violating fixture:** Create the source counterexample “Boot fails because an unused discovery service is absent” for “Discovery applicability”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C003-T08 · Enforcement evidence:** Exercise the “Discovery applicability” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C003-T09 · Regression linkage:** Link the “Discovery applicability” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C003-T10 · Property disposition:** Compare the satisfying and violating “Discovery applicability” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C004 · Integration

**Original checklist item:** Integrate discovery applicability with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Discovery applicability” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C004-T02 · Field mapping:** Map every “Discovery applicability” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Discovery applicability” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C004-T04 · Ownership agreement:** Specify who owns “Discovery applicability” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C004-T05 · Handoff implementation:** Connect “Discovery applicability” through the mapped seam using the real adapter or explicit specification reference; preserve “Offline single-guest operation does not depend on discovery” across the handoff.
- [ ] **UC-M08.08-C004-T06 · Absent-input case:** Omit one required “Discovery applicability” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C004-T07 · Stale-input case:** Supply an outdated “Discovery applicability” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C004-T08 · Incompatible-input case:** Supply an incompatible “Discovery applicability” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C004-T09 · Valid integration trace:** Run a valid “Discovery applicability” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C004-T10 · Seam review:** Reconcile the “Discovery applicability” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for discovery applicability; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Discovery applicability” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C005-T02 · Expected-result oracle:** Specify the “Discovery applicability” expected result independently of the implementation output; include the property “Offline single-guest operation does not depend on discovery” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C005-T03 · Fixture material:** Create the concrete “Discovery applicability” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C005-T04 · Target preparation:** Prepare the “Discovery applicability” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C005-T05 · Initial-state record:** Record the initial “Discovery applicability” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C005-T06 · Valid-path execution:** Execute the “Discovery applicability” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C005-T07 · Outcome comparison:** Compare every declared “Discovery applicability” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C005-T08 · State and bounds check:** Inspect the “Discovery applicability” ownership/state effects and actual use of “Service profiles and dependency count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C005-T09 · Repeatability check:** Repeat the same “Discovery applicability” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C005-T10 · Positive evidence:** Attach the “Discovery applicability” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C006 · Negative test

**Original checklist item:** Negative case: Boot fails because an unused discovery service is absent. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “Discovery applicability” source counterexample: “Boot fails because an unused discovery service is absent”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Discovery applicability”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C006-T03 · Valid control:** Construct a valid “Discovery applicability” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C006-T04 · Minimal adverse input:** Derive the “Discovery applicability” adverse fixture from the control with the smallest documented change needed to reproduce “Boot fails because an unused discovery service is absent”; retain that change as reproducible data.
- [ ] **UC-M08.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Discovery applicability”; require “Offline single-guest operation does not depend on discovery” and forbid a false-success verdict.
- [ ] **UC-M08.08-C006-T06 · Adverse execution:** Exercise the “Discovery applicability” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C006-T07 · Effect inspection:** Inspect “Discovery applicability” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C006-T08 · Refusal versus failure:** Confirm the “Discovery applicability” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C006-T09 · Reset and retention:** Restore only the disposable “Discovery applicability” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C006-T10 · Negative regression:** Register the “Discovery applicability” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C007 · Change / failure test

**Original checklist item:** Exercise discovery applicability when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C007-T01 · Scenario record:** Write the “Discovery applicability” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “Offline single-guest operation does not depend on discovery”.
- [ ] **UC-M08.08-C007-T02 · Baseline capture:** Create a known-valid “Discovery applicability” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C007-T03 · Injection map:** Locate the “Discovery applicability” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Discovery applicability” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C007-T05 · Controlled trigger:** Introduce the controlled “Discovery applicability” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C007-T06 · Intermediate inspection:** Inspect the “Discovery applicability” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Discovery applicability”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Discovery applicability” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C007-T09 · Repeat and compare:** Repeat the selected “Discovery applicability” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C007-T10 · Failure evidence:** Publish the “Discovery applicability” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C008 · Bounds

**Original checklist item:** Choose, document and test limits for service profiles and dependency count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “Discovery applicability”: “Service profiles and dependency count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C008-T02 · Measurement method:** Choose how to observe each “Discovery applicability” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C008-T03 · Budget decision:** Select justified resource and input limits for “Discovery applicability”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Discovery applicability” cases for “Service profiles and dependency count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Discovery applicability” limit; preserve “Offline single-guest operation does not depend on discovery”.
- [ ] **UC-M08.08-C008-T06 · Normal measurement:** Run or review the normal “Discovery applicability” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C008-T07 · At-limit measurement:** Exercise the “Discovery applicability” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C008-T08 · Over-limit measurement:** Exercise the “Discovery applicability” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C008-T09 · Uncovered-scope report:** List the “Discovery applicability” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C008-T10 · Limit evidence:** Publish the selected “Discovery applicability” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for discovery applicability with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C009-T01 · Event inventory:** List the “Discovery applicability” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Discovery applicability” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C009-T03 · Failure mapping:** Map each documented “Discovery applicability” refusal or error to a diagnostic outcome; include “Boot fails because an unused discovery service is absent” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C009-T04 · Emission path:** Add the “Discovery applicability” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C009-T05 · Redaction check:** Test “Discovery applicability” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C009-T06 · Output budget:** Set and exercise bounded “Discovery applicability” message size, rate and retention compatible with “Service profiles and dependency count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C009-T07 · Success/refusal fixtures:** Capture “Discovery applicability” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Discovery applicability” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C009-T09 · Operator review:** Read the “Discovery applicability” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C009-T10 · Diagnostic evidence:** Publish redacted “Discovery applicability” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for discovery applicability; label unexecuted checks as untested.

- [ ] **UC-M08.08-C010-T01 · Evidence inventory:** List the “Discovery applicability” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C010-T02 · Artifact references:** Record the exact “Discovery applicability” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C010-T03 · Fixture references:** Attach the “Discovery applicability” fixture IDs, input identities and oracle definition; preserve the source counterexample “Boot fails because an unused discovery service is absent” as a distinct evidence case.
- [ ] **UC-M08.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Discovery applicability”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C010-T05 · Environment record:** Record the actual “Discovery applicability” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C010-T06 · Expected versus observed:** Pair every “Discovery applicability” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C010-T07 · Failure and limit records:** Attach “Discovery applicability” change/failure and bounds evidence where required; include uncovered “Service profiles and dependency count” and unresolved violations of “Offline single-guest operation does not depend on discovery”.
- [ ] **UC-M08.08-C010-T08 · Evidence hygiene:** Check the “Discovery applicability” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C010-T09 · Reproduction review:** Have the “Discovery applicability” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C010-T10 · Acceptance linkage:** Link the “Discovery applicability” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Endpoint identity

**Source delivery:** Bind published endpoints to service, tenant, workload and generation.

**Source invariant:** A reused service name cannot authorize an obsolete generation.

**Source negative case:** An old endpoint is republished under a new workload's name.

**Source bounded quantities:** Endpoint records and identity bytes.

### UC-M08.08-C011 · Contract

**Original checklist item:** Specify endpoint identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C011-T01 · Scope statement:** Draft the operation boundary for “Endpoint identity” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Endpoint identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C011-T03 · Output inventory:** List the outputs of “Endpoint identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Endpoint identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C011-T05 · Prerequisite contract:** Map “Endpoint identity” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Endpoint identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C011-T07 · Invariant clause:** Add a normative clause for “Endpoint identity” that preserves “A reused service name cannot authorize an obsolete generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Endpoint identity”; include the source counterexample “An old endpoint is republished under a new workload's name” and the intended safe disposition.
- [ ] **UC-M08.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Endpoint records and identity bytes” in the “Endpoint identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C011-T10 · Contract review:** Review the “Endpoint identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C012 · Delivery

**Original checklist item:** Bind published endpoints to service, tenant, workload and generation.

- [ ] **UC-M08.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Endpoint identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C012-T02 · Change plan:** Break the source delivery for “Endpoint identity” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Endpoint identity” that realizes this source instruction: Bind published endpoints to service, tenant, workload and generation.
- [ ] **UC-M08.08-C012-T04 · Concrete realization:** Trace “Endpoint identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Endpoint identity” needed to preserve “A reused service name cannot authorize an obsolete generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C012-T06 · Dependency connection:** Connect the “Endpoint identity” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C012-T07 · Resource behavior:** Account for “Endpoint records and identity bytes” in “Endpoint identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C012-T08 · Delivery check:** Run the smallest real “Endpoint identity” path and its adverse fixture “An old endpoint is republished under a new workload's name”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C012-T09 · Patch review:** Review the “Endpoint identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C012-T10 · Delivery handoff:** Publish the “Endpoint identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A reused service name cannot authorize an obsolete generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Endpoint identity”; copy its required invariant exactly: “A reused service name cannot authorize an obsolete generation”.
- [ ] **UC-M08.08-C013-T02 · Observable terms:** Define each term in the “Endpoint identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C013-T03 · Precondition set:** List the preconditions under which “A reused service name cannot authorize an obsolete generation” must hold for “Endpoint identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C013-T04 · Transition coverage:** Map the “Endpoint identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Endpoint identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C013-T06 · Satisfying fixture:** Create a concrete “Endpoint identity” case that satisfies “A reused service name cannot authorize an obsolete generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C013-T07 · Violating fixture:** Create the source counterexample “An old endpoint is republished under a new workload's name” for “Endpoint identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C013-T08 · Enforcement evidence:** Exercise the “Endpoint identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C013-T09 · Regression linkage:** Link the “Endpoint identity” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Endpoint identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C014 · Integration

**Original checklist item:** Integrate endpoint identity with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Endpoint identity” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C014-T02 · Field mapping:** Map every “Endpoint identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Endpoint identity” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C014-T04 · Ownership agreement:** Specify who owns “Endpoint identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C014-T05 · Handoff implementation:** Connect “Endpoint identity” through the mapped seam using the real adapter or explicit specification reference; preserve “A reused service name cannot authorize an obsolete generation” across the handoff.
- [ ] **UC-M08.08-C014-T06 · Absent-input case:** Omit one required “Endpoint identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C014-T07 · Stale-input case:** Supply an outdated “Endpoint identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Endpoint identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C014-T09 · Valid integration trace:** Run a valid “Endpoint identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C014-T10 · Seam review:** Reconcile the “Endpoint identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for endpoint identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Endpoint identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C015-T02 · Expected-result oracle:** Specify the “Endpoint identity” expected result independently of the implementation output; include the property “A reused service name cannot authorize an obsolete generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C015-T03 · Fixture material:** Create the concrete “Endpoint identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C015-T04 · Target preparation:** Prepare the “Endpoint identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C015-T05 · Initial-state record:** Record the initial “Endpoint identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C015-T06 · Valid-path execution:** Execute the “Endpoint identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C015-T07 · Outcome comparison:** Compare every declared “Endpoint identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C015-T08 · State and bounds check:** Inspect the “Endpoint identity” ownership/state effects and actual use of “Endpoint records and identity bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C015-T09 · Repeatability check:** Repeat the same “Endpoint identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C015-T10 · Positive evidence:** Attach the “Endpoint identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C016 · Negative test

**Original checklist item:** Negative case: An old endpoint is republished under a new workload's name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Endpoint identity” source counterexample: “An old endpoint is republished under a new workload's name”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Endpoint identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C016-T03 · Valid control:** Construct a valid “Endpoint identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C016-T04 · Minimal adverse input:** Derive the “Endpoint identity” adverse fixture from the control with the smallest documented change needed to reproduce “An old endpoint is republished under a new workload's name”; retain that change as reproducible data.
- [ ] **UC-M08.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Endpoint identity”; require “A reused service name cannot authorize an obsolete generation” and forbid a false-success verdict.
- [ ] **UC-M08.08-C016-T06 · Adverse execution:** Exercise the “Endpoint identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C016-T07 · Effect inspection:** Inspect “Endpoint identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C016-T08 · Refusal versus failure:** Confirm the “Endpoint identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C016-T09 · Reset and retention:** Restore only the disposable “Endpoint identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C016-T10 · Negative regression:** Register the “Endpoint identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C017 · Change / failure test

**Original checklist item:** Exercise endpoint identity when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C017-T01 · Scenario record:** Write the “Endpoint identity” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “A reused service name cannot authorize an obsolete generation”.
- [ ] **UC-M08.08-C017-T02 · Baseline capture:** Create a known-valid “Endpoint identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C017-T03 · Injection map:** Locate the “Endpoint identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Endpoint identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C017-T05 · Controlled trigger:** Introduce the controlled “Endpoint identity” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C017-T06 · Intermediate inspection:** Inspect the “Endpoint identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Endpoint identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Endpoint identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C017-T09 · Repeat and compare:** Repeat the selected “Endpoint identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C017-T10 · Failure evidence:** Publish the “Endpoint identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C018 · Bounds

**Original checklist item:** Choose, document and test limits for endpoint records and identity bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Endpoint identity”: “Endpoint records and identity bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C018-T02 · Measurement method:** Choose how to observe each “Endpoint identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C018-T03 · Budget decision:** Select justified resource and input limits for “Endpoint identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Endpoint identity” cases for “Endpoint records and identity bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Endpoint identity” limit; preserve “A reused service name cannot authorize an obsolete generation”.
- [ ] **UC-M08.08-C018-T06 · Normal measurement:** Run or review the normal “Endpoint identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C018-T07 · At-limit measurement:** Exercise the “Endpoint identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C018-T08 · Over-limit measurement:** Exercise the “Endpoint identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C018-T09 · Uncovered-scope report:** List the “Endpoint identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C018-T10 · Limit evidence:** Publish the selected “Endpoint identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for endpoint identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C019-T01 · Event inventory:** List the “Endpoint identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Endpoint identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C019-T03 · Failure mapping:** Map each documented “Endpoint identity” refusal or error to a diagnostic outcome; include “An old endpoint is republished under a new workload's name” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C019-T04 · Emission path:** Add the “Endpoint identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C019-T05 · Redaction check:** Test “Endpoint identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C019-T06 · Output budget:** Set and exercise bounded “Endpoint identity” message size, rate and retention compatible with “Endpoint records and identity bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C019-T07 · Success/refusal fixtures:** Capture “Endpoint identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Endpoint identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C019-T09 · Operator review:** Read the “Endpoint identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C019-T10 · Diagnostic evidence:** Publish redacted “Endpoint identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for endpoint identity; label unexecuted checks as untested.

- [ ] **UC-M08.08-C020-T01 · Evidence inventory:** List the “Endpoint identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C020-T02 · Artifact references:** Record the exact “Endpoint identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C020-T03 · Fixture references:** Attach the “Endpoint identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old endpoint is republished under a new workload's name” as a distinct evidence case.
- [ ] **UC-M08.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Endpoint identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C020-T05 · Environment record:** Record the actual “Endpoint identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C020-T06 · Expected versus observed:** Pair every “Endpoint identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C020-T07 · Failure and limit records:** Attach “Endpoint identity” change/failure and bounds evidence where required; include uncovered “Endpoint records and identity bytes” and unresolved violations of “A reused service name cannot authorize an obsolete generation”.
- [ ] **UC-M08.08-C020-T08 · Evidence hygiene:** Check the “Endpoint identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C020-T09 · Reproduction review:** Have the “Endpoint identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C020-T10 · Acceptance linkage:** Link the “Endpoint identity” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Authenticated publication

**Source delivery:** Authorize publishers and validate endpoint ownership.

**Source invariant:** An untrusted guest cannot register routes for another service.

**Source negative case:** A guest claims the identity of a privileged management service.

**Source bounded quantities:** Publishers and registration rate.

### UC-M08.08-C021 · Contract

**Original checklist item:** Specify authenticated publication inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C021-T01 · Scope statement:** Draft the operation boundary for “Authenticated publication” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Authenticated publication”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C021-T03 · Output inventory:** List the outputs of “Authenticated publication” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Authenticated publication”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C021-T05 · Prerequisite contract:** Map “Authenticated publication” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Authenticated publication”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C021-T07 · Invariant clause:** Add a normative clause for “Authenticated publication” that preserves “An untrusted guest cannot register routes for another service”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Authenticated publication”; include the source counterexample “A guest claims the identity of a privileged management service” and the intended safe disposition.
- [ ] **UC-M08.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Publishers and registration rate” in the “Authenticated publication” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C021-T10 · Contract review:** Review the “Authenticated publication” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C022 · Delivery

**Original checklist item:** Authorize publishers and validate endpoint ownership.

- [ ] **UC-M08.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Authenticated publication”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C022-T02 · Change plan:** Break the source delivery for “Authenticated publication” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Authenticated publication” that realizes this source instruction: Authorize publishers and validate endpoint ownership.
- [ ] **UC-M08.08-C022-T04 · Concrete realization:** Trace “Authenticated publication” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Authenticated publication” needed to preserve “An untrusted guest cannot register routes for another service”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C022-T06 · Dependency connection:** Connect the “Authenticated publication” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C022-T07 · Resource behavior:** Account for “Publishers and registration rate” in “Authenticated publication”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C022-T08 · Delivery check:** Run the smallest real “Authenticated publication” path and its adverse fixture “A guest claims the identity of a privileged management service”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C022-T09 · Patch review:** Review the “Authenticated publication” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C022-T10 · Delivery handoff:** Publish the “Authenticated publication” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An untrusted guest cannot register routes for another service. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Authenticated publication”; copy its required invariant exactly: “An untrusted guest cannot register routes for another service”.
- [ ] **UC-M08.08-C023-T02 · Observable terms:** Define each term in the “Authenticated publication” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C023-T03 · Precondition set:** List the preconditions under which “An untrusted guest cannot register routes for another service” must hold for “Authenticated publication”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C023-T04 · Transition coverage:** Map the “Authenticated publication” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Authenticated publication”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C023-T06 · Satisfying fixture:** Create a concrete “Authenticated publication” case that satisfies “An untrusted guest cannot register routes for another service”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C023-T07 · Violating fixture:** Create the source counterexample “A guest claims the identity of a privileged management service” for “Authenticated publication”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C023-T08 · Enforcement evidence:** Exercise the “Authenticated publication” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C023-T09 · Regression linkage:** Link the “Authenticated publication” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Authenticated publication” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C024 · Integration

**Original checklist item:** Integrate authenticated publication with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Authenticated publication” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C024-T02 · Field mapping:** Map every “Authenticated publication” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Authenticated publication” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C024-T04 · Ownership agreement:** Specify who owns “Authenticated publication” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C024-T05 · Handoff implementation:** Connect “Authenticated publication” through the mapped seam using the real adapter or explicit specification reference; preserve “An untrusted guest cannot register routes for another service” across the handoff.
- [ ] **UC-M08.08-C024-T06 · Absent-input case:** Omit one required “Authenticated publication” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C024-T07 · Stale-input case:** Supply an outdated “Authenticated publication” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Authenticated publication” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C024-T09 · Valid integration trace:** Run a valid “Authenticated publication” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C024-T10 · Seam review:** Reconcile the “Authenticated publication” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for authenticated publication; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Authenticated publication” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C025-T02 · Expected-result oracle:** Specify the “Authenticated publication” expected result independently of the implementation output; include the property “An untrusted guest cannot register routes for another service” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C025-T03 · Fixture material:** Create the concrete “Authenticated publication” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C025-T04 · Target preparation:** Prepare the “Authenticated publication” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C025-T05 · Initial-state record:** Record the initial “Authenticated publication” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C025-T06 · Valid-path execution:** Execute the “Authenticated publication” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C025-T07 · Outcome comparison:** Compare every declared “Authenticated publication” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C025-T08 · State and bounds check:** Inspect the “Authenticated publication” ownership/state effects and actual use of “Publishers and registration rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C025-T09 · Repeatability check:** Repeat the same “Authenticated publication” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C025-T10 · Positive evidence:** Attach the “Authenticated publication” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C026 · Negative test

**Original checklist item:** Negative case: A guest claims the identity of a privileged management service. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Authenticated publication” source counterexample: “A guest claims the identity of a privileged management service”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Authenticated publication”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C026-T03 · Valid control:** Construct a valid “Authenticated publication” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C026-T04 · Minimal adverse input:** Derive the “Authenticated publication” adverse fixture from the control with the smallest documented change needed to reproduce “A guest claims the identity of a privileged management service”; retain that change as reproducible data.
- [ ] **UC-M08.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Authenticated publication”; require “An untrusted guest cannot register routes for another service” and forbid a false-success verdict.
- [ ] **UC-M08.08-C026-T06 · Adverse execution:** Exercise the “Authenticated publication” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C026-T07 · Effect inspection:** Inspect “Authenticated publication” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C026-T08 · Refusal versus failure:** Confirm the “Authenticated publication” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C026-T09 · Reset and retention:** Restore only the disposable “Authenticated publication” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C026-T10 · Negative regression:** Register the “Authenticated publication” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C027 · Change / failure test

**Original checklist item:** Exercise authenticated publication when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C027-T01 · Scenario record:** Write the “Authenticated publication” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “An untrusted guest cannot register routes for another service”.
- [ ] **UC-M08.08-C027-T02 · Baseline capture:** Create a known-valid “Authenticated publication” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C027-T03 · Injection map:** Locate the “Authenticated publication” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Authenticated publication” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C027-T05 · Controlled trigger:** Introduce the controlled “Authenticated publication” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C027-T06 · Intermediate inspection:** Inspect the “Authenticated publication” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Authenticated publication”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Authenticated publication” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C027-T09 · Repeat and compare:** Repeat the selected “Authenticated publication” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C027-T10 · Failure evidence:** Publish the “Authenticated publication” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C028 · Bounds

**Original checklist item:** Choose, document and test limits for publishers and registration rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Authenticated publication”: “Publishers and registration rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C028-T02 · Measurement method:** Choose how to observe each “Authenticated publication” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C028-T03 · Budget decision:** Select justified resource and input limits for “Authenticated publication”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Authenticated publication” cases for “Publishers and registration rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Authenticated publication” limit; preserve “An untrusted guest cannot register routes for another service”.
- [ ] **UC-M08.08-C028-T06 · Normal measurement:** Run or review the normal “Authenticated publication” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C028-T07 · At-limit measurement:** Exercise the “Authenticated publication” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C028-T08 · Over-limit measurement:** Exercise the “Authenticated publication” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C028-T09 · Uncovered-scope report:** List the “Authenticated publication” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C028-T10 · Limit evidence:** Publish the selected “Authenticated publication” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for authenticated publication with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C029-T01 · Event inventory:** List the “Authenticated publication” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Authenticated publication” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C029-T03 · Failure mapping:** Map each documented “Authenticated publication” refusal or error to a diagnostic outcome; include “A guest claims the identity of a privileged management service” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C029-T04 · Emission path:** Add the “Authenticated publication” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C029-T05 · Redaction check:** Test “Authenticated publication” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C029-T06 · Output budget:** Set and exercise bounded “Authenticated publication” message size, rate and retention compatible with “Publishers and registration rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C029-T07 · Success/refusal fixtures:** Capture “Authenticated publication” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Authenticated publication” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C029-T09 · Operator review:** Read the “Authenticated publication” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C029-T10 · Diagnostic evidence:** Publish redacted “Authenticated publication” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for authenticated publication; label unexecuted checks as untested.

- [ ] **UC-M08.08-C030-T01 · Evidence inventory:** List the “Authenticated publication” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C030-T02 · Artifact references:** Record the exact “Authenticated publication” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C030-T03 · Fixture references:** Attach the “Authenticated publication” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest claims the identity of a privileged management service” as a distinct evidence case.
- [ ] **UC-M08.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Authenticated publication”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C030-T05 · Environment record:** Record the actual “Authenticated publication” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C030-T06 · Expected versus observed:** Pair every “Authenticated publication” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C030-T07 · Failure and limit records:** Attach “Authenticated publication” change/failure and bounds evidence where required; include uncovered “Publishers and registration rate” and unresolved violations of “An untrusted guest cannot register routes for another service”.
- [ ] **UC-M08.08-C030-T08 · Evidence hygiene:** Check the “Authenticated publication” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C030-T09 · Reproduction review:** Have the “Authenticated publication” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C030-T10 · Acceptance linkage:** Link the “Authenticated publication” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Readiness gating

**Source delivery:** Publish routable endpoints only after required readiness evidence.

**Source invariant:** An unready replica receives no newly routed requests.

**Source negative case:** Registration happens before guest state initialization completes.

**Source bounded quantities:** Ready endpoints and publication delay.

### UC-M08.08-C031 · Contract

**Original checklist item:** Specify readiness gating inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C031-T01 · Scope statement:** Draft the operation boundary for “Readiness gating” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Readiness gating”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C031-T03 · Output inventory:** List the outputs of “Readiness gating” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Readiness gating”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C031-T05 · Prerequisite contract:** Map “Readiness gating” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Readiness gating”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C031-T07 · Invariant clause:** Add a normative clause for “Readiness gating” that preserves “An unready replica receives no newly routed requests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Readiness gating”; include the source counterexample “Registration happens before guest state initialization completes” and the intended safe disposition.
- [ ] **UC-M08.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Ready endpoints and publication delay” in the “Readiness gating” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C031-T10 · Contract review:** Review the “Readiness gating” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C032 · Delivery

**Original checklist item:** Publish routable endpoints only after required readiness evidence.

- [ ] **UC-M08.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Readiness gating”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C032-T02 · Change plan:** Break the source delivery for “Readiness gating” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C032-T03 · Core artifact:** Create the “Readiness gating” output artifact for this source instruction: Publish routable endpoints only after required readiness evidence.
- [ ] **UC-M08.08-C032-T04 · Concrete realization:** Populate the “Readiness gating” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M08.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Readiness gating” needed to preserve “An unready replica receives no newly routed requests”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C032-T06 · Dependency connection:** Connect the “Readiness gating” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C032-T07 · Resource behavior:** Account for “Ready endpoints and publication delay” in “Readiness gating”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C032-T08 · Delivery check:** Run the smallest real “Readiness gating” path and its adverse fixture “Registration happens before guest state initialization completes”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C032-T09 · Patch review:** Review the “Readiness gating” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C032-T10 · Delivery handoff:** Publish the “Readiness gating” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An unready replica receives no newly routed requests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Readiness gating”; copy its required invariant exactly: “An unready replica receives no newly routed requests”.
- [ ] **UC-M08.08-C033-T02 · Observable terms:** Define each term in the “Readiness gating” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C033-T03 · Precondition set:** List the preconditions under which “An unready replica receives no newly routed requests” must hold for “Readiness gating”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C033-T04 · Transition coverage:** Map the “Readiness gating” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Readiness gating”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C033-T06 · Satisfying fixture:** Create a concrete “Readiness gating” case that satisfies “An unready replica receives no newly routed requests”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C033-T07 · Violating fixture:** Create the source counterexample “Registration happens before guest state initialization completes” for “Readiness gating”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C033-T08 · Enforcement evidence:** Exercise the “Readiness gating” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C033-T09 · Regression linkage:** Link the “Readiness gating” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Readiness gating” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C034 · Integration

**Original checklist item:** Integrate readiness gating with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Readiness gating” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C034-T02 · Field mapping:** Map every “Readiness gating” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Readiness gating” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C034-T04 · Ownership agreement:** Specify who owns “Readiness gating” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C034-T05 · Handoff implementation:** Connect “Readiness gating” through the mapped seam using the real adapter or explicit specification reference; preserve “An unready replica receives no newly routed requests” across the handoff.
- [ ] **UC-M08.08-C034-T06 · Absent-input case:** Omit one required “Readiness gating” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C034-T07 · Stale-input case:** Supply an outdated “Readiness gating” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Readiness gating” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C034-T09 · Valid integration trace:** Run a valid “Readiness gating” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C034-T10 · Seam review:** Reconcile the “Readiness gating” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for readiness gating; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Readiness gating” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C035-T02 · Expected-result oracle:** Specify the “Readiness gating” expected result independently of the implementation output; include the property “An unready replica receives no newly routed requests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C035-T03 · Fixture material:** Create the concrete “Readiness gating” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C035-T04 · Target preparation:** Prepare the “Readiness gating” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C035-T05 · Initial-state record:** Record the initial “Readiness gating” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C035-T06 · Valid-path execution:** Execute the “Readiness gating” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C035-T07 · Outcome comparison:** Compare every declared “Readiness gating” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C035-T08 · State and bounds check:** Inspect the “Readiness gating” ownership/state effects and actual use of “Ready endpoints and publication delay”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C035-T09 · Repeatability check:** Repeat the same “Readiness gating” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C035-T10 · Positive evidence:** Attach the “Readiness gating” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C036 · Negative test

**Original checklist item:** Negative case: Registration happens before guest state initialization completes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Readiness gating” source counterexample: “Registration happens before guest state initialization completes”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Readiness gating”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C036-T03 · Valid control:** Construct a valid “Readiness gating” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C036-T04 · Minimal adverse input:** Derive the “Readiness gating” adverse fixture from the control with the smallest documented change needed to reproduce “Registration happens before guest state initialization completes”; retain that change as reproducible data.
- [ ] **UC-M08.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Readiness gating”; require “An unready replica receives no newly routed requests” and forbid a false-success verdict.
- [ ] **UC-M08.08-C036-T06 · Adverse execution:** Exercise the “Readiness gating” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C036-T07 · Effect inspection:** Inspect “Readiness gating” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C036-T08 · Refusal versus failure:** Confirm the “Readiness gating” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C036-T09 · Reset and retention:** Restore only the disposable “Readiness gating” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C036-T10 · Negative regression:** Register the “Readiness gating” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C037 · Change / failure test

**Original checklist item:** Exercise readiness gating when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C037-T01 · Scenario record:** Write the “Readiness gating” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “An unready replica receives no newly routed requests”.
- [ ] **UC-M08.08-C037-T02 · Baseline capture:** Create a known-valid “Readiness gating” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C037-T03 · Injection map:** Locate the “Readiness gating” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Readiness gating” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C037-T05 · Controlled trigger:** Introduce the controlled “Readiness gating” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C037-T06 · Intermediate inspection:** Inspect the “Readiness gating” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Readiness gating”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Readiness gating” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C037-T09 · Repeat and compare:** Repeat the selected “Readiness gating” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C037-T10 · Failure evidence:** Publish the “Readiness gating” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C038 · Bounds

**Original checklist item:** Choose, document and test limits for ready endpoints and publication delay; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Readiness gating”: “Ready endpoints and publication delay”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C038-T02 · Measurement method:** Choose how to observe each “Readiness gating” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C038-T03 · Budget decision:** Select justified resource and input limits for “Readiness gating”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Readiness gating” cases for “Ready endpoints and publication delay”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Readiness gating” limit; preserve “An unready replica receives no newly routed requests”.
- [ ] **UC-M08.08-C038-T06 · Normal measurement:** Run or review the normal “Readiness gating” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C038-T07 · At-limit measurement:** Exercise the “Readiness gating” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C038-T08 · Over-limit measurement:** Exercise the “Readiness gating” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C038-T09 · Uncovered-scope report:** List the “Readiness gating” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C038-T10 · Limit evidence:** Publish the selected “Readiness gating” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for readiness gating with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C039-T01 · Event inventory:** List the “Readiness gating” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Readiness gating” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C039-T03 · Failure mapping:** Map each documented “Readiness gating” refusal or error to a diagnostic outcome; include “Registration happens before guest state initialization completes” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C039-T04 · Emission path:** Add the “Readiness gating” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C039-T05 · Redaction check:** Test “Readiness gating” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C039-T06 · Output budget:** Set and exercise bounded “Readiness gating” message size, rate and retention compatible with “Ready endpoints and publication delay”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C039-T07 · Success/refusal fixtures:** Capture “Readiness gating” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Readiness gating” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C039-T09 · Operator review:** Read the “Readiness gating” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C039-T10 · Diagnostic evidence:** Publish redacted “Readiness gating” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for readiness gating; label unexecuted checks as untested.

- [ ] **UC-M08.08-C040-T01 · Evidence inventory:** List the “Readiness gating” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C040-T02 · Artifact references:** Record the exact “Readiness gating” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C040-T03 · Fixture references:** Attach the “Readiness gating” fixture IDs, input identities and oracle definition; preserve the source counterexample “Registration happens before guest state initialization completes” as a distinct evidence case.
- [ ] **UC-M08.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Readiness gating”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C040-T05 · Environment record:** Record the actual “Readiness gating” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C040-T06 · Expected versus observed:** Pair every “Readiness gating” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C040-T07 · Failure and limit records:** Attach “Readiness gating” change/failure and bounds evidence where required; include uncovered “Ready endpoints and publication delay” and unresolved violations of “An unready replica receives no newly routed requests”.
- [ ] **UC-M08.08-C040-T08 · Evidence hygiene:** Check the “Readiness gating” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C040-T09 · Reproduction review:** Have the “Readiness gating” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C040-T10 · Acceptance linkage:** Link the “Readiness gating” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Expiry semantics

**Source delivery:** Attach expiry or lease semantics to endpoint records.

**Source invariant:** Stale endpoint records cannot remain routable indefinitely.

**Source negative case:** A crashed publisher never withdraws its endpoint.

**Source bounded quantities:** Lease duration and stale endpoint count.

### UC-M08.08-C041 · Contract

**Original checklist item:** Specify expiry semantics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C041-T01 · Scope statement:** Draft the operation boundary for “Expiry semantics” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Expiry semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C041-T03 · Output inventory:** List the outputs of “Expiry semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Expiry semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C041-T05 · Prerequisite contract:** Map “Expiry semantics” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Expiry semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C041-T07 · Invariant clause:** Add a normative clause for “Expiry semantics” that preserves “Stale endpoint records cannot remain routable indefinitely”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Expiry semantics”; include the source counterexample “A crashed publisher never withdraws its endpoint” and the intended safe disposition.
- [ ] **UC-M08.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Lease duration and stale endpoint count” in the “Expiry semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C041-T10 · Contract review:** Review the “Expiry semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C042 · Delivery

**Original checklist item:** Attach expiry or lease semantics to endpoint records.

- [ ] **UC-M08.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Expiry semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C042-T02 · Change plan:** Break the source delivery for “Expiry semantics” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C042-T03 · Core artifact:** Create the “Expiry semantics” output artifact for this source instruction: Attach expiry or lease semantics to endpoint records.
- [ ] **UC-M08.08-C042-T04 · Concrete realization:** Populate the “Expiry semantics” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M08.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Expiry semantics” needed to preserve “Stale endpoint records cannot remain routable indefinitely”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C042-T06 · Dependency connection:** Connect the “Expiry semantics” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C042-T07 · Resource behavior:** Account for “Lease duration and stale endpoint count” in “Expiry semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C042-T08 · Delivery check:** Run the smallest real “Expiry semantics” path and its adverse fixture “A crashed publisher never withdraws its endpoint”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C042-T09 · Patch review:** Review the “Expiry semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C042-T10 · Delivery handoff:** Publish the “Expiry semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stale endpoint records cannot remain routable indefinitely. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Expiry semantics”; copy its required invariant exactly: “Stale endpoint records cannot remain routable indefinitely”.
- [ ] **UC-M08.08-C043-T02 · Observable terms:** Define each term in the “Expiry semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C043-T03 · Precondition set:** List the preconditions under which “Stale endpoint records cannot remain routable indefinitely” must hold for “Expiry semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C043-T04 · Transition coverage:** Map the “Expiry semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Expiry semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C043-T06 · Satisfying fixture:** Create a concrete “Expiry semantics” case that satisfies “Stale endpoint records cannot remain routable indefinitely”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C043-T07 · Violating fixture:** Create the source counterexample “A crashed publisher never withdraws its endpoint” for “Expiry semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C043-T08 · Enforcement evidence:** Exercise the “Expiry semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C043-T09 · Regression linkage:** Link the “Expiry semantics” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Expiry semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C044 · Integration

**Original checklist item:** Integrate expiry semantics with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Expiry semantics” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C044-T02 · Field mapping:** Map every “Expiry semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Expiry semantics” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C044-T04 · Ownership agreement:** Specify who owns “Expiry semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C044-T05 · Handoff implementation:** Connect “Expiry semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Stale endpoint records cannot remain routable indefinitely” across the handoff.
- [ ] **UC-M08.08-C044-T06 · Absent-input case:** Omit one required “Expiry semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C044-T07 · Stale-input case:** Supply an outdated “Expiry semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Expiry semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C044-T09 · Valid integration trace:** Run a valid “Expiry semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C044-T10 · Seam review:** Reconcile the “Expiry semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for expiry semantics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Expiry semantics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C045-T02 · Expected-result oracle:** Specify the “Expiry semantics” expected result independently of the implementation output; include the property “Stale endpoint records cannot remain routable indefinitely” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C045-T03 · Fixture material:** Create the concrete “Expiry semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C045-T04 · Target preparation:** Prepare the “Expiry semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C045-T05 · Initial-state record:** Record the initial “Expiry semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C045-T06 · Valid-path execution:** Execute the “Expiry semantics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C045-T07 · Outcome comparison:** Compare every declared “Expiry semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C045-T08 · State and bounds check:** Inspect the “Expiry semantics” ownership/state effects and actual use of “Lease duration and stale endpoint count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C045-T09 · Repeatability check:** Repeat the same “Expiry semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C045-T10 · Positive evidence:** Attach the “Expiry semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C046 · Negative test

**Original checklist item:** Negative case: A crashed publisher never withdraws its endpoint. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Expiry semantics” source counterexample: “A crashed publisher never withdraws its endpoint”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Expiry semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C046-T03 · Valid control:** Construct a valid “Expiry semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C046-T04 · Minimal adverse input:** Derive the “Expiry semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A crashed publisher never withdraws its endpoint”; retain that change as reproducible data.
- [ ] **UC-M08.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Expiry semantics”; require “Stale endpoint records cannot remain routable indefinitely” and forbid a false-success verdict.
- [ ] **UC-M08.08-C046-T06 · Adverse execution:** Exercise the “Expiry semantics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C046-T07 · Effect inspection:** Inspect “Expiry semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C046-T08 · Refusal versus failure:** Confirm the “Expiry semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C046-T09 · Reset and retention:** Restore only the disposable “Expiry semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C046-T10 · Negative regression:** Register the “Expiry semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C047 · Change / failure test

**Original checklist item:** Exercise expiry semantics when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C047-T01 · Scenario record:** Write the “Expiry semantics” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “Stale endpoint records cannot remain routable indefinitely”.
- [ ] **UC-M08.08-C047-T02 · Baseline capture:** Create a known-valid “Expiry semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C047-T03 · Injection map:** Locate the “Expiry semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Expiry semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C047-T05 · Controlled trigger:** Introduce the controlled “Expiry semantics” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C047-T06 · Intermediate inspection:** Inspect the “Expiry semantics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Expiry semantics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Expiry semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C047-T09 · Repeat and compare:** Repeat the selected “Expiry semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C047-T10 · Failure evidence:** Publish the “Expiry semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C048 · Bounds

**Original checklist item:** Choose, document and test limits for lease duration and stale endpoint count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Expiry semantics”: “Lease duration and stale endpoint count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C048-T02 · Measurement method:** Choose how to observe each “Expiry semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C048-T03 · Budget decision:** Select justified resource and input limits for “Expiry semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Expiry semantics” cases for “Lease duration and stale endpoint count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Expiry semantics” limit; preserve “Stale endpoint records cannot remain routable indefinitely”.
- [ ] **UC-M08.08-C048-T06 · Normal measurement:** Run or review the normal “Expiry semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C048-T07 · At-limit measurement:** Exercise the “Expiry semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C048-T08 · Over-limit measurement:** Exercise the “Expiry semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C048-T09 · Uncovered-scope report:** List the “Expiry semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C048-T10 · Limit evidence:** Publish the selected “Expiry semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for expiry semantics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C049-T01 · Event inventory:** List the “Expiry semantics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Expiry semantics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C049-T03 · Failure mapping:** Map each documented “Expiry semantics” refusal or error to a diagnostic outcome; include “A crashed publisher never withdraws its endpoint” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C049-T04 · Emission path:** Add the “Expiry semantics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C049-T05 · Redaction check:** Test “Expiry semantics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C049-T06 · Output budget:** Set and exercise bounded “Expiry semantics” message size, rate and retention compatible with “Lease duration and stale endpoint count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C049-T07 · Success/refusal fixtures:** Capture “Expiry semantics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Expiry semantics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C049-T09 · Operator review:** Read the “Expiry semantics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C049-T10 · Diagnostic evidence:** Publish redacted “Expiry semantics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for expiry semantics; label unexecuted checks as untested.

- [ ] **UC-M08.08-C050-T01 · Evidence inventory:** List the “Expiry semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C050-T02 · Artifact references:** Record the exact “Expiry semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C050-T03 · Fixture references:** Attach the “Expiry semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A crashed publisher never withdraws its endpoint” as a distinct evidence case.
- [ ] **UC-M08.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Expiry semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C050-T05 · Environment record:** Record the actual “Expiry semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C050-T06 · Expected versus observed:** Pair every “Expiry semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C050-T07 · Failure and limit records:** Attach “Expiry semantics” change/failure and bounds evidence where required; include uncovered “Lease duration and stale endpoint count” and unresolved violations of “Stale endpoint records cannot remain routable indefinitely”.
- [ ] **UC-M08.08-C050-T08 · Evidence hygiene:** Check the “Expiry semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C050-T09 · Reproduction review:** Have the “Expiry semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C050-T10 · Acceptance linkage:** Link the “Expiry semantics” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Withdrawal protocol

**Source delivery:** Withdraw an endpoint before or during the defined stop/drain sequence.

**Source invariant:** A withdrawn stopped generation receives no newly routed requests.

**Source negative case:** The guest stops while routing still advertises its endpoint.

**Source bounded quantities:** Withdrawal propagation time and queued requests.

### UC-M08.08-C051 · Contract

**Original checklist item:** Specify withdrawal protocol inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C051-T01 · Scope statement:** Draft the operation boundary for “Withdrawal protocol” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Withdrawal protocol”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C051-T03 · Output inventory:** List the outputs of “Withdrawal protocol” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Withdrawal protocol”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C051-T05 · Prerequisite contract:** Map “Withdrawal protocol” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Withdrawal protocol”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C051-T07 · Invariant clause:** Add a normative clause for “Withdrawal protocol” that preserves “A withdrawn stopped generation receives no newly routed requests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Withdrawal protocol”; include the source counterexample “The guest stops while routing still advertises its endpoint” and the intended safe disposition.
- [ ] **UC-M08.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Withdrawal propagation time and queued requests” in the “Withdrawal protocol” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C051-T10 · Contract review:** Review the “Withdrawal protocol” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C052 · Delivery

**Original checklist item:** Withdraw an endpoint before or during the defined stop/drain sequence.

- [ ] **UC-M08.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Withdrawal protocol”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C052-T02 · Change plan:** Break the source delivery for “Withdrawal protocol” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Withdrawal protocol” that realizes this source instruction: Withdraw an endpoint before or during the defined stop/drain sequence.
- [ ] **UC-M08.08-C052-T04 · Concrete realization:** Trace “Withdrawal protocol” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Withdrawal protocol” needed to preserve “A withdrawn stopped generation receives no newly routed requests”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C052-T06 · Dependency connection:** Connect the “Withdrawal protocol” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C052-T07 · Resource behavior:** Account for “Withdrawal propagation time and queued requests” in “Withdrawal protocol”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C052-T08 · Delivery check:** Run the smallest real “Withdrawal protocol” path and its adverse fixture “The guest stops while routing still advertises its endpoint”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C052-T09 · Patch review:** Review the “Withdrawal protocol” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C052-T10 · Delivery handoff:** Publish the “Withdrawal protocol” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A withdrawn stopped generation receives no newly routed requests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Withdrawal protocol”; copy its required invariant exactly: “A withdrawn stopped generation receives no newly routed requests”.
- [ ] **UC-M08.08-C053-T02 · Observable terms:** Define each term in the “Withdrawal protocol” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C053-T03 · Precondition set:** List the preconditions under which “A withdrawn stopped generation receives no newly routed requests” must hold for “Withdrawal protocol”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C053-T04 · Transition coverage:** Map the “Withdrawal protocol” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Withdrawal protocol”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C053-T06 · Satisfying fixture:** Create a concrete “Withdrawal protocol” case that satisfies “A withdrawn stopped generation receives no newly routed requests”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C053-T07 · Violating fixture:** Create the source counterexample “The guest stops while routing still advertises its endpoint” for “Withdrawal protocol”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C053-T08 · Enforcement evidence:** Exercise the “Withdrawal protocol” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C053-T09 · Regression linkage:** Link the “Withdrawal protocol” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Withdrawal protocol” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C054 · Integration

**Original checklist item:** Integrate withdrawal protocol with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Withdrawal protocol” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C054-T02 · Field mapping:** Map every “Withdrawal protocol” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Withdrawal protocol” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C054-T04 · Ownership agreement:** Specify who owns “Withdrawal protocol” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C054-T05 · Handoff implementation:** Connect “Withdrawal protocol” through the mapped seam using the real adapter or explicit specification reference; preserve “A withdrawn stopped generation receives no newly routed requests” across the handoff.
- [ ] **UC-M08.08-C054-T06 · Absent-input case:** Omit one required “Withdrawal protocol” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C054-T07 · Stale-input case:** Supply an outdated “Withdrawal protocol” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Withdrawal protocol” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C054-T09 · Valid integration trace:** Run a valid “Withdrawal protocol” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C054-T10 · Seam review:** Reconcile the “Withdrawal protocol” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for withdrawal protocol; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Withdrawal protocol” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C055-T02 · Expected-result oracle:** Specify the “Withdrawal protocol” expected result independently of the implementation output; include the property “A withdrawn stopped generation receives no newly routed requests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C055-T03 · Fixture material:** Create the concrete “Withdrawal protocol” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C055-T04 · Target preparation:** Prepare the “Withdrawal protocol” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C055-T05 · Initial-state record:** Record the initial “Withdrawal protocol” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C055-T06 · Valid-path execution:** Execute the “Withdrawal protocol” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C055-T07 · Outcome comparison:** Compare every declared “Withdrawal protocol” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C055-T08 · State and bounds check:** Inspect the “Withdrawal protocol” ownership/state effects and actual use of “Withdrawal propagation time and queued requests”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C055-T09 · Repeatability check:** Repeat the same “Withdrawal protocol” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C055-T10 · Positive evidence:** Attach the “Withdrawal protocol” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C056 · Negative test

**Original checklist item:** Negative case: The guest stops while routing still advertises its endpoint. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Withdrawal protocol” source counterexample: “The guest stops while routing still advertises its endpoint”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Withdrawal protocol”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C056-T03 · Valid control:** Construct a valid “Withdrawal protocol” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C056-T04 · Minimal adverse input:** Derive the “Withdrawal protocol” adverse fixture from the control with the smallest documented change needed to reproduce “The guest stops while routing still advertises its endpoint”; retain that change as reproducible data.
- [ ] **UC-M08.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Withdrawal protocol”; require “A withdrawn stopped generation receives no newly routed requests” and forbid a false-success verdict.
- [ ] **UC-M08.08-C056-T06 · Adverse execution:** Exercise the “Withdrawal protocol” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C056-T07 · Effect inspection:** Inspect “Withdrawal protocol” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C056-T08 · Refusal versus failure:** Confirm the “Withdrawal protocol” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C056-T09 · Reset and retention:** Restore only the disposable “Withdrawal protocol” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C056-T10 · Negative regression:** Register the “Withdrawal protocol” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C057 · Change / failure test

**Original checklist item:** Exercise withdrawal protocol when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C057-T01 · Scenario record:** Write the “Withdrawal protocol” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “A withdrawn stopped generation receives no newly routed requests”.
- [ ] **UC-M08.08-C057-T02 · Baseline capture:** Create a known-valid “Withdrawal protocol” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C057-T03 · Injection map:** Locate the “Withdrawal protocol” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Withdrawal protocol” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C057-T05 · Controlled trigger:** Introduce the controlled “Withdrawal protocol” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C057-T06 · Intermediate inspection:** Inspect the “Withdrawal protocol” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Withdrawal protocol”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Withdrawal protocol” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C057-T09 · Repeat and compare:** Repeat the selected “Withdrawal protocol” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C057-T10 · Failure evidence:** Publish the “Withdrawal protocol” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C058 · Bounds

**Original checklist item:** Choose, document and test limits for withdrawal propagation time and queued requests; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Withdrawal protocol”: “Withdrawal propagation time and queued requests”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C058-T02 · Measurement method:** Choose how to observe each “Withdrawal protocol” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C058-T03 · Budget decision:** Select justified resource and input limits for “Withdrawal protocol”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Withdrawal protocol” cases for “Withdrawal propagation time and queued requests”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Withdrawal protocol” limit; preserve “A withdrawn stopped generation receives no newly routed requests”.
- [ ] **UC-M08.08-C058-T06 · Normal measurement:** Run or review the normal “Withdrawal protocol” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C058-T07 · At-limit measurement:** Exercise the “Withdrawal protocol” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C058-T08 · Over-limit measurement:** Exercise the “Withdrawal protocol” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C058-T09 · Uncovered-scope report:** List the “Withdrawal protocol” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C058-T10 · Limit evidence:** Publish the selected “Withdrawal protocol” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for withdrawal protocol with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C059-T01 · Event inventory:** List the “Withdrawal protocol” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Withdrawal protocol” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C059-T03 · Failure mapping:** Map each documented “Withdrawal protocol” refusal or error to a diagnostic outcome; include “The guest stops while routing still advertises its endpoint” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C059-T04 · Emission path:** Add the “Withdrawal protocol” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C059-T05 · Redaction check:** Test “Withdrawal protocol” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C059-T06 · Output budget:** Set and exercise bounded “Withdrawal protocol” message size, rate and retention compatible with “Withdrawal propagation time and queued requests”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C059-T07 · Success/refusal fixtures:** Capture “Withdrawal protocol” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Withdrawal protocol” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C059-T09 · Operator review:** Read the “Withdrawal protocol” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C059-T10 · Diagnostic evidence:** Publish redacted “Withdrawal protocol” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for withdrawal protocol; label unexecuted checks as untested.

- [ ] **UC-M08.08-C060-T01 · Evidence inventory:** List the “Withdrawal protocol” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C060-T02 · Artifact references:** Record the exact “Withdrawal protocol” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C060-T03 · Fixture references:** Attach the “Withdrawal protocol” fixture IDs, input identities and oracle definition; preserve the source counterexample “The guest stops while routing still advertises its endpoint” as a distinct evidence case.
- [ ] **UC-M08.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Withdrawal protocol”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C060-T05 · Environment record:** Record the actual “Withdrawal protocol” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C060-T06 · Expected versus observed:** Pair every “Withdrawal protocol” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C060-T07 · Failure and limit records:** Attach “Withdrawal protocol” change/failure and bounds evidence where required; include uncovered “Withdrawal propagation time and queued requests” and unresolved violations of “A withdrawn stopped generation receives no newly routed requests”.
- [ ] **UC-M08.08-C060-T08 · Evidence hygiene:** Check the “Withdrawal protocol” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C060-T09 · Reproduction review:** Have the “Withdrawal protocol” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C060-T10 · Acceptance linkage:** Link the “Withdrawal protocol” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Routing authorization

**Source delivery:** Apply tenant and service policy when resolving and routing requests.

**Source invariant:** Discovery visibility does not grant unrestricted connectivity.

**Source negative case:** A tenant resolves and routes to another tenant's private service.

**Source bounded quantities:** Routing rules and request rate.

### UC-M08.08-C061 · Contract

**Original checklist item:** Specify routing authorization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C061-T01 · Scope statement:** Draft the operation boundary for “Routing authorization” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Routing authorization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C061-T03 · Output inventory:** List the outputs of “Routing authorization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Routing authorization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C061-T05 · Prerequisite contract:** Map “Routing authorization” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C061-T06 · Authority map:** Identify who may produce, change and consume “Routing authorization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C061-T07 · Invariant clause:** Add a normative clause for “Routing authorization” that preserves “Discovery visibility does not grant unrestricted connectivity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Routing authorization”; include the source counterexample “A tenant resolves and routes to another tenant's private service” and the intended safe disposition.
- [ ] **UC-M08.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Routing rules and request rate” in the “Routing authorization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C061-T10 · Contract review:** Review the “Routing authorization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C062 · Delivery

**Original checklist item:** Apply tenant and service policy when resolving and routing requests.

- [ ] **UC-M08.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Routing authorization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C062-T02 · Change plan:** Break the source delivery for “Routing authorization” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Routing authorization” that realizes this source instruction: Apply tenant and service policy when resolving and routing requests.
- [ ] **UC-M08.08-C062-T04 · Concrete realization:** Trace “Routing authorization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Routing authorization” needed to preserve “Discovery visibility does not grant unrestricted connectivity”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C062-T06 · Dependency connection:** Connect the “Routing authorization” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C062-T07 · Resource behavior:** Account for “Routing rules and request rate” in “Routing authorization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C062-T08 · Delivery check:** Run the smallest real “Routing authorization” path and its adverse fixture “A tenant resolves and routes to another tenant's private service”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C062-T09 · Patch review:** Review the “Routing authorization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C062-T10 · Delivery handoff:** Publish the “Routing authorization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Discovery visibility does not grant unrestricted connectivity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “Routing authorization”; copy its required invariant exactly: “Discovery visibility does not grant unrestricted connectivity”.
- [ ] **UC-M08.08-C063-T02 · Observable terms:** Define each term in the “Routing authorization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C063-T03 · Precondition set:** List the preconditions under which “Discovery visibility does not grant unrestricted connectivity” must hold for “Routing authorization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C063-T04 · Transition coverage:** Map the “Routing authorization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Routing authorization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C063-T06 · Satisfying fixture:** Create a concrete “Routing authorization” case that satisfies “Discovery visibility does not grant unrestricted connectivity”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C063-T07 · Violating fixture:** Create the source counterexample “A tenant resolves and routes to another tenant's private service” for “Routing authorization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C063-T08 · Enforcement evidence:** Exercise the “Routing authorization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C063-T09 · Regression linkage:** Link the “Routing authorization” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C063-T10 · Property disposition:** Compare the satisfying and violating “Routing authorization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C064 · Integration

**Original checklist item:** Integrate routing authorization with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Routing authorization” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C064-T02 · Field mapping:** Map every “Routing authorization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Routing authorization” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C064-T04 · Ownership agreement:** Specify who owns “Routing authorization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C064-T05 · Handoff implementation:** Connect “Routing authorization” through the mapped seam using the real adapter or explicit specification reference; preserve “Discovery visibility does not grant unrestricted connectivity” across the handoff.
- [ ] **UC-M08.08-C064-T06 · Absent-input case:** Omit one required “Routing authorization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C064-T07 · Stale-input case:** Supply an outdated “Routing authorization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C064-T08 · Incompatible-input case:** Supply an incompatible “Routing authorization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C064-T09 · Valid integration trace:** Run a valid “Routing authorization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C064-T10 · Seam review:** Reconcile the “Routing authorization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for routing authorization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Routing authorization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C065-T02 · Expected-result oracle:** Specify the “Routing authorization” expected result independently of the implementation output; include the property “Discovery visibility does not grant unrestricted connectivity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C065-T03 · Fixture material:** Create the concrete “Routing authorization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C065-T04 · Target preparation:** Prepare the “Routing authorization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C065-T05 · Initial-state record:** Record the initial “Routing authorization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C065-T06 · Valid-path execution:** Execute the “Routing authorization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C065-T07 · Outcome comparison:** Compare every declared “Routing authorization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C065-T08 · State and bounds check:** Inspect the “Routing authorization” ownership/state effects and actual use of “Routing rules and request rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C065-T09 · Repeatability check:** Repeat the same “Routing authorization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C065-T10 · Positive evidence:** Attach the “Routing authorization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C066 · Negative test

**Original checklist item:** Negative case: A tenant resolves and routes to another tenant's private service. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “Routing authorization” source counterexample: “A tenant resolves and routes to another tenant's private service”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Routing authorization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C066-T03 · Valid control:** Construct a valid “Routing authorization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C066-T04 · Minimal adverse input:** Derive the “Routing authorization” adverse fixture from the control with the smallest documented change needed to reproduce “A tenant resolves and routes to another tenant's private service”; retain that change as reproducible data.
- [ ] **UC-M08.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Routing authorization”; require “Discovery visibility does not grant unrestricted connectivity” and forbid a false-success verdict.
- [ ] **UC-M08.08-C066-T06 · Adverse execution:** Exercise the “Routing authorization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C066-T07 · Effect inspection:** Inspect “Routing authorization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C066-T08 · Refusal versus failure:** Confirm the “Routing authorization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C066-T09 · Reset and retention:** Restore only the disposable “Routing authorization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C066-T10 · Negative regression:** Register the “Routing authorization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C067 · Change / failure test

**Original checklist item:** Exercise routing authorization when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C067-T01 · Scenario record:** Write the “Routing authorization” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “Discovery visibility does not grant unrestricted connectivity”.
- [ ] **UC-M08.08-C067-T02 · Baseline capture:** Create a known-valid “Routing authorization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C067-T03 · Injection map:** Locate the “Routing authorization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Routing authorization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C067-T05 · Controlled trigger:** Introduce the controlled “Routing authorization” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C067-T06 · Intermediate inspection:** Inspect the “Routing authorization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Routing authorization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Routing authorization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C067-T09 · Repeat and compare:** Repeat the selected “Routing authorization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C067-T10 · Failure evidence:** Publish the “Routing authorization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C068 · Bounds

**Original checklist item:** Choose, document and test limits for routing rules and request rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “Routing authorization”: “Routing rules and request rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C068-T02 · Measurement method:** Choose how to observe each “Routing authorization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C068-T03 · Budget decision:** Select justified resource and input limits for “Routing authorization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Routing authorization” cases for “Routing rules and request rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Routing authorization” limit; preserve “Discovery visibility does not grant unrestricted connectivity”.
- [ ] **UC-M08.08-C068-T06 · Normal measurement:** Run or review the normal “Routing authorization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C068-T07 · At-limit measurement:** Exercise the “Routing authorization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C068-T08 · Over-limit measurement:** Exercise the “Routing authorization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C068-T09 · Uncovered-scope report:** List the “Routing authorization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C068-T10 · Limit evidence:** Publish the selected “Routing authorization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for routing authorization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C069-T01 · Event inventory:** List the “Routing authorization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Routing authorization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C069-T03 · Failure mapping:** Map each documented “Routing authorization” refusal or error to a diagnostic outcome; include “A tenant resolves and routes to another tenant's private service” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C069-T04 · Emission path:** Add the “Routing authorization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C069-T05 · Redaction check:** Test “Routing authorization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C069-T06 · Output budget:** Set and exercise bounded “Routing authorization” message size, rate and retention compatible with “Routing rules and request rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C069-T07 · Success/refusal fixtures:** Capture “Routing authorization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Routing authorization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C069-T09 · Operator review:** Read the “Routing authorization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C069-T10 · Diagnostic evidence:** Publish redacted “Routing authorization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for routing authorization; label unexecuted checks as untested.

- [ ] **UC-M08.08-C070-T01 · Evidence inventory:** List the “Routing authorization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C070-T02 · Artifact references:** Record the exact “Routing authorization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C070-T03 · Fixture references:** Attach the “Routing authorization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A tenant resolves and routes to another tenant's private service” as a distinct evidence case.
- [ ] **UC-M08.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Routing authorization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C070-T05 · Environment record:** Record the actual “Routing authorization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C070-T06 · Expected versus observed:** Pair every “Routing authorization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C070-T07 · Failure and limit records:** Attach “Routing authorization” change/failure and bounds evidence where required; include uncovered “Routing rules and request rate” and unresolved violations of “Discovery visibility does not grant unrestricted connectivity”.
- [ ] **UC-M08.08-C070-T08 · Evidence hygiene:** Check the “Routing authorization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C070-T09 · Reproduction review:** Have the “Routing authorization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C070-T10 · Acceptance linkage:** Link the “Routing authorization” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Replacement handoff

**Source delivery:** Coordinate readiness and withdrawal when a service generation changes.

**Source invariant:** Routes identify the active approved generation rather than a stale address.

**Source negative case:** A replaced generation continues receiving new traffic.

**Source bounded quantities:** Handoff window and replica count.

### UC-M08.08-C071 · Contract

**Original checklist item:** Specify replacement handoff inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C071-T01 · Scope statement:** Draft the operation boundary for “Replacement handoff” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Replacement handoff”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C071-T03 · Output inventory:** List the outputs of “Replacement handoff” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Replacement handoff”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C071-T05 · Prerequisite contract:** Map “Replacement handoff” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Replacement handoff”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C071-T07 · Invariant clause:** Add a normative clause for “Replacement handoff” that preserves “Routes identify the active approved generation rather than a stale address”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Replacement handoff”; include the source counterexample “A replaced generation continues receiving new traffic” and the intended safe disposition.
- [ ] **UC-M08.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Handoff window and replica count” in the “Replacement handoff” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C071-T10 · Contract review:** Review the “Replacement handoff” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C072 · Delivery

**Original checklist item:** Coordinate readiness and withdrawal when a service generation changes.

- [ ] **UC-M08.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Replacement handoff”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C072-T02 · Change plan:** Break the source delivery for “Replacement handoff” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Replacement handoff” that realizes this source instruction: Coordinate readiness and withdrawal when a service generation changes.
- [ ] **UC-M08.08-C072-T04 · Concrete realization:** Trace “Replacement handoff” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Replacement handoff” needed to preserve “Routes identify the active approved generation rather than a stale address”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C072-T06 · Dependency connection:** Connect the “Replacement handoff” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C072-T07 · Resource behavior:** Account for “Handoff window and replica count” in “Replacement handoff”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C072-T08 · Delivery check:** Run the smallest real “Replacement handoff” path and its adverse fixture “A replaced generation continues receiving new traffic”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C072-T09 · Patch review:** Review the “Replacement handoff” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C072-T10 · Delivery handoff:** Publish the “Replacement handoff” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Routes identify the active approved generation rather than a stale address. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Replacement handoff”; copy its required invariant exactly: “Routes identify the active approved generation rather than a stale address”.
- [ ] **UC-M08.08-C073-T02 · Observable terms:** Define each term in the “Replacement handoff” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C073-T03 · Precondition set:** List the preconditions under which “Routes identify the active approved generation rather than a stale address” must hold for “Replacement handoff”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C073-T04 · Transition coverage:** Map the “Replacement handoff” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Replacement handoff”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C073-T06 · Satisfying fixture:** Create a concrete “Replacement handoff” case that satisfies “Routes identify the active approved generation rather than a stale address”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C073-T07 · Violating fixture:** Create the source counterexample “A replaced generation continues receiving new traffic” for “Replacement handoff”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C073-T08 · Enforcement evidence:** Exercise the “Replacement handoff” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C073-T09 · Regression linkage:** Link the “Replacement handoff” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Replacement handoff” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C074 · Integration

**Original checklist item:** Integrate replacement handoff with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Replacement handoff” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C074-T02 · Field mapping:** Map every “Replacement handoff” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Replacement handoff” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C074-T04 · Ownership agreement:** Specify who owns “Replacement handoff” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C074-T05 · Handoff implementation:** Connect “Replacement handoff” through the mapped seam using the real adapter or explicit specification reference; preserve “Routes identify the active approved generation rather than a stale address” across the handoff.
- [ ] **UC-M08.08-C074-T06 · Absent-input case:** Omit one required “Replacement handoff” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C074-T07 · Stale-input case:** Supply an outdated “Replacement handoff” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Replacement handoff” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C074-T09 · Valid integration trace:** Run a valid “Replacement handoff” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C074-T10 · Seam review:** Reconcile the “Replacement handoff” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for replacement handoff; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Replacement handoff” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C075-T02 · Expected-result oracle:** Specify the “Replacement handoff” expected result independently of the implementation output; include the property “Routes identify the active approved generation rather than a stale address” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C075-T03 · Fixture material:** Create the concrete “Replacement handoff” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C075-T04 · Target preparation:** Prepare the “Replacement handoff” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C075-T05 · Initial-state record:** Record the initial “Replacement handoff” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C075-T06 · Valid-path execution:** Execute the “Replacement handoff” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C075-T07 · Outcome comparison:** Compare every declared “Replacement handoff” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C075-T08 · State and bounds check:** Inspect the “Replacement handoff” ownership/state effects and actual use of “Handoff window and replica count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C075-T09 · Repeatability check:** Repeat the same “Replacement handoff” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C075-T10 · Positive evidence:** Attach the “Replacement handoff” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C076 · Negative test

**Original checklist item:** Negative case: A replaced generation continues receiving new traffic. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Replacement handoff” source counterexample: “A replaced generation continues receiving new traffic”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Replacement handoff”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C076-T03 · Valid control:** Construct a valid “Replacement handoff” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C076-T04 · Minimal adverse input:** Derive the “Replacement handoff” adverse fixture from the control with the smallest documented change needed to reproduce “A replaced generation continues receiving new traffic”; retain that change as reproducible data.
- [ ] **UC-M08.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Replacement handoff”; require “Routes identify the active approved generation rather than a stale address” and forbid a false-success verdict.
- [ ] **UC-M08.08-C076-T06 · Adverse execution:** Exercise the “Replacement handoff” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C076-T07 · Effect inspection:** Inspect “Replacement handoff” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C076-T08 · Refusal versus failure:** Confirm the “Replacement handoff” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C076-T09 · Reset and retention:** Restore only the disposable “Replacement handoff” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C076-T10 · Negative regression:** Register the “Replacement handoff” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C077 · Change / failure test

**Original checklist item:** Exercise replacement handoff when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C077-T01 · Scenario record:** Write the “Replacement handoff” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “Routes identify the active approved generation rather than a stale address”.
- [ ] **UC-M08.08-C077-T02 · Baseline capture:** Create a known-valid “Replacement handoff” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C077-T03 · Injection map:** Locate the “Replacement handoff” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Replacement handoff” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C077-T05 · Controlled trigger:** Introduce the controlled “Replacement handoff” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C077-T06 · Intermediate inspection:** Inspect the “Replacement handoff” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Replacement handoff”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Replacement handoff” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C077-T09 · Repeat and compare:** Repeat the selected “Replacement handoff” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C077-T10 · Failure evidence:** Publish the “Replacement handoff” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C078 · Bounds

**Original checklist item:** Choose, document and test limits for handoff window and replica count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Replacement handoff”: “Handoff window and replica count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C078-T02 · Measurement method:** Choose how to observe each “Replacement handoff” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C078-T03 · Budget decision:** Select justified resource and input limits for “Replacement handoff”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Replacement handoff” cases for “Handoff window and replica count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Replacement handoff” limit; preserve “Routes identify the active approved generation rather than a stale address”.
- [ ] **UC-M08.08-C078-T06 · Normal measurement:** Run or review the normal “Replacement handoff” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C078-T07 · At-limit measurement:** Exercise the “Replacement handoff” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C078-T08 · Over-limit measurement:** Exercise the “Replacement handoff” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C078-T09 · Uncovered-scope report:** List the “Replacement handoff” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C078-T10 · Limit evidence:** Publish the selected “Replacement handoff” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for replacement handoff with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C079-T01 · Event inventory:** List the “Replacement handoff” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Replacement handoff” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C079-T03 · Failure mapping:** Map each documented “Replacement handoff” refusal or error to a diagnostic outcome; include “A replaced generation continues receiving new traffic” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C079-T04 · Emission path:** Add the “Replacement handoff” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C079-T05 · Redaction check:** Test “Replacement handoff” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C079-T06 · Output budget:** Set and exercise bounded “Replacement handoff” message size, rate and retention compatible with “Handoff window and replica count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C079-T07 · Success/refusal fixtures:** Capture “Replacement handoff” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Replacement handoff” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C079-T09 · Operator review:** Read the “Replacement handoff” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C079-T10 · Diagnostic evidence:** Publish redacted “Replacement handoff” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for replacement handoff; label unexecuted checks as untested.

- [ ] **UC-M08.08-C080-T01 · Evidence inventory:** List the “Replacement handoff” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C080-T02 · Artifact references:** Record the exact “Replacement handoff” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C080-T03 · Fixture references:** Attach the “Replacement handoff” fixture IDs, input identities and oracle definition; preserve the source counterexample “A replaced generation continues receiving new traffic” as a distinct evidence case.
- [ ] **UC-M08.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Replacement handoff”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C080-T05 · Environment record:** Record the actual “Replacement handoff” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C080-T06 · Expected versus observed:** Pair every “Replacement handoff” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C080-T07 · Failure and limit records:** Attach “Replacement handoff” change/failure and bounds evidence where required; include uncovered “Handoff window and replica count” and unresolved violations of “Routes identify the active approved generation rather than a stale address”.
- [ ] **UC-M08.08-C080-T08 · Evidence hygiene:** Check the “Replacement handoff” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C080-T09 · Reproduction review:** Have the “Replacement handoff” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C080-T10 · Acceptance linkage:** Link the “Replacement handoff” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Unavailable-service behavior

**Source delivery:** Return bounded explicit failure when no eligible endpoint exists.

**Source invariant:** Missing service routes do not trigger unbounded retries.

**Source negative case:** A caller loops indefinitely while every endpoint is expired.

**Source bounded quantities:** Retry ceiling and resolution deadline.

### UC-M08.08-C081 · Contract

**Original checklist item:** Specify unavailable-service behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C081-T01 · Scope statement:** Draft the operation boundary for “Unavailable-service behavior” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Unavailable-service behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C081-T03 · Output inventory:** List the outputs of “Unavailable-service behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Unavailable-service behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C081-T05 · Prerequisite contract:** Map “Unavailable-service behavior” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Unavailable-service behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C081-T07 · Invariant clause:** Add a normative clause for “Unavailable-service behavior” that preserves “Missing service routes do not trigger unbounded retries”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Unavailable-service behavior”; include the source counterexample “A caller loops indefinitely while every endpoint is expired” and the intended safe disposition.
- [ ] **UC-M08.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retry ceiling and resolution deadline” in the “Unavailable-service behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C081-T10 · Contract review:** Review the “Unavailable-service behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C082 · Delivery

**Original checklist item:** Return bounded explicit failure when no eligible endpoint exists.

- [ ] **UC-M08.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Unavailable-service behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C082-T02 · Change plan:** Break the source delivery for “Unavailable-service behavior” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Unavailable-service behavior” that realizes this source instruction: Return bounded explicit failure when no eligible endpoint exists.
- [ ] **UC-M08.08-C082-T04 · Concrete realization:** Trace “Unavailable-service behavior” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Unavailable-service behavior” needed to preserve “Missing service routes do not trigger unbounded retries”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C082-T06 · Dependency connection:** Connect the “Unavailable-service behavior” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C082-T07 · Resource behavior:** Account for “Retry ceiling and resolution deadline” in “Unavailable-service behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C082-T08 · Delivery check:** Run the smallest real “Unavailable-service behavior” path and its adverse fixture “A caller loops indefinitely while every endpoint is expired”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C082-T09 · Patch review:** Review the “Unavailable-service behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C082-T10 · Delivery handoff:** Publish the “Unavailable-service behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Missing service routes do not trigger unbounded retries. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Unavailable-service behavior”; copy its required invariant exactly: “Missing service routes do not trigger unbounded retries”.
- [ ] **UC-M08.08-C083-T02 · Observable terms:** Define each term in the “Unavailable-service behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C083-T03 · Precondition set:** List the preconditions under which “Missing service routes do not trigger unbounded retries” must hold for “Unavailable-service behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C083-T04 · Transition coverage:** Map the “Unavailable-service behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Unavailable-service behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C083-T06 · Satisfying fixture:** Create a concrete “Unavailable-service behavior” case that satisfies “Missing service routes do not trigger unbounded retries”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C083-T07 · Violating fixture:** Create the source counterexample “A caller loops indefinitely while every endpoint is expired” for “Unavailable-service behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C083-T08 · Enforcement evidence:** Exercise the “Unavailable-service behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C083-T09 · Regression linkage:** Link the “Unavailable-service behavior” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Unavailable-service behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C084 · Integration

**Original checklist item:** Integrate unavailable-service behavior with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Unavailable-service behavior” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C084-T02 · Field mapping:** Map every “Unavailable-service behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Unavailable-service behavior” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C084-T04 · Ownership agreement:** Specify who owns “Unavailable-service behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C084-T05 · Handoff implementation:** Connect “Unavailable-service behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Missing service routes do not trigger unbounded retries” across the handoff.
- [ ] **UC-M08.08-C084-T06 · Absent-input case:** Omit one required “Unavailable-service behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C084-T07 · Stale-input case:** Supply an outdated “Unavailable-service behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Unavailable-service behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C084-T09 · Valid integration trace:** Run a valid “Unavailable-service behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C084-T10 · Seam review:** Reconcile the “Unavailable-service behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for unavailable-service behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Unavailable-service behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C085-T02 · Expected-result oracle:** Specify the “Unavailable-service behavior” expected result independently of the implementation output; include the property “Missing service routes do not trigger unbounded retries” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C085-T03 · Fixture material:** Create the concrete “Unavailable-service behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C085-T04 · Target preparation:** Prepare the “Unavailable-service behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C085-T05 · Initial-state record:** Record the initial “Unavailable-service behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C085-T06 · Valid-path execution:** Execute the “Unavailable-service behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C085-T07 · Outcome comparison:** Compare every declared “Unavailable-service behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C085-T08 · State and bounds check:** Inspect the “Unavailable-service behavior” ownership/state effects and actual use of “Retry ceiling and resolution deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C085-T09 · Repeatability check:** Repeat the same “Unavailable-service behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C085-T10 · Positive evidence:** Attach the “Unavailable-service behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C086 · Negative test

**Original checklist item:** Negative case: A caller loops indefinitely while every endpoint is expired. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Unavailable-service behavior” source counterexample: “A caller loops indefinitely while every endpoint is expired”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Unavailable-service behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C086-T03 · Valid control:** Construct a valid “Unavailable-service behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C086-T04 · Minimal adverse input:** Derive the “Unavailable-service behavior” adverse fixture from the control with the smallest documented change needed to reproduce “A caller loops indefinitely while every endpoint is expired”; retain that change as reproducible data.
- [ ] **UC-M08.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Unavailable-service behavior”; require “Missing service routes do not trigger unbounded retries” and forbid a false-success verdict.
- [ ] **UC-M08.08-C086-T06 · Adverse execution:** Exercise the “Unavailable-service behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C086-T07 · Effect inspection:** Inspect “Unavailable-service behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C086-T08 · Refusal versus failure:** Confirm the “Unavailable-service behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C086-T09 · Reset and retention:** Restore only the disposable “Unavailable-service behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C086-T10 · Negative regression:** Register the “Unavailable-service behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C087 · Change / failure test

**Original checklist item:** Exercise unavailable-service behavior when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C087-T01 · Scenario record:** Write the “Unavailable-service behavior” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “Missing service routes do not trigger unbounded retries”.
- [ ] **UC-M08.08-C087-T02 · Baseline capture:** Create a known-valid “Unavailable-service behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C087-T03 · Injection map:** Locate the “Unavailable-service behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Unavailable-service behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C087-T05 · Controlled trigger:** Introduce the controlled “Unavailable-service behavior” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C087-T06 · Intermediate inspection:** Inspect the “Unavailable-service behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Unavailable-service behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Unavailable-service behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C087-T09 · Repeat and compare:** Repeat the selected “Unavailable-service behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C087-T10 · Failure evidence:** Publish the “Unavailable-service behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C088 · Bounds

**Original checklist item:** Choose, document and test limits for retry ceiling and resolution deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Unavailable-service behavior”: “Retry ceiling and resolution deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C088-T02 · Measurement method:** Choose how to observe each “Unavailable-service behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C088-T03 · Budget decision:** Select justified resource and input limits for “Unavailable-service behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Unavailable-service behavior” cases for “Retry ceiling and resolution deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Unavailable-service behavior” limit; preserve “Missing service routes do not trigger unbounded retries”.
- [ ] **UC-M08.08-C088-T06 · Normal measurement:** Run or review the normal “Unavailable-service behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C088-T07 · At-limit measurement:** Exercise the “Unavailable-service behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C088-T08 · Over-limit measurement:** Exercise the “Unavailable-service behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C088-T09 · Uncovered-scope report:** List the “Unavailable-service behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C088-T10 · Limit evidence:** Publish the selected “Unavailable-service behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for unavailable-service behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C089-T01 · Event inventory:** List the “Unavailable-service behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Unavailable-service behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C089-T03 · Failure mapping:** Map each documented “Unavailable-service behavior” refusal or error to a diagnostic outcome; include “A caller loops indefinitely while every endpoint is expired” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C089-T04 · Emission path:** Add the “Unavailable-service behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C089-T05 · Redaction check:** Test “Unavailable-service behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C089-T06 · Output budget:** Set and exercise bounded “Unavailable-service behavior” message size, rate and retention compatible with “Retry ceiling and resolution deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C089-T07 · Success/refusal fixtures:** Capture “Unavailable-service behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Unavailable-service behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C089-T09 · Operator review:** Read the “Unavailable-service behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C089-T10 · Diagnostic evidence:** Publish redacted “Unavailable-service behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for unavailable-service behavior; label unexecuted checks as untested.

- [ ] **UC-M08.08-C090-T01 · Evidence inventory:** List the “Unavailable-service behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C090-T02 · Artifact references:** Record the exact “Unavailable-service behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C090-T03 · Fixture references:** Attach the “Unavailable-service behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “A caller loops indefinitely while every endpoint is expired” as a distinct evidence case.
- [ ] **UC-M08.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Unavailable-service behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C090-T05 · Environment record:** Record the actual “Unavailable-service behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C090-T06 · Expected versus observed:** Pair every “Unavailable-service behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C090-T07 · Failure and limit records:** Attach “Unavailable-service behavior” change/failure and bounds evidence where required; include uncovered “Retry ceiling and resolution deadline” and unresolved violations of “Missing service routes do not trigger unbounded retries”.
- [ ] **UC-M08.08-C090-T08 · Evidence hygiene:** Check the “Unavailable-service behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C090-T09 · Reproduction review:** Have the “Unavailable-service behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C090-T10 · Acceptance linkage:** Link the “Unavailable-service behavior” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Discovery acceptance tests

**Source delivery:** Exercise unauthorized registration, expiry, replacement and stop withdrawal.

**Source invariant:** No newly routed request reaches a withdrawn obsolete generation.

**Source negative case:** A cached route survives beyond its allowed expiry after stop.

**Source bounded quantities:** Endpoint matrix and cache invalidation trials.

### UC-M08.08-C091 · Contract

**Original checklist item:** Specify discovery acceptance tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.08-C091-T01 · Scope statement:** Draft the operation boundary for “Discovery acceptance tests” within Optional service discovery and routing; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Discovery acceptance tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.08-C091-T03 · Output inventory:** List the outputs of “Discovery acceptance tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Discovery acceptance tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.08-C091-T05 · Prerequisite contract:** Map “Discovery acceptance tests” to the source component prerequisites (UC-M05.05, UC-M05.06, UC-M08.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.08-C091-T06 · Authority map:** Identify who may produce, change and consume “Discovery acceptance tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.08-C091-T07 · Invariant clause:** Add a normative clause for “Discovery acceptance tests” that preserves “No newly routed request reaches a withdrawn obsolete generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Discovery acceptance tests”; include the source counterexample “A cached route survives beyond its allowed expiry after stop” and the intended safe disposition.
- [ ] **UC-M08.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Endpoint matrix and cache invalidation trials” in the “Discovery acceptance tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.08-C091-T10 · Contract review:** Review the “Discovery acceptance tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.08-C092 · Delivery

**Original checklist item:** Exercise unauthorized registration, expiry, replacement and stop withdrawal.

- [ ] **UC-M08.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Discovery acceptance tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.08-C092-T02 · Change plan:** Break the source delivery for “Discovery acceptance tests” into concrete edit targets and reviewable outputs; keep the UC-M08.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.08-C092-T03 · Core artifact:** Create the “Discovery acceptance tests” fixture or harness for this source instruction: Exercise unauthorized registration, expiry, replacement and stop withdrawal.
- [ ] **UC-M08.08-C092-T04 · Concrete realization:** Connect the “Discovery acceptance tests” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M08.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Discovery acceptance tests” needed to preserve “No newly routed request reaches a withdrawn obsolete generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.08-C092-T06 · Dependency connection:** Connect the “Discovery acceptance tests” implementation to authenticated endpoint publication, readiness and stop/drain withdrawal; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.08-C092-T07 · Resource behavior:** Account for “Endpoint matrix and cache invalidation trials” in “Discovery acceptance tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.08-C092-T08 · Delivery check:** Run the smallest real “Discovery acceptance tests” path and its adverse fixture “A cached route survives beyond its allowed expiry after stop”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.08-C092-T09 · Patch review:** Review the “Discovery acceptance tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.08-C092-T10 · Delivery handoff:** Publish the “Discovery acceptance tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No newly routed request reaches a withdrawn obsolete generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “Discovery acceptance tests”; copy its required invariant exactly: “No newly routed request reaches a withdrawn obsolete generation”.
- [ ] **UC-M08.08-C093-T02 · Observable terms:** Define each term in the “Discovery acceptance tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.08-C093-T03 · Precondition set:** List the preconditions under which “No newly routed request reaches a withdrawn obsolete generation” must hold for “Discovery acceptance tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.08-C093-T04 · Transition coverage:** Map the “Discovery acceptance tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Discovery acceptance tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.08-C093-T06 · Satisfying fixture:** Create a concrete “Discovery acceptance tests” case that satisfies “No newly routed request reaches a withdrawn obsolete generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.08-C093-T07 · Violating fixture:** Create the source counterexample “A cached route survives beyond its allowed expiry after stop” for “Discovery acceptance tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.08-C093-T08 · Enforcement evidence:** Exercise the “Discovery acceptance tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.08-C093-T09 · Regression linkage:** Link the “Discovery acceptance tests” property to changes in authenticated endpoint publication, readiness and stop/drain withdrawal; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.08-C093-T10 · Property disposition:** Compare the satisfying and violating “Discovery acceptance tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.08-C094 · Integration

**Original checklist item:** Integrate discovery acceptance tests with authenticated endpoint publication, readiness and stop/drain withdrawal; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Discovery acceptance tests” across authenticated endpoint publication, readiness and stop/drain withdrawal; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.08-C094-T02 · Field mapping:** Map every “Discovery acceptance tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Discovery acceptance tests” (source dependency list: UC-M05.05, UC-M05.06, UC-M08.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.08-C094-T04 · Ownership agreement:** Specify who owns “Discovery acceptance tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.08-C094-T05 · Handoff implementation:** Connect “Discovery acceptance tests” through the mapped seam using the real adapter or explicit specification reference; preserve “No newly routed request reaches a withdrawn obsolete generation” across the handoff.
- [ ] **UC-M08.08-C094-T06 · Absent-input case:** Omit one required “Discovery acceptance tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.08-C094-T07 · Stale-input case:** Supply an outdated “Discovery acceptance tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.08-C094-T08 · Incompatible-input case:** Supply an incompatible “Discovery acceptance tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.08-C094-T09 · Valid integration trace:** Run a valid “Discovery acceptance tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.08-C094-T10 · Seam review:** Reconcile the “Discovery acceptance tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.08-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for discovery acceptance tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.08-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Discovery acceptance tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.08-C095-T02 · Expected-result oracle:** Specify the “Discovery acceptance tests” expected result independently of the implementation output; include the property “No newly routed request reaches a withdrawn obsolete generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.08-C095-T03 · Fixture material:** Create the concrete “Discovery acceptance tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.08-C095-T04 · Target preparation:** Prepare the “Discovery acceptance tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.08-C095-T05 · Initial-state record:** Record the initial “Discovery acceptance tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.08-C095-T06 · Valid-path execution:** Execute the “Discovery acceptance tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.08-C095-T07 · Outcome comparison:** Compare every declared “Discovery acceptance tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.08-C095-T08 · State and bounds check:** Inspect the “Discovery acceptance tests” ownership/state effects and actual use of “Endpoint matrix and cache invalidation trials”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.08-C095-T09 · Repeatability check:** Repeat the same “Discovery acceptance tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.08-C095-T10 · Positive evidence:** Attach the “Discovery acceptance tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.08-C096 · Negative test

**Original checklist item:** Negative case: A cached route survives beyond its allowed expiry after stop. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “Discovery acceptance tests” source counterexample: “A cached route survives beyond its allowed expiry after stop”; state which precondition or invariant it challenges.
- [ ] **UC-M08.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Discovery acceptance tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.08-C096-T03 · Valid control:** Construct a valid “Discovery acceptance tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.08-C096-T04 · Minimal adverse input:** Derive the “Discovery acceptance tests” adverse fixture from the control with the smallest documented change needed to reproduce “A cached route survives beyond its allowed expiry after stop”; retain that change as reproducible data.
- [ ] **UC-M08.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Discovery acceptance tests”; require “No newly routed request reaches a withdrawn obsolete generation” and forbid a false-success verdict.
- [ ] **UC-M08.08-C096-T06 · Adverse execution:** Exercise the “Discovery acceptance tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.08-C096-T07 · Effect inspection:** Inspect “Discovery acceptance tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.08-C096-T08 · Refusal versus failure:** Confirm the “Discovery acceptance tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.08-C096-T09 · Reset and retention:** Restore only the disposable “Discovery acceptance tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.08-C096-T10 · Negative regression:** Register the “Discovery acceptance tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.08-C097 · Change / failure test

**Original checklist item:** Exercise discovery acceptance tests when a service generation is replaced while clients retain cached routes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.08-C097-T01 · Scenario record:** Write the “Discovery acceptance tests” change/failure scenario exactly as supplied: a service generation is replaced while clients retain cached routes; identify the property that must remain true: “No newly routed request reaches a withdrawn obsolete generation”.
- [ ] **UC-M08.08-C097-T02 · Baseline capture:** Create a known-valid “Discovery acceptance tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.08-C097-T03 · Injection map:** Locate the “Discovery acceptance tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Discovery acceptance tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.08-C097-T05 · Controlled trigger:** Introduce the controlled “Discovery acceptance tests” scenario in the disposable fixture: a service generation is replaced while clients retain cached routes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.08-C097-T06 · Intermediate inspection:** Inspect the “Discovery acceptance tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Discovery acceptance tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Discovery acceptance tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.08-C097-T09 · Repeat and compare:** Repeat the selected “Discovery acceptance tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.08-C097-T10 · Failure evidence:** Publish the “Discovery acceptance tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.08-C098 · Bounds

**Original checklist item:** Choose, document and test limits for endpoint matrix and cache invalidation trials; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “Discovery acceptance tests”: “Endpoint matrix and cache invalidation trials”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.08-C098-T02 · Measurement method:** Choose how to observe each “Discovery acceptance tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.08-C098-T03 · Budget decision:** Select justified resource and input limits for “Discovery acceptance tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Discovery acceptance tests” cases for “Endpoint matrix and cache invalidation trials”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Discovery acceptance tests” limit; preserve “No newly routed request reaches a withdrawn obsolete generation”.
- [ ] **UC-M08.08-C098-T06 · Normal measurement:** Run or review the normal “Discovery acceptance tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.08-C098-T07 · At-limit measurement:** Exercise the “Discovery acceptance tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.08-C098-T08 · Over-limit measurement:** Exercise the “Discovery acceptance tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.08-C098-T09 · Uncovered-scope report:** List the “Discovery acceptance tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.08-C098-T10 · Limit evidence:** Publish the selected “Discovery acceptance tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.08-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for discovery acceptance tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.08-C099-T01 · Event inventory:** List the “Discovery acceptance tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.08-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Discovery acceptance tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.08-C099-T03 · Failure mapping:** Map each documented “Discovery acceptance tests” refusal or error to a diagnostic outcome; include “A cached route survives beyond its allowed expiry after stop” and prohibit conversion into a success message.
- [ ] **UC-M08.08-C099-T04 · Emission path:** Add the “Discovery acceptance tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.08-C099-T05 · Redaction check:** Test “Discovery acceptance tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.08-C099-T06 · Output budget:** Set and exercise bounded “Discovery acceptance tests” message size, rate and retention compatible with “Endpoint matrix and cache invalidation trials”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.08-C099-T07 · Success/refusal fixtures:** Capture “Discovery acceptance tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.08-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Discovery acceptance tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.08-C099-T09 · Operator review:** Read the “Discovery acceptance tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.08-C099-T10 · Diagnostic evidence:** Publish redacted “Discovery acceptance tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for discovery acceptance tests; label unexecuted checks as untested.

- [ ] **UC-M08.08-C100-T01 · Evidence inventory:** List the “Discovery acceptance tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.08-C100-T02 · Artifact references:** Record the exact “Discovery acceptance tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.08-C100-T03 · Fixture references:** Attach the “Discovery acceptance tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “A cached route survives beyond its allowed expiry after stop” as a distinct evidence case.
- [ ] **UC-M08.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Discovery acceptance tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.08-C100-T05 · Environment record:** Record the actual “Discovery acceptance tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.08-C100-T06 · Expected versus observed:** Pair every “Discovery acceptance tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.08-C100-T07 · Failure and limit records:** Attach “Discovery acceptance tests” change/failure and bounds evidence where required; include uncovered “Endpoint matrix and cache invalidation trials” and unresolved violations of “No newly routed request reaches a withdrawn obsolete generation”.
- [ ] **UC-M08.08-C100-T08 · Evidence hygiene:** Check the “Discovery acceptance tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.08-C100-T09 · Reproduction review:** Have the “Discovery acceptance tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.08-C100-T10 · Acceptance linkage:** Link the “Discovery acceptance tests” evidence to its parent and UC-M08.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

