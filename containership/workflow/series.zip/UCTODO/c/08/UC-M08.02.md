# UC-M08.02 — Message framing and versioned serialization

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/08.md)

| Field | Preserved source value |
|---|---|
| Workstream | 08. Guest communication and data plane |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M08.01](../08/UC-M08.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3], [S4]. |

## Original requirement

Specify maximum lengths, canonical field encodings, numeric bounds, checksums and compatibility handling for every frame.

**Original acceptance criterion:** Truncated, oversized, duplicate-field and mismatched-version messages are rejected without desynchronizing the channel.

**Source trace:** Original checklist `UC100/c/08/UC-M08.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 725–735 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Frame envelope

**Source delivery:** Define frame type, version, length and integrity fields with explicit encodings.

**Source invariant:** Every frame has a single unambiguous boundary.

**Source negative case:** A frame declares conflicting header and payload lengths.

**Source bounded quantities:** Header bytes and maximum frame size.

### UC-M08.02-C001 · Contract

**Original checklist item:** Specify frame envelope inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C001-T01 · Scope statement:** Draft the operation boundary for “Frame envelope” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Frame envelope”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C001-T03 · Output inventory:** List the outputs of “Frame envelope” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Frame envelope”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C001-T05 · Prerequisite contract:** Map “Frame envelope” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Frame envelope”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C001-T07 · Invariant clause:** Add a normative clause for “Frame envelope” that preserves “Every frame has a single unambiguous boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Frame envelope”; include the source counterexample “A frame declares conflicting header and payload lengths” and the intended safe disposition.
- [ ] **UC-M08.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Header bytes and maximum frame size” in the “Frame envelope” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C001-T10 · Contract review:** Review the “Frame envelope” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C002 · Delivery

**Original checklist item:** Define frame type, version, length and integrity fields with explicit encodings.

- [ ] **UC-M08.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Frame envelope”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C002-T02 · Change plan:** Break the source delivery for “Frame envelope” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C002-T03 · Core artifact:** Create the “Frame envelope” model, schema or inventory that realizes this source instruction: Define frame type, version, length and integrity fields with explicit encodings.
- [ ] **UC-M08.02-C002-T04 · Concrete realization:** Populate “Frame envelope” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Frame envelope” needed to preserve “Every frame has a single unambiguous boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C002-T06 · Dependency connection:** Connect the “Frame envelope” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C002-T07 · Resource behavior:** Account for “Header bytes and maximum frame size” in “Frame envelope”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C002-T08 · Delivery check:** Run the smallest real “Frame envelope” path and its adverse fixture “A frame declares conflicting header and payload lengths”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C002-T09 · Patch review:** Review the “Frame envelope” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C002-T10 · Delivery handoff:** Publish the “Frame envelope” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every frame has a single unambiguous boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Frame envelope”; copy its required invariant exactly: “Every frame has a single unambiguous boundary”.
- [ ] **UC-M08.02-C003-T02 · Observable terms:** Define each term in the “Frame envelope” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C003-T03 · Precondition set:** List the preconditions under which “Every frame has a single unambiguous boundary” must hold for “Frame envelope”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C003-T04 · Transition coverage:** Map the “Frame envelope” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Frame envelope”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C003-T06 · Satisfying fixture:** Create a concrete “Frame envelope” case that satisfies “Every frame has a single unambiguous boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C003-T07 · Violating fixture:** Create the source counterexample “A frame declares conflicting header and payload lengths” for “Frame envelope”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C003-T08 · Enforcement evidence:** Exercise the “Frame envelope” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C003-T09 · Regression linkage:** Link the “Frame envelope” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Frame envelope” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C004 · Integration

**Original checklist item:** Integrate frame envelope with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Frame envelope” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C004-T02 · Field mapping:** Map every “Frame envelope” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Frame envelope” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C004-T04 · Ownership agreement:** Specify who owns “Frame envelope” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C004-T05 · Handoff implementation:** Connect “Frame envelope” through the mapped seam using the real adapter or explicit specification reference; preserve “Every frame has a single unambiguous boundary” across the handoff.
- [ ] **UC-M08.02-C004-T06 · Absent-input case:** Omit one required “Frame envelope” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C004-T07 · Stale-input case:** Supply an outdated “Frame envelope” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Frame envelope” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C004-T09 · Valid integration trace:** Run a valid “Frame envelope” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C004-T10 · Seam review:** Reconcile the “Frame envelope” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for frame envelope; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Frame envelope” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C005-T02 · Expected-result oracle:** Specify the “Frame envelope” expected result independently of the implementation output; include the property “Every frame has a single unambiguous boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C005-T03 · Fixture material:** Create the concrete “Frame envelope” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C005-T04 · Target preparation:** Prepare the “Frame envelope” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C005-T05 · Initial-state record:** Record the initial “Frame envelope” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C005-T06 · Valid-path execution:** Execute the “Frame envelope” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C005-T07 · Outcome comparison:** Compare every declared “Frame envelope” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C005-T08 · State and bounds check:** Inspect the “Frame envelope” ownership/state effects and actual use of “Header bytes and maximum frame size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C005-T09 · Repeatability check:** Repeat the same “Frame envelope” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C005-T10 · Positive evidence:** Attach the “Frame envelope” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C006 · Negative test

**Original checklist item:** Negative case: A frame declares conflicting header and payload lengths. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Frame envelope” source counterexample: “A frame declares conflicting header and payload lengths”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Frame envelope”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C006-T03 · Valid control:** Construct a valid “Frame envelope” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C006-T04 · Minimal adverse input:** Derive the “Frame envelope” adverse fixture from the control with the smallest documented change needed to reproduce “A frame declares conflicting header and payload lengths”; retain that change as reproducible data.
- [ ] **UC-M08.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Frame envelope”; require “Every frame has a single unambiguous boundary” and forbid a false-success verdict.
- [ ] **UC-M08.02-C006-T06 · Adverse execution:** Exercise the “Frame envelope” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C006-T07 · Effect inspection:** Inspect “Frame envelope” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C006-T08 · Refusal versus failure:** Confirm the “Frame envelope” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C006-T09 · Reset and retention:** Restore only the disposable “Frame envelope” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C006-T10 · Negative regression:** Register the “Frame envelope” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C007 · Change / failure test

**Original checklist item:** Exercise frame envelope when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C007-T01 · Scenario record:** Write the “Frame envelope” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “Every frame has a single unambiguous boundary”.
- [ ] **UC-M08.02-C007-T02 · Baseline capture:** Create a known-valid “Frame envelope” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C007-T03 · Injection map:** Locate the “Frame envelope” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Frame envelope” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C007-T05 · Controlled trigger:** Introduce the controlled “Frame envelope” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C007-T06 · Intermediate inspection:** Inspect the “Frame envelope” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Frame envelope”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Frame envelope” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C007-T09 · Repeat and compare:** Repeat the selected “Frame envelope” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C007-T10 · Failure evidence:** Publish the “Frame envelope” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for header bytes and maximum frame size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Frame envelope”: “Header bytes and maximum frame size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C008-T02 · Measurement method:** Choose how to observe each “Frame envelope” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C008-T03 · Budget decision:** Select justified resource and input limits for “Frame envelope”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Frame envelope” cases for “Header bytes and maximum frame size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Frame envelope” limit; preserve “Every frame has a single unambiguous boundary”.
- [ ] **UC-M08.02-C008-T06 · Normal measurement:** Run or review the normal “Frame envelope” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C008-T07 · At-limit measurement:** Exercise the “Frame envelope” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C008-T08 · Over-limit measurement:** Exercise the “Frame envelope” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C008-T09 · Uncovered-scope report:** List the “Frame envelope” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C008-T10 · Limit evidence:** Publish the selected “Frame envelope” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for frame envelope with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C009-T01 · Event inventory:** List the “Frame envelope” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Frame envelope” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C009-T03 · Failure mapping:** Map each documented “Frame envelope” refusal or error to a diagnostic outcome; include “A frame declares conflicting header and payload lengths” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C009-T04 · Emission path:** Add the “Frame envelope” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C009-T05 · Redaction check:** Test “Frame envelope” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C009-T06 · Output budget:** Set and exercise bounded “Frame envelope” message size, rate and retention compatible with “Header bytes and maximum frame size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C009-T07 · Success/refusal fixtures:** Capture “Frame envelope” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Frame envelope” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C009-T09 · Operator review:** Read the “Frame envelope” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C009-T10 · Diagnostic evidence:** Publish redacted “Frame envelope” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for frame envelope; label unexecuted checks as untested.

- [ ] **UC-M08.02-C010-T01 · Evidence inventory:** List the “Frame envelope” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C010-T02 · Artifact references:** Record the exact “Frame envelope” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C010-T03 · Fixture references:** Attach the “Frame envelope” fixture IDs, input identities and oracle definition; preserve the source counterexample “A frame declares conflicting header and payload lengths” as a distinct evidence case.
- [ ] **UC-M08.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Frame envelope”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C010-T05 · Environment record:** Record the actual “Frame envelope” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C010-T06 · Expected versus observed:** Pair every “Frame envelope” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C010-T07 · Failure and limit records:** Attach “Frame envelope” change/failure and bounds evidence where required; include uncovered “Header bytes and maximum frame size” and unresolved violations of “Every frame has a single unambiguous boundary”.
- [ ] **UC-M08.02-C010-T08 · Evidence hygiene:** Check the “Frame envelope” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C010-T09 · Reproduction review:** Have the “Frame envelope” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C010-T10 · Acceptance linkage:** Link the “Frame envelope” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Maximum lengths

**Source delivery:** Apply frame, field and aggregate message limits before allocation.

**Source invariant:** A length field cannot trigger unbounded buffering.

**Source negative case:** A short header advertises an enormous payload.

**Source bounded quantities:** Frame bytes and per-channel buffered bytes.

### UC-M08.02-C011 · Contract

**Original checklist item:** Specify maximum lengths inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C011-T01 · Scope statement:** Draft the operation boundary for “Maximum lengths” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Maximum lengths”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C011-T03 · Output inventory:** List the outputs of “Maximum lengths” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Maximum lengths”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C011-T05 · Prerequisite contract:** Map “Maximum lengths” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Maximum lengths”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C011-T07 · Invariant clause:** Add a normative clause for “Maximum lengths” that preserves “A length field cannot trigger unbounded buffering”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Maximum lengths”; include the source counterexample “A short header advertises an enormous payload” and the intended safe disposition.
- [ ] **UC-M08.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Frame bytes and per-channel buffered bytes” in the “Maximum lengths” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C011-T10 · Contract review:** Review the “Maximum lengths” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C012 · Delivery

**Original checklist item:** Apply frame, field and aggregate message limits before allocation.

- [ ] **UC-M08.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Maximum lengths”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C012-T02 · Change plan:** Break the source delivery for “Maximum lengths” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Maximum lengths” that realizes this source instruction: Apply frame, field and aggregate message limits before allocation.
- [ ] **UC-M08.02-C012-T04 · Concrete realization:** Trace “Maximum lengths” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Maximum lengths” needed to preserve “A length field cannot trigger unbounded buffering”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C012-T06 · Dependency connection:** Connect the “Maximum lengths” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C012-T07 · Resource behavior:** Account for “Frame bytes and per-channel buffered bytes” in “Maximum lengths”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C012-T08 · Delivery check:** Run the smallest real “Maximum lengths” path and its adverse fixture “A short header advertises an enormous payload”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C012-T09 · Patch review:** Review the “Maximum lengths” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C012-T10 · Delivery handoff:** Publish the “Maximum lengths” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A length field cannot trigger unbounded buffering. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Maximum lengths”; copy its required invariant exactly: “A length field cannot trigger unbounded buffering”.
- [ ] **UC-M08.02-C013-T02 · Observable terms:** Define each term in the “Maximum lengths” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C013-T03 · Precondition set:** List the preconditions under which “A length field cannot trigger unbounded buffering” must hold for “Maximum lengths”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C013-T04 · Transition coverage:** Map the “Maximum lengths” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Maximum lengths”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C013-T06 · Satisfying fixture:** Create a concrete “Maximum lengths” case that satisfies “A length field cannot trigger unbounded buffering”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C013-T07 · Violating fixture:** Create the source counterexample “A short header advertises an enormous payload” for “Maximum lengths”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C013-T08 · Enforcement evidence:** Exercise the “Maximum lengths” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C013-T09 · Regression linkage:** Link the “Maximum lengths” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Maximum lengths” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C014 · Integration

**Original checklist item:** Integrate maximum lengths with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Maximum lengths” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C014-T02 · Field mapping:** Map every “Maximum lengths” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Maximum lengths” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C014-T04 · Ownership agreement:** Specify who owns “Maximum lengths” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C014-T05 · Handoff implementation:** Connect “Maximum lengths” through the mapped seam using the real adapter or explicit specification reference; preserve “A length field cannot trigger unbounded buffering” across the handoff.
- [ ] **UC-M08.02-C014-T06 · Absent-input case:** Omit one required “Maximum lengths” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C014-T07 · Stale-input case:** Supply an outdated “Maximum lengths” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Maximum lengths” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C014-T09 · Valid integration trace:** Run a valid “Maximum lengths” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C014-T10 · Seam review:** Reconcile the “Maximum lengths” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for maximum lengths; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Maximum lengths” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C015-T02 · Expected-result oracle:** Specify the “Maximum lengths” expected result independently of the implementation output; include the property “A length field cannot trigger unbounded buffering” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C015-T03 · Fixture material:** Create the concrete “Maximum lengths” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C015-T04 · Target preparation:** Prepare the “Maximum lengths” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C015-T05 · Initial-state record:** Record the initial “Maximum lengths” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C015-T06 · Valid-path execution:** Execute the “Maximum lengths” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C015-T07 · Outcome comparison:** Compare every declared “Maximum lengths” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C015-T08 · State and bounds check:** Inspect the “Maximum lengths” ownership/state effects and actual use of “Frame bytes and per-channel buffered bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C015-T09 · Repeatability check:** Repeat the same “Maximum lengths” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C015-T10 · Positive evidence:** Attach the “Maximum lengths” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C016 · Negative test

**Original checklist item:** Negative case: A short header advertises an enormous payload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Maximum lengths” source counterexample: “A short header advertises an enormous payload”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Maximum lengths”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C016-T03 · Valid control:** Construct a valid “Maximum lengths” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C016-T04 · Minimal adverse input:** Derive the “Maximum lengths” adverse fixture from the control with the smallest documented change needed to reproduce “A short header advertises an enormous payload”; retain that change as reproducible data.
- [ ] **UC-M08.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Maximum lengths”; require “A length field cannot trigger unbounded buffering” and forbid a false-success verdict.
- [ ] **UC-M08.02-C016-T06 · Adverse execution:** Exercise the “Maximum lengths” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C016-T07 · Effect inspection:** Inspect “Maximum lengths” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C016-T08 · Refusal versus failure:** Confirm the “Maximum lengths” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C016-T09 · Reset and retention:** Restore only the disposable “Maximum lengths” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C016-T10 · Negative regression:** Register the “Maximum lengths” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C017 · Change / failure test

**Original checklist item:** Exercise maximum lengths when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C017-T01 · Scenario record:** Write the “Maximum lengths” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “A length field cannot trigger unbounded buffering”.
- [ ] **UC-M08.02-C017-T02 · Baseline capture:** Create a known-valid “Maximum lengths” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C017-T03 · Injection map:** Locate the “Maximum lengths” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Maximum lengths” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C017-T05 · Controlled trigger:** Introduce the controlled “Maximum lengths” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C017-T06 · Intermediate inspection:** Inspect the “Maximum lengths” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Maximum lengths”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Maximum lengths” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C017-T09 · Repeat and compare:** Repeat the selected “Maximum lengths” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C017-T10 · Failure evidence:** Publish the “Maximum lengths” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for frame bytes and per-channel buffered bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Maximum lengths”: “Frame bytes and per-channel buffered bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C018-T02 · Measurement method:** Choose how to observe each “Maximum lengths” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C018-T03 · Budget decision:** Select justified resource and input limits for “Maximum lengths”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Maximum lengths” cases for “Frame bytes and per-channel buffered bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Maximum lengths” limit; preserve “A length field cannot trigger unbounded buffering”.
- [ ] **UC-M08.02-C018-T06 · Normal measurement:** Run or review the normal “Maximum lengths” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C018-T07 · At-limit measurement:** Exercise the “Maximum lengths” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C018-T08 · Over-limit measurement:** Exercise the “Maximum lengths” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C018-T09 · Uncovered-scope report:** List the “Maximum lengths” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C018-T10 · Limit evidence:** Publish the selected “Maximum lengths” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for maximum lengths with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C019-T01 · Event inventory:** List the “Maximum lengths” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Maximum lengths” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C019-T03 · Failure mapping:** Map each documented “Maximum lengths” refusal or error to a diagnostic outcome; include “A short header advertises an enormous payload” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C019-T04 · Emission path:** Add the “Maximum lengths” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C019-T05 · Redaction check:** Test “Maximum lengths” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C019-T06 · Output budget:** Set and exercise bounded “Maximum lengths” message size, rate and retention compatible with “Frame bytes and per-channel buffered bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C019-T07 · Success/refusal fixtures:** Capture “Maximum lengths” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Maximum lengths” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C019-T09 · Operator review:** Read the “Maximum lengths” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C019-T10 · Diagnostic evidence:** Publish redacted “Maximum lengths” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for maximum lengths; label unexecuted checks as untested.

- [ ] **UC-M08.02-C020-T01 · Evidence inventory:** List the “Maximum lengths” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C020-T02 · Artifact references:** Record the exact “Maximum lengths” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C020-T03 · Fixture references:** Attach the “Maximum lengths” fixture IDs, input identities and oracle definition; preserve the source counterexample “A short header advertises an enormous payload” as a distinct evidence case.
- [ ] **UC-M08.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Maximum lengths”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C020-T05 · Environment record:** Record the actual “Maximum lengths” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C020-T06 · Expected versus observed:** Pair every “Maximum lengths” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C020-T07 · Failure and limit records:** Attach “Maximum lengths” change/failure and bounds evidence where required; include uncovered “Frame bytes and per-channel buffered bytes” and unresolved violations of “A length field cannot trigger unbounded buffering”.
- [ ] **UC-M08.02-C020-T08 · Evidence hygiene:** Check the “Maximum lengths” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C020-T09 · Reproduction review:** Have the “Maximum lengths” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C020-T10 · Acceptance linkage:** Link the “Maximum lengths” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Canonical field encoding

**Source delivery:** Specify numeric byte order, text encoding and canonical field representation.

**Source invariant:** Equivalent accepted messages decode to equivalent typed values.

**Source negative case:** Two consumers interpret the same numeric field differently.

**Source bounded quantities:** Field count and encoding expansion.

### UC-M08.02-C021 · Contract

**Original checklist item:** Specify canonical field encoding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C021-T01 · Scope statement:** Draft the operation boundary for “Canonical field encoding” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Canonical field encoding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C021-T03 · Output inventory:** List the outputs of “Canonical field encoding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Canonical field encoding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C021-T05 · Prerequisite contract:** Map “Canonical field encoding” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Canonical field encoding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C021-T07 · Invariant clause:** Add a normative clause for “Canonical field encoding” that preserves “Equivalent accepted messages decode to equivalent typed values”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Canonical field encoding”; include the source counterexample “Two consumers interpret the same numeric field differently” and the intended safe disposition.
- [ ] **UC-M08.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Field count and encoding expansion” in the “Canonical field encoding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C021-T10 · Contract review:** Review the “Canonical field encoding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C022 · Delivery

**Original checklist item:** Specify numeric byte order, text encoding and canonical field representation.

- [ ] **UC-M08.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Canonical field encoding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C022-T02 · Change plan:** Break the source delivery for “Canonical field encoding” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C022-T03 · Core artifact:** Create the “Canonical field encoding” model, schema or inventory that realizes this source instruction: Specify numeric byte order, text encoding and canonical field representation.
- [ ] **UC-M08.02-C022-T04 · Concrete realization:** Populate “Canonical field encoding” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Canonical field encoding” needed to preserve “Equivalent accepted messages decode to equivalent typed values”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C022-T06 · Dependency connection:** Connect the “Canonical field encoding” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C022-T07 · Resource behavior:** Account for “Field count and encoding expansion” in “Canonical field encoding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C022-T08 · Delivery check:** Run the smallest real “Canonical field encoding” path and its adverse fixture “Two consumers interpret the same numeric field differently”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C022-T09 · Patch review:** Review the “Canonical field encoding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C022-T10 · Delivery handoff:** Publish the “Canonical field encoding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Equivalent accepted messages decode to equivalent typed values. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Canonical field encoding”; copy its required invariant exactly: “Equivalent accepted messages decode to equivalent typed values”.
- [ ] **UC-M08.02-C023-T02 · Observable terms:** Define each term in the “Canonical field encoding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C023-T03 · Precondition set:** List the preconditions under which “Equivalent accepted messages decode to equivalent typed values” must hold for “Canonical field encoding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C023-T04 · Transition coverage:** Map the “Canonical field encoding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Canonical field encoding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C023-T06 · Satisfying fixture:** Create a concrete “Canonical field encoding” case that satisfies “Equivalent accepted messages decode to equivalent typed values”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C023-T07 · Violating fixture:** Create the source counterexample “Two consumers interpret the same numeric field differently” for “Canonical field encoding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C023-T08 · Enforcement evidence:** Exercise the “Canonical field encoding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C023-T09 · Regression linkage:** Link the “Canonical field encoding” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Canonical field encoding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C024 · Integration

**Original checklist item:** Integrate canonical field encoding with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Canonical field encoding” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C024-T02 · Field mapping:** Map every “Canonical field encoding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Canonical field encoding” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C024-T04 · Ownership agreement:** Specify who owns “Canonical field encoding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C024-T05 · Handoff implementation:** Connect “Canonical field encoding” through the mapped seam using the real adapter or explicit specification reference; preserve “Equivalent accepted messages decode to equivalent typed values” across the handoff.
- [ ] **UC-M08.02-C024-T06 · Absent-input case:** Omit one required “Canonical field encoding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C024-T07 · Stale-input case:** Supply an outdated “Canonical field encoding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Canonical field encoding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C024-T09 · Valid integration trace:** Run a valid “Canonical field encoding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C024-T10 · Seam review:** Reconcile the “Canonical field encoding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for canonical field encoding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Canonical field encoding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C025-T02 · Expected-result oracle:** Specify the “Canonical field encoding” expected result independently of the implementation output; include the property “Equivalent accepted messages decode to equivalent typed values” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C025-T03 · Fixture material:** Create the concrete “Canonical field encoding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C025-T04 · Target preparation:** Prepare the “Canonical field encoding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C025-T05 · Initial-state record:** Record the initial “Canonical field encoding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C025-T06 · Valid-path execution:** Execute the “Canonical field encoding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C025-T07 · Outcome comparison:** Compare every declared “Canonical field encoding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C025-T08 · State and bounds check:** Inspect the “Canonical field encoding” ownership/state effects and actual use of “Field count and encoding expansion”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C025-T09 · Repeatability check:** Repeat the same “Canonical field encoding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C025-T10 · Positive evidence:** Attach the “Canonical field encoding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C026 · Negative test

**Original checklist item:** Negative case: Two consumers interpret the same numeric field differently. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Canonical field encoding” source counterexample: “Two consumers interpret the same numeric field differently”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Canonical field encoding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C026-T03 · Valid control:** Construct a valid “Canonical field encoding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C026-T04 · Minimal adverse input:** Derive the “Canonical field encoding” adverse fixture from the control with the smallest documented change needed to reproduce “Two consumers interpret the same numeric field differently”; retain that change as reproducible data.
- [ ] **UC-M08.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Canonical field encoding”; require “Equivalent accepted messages decode to equivalent typed values” and forbid a false-success verdict.
- [ ] **UC-M08.02-C026-T06 · Adverse execution:** Exercise the “Canonical field encoding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C026-T07 · Effect inspection:** Inspect “Canonical field encoding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C026-T08 · Refusal versus failure:** Confirm the “Canonical field encoding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C026-T09 · Reset and retention:** Restore only the disposable “Canonical field encoding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C026-T10 · Negative regression:** Register the “Canonical field encoding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C027 · Change / failure test

**Original checklist item:** Exercise canonical field encoding when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C027-T01 · Scenario record:** Write the “Canonical field encoding” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “Equivalent accepted messages decode to equivalent typed values”.
- [ ] **UC-M08.02-C027-T02 · Baseline capture:** Create a known-valid “Canonical field encoding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C027-T03 · Injection map:** Locate the “Canonical field encoding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Canonical field encoding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C027-T05 · Controlled trigger:** Introduce the controlled “Canonical field encoding” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C027-T06 · Intermediate inspection:** Inspect the “Canonical field encoding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Canonical field encoding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Canonical field encoding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C027-T09 · Repeat and compare:** Repeat the selected “Canonical field encoding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C027-T10 · Failure evidence:** Publish the “Canonical field encoding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for field count and encoding expansion; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Canonical field encoding”: “Field count and encoding expansion”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C028-T02 · Measurement method:** Choose how to observe each “Canonical field encoding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Canonical field encoding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Canonical field encoding” cases for “Field count and encoding expansion”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Canonical field encoding” limit; preserve “Equivalent accepted messages decode to equivalent typed values”.
- [ ] **UC-M08.02-C028-T06 · Normal measurement:** Run or review the normal “Canonical field encoding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C028-T07 · At-limit measurement:** Exercise the “Canonical field encoding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C028-T08 · Over-limit measurement:** Exercise the “Canonical field encoding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C028-T09 · Uncovered-scope report:** List the “Canonical field encoding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C028-T10 · Limit evidence:** Publish the selected “Canonical field encoding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for canonical field encoding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C029-T01 · Event inventory:** List the “Canonical field encoding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Canonical field encoding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C029-T03 · Failure mapping:** Map each documented “Canonical field encoding” refusal or error to a diagnostic outcome; include “Two consumers interpret the same numeric field differently” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C029-T04 · Emission path:** Add the “Canonical field encoding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C029-T05 · Redaction check:** Test “Canonical field encoding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C029-T06 · Output budget:** Set and exercise bounded “Canonical field encoding” message size, rate and retention compatible with “Field count and encoding expansion”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C029-T07 · Success/refusal fixtures:** Capture “Canonical field encoding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Canonical field encoding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C029-T09 · Operator review:** Read the “Canonical field encoding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C029-T10 · Diagnostic evidence:** Publish redacted “Canonical field encoding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for canonical field encoding; label unexecuted checks as untested.

- [ ] **UC-M08.02-C030-T01 · Evidence inventory:** List the “Canonical field encoding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C030-T02 · Artifact references:** Record the exact “Canonical field encoding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C030-T03 · Fixture references:** Attach the “Canonical field encoding” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two consumers interpret the same numeric field differently” as a distinct evidence case.
- [ ] **UC-M08.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Canonical field encoding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C030-T05 · Environment record:** Record the actual “Canonical field encoding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C030-T06 · Expected versus observed:** Pair every “Canonical field encoding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C030-T07 · Failure and limit records:** Attach “Canonical field encoding” change/failure and bounds evidence where required; include uncovered “Field count and encoding expansion” and unresolved violations of “Equivalent accepted messages decode to equivalent typed values”.
- [ ] **UC-M08.02-C030-T08 · Evidence hygiene:** Check the “Canonical field encoding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C030-T09 · Reproduction review:** Have the “Canonical field encoding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C030-T10 · Acceptance linkage:** Link the “Canonical field encoding” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Numeric bounds

**Source delivery:** Validate widths, signedness and length arithmetic in serialization paths.

**Source invariant:** Numeric overflow cannot bypass a frame boundary check.

**Source negative case:** Payload length plus header size wraps during validation.

**Source bounded quantities:** Integer widths and arithmetic cases.

### UC-M08.02-C031 · Contract

**Original checklist item:** Specify numeric bounds inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C031-T01 · Scope statement:** Draft the operation boundary for “Numeric bounds” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Numeric bounds”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C031-T03 · Output inventory:** List the outputs of “Numeric bounds” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Numeric bounds”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C031-T05 · Prerequisite contract:** Map “Numeric bounds” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Numeric bounds”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C031-T07 · Invariant clause:** Add a normative clause for “Numeric bounds” that preserves “Numeric overflow cannot bypass a frame boundary check”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Numeric bounds”; include the source counterexample “Payload length plus header size wraps during validation” and the intended safe disposition.
- [ ] **UC-M08.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Integer widths and arithmetic cases” in the “Numeric bounds” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C031-T10 · Contract review:** Review the “Numeric bounds” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C032 · Delivery

**Original checklist item:** Validate widths, signedness and length arithmetic in serialization paths.

- [ ] **UC-M08.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Numeric bounds”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C032-T02 · Change plan:** Break the source delivery for “Numeric bounds” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Numeric bounds” that realizes this source instruction: Validate widths, signedness and length arithmetic in serialization paths.
- [ ] **UC-M08.02-C032-T04 · Concrete realization:** Trace “Numeric bounds” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Numeric bounds” needed to preserve “Numeric overflow cannot bypass a frame boundary check”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C032-T06 · Dependency connection:** Connect the “Numeric bounds” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C032-T07 · Resource behavior:** Account for “Integer widths and arithmetic cases” in “Numeric bounds”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C032-T08 · Delivery check:** Run the smallest real “Numeric bounds” path and its adverse fixture “Payload length plus header size wraps during validation”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C032-T09 · Patch review:** Review the “Numeric bounds” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C032-T10 · Delivery handoff:** Publish the “Numeric bounds” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Numeric overflow cannot bypass a frame boundary check. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Numeric bounds”; copy its required invariant exactly: “Numeric overflow cannot bypass a frame boundary check”.
- [ ] **UC-M08.02-C033-T02 · Observable terms:** Define each term in the “Numeric bounds” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C033-T03 · Precondition set:** List the preconditions under which “Numeric overflow cannot bypass a frame boundary check” must hold for “Numeric bounds”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C033-T04 · Transition coverage:** Map the “Numeric bounds” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Numeric bounds”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C033-T06 · Satisfying fixture:** Create a concrete “Numeric bounds” case that satisfies “Numeric overflow cannot bypass a frame boundary check”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C033-T07 · Violating fixture:** Create the source counterexample “Payload length plus header size wraps during validation” for “Numeric bounds”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C033-T08 · Enforcement evidence:** Exercise the “Numeric bounds” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C033-T09 · Regression linkage:** Link the “Numeric bounds” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Numeric bounds” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C034 · Integration

**Original checklist item:** Integrate numeric bounds with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Numeric bounds” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C034-T02 · Field mapping:** Map every “Numeric bounds” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Numeric bounds” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C034-T04 · Ownership agreement:** Specify who owns “Numeric bounds” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C034-T05 · Handoff implementation:** Connect “Numeric bounds” through the mapped seam using the real adapter or explicit specification reference; preserve “Numeric overflow cannot bypass a frame boundary check” across the handoff.
- [ ] **UC-M08.02-C034-T06 · Absent-input case:** Omit one required “Numeric bounds” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C034-T07 · Stale-input case:** Supply an outdated “Numeric bounds” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Numeric bounds” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C034-T09 · Valid integration trace:** Run a valid “Numeric bounds” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C034-T10 · Seam review:** Reconcile the “Numeric bounds” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for numeric bounds; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Numeric bounds” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C035-T02 · Expected-result oracle:** Specify the “Numeric bounds” expected result independently of the implementation output; include the property “Numeric overflow cannot bypass a frame boundary check” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C035-T03 · Fixture material:** Create the concrete “Numeric bounds” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C035-T04 · Target preparation:** Prepare the “Numeric bounds” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C035-T05 · Initial-state record:** Record the initial “Numeric bounds” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C035-T06 · Valid-path execution:** Execute the “Numeric bounds” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C035-T07 · Outcome comparison:** Compare every declared “Numeric bounds” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C035-T08 · State and bounds check:** Inspect the “Numeric bounds” ownership/state effects and actual use of “Integer widths and arithmetic cases”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C035-T09 · Repeatability check:** Repeat the same “Numeric bounds” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C035-T10 · Positive evidence:** Attach the “Numeric bounds” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C036 · Negative test

**Original checklist item:** Negative case: Payload length plus header size wraps during validation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Numeric bounds” source counterexample: “Payload length plus header size wraps during validation”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Numeric bounds”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C036-T03 · Valid control:** Construct a valid “Numeric bounds” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C036-T04 · Minimal adverse input:** Derive the “Numeric bounds” adverse fixture from the control with the smallest documented change needed to reproduce “Payload length plus header size wraps during validation”; retain that change as reproducible data.
- [ ] **UC-M08.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Numeric bounds”; require “Numeric overflow cannot bypass a frame boundary check” and forbid a false-success verdict.
- [ ] **UC-M08.02-C036-T06 · Adverse execution:** Exercise the “Numeric bounds” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C036-T07 · Effect inspection:** Inspect “Numeric bounds” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C036-T08 · Refusal versus failure:** Confirm the “Numeric bounds” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C036-T09 · Reset and retention:** Restore only the disposable “Numeric bounds” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C036-T10 · Negative regression:** Register the “Numeric bounds” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C037 · Change / failure test

**Original checklist item:** Exercise numeric bounds when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C037-T01 · Scenario record:** Write the “Numeric bounds” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “Numeric overflow cannot bypass a frame boundary check”.
- [ ] **UC-M08.02-C037-T02 · Baseline capture:** Create a known-valid “Numeric bounds” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C037-T03 · Injection map:** Locate the “Numeric bounds” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Numeric bounds” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C037-T05 · Controlled trigger:** Introduce the controlled “Numeric bounds” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C037-T06 · Intermediate inspection:** Inspect the “Numeric bounds” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Numeric bounds”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Numeric bounds” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C037-T09 · Repeat and compare:** Repeat the selected “Numeric bounds” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C037-T10 · Failure evidence:** Publish the “Numeric bounds” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for integer widths and arithmetic cases; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Numeric bounds”: “Integer widths and arithmetic cases”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C038-T02 · Measurement method:** Choose how to observe each “Numeric bounds” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C038-T03 · Budget decision:** Select justified resource and input limits for “Numeric bounds”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Numeric bounds” cases for “Integer widths and arithmetic cases”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Numeric bounds” limit; preserve “Numeric overflow cannot bypass a frame boundary check”.
- [ ] **UC-M08.02-C038-T06 · Normal measurement:** Run or review the normal “Numeric bounds” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C038-T07 · At-limit measurement:** Exercise the “Numeric bounds” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C038-T08 · Over-limit measurement:** Exercise the “Numeric bounds” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C038-T09 · Uncovered-scope report:** List the “Numeric bounds” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C038-T10 · Limit evidence:** Publish the selected “Numeric bounds” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for numeric bounds with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C039-T01 · Event inventory:** List the “Numeric bounds” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Numeric bounds” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C039-T03 · Failure mapping:** Map each documented “Numeric bounds” refusal or error to a diagnostic outcome; include “Payload length plus header size wraps during validation” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C039-T04 · Emission path:** Add the “Numeric bounds” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C039-T05 · Redaction check:** Test “Numeric bounds” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C039-T06 · Output budget:** Set and exercise bounded “Numeric bounds” message size, rate and retention compatible with “Integer widths and arithmetic cases”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C039-T07 · Success/refusal fixtures:** Capture “Numeric bounds” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Numeric bounds” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C039-T09 · Operator review:** Read the “Numeric bounds” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C039-T10 · Diagnostic evidence:** Publish redacted “Numeric bounds” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for numeric bounds; label unexecuted checks as untested.

- [ ] **UC-M08.02-C040-T01 · Evidence inventory:** List the “Numeric bounds” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C040-T02 · Artifact references:** Record the exact “Numeric bounds” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C040-T03 · Fixture references:** Attach the “Numeric bounds” fixture IDs, input identities and oracle definition; preserve the source counterexample “Payload length plus header size wraps during validation” as a distinct evidence case.
- [ ] **UC-M08.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Numeric bounds”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C040-T05 · Environment record:** Record the actual “Numeric bounds” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C040-T06 · Expected versus observed:** Pair every “Numeric bounds” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C040-T07 · Failure and limit records:** Attach “Numeric bounds” change/failure and bounds evidence where required; include uncovered “Integer widths and arithmetic cases” and unresolved violations of “Numeric overflow cannot bypass a frame boundary check”.
- [ ] **UC-M08.02-C040-T08 · Evidence hygiene:** Check the “Numeric bounds” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C040-T09 · Reproduction review:** Have the “Numeric bounds” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C040-T10 · Acceptance linkage:** Link the “Numeric bounds” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Duplicate-field refusal

**Source delivery:** Reject competing values for fields that must be unique.

**Source invariant:** A frame cannot redefine its operation or generation through duplicate fields.

**Source negative case:** A serialized request repeats its target-generation field.

**Source bounded quantities:** Unique fields and duplicate-detection memory.

### UC-M08.02-C041 · Contract

**Original checklist item:** Specify duplicate-field refusal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C041-T01 · Scope statement:** Draft the operation boundary for “Duplicate-field refusal” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Duplicate-field refusal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C041-T03 · Output inventory:** List the outputs of “Duplicate-field refusal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Duplicate-field refusal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C041-T05 · Prerequisite contract:** Map “Duplicate-field refusal” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Duplicate-field refusal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C041-T07 · Invariant clause:** Add a normative clause for “Duplicate-field refusal” that preserves “A frame cannot redefine its operation or generation through duplicate fields”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Duplicate-field refusal”; include the source counterexample “A serialized request repeats its target-generation field” and the intended safe disposition.
- [ ] **UC-M08.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Unique fields and duplicate-detection memory” in the “Duplicate-field refusal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C041-T10 · Contract review:** Review the “Duplicate-field refusal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C042 · Delivery

**Original checklist item:** Reject competing values for fields that must be unique.

- [ ] **UC-M08.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Duplicate-field refusal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C042-T02 · Change plan:** Break the source delivery for “Duplicate-field refusal” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Duplicate-field refusal” that realizes this source instruction: Reject competing values for fields that must be unique.
- [ ] **UC-M08.02-C042-T04 · Concrete realization:** Trace “Duplicate-field refusal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Duplicate-field refusal” needed to preserve “A frame cannot redefine its operation or generation through duplicate fields”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C042-T06 · Dependency connection:** Connect the “Duplicate-field refusal” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C042-T07 · Resource behavior:** Account for “Unique fields and duplicate-detection memory” in “Duplicate-field refusal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C042-T08 · Delivery check:** Run the smallest real “Duplicate-field refusal” path and its adverse fixture “A serialized request repeats its target-generation field”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C042-T09 · Patch review:** Review the “Duplicate-field refusal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C042-T10 · Delivery handoff:** Publish the “Duplicate-field refusal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A frame cannot redefine its operation or generation through duplicate fields. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Duplicate-field refusal”; copy its required invariant exactly: “A frame cannot redefine its operation or generation through duplicate fields”.
- [ ] **UC-M08.02-C043-T02 · Observable terms:** Define each term in the “Duplicate-field refusal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C043-T03 · Precondition set:** List the preconditions under which “A frame cannot redefine its operation or generation through duplicate fields” must hold for “Duplicate-field refusal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C043-T04 · Transition coverage:** Map the “Duplicate-field refusal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Duplicate-field refusal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C043-T06 · Satisfying fixture:** Create a concrete “Duplicate-field refusal” case that satisfies “A frame cannot redefine its operation or generation through duplicate fields”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C043-T07 · Violating fixture:** Create the source counterexample “A serialized request repeats its target-generation field” for “Duplicate-field refusal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C043-T08 · Enforcement evidence:** Exercise the “Duplicate-field refusal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C043-T09 · Regression linkage:** Link the “Duplicate-field refusal” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Duplicate-field refusal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C044 · Integration

**Original checklist item:** Integrate duplicate-field refusal with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Duplicate-field refusal” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C044-T02 · Field mapping:** Map every “Duplicate-field refusal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Duplicate-field refusal” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C044-T04 · Ownership agreement:** Specify who owns “Duplicate-field refusal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C044-T05 · Handoff implementation:** Connect “Duplicate-field refusal” through the mapped seam using the real adapter or explicit specification reference; preserve “A frame cannot redefine its operation or generation through duplicate fields” across the handoff.
- [ ] **UC-M08.02-C044-T06 · Absent-input case:** Omit one required “Duplicate-field refusal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C044-T07 · Stale-input case:** Supply an outdated “Duplicate-field refusal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Duplicate-field refusal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C044-T09 · Valid integration trace:** Run a valid “Duplicate-field refusal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C044-T10 · Seam review:** Reconcile the “Duplicate-field refusal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for duplicate-field refusal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Duplicate-field refusal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C045-T02 · Expected-result oracle:** Specify the “Duplicate-field refusal” expected result independently of the implementation output; include the property “A frame cannot redefine its operation or generation through duplicate fields” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C045-T03 · Fixture material:** Create the concrete “Duplicate-field refusal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C045-T04 · Target preparation:** Prepare the “Duplicate-field refusal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C045-T05 · Initial-state record:** Record the initial “Duplicate-field refusal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C045-T06 · Valid-path execution:** Execute the “Duplicate-field refusal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C045-T07 · Outcome comparison:** Compare every declared “Duplicate-field refusal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C045-T08 · State and bounds check:** Inspect the “Duplicate-field refusal” ownership/state effects and actual use of “Unique fields and duplicate-detection memory”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C045-T09 · Repeatability check:** Repeat the same “Duplicate-field refusal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C045-T10 · Positive evidence:** Attach the “Duplicate-field refusal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C046 · Negative test

**Original checklist item:** Negative case: A serialized request repeats its target-generation field. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Duplicate-field refusal” source counterexample: “A serialized request repeats its target-generation field”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Duplicate-field refusal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C046-T03 · Valid control:** Construct a valid “Duplicate-field refusal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C046-T04 · Minimal adverse input:** Derive the “Duplicate-field refusal” adverse fixture from the control with the smallest documented change needed to reproduce “A serialized request repeats its target-generation field”; retain that change as reproducible data.
- [ ] **UC-M08.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Duplicate-field refusal”; require “A frame cannot redefine its operation or generation through duplicate fields” and forbid a false-success verdict.
- [ ] **UC-M08.02-C046-T06 · Adverse execution:** Exercise the “Duplicate-field refusal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C046-T07 · Effect inspection:** Inspect “Duplicate-field refusal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C046-T08 · Refusal versus failure:** Confirm the “Duplicate-field refusal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C046-T09 · Reset and retention:** Restore only the disposable “Duplicate-field refusal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C046-T10 · Negative regression:** Register the “Duplicate-field refusal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C047 · Change / failure test

**Original checklist item:** Exercise duplicate-field refusal when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C047-T01 · Scenario record:** Write the “Duplicate-field refusal” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “A frame cannot redefine its operation or generation through duplicate fields”.
- [ ] **UC-M08.02-C047-T02 · Baseline capture:** Create a known-valid “Duplicate-field refusal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C047-T03 · Injection map:** Locate the “Duplicate-field refusal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Duplicate-field refusal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C047-T05 · Controlled trigger:** Introduce the controlled “Duplicate-field refusal” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C047-T06 · Intermediate inspection:** Inspect the “Duplicate-field refusal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Duplicate-field refusal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Duplicate-field refusal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C047-T09 · Repeat and compare:** Repeat the selected “Duplicate-field refusal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C047-T10 · Failure evidence:** Publish the “Duplicate-field refusal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for unique fields and duplicate-detection memory; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Duplicate-field refusal”: “Unique fields and duplicate-detection memory”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C048-T02 · Measurement method:** Choose how to observe each “Duplicate-field refusal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C048-T03 · Budget decision:** Select justified resource and input limits for “Duplicate-field refusal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Duplicate-field refusal” cases for “Unique fields and duplicate-detection memory”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Duplicate-field refusal” limit; preserve “A frame cannot redefine its operation or generation through duplicate fields”.
- [ ] **UC-M08.02-C048-T06 · Normal measurement:** Run or review the normal “Duplicate-field refusal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C048-T07 · At-limit measurement:** Exercise the “Duplicate-field refusal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C048-T08 · Over-limit measurement:** Exercise the “Duplicate-field refusal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C048-T09 · Uncovered-scope report:** List the “Duplicate-field refusal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C048-T10 · Limit evidence:** Publish the selected “Duplicate-field refusal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for duplicate-field refusal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C049-T01 · Event inventory:** List the “Duplicate-field refusal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Duplicate-field refusal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C049-T03 · Failure mapping:** Map each documented “Duplicate-field refusal” refusal or error to a diagnostic outcome; include “A serialized request repeats its target-generation field” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C049-T04 · Emission path:** Add the “Duplicate-field refusal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C049-T05 · Redaction check:** Test “Duplicate-field refusal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C049-T06 · Output budget:** Set and exercise bounded “Duplicate-field refusal” message size, rate and retention compatible with “Unique fields and duplicate-detection memory”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C049-T07 · Success/refusal fixtures:** Capture “Duplicate-field refusal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Duplicate-field refusal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C049-T09 · Operator review:** Read the “Duplicate-field refusal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C049-T10 · Diagnostic evidence:** Publish redacted “Duplicate-field refusal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for duplicate-field refusal; label unexecuted checks as untested.

- [ ] **UC-M08.02-C050-T01 · Evidence inventory:** List the “Duplicate-field refusal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C050-T02 · Artifact references:** Record the exact “Duplicate-field refusal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C050-T03 · Fixture references:** Attach the “Duplicate-field refusal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A serialized request repeats its target-generation field” as a distinct evidence case.
- [ ] **UC-M08.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Duplicate-field refusal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C050-T05 · Environment record:** Record the actual “Duplicate-field refusal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C050-T06 · Expected versus observed:** Pair every “Duplicate-field refusal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C050-T07 · Failure and limit records:** Attach “Duplicate-field refusal” change/failure and bounds evidence where required; include uncovered “Unique fields and duplicate-detection memory” and unresolved violations of “A frame cannot redefine its operation or generation through duplicate fields”.
- [ ] **UC-M08.02-C050-T08 · Evidence hygiene:** Check the “Duplicate-field refusal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C050-T09 · Reproduction review:** Have the “Duplicate-field refusal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C050-T10 · Acceptance linkage:** Link the “Duplicate-field refusal” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Version compatibility

**Source delivery:** Negotiate or reject frame versions according to the IPC contract.

**Source invariant:** Incompatible messages are not decoded using guessed legacy rules.

**Source negative case:** A future frame version is accepted with current field defaults.

**Source bounded quantities:** Supported versions and negotiation exchanges.

### UC-M08.02-C051 · Contract

**Original checklist item:** Specify version compatibility inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C051-T01 · Scope statement:** Draft the operation boundary for “Version compatibility” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Version compatibility”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C051-T03 · Output inventory:** List the outputs of “Version compatibility” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Version compatibility”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C051-T05 · Prerequisite contract:** Map “Version compatibility” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Version compatibility”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C051-T07 · Invariant clause:** Add a normative clause for “Version compatibility” that preserves “Incompatible messages are not decoded using guessed legacy rules”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Version compatibility”; include the source counterexample “A future frame version is accepted with current field defaults” and the intended safe disposition.
- [ ] **UC-M08.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Supported versions and negotiation exchanges” in the “Version compatibility” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C051-T10 · Contract review:** Review the “Version compatibility” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C052 · Delivery

**Original checklist item:** Negotiate or reject frame versions according to the IPC contract.

- [ ] **UC-M08.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Version compatibility”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C052-T02 · Change plan:** Break the source delivery for “Version compatibility” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Version compatibility” that realizes this source instruction: Negotiate or reject frame versions according to the IPC contract.
- [ ] **UC-M08.02-C052-T04 · Concrete realization:** Trace “Version compatibility” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Version compatibility” needed to preserve “Incompatible messages are not decoded using guessed legacy rules”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C052-T06 · Dependency connection:** Connect the “Version compatibility” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C052-T07 · Resource behavior:** Account for “Supported versions and negotiation exchanges” in “Version compatibility”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C052-T08 · Delivery check:** Run the smallest real “Version compatibility” path and its adverse fixture “A future frame version is accepted with current field defaults”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C052-T09 · Patch review:** Review the “Version compatibility” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C052-T10 · Delivery handoff:** Publish the “Version compatibility” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Incompatible messages are not decoded using guessed legacy rules. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Version compatibility”; copy its required invariant exactly: “Incompatible messages are not decoded using guessed legacy rules”.
- [ ] **UC-M08.02-C053-T02 · Observable terms:** Define each term in the “Version compatibility” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C053-T03 · Precondition set:** List the preconditions under which “Incompatible messages are not decoded using guessed legacy rules” must hold for “Version compatibility”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C053-T04 · Transition coverage:** Map the “Version compatibility” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Version compatibility”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C053-T06 · Satisfying fixture:** Create a concrete “Version compatibility” case that satisfies “Incompatible messages are not decoded using guessed legacy rules”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C053-T07 · Violating fixture:** Create the source counterexample “A future frame version is accepted with current field defaults” for “Version compatibility”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C053-T08 · Enforcement evidence:** Exercise the “Version compatibility” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C053-T09 · Regression linkage:** Link the “Version compatibility” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Version compatibility” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C054 · Integration

**Original checklist item:** Integrate version compatibility with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Version compatibility” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C054-T02 · Field mapping:** Map every “Version compatibility” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Version compatibility” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C054-T04 · Ownership agreement:** Specify who owns “Version compatibility” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C054-T05 · Handoff implementation:** Connect “Version compatibility” through the mapped seam using the real adapter or explicit specification reference; preserve “Incompatible messages are not decoded using guessed legacy rules” across the handoff.
- [ ] **UC-M08.02-C054-T06 · Absent-input case:** Omit one required “Version compatibility” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C054-T07 · Stale-input case:** Supply an outdated “Version compatibility” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Version compatibility” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C054-T09 · Valid integration trace:** Run a valid “Version compatibility” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C054-T10 · Seam review:** Reconcile the “Version compatibility” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for version compatibility; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Version compatibility” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C055-T02 · Expected-result oracle:** Specify the “Version compatibility” expected result independently of the implementation output; include the property “Incompatible messages are not decoded using guessed legacy rules” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C055-T03 · Fixture material:** Create the concrete “Version compatibility” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C055-T04 · Target preparation:** Prepare the “Version compatibility” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C055-T05 · Initial-state record:** Record the initial “Version compatibility” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C055-T06 · Valid-path execution:** Execute the “Version compatibility” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C055-T07 · Outcome comparison:** Compare every declared “Version compatibility” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C055-T08 · State and bounds check:** Inspect the “Version compatibility” ownership/state effects and actual use of “Supported versions and negotiation exchanges”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C055-T09 · Repeatability check:** Repeat the same “Version compatibility” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C055-T10 · Positive evidence:** Attach the “Version compatibility” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C056 · Negative test

**Original checklist item:** Negative case: A future frame version is accepted with current field defaults. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Version compatibility” source counterexample: “A future frame version is accepted with current field defaults”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Version compatibility”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C056-T03 · Valid control:** Construct a valid “Version compatibility” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C056-T04 · Minimal adverse input:** Derive the “Version compatibility” adverse fixture from the control with the smallest documented change needed to reproduce “A future frame version is accepted with current field defaults”; retain that change as reproducible data.
- [ ] **UC-M08.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Version compatibility”; require “Incompatible messages are not decoded using guessed legacy rules” and forbid a false-success verdict.
- [ ] **UC-M08.02-C056-T06 · Adverse execution:** Exercise the “Version compatibility” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C056-T07 · Effect inspection:** Inspect “Version compatibility” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C056-T08 · Refusal versus failure:** Confirm the “Version compatibility” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C056-T09 · Reset and retention:** Restore only the disposable “Version compatibility” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C056-T10 · Negative regression:** Register the “Version compatibility” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C057 · Change / failure test

**Original checklist item:** Exercise version compatibility when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C057-T01 · Scenario record:** Write the “Version compatibility” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “Incompatible messages are not decoded using guessed legacy rules”.
- [ ] **UC-M08.02-C057-T02 · Baseline capture:** Create a known-valid “Version compatibility” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C057-T03 · Injection map:** Locate the “Version compatibility” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Version compatibility” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C057-T05 · Controlled trigger:** Introduce the controlled “Version compatibility” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C057-T06 · Intermediate inspection:** Inspect the “Version compatibility” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Version compatibility”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Version compatibility” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C057-T09 · Repeat and compare:** Repeat the selected “Version compatibility” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C057-T10 · Failure evidence:** Publish the “Version compatibility” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for supported versions and negotiation exchanges; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Version compatibility”: “Supported versions and negotiation exchanges”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C058-T02 · Measurement method:** Choose how to observe each “Version compatibility” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Version compatibility”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Version compatibility” cases for “Supported versions and negotiation exchanges”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Version compatibility” limit; preserve “Incompatible messages are not decoded using guessed legacy rules”.
- [ ] **UC-M08.02-C058-T06 · Normal measurement:** Run or review the normal “Version compatibility” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C058-T07 · At-limit measurement:** Exercise the “Version compatibility” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C058-T08 · Over-limit measurement:** Exercise the “Version compatibility” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C058-T09 · Uncovered-scope report:** List the “Version compatibility” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C058-T10 · Limit evidence:** Publish the selected “Version compatibility” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for version compatibility with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C059-T01 · Event inventory:** List the “Version compatibility” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Version compatibility” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C059-T03 · Failure mapping:** Map each documented “Version compatibility” refusal or error to a diagnostic outcome; include “A future frame version is accepted with current field defaults” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C059-T04 · Emission path:** Add the “Version compatibility” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C059-T05 · Redaction check:** Test “Version compatibility” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C059-T06 · Output budget:** Set and exercise bounded “Version compatibility” message size, rate and retention compatible with “Supported versions and negotiation exchanges”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C059-T07 · Success/refusal fixtures:** Capture “Version compatibility” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Version compatibility” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C059-T09 · Operator review:** Read the “Version compatibility” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C059-T10 · Diagnostic evidence:** Publish redacted “Version compatibility” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for version compatibility; label unexecuted checks as untested.

- [ ] **UC-M08.02-C060-T01 · Evidence inventory:** List the “Version compatibility” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C060-T02 · Artifact references:** Record the exact “Version compatibility” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C060-T03 · Fixture references:** Attach the “Version compatibility” fixture IDs, input identities and oracle definition; preserve the source counterexample “A future frame version is accepted with current field defaults” as a distinct evidence case.
- [ ] **UC-M08.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Version compatibility”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C060-T05 · Environment record:** Record the actual “Version compatibility” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C060-T06 · Expected versus observed:** Pair every “Version compatibility” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C060-T07 · Failure and limit records:** Attach “Version compatibility” change/failure and bounds evidence where required; include uncovered “Supported versions and negotiation exchanges” and unresolved violations of “Incompatible messages are not decoded using guessed legacy rules”.
- [ ] **UC-M08.02-C060-T08 · Evidence hygiene:** Check the “Version compatibility” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C060-T09 · Reproduction review:** Have the “Version compatibility” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C060-T10 · Acceptance linkage:** Link the “Version compatibility” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Truncation handling

**Source delivery:** Detect partial headers and payloads with bounded waiting behavior.

**Source invariant:** Truncated input cannot hang a channel indefinitely.

**Source negative case:** A sender stops after half of a required header.

**Source bounded quantities:** Read timeout and partial-frame bytes.

### UC-M08.02-C061 · Contract

**Original checklist item:** Specify truncation handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C061-T01 · Scope statement:** Draft the operation boundary for “Truncation handling” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Truncation handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C061-T03 · Output inventory:** List the outputs of “Truncation handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Truncation handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C061-T05 · Prerequisite contract:** Map “Truncation handling” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Truncation handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C061-T07 · Invariant clause:** Add a normative clause for “Truncation handling” that preserves “Truncated input cannot hang a channel indefinitely”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Truncation handling”; include the source counterexample “A sender stops after half of a required header” and the intended safe disposition.
- [ ] **UC-M08.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Read timeout and partial-frame bytes” in the “Truncation handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C061-T10 · Contract review:** Review the “Truncation handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C062 · Delivery

**Original checklist item:** Detect partial headers and payloads with bounded waiting behavior.

- [ ] **UC-M08.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Truncation handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C062-T02 · Change plan:** Break the source delivery for “Truncation handling” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Truncation handling” that realizes this source instruction: Detect partial headers and payloads with bounded waiting behavior.
- [ ] **UC-M08.02-C062-T04 · Concrete realization:** Trace “Truncation handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Truncation handling” needed to preserve “Truncated input cannot hang a channel indefinitely”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C062-T06 · Dependency connection:** Connect the “Truncation handling” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C062-T07 · Resource behavior:** Account for “Read timeout and partial-frame bytes” in “Truncation handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C062-T08 · Delivery check:** Run the smallest real “Truncation handling” path and its adverse fixture “A sender stops after half of a required header”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C062-T09 · Patch review:** Review the “Truncation handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C062-T10 · Delivery handoff:** Publish the “Truncation handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Truncated input cannot hang a channel indefinitely. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Truncation handling”; copy its required invariant exactly: “Truncated input cannot hang a channel indefinitely”.
- [ ] **UC-M08.02-C063-T02 · Observable terms:** Define each term in the “Truncation handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C063-T03 · Precondition set:** List the preconditions under which “Truncated input cannot hang a channel indefinitely” must hold for “Truncation handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C063-T04 · Transition coverage:** Map the “Truncation handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Truncation handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C063-T06 · Satisfying fixture:** Create a concrete “Truncation handling” case that satisfies “Truncated input cannot hang a channel indefinitely”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C063-T07 · Violating fixture:** Create the source counterexample “A sender stops after half of a required header” for “Truncation handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C063-T08 · Enforcement evidence:** Exercise the “Truncation handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C063-T09 · Regression linkage:** Link the “Truncation handling” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Truncation handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C064 · Integration

**Original checklist item:** Integrate truncation handling with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Truncation handling” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C064-T02 · Field mapping:** Map every “Truncation handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Truncation handling” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C064-T04 · Ownership agreement:** Specify who owns “Truncation handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C064-T05 · Handoff implementation:** Connect “Truncation handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Truncated input cannot hang a channel indefinitely” across the handoff.
- [ ] **UC-M08.02-C064-T06 · Absent-input case:** Omit one required “Truncation handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C064-T07 · Stale-input case:** Supply an outdated “Truncation handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Truncation handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C064-T09 · Valid integration trace:** Run a valid “Truncation handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C064-T10 · Seam review:** Reconcile the “Truncation handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for truncation handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Truncation handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C065-T02 · Expected-result oracle:** Specify the “Truncation handling” expected result independently of the implementation output; include the property “Truncated input cannot hang a channel indefinitely” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C065-T03 · Fixture material:** Create the concrete “Truncation handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C065-T04 · Target preparation:** Prepare the “Truncation handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C065-T05 · Initial-state record:** Record the initial “Truncation handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C065-T06 · Valid-path execution:** Execute the “Truncation handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C065-T07 · Outcome comparison:** Compare every declared “Truncation handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C065-T08 · State and bounds check:** Inspect the “Truncation handling” ownership/state effects and actual use of “Read timeout and partial-frame bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C065-T09 · Repeatability check:** Repeat the same “Truncation handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C065-T10 · Positive evidence:** Attach the “Truncation handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C066 · Negative test

**Original checklist item:** Negative case: A sender stops after half of a required header. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Truncation handling” source counterexample: “A sender stops after half of a required header”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Truncation handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C066-T03 · Valid control:** Construct a valid “Truncation handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C066-T04 · Minimal adverse input:** Derive the “Truncation handling” adverse fixture from the control with the smallest documented change needed to reproduce “A sender stops after half of a required header”; retain that change as reproducible data.
- [ ] **UC-M08.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Truncation handling”; require “Truncated input cannot hang a channel indefinitely” and forbid a false-success verdict.
- [ ] **UC-M08.02-C066-T06 · Adverse execution:** Exercise the “Truncation handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C066-T07 · Effect inspection:** Inspect “Truncation handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C066-T08 · Refusal versus failure:** Confirm the “Truncation handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C066-T09 · Reset and retention:** Restore only the disposable “Truncation handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C066-T10 · Negative regression:** Register the “Truncation handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C067 · Change / failure test

**Original checklist item:** Exercise truncation handling when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C067-T01 · Scenario record:** Write the “Truncation handling” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “Truncated input cannot hang a channel indefinitely”.
- [ ] **UC-M08.02-C067-T02 · Baseline capture:** Create a known-valid “Truncation handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C067-T03 · Injection map:** Locate the “Truncation handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Truncation handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C067-T05 · Controlled trigger:** Introduce the controlled “Truncation handling” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C067-T06 · Intermediate inspection:** Inspect the “Truncation handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Truncation handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Truncation handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C067-T09 · Repeat and compare:** Repeat the selected “Truncation handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C067-T10 · Failure evidence:** Publish the “Truncation handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for read timeout and partial-frame bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Truncation handling”: “Read timeout and partial-frame bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C068-T02 · Measurement method:** Choose how to observe each “Truncation handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Truncation handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Truncation handling” cases for “Read timeout and partial-frame bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Truncation handling” limit; preserve “Truncated input cannot hang a channel indefinitely”.
- [ ] **UC-M08.02-C068-T06 · Normal measurement:** Run or review the normal “Truncation handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C068-T07 · At-limit measurement:** Exercise the “Truncation handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C068-T08 · Over-limit measurement:** Exercise the “Truncation handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C068-T09 · Uncovered-scope report:** List the “Truncation handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C068-T10 · Limit evidence:** Publish the selected “Truncation handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for truncation handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C069-T01 · Event inventory:** List the “Truncation handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Truncation handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C069-T03 · Failure mapping:** Map each documented “Truncation handling” refusal or error to a diagnostic outcome; include “A sender stops after half of a required header” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C069-T04 · Emission path:** Add the “Truncation handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C069-T05 · Redaction check:** Test “Truncation handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C069-T06 · Output budget:** Set and exercise bounded “Truncation handling” message size, rate and retention compatible with “Read timeout and partial-frame bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C069-T07 · Success/refusal fixtures:** Capture “Truncation handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Truncation handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C069-T09 · Operator review:** Read the “Truncation handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C069-T10 · Diagnostic evidence:** Publish redacted “Truncation handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for truncation handling; label unexecuted checks as untested.

- [ ] **UC-M08.02-C070-T01 · Evidence inventory:** List the “Truncation handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C070-T02 · Artifact references:** Record the exact “Truncation handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C070-T03 · Fixture references:** Attach the “Truncation handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A sender stops after half of a required header” as a distinct evidence case.
- [ ] **UC-M08.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Truncation handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C070-T05 · Environment record:** Record the actual “Truncation handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C070-T06 · Expected versus observed:** Pair every “Truncation handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C070-T07 · Failure and limit records:** Attach “Truncation handling” change/failure and bounds evidence where required; include uncovered “Read timeout and partial-frame bytes” and unresolved violations of “Truncated input cannot hang a channel indefinitely”.
- [ ] **UC-M08.02-C070-T08 · Evidence hygiene:** Check the “Truncation handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C070-T09 · Reproduction review:** Have the “Truncation handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C070-T10 · Acceptance linkage:** Link the “Truncation handling” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Integrity checks

**Source delivery:** Verify the selected frame-integrity fields without treating them as identity authority.

**Source invariant:** A valid checksum cannot authorize an otherwise invalid request.

**Source negative case:** A tampered message recomputes its checksum but lacks required authority.

**Source bounded quantities:** Integrity fields and verification work.

### UC-M08.02-C071 · Contract

**Original checklist item:** Specify integrity checks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C071-T01 · Scope statement:** Draft the operation boundary for “Integrity checks” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Integrity checks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C071-T03 · Output inventory:** List the outputs of “Integrity checks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Integrity checks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C071-T05 · Prerequisite contract:** Map “Integrity checks” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Integrity checks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C071-T07 · Invariant clause:** Add a normative clause for “Integrity checks” that preserves “A valid checksum cannot authorize an otherwise invalid request”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Integrity checks”; include the source counterexample “A tampered message recomputes its checksum but lacks required authority” and the intended safe disposition.
- [ ] **UC-M08.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Integrity fields and verification work” in the “Integrity checks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C071-T10 · Contract review:** Review the “Integrity checks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C072 · Delivery

**Original checklist item:** Verify the selected frame-integrity fields without treating them as identity authority.

- [ ] **UC-M08.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Integrity checks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C072-T02 · Change plan:** Break the source delivery for “Integrity checks” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C072-T03 · Core artifact:** Create the “Integrity checks” fixture or harness for this source instruction: Verify the selected frame-integrity fields without treating them as identity authority.
- [ ] **UC-M08.02-C072-T04 · Concrete realization:** Connect the “Integrity checks” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M08.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Integrity checks” needed to preserve “A valid checksum cannot authorize an otherwise invalid request”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C072-T06 · Dependency connection:** Connect the “Integrity checks” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C072-T07 · Resource behavior:** Account for “Integrity fields and verification work” in “Integrity checks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C072-T08 · Delivery check:** Run the smallest real “Integrity checks” path and its adverse fixture “A tampered message recomputes its checksum but lacks required authority”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C072-T09 · Patch review:** Review the “Integrity checks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C072-T10 · Delivery handoff:** Publish the “Integrity checks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A valid checksum cannot authorize an otherwise invalid request. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Integrity checks”; copy its required invariant exactly: “A valid checksum cannot authorize an otherwise invalid request”.
- [ ] **UC-M08.02-C073-T02 · Observable terms:** Define each term in the “Integrity checks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C073-T03 · Precondition set:** List the preconditions under which “A valid checksum cannot authorize an otherwise invalid request” must hold for “Integrity checks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C073-T04 · Transition coverage:** Map the “Integrity checks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Integrity checks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C073-T06 · Satisfying fixture:** Create a concrete “Integrity checks” case that satisfies “A valid checksum cannot authorize an otherwise invalid request”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C073-T07 · Violating fixture:** Create the source counterexample “A tampered message recomputes its checksum but lacks required authority” for “Integrity checks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C073-T08 · Enforcement evidence:** Exercise the “Integrity checks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C073-T09 · Regression linkage:** Link the “Integrity checks” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Integrity checks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C074 · Integration

**Original checklist item:** Integrate integrity checks with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Integrity checks” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C074-T02 · Field mapping:** Map every “Integrity checks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Integrity checks” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C074-T04 · Ownership agreement:** Specify who owns “Integrity checks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C074-T05 · Handoff implementation:** Connect “Integrity checks” through the mapped seam using the real adapter or explicit specification reference; preserve “A valid checksum cannot authorize an otherwise invalid request” across the handoff.
- [ ] **UC-M08.02-C074-T06 · Absent-input case:** Omit one required “Integrity checks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C074-T07 · Stale-input case:** Supply an outdated “Integrity checks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Integrity checks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C074-T09 · Valid integration trace:** Run a valid “Integrity checks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C074-T10 · Seam review:** Reconcile the “Integrity checks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for integrity checks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Integrity checks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C075-T02 · Expected-result oracle:** Specify the “Integrity checks” expected result independently of the implementation output; include the property “A valid checksum cannot authorize an otherwise invalid request” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C075-T03 · Fixture material:** Create the concrete “Integrity checks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C075-T04 · Target preparation:** Prepare the “Integrity checks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C075-T05 · Initial-state record:** Record the initial “Integrity checks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C075-T06 · Valid-path execution:** Execute the “Integrity checks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C075-T07 · Outcome comparison:** Compare every declared “Integrity checks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C075-T08 · State and bounds check:** Inspect the “Integrity checks” ownership/state effects and actual use of “Integrity fields and verification work”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C075-T09 · Repeatability check:** Repeat the same “Integrity checks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C075-T10 · Positive evidence:** Attach the “Integrity checks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C076 · Negative test

**Original checklist item:** Negative case: A tampered message recomputes its checksum but lacks required authority. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Integrity checks” source counterexample: “A tampered message recomputes its checksum but lacks required authority”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Integrity checks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C076-T03 · Valid control:** Construct a valid “Integrity checks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C076-T04 · Minimal adverse input:** Derive the “Integrity checks” adverse fixture from the control with the smallest documented change needed to reproduce “A tampered message recomputes its checksum but lacks required authority”; retain that change as reproducible data.
- [ ] **UC-M08.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Integrity checks”; require “A valid checksum cannot authorize an otherwise invalid request” and forbid a false-success verdict.
- [ ] **UC-M08.02-C076-T06 · Adverse execution:** Exercise the “Integrity checks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C076-T07 · Effect inspection:** Inspect “Integrity checks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C076-T08 · Refusal versus failure:** Confirm the “Integrity checks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C076-T09 · Reset and retention:** Restore only the disposable “Integrity checks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C076-T10 · Negative regression:** Register the “Integrity checks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C077 · Change / failure test

**Original checklist item:** Exercise integrity checks when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C077-T01 · Scenario record:** Write the “Integrity checks” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “A valid checksum cannot authorize an otherwise invalid request”.
- [ ] **UC-M08.02-C077-T02 · Baseline capture:** Create a known-valid “Integrity checks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C077-T03 · Injection map:** Locate the “Integrity checks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Integrity checks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C077-T05 · Controlled trigger:** Introduce the controlled “Integrity checks” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C077-T06 · Intermediate inspection:** Inspect the “Integrity checks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Integrity checks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Integrity checks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C077-T09 · Repeat and compare:** Repeat the selected “Integrity checks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C077-T10 · Failure evidence:** Publish the “Integrity checks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for integrity fields and verification work; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Integrity checks”: “Integrity fields and verification work”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C078-T02 · Measurement method:** Choose how to observe each “Integrity checks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Integrity checks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Integrity checks” cases for “Integrity fields and verification work”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Integrity checks” limit; preserve “A valid checksum cannot authorize an otherwise invalid request”.
- [ ] **UC-M08.02-C078-T06 · Normal measurement:** Run or review the normal “Integrity checks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C078-T07 · At-limit measurement:** Exercise the “Integrity checks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C078-T08 · Over-limit measurement:** Exercise the “Integrity checks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C078-T09 · Uncovered-scope report:** List the “Integrity checks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C078-T10 · Limit evidence:** Publish the selected “Integrity checks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for integrity checks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C079-T01 · Event inventory:** List the “Integrity checks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Integrity checks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C079-T03 · Failure mapping:** Map each documented “Integrity checks” refusal or error to a diagnostic outcome; include “A tampered message recomputes its checksum but lacks required authority” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C079-T04 · Emission path:** Add the “Integrity checks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C079-T05 · Redaction check:** Test “Integrity checks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C079-T06 · Output budget:** Set and exercise bounded “Integrity checks” message size, rate and retention compatible with “Integrity fields and verification work”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C079-T07 · Success/refusal fixtures:** Capture “Integrity checks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Integrity checks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C079-T09 · Operator review:** Read the “Integrity checks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C079-T10 · Diagnostic evidence:** Publish redacted “Integrity checks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for integrity checks; label unexecuted checks as untested.

- [ ] **UC-M08.02-C080-T01 · Evidence inventory:** List the “Integrity checks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C080-T02 · Artifact references:** Record the exact “Integrity checks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C080-T03 · Fixture references:** Attach the “Integrity checks” fixture IDs, input identities and oracle definition; preserve the source counterexample “A tampered message recomputes its checksum but lacks required authority” as a distinct evidence case.
- [ ] **UC-M08.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Integrity checks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C080-T05 · Environment record:** Record the actual “Integrity checks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C080-T06 · Expected versus observed:** Pair every “Integrity checks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C080-T07 · Failure and limit records:** Attach “Integrity checks” change/failure and bounds evidence where required; include uncovered “Integrity fields and verification work” and unresolved violations of “A valid checksum cannot authorize an otherwise invalid request”.
- [ ] **UC-M08.02-C080-T08 · Evidence hygiene:** Check the “Integrity checks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C080-T09 · Reproduction review:** Have the “Integrity checks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C080-T10 · Acceptance linkage:** Link the “Integrity checks” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Channel resynchronization

**Source delivery:** Specify whether malformed input closes or safely resynchronizes the channel.

**Source invariant:** Rejected frames do not cause later frames to be misinterpreted.

**Source negative case:** An oversized frame causes the next valid header to be read as payload.

**Source bounded quantities:** Discard bytes and recovery attempts.

### UC-M08.02-C081 · Contract

**Original checklist item:** Specify channel resynchronization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C081-T01 · Scope statement:** Draft the operation boundary for “Channel resynchronization” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Channel resynchronization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C081-T03 · Output inventory:** List the outputs of “Channel resynchronization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Channel resynchronization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C081-T05 · Prerequisite contract:** Map “Channel resynchronization” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Channel resynchronization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C081-T07 · Invariant clause:** Add a normative clause for “Channel resynchronization” that preserves “Rejected frames do not cause later frames to be misinterpreted”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Channel resynchronization”; include the source counterexample “An oversized frame causes the next valid header to be read as payload” and the intended safe disposition.
- [ ] **UC-M08.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Discard bytes and recovery attempts” in the “Channel resynchronization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C081-T10 · Contract review:** Review the “Channel resynchronization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C082 · Delivery

**Original checklist item:** Specify whether malformed input closes or safely resynchronizes the channel.

- [ ] **UC-M08.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Channel resynchronization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C082-T02 · Change plan:** Break the source delivery for “Channel resynchronization” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C082-T03 · Core artifact:** Create the “Channel resynchronization” model, schema or inventory that realizes this source instruction: Specify whether malformed input closes or safely resynchronizes the channel.
- [ ] **UC-M08.02-C082-T04 · Concrete realization:** Populate “Channel resynchronization” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M08.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Channel resynchronization” needed to preserve “Rejected frames do not cause later frames to be misinterpreted”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C082-T06 · Dependency connection:** Connect the “Channel resynchronization” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C082-T07 · Resource behavior:** Account for “Discard bytes and recovery attempts” in “Channel resynchronization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C082-T08 · Delivery check:** Run the smallest real “Channel resynchronization” path and its adverse fixture “An oversized frame causes the next valid header to be read as payload”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C082-T09 · Patch review:** Review the “Channel resynchronization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C082-T10 · Delivery handoff:** Publish the “Channel resynchronization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rejected frames do not cause later frames to be misinterpreted. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Channel resynchronization”; copy its required invariant exactly: “Rejected frames do not cause later frames to be misinterpreted”.
- [ ] **UC-M08.02-C083-T02 · Observable terms:** Define each term in the “Channel resynchronization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C083-T03 · Precondition set:** List the preconditions under which “Rejected frames do not cause later frames to be misinterpreted” must hold for “Channel resynchronization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C083-T04 · Transition coverage:** Map the “Channel resynchronization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Channel resynchronization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C083-T06 · Satisfying fixture:** Create a concrete “Channel resynchronization” case that satisfies “Rejected frames do not cause later frames to be misinterpreted”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C083-T07 · Violating fixture:** Create the source counterexample “An oversized frame causes the next valid header to be read as payload” for “Channel resynchronization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C083-T08 · Enforcement evidence:** Exercise the “Channel resynchronization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C083-T09 · Regression linkage:** Link the “Channel resynchronization” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Channel resynchronization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C084 · Integration

**Original checklist item:** Integrate channel resynchronization with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Channel resynchronization” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C084-T02 · Field mapping:** Map every “Channel resynchronization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Channel resynchronization” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C084-T04 · Ownership agreement:** Specify who owns “Channel resynchronization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C084-T05 · Handoff implementation:** Connect “Channel resynchronization” through the mapped seam using the real adapter or explicit specification reference; preserve “Rejected frames do not cause later frames to be misinterpreted” across the handoff.
- [ ] **UC-M08.02-C084-T06 · Absent-input case:** Omit one required “Channel resynchronization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C084-T07 · Stale-input case:** Supply an outdated “Channel resynchronization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Channel resynchronization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C084-T09 · Valid integration trace:** Run a valid “Channel resynchronization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C084-T10 · Seam review:** Reconcile the “Channel resynchronization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for channel resynchronization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Channel resynchronization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C085-T02 · Expected-result oracle:** Specify the “Channel resynchronization” expected result independently of the implementation output; include the property “Rejected frames do not cause later frames to be misinterpreted” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C085-T03 · Fixture material:** Create the concrete “Channel resynchronization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C085-T04 · Target preparation:** Prepare the “Channel resynchronization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C085-T05 · Initial-state record:** Record the initial “Channel resynchronization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C085-T06 · Valid-path execution:** Execute the “Channel resynchronization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C085-T07 · Outcome comparison:** Compare every declared “Channel resynchronization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C085-T08 · State and bounds check:** Inspect the “Channel resynchronization” ownership/state effects and actual use of “Discard bytes and recovery attempts”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C085-T09 · Repeatability check:** Repeat the same “Channel resynchronization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C085-T10 · Positive evidence:** Attach the “Channel resynchronization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C086 · Negative test

**Original checklist item:** Negative case: An oversized frame causes the next valid header to be read as payload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Channel resynchronization” source counterexample: “An oversized frame causes the next valid header to be read as payload”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Channel resynchronization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C086-T03 · Valid control:** Construct a valid “Channel resynchronization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C086-T04 · Minimal adverse input:** Derive the “Channel resynchronization” adverse fixture from the control with the smallest documented change needed to reproduce “An oversized frame causes the next valid header to be read as payload”; retain that change as reproducible data.
- [ ] **UC-M08.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Channel resynchronization”; require “Rejected frames do not cause later frames to be misinterpreted” and forbid a false-success verdict.
- [ ] **UC-M08.02-C086-T06 · Adverse execution:** Exercise the “Channel resynchronization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C086-T07 · Effect inspection:** Inspect “Channel resynchronization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C086-T08 · Refusal versus failure:** Confirm the “Channel resynchronization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C086-T09 · Reset and retention:** Restore only the disposable “Channel resynchronization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C086-T10 · Negative regression:** Register the “Channel resynchronization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C087 · Change / failure test

**Original checklist item:** Exercise channel resynchronization when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C087-T01 · Scenario record:** Write the “Channel resynchronization” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “Rejected frames do not cause later frames to be misinterpreted”.
- [ ] **UC-M08.02-C087-T02 · Baseline capture:** Create a known-valid “Channel resynchronization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C087-T03 · Injection map:** Locate the “Channel resynchronization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Channel resynchronization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C087-T05 · Controlled trigger:** Introduce the controlled “Channel resynchronization” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C087-T06 · Intermediate inspection:** Inspect the “Channel resynchronization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Channel resynchronization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Channel resynchronization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C087-T09 · Repeat and compare:** Repeat the selected “Channel resynchronization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C087-T10 · Failure evidence:** Publish the “Channel resynchronization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for discard bytes and recovery attempts; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Channel resynchronization”: “Discard bytes and recovery attempts”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C088-T02 · Measurement method:** Choose how to observe each “Channel resynchronization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Channel resynchronization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Channel resynchronization” cases for “Discard bytes and recovery attempts”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Channel resynchronization” limit; preserve “Rejected frames do not cause later frames to be misinterpreted”.
- [ ] **UC-M08.02-C088-T06 · Normal measurement:** Run or review the normal “Channel resynchronization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C088-T07 · At-limit measurement:** Exercise the “Channel resynchronization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C088-T08 · Over-limit measurement:** Exercise the “Channel resynchronization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C088-T09 · Uncovered-scope report:** List the “Channel resynchronization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C088-T10 · Limit evidence:** Publish the selected “Channel resynchronization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for channel resynchronization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C089-T01 · Event inventory:** List the “Channel resynchronization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Channel resynchronization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C089-T03 · Failure mapping:** Map each documented “Channel resynchronization” refusal or error to a diagnostic outcome; include “An oversized frame causes the next valid header to be read as payload” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C089-T04 · Emission path:** Add the “Channel resynchronization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C089-T05 · Redaction check:** Test “Channel resynchronization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C089-T06 · Output budget:** Set and exercise bounded “Channel resynchronization” message size, rate and retention compatible with “Discard bytes and recovery attempts”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C089-T07 · Success/refusal fixtures:** Capture “Channel resynchronization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Channel resynchronization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C089-T09 · Operator review:** Read the “Channel resynchronization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C089-T10 · Diagnostic evidence:** Publish redacted “Channel resynchronization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for channel resynchronization; label unexecuted checks as untested.

- [ ] **UC-M08.02-C090-T01 · Evidence inventory:** List the “Channel resynchronization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C090-T02 · Artifact references:** Record the exact “Channel resynchronization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C090-T03 · Fixture references:** Attach the “Channel resynchronization” fixture IDs, input identities and oracle definition; preserve the source counterexample “An oversized frame causes the next valid header to be read as payload” as a distinct evidence case.
- [ ] **UC-M08.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Channel resynchronization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C090-T05 · Environment record:** Record the actual “Channel resynchronization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C090-T06 · Expected versus observed:** Pair every “Channel resynchronization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C090-T07 · Failure and limit records:** Attach “Channel resynchronization” change/failure and bounds evidence where required; include uncovered “Discard bytes and recovery attempts” and unresolved violations of “Rejected frames do not cause later frames to be misinterpreted”.
- [ ] **UC-M08.02-C090-T08 · Evidence hygiene:** Check the “Channel resynchronization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C090-T09 · Reproduction review:** Have the “Channel resynchronization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C090-T10 · Acceptance linkage:** Link the “Channel resynchronization” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Serialization fixtures

**Source delivery:** Maintain valid, truncated, duplicate, oversized and incompatible-version vectors.

**Source invariant:** Every rejection preserves the documented channel disposition.

**Source negative case:** The decoder rejects one frame but silently executes its trailing bytes.

**Source bounded quantities:** Vector count and total corpus bytes.

### UC-M08.02-C091 · Contract

**Original checklist item:** Specify serialization fixtures inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M08.02-C091-T01 · Scope statement:** Draft the operation boundary for “Serialization fixtures” within Message framing and versioned serialization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M08.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Serialization fixtures”; record each producer, representation and missing-value meaning.
- [ ] **UC-M08.02-C091-T03 · Output inventory:** List the outputs of “Serialization fixtures” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M08.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Serialization fixtures”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M08.02-C091-T05 · Prerequisite contract:** Map “Serialization fixtures” to the source component prerequisites (UC-M08.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M08.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Serialization fixtures”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M08.02-C091-T07 · Invariant clause:** Add a normative clause for “Serialization fixtures” that preserves “Every rejection preserves the documented channel disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M08.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Serialization fixtures”; include the source counterexample “The decoder rejects one frame but silently executes its trailing bytes” and the intended safe disposition.
- [ ] **UC-M08.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Vector count and total corpus bytes” in the “Serialization fixtures” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M08.02-C091-T10 · Contract review:** Review the “Serialization fixtures” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M08.02-C092 · Delivery

**Original checklist item:** Maintain valid, truncated, duplicate, oversized and incompatible-version vectors.

- [ ] **UC-M08.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Serialization fixtures”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M08.02-C092-T02 · Change plan:** Break the source delivery for “Serialization fixtures” into concrete edit targets and reviewable outputs; keep the UC-M08.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M08.02-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Serialization fixtures” that realizes this source instruction: Maintain valid, truncated, duplicate, oversized and incompatible-version vectors.
- [ ] **UC-M08.02-C092-T04 · Concrete realization:** Trace “Serialization fixtures” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M08.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Serialization fixtures” needed to preserve “Every rejection preserves the documented channel disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M08.02-C092-T06 · Dependency connection:** Connect the “Serialization fixtures” implementation to transport framing, typed message decoding and channel error disposition; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M08.02-C092-T07 · Resource behavior:** Account for “Vector count and total corpus bytes” in “Serialization fixtures”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M08.02-C092-T08 · Delivery check:** Run the smallest real “Serialization fixtures” path and its adverse fixture “The decoder rejects one frame but silently executes its trailing bytes”; retain actual output, state effects and final disposition.
- [ ] **UC-M08.02-C092-T09 · Patch review:** Review the “Serialization fixtures” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M08.02-C092-T10 · Delivery handoff:** Publish the “Serialization fixtures” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M08.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every rejection preserves the documented channel disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M08.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Serialization fixtures”; copy its required invariant exactly: “Every rejection preserves the documented channel disposition”.
- [ ] **UC-M08.02-C093-T02 · Observable terms:** Define each term in the “Serialization fixtures” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M08.02-C093-T03 · Precondition set:** List the preconditions under which “Every rejection preserves the documented channel disposition” must hold for “Serialization fixtures”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M08.02-C093-T04 · Transition coverage:** Map the “Serialization fixtures” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M08.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Serialization fixtures”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M08.02-C093-T06 · Satisfying fixture:** Create a concrete “Serialization fixtures” case that satisfies “Every rejection preserves the documented channel disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M08.02-C093-T07 · Violating fixture:** Create the source counterexample “The decoder rejects one frame but silently executes its trailing bytes” for “Serialization fixtures”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M08.02-C093-T08 · Enforcement evidence:** Exercise the “Serialization fixtures” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M08.02-C093-T09 · Regression linkage:** Link the “Serialization fixtures” property to changes in transport framing, typed message decoding and channel error disposition; record which dependency or contract changes require rerunning it.
- [ ] **UC-M08.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Serialization fixtures” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M08.02-C094 · Integration

**Original checklist item:** Integrate serialization fixtures with transport framing, typed message decoding and channel error disposition; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M08.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Serialization fixtures” across transport framing, typed message decoding and channel error disposition; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M08.02-C094-T02 · Field mapping:** Map every “Serialization fixtures” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M08.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Serialization fixtures” (source dependency list: UC-M08.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M08.02-C094-T04 · Ownership agreement:** Specify who owns “Serialization fixtures” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M08.02-C094-T05 · Handoff implementation:** Connect “Serialization fixtures” through the mapped seam using the real adapter or explicit specification reference; preserve “Every rejection preserves the documented channel disposition” across the handoff.
- [ ] **UC-M08.02-C094-T06 · Absent-input case:** Omit one required “Serialization fixtures” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M08.02-C094-T07 · Stale-input case:** Supply an outdated “Serialization fixtures” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M08.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Serialization fixtures” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M08.02-C094-T09 · Valid integration trace:** Run a valid “Serialization fixtures” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M08.02-C094-T10 · Seam review:** Reconcile the “Serialization fixtures” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M08.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for serialization fixtures; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M08.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Serialization fixtures” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M08.02-C095-T02 · Expected-result oracle:** Specify the “Serialization fixtures” expected result independently of the implementation output; include the property “Every rejection preserves the documented channel disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M08.02-C095-T03 · Fixture material:** Create the concrete “Serialization fixtures” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M08.02-C095-T04 · Target preparation:** Prepare the “Serialization fixtures” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M08.02-C095-T05 · Initial-state record:** Record the initial “Serialization fixtures” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M08.02-C095-T06 · Valid-path execution:** Execute the “Serialization fixtures” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M08.02-C095-T07 · Outcome comparison:** Compare every declared “Serialization fixtures” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M08.02-C095-T08 · State and bounds check:** Inspect the “Serialization fixtures” ownership/state effects and actual use of “Vector count and total corpus bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M08.02-C095-T09 · Repeatability check:** Repeat the same “Serialization fixtures” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M08.02-C095-T10 · Positive evidence:** Attach the “Serialization fixtures” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M08.02-C096 · Negative test

**Original checklist item:** Negative case: The decoder rejects one frame but silently executes its trailing bytes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M08.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Serialization fixtures” source counterexample: “The decoder rejects one frame but silently executes its trailing bytes”; state which precondition or invariant it challenges.
- [ ] **UC-M08.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Serialization fixtures”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M08.02-C096-T03 · Valid control:** Construct a valid “Serialization fixtures” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M08.02-C096-T04 · Minimal adverse input:** Derive the “Serialization fixtures” adverse fixture from the control with the smallest documented change needed to reproduce “The decoder rejects one frame but silently executes its trailing bytes”; retain that change as reproducible data.
- [ ] **UC-M08.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Serialization fixtures”; require “Every rejection preserves the documented channel disposition” and forbid a false-success verdict.
- [ ] **UC-M08.02-C096-T06 · Adverse execution:** Exercise the “Serialization fixtures” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M08.02-C096-T07 · Effect inspection:** Inspect “Serialization fixtures” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M08.02-C096-T08 · Refusal versus failure:** Confirm the “Serialization fixtures” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M08.02-C096-T09 · Reset and retention:** Restore only the disposable “Serialization fixtures” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M08.02-C096-T10 · Negative regression:** Register the “Serialization fixtures” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M08.02-C097 · Change / failure test

**Original checklist item:** Exercise serialization fixtures when a truncated or rejected frame is followed by a valid frame; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M08.02-C097-T01 · Scenario record:** Write the “Serialization fixtures” change/failure scenario exactly as supplied: a truncated or rejected frame is followed by a valid frame; identify the property that must remain true: “Every rejection preserves the documented channel disposition”.
- [ ] **UC-M08.02-C097-T02 · Baseline capture:** Create a known-valid “Serialization fixtures” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M08.02-C097-T03 · Injection map:** Locate the “Serialization fixtures” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M08.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Serialization fixtures” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M08.02-C097-T05 · Controlled trigger:** Introduce the controlled “Serialization fixtures” scenario in the disposable fixture: a truncated or rejected frame is followed by a valid frame; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M08.02-C097-T06 · Intermediate inspection:** Inspect the “Serialization fixtures” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M08.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Serialization fixtures”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M08.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Serialization fixtures” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M08.02-C097-T09 · Repeat and compare:** Repeat the selected “Serialization fixtures” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M08.02-C097-T10 · Failure evidence:** Publish the “Serialization fixtures” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M08.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for vector count and total corpus bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M08.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Serialization fixtures”: “Vector count and total corpus bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M08.02-C098-T02 · Measurement method:** Choose how to observe each “Serialization fixtures” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M08.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Serialization fixtures”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M08.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Serialization fixtures” cases for “Vector count and total corpus bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M08.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Serialization fixtures” limit; preserve “Every rejection preserves the documented channel disposition”.
- [ ] **UC-M08.02-C098-T06 · Normal measurement:** Run or review the normal “Serialization fixtures” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M08.02-C098-T07 · At-limit measurement:** Exercise the “Serialization fixtures” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M08.02-C098-T08 · Over-limit measurement:** Exercise the “Serialization fixtures” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M08.02-C098-T09 · Uncovered-scope report:** List the “Serialization fixtures” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M08.02-C098-T10 · Limit evidence:** Publish the selected “Serialization fixtures” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M08.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for serialization fixtures with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M08.02-C099-T01 · Event inventory:** List the “Serialization fixtures” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M08.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Serialization fixtures” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M08.02-C099-T03 · Failure mapping:** Map each documented “Serialization fixtures” refusal or error to a diagnostic outcome; include “The decoder rejects one frame but silently executes its trailing bytes” and prohibit conversion into a success message.
- [ ] **UC-M08.02-C099-T04 · Emission path:** Add the “Serialization fixtures” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M08.02-C099-T05 · Redaction check:** Test “Serialization fixtures” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M08.02-C099-T06 · Output budget:** Set and exercise bounded “Serialization fixtures” message size, rate and retention compatible with “Vector count and total corpus bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M08.02-C099-T07 · Success/refusal fixtures:** Capture “Serialization fixtures” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M08.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Serialization fixtures” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M08.02-C099-T09 · Operator review:** Read the “Serialization fixtures” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M08.02-C099-T10 · Diagnostic evidence:** Publish redacted “Serialization fixtures” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M08.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for serialization fixtures; label unexecuted checks as untested.

- [ ] **UC-M08.02-C100-T01 · Evidence inventory:** List the “Serialization fixtures” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M08.02-C100-T02 · Artifact references:** Record the exact “Serialization fixtures” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M08.02-C100-T03 · Fixture references:** Attach the “Serialization fixtures” fixture IDs, input identities and oracle definition; preserve the source counterexample “The decoder rejects one frame but silently executes its trailing bytes” as a distinct evidence case.
- [ ] **UC-M08.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Serialization fixtures”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M08.02-C100-T05 · Environment record:** Record the actual “Serialization fixtures” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M08.02-C100-T06 · Expected versus observed:** Pair every “Serialization fixtures” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M08.02-C100-T07 · Failure and limit records:** Attach “Serialization fixtures” change/failure and bounds evidence where required; include uncovered “Vector count and total corpus bytes” and unresolved violations of “Every rejection preserves the documented channel disposition”.
- [ ] **UC-M08.02-C100-T08 · Evidence hygiene:** Check the “Serialization fixtures” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M08.02-C100-T09 · Reproduction review:** Have the “Serialization fixtures” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M08.02-C100-T10 · Acceptance linkage:** Link the “Serialization fixtures” evidence to its parent and UC-M08.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

